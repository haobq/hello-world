package jp.co.inc.media.video.utils;

import java.io.File;

import javax.imageio.ImageIO;

import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.Scene;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

public class TestMediaPlayer extends Application{

	public static void main(String[] args) {
		launch(args);
	}

	public void CaptureImage(MediaView view,int width, int height) {
		 WritableImage wim = new WritableImage(width, height);
		 MediaView mv = view;
		 mv.snapshot(null, wim);
		 try {
		   ImageIO.write(SwingFXUtils.fromFXImage(wim, null), "png", new File("test.png"));
		 } catch (Exception s) {
		   System.out.println(s);
		 }
	}

	public void start(Stage primaryStage) {
		BorderPane p = new BorderPane();
		Scene scene = new Scene(p, 800, 600);
		primaryStage.setScene(scene);
		primaryStage.show();


		//ファイルを読み込み
		Media m = new Media(new File("d:/temp/sample.mp4").toURI().toString());

		//動画の再生等の操作を実行できるオブジェクト
		MediaPlayer mp = new MediaPlayer(m);

		//動画パネルの挿入
		MediaView view = new MediaView(mp);


		p.setCenter(view);
		mp.play();
		//再生開始
		if (mp.getMedia().getWidth() >0 && mp.getMedia().getHeight()>0 ) {

			WritableImage wim = new WritableImage(mp.getMedia().getWidth(), mp.getMedia().getHeight());
			view.snapshot(null, wim);
			 try {
			   ImageIO.write(SwingFXUtils.fromFXImage(wim, null), "png", new File("c:/tmp/test.png"));
			 } catch (Exception s) {
			   System.out.println(s);
			 }
			 mp.stop();
		}

	}

}