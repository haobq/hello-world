package jp.co.inc.media.video.components;

import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasDialog;
import jp.co.inc.media.video.common.BasImage;
import jp.co.inc.media.video.common.MessageConst;

public class LoadingDialog extends BasDialog  implements BasConst, MessageConst {
	public static Pane loadingPane = new Pane();

	public LoadingDialog(Stage owner, String title, int width, int height) {
		super(owner, title, width, height);

		initStyle(StageStyle.TRANSPARENT);

		ImageView loadingView = new BasImage("loader.gif").getImageView(200, 200);
		loadingView.setPreserveRatio(false);

		loadingPane.getChildren().add(loadingView);

		loadingPane.prefWidthProperty().bind(root.getScene().widthProperty());
		loadingPane.prefHeightProperty().bind(root.getScene().heightProperty());

		loadingPane.setOnMouseClicked(event -> {
			System.out.println("=======LoadingDialog close===============");
			this.close();

		});

		root.getChildren().add(loadingPane);

	}


}
