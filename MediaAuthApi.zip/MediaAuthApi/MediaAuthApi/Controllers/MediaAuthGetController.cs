﻿using IO.Swagger.Models;
using MediaAuthApi.Models;
using MediaAuthApi.Models.Common;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace MediaAuthApi.Controllers
{
    public class MediaAuthGetController : ApiController
    {
        [HttpPost]
        public HttpResponseMessage Post()
        {
            return Request.CreateResponse(HttpStatusCode.MethodNotAllowed,
                new ApiResponse()
                {
                    ErrorCode = (int)HttpStatusCode.MethodNotAllowed,
                    Message = WebApiConstants.MsgMethodNotAllowed
                });
        }

        [HttpPost]
        [ActionName("MediaAuthGet")]
        [Route("authkey/{groupId}")]
        public HttpResponseMessage Post(string groupId, string deviceId = null, string userId = null, string pswd = null, int productKbn = 1, string sessionId = null)
        {
            // 403 (Forbidden)
            if (!HttpContext.Current.Request.Url.ToString().StartsWith("http"))
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.Forbidden,
                    Message = WebApiConstants.MsgForbidden
                });
            }

            // 400 (Bad Request)
            //必須のパラメータをチェックする
            if (string.IsNullOrEmpty(groupId) || string.IsNullOrEmpty(deviceId) || string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(pswd) || string.IsNullOrEmpty(sessionId))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.NoParam,
                    Message = WebApiConstants.MsgParameterRequired
                });
            }
            //各パラメータの形式をチェックする
            if (!Tools.IsCheckStrLen(groupId, 20) || !Tools.IsCheckStrLen(deviceId, 20) || !Tools.IsCheckStrLen(userId, 20) || !Tools.IsCheckStrLen(pswd, 80) || !Tools.IsCheckStrLen(sessionId, 50) || !Tools.IsCheckNum(productKbn))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                    Message = WebApiConstants.MsgParameterFormatError
                });
            }
            //グループIDをチェックする

            if (!Tools.IsCorrect(groupId))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.GroudIdError,
                    Message = WebApiConstants.MsgGroudIdError
                });
            }

            //端末IDをチェックする

            if (!Tools.terminal_chk(groupId, deviceId))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.NotUseTerminalId,
                    Message = WebApiConstants.MsgNotUseTerminalId
                });
            }

            //userID PSWD をチェックする
            if (!Tools.IsCorrect(groupId, userId, pswd))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.WrongUserIdOrPassword,
                    Message = WebApiConstants.MsgWrongUserIdOrPassword
                });
            }
            //古い認証データを削除する
            Tools.date_del_old();

            //hospID をチェックする
            string HospValue = Tools.Ishosp(groupId, userId);
            if (HospValue == null)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.InvalidHospId,
                    Message = WebApiConstants.MsgInvalidHospId
                });
            }

            //認証データ取得をチェックする
            int session_chk = Tools.IsSession(groupId, userId, productKbn, deviceId,sessionId);

            if(session_chk == 1)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.ExistedAuthentication,
                    Message = WebApiConstants.MsgExistedAuthentication
                });
            }else if(session_chk == 2)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.MultipleTerminal,
                    Message = WebApiConstants.MsgMultipleTerminal
                });

            }else if((session_chk == 3))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.AnotherTermina,
                    Message = WebApiConstants.MsgAnotherTermina
                });

            }

            //同時アクセスをチェックする

            if (!Tools.licenseChk(groupId,productKbn))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.ExceedMaxAccess,
                    Message = WebApiConstants.ExceedMaxAccess
                });
            }

            string Mediakey = Tools.CreateTerminalId();
            MediaAuthGet authget = new MediaAuthGet()
            {
                GroupId = groupId,
                DeviceId = deviceId,
                UserId = userId,
                Pswd = pswd,
                ProductKbn = productKbn,
                SessionId = sessionId,
                HospId = "",
                MediaAuth = Mediakey

            };
            
            MediaAuthGetJson mediaAuthGetJson = new MediaAuthGetJson()
            {
                HospId = HospValue,
                MediaAuth = Mediakey
            };

            
            //認証データを登録する
            string str = "\"" + "HospId" + "\":" + "\"" + HospValue + "\",";
                   str += "\"" + "MediaAuth" + "\":" + "\"" + Mediakey + "\",";

            string dataShow = "{" + (str.TrimEnd(new char[] { ',' })) + "}";
            string dataJson = Tools.date_insert(authget);
            if (dataJson == null)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.FailedRegister,
                    Message = WebApiConstants.MsgFailedRegister
                });
            }
            else
            {
                ApiMediaAuthGet apiAuthGet = new ApiMediaAuthGet()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.ok,
                    Message = WebApiConstants.MsgOK,
                    Data = JsonConvert.DeserializeObject<MediaAuthGetJson>(dataShow)
            };
                return Request.CreateResponse(HttpStatusCode.Unauthorized, apiAuthGet);
            }            
        }        
    }
}
