﻿using IO.Swagger.Models;
using MediaAuthApi.Models;
using MediaAuthApi.Models.Common;
using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace MediaAuthApi.Controllers
{
    public class MediaAuthDelController : ApiController
    {
        [HttpDelete]
        public HttpResponseMessage Delete()
        {
            return Request.CreateResponse(HttpStatusCode.MethodNotAllowed,
                new ApiResponse()
                {
                    ErrorCode = (int)HttpStatusCode.MethodNotAllowed,
                    Message = WebApiConstants.MsgMethodNotAllowed
                });
        }
        [HttpDelete]
        [ActionName("MediaAuthDel")]
        [Route("auth/{hospId}/{mediaAuth}")]
        public HttpResponseMessage Delete(string hospId, string mediaAuth,int productKbn=1)
        {
            // 403 (Forbidden)
            if (!HttpContext.Current.Request.Url.ToString().StartsWith("https"))
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.Forbidden,
                    Message = WebApiConstants.MsgForbidden
                });
            }

            // 400 (Bad Request)
            if (string.IsNullOrEmpty(hospId) || string.IsNullOrEmpty(mediaAuth))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.NoParam,
                    Message = WebApiConstants.MsgParameterRequired
                });
            }
            if (!Tools.IsCheckStrLen(hospId, 10) || !Tools.IsCheckStrLen(mediaAuth, 100) || !Tools.IsCheckNum(productKbn))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                    Message = WebApiConstants.MsgParameterFormatError
                });
            }
            //古い認証キー　削除をチェックする
            Tools.date_del_old();

            //認証キーを削除する
            if (!Tools.date_key_chk(mediaAuth, hospId, productKbn))
            {
                return Request.CreateResponse(HttpStatusCode.OK, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.ok,
                    Message = WebApiConstants.MsgOK
                });
            }
            else
            {
                if (!Tools.date_key_del(mediaAuth, hospId, productKbn))
                {
                    return Request.CreateResponse(HttpStatusCode.OK, new ApiResponse()
                    {
                        ErrorCode = (int)WebApiConstants.ErrorCode.ok,
                        Message = WebApiConstants.MsgOK
                    });
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.InternalServerError, new ApiResponse()
                    {
                        ErrorCode = (int)WebApiConstants.ErrorCode.FailedDelete,
                        Message = WebApiConstants.MsgFailedDelete
                    });
                }
            }


        }

        // Delete
        [Route("auth/{hospId}/{mediaAuth}")]
        public HttpResponseMessage Post(string hospId, string mediaAuth, int productKbn)
        {
            return Delete(hospId, mediaAuth, productKbn);
        }
    }
}
