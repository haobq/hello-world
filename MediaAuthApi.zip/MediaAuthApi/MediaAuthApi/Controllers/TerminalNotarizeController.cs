﻿using MediaAuthApi.Models;
using IO.Swagger.Models;
using MediaAuthApi.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Routing;
using System.Web;

namespace MediaAuthApi.Controllers
{
    public class TerminalNotarizeController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage Get()
        {
            //HTTPSによるリクエストかをチェックする。
            if (!HttpContext.Current.Request.Url.ToString().StartsWith("https"))
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden,
               new ApiResponse()
               {
                   ErrorCode = (int)WebApiConstants.ErrorCode.Forbidden,
                   Message = WebApiConstants.MsgForbidden
               });
            }

            return Request.CreateResponse(HttpStatusCode.MethodNotAllowed,
                new ApiResponse() {
                    ErrorCode = (int)HttpStatusCode.MethodNotAllowed,
                    Message = WebApiConstants.MsgMethodNotAllowed
                });
        }

        //端末を確認
        [HttpGet]
        [ActionName("deviceauth")]
        [Route("deviceauth/{groupId}/{deviceId}")]
        public HttpResponseMessage Get(string groupId, string deviceId, int productKbn)
        {
            //HTTPSによるリクエストかをチェックする。
            if (!HttpContext.Current.Request.Url.ToString().StartsWith("https"))
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden,
               new ApiResponse()
               {
                   ErrorCode = (int)WebApiConstants.ErrorCode.Forbidden,
                   Message = WebApiConstants.MsgForbidden
               });
            }

            //必須パラメータの有無をチェックする
            if (string.IsNullOrEmpty(groupId) || string.IsNullOrEmpty(deviceId))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                          new ApiResponse()
                          {
                              ErrorCode = (int)WebApiConstants.ErrorCode.NoParam,
                              Message = WebApiConstants.MsgParameterRequired
                          });
            }

            //各パラメータの形式等をチェックする
            if (!Tools.IsCheckStrLen(groupId, 20) ||
                !Tools.IsCheckStrLen(deviceId, 20) ||
                !Tools.IsCheckNum(productKbn))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                      new ApiResponse()
                      {
                          ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                          Message = WebApiConstants.MsgParameterFormatError
                      });
            }

            //グループIDが正しいかをチェックする
            if (!Tools.IsCorrect(groupId))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                        new ApiResponse()
                        {
                            ErrorCode = (int)WebApiConstants.ErrorCode.GroudIdError,
                            Message = WebApiConstants.MsgGroudIdError
                        });
            }

             //ユーザID、パスワードをチェックする。
            if (!Tools.GetFlag(groupId, deviceId, productKbn))
            {
                return Request.CreateResponse(HttpStatusCode.Unauthorized,
                    new ApiResponse()
                    {
                        ErrorCode = (int)WebApiConstants.ErrorCode.NotUseTerminalId,
                        Message = WebApiConstants.MsgNotUseTerminalId
                    });
            }

            return Request.CreateResponse(HttpStatusCode.OK,
                         new ApiResponse()
                         {
                             ErrorCode = (int)WebApiConstants.ErrorCode.ok,
                             Message = WebApiConstants.MsgOK
                         });

        }

    }
}
