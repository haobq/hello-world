﻿using IO.Swagger.Models;
using MediaAuthApi.Models;
using MediaAuthApi.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace MediaAuthApi.Controllers
{
    public class TerminalRegisteController : ApiController
    {
        [HttpPost]
        public HttpResponseMessage Post()
        {
            //HTTPSによるリクエストかをチェックする。
            if (!HttpContext.Current.Request.Url.ToString().StartsWith("https"))
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden,
               new ApiResponse()
               {
                   ErrorCode = (int)WebApiConstants.ErrorCode.Forbidden,
                   Message = WebApiConstants.MsgForbidden
               });
            }

            return Request.CreateResponse(HttpStatusCode.MethodNotAllowed,
                new ApiResponse()
                {
                    ErrorCode = (int)HttpStatusCode.MethodNotAllowed,
                    Message = WebApiConstants.MsgMethodNotAllowed
                });
        }

        //端末を登録
        [HttpPost]
        [ActionName("devices")]
        [Route("devices/{groupId}")]
        public HttpResponseMessage Post(string groupId, string userId, string pswd, int productKbn, string deviceName,
            string deviceRemarks = null, string deviceOS = null, string deviceBrowser = null, string devicePCName = null, string effectStartDate = null, string effectEndDate = null)
        {
            //HTTPSによるリクエストかをチェックする。
            if (!HttpContext.Current.Request.Url.ToString().StartsWith("https"))
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden,
               new ApiResponse()
               {
                   ErrorCode = (int)WebApiConstants.ErrorCode.Forbidden,
                   Message = WebApiConstants.MsgForbidden
               });
            }

            //必須パラメータの有無をチェックする
            if (!Tools.IsCheckParm(groupId) ||
                !Tools.IsCheckParm(userId) ||
                !Tools.IsCheckParm(pswd) ||
                !Tools.IsCheckParm(deviceName))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,
               new ApiResponse()
               {
                   ErrorCode = (int)WebApiConstants.ErrorCode.NoParam,
                   Message = WebApiConstants.MsgParameterRequired
               });

            }

            bool flag = true;

            //各パラメータの形式等をチェックする
            if (string.IsNullOrEmpty(effectStartDate))
            {
                effectStartDate = DateTime.Now.Date.ToString();
            }
            if (string.IsNullOrEmpty(effectEndDate))
            {
                effectEndDate = "9999-12-31";
            }

            //日付をチェックする
            if (!Tools.IsCheckDate(effectStartDate)||
                !Tools.IsCheckDate(effectEndDate))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                 new ApiResponse()
                 {
                     ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                     Message = WebApiConstants.MsgParameterFormatError
                 });

            }
            else {
                //日付の前後妥当性をチェック
                flag = Tools.IsCheckDate(effectStartDate, effectEndDate);
            }

            if (!flag ||
                !Tools.IsCheckStrLen(groupId, 20) ||
                !Tools.IsCheckStrLen(userId, 20) ||
                !Tools.IsCheckStrLen(pswd, 80) ||
                !Tools.IsCheckNum(productKbn)||
                !Tools.IsCheckStrLen(deviceName, 40))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                 new ApiResponse()
                 {
                     ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                     Message = WebApiConstants.MsgParameterFormatError
                 });

            }

            //備考をチェックする
            if (!string.IsNullOrEmpty(deviceRemarks))
            {
                if (!Tools.IsCheckStrLen(deviceRemarks, 100))
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest,
                 new ApiResponse()
                 {
                     ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                     Message = WebApiConstants.MsgParameterFormatError
                 });

                }
            }

            //登録端末OSをチェックする
            if (!string.IsNullOrEmpty(deviceOS))
            {
                if (!Tools.IsCheckStrLen(deviceOS, 20))
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest,
                 new ApiResponse()
                 {
                     ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                     Message = WebApiConstants.MsgParameterFormatError
                 });

                }
            }

            //備考をチェックする
            if (!string.IsNullOrEmpty(deviceBrowser))
            {
                if (!Tools.IsCheckStrLen(deviceBrowser, 20))
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest,
                 new ApiResponse()
                 {
                     ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                     Message = WebApiConstants.MsgParameterFormatError
                 });

                }
            }

            //登録端末PC名をチェックする
            if (!string.IsNullOrEmpty(devicePCName))
            {
                if (!Tools.IsCheckStrLen(devicePCName, 20))
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest,
                 new ApiResponse()
                 {
                     ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                     Message = WebApiConstants.MsgParameterFormatError
                 });

                }
            }


            //グループIDが正しいかをチェックする
            if (!Tools.IsCorrect(groupId))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                        new ApiResponse()
                        {
                            ErrorCode = (int)WebApiConstants.ErrorCode.GroudIdError,
                            Message = WebApiConstants.MsgGroudIdError
                        });
            }

            //ユーザID、パスワードをチェックする。
            if (!Tools.IsCorrect(groupId, userId, pswd))
            {
                return Request.CreateResponse(HttpStatusCode.Unauthorized,
                        new ApiResponse()
                        {
                            ErrorCode = (int)WebApiConstants.ErrorCode.WrongUserIdOrPassword,
                            Message = WebApiConstants.MsgWrongUserIdOrPassword
                        });
            }


            Terminal terminal = new Terminal()
            {
                IndexNo = null,
                TerminalId = new GetDeviceId().getTerminalId(),
                GroupId = groupId,
                UserId = userId,
                Pswd = pswd,
                ProductKbn = productKbn,
                TerminalName = deviceName,
                RegistDatetime = null,
                Remarks = deviceRemarks,
                OsName = deviceOS,
                BrowserName = deviceBrowser,
                PcName = devicePCName,
                ValidDateFrom = effectStartDate,
                ValidDateTo = effectEndDate,
                Mask = "0"
            };

            ApiTerminal apiTerminal = new ApiTerminal()
            {
                ErrorCode = (int)WebApiConstants.ErrorCode.ok,
                Message = WebApiConstants.MsgOK,
                Data = Tools.PostTerminal(terminal)
            };

            if (apiTerminal.Data.TerminalId == null)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError,
                        new ApiResponse()
                        {
                            ErrorCode = (int)WebApiConstants.ErrorCode.FailedRegister,
                            Message = WebApiConstants.MsgFailedRegister
                        });
            }

            return Request.CreateResponse(HttpStatusCode.OK, apiTerminal);
        }

    }
}
