﻿using IO.Swagger.Models;
using MediaAuthApi.Models;
using MediaAuthApi.Models.Common;
using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace MediaAuthApi.Controllers
{
    public class MediaAuthConfirmController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage Get()
        {
            return Request.CreateResponse(HttpStatusCode.MethodNotAllowed,
                new ApiResponse()
                {
                    ErrorCode = (int)HttpStatusCode.MethodNotAllowed,
                    Message = WebApiConstants.MsgMethodNotAllowed
                });
        }

        [ActionName("MediaAuthConfrim")]
        [Route("auths/{hospId}/{mediaAuth}")]
        public HttpResponseMessage Get(string hospId, string mediaAuth, int productKbn)
        {
            // 403 (Forbidden)
            if (!HttpContext.Current.Request.Url.ToString().StartsWith("https"))
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.Forbidden,
                    Message = WebApiConstants.MsgForbidden
                });
            }

            // 400 (Bad Request)
            if (string.IsNullOrEmpty(hospId) || string.IsNullOrEmpty(mediaAuth))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.NoParam,
                    Message = WebApiConstants.MsgParameterRequired
                });
            }
            if (!Tools.IsCheckStrLen(hospId, 10) || !Tools.IsCheckStrLen(mediaAuth, 100) || !Tools.IsCheckNum(productKbn))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.ParameterFormatError,
                    Message = WebApiConstants.MsgParameterFormatError
                });
            }

            //古い認証キー　削除をチェックする
            Tools.date_del_old();

            //認証キーをチェックする

            if (!Tools.KEY_CHK(mediaAuth, productKbn))
            {

                return Request.CreateResponse(HttpStatusCode.Unauthorized, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.Unauthorized,
                    Message = WebApiConstants.MsgUnauthorized
                });
            }
            else
            {
                //OKの場合は データを更新する
                Tools.KEY_CHK_UPDATE(mediaAuth, productKbn, hospId);
                return Request.CreateResponse(HttpStatusCode.OK, new ApiResponse()
                {
                    ErrorCode = (int)WebApiConstants.ErrorCode.ok,
                    Message = WebApiConstants.MsgOK
                });

            }


        }

       
    }

}
