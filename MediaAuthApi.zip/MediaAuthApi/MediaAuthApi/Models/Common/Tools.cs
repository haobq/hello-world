﻿using IO.Swagger.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Web;

namespace MediaAuthApi.Models.Common
{
    public class Tools
    {
        //パラメータの有無をチェック
        public static bool IsCheckParm(string parm)
        {
            if (string.IsNullOrEmpty(parm))
            {
                return false;
            }

            return true;
        }

        //文字数の範囲をチェック
        public static bool IsCheckStrLen(string str,int length)
        {
            if (str !=null && length>0　&& str.Length <= length)
            {
                return true;
            }

            return false;
        }

        //日付が正しいかをチェックする
        public static bool IsCheckDate(string date)
        {
            DateTime dateTime = new DateTime();

            if (!string.IsNullOrEmpty(date) &&

                DateTime.TryParse(date, out dateTime))
            {
                return true;
            }
            return false;
        }

        //日付の前後妥当性をチェック
        public static bool IsCheckDate(string str1, string str2)
        {
            DateTime date1, date2;

            if (DateTime.TryParse(str1, out date1) && DateTime.TryParse(str2, out date2))
            {
                TimeSpan span = date2.Subtract(date1);

                if (span.TotalDays >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        //ユーザID、パスワードをチェックする。
        public static bool IsCorrect(string GroupId, string UserId, string Pswd)
        {
            return SqlHelper.IsCorrect(GroupId, UserId, Pswd);
        }

        //グループIDが正しいかをチェックする。
        public static bool IsCorrect(string GroupId)
        {
            return SqlHelper.IsCorrect(GroupId);
        }

        //端末情報登録
        public static Terminal PostTerminal(Terminal terminal)
        {
            Terminal result = SqlHelper.PostTerminal(terminal);

            result.ValidDateFrom = getTimeStr(result.ValidDateFrom);

            result.ValidDateTo = getTimeStr(result.ValidDateTo);

            result.Remarks = getString(result.Remarks);

            result.OsName = getString(result.OsName);

            result.BrowserName = getString(result.BrowserName);

            result.PcName = getString(result.PcName);

            return result;
        }

        //時間形式を変更する
        public static string getTimeStr(string time)
        {
            string validDate = "";

            if (!string.IsNullOrEmpty(time))
            {
                 validDate = time.Replace("/", "-").Split(' ')[0];
            }

            return validDate;
        }

        public static string getString(string value)
        {
            return (value == null ? "" : value);
        }

        //端末情報確認
        public static bool GetFlag(string groupId, string terminal_id, int productKbn)
        {
            return SqlHelper.GetFlag(groupId, terminal_id, productKbn);

        }

        //数値をチェックする
        public static bool IsCheckNum(int num)
        {
            int[] nums = { 1, 2 };

            if (Array.IndexOf(nums, num) < 0)
            {
                return false;
            }
            return true;
        }

        //String To Datime
        public static DateTime ToDateTime(string str)
        {
            System.Globalization.DateTimeFormatInfo dtFormat = new System.Globalization.DateTimeFormatInfo();

            dtFormat.ShortDatePattern = "yyyy-MM-dd";

            return Convert.ToDateTime(str, dtFormat);
           
        }

      



        public static bool terminal_chk(string groupId, string deviceId)
        {
            return SqlHelper.terminal_chk(groupId, deviceId);
        }

        public static string Ishosp(string groupId, string userId)
        {
            return SqlHelper.Ishosp(groupId, userId);
        }

        public static int IsSession(string groupId, string userId,int productKbn,string deviceId,string sessionId)
        {
            return SqlHelper.IsSession(groupId, userId, productKbn, deviceId,sessionId);
        }
        public static bool licenseChk(string groupId,int productKbn)
        {
            return SqlHelper.licenseChk(groupId, productKbn);
        }
        //認証キーをチェックする
        public static bool KEY_CHK(string mediaAuth,int productKbn)
        {
            return SqlHelper.KEY_CHK(mediaAuth, productKbn);
        }
        //OKの場合は データを更新する
        public static bool KEY_CHK_UPDATE(string mediaAuth, int productKbn, string hospId)
        {
            return SqlHelper.KEY_CHK_UPDATE(mediaAuth, productKbn, hospId);
        }
        public static string date_insert(MediaAuthGet authGet)
        {
            return SqlHelper.date_insert(authGet);
        }
        //古い認証データを削除する
        public static bool date_del_old()
        {
            return SqlHelper.date_del_old();
        }
        //認証キーを削除する
        public static bool date_key_chk(string mediaAuth, string hospId, int productKbn)
        {
            return SqlHelper.date_key_chk(mediaAuth, hospId, productKbn);
        }

        public static bool date_key_del(string mediaAuth, string hospId, int productKbn)
        {
            return SqlHelper.date_key_del(mediaAuth, hospId, productKbn);
        }
        //認証キー取得
        public static string CreateTerminalId()
        {
            string tmpTerminalId = "";

            // システム時刻を渡してランダムな文字列を作成する
            string[] strSeed = { DateTime.Now.ToString("yyyyMMddHHmmssffff") };
            tmpTerminalId = getKey(20, strSeed);

            return tmpTerminalId;
        }
        /// <summary>
        /// ランダムな英数字を生成する。前回の値と別のものを作りたい場合は、第二引数に文字列を渡せば違うものを生成する。
        /// </summary>
        /// <param name="cnt">生成する文字数（255文字まで）</param>
        /// <param name="p">前回の値</param>
        /// <returns>ランダムな英数字</returns>
        public static string getKey(byte cnt, params string[] p)
        {
            string tmp = "", pre = "", pw = "";
            if (p.Length > 0) pre = p[0];
            do
            {
                do
                {
                    //128文字が上限なため
                    pw = System.Web.Security.Membership.GeneratePassword(128, 0);
                    //記号とアンダースコアの置換
                    pw = System.Text.RegularExpressions.Regex.Replace(pw, "\\W", "").Replace("_", "");
                    tmp += pw;
                } while (cnt >= tmp.Length);
                tmp = tmp.Substring(0, cnt);
            } while (tmp == pre);
            return tmp;
        }
    }
}