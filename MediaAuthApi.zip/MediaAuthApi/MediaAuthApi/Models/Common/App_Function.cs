using System;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Reflection;
using System.Net;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// 共通関数
/// </summary>
public partial  class App_Function : System.Web.UI.Page
{

    #region DB関連
    SqlConnection dbCon = new SqlConnection(ConfigurationManager.ConnectionStrings["DB_CONNECTION"].ConnectionString);
    SqlDataAdapter dbAda = new SqlDataAdapter();
    SqlCommand dbCom = new SqlCommand();
    Object thisLock = new Object();
    #endregion


    /// <summary>
    /// 文字列の左端から指定したバイト数までの文字列を返します。
    /// </summary>
    /// <param name="str">取り出す元になる文字列</param>
    /// <param name="cnt">取り出すバイト数</param>
    /// <returns>左端から指定されたバイト数までの文字列</returns>
    public string omitLeftB(string str, int cnt)
    {
        return (LenB(str) >= cnt) ? LeftB(str, cnt) : str;
    }

    /// <summary>半角 1 バイト、全角 2 バイトとして、指定された文字列のバイト数を返します。</summary>
    /// <param name="str">バイト数取得の対象となる文字列。</param>
    /// <returns>半角 1 バイト、全角 2 バイトでカウントされたバイト数。</returns>
    public int LenB(string str)
    {
        return System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(str);
    }

    /// <summary>文字列の左端から指定したバイト数分の文字列を返します。</summary>
    /// <param name="str">取り出す元になる文字列<param>
    /// <param name="cnt">取り出すバイト数</param>
    /// <returns>左端から指定されたバイト数分の文字列</returns>
    public string LeftB(string str, int cnt)
    {
        return MidB(str, 1, cnt);
    }

    /// <summary>文字列の指定されたバイト位置以降のすべての文字列を返します。</summary>
    /// <param name="str">取り出す元になる文字列。</param>
    /// <param name="iStart">取り出しを開始する位置。</param>
    /// <returns>指定されたバイト位置以降のすべての文字列。</returns>
    public string MidB(string str, int iStart)
    {
        System.Text.Encoding hEncoding = System.Text.Encoding.GetEncoding("Shift_JIS");
        byte[] btBytes = hEncoding.GetBytes(str);

        return hEncoding.GetString(btBytes, iStart - 1, btBytes.Length - iStart + 1);
    }

    /// <summary>文字列の指定されたバイト位置から、指定されたバイト数分の文字列を返します。</summary>
    /// <param name="str">取り出す元になる文字列。</param>
    /// <param name="iStart">取り出しを開始する位置。</param>
    /// <param name="cnt">取り出すバイト数。</param>
    /// <returns>指定されたバイト位置から指定されたバイト数分の文字列。</returns>
    public string MidB(string str, int iStart, int cnt)
    {
        System.Text.Encoding hEncoding = System.Text.Encoding.GetEncoding("Shift_JIS");
        byte[] btBytes = hEncoding.GetBytes(str);
        return hEncoding.GetString(btBytes, iStart - 1, cnt);
    }


    /// <summary>
    /// ランダムな英数字を生成する。前回の値と別のものを作りたい場合は、第二引数に文字列を渡せば違うものを生成する。
    /// </summary>
    /// <param name="cnt">生成する文字数（255文字まで）</param>
    /// <param name="p">前回の値</param>
    /// <returns>ランダムな英数字</returns>
    public string getKey(byte cnt, params string[] p)
    {
        string tmp = "", pre = "", pw = "";
        if (p.Length > 0) pre = p[0];
        do
        {
            do
            {
                //128文字が上限なため
                pw = System.Web.Security.Membership.GeneratePassword(128, 0);
                //記号とアンダースコアの置換
                pw = System.Text.RegularExpressions.Regex.Replace(pw, "\\W", "").Replace("_", "");
                tmp += pw;
            } while (cnt >= tmp.Length);
            tmp = tmp.Substring(0, cnt);
        } while (tmp == pre);
        return tmp;
    }

    /// <summary>
    /// SQLパラメーターを作成する
    /// </summary>
    /// <param name="parameterName"></param>
    /// <param name="dbType"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    public SqlParameter createSqlParameter(string parameterName, SqlDbType dbType, object value)
    {
        var rtn = new SqlParameter();
        rtn.ParameterName = parameterName;
        rtn.SqlDbType = dbType;
        rtn.Direction = ParameterDirection.Input;
        rtn.Value = value;
        return rtn;
    }

    /// <summary>
    /// SQLエスケープ
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public string sqlTabooChar(string str)
    {
        return str.Replace("'", "''");
    }

    /// <summary>
    /// SQLセレクトテーブル
    /// </summary>
    /// <param name="sentence"></param>
    /// <param name="dataTbl"></param>
    /// <returns></returns>
    public bool sqlSelectTable(string sentence, SqlParameter[] param, ref DataTable dataTbl)
    {
        var rtn = true;
        lock (thisLock)
        {
            try
            {
                dbCon.Open();
                dbCom.Connection = dbCon;
                dbAda.SelectCommand = dbCom;
                dbCom.CommandText = sentence;
                dbCom.Parameters.Clear();
                dbAda.SelectCommand.Parameters.AddRange(param);
                dbAda.Fill(dataTbl);
                dbCon.Close();
            }
            catch (SqlException ex)
            {
               /* dbCon.Close();
                logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
                logError(sentence);*/
                rtn = false;
            }
            finally
            {
                dbCon.Close();
            }
        }
        return rtn;
    }

    public bool logError(string description)
    {
        
        //logLong(4, "", "", description, "", "", "");
        return true;
    }

    #region ログ
    //public bool logLong(short hospId, short kind, string businessName, string displayName,
    //  string description, string patientId, string patientName, string exmDate)
    public bool logLong(short kind, string businessName, string displayName,
      string description, string patientId, string patientName, string exmDate)
    {
        try
        {
            DateTime dTime = new DateTime();
            string exmDateTmp = (DateTime.TryParse(exmDate, out dTime)) ? dTime.ToString("yyyy/MM/dd") : "1999/01/01";

            var sql = new StringBuilder();
            sql.AppendLine("insert tbl_operation_log values(");
            sql.AppendLine("@HOSP_ID,"); //HOSP_ID:varchar(10)
            sql.AppendLine("@KIND,"); //KIND:smallint
            sql.AppendLine("SYSDATETIME(),"); //DO_DATE:datetime
            sql.AppendLine("@BUSINESS_NAME,"); //BUSINESS_NAME:varchar(40)
            sql.AppendLine("@DISPLAY_NAME,"); //DISPLAY_NAME:varchar(40)
            sql.AppendLine("@DESCRIPTION,");//DESCRIPTION:varchar(1000)
            sql.AppendLine("@PATIENT_ID,"); //PATIENT_ID:varchar(10)
            sql.AppendLine("@PATIENT_NAME,"); //PATIENT_NAME:varchar(40)
            sql.AppendLine("CONVERT(datetime, @EXM_DATE),"); //EXM_DATE:date
            sql.AppendLine("@TERMINAL_ID,"); //TERMINAL_ID:varchar(20)
            sql.AppendLine("@LOGIN_ID,"); //LOGIN_ID:varchar(20)
            sql.AppendLine("@TEAM_ID,"); //TEAM_ID:varchar(10)
            sql.AppendLine("@GROUP_ID"); //GROUP_ID:varchar(20)
            sql.AppendLine(")");
            /*
                      var param = new SqlParameter[] {
                  createSqlParameter("@HOSP_ID", SqlDbType.VarChar, omitLeftB(sqlTabooChar(mySession.hosp_id), 10)), //HOSP_ID:varchar(10)
                  createSqlParameter("@KIND", SqlDbType.SmallInt, kind), //KIND:smallint
                  createSqlParameter("@BUSINESS_NAME", SqlDbType.VarChar, omitLeftB(sqlTabooChar(businessName), 40)), //BUSINESS_NAME:varchar(40)
                  createSqlParameter("@DISPLAY_NAME", SqlDbType.VarChar, omitLeftB(sqlTabooChar(displayName), 40)), //DISPLAY_NAME:varchar(40)
                  createSqlParameter("@DESCRIPTION", SqlDbType.VarChar, omitLeftB(sqlTabooChar(description), 1000)),//DESCRIPTION:varchar(1000)
                  createSqlParameter("@PATIENT_ID", SqlDbType.VarChar, omitLeftB(sqlTabooChar(patientId), 10)), //PATIENT_ID:varchar(10)
                  createSqlParameter("@PATIENT_NAME", SqlDbType.VarChar, omitLeftB(sqlTabooChar(patientName), 40)), //PATIENT_NAME:varchar(40)
                  createSqlParameter("@EXM_DATE", SqlDbType.VarChar, exmDateTmp), //EXM_DATE:date
                  createSqlParameter("@TERMINAL_ID", SqlDbType.VarChar, omitLeftB(sqlTabooChar(mySession.terminal_id), 20)), //TERMINAL_ID:varchar(20)
                  createSqlParameter("@LOGIN_ID", SqlDbType.VarChar, omitLeftB(sqlTabooChar(mySession.login_id), 20)), //LOGIN_ID:varchar(20)
                  createSqlParameter("@TEAM_ID", SqlDbType.VarChar, omitLeftB(sqlTabooChar(mySession.team_id), 10)), //TEAM_ID:varchar(10)
                  createSqlParameter("@GROUP_ID", SqlDbType.VarChar, omitLeftB(sqlTabooChar(mySession.group_id), 20)), //GROUP_ID:varchar(20)
                };

                      var p = new string[] { sql.ToString() };
                      var lstparam = new SqlParameter[][] { param }.ToList();
                      sqlTran(p, lstparam);  */
        }

        catch (Exception ex)
                {
                    jsl(ex.ToString());
                    return false;
                }
               
            return true;
    }

    #endregion

    /// <summary>
    /// SQLトランザクション
    /// </summary>
    /// <param name="p">SQL文</param>
    /// <returns></returns>
    public bool sqlTran(string[] p, List<SqlParameter[]> lstparam)
    {
        var rtn = true;
        lock (thisLock)
        {
            try
            {
                DataTable dataTable = new DataTable();
                dbCon.Open();
                dbCom.Connection = dbCon;
                dbAda.SelectCommand = dbCom;
                dbAda.InsertCommand = dbCom;
                dbAda.UpdateCommand = dbCom;
                dbAda.DeleteCommand = dbCom;

                SqlTransaction dbTra = null;
                dbTra = dbCon.BeginTransaction();
                dbCom.Transaction = dbTra;

                for (var i = 0; i < p.Length; i++)
                {
                    try
                    {
                        dbCom.CommandText = p[i];
                        dbCom.Parameters.Clear();
                        if (lstparam[i] != null) { dbCom.Parameters.AddRange(lstparam[i]); }
                        dbCom.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        dbTra.Rollback();
                        dbCon.Close();
                        /*logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
                        logError(p[i]);*/
                        throw ex;
                    }
                }
                dbTra.Commit();
            }
            catch (SqlException ex)
            {
               /* logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);*/
                rtn = false;
            }
            finally
            {
                dbCon.Close();
            }
        }
        return rtn;
    }

    /// <summary>
    /// JavaScriptのconsole.logを出す。
    /// </summary>
    /// <param name="p">複数出せる</param>
    public void jsl(params string[] p)
    {
        string str = "", tmp = "";
        for (int i = 0; i <= p.Length - 1; i++)
        {
            if (p[i] == null)
                p[i] = "null";
            if (i > 0)
                str += ",";
            tmp = p[i].Replace("\\", "\\\\").Replace("'", "\\'");
            tmp = tmp.Replace("\n", "\\n");
            tmp = tmp.Replace("\r", "\\r");
            tmp = tmp.Replace("\r\n", "\\r\\n");
            str += "'" + tmp + "'";
        }
        js("console.log(" + str + ");");
    }

    /// <summary>
    /// JavaScript実行
    /// </summary>
    /// <param name="p">実行させたいJavaScript</param>
    public void js(string p)
    {
        if (p.Substring(p.Length - 1, 1) != ";") p += ";";
        Page cp = (Page)HttpContext.Current.CurrentHandler;
        ScriptManager.RegisterStartupScript(cp, Page.GetType(), getKey(16), p, true);
    }

}
