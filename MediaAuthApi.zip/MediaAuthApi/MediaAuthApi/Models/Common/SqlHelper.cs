﻿using IO.Swagger.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web;

namespace MediaAuthApi.Models.Common
{
    public class SqlHelper
    {
        private static readonly string connstr = ConfigurationManager.ConnectionStrings["DB_CONNECTION"].ConnectionString;

        //全ての端末を取得文字列のクラス
        internal static List<String> GetAllTerminals( string  terminal_id = null)
        {
            string sql = "";

            SqlParameter parameter = null;

            if (string.IsNullOrEmpty(terminal_id))
            {
                //クエリのSQL文を定義する
                sql = "select  * from mst_terminal";
            }
            else
            {
                sql = "select  * from mst_terminal where terminal_id = @terminal_id";

                //SQLインジェクションを防止する
                parameter = new SqlParameter("@terminal_id", SqlDbType.NVarChar);
                parameter.Value = terminal_id;
            }
          

            List<string> terminals = new List<string>();

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (parameter != null)
                    {
                        cmd.Parameters.Add(parameter);
                    }

                    SqlDataReader reader =  cmd.ExecuteReader();

                    List<string> list = new List<string>();

                    int num = reader.FieldCount;

                    for (int index = 0; index < num; index++)
                    {
                        list.Add(reader.GetName(index));
                    }

                    while (reader.Read()) {

                        string str = "";

                        foreach (var li in list) {

                            str += "\"" + li + "\":" + "\"" +reader[li] +"\",";

                        }

                        terminals.Add("{" + (str.TrimEnd(new char[] {','})) + "}");
                    }
                }
            }

            return terminals;
        }

        //端末を取得
        internal static List<Terminal> GetTerminals(string terminal_id = null)
        {
            string sql = "";

            SqlParameter parameter = null;

            if (string.IsNullOrEmpty(terminal_id))
            {
                //クエリのSQL文を定義する
                sql = "select  * from mst_terminal";
            }
            else
            {
                sql = "select  * from mst_terminal where terminal_id = @terminal_id";

                //SQLインジェクションを防止する
                parameter = new SqlParameter("@terminal_id", SqlDbType.NVarChar);
                parameter.Value = terminal_id;
            }


            List<Terminal> terminals = new List<Terminal>();

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (parameter != null)
                    {
                        cmd.Parameters.Add(parameter);
                    }

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Terminal terminal = new Terminal();

                        terminal.GroupId = reader["group_id"].ToString();
                        terminal.ProductKbn = Convert.ToInt32(reader["product_kbn"].ToString());
                        terminal.TerminalId = reader["terminal_id"].ToString();
                        terminal.TerminalName = reader["terminal_name"].ToString();
                        terminal.Remarks = reader["remarks"].ToString();
                        terminal.UserId = reader["user_id"].ToString();
                        terminal.RegistDatetime = Convert.ToDateTime(reader["regist_datetime"].ToString());
                        terminal.OsName = reader["os_name"].ToString();
                        terminal.BrowserName = reader["browser_name"].ToString();
                        terminal.PcName = reader["pc_name"].ToString();
                        terminal.ValidDateFrom = reader["valid_date_from"].ToString();
                        terminal.ValidDateTo = reader["valid_date_to"].ToString();

                        terminals.Add(terminal);
                    }
                }
            }

            return terminals;
        }

        //端末のIdについて端末を取得
        internal static Terminal GetTerminal(string terminal_id)
        {
            return GetTerminals(terminal_id)[0];
        }

        //端末を確認
        internal static bool GetFlag(string groupId, string terminal_id, int productKbn)
        {
            string sql = "select  * from mst_terminal where " +
                        "group_id = @groupId and " +
                        "terminal_id = @terminal_id and " +
                        "product_kbn = @productKbn and  " +
                        "mask = 0 and " +
                        "DATEDIFF(day, valid_date_from, CONVERT(varchar(30), getdate(), 21)) >= 0 and "+
                        "DATEDIFF(day, CONVERT(varchar(30), getdate(), 21),valid_date_to ) >= 0";

            SqlParameter parameter1 = new SqlParameter("@groupId", SqlDbType.NVarChar);
            parameter1.Value = groupId;

            SqlParameter parameter2 = new SqlParameter("@terminal_id", SqlDbType.NVarChar);
            parameter2.Value = terminal_id;

            SqlParameter parameter3 = new SqlParameter("@productKbn", SqlDbType.Int);
            parameter3.Value = productKbn;

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    if (cmd.ExecuteScalar() != null)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        //ユーザID、パスワード、グループIDが正しいかをチェックする。
        internal static bool IsCorrect(string groupId,string userId , string pswd)
        {
            string sql = "";

            SqlParameter[] parameters = null;

            if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(pswd))
            {
                //クエリのSQL文を定義する
                sql = "select  index_no from mst_user where group_id = @groupId and user_id = @userId and user_pw = @pswd and mask= 0";

                //SQLインジェクションを防止する
                SqlParameter parameter1 = new SqlParameter("@groupId", SqlDbType.NVarChar);
                parameter1.Value = groupId == null ? "" : groupId;

                SqlParameter parameter2 = new SqlParameter("@userId", SqlDbType.NVarChar);
                parameter2.Value = userId == null ? "" : userId;

                SqlParameter parameter3 = new SqlParameter("@pswd", SqlDbType.NVarChar);
                parameter3.Value = pswd == null ? "" : pswd;

                parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };
            }
            else
            {
                //クエリのSQL文を定義する
                sql = "select index_no from mst_group where group_id = @groupId and mask= 0";

                //SQLインジェクションを防止する
                SqlParameter parameter = new SqlParameter("@groupId", SqlDbType.NVarChar);
                parameter.Value = groupId == null ? "" : groupId;

                parameters = new SqlParameter[] { parameter };
            }
            try
            {
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    conn.Open();
                    //var a = 0;
                    //var c = 1 /a;
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);

                        try
                        {
                            if (cmd.ExecuteScalar() != null)
                            {
                                return true;
                            }
                        }
                        catch (Exception ex)
                        {
                            ex.Message.ToString();
                        }
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
                log.Info(DateTime.Now.ToString() , e);
                log.Debug(DateTime.Now.ToString(), e);
                log.Error(DateTime.Now.ToString(), e);
                log.Warn(DateTime.Now.ToString(), e);
                log.Fatal(DateTime.Now.ToString(), e);

                string ec =  e.Message.ToString();
                return false;
            }

        }

        internal static bool IsCorrect(string groupId)
        {
            bool flag = IsCorrect(groupId, null, null);

            return flag;
        }

        //端末情報を登録する。					
        internal static Terminal PostTerminal(Terminal terminal)
        {
            //throw new NotImplementedException();
            string sql = "";
            SqlParameter[] parameters = null;

            sql = "INSERT INTO mst_terminal" +
                "(index_no, group_id,terminal_id,user_id,regist_datetime,os_name,browser_name," +
                "pc_name,remarks,valid_date_from,valid_date_to,mask,terminal_name,product_kbn) " +
                "VALUES(@index_no,@group_id,@terminal_id,@user_id,@regist_datetime,@os_name," +
                "@browser_name,@pc_name,@remarks,@valid_date_from,@valid_date_to,@mask,@terminal_name," +
                "@product_kbn)";
            try
            {
                //index_no
                SqlParameter parameter1 = new SqlParameter("@index_no", SqlDbType.NVarChar);
                parameter1.Value = terminal.IndexNo == null ? (object)DBNull.Value : terminal.IndexNo;
                //group_id
                SqlParameter parameter2 = new SqlParameter("@group_id", SqlDbType.NVarChar);
                parameter2.Value = terminal.GroupId;
                //terminal_id
                SqlParameter parameter3 = new SqlParameter("@terminal_id", SqlDbType.NVarChar);
                parameter3.Value = terminal.TerminalId;
                //user_id
                SqlParameter parameter4 = new SqlParameter("@user_id", SqlDbType.NVarChar);
                parameter4.Value = terminal.UserId;
                //regist_datetime
                SqlParameter parameter5 = new SqlParameter("@regist_datetime", SqlDbType.DateTime);
                parameter5.Value = terminal.RegistDatetime == null ? GetSbuTime() : terminal.RegistDatetime;
                //os_name
                SqlParameter parameter6 = new SqlParameter("@os_name", SqlDbType.NVarChar);
                parameter6.Value = terminal.OsName == null ? (object)DBNull.Value : terminal.OsName;
                //browser_name
                SqlParameter parameter7 = new SqlParameter("@browser_name", SqlDbType.NVarChar);
                parameter7.Value = terminal.BrowserName == null ? (object)DBNull.Value : terminal.BrowserName;
                //pc_name
                SqlParameter parameter8 = new SqlParameter("@pc_name", SqlDbType.NVarChar);
                parameter8.Value = terminal.PcName == null ? (object)DBNull.Value : terminal.PcName;
                //remarks
                SqlParameter parameter9 = new SqlParameter("@remarks", SqlDbType.NVarChar);
                parameter9.Value = terminal.Remarks == null ? (object)DBNull.Value : terminal.Remarks;
                //valid_date_from
                SqlParameter parameter10 = new SqlParameter("@valid_date_from", SqlDbType.Date);
                parameter10.Value = terminal.ValidDateFrom;
                //valid_date_to
                SqlParameter parameter11 = new SqlParameter("@valid_date_to", SqlDbType.Date);
                parameter11.Value = terminal.ValidDateTo;
                //mask
                SqlParameter parameter12 = new SqlParameter("@mask", SqlDbType.NVarChar);
                parameter12.Value = terminal.Mask;
                //terminal_name
                SqlParameter parameter13 = new SqlParameter("@terminal_name", SqlDbType.NVarChar);
                parameter13.Value = terminal.TerminalName;
                //product_kbn
                SqlParameter parameter14 = new SqlParameter("@product_kbn", SqlDbType.SmallInt);
                parameter14.Value = terminal.ProductKbn;

                parameters = new SqlParameter[]{
                    parameter1, parameter2, parameter3, parameter4, parameter5, parameter6, parameter7,
                    parameter8,parameter9,parameter10,parameter11,parameter12,parameter13,parameter14};

                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(sql,conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                  
                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                return GetTerminal(terminal.TerminalId);
                            }
                    }
                }
           }
           catch (Exception e)
           {
                string ec = e.Message.ToString();
           }

            return new Terminal();
        }

        //サーバ日付を取得する
        public static DateTime? GetSbuTime()
        {
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                DateTime date ;

                using (SqlCommand cmd = new SqlCommand("SELECT  GETDATE();", conn))
                {
                    try
                    {
                        if (cmd.ExecuteScalar() != null)
                        {
                            date  = (DateTime)cmd.ExecuteScalar();
                          
                            return date.ToLocalTime();
                           
                        }
                    }
                    catch(Exception ex)
                    {
                        ex.Message.ToString();
                    }
                    return null;

                }
            }

        }

        internal static bool terminal_chk(string groupId, string deviceId)
        {
            string sql = "";

            //クエリのSQL文を定義する
            sql =  "SELECT top 1 * ";
            sql += "  FROM mst_terminal ";
            sql +=  " WHERE group_id = @group_id";
            sql +=  " AND terminal_id = @terminal_id";
            sql +=  " AND valid_date_from <= GETUTCDATE()";
            sql +=  "  AND GETUTCDATE() <= valid_date_to";
            sql +=  " AND MASK = 0";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar);
            parameter1.Value = groupId;

            SqlParameter parameter2 = new SqlParameter("@terminal_id", SqlDbType.NVarChar);
            parameter2.Value = deviceId;

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    if (cmd.ExecuteScalar() != null)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        //hospID をチェックする
        internal static string Ishosp(string groupId, string userId)
        {
            string sql = "";
            string value = "";

            //クエリのSQL文を定義する
            sql +="SELECT hosp_id ";
            sql +="  FROM mst_user_hosp ";
            sql +=" WHERE group_id = @group_id";
            sql +=" AND user_id = @user_id";
            sql +=" AND effect_date_from <= GETUTCDATE()";
            sql +="   AND GETUTCDATE() <= effect_date_to";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar);
            parameter1.Value = groupId;

            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar);
            parameter2.Value = userId;

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    SqlDataReader reader = cmd.ExecuteReader();

                    List<string> list = new List<string>();
                    for (int index = 0; index < 1; index++)
                    {
                        list.Add(reader.GetName(index));
                    }

                    while (reader.Read())
                    {

                        string str = "";

                        foreach (var li in list)
                        {

                            str += li + ":" + reader[li] ;

                        }
                        if (str != "")
                        {
                            string[] Array = str.Split(':');
                            if (Array[1] != null)
                            {
                                value = Array[1].ToString();
                                return value ;
                            }
                            
                        }

                    }

                }
            }
            return "";
        }
        //認証データ取得をチェックする
        internal static int IsSession(string groupId, string userId,int flg, string deviceId, string sessionId)
        {
            string sql = "";
            int num = 0;

            //クエリのSQL文を定義する
            sql = "select terminal_id,session_id from tbl_session WHERE user_id =@userId AND group_id =@groupId AND product_kbn = @product_kbn";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@groupId", SqlDbType.NVarChar);
            parameter1.Value = groupId;

            SqlParameter parameter2 = new SqlParameter("@userId", SqlDbType.NVarChar);
            parameter2.Value = userId;

            SqlParameter parameter3 = new SqlParameter("@product_kbn", SqlDbType.Int);
            parameter3.Value = flg;


            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 ,parameter3};
            List<string> terminals = new List<string>();
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    SqlDataReader reader = cmd.ExecuteReader();

                    List<string> list = new List<string>();

                    num = reader.FieldCount;
                    for (int index = 0; index < num; index++)
                    {
                        list.Add(reader.GetName(index));
                    }

                    while (reader.Read())
                    {

                        string str = "";

                        foreach (var li in list)
                        {

                            str += li + ":" + reader[li] + ":";

                        }
                        if (str != "")
                        {
                            string[] Array = str.Split(':');
                            if(Array[1] == deviceId && Array[3] == sessionId)
                            {
                                return 1;
                            }else if(Array[1] == deviceId && Array[3] != sessionId)
                            {
                                return 2;
                            }else if(Array[1] != deviceId)
                            {
                                return 3;
                            }
                        }
                        
                    }
                    
                }
            }
            return 0;
        }

        internal static bool licenseChk(string groupId,int productKbn)
        {
            string sql = "";
            string sql_session = "";
            int num = 0, num2 =0;
            DataTable dataTable = new DataTable();

            //クエリのSQL文を定義する
            sql = "select license_number from mst_group WHERE group_id = @group_id";
            sql_session = "select * from tbl_session WHERE group_id = @group_id AND product_kbn=@product_kbn";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar);
            parameter1.Value = groupId;

            SqlParameter parameter2 = new SqlParameter("@group_id", SqlDbType.NVarChar);
            parameter2.Value = groupId;

            SqlParameter parameter3 = new SqlParameter("@product_kbn", SqlDbType.NVarChar);
            parameter3.Value = productKbn;

            SqlParameter[] parameters = new SqlParameter[] { parameter1 };
            SqlParameter[] parameters2 = new SqlParameter[] { parameter2, parameter3 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                List<string> terminals = new List<string>();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    SqlDataReader reader = cmd.ExecuteReader();

                    List<string> list = new List<string>();

                    num = reader.FieldCount;
                    for (int index = 0; index < num; index++)
                    {
                        list.Add(reader.GetName(index));
                    }

                    while (reader.Read())
                    {

                        string str = "";

                        foreach (var li in list)
                        {

                            str += li + ":" + reader[li] ;

                        }
                        if( str != "")
                        {
                            string[] Array = str.Split(':');

                            num = int.Parse(Array[1]);
                        }
                        else
                        {
                            num = 0;
                        }


                    }
                    reader.Close();


                }
                using (SqlCommand cmd2 = new SqlCommand(sql_session, conn))
                {

                    cmd2.Parameters.AddRange(parameters2);

                    SqlDataReader reader = cmd2.ExecuteReader();

                    while (reader.Read())
                    {
                        num2 += 1;
                    }

                }
                if(num > num2)
                {
                    return true;
                }
            }
            return false;
        }
        //認証キーをチェックする
        internal static bool KEY_CHK(string mediaAuth, int productKbn)
        {
            string sql = "";

            //クエリのSQL文を定義する
            sql = "select * from tbl_session WHERE media_auth = @mediaAuth AND product_kbn =@productKbn ";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@mediaAuth", SqlDbType.NVarChar);
            parameter1.Value = mediaAuth;

            SqlParameter parameter2 = new SqlParameter("@productKbn", SqlDbType.Int);
            parameter2.Value = productKbn;



            SqlParameter[] parameters = new SqlParameter[] { parameter1,parameter2 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    if (cmd.ExecuteScalar() != null)
                    {
                        
                        return true;

                    }
                }
            }
            return false;
        }
        //OKの場合は データを更新する
        internal static bool KEY_CHK_UPDATE(string mediaAuth, int productKbn,string hospId)
        {
            string sql = "";

            //クエリのSQL文を定義する
            if (string.IsNullOrEmpty(hospId))
            {
                sql = "UPDATE TBL_SESSION SET REGIST_DATETIME = GETUTCDATE() , HOSP_ID = @HOSP_ID WHERE media_auth = @mediaAuth AND product_kbn =@productKbn ";



                //SQLインジェクションを防止する
                SqlParameter parameter1 = new SqlParameter("@mediaAuth", SqlDbType.NVarChar);
                parameter1.Value = mediaAuth;

                SqlParameter parameter2 = new SqlParameter("@productKbn", SqlDbType.Int);
                parameter2.Value = productKbn;

                SqlParameter parameter3 = new SqlParameter("@HOSP_ID", SqlDbType.NVarChar);
                parameter3.Value = hospId;



                SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };

                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {

                        cmd.Parameters.AddRange(parameters);

                        if (cmd.ExecuteScalar() != null)
                        {

                            return true;

                        }
                    }
                }
            }
            return false;
        }
        //認証キーを削除する
        internal static bool date_key_chk(string mediaAuth, string hospId, int productKbn)
        {
            string sql = "";

            //クエリのSQL文を定義する
            sql = "select * from tbl_session WHERE media_auth = @mediaAuth AND session_flg =@productKbn  AND hosp_id = @hospId";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@mediaAuth", SqlDbType.NVarChar);
            parameter1.Value = mediaAuth;

            SqlParameter parameter2 = new SqlParameter("@productKbn", SqlDbType.Int);
            parameter2.Value = productKbn;

            SqlParameter parameter3 = new SqlParameter("@hospId", SqlDbType.NVarChar);
            parameter3.Value = hospId;



            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2,parameter3 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    if (cmd.ExecuteScalar() != null)
                    {
                        
                        return true;

                    }
                }
            }
            return false;
        }

        internal static bool date_key_del(string mediaAuth, string hospId, int productKbn)
        {
            string sql = "";

            //クエリのSQL文を定義する
            sql = " delete from tbl_session WHERE media_auth = @mediaAuth AND product_kbn = @productKbn  AND hosp_id = @hospId";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@mediaAuth", SqlDbType.NVarChar);
            parameter1.Value = mediaAuth;

            SqlParameter parameter2 = new SqlParameter("@productKbn", SqlDbType.Int);
            parameter2.Value = productKbn;

            SqlParameter parameter3 = new SqlParameter("@hospId", SqlDbType.NVarChar);
            parameter3.Value = hospId;



            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    

                    try
                    {
                        if (cmd.ExecuteNonQuery() == 0)
                        {

                            return true;

                        }
                    }
                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                        return false;
                    }
                }
            }
            return false;
        }
        //古い認証データを削除する
        internal static bool date_del_old()
        {
            string sql = "";

            //クエリのSQL文を定義する
            sql = "DELETE FROM tbl_session WHERE REGIST_DATETIME < DATEADD( minute,-70,GETUTCDATE()) ";

            //SQLインジェクションを防止する

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    try
                    {
                        if (cmd.ExecuteNonQuery() == 0)
                        {
                            return true;
                        }
                    }
                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }
            return false;
        }

        //認証データ登録

        internal static string date_insert(MediaAuthGet authget)
        {
            //throw new NotImplementedException();
            string sql = "";
            SqlParameter[] parameters;
            SqlParameter[] parameters_chk;
            int num;
            string Json;
            string sql_chk = "";

            sql  = "INSERT INTO TBL_SESSION";
            sql += "(USER_ID,USER_NAME,GROUP_ID,TERMINAL_ID,REGIST_DATETIME,SESSION_ID,SESSION_FLG,MEDIA_AUTH,PRODUCT_KBN)";
            sql += "VALUES";
            sql += "(@USER_ID,(SELECT USER_NAME FROM MST_USER WHERE USER_ID =@USER_ID),@GROUP_ID,@TERMINAL_ID,GETUTCDATE(),@SESSION_ID,2,@MEDIA_AUTH,@PRODUCT_KBN)";

            sql_chk = "select * from TBL_SESSION WHERE USER_ID =@USER_ID_CHK AND GROUP_ID=@GROUP_ID_CHK";

            SqlParameter parameter1 = new SqlParameter("@USER_ID", SqlDbType.NVarChar);
            parameter1.Value = authget.UserId;
            SqlParameter parameter2 = new SqlParameter("@GROUP_ID", SqlDbType.NVarChar);
            parameter2.Value = authget.GroupId;
            SqlParameter parameter3 = new SqlParameter("@TERMINAL_ID", SqlDbType.NVarChar);
            parameter3.Value = authget.DeviceId;
            SqlParameter parameter4 = new SqlParameter("@SESSION_ID", SqlDbType.NVarChar);
            parameter4.Value = authget.SessionId;
            SqlParameter parameter5 = new SqlParameter("@PRODUCT_KBN", SqlDbType.Int);
            parameter5.Value = authget.ProductKbn;
            SqlParameter parameter6 = new SqlParameter("@USER_ID_CHK", SqlDbType.NVarChar);
            parameter6.Value = authget.UserId;
            SqlParameter parameter7 = new SqlParameter("@GROUP_ID_CHK", SqlDbType.NVarChar);
            parameter7.Value = authget.GroupId;
            SqlParameter parameter8 = new SqlParameter("@MEDIA_AUTH", SqlDbType.NVarChar);
            parameter8.Value = authget.MediaAuth;



            parameters = new SqlParameter[] { parameter1, parameter2, parameter3, parameter4, parameter5,parameter8};
            parameters_chk = new SqlParameter[] { parameter6, parameter7};


            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd_chk = new SqlCommand(sql_chk, conn))
                {
                    cmd_chk.Parameters.AddRange(parameters_chk);
                    if (cmd_chk.ExecuteScalar() == null)
                    {
                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddRange(parameters);

                            num =cmd.ExecuteNonQuery();
                            if (num > 0)
                            {
                                Json = GetMedia_data(authget.GroupId);
                                return Json;
                            }
                        }
                        return null;

                    }
                }
                
            }

            return null;
        }

        internal static String GetMedia_data(string groupID)
        {
            return GetAllMedia_data(groupID)[0];
        }

        public static List<String> GetAllMedia_data(string groupID = null)
        {
            string sql;

            SqlParameter[] parameters = null;

            sql = "select mst_user_hosp.hosp_id,tbl_session.media_auth";
            sql += " from mst_user_hosp";
            sql += " left join tbl_session";
            sql += " ON mst_user_hosp.group_id = tbl_session.group_id";
            sql += " where";
            sql += " tbl_session.group_id = @group_id";

            //SQLインジェクションを防止する
            SqlParameter parameter = new SqlParameter("@group_id", SqlDbType.NVarChar);
            parameter.Value = groupID;

            parameters = new SqlParameter[] { parameter};

            List<string> terminals = new List<string>();

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddRange(parameters);

                    SqlDataReader reader = cmd.ExecuteReader();

                    List<string> list = new List<string>();

                    int num = reader.FieldCount;

                    for (int index = 0; index < num; index++)
                    {
                        list.Add(reader.GetName(index));
                    }

                    while (reader.Read())
                    {

                        string str = "";

                        foreach (var li in list)
                        {

                            str += "\"" + li + "\":" + "\"" + reader[li] + "\",";

                        }

                        terminals.Add("{" + (str.TrimEnd(new char[] { ',' })) + "}");
                    }
                }
            }

            return terminals;
        }

        

    }
}