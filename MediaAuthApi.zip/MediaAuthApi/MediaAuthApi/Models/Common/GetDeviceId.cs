using System;
using System.Data;
using System.Reflection;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.IO;

public partial class GetDeviceId : App_Function
{
    /// <summary>
    /// 新規登録用TerminalId生成
    /// </summary>
    /// <returns>TerminalId</returns>
    private string CreateTerminalId()
    {
        string tmpTerminalId = "";
        DataTable dtMstTerminal = new DataTable();
        do
        {
            // システム時刻を渡してランダムな文字列を作成する
            string[] strSeed = { DateTime.Now.ToString("yyyyMMddHHmmssffff") };
            //jsl("=DEBUG=");
            //jsl(strSeed);
            tmpTerminalId = getKey(20, strSeed);
            string sqlString = "";
            sqlString += "SELECT * FROM mst_terminal ";
            //sqlString += string.Format(@" WHERE terminal_id = '{0}' ", tmpTerminalId);
            sqlString += " WHERE terminal_id = @TERMID ";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = createSqlParameter("@TERMID", SqlDbType.VarChar, sqlTabooChar(tmpTerminalId));
            //if (!sqlSelectTable(sqlString, ref dtMstTerminal))
            if (!sqlSelectTable(sqlString, param, ref dtMstTerminal))
            {
            }
        }
        while (dtMstTerminal.Rows.Count != 0);
        return tmpTerminalId;
    }

    public  string getTerminalId()
    {
        return CreateTerminalId();
    }


}