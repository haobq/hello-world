﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Collections;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MediaAuthApi.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public partial class MediaAuthDel :IEquatable<MediaAuthDel>
    {
        /// <summary>
        /// Gets or Sets errCode
        /// </summary>
        [DataMember(Name = "errCode", EmitDefaultValue = false)]
        public int? ErrCode { get; set; }

        /// <summary>
        /// Gets or Sets message
        /// </summary>
        [DataMember(Name = "message", EmitDefaultValue = false)]
        public string Message { get; set; }

        /// <summary>
        /// Gets or Sets data
        /// </summary>
        [DataMember(Name = "data", EmitDefaultValue = false)]
        public string Data { get; set; }

        /// <summary>
        /// Gets or Sets mediaAuth
        /// </summary>
        [DataMember(Name = "mediaAuth", EmitDefaultValue = false)]
        public string MediaAuth { get; set; }

        /// <summary>
        /// Gets or Sets hospId
        /// </summary>
        [DataMember(Name = "hospId", EmitDefaultValue = false)]
        public string HospId { get; set; }

        /// <summary>
        /// Gets or Sets productKbn
        /// </summary>
        [DataMember(Name = "productKbn", EmitDefaultValue = false)]
        public int ProductKbn { get; set; }


        /// <summary>
        /// Get the string presentation of the object
        /// </summary>
        /// <returns>String presentation of the object</returns>
        public override string ToString()
        {
            var cmd = new StringBuilder();
            cmd.Append("class MediaAuthDel {\n");
            cmd.Append("  errCode: ").Append(ErrCode).Append("\n");
            cmd.Append("  message: ").Append(Message).Append("\n");
            cmd.Append("  data: ").Append(Data).Append("\n");
            cmd.Append("  mediaAuth: ").Append(MediaAuth).Append("\n");
            cmd.Append("  hospId: ").Append(HospId).Append("\n");
            cmd.Append("  productKbn: ").Append(ProductKbn).Append("\n");
            cmd.Append("}\n");
            return cmd.ToString();
        }

        /// <summary>
        /// Get the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public string ToJson()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            return obj.GetType() == GetType() && Equals((MediaAuthDel)obj);
        }

        /// <summary>
        /// Returns true if Mediaauth instances are equal
        /// </summary>
        /// <param name="other">Instance of Mediaauth to be compared</param>
        /// <returns>Boolean</returns>
        public bool Equals(MediaAuthDel other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;

            return
                (
                    ErrCode == other.ErrCode ||
                    ErrCode != null &&
                    ErrCode.Equals(other.ErrCode)
                ) &&
                (
                    Message == other.Message ||
                    Message != null &&
                    Message.Equals(other.Message)
                ) &&
                (
                    Data == other.Data ||
                    Data != null &&
                    Data.Equals(other.Data)
                );
        }

        public override int GetHashCode()
        {
            unchecked // Overflow is fine, just wrap
            {
                var hashCode = 41;
                // Suitable nullity checks etc, of course :)
                if (ErrCode != null)
                    hashCode = hashCode * 59 + ErrCode.GetHashCode();
                if (Message != null)
                    hashCode = hashCode * 59 + Message.GetHashCode();
                if (Data != null)
                    hashCode = hashCode * 59 + Data.GetHashCode();
                return hashCode;
            }
        }

        #region Operators
        #pragma warning disable 1591

        public static bool operator ==(MediaAuthDel left, MediaAuthDel right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(MediaAuthDel left, MediaAuthDel right)
        {
            return !Equals(left, right);
        }
        #pragma warning restore 1591
        #endregion Operators


    }

}