﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MediaAuthApi.Models
{
    public class WebApiConstants
    {
        /// <summary>
        /// エラーコード
        /// </summary>
        public enum ErrorCode
        {
            ok = 0,
            NoParam,
            ParameterRequired = 1,
            ParameterFormatError = 2,
            HospIdError = 3,
            GroudIdError = 4,
            InvalidHospId = 5,
            ExistedAuthentication = 6,
            MultipleTerminal = 7,
            AnotherTermina = 8,
            ExceedMaxAccess = 9,
            Other = 999,
            Unauthorized = 401,
            WrongUserIdOrPassword = 402,
            NotUseTerminalId = 403,
            Forbidden = 404,
            MethodNotAllowed = 405,
            NotRequest,
            FailedRegister = 501,
            FailedDelete = 502,
            InternalServerError,
            ServiceUnavailable
        }

        #region メッセージ
        // メッセージ
        public const string MsgOK = "ok";
        public const string MsgParameterRequired = "必須のパラメータがありません";
        public const string MsgParameterFormatError = "パラメータの形式・データ形式が不正";
        public const string MsgHospIdError = "医院IDが不正";
        public const string MsgGroudIdError = "グループIDが不正です。";
        public const string MsgInvalidHospId = "有効な医院IDがありません。";
        public const string MsgExistedAuthentication = "有効な認証データが既にあります。";
        public const string MsgMultipleTerminal = "同じ端末で複数の利用はできません。";
        public const string MsgAnotherTermina = "別の端末で同時に利用はできません。";
        public const string ExceedMaxAccess = "最大同時アクセス数を超えています。";
        public const string MsgUnauthorized = "認証キーが不正";
        public const string MsgWrongUserIdOrPassword = "ユーザID／パスワードが不正です。";
        public const string MsgNotUseTerminalId = "この端末IDは利用できません。";
        public const string MsgForbidden = "利用が禁止されている";
        public const string MsgMethodNotAllowed = "不正なURIが渡された";
        public const string MsgOther = "その他";
        public const string MsgFailedRegister = "データ登録に失敗しました";
        public const string MsgFailedDelete = "データ削除に失敗しました";
        public const string MsgRequestTimeout = "サーバからのレスポンスが返ってこない";
        public const string MsgInternalServerError = "サーバ側で何らかのエラーが発生した";
        public const string MsgServiceUnavailable = "サーバが稼働していない";
        #endregion

        // ConnectionStringsNames
        public const string ConStrHIS = "DB_CONNECTION_HIS";
        public const string ConStrWY = "DB_CONNECTION_WY";

    }
}