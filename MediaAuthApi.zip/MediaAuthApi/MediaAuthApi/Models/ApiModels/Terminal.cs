﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace IO.Swagger.Models
{
   [DataContract]
    public class Terminal
    {
       // [DataMember(Name = "index_no")]
        public string IndexNo { set; get; }

        //[DataMember(Name = "group_id")]
        [DataMember]
         [StringLength(20)]
        [JsonProperty(PropertyName = "groupId")]
        public string GroupId { set; get; }

        [DataMember]
        //[DataMember(Name = "product_kbn")]
        [JsonProperty(PropertyName = "productKbn")]
        public int ProductKbn { set; get; }

        [DataMember]
        // [DataMember(Name = "terminal_id")]
        [StringLength(20)]
        [JsonProperty(PropertyName = "deviceId")]
        public string TerminalId { set; get; }

        [DataMember]
        //[DataMember(Name = "terminal_name")]
        [StringLength(40)]
        [JsonProperty(PropertyName = "deviceName")]
        public string TerminalName { set; get; }

        [DataMember]
        //[DataMember(Name = "remarks")]
        [StringLength(100)]
        [JsonProperty(PropertyName = "deviceRemarks")]
        public string Remarks { set; get; }

        [DataMember]
        //[DataMember(Name = "user_id")]
        [StringLength(20)]
        [JsonProperty(PropertyName = "userId")]
        public string UserId { set; get; }

        [StringLength(20)]
        //[JsonProperty(PropertyName = "Pswd")]
        public string Pswd { set; get; }

       
        [DataMember]
        //[DataMember(Name = "regist_datetime")]
        [JsonProperty(PropertyName = "registDatetime")]
        public DateTime? RegistDatetime {get;set;}

        [DataMember]
        //[DataMember(Name = "os_name")]
        [StringLength(20)]
        [JsonProperty(PropertyName = "deviceOS")]
        public string OsName { set; get; }

        [DataMember]
        //[DataMember(Name = "browser_name")]
        [StringLength(20)]
        [JsonProperty(PropertyName = "deviceBrowser")]
        public string BrowserName { set; get; }

        [DataMember]
        //[DataMember(Name = "pc_name")]
        [StringLength(20)]
        [JsonProperty(PropertyName = "devicePCName")]
        public string PcName { set; get; }

        
        [DataMember]
        //[DataMember(Name = "valid_date_from")]
        [JsonProperty(PropertyName = "effectStartDate")]
        public String ValidDateFrom {set;get;}

        [DataMember]
        //[DataMember(Name = "valid_date_to")]
        [JsonProperty(PropertyName = "effectEndDate")]
        public String ValidDateTo {set;get;}

        //[DataMember(Name = "mask")]
        [StringLength(1)]
        public string Mask { set; get; }

       



        /// <summary>
        /// Get the string presentation of the object
        /// </summary>
        /// <returns>String presentation of the object</returns>
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append("class Terminal {\n");
            sb.Append("  TerminalId: ").Append(TerminalId).Append("\n");
            sb.Append("  UserId: ").Append(UserId).Append("\n");
            sb.Append("  RegistDatetime: ").Append(RegistDatetime).Append("\n");
            sb.Append("  OsName: ").Append(OsName).Append("\n");
            sb.Append("  BrowserName: ").Append(BrowserName).Append("\n");
            sb.Append("  PcName: ").Append(PcName).Append("\n");
            sb.Append("  Remarks: ").Append(Remarks).Append("\n");
            sb.Append("  ValidDateFrom: ").Append(ValidDateFrom).Append("\n");
            sb.Append("  ValidDateTo: ").Append(ValidDateTo).Append("\n");
            sb.Append("  Mask: ").Append(Mask).Append("\n");
            sb.Append("  TerminalName: ").Append(TerminalName).Append("\n");
            sb.Append("  ProductKbn: ").Append(ProductKbn).Append("\n");
            sb.Append("}\n");
            return sb.ToString();
        }

        /// <summary>
        /// Get the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public string ToJson()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }

    }

}