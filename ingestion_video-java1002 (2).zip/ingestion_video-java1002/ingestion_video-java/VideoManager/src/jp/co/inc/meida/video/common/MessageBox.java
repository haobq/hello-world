/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.meida.video.common;

import java.awt.Component;

import javax.swing.JOptionPane;

public class MessageBox extends Thread implements MessageConst {

	private static boolean _bSubOutFlg = false;

	/*
	 * Controlのフラグを設定
	 */
	public static void setSubOutFlg(boolean bFlg) {
		_bSubOutFlg = bFlg;
	}

	/*
	 * ControlのフラグをGET
	 */
	public static boolean getSubOutFlg() {
		return _bSubOutFlg;
	}

	/*
	 * showConfirmDialog 設定
	 */
	public static int showConfirmDlg(Component iframe, String strMessage, String strTitle) {
		return showConfirmDlg(iframe, strMessage, strTitle, false);
	}

	public static int showConfirmDlg(Component iframe, String strMessage, String strTitle, boolean bDefa) {

		int btnFlg = 0;
		if (bDefa) {
			String[] strInfo = { "はい", "いいえ" };
			btnFlg = JOptionPane.showOptionDialog(iframe,
					strMessage, strTitle,
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,
					null, strInfo, strInfo[1]);
		} else {
			btnFlg = JOptionPane.showConfirmDialog(iframe, // parentComponent
					strMessage, // message
					strTitle, // title
					JOptionPane.YES_NO_OPTION, // optionType
					JOptionPane.QUESTION_MESSAGE, // messageType
					null); // icon
		}
		return btnFlg;
	}
}
