/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author 李
 * @version 1.0 2020/09/01
 */
package jp.co.inc.meida.video.common;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Callback;
import jp.co.inc.meida.video.utils.FileInfoBean;

public class BasFrame extends Application implements MediaPlay, BasConst {

	private static final Window mStage = null;

	// SplitPane
	private SplitPane splitRoot;
	private SplitPane splitPane;
	private SplitPane splitRootLeft;
	private SplitPane splitRootRight;
	private SplitPane splitMediaSub;
	private SplitPane splitMedia;

	// フォルダ選択ボタン
	private Button BtnSelectFold;
	// 動画リスト

	private Pane paneFileList;

	// テクストボックス　検索
	private TextField txtFind;
	// 検索ボタン
	private Button btnSearch;

	// 患者リスト
	private Pane vbPatientList;

	// ファイルリストテーブル
	private TableView<FileInfoBean> table;

	// サブぺネル
	private Pane bp1 = new Pane();
	private Pane bp2 = new Pane();
	private Pane bp3 = new Pane();
	private Pane bp4 = new Pane();
	private Pane bp5 = new Pane();
	private HBox bottomNode = new HBox();
	// メインぺネル
	private Pane bp = new Pane();

	private HBox hboxMain;

	private HBox hvBoxMainPane;

	private HBox hvMediaBottom;

	private MediaPlayer mainPlay;
	// カレンダー
	private DatePicker checkInDatePicker;

	// 動画送信 ボタン
	private Button btnSend;

	// キャンセル ボタン
	private Button btnCancel;

	// 削除 ボタン
	private Button btnDelete;

	// 状況
	private Label lblStats;

	// プログレスバー
	private ProgressBar progressBar;

	// 備考
	private TextField txtABikou;

	// 動画ファイルリスト
	private ObservableList<FileInfoBean> fileInfolist = FXCollections.observableArrayList();

	// 選択した動画ファイルリスト
	private ObservableList<FileInfoBean> selectedFileInfolist;

	private ObservableMap<String, String> mediaMap = FXCollections.observableHashMap();

	private double posSplitPane[] = { 0.2f, 0.8f };
	private double posRootRight[] = { 0.2f, 0.8f };
	private double posRootLeft[]  = { 0.01f, 0.5f, 0.502f };
	private double posSubMedia[]  = { 0.2f, 0.4f, 0.6f, 0.8f };
	private double postRoot[]     = { 0.95f };
	private double posMainMedia[] = { 0.95f };


	/**
	 * 画面スタート
	 * @param primaryStage
	 */
	@Override
	public void start(Stage primaryStage) {
		// 初期化
		initUI(primaryStage);
	}

	/**
	 * メイン
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);

	}

	/**
	 * Appends text to the end of the specified TextArea without moving the scrollbar.
	 * @param ta TextArea to be used for operation.
	 * @param text Text to append.
	 */
	public static void appendTextToTextArea(TextArea ta, String text) {
		double scrollTop = ta.getScrollTop();
		ta.setText(ta.getText() + text);
		ta.setScrollTop(scrollTop);
	}

	/**
	 * 画面コントロール設定
	 * @param primaryStage
	 * @param boot
	 */
	public void initUI(final Stage primaryStage) {
		try {

			System.out.println("START -initUI");

			// 初期化
			init(primaryStage);

			// 常に最前面に表示の
			//			 primaryStage.setAlwaysOnTop(true);

			//イベント設定

			// 最大化状態を監視
			primaryStage.maximizedProperty().addListener(new ChangeListener<Boolean>() {
				@Override
				public void changed(ObservableValue<? extends Boolean> ov, Boolean t, Boolean t1) {

					splitRoot.setDividerPositions(postRoot);
					splitPane.setDividerPositions(posSplitPane);
					splitRootLeft.setDividerPositions(posRootLeft);
					splitRootRight.setDividerPositions(posRootRight);
					splitMediaSub.setDividerPositions(posSubMedia);
					splitMedia.setDividerPositions(posMainMedia);
					
					mediaReSet();
					
					if (primaryStage.isMaximized()) {

					} else {

					}

				}
			});

			// ファイルリスト初期化
			initScreen(fileInfolist);

			System.out.println("END -initUI");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 画面コントロール初期化
	 * @param primaryStage
	 * @param boot
	 */
	public void init(Stage primaryStage) {
		// ベース
		final BorderPane root = new BorderPane();
		root.setStyle("-fx-border-style: solid; -fx-border-width: 0 0 0 0;");

		// メニュー作成
		MenuBarFx menuBar = new MenuBarFx(this);
		// Top追加
		root.setTop(menuBar);

		// bottom HBox
		final HBox hvMediaBottom1 = new HBox();

		// 状況
		lblStats = new Label(STATUSBAR_TITLE_STATAS);
		lblStats.setPrefWidth(700);
		hvMediaBottom1.getChildren().add(lblStats);

		// プログレスバー
		progressBar = new ProgressBar();
		progressBar.setPrefHeight(25);
		hvMediaBottom1.getChildren().add(progressBar);

		final Label lbLeft = new Label();
		lbLeft.setPrefWidth(5);
		// Left追加
		root.setLeft(lbLeft);
		final Label lbRight = new Label();
		lbRight.setPrefWidth(5);
		// Right追加
		root.setRight(lbRight);

		// フォームSplitPane
		splitPane = new SplitPane();
		// Center追加
		root.setCenter(splitPane);

		// フォルダ選択
		final HBox btnFoldSelect = new HBox();
		BtnSelectFold = new Button(BUTTON_FOLD_SELECT);
		BtnSelectFold.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		BtnSelectFold.setAlignment(Pos.TOP_LEFT);
		btnFoldSelect.getChildren().add(BtnSelectFold);
		btnFoldSelect.setAlignment(Pos.TOP_LEFT);

		// ファイル一覧
		paneFileList = new HBox();
		paneFileList.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");

		// 検索
		final HBox hvBoxSearch = new HBox();
		// 検索テクストボックス
		txtFind = new TextField();
		txtFind.setPromptText(TXT_FIND);
		txtFind.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		txtFind.prefWidthProperty().bind(hvBoxSearch.widthProperty());
		// 検索ボタン
		btnSearch = new Button(BUTTON_FIND);
		btnSearch.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		hvBoxSearch.getChildren().addAll(txtFind, btnSearch);

		// 患者一覧
		vbPatientList = new Pane();
		// 			 vbPatientList.setMinHeight(FILE_LIST_HEIGHT);
		// 			 vbPatientList.setMaxHeight(FILE_LIST_HEIGHT);

		vbPatientList.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");

		// 左垂直SplitPane
		splitRootLeft = new SplitPane();
		splitRootLeft.setOrientation(Orientation.VERTICAL);
		splitRootLeft.getItems().addAll(btnFoldSelect, paneFileList, hvBoxSearch, vbPatientList);
		splitRootLeft.setDividerPositions(posRootLeft);
		for (int i = 0; i < splitRootLeft.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = splitRootLeft.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootLeft[ind]);
				}
			});
		}

		bp1 = new BorderPane();
		bp2 = new BorderPane();
		bp3 = new BorderPane();
		bp4 = new BorderPane();
		bp5 = new BorderPane();

		bp.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp1.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp2.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp3.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp4.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp5.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");

		// MediaSub垂直SplitPane
		splitMediaSub = new SplitPane();
		splitMediaSub.setOrientation(Orientation.HORIZONTAL);
		splitMediaSub.getItems().addAll(bp1, bp2, bp3, bp4, bp5);

		splitMediaSub.setDividerPositions(posSubMedia);

		for (int i = 0; i < splitMediaSub.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = splitMediaSub.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posSubMedia[ind]);
				}
			});
		}

		// メインぺネル
		hvBoxMainPane = new HBox();
		hvBoxMainPane.getChildren().add(bp);

		hvBoxMainPane.setAlignment(Pos.CENTER);

		// mediaSplitPane
		splitMedia = new SplitPane();
		splitMedia.setOrientation(Orientation.VERTICAL);
		hboxMain = new HBox();
		splitMedia.getItems().addAll(bp, hboxMain);
		splitMedia.setDividerPositions(posMainMedia);
		for (int i = 0; i < splitMedia.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = splitMedia.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posMainMedia[ind]);
				}
			});
		}
		hvMediaBottom = new HBox();
		final VBox vblank1 = new VBox();
		vblank1.setPrefWidth(20);
		final VBox vblank2 = new VBox();
		vblank2.setPrefWidth(20);
		final VBox vblank3 = new VBox();
		vblank3.setPrefWidth(20);
		final VBox vblank4 = new VBox();
		vblank4.setPrefWidth(20);
		final VBox v1 = new VBox();
		final VBox v2 = new VBox();
		final VBox v3 = new VBox();
		final VBox v4 = new VBox();

		final Label labBikou = new Label(TEXTARIA_BIKOU);
		labBikou.setAlignment(Pos.BOTTOM_LEFT);
		labBikou.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");

		labBikou.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		txtABikou = new TextField("");
		txtABikou.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);

		final TextArea textArea = new TextArea();
		textArea.setPrefWidth(300);

		textArea.setMaxHeight(30);
		textArea.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		textArea.setWrapText(true);
		textArea.setMinHeight(40);

		// カレンダーコントロール
		checkInDatePicker = new DatePicker();
		checkInDatePicker.setMinWidth(30);
		checkInDatePicker.setMaxWidth(140);
		checkInDatePicker.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);

		checkInDatePicker.setPromptText(DATE_TYPE_YYYY_MM_DD.toLowerCase());

		checkInDatePicker.setValue(LocalDate.now());

		final GridPane gridPane = new GridPane();
		gridPane.setHgap(10);
		gridPane.setVgap(10);
		gridPane.add(checkInDatePicker, 0, 0);

		v1.getChildren().add(gridPane);

		hvMediaBottom.getChildren().add(v1);
		hvMediaBottom.getChildren().add(vblank1);
		hvMediaBottom.getChildren().add(labBikou);
		hvMediaBottom.getChildren().add(textArea);
		hvMediaBottom.getChildren().add(vblank4);
		hvMediaBottom.getChildren().add(v2);
		hvMediaBottom.getChildren().add(vblank2);
		hvMediaBottom.getChildren().add(v3);
		hvMediaBottom.getChildren().add(vblank3);
		hvMediaBottom.getChildren().add(v4);

		/* ---------------------------- */
		/* 送信、キャンセル、削除ボタン */
		/* ---------------------------- */
		 
		// 動画送信 ボタン
		btnSend = new Button("送    信");
		btnSend.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		v2.getChildren().add(btnSend);

		// キャンセル ボタン
		btnCancel = new Button("キャンセル");
		btnCancel.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		v3.getChildren().add(btnCancel);

		// 削除 ボタン
		btnDelete = new Button("削    除");
		btnDelete.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		v4.getChildren().add(btnDelete);

		// 配置⇒中央設定
		hvMediaBottom.setAlignment(Pos.CENTER);

		// 左垂直SplitPane
		splitRootRight = new SplitPane();
		splitRootRight.setOrientation(Orientation.VERTICAL);
		splitRootRight.getItems().addAll(splitMediaSub, splitMedia, hvMediaBottom);

		splitRootRight.setDividerPositions(posRootRight);

		for (int i = 0; i < splitRootRight.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = splitRootRight.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootRight[ind]);
				}
			});
		}

		// ベース
		final BorderPane rootRight = new BorderPane();
		rootRight.setStyle("-fx-border-style: solid; -fx-border-width: 0 0 0 0;");

		// Center追加
		rootRight.setCenter(splitRootRight);

		// 左、右フレームを親子フレームに追加
		splitPane.getItems().addAll(splitRootLeft, rootRight);
		splitPane.setDividerPositions(posSplitPane);

		// Bottom追加
		// rootSplitPane
		splitRoot = new SplitPane();
		splitRoot.setOrientation(Orientation.VERTICAL);
		splitRoot.getItems().addAll(root, hvMediaBottom1);
		splitRoot.setDividerPositions(postRoot);
		for (int i = 0; i < splitRoot.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = splitRoot.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(postRoot[ind]);
				}
			});
		}

		/* ---------------------------- */
		/*      ウィンドウサイズ設定    */
		/* ---------------------------- */

		// ウィンドウサイズ設定
		Scene scene = new Scene(splitRoot, WINDOWS_WHITH, WINDOWS_HEIGHT);
		primaryStage.setMaximized(false);

		root.prefWidthProperty().bind(scene.widthProperty());
		root.prefHeightProperty().bind(scene.heightProperty());

		splitRoot.prefWidthProperty().bind(scene.widthProperty());
		splitRoot.prefHeightProperty().bind(scene.heightProperty());

		//ウィンドウタイトル
		primaryStage.setTitle(SYSTEM_NAME);

		//ウィンドウサイズ変更の無効化
		primaryStage.setResizable(true);

		//アイコンの設定
		Image img = new Image(getClass().getResourceAsStream("../img/media.jpg"));
		primaryStage.getIcons().add(img);

		//フルスクリーンモードのオン、オフ
		//フルスクリーンオンの時はescキーで解除できます
		primaryStage.setFullScreen(false);
		primaryStage.setScene(scene);
		primaryStage.show();

		// マウスイベント登録
		Set<Node> dividers = splitPane.lookupAll(".split-pane-divider");
		for (Node divider : dividers) {
			if (divider.getParent() == splitPane) {
				// Listen to the position property
				divider.setOnMousePressed(setOnMousePressed -> {
					mediaSetClear();

				});
				// Listen to the position property
				divider.setOnMouseReleased(evMouseReleased -> {
					mediaReSet();
				});
			}
		}

		// フォルダ選択ボタンイベント登録
		BtnSelectFold.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickBtnSelectFold(e);
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		});

	}

	/**
	 * フォルダ選択処理
	 * @param event
	 * @throws IOException
	 */
	void onClickBtnSelectFold(ActionEvent event) throws IOException {

		try {

			FileChooser fileChooser = new FileChooser();

			fileChooser.setTitle("ファイル選択");
			// 拡張子フィルタを設定
			fileChooser.getExtensionFilters().add(
					new FileChooser.ExtensionFilter("イメージファイル", "*.mp4"));
			fileChooser.getExtensionFilters().add(
					new FileChooser.ExtensionFilter("すべてのファイル", "*.mp4"));
			// 初期ディレクトリをホームにする。
			fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));

			// ファイル選択
			List<File> list = fileChooser.showOpenMultipleDialog(mStage);

			boolean isExist = true;
			ObservableMap<String, String> mediatmpMap = FXCollections.observableHashMap();

			//最終更新日時表示書式
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

			int ifile = 0;
			if (list != null) {

				for (FileInfoBean fb : fileInfolist) {

					mediatmpMap.putIfAbsent(fb.fileName, "");
				}

				for (File file : list) {
					// openFile(file);

					// 事前チェック
					if (!mediatmpMap.containsKey(file.getName())) {
						mediatmpMap.putIfAbsent(file.getName(), "");
					} else {
						infoMessageBox("[" + file.getName() + "]" + "は重複です。", "エラー", "メセージ");
						isExist = false;
						mediatmpMap = null;
						break;
					}

					ifile++;

				}

				if (isExist) {

					ifile = 0;
					for (File file : list) {

						mediaMap.putIfAbsent(file.getName(), "");

						FileInfoBean f = new FileInfoBean();
						f.setFileName(file.getName());
						f.setFilePath(file.getPath());
						f.setChecked(true);
						f.setFileSended(false);

						//対象ファイルの最終更新日時取得（1970年1月1日からの経過時間）
						Long lastModified = file.lastModified();
						// 最終更新日時書式整形
						f.setUpdateDate(sdf.format(lastModified));

						// 動画ファイルサイズ(byte)
						f.setFileSize(file.length());

						fileInfolist.add(f);

						if (ifile == 0) {
							f.setStatus(STATUS_NEW);

						} else if (ifile == 1) {
							f.setStatus(STATUS_WORKING);

						} else if (ifile == 2) {
							f.setStatus(sSTATUS_COMPLETED);
						} else if (ifile == 3) {

							f.setStatus(STATUS_NEW);

						} else if (ifile == 4) {
							f.setStatus(STATUS_NEW);

						} else if (ifile == 5) {
							f.setStatus(STATUS_WORKING);

						} else if (ifile == 6) {
							f.setStatus(sSTATUS_COMPLETED);

						} else if (ifile == 7) {
							f.setStatus(STATUS_NEW);

						}

						ifile++;

					}

					// ファイルリスト初期化
					initScreen(fileInfolist);

					// ファイル一覧拙宅
					table.requestFocus();
					table.getSelectionModel().selectFirst();
					table.getFocusModel().focus(0);
				}

			}

		} catch (IllegalArgumentException e) {
			//			logger.log(Level.INFO, "例外のスローを捕捉", e);
		} catch (SecurityException e) {
			e.printStackTrace();
		}

	}

	/**
	 * メッセージボックス
	 * @param infoMessage
	 * @param headerText
	 * @param title
	 * @return boolean
	 */
	public static boolean infoMessageBox(String infoMessage, String headerText, String title) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setContentText(infoMessage);
		alert.setTitle(title);
		alert.setHeaderText(headerText);
		alert.getButtonTypes();

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK) {
			// ... user chose OK button
			return true;
		} else {
			// ... user chose CANCEL or closed the dialog
			return false;
		}

	}

	/**
	 * 画面レイアウト初期化
	 * @param fileList
	 */
	private void initScreen(ObservableList<FileInfoBean> fileList) {
		System.out.println("START -initScreen");

		//初期化
		paneFileList.getChildren().clear();

		table = new TableView<>();
		final ObservableList<TableColumn<FileInfoBean, ?>> columns = table.getColumns();

		final TableColumn<FileInfoBean, CheckBox> fileCheckBoxColumn = new TableColumn<FileInfoBean, CheckBox>(
				FILE_TITLE_CHECKED);
		fileCheckBoxColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<FileInfoBean, CheckBox>, ObservableValue<CheckBox>>() {

					@Override
					public ObservableValue<CheckBox> call(TableColumn.CellDataFeatures<FileInfoBean, CheckBox> arg0) {
						final FileInfoBean data = arg0.getValue();
						final CheckBox checkBox = new CheckBox();
						checkBox.selectedProperty().setValue(data.isChecked());

						if (data.isFileSended()) {
							// 無効に設定
							checkBox.setDisable(true);
						}

						checkBox.selectedProperty().addListener(new ChangeListener<Boolean>() {
							public void changed(ObservableValue<? extends Boolean> ov, Boolean old_val,
									Boolean new_val) {
								data.setChecked(new_val);
								checkBox.setSelected(new_val);
							}
						});

						return new SimpleObjectProperty<CheckBox>(checkBox);
					}

				});

		fileCheckBoxColumn.setMaxWidth(30);

		final TableColumn<FileInfoBean, Label> fileStatusColumn = new TableColumn<FileInfoBean, Label>(
				FILE_TITLE_STATAS);
		fileStatusColumn.setMaxWidth(35);

		final TableColumn<FileInfoBean, String> fileNameColumn = new TableColumn<>(FILE_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory<>("fileName"));

		final TableColumn<FileInfoBean, String> lastedUpdateColumn = new TableColumn<>(FILE_TITLE_LASTED_UPDATE);
		lastedUpdateColumn.setCellValueFactory(new PropertyValueFactory<>("updateDate"));

		final TableColumn<FileInfoBean, String> fileSizeColumn = new TableColumn<>(FILE_TITLE_SIZE);
		fileSizeColumn.setCellValueFactory(new PropertyValueFactory<>("fileSize"));

		/** ファイルリストクリックイベント処理 */
		setCellValueFactory(fileStatusColumn);

		// カラム追加
		columns.add(fileCheckBoxColumn);
		columns.add(fileStatusColumn);
		columns.add(fileNameColumn);
		columns.add(lastedUpdateColumn);
		columns.add(fileSizeColumn);
		table.setItems(fileList);
		// sort
		table.sort();

		table.setMinWidth(300);
		paneFileList.getChildren().add(table);
		paneFileList.prefHeightProperty().bind(table.heightProperty());
		table.prefWidthProperty().bind(paneFileList.widthProperty());

		if (fileList.size() > 0) {
			//選択状態を検知するバインディングの設定
			table_addListener(fileList);

		}

		System.out.println("END -initScreen");
	}

	/**
	 * テーブルリスナー
	 * @param fileList
	 */
	void table_addListener(final ObservableList<FileInfoBean> fileList) {

		System.out.println("START -table_addListener");

		table.getSelectionModel().selectedItemProperty().addListener((ov, old, current) -> {

			System.out.println("選択したファイル:" + current.filePath);

			if (fileList != null) {
				table_selected(fileList, current);
			}
		});

		System.out.println("END -table_addListener");

	}

	/**
	 * テーブルリスナー
	 * @param fileList
	 * @param current
	 */
	void table_selected(ObservableList<FileInfoBean> fileList, FileInfoBean current) {

		System.out.println("START -table_selected");

		if (fileList != null) {
			// 初期化
			selectedFileInfolist = FXCollections.observableArrayList();
			for (int count = 0; count < fileList.size(); count++) {
				FileInfoBean fileInfo = new FileInfoBean();
				fileInfo = fileList.get(count);

				if (fileInfo.fileName.equals(current.fileName)) {

					if (fileList.size() - count >= 5) {
						System.out.println("選択セル 5");
						System.out.println("count:" + count);

						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));

						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;

					} else if (fileList.size() - count == 4) {
						System.out.println("選択セル 4");

						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;

					} else if (fileList.size() - count == 3) {
						System.out.println("選択セル 3");

						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;

					} else if (fileList.size() - count == 2) {
						System.out.println("選択セル 2");

						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;

					} else if (fileList.size() - count == 1) {
						System.out.println("選択セル 1");

						selectedFileInfolist.add(fileList.get(count++));
						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;
					}

				}

			}

		}

		System.out.println("END -table_selected");

	}

	/**
	 * セールファクトリー
	 * @param fileStatusColumn
	 */
	void setCellValueFactory(TableColumn<FileInfoBean, Label> fileStatusColumn) {
		fileStatusColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<FileInfoBean, Label>, ObservableValue<Label>>() {

					@Override
					public ObservableValue<Label> call(TableColumn.CellDataFeatures<FileInfoBean, Label> arg0) {
						FileInfoBean data = arg0.getValue();
						final Label label = new Label();
						label.setTextFill(Color.RED);

						label.setBackground(new Background(
								new BackgroundFill(Color.BLUEVIOLET, new CornerRadii(10), new Insets(5))));

						label.setPrefSize(10, 10);

						if (data.getStatus().equals(STATUS_NEW)) {

							final Image imageDecline = new Image(getClass().getResourceAsStream("../img/unreg.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(STATUS_WORKING)) {

							final Image imageDecline = new Image(getClass().getResourceAsStream("../img/loading.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(sSTATUS_COMPLETED)) {

							final Image imageDecline = new Image(getClass().getResourceAsStream("../img/finish.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);
						}

						return new SimpleObjectProperty<Label>(label);
					}

				});
	}

	/**
	 * コントロールサブパネルを画面に設定
	 * @param pa パネル
	 * @param mediafile メディアファイル
	 */
	void MediaSet(Pane pa, File mediafile) {
		System.out.println("START -MediaSet");

		try {

			// 動画再生クラスをインスタンス化
			Media Video = new Media(mediafile.toURI().toString());
			MediaPlayer Play = new MediaPlayer(Video);
			MediaView mediaView = new MediaView(Play);
			
			mediaView.setFitWidth(pa.getWidth());
			mediaView.setFitHeight(pa.getHeight());
			mediaView.fitHeightProperty().bind(pa.heightProperty());
			mediaView.fitWidthProperty().bind(pa.widthProperty());

			pa.getChildren().add(mediaView);

		} catch (IllegalArgumentException e) {
			//			logger.log(Level.INFO, "例外のスローを捕捉", e);
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		System.out.println("END -MediaSet");

	}

	
	/**
	 * メディア メインパネル設定
	 * @param pa パネル
	 * @param mediafile メディアファイル
	 */
	void MediaMainRefresh(Pane pa, File mediafile) {
		System.out.println("START -MediaMainRefresh");

		try {

			// 動画再生クラスをインスタンス化
			Media Video = new Media(mediafile.toURI().toString());
			MediaPlayer Play = new MediaPlayer(Video);
			MediaView mediaView = new MediaView(Play);
			
			mediaView.setFitWidth(pa.getWidth());
			mediaView.setFitHeight(pa.getHeight());
			mediaView.fitHeightProperty().bind(pa.heightProperty());
			mediaView.fitWidthProperty().bind(pa.widthProperty());

			pa.getChildren().add(mediaView);

			// 保存
			mainPlay = Play;
			// 画面下に表示する情報バーを作成
			bottomNode = new HBox(10.0);
			bottomNode.getChildren().add(MediaPlay.createButton(mainPlay));        // 再生・停止・繰り返しボタン作成
			bottomNode.getChildren().add(MediaPlay.createTimeSlider(mainPlay));    // 時間表示スライダ作成
			bottomNode.getChildren().add(MediaPlay.createVolumeSlider(mainPlay));  // ボリューム表示スライダ作成

			hboxMain.getChildren().clear();
			hboxMain.getChildren().add(bottomNode);
			splitMedia.setDividerPositions(posMainMedia);
			
		} catch (IllegalArgumentException e) {
			//			logger.log(Level.INFO, "例外のスローを捕捉", e);
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		System.out.println("END -MediaMainRefresh");

	}
	
	/**
	 * メディア メインパネル設定
	 * @param pa パネル
	 * @param mediafile メディアファイル
	 * @param Play プレイヤー
	 */
	void MediaMainSet(Pane pa, MediaPlayer Play) {
		System.out.println("START -MediaMainSet");

		try {

			// 動画再生クラスをインスタンス化
			MediaView mediaView = new MediaView(Play);
			
			mediaView.setFitWidth(pa.getWidth());
			mediaView.setFitHeight(pa.getHeight());
			mediaView.fitHeightProperty().bind(pa.heightProperty());
			mediaView.fitWidthProperty().bind(pa.widthProperty());

			pa.getChildren().add(mediaView);

		} catch (IllegalArgumentException e) {
			//			logger.log(Level.INFO, "例外のスローを捕捉", e);
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		System.out.println("END -MediaMainSet");

	}
	
	/**
	 * パネル再設定設定(メインの状態を保存)
	 */
	void mediaReSet() {
		System.out.println("START -mediaReSet");

		// 動画ファイル
		File file;
		mediaSetClear();

		if (selectedFileInfolist != null) {
			for (int count = 0; count < selectedFileInfolist.size(); count++) {

				// 動画ファイルのパスを取得
				file = new File(selectedFileInfolist.get(count).filePath);
				if (count == 0) {

					// メインパネル設定
					MediaMainSet(bp, mainPlay);

					// 動画ファイル設定
					MediaSet(bp1, file);

				} else if (count == 1) {
					// 動画ファイル設定
					MediaSet(bp2, file);

				} else if (count == 2) {
					// 動画ファイル設定
					MediaSet(bp3, file);
				} else if (count == 3) {
					// 動画ファイル設定
					MediaSet(bp4, file);
				} else if (count == 4) {
					// 動画ファイル設定
					MediaSet(bp5, file);

				}

			}

		}

		System.out.println("END -mediaReSet");

	}

	
	/**
	 * パネル再設定設定
	 */
	void mediaRefresh() {
		System.out.println("START -mediaRefresh");

		// 動画ファイル
		File file;
		mediaSetClear();

		if (selectedFileInfolist != null) {
			for (int count = 0; count < selectedFileInfolist.size(); count++) {

				// 動画ファイルのパスを取得
				file = new File(selectedFileInfolist.get(count).filePath);
				if (count == 0) {

					// メインパネル設定
					MediaMainRefresh(bp, file);

					// 動画ファイル設定
					MediaSet(bp1, file);

				} else if (count == 1) {
					// 動画ファイル設定
					MediaSet(bp2, file);

				} else if (count == 2) {
					// 動画ファイル設定
					MediaSet(bp3, file);
				} else if (count == 3) {
					// 動画ファイル設定
					MediaSet(bp4, file);
				} else if (count == 4) {
					// 動画ファイル設定
					MediaSet(bp5, file);

				}

			}

		}

		System.out.println("END -mediaRefresh");

	}
	

	/**
	 * パネルクリア
	 */
	void mediaSetClear() {
		System.out.println("START -mediaSetClear");

		bp.getChildren().clear();
		bp1.getChildren().clear();
		bp2.getChildren().clear();
		bp3.getChildren().clear();
		bp4.getChildren().clear();
		bp5.getChildren().clear();

		splitRoot.setDividerPositions(postRoot);
		splitRootLeft.setDividerPositions(posRootLeft);
		splitRootRight.setDividerPositions(posRootRight);
		splitMediaSub.setDividerPositions(posSubMedia);
		splitMedia.setDividerPositions(posMainMedia);

		for (int i = 0; i < splitMediaSub.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = splitMediaSub.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posSubMedia[ind]);
				}
			});
		}

		System.out.println("END -mediaSetClear");

	}

	/**
	 * ディバグ用
	 */
	void printFileName() {
		// 動画ファイル
		File file;

		if (selectedFileInfolist != null) {
			for (int count = 0; count < selectedFileInfolist.size(); count++) {

				// 動画ファイルのパスを取得
				file = new File(selectedFileInfolist.get(count).filePath);

				System.out.println(file.getName());

			}

		}

	}
	
	
}
