package jp.co.inc.meida.video.common;

import java.io.File;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.util.Duration;

public interface MediaPlay {
	
	/**
	 * コントロールを画面に設定
	 * @param pa
	 * @param f
	 * @param showPlay
	 */
	public  static void MediaSet(BorderPane pa, File f, int showPlay) {
		// 動画再生クラスをインスタンス化
		Media Video = new Media(f.toURI().toString());
		MediaPlayer Play = new MediaPlayer(Video);
		MediaView mediaView = new MediaView(Play);
		mediaView.setFitWidth(pa.getWidth());
		mediaView.setFitHeight(pa.getHeight());
		
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		
		pa.setCenter(mediaView);
		if (showPlay == 1) {
			// 画面下に表示する情報バーを作成
			HBox bottomNode = new HBox(10.0);
			bottomNode.getChildren().add(createButton(Play)); // 再生・停止・繰り返しボタン作成
			bottomNode.getChildren().add(createTimeSlider(Play)); // 時間表示スライダ作成
			bottomNode.getChildren().add(createVolumeSlider(Play)); // ボリューム表示スライダ作成
			pa.setBottom(bottomNode);

		}
	}


	/**
	 * 再生、一時停止、停止、連続再生ボタンを作成
	 * @param mp
	 * @return
	 */
	public static Node createButton(final MediaPlayer mp) {
		// 表示コンポーネントを作成
		HBox root = new HBox(1.0);
		Button playButton = new Button("Play");
		Button pauseButton = new Button("Pause");
		Button stopButton = new Button("Stop");
		ToggleButton repeatButton = new ToggleButton("Repeat");
		root.getChildren().add(playButton);
		root.getChildren().add(pauseButton);
		root.getChildren().add(stopButton);
		root.getChildren().add(repeatButton);

		// 再生ボタンにイベントを登録
		EventHandler<ActionEvent> playHandler = (e) -> {
			// 再生開始
			mp.play();
		};
		playButton.addEventHandler(ActionEvent.ACTION, playHandler);

		// 一時停止ボタンにイベントを登録
		EventHandler<ActionEvent> pauseHandler = (e) -> {
			// 一時停止
			mp.pause();
		};
		pauseButton.addEventHandler(ActionEvent.ACTION, pauseHandler);

		// 停止ボタンにイベントを登録
		EventHandler<ActionEvent> stopHandler = (e) -> {
			// 停止
			mp.stop();
		};
		stopButton.addEventHandler(ActionEvent.ACTION, stopHandler);

		// 連続再生設定
		Runnable repeatFunc = () -> {
			// 連続再生ボタンの状態を取得し
			if (repeatButton.isSelected()) {
				// 頭だしして再生
				mp.seek(mp.getStartTime());
				mp.play();
			} else {
				// 頭だしして停止
				mp.seek(mp.getStartTime());
				mp.stop();
			}
			;
		};
		mp.setOnEndOfMedia(repeatFunc);

		return root;
	}

	
	/**
	 * 再生、一時停止、停止、連続再生ボタンを設定
	 * @param mp
	 * @return
	 */
	public static Node setButton( MediaPlayer mp) {
		// 表示コンポーネントを作成
		HBox root = new HBox(1.0);
		Button playButton = new Button("Play");
		Button pauseButton = new Button("Pause");
		Button stopButton = new Button("Stop");
		ToggleButton repeatButton = new ToggleButton("Repeat");
		root.getChildren().add(playButton);
		root.getChildren().add(pauseButton);
		root.getChildren().add(stopButton);
		root.getChildren().add(repeatButton);

		// 再生ボタンにイベントを登録
		EventHandler<ActionEvent> playHandler = (e) -> {
			// 再生開始
			mp.play();
		};
		playButton.addEventHandler(ActionEvent.ACTION, playHandler);

		// 一時停止ボタンにイベントを登録
		EventHandler<ActionEvent> pauseHandler = (e) -> {
			// 一時停止
			mp.pause();
		};
		pauseButton.addEventHandler(ActionEvent.ACTION, pauseHandler);

		// 停止ボタンにイベントを登録
		EventHandler<ActionEvent> stopHandler = (e) -> {
			// 停止
			mp.stop();
		};
		stopButton.addEventHandler(ActionEvent.ACTION, stopHandler);

		// 連続再生設定
		Runnable repeatFunc = () -> {
			// 連続再生ボタンの状態を取得し
			if (repeatButton.isSelected()) {
				// 頭だしして再生
				mp.seek(mp.getStartTime());
				mp.play();
			} else {
				// 頭だしして停止
				mp.seek(mp.getStartTime());
				mp.stop();
			}
			;
		};
		mp.setOnEndOfMedia(repeatFunc);

		return root;
	}

	
	/**
	 * 再生時間を表示・操作するスライダを作成
	 * @param mp
	 * @return
	 */
	public static Node createTimeSlider(MediaPlayer mp) {
		// 表示コンポーネントを作成
		HBox root = new HBox(5.0);
		final Slider slider = new Slider();
		final Label info = new Label();
		root.getChildren().add(slider);
		root.getChildren().add(info);

		// 再生準備完了時に各種情報を取得する関数を登録
		final Runnable beforeFunc = mp.getOnReady(); // 現在のレディ関数
		Runnable readyFunc = () -> {
			// 先に登録された関数を実行
			if (beforeFunc != null) {
				beforeFunc.run();
			}

			// スライダの値を設定
			slider.setMin(mp.getStartTime().toSeconds());
			slider.setMax(mp.getStopTime().toSeconds());
			slider.setSnapToTicks(true);
		};
		mp.setOnReady(readyFunc);

		// 再生中にスライダを移動
		// プレイヤの現在時間が変更されるたびに呼び出されるリスナを登録
		ChangeListener<? super Duration> playListener = (ov, old, current) -> {
			//			System.out.println( "here" );
			// 動画の情報をラベル出力
			String infoStr = String.format("%4.2f", mp.getCurrentTime().toSeconds())
					+ "/"
					+ String.format("%4.2f", mp.getTotalDuration().toSeconds());
			info.setText(infoStr);

			// スライダを移動
			slider.setValue(mp.getCurrentTime().toSeconds());
		};
		mp.currentTimeProperty().addListener(playListener);

		// スライダを操作するとシークする
		EventHandler<MouseEvent> sliderHandler = (e) -> {
			// スライダを操作すると、シークする
			mp.seek(javafx.util.Duration.seconds(slider.getValue()));

		};
		slider.addEventFilter(MouseEvent.MOUSE_RELEASED, sliderHandler);

		return root;
	}

	/**
	 * ボリュームを表示・操作するスライダを作成
	 * @param mp
	 * @return
	 */
	public static Node createVolumeSlider(MediaPlayer mp) {
		// 表示コンポーネントを作成
		HBox root = new HBox(5.0);
		final Label info = new Label();
		final Slider slider = new Slider();

		// 再生準備完了時に各種情報を取得する関数を登録
		final Runnable beforeFunc = mp.getOnReady(); // 現在のレディ関数
		Runnable readyFunc = () -> {
			// 先に登録された関数を実行
			if (beforeFunc != null) {
				beforeFunc.run();
			}

			// スライダの値を設定
			slider.setMin(0.0);
			slider.setMax(1.0);
			slider.setValue(mp.getVolume());
		};
		mp.setOnReady(readyFunc);

		// 再生中にボリュームを表示
		// プレイヤの現在時間が変更されるたびに呼び出されるリスナを登録
		ChangeListener<? super Number> sliderListener = (ov, old, current) -> {
			// 動画の情報をラベル出力
			String infoStr = String.format("Vol:%4.2f", mp.getVolume());
			info.setText(infoStr);

			// スライダにあわせてボリュームを変更
			mp.setVolume(slider.getValue());

		};
		slider.valueProperty().addListener(sliderListener);

		//		double sliderWidth = 400;
		//		slider.setId("custom-slider");
		//
		//		slider.setMinWidth(10);
		//		slider.setMaxWidth(sliderWidth);
		//
		//		slider.setMin(0);
		//		slider.setMax(50);
		//		//        slider.setMinWidth(sliderWidth);
		//		//        slider.setMaxWidth(sliderWidth);
		//
		//		final ProgressBar pb = new ProgressBar(0);
		//		pb.setMinHeight(10);
		//		pb.setMaxHeight(50);
		//		pb.setMinWidth(slider.getMinWidth());
		//		pb.setMaxWidth(slider.getMaxWidth());
		//
		//		final ProgressIndicator pi = new ProgressIndicator(0);
		//
		//		slider.valueProperty().addListener(
		//				(ObservableValue<? extends Number> ov, Number old_val,
		//						Number new_val) -> {
		//							pb.setProgress(new_val.doubleValue()/50);
		//							pi.setProgress(new_val.doubleValue()/50);
		//						});
		//
		//		StackPane pane = new StackPane();
		//
		//		pane.getChildren().addAll(pb, slider);
		//
		//
		root.getChildren().add(slider);

		root.getChildren().add(info);

		return root;
	}

}
