package jp.co.inc.media.video.common;

import java.util.logging.Logger;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import jp.co.inc.media.video.utils.OSDetector;

public class BasDialog extends Stage implements BasConst, MessageConst {
	public Group root = new Group();

	// Loggerクラスのインスタンスを生成
	public static Logger logger = Logger.getLogger(BasDialog.class.getName());

	public BasDialog(Stage owner, String title, int width, int height) {
		initOwner(owner);
		initModality(Modality.WINDOW_MODAL);
		setTitle(title);
		setAlwaysOnTop(true);
		setResizable(false);
		setMaximized(false);
		//アイコンの設定
		Image img = new BasImage("media.png").getImage();
		getIcons().add(img);
		
		Scene scene = new Scene(root, width, height, Color.WHITE);
		if (OSDetector.isMac()) {
			scene.getStylesheets().add(BasDialog.class.getResource("style_mac.css").toExternalForm());
		}else {
			scene.getStylesheets().add(BasDialog.class.getResource("style.css").toExternalForm());
		}
		
		setScene(scene);
	}

}
