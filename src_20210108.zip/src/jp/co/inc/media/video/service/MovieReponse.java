
package jp.co.inc.media.video.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;MovieReponse complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="MovieReponse"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="Group_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Hosp_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Patient_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="User_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Upload_movie_name" type="{http://video.media.inc.co.jp/service}ArrayOfString" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Error" type="{http://video.media.inc.co.jp/service}ErrorReponse" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Image_no" type="{http://www.w3.org/2001/XMLSchema}int"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MovieReponse", propOrder = {
    "groupId",
    "hospId",
    "patientId",
    "userId",
    "uploadMovieName",
    "error",
    "imageNo"
})
public class MovieReponse {

    @XmlElement(name = "Group_id")
    protected String groupId;
    @XmlElement(name = "Hosp_id")
    protected String hospId;
    @XmlElement(name = "Patient_id")
    protected String patientId;
    @XmlElement(name = "User_id")
    protected String userId;
    @XmlElement(name = "Upload_movie_name")
    protected ArrayOfString uploadMovieName;
    @XmlElement(name = "Error")
    protected ErrorReponse error;
    @XmlElement(name = "Image_no")
    protected int imageNo;

    /**
     * groupIdプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * groupIdプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupId(String value) {
        this.groupId = value;
    }

    /**
     * hospIdプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHospId() {
        return hospId;
    }

    /**
     * hospIdプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHospId(String value) {
        this.hospId = value;
    }

    /**
     * patientIdプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientId() {
        return patientId;
    }

    /**
     * patientIdプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientId(String value) {
        this.patientId = value;
    }

    /**
     * userIdプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserId() {
        return userId;
    }

    /**
     * userIdプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * uploadMovieNameプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfString }
     *     
     */
    public ArrayOfString getUploadMovieName() {
        return uploadMovieName;
    }

    /**
     * uploadMovieNameプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfString }
     *     
     */
    public void setUploadMovieName(ArrayOfString value) {
        this.uploadMovieName = value;
    }

    /**
     * errorプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ErrorReponse }
     *     
     */
    public ErrorReponse getError() {
        return error;
    }

    /**
     * errorプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ErrorReponse }
     *     
     */
    public void setError(ErrorReponse value) {
        this.error = value;
    }

    /**
     * imageNoプロパティの値を取得します。
     * 
     */
    public int getImageNo() {
        return imageNo;
    }

    /**
     * imageNoプロパティの値を設定します。
     * 
     */
    public void setImageNo(int value) {
        this.imageNo = value;
    }

}
