
package jp.co.inc.media.video.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;anonymous complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="cert" type="{http://video.media.inc.co.jp/service}Certification" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="patient_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="movie_type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="movie_index" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cert",
    "patientId",
    "movieType",
    "movieIndex"
})
@XmlRootElement(name = "GetMovieList")
public class GetMovieList {

    protected Certification cert;
    @XmlElement(name = "patient_id")
    protected String patientId;
    @XmlElement(name = "movie_type")
    protected String movieType;
    @XmlElement(name = "movie_index")
    protected String movieIndex;

    /**
     * certプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Certification }
     *     
     */
    public Certification getCert() {
        return cert;
    }

    /**
     * certプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Certification }
     *     
     */
    public void setCert(Certification value) {
        this.cert = value;
    }

    /**
     * patientIdプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientId() {
        return patientId;
    }

    /**
     * patientIdプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientId(String value) {
        this.patientId = value;
    }

    /**
     * movieTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMovieType() {
        return movieType;
    }

    /**
     * movieTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMovieType(String value) {
        this.movieType = value;
    }

    /**
     * movieIndexプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMovieIndex() {
        return movieIndex;
    }

    /**
     * movieIndexプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMovieIndex(String value) {
        this.movieIndex = value;
    }

}
