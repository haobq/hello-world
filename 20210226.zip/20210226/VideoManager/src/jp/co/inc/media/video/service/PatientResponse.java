
package jp.co.inc.media.video.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;PatientResponse complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="PatientResponse"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="patients" type="{http://video.media.inc.co.jp/service}ArrayOfPatient" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Error" type="{http://video.media.inc.co.jp/service}ErrorResponse" minOccurs="0"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PatientResponse", propOrder = {
    "patients",
    "error"
})
public class PatientResponse {

    protected ArrayOfPatient patients;
    @XmlElement(name = "Error")
    protected ErrorResponse error;

    /**
     * patientsプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfPatient }
     *     
     */
    public ArrayOfPatient getPatients() {
        return patients;
    }

    /**
     * patientsプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfPatient }
     *     
     */
    public void setPatients(ArrayOfPatient value) {
        this.patients = value;
    }

    /**
     * errorプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ErrorResponse }
     *     
     */
    public ErrorResponse getError() {
        return error;
    }

    /**
     * errorプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ErrorResponse }
     *     
     */
    public void setError(ErrorResponse value) {
        this.error = value;
    }

}
