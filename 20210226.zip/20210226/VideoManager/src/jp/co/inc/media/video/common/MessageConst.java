/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0  2020/09/01
 */

package jp.co.inc.media.video.common;

/**
 * 概要：システムメッセージのクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public interface MessageConst {
	public final static String E0000 = "システムは二重起動できません。";
	public final static String E0001 = "システムエラーが発生しました。" +System.lineSeparator() +"サポートセンターまでご連絡ください。";
	public final static String E0002 = "選択したフォルダには動画／静止画がありません。" +System.lineSeparator() +"別のフォルダを選択してください。";
	public final static String E0003 = "画像ファイル格納フォルダの履歴ファイルが作成できません。";
	public final static String E0004 = "患者を選択してください。";
	public final static String E0005 = "訪問日日付が正しくありません。";
	public final static String E0006 = "システム起動中でエラーが発生しました。" +System.lineSeparator() +"サポートセンターまでご連絡ください。";
	public final static String E0007 = "設定ファイル（system.ini）を開き、" +System.lineSeparator() +"プロキシ名(proxyurl）を入力してください。";
	public final static String E0008 = "設定ファイル（system.ini）を開き、" +System.lineSeparator() +"プロキシポート(proxyport）を入力してください。";
	public final static String E0009 = "ユーザーIDを入力してください。";
	public final static String E0010 = "パスワードを入力してください。";
	public final static String E0011 = "医院を選択してください。";
	//public final static String E0012 = "設定ファイル（system.ini）を開き、" +System.lineSeparator() +"グループID(groupid)を入力してください。";
	public final static String E0012 = "グループIDを入力してください。";
	public final static String E0013 = "設定ファイル（system.ini）を開き、" +System.lineSeparator() +"サーバ接続URL(loginurl)を入力してください。";
	public final static String E0014 = "フォルダ選択時、エラーが発生しました。";
	public final static String E0015 = "患者検索時、エラーが発生しました。";
	public final static String E0016 = "訪問先データが取得できません。";
	public final static String E0017 = "訪問先を検索時、エラーが発生しました。";
	public final static String E0018 = "動画再生時、エラーが発生しました。";
	public final static String E0019 = "サムネイルでエラーが発生しました。";
	public final static String E0020 = "ファイルの送信でエラーが発生しました。";
	public final static String E0021 = "サーバに接続できません。";
	public final static String E0022 = "マニュアルPDFを開く時、エラーが発生しました。";
	public final static String E0023 = "容量のチェック時、エラーが発生しました。";
	public final static String E0024 = "画像ファイルを削除時、エラーが発生しました。";
	public final static String E0025 = "医院を選択時、エラーが発生しました。";
	public final static String E0026 = "動画ファイルを分割時、エラーが発生しました。";
	public final static String E0027 = "画像ファイルをアップロード時、エラーが発生しました。";
	public final static String E0028 = "指定されたファイルが見つかりません。再度フォルダ選択してください。";
	public final static String E0029 = "1時間以上画面を操作していないので、再度ログインしてください。";
	public final static String E0030 = "動画のサムネイルファイルを作成時、エラーが発生しました。";
	public final static String E0031 = "送信した医院IDと現在医院IDは一致しません。" +System.lineSeparator() +" 再ログインして送信した医院IDを選択してください。";
	public final static String E0032 = "格納容量の最大制限を超えています。";
	public final static String E0033 = "契約容量テーブルに基準容量を設定してください。";

	public final static String I0001 = "ファイルをアップロードします。よろしいですか。";
	public final static String I0002 = "アップロードされたファイルを削除します。よろしいですか。";
	public final static String I0003 = "ファイルを選択してください。";
	public final static String I0004 = "完了";
	public final static String I0005 = "備考欄の入力文字が最大制限(半角200文字)を超えています。";
	public final static String I0006 = "既に送信済みです。";
	//public final static String I0007 = "格納容量の最大制限を超えています。";
	public final static String I0008 = "タイトル欄の入力文字が最大制限(半角40文字)を超えています。";
	public final static String I0009 = "医院を選択してください。";
	//public final static String I0010 = "契約容量テーブルに基準容量を設定してください。";
	public final static String I0011 = "画像アップローダーを閉じますが宜しいでしょうか";
	//public final static String I0012 = "契約容量は80％以上を使用した。今回正常にアップロードできます。" +System.lineSeparator() +"増量必要場合、サポートセンターまでご連絡ください。";
	public final static String I0013 = "最新バージョンに更新しますか？"+System.lineSeparator() +"更新の場合、次のWEB画面からダウンロードしてインストールしてください";
}
