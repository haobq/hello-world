package jp.co.inc.media.video.utils;
import jp.co.inc.media.video.common.BasConst;

/**
 * 概要：履歴情報格納BEAN
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class JsonListBean implements BasConst {

	/** JSONファイル名 */
	public String fileName = "";

	public String status = "";

	/**ファイル変更した最新更新日 */
	private String lastUpdateDate = "";

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * JSONファイル名取得
	 *
	 * @return JSONファイル名
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * JSONファイル名設定
	 *
	 * @param fileName　JSONファイル名
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 *  JSONファイル最新更新日を取得する
	 * @return 最新更新日時
	 */
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	/**
	 * JSONファイル最新更新日を設定する
	 * @param lastUpdateDate
	 */
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
}
