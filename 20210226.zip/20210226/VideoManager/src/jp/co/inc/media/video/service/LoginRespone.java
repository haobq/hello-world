
package jp.co.inc.media.video.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;LoginRespone complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="LoginRespone"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="Cert" type="{http://video.media.inc.co.jp/service}Certification" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="ClinicList" type="{http://video.media.inc.co.jp/service}ArrayOfClinic" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="FacilityList" type="{http://video.media.inc.co.jp/service}ArrayOfFacility" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Error" type="{http://video.media.inc.co.jp/service}ErrorResponse" minOccurs="0"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoginRespone", propOrder = {
    "cert",
    "clinicList",
    "facilityList",
    "error"
})
public class LoginRespone {

    @XmlElement(name = "Cert")
    protected Certification cert;
    @XmlElement(name = "ClinicList")
    protected ArrayOfClinic clinicList;
    @XmlElement(name = "FacilityList")
    protected ArrayOfFacility facilityList;
    @XmlElement(name = "Error")
    protected ErrorResponse error;

    /**
     * certプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Certification }
     *     
     */
    public Certification getCert() {
        return cert;
    }

    /**
     * certプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Certification }
     *     
     */
    public void setCert(Certification value) {
        this.cert = value;
    }

    /**
     * clinicListプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfClinic }
     *     
     */
    public ArrayOfClinic getClinicList() {
        return clinicList;
    }

    /**
     * clinicListプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfClinic }
     *     
     */
    public void setClinicList(ArrayOfClinic value) {
        this.clinicList = value;
    }

    /**
     * facilityListプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfFacility }
     *     
     */
    public ArrayOfFacility getFacilityList() {
        return facilityList;
    }

    /**
     * facilityListプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfFacility }
     *     
     */
    public void setFacilityList(ArrayOfFacility value) {
        this.facilityList = value;
    }

    /**
     * errorプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ErrorResponse }
     *     
     */
    public ErrorResponse getError() {
        return error;
    }

    /**
     * errorプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ErrorResponse }
     *     
     */
    public void setError(ErrorResponse value) {
        this.error = value;
    }

}
