
package jp.co.inc.media.video.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;PatientRequest complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="PatientRequest"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="Certification" type="{http://video.media.inc.co.jp/service}Certification" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Visit_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Visit_Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Patient_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Kbn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PatientRequest", propOrder = {
    "certification",
    "visitId",
    "visitDate",
    "patientName",
    "kbn"
})
public class PatientRequest {

    @XmlElement(name = "Certification")
    protected Certification certification;
    @XmlElement(name = "Visit_id")
    protected String visitId;
    @XmlElement(name = "Visit_Date")
    protected String visitDate;
    @XmlElement(name = "Patient_name")
    protected String patientName;
    @XmlElement(name = "Kbn")
    protected String kbn;

    /**
     * certificationプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Certification }
     *     
     */
    public Certification getCertification() {
        return certification;
    }

    /**
     * certificationプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Certification }
     *     
     */
    public void setCertification(Certification value) {
        this.certification = value;
    }

    /**
     * visitIdプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVisitId() {
        return visitId;
    }

    /**
     * visitIdプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVisitId(String value) {
        this.visitId = value;
    }

    /**
     * visitDateプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVisitDate() {
        return visitDate;
    }

    /**
     * visitDateプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVisitDate(String value) {
        this.visitDate = value;
    }

    /**
     * patientNameプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientName() {
        return patientName;
    }

    /**
     * patientNameプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientName(String value) {
        this.patientName = value;
    }

    /**
     * kbnプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKbn() {
        return kbn;
    }

    /**
     * kbnプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKbn(String value) {
        this.kbn = value;
    }

}
