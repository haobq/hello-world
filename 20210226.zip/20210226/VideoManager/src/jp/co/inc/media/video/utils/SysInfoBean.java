package jp.co.inc.media.video.utils;

import javafx.util.Duration;
import jp.co.inc.media.video.service.LoginRespone;

/**
 * 概要：システムbean情報のクラスです。
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class SysInfoBean {
	// ファイルリストテーブル選択したカラム
	public int selectedRow = 0;
	// 選択したファイル名称
	private String selectedFileName = "";

	//操作時間監視
	private static double startRunTime = 0;
	
	public static double getStartRunTime() {
		return startRunTime;
	}

	public static void setStartRunTime(double startRunTime) {
		SysInfoBean.startRunTime = startRunTime;
	}

	private static LoginRespone loginInfo = null;

	public static LoginRespone getLoginInfo() {
		return loginInfo;
	}

	public static void setLoginInfo(LoginRespone loginInfo) {
		SysInfoBean.loginInfo = loginInfo;
	}

	public String getSelectedFileName() {
		return selectedFileName;
	}

	public void setSelectedFileName(String selectedFileName) {
		this.selectedFileName = selectedFileName;
	}

	// メディア終了時間
	private static Duration endTime = new Duration(0);

	/**
	 * @return endTime
	 */
	public Duration getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime1 セットする endTime
	 */
	public static void setEndTime(Duration endTime1) {
		endTime = endTime1;
	}

	/**
	 * @return selectedRow
	 */
	public int getSelectedRow() {
		return selectedRow;
	}

	/**
	 * @param selectedRow セットする selectedRow
	 */
	public void setSelectedRow(int selectedRow) {
		this.selectedRow = selectedRow;
	}

	// MediaPlayerボリューム
	private static double mediaVolume = 0.0;

	/**
	 * @return mediaVolume
	 */
	public static double getMediaVolume() {
		return mediaVolume;
	}

	/**
	 * @param mediaVolume1 セットする mediaVolume
	 */
	public static void setMediaVolume(double mediaVolume1) {
		mediaVolume = mediaVolume1;
	}

}
