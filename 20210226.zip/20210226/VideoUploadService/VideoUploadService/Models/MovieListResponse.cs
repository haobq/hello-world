﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VideoUploadService.Models;

namespace VideoUploadService
{
    public class MovieListResponse
    {
        //医院ID
        public string Hosp_id { get; set; }
        //動画・写真リスト
        public List<Movies> movies { get; set; }
        //エラー
        public ErrorResponse Error { get; set; }
    }
}