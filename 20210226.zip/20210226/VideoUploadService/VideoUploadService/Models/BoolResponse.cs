﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class BoolResponse
    {
        public int Reslt { get; set; }
        public bool ret { get; set; }
        //エラー
        public ErrorResponse Error { get; set; }
    }
}