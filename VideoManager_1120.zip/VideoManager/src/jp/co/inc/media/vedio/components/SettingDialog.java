package jp.co.inc.media.vedio.components;

import java.io.File;
import java.util.HashMap;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import jp.co.inc.media.vedio.common.BasButton;
import jp.co.inc.media.vedio.common.BasDialog;
import jp.co.inc.media.vedio.utils.FileProperty;
import jp.co.inc.media.vedio.utils.Messagebox;

public class SettingDialog extends BasDialog {
	String logLevel = "";

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public SettingDialog(Stage owner, String title, int width, int height) throws Exception {
		super(owner, title, width, height);

		FileProperty filePro = new FileProperty(proFilePath);
		FileProperty logPro = new FileProperty(logFilePath);
		String WorkingDirJson = filePro.getProperty("WorkingDirJson");

		TabPane tabPane = new TabPane();
		tabPane.setPrefWidth(width);
		tabPane.setStyle("-fx-background-color: white");
		tabPane.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);

		Tab tabAll = new Tab("全盤");
		GridPane gridAll = new GridPane();
		gridAll.setPadding(new Insets(5));
		gridAll.setHgap(5);
		gridAll.setVgap(5);

		Label groupNameLbl = new Label("グループID: ");
		gridAll.add(groupNameLbl, 0, 1);

		final TextField groupNameFld = new TextField(filePro.getProperty("groupid"));
		groupNameFld.setPrefWidth(200);
		gridAll.add(groupNameFld, 1, 1);

		Label loginNameLbl = new Label("ログインURL: ");
		gridAll.add(loginNameLbl, 0, 2);

		final TextField loginUrlFld = new TextField(filePro.getProperty("loginurl"));
		loginUrlFld.setPrefWidth(200);
		gridAll.add(loginUrlFld, 1, 2);

		Label workPathLbl = new Label("作業フォルダ: ");
		gridAll.add(workPathLbl, 0, 3);
		final TextField workPathFld = new TextField(filePro.getProperty("WorkingDir"));
		workPathFld.setPrefWidth(200);
		gridAll.add(workPathFld, 1, 3);

		tabAll.setContent(gridAll);

		Tab tabProxy = new Tab("プロキシ");
		GridPane gridProxy = new GridPane();
		gridProxy.setPadding(new Insets(5));
		gridProxy.setHgap(5);
		gridProxy.setVgap(5);

		Label proxyUrlNameLbl = new Label("URL: ");
		gridProxy.add(proxyUrlNameLbl, 0, 1);

		Label proxyPortNameLbl = new Label("ポート: ");
		gridProxy.add(proxyPortNameLbl, 0, 2);

		Label proxyActiveLbl = new Label("有効: ");
		gridProxy.add(proxyActiveLbl, 0, 3);

		final TextField proxyUrlFld = new TextField(filePro.getProperty("proxyurl"));
		proxyUrlFld.setPrefWidth(200);
		gridProxy.add(proxyUrlFld, 1, 1);

		final TextField proxyPortFld = new TextField(filePro.getProperty("proxyport"));
		proxyPortFld.setPrefWidth(200);
		gridProxy.add(proxyPortFld, 1, 2);

		final CheckBox checkFld = new CheckBox();
		checkFld.setPrefWidth(30);
		String active = filePro.getProperty("active");
		if ("true".equals(active)) {
			checkFld.setSelected(true);
		}
		gridProxy.add(checkFld, 1, 3);
		tabProxy.setContent(gridProxy);

		Tab tabLog = new Tab("ログ設定");
		GridPane gridLog = new GridPane();
		gridLog.setPadding(new Insets(5));
		gridLog.setHgap(5);
		gridLog.setVgap(5);

		Label logLevelNameLbl = new Label("ログレベル: ");
		gridLog.add(logLevelNameLbl, 0, 1);
		tabLog.setContent(gridLog);

		final ComboBox<String> combobox = new ComboBox<>();
		combobox.getItems().addAll("最も詳細", "詳細", "普通", "構成", "情報", "警告", "重大");
		combobox.setVisibleRowCount(4);
		HashMap<String, String> logMap = new HashMap<String, String>();
		logMap.put("最も詳細", "FINEST");
		logMap.put("詳細", "FINER");
		logMap.put("普通", "FINE");
		logMap.put("構成", "CONFIG");
		logMap.put("情報", "INFO");
		logMap.put("警告", "WARNING");
		logMap.put("重大", "SEVERE");

		logLevel = logPro.getProperty("java.util.logging.FileHandler.level");
		for (String key : logMap.keySet()) {
			if (logMap.get(key).contains(logLevel)) {
				combobox.setValue(key);
			}
		}

		combobox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			public void changed(ObservableValue<? extends String> ov,
					final String oldvalue, final String newvalue) {
				setLogLevel(logMap.get(newvalue));
			}
		});

		gridLog.add(combobox, 1, 1);
		tabLog.setContent(gridLog);

		Label logFileNameLbl = new Label("ログファイル名: ");
		gridLog.add(logFileNameLbl, 0, 2);
		tabLog.setContent(gridLog);

		final TextField logFileFld = new TextField(logPro.getProperty("java.util.logging.FileHandler.pattern"));
		logFileFld.setPrefWidth(200);
		gridLog.add(logFileFld, 1, 2);

		tabPane.getTabs().addAll(tabAll, tabProxy, tabLog);

		HBox hBox = new HBox(15.0);
		hBox.setPadding(new Insets(15, 12, 15, 12));
		hBox.setSpacing(10);
		Button saveBtn = new BasButton("save.png", 16, 16, BUTTON_SAVE);
		saveBtn.setPrefWidth(100);
		saveBtn.setStyle(BUTTON_STYLE);
		saveBtn.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				try {
					if (CheckData()) {
						FileProperty filePro = new FileProperty(proFilePath);
						filePro.setProperty("WorkingDirJson", WorkingDirJson);
						filePro.setProperty("WorkingDir", workPathFld.getText().replace("\\", ""));
						filePro.setProperty("groupid", groupNameFld.getText());
						filePro.setProperty("proxyurl", proxyUrlFld.getText());
						filePro.setProperty("proxyport", proxyPortFld.getText());
						filePro.setProperty("loginurl", loginUrlFld.getText());
						if (checkFld.isSelected()) {
							filePro.setProperty("active", "true");
						} else {
							filePro.setProperty("active", "false");
						}
						filePro.storeProperty();

						FileProperty logPro = new FileProperty(logFilePath);
						logPro.setProperty("java.util.logging.FileHandler.level", getLogLevel());
						logPro.setProperty("java.util.logging.FileHandler.pattern", logFileFld.getText());
						logPro.storeProperty();
						close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

			private boolean CheckData() {
				boolean checkResult = true;
				String errMsg = "";
				// URL有効性
				String proxyUrl = proxyUrlFld.getText();
				if (proxyUrl != null && !"".equals(proxyUrl)) {
					if (!proxyUrl.toUpperCase().contains("HTTP://") && !proxyUrl.toUpperCase().contains("HTTPS://")) {
						errMsg = E0008 +"\n";
						proxyUrlFld.setFocusTraversable(true);
						checkResult = false;
					}
				}


				String logUrl = loginUrlFld.getText();
				if (logUrl != null && !"".equals(logUrl)) {
					if (!logUrl.toUpperCase().contains("HTTP://") && !logUrl.toUpperCase().contains("HTTPS://")) {
						errMsg = E0009 +"\n";
						loginUrlFld.setFocusTraversable(true);
						checkResult = false;
					}
				}
				// ポート数字
				try {
					int num = Integer.parseInt(proxyPortFld.getText());
				} catch (Exception e) {
					errMsg = E0010 + "\n";
					proxyPortFld.setFocusTraversable(true);
					checkResult = false;
				}

				// プロキシ有効
				if (checkFld.isSelected()) {
					if ("".equals(proxyUrl) || proxyUrl == null) {
						errMsg = E0011 + "\n";
						proxyUrlFld.setFocusTraversable(true);
						checkResult = false;
					}
					if ("".equals(proxyPortFld.getText()) || proxyPortFld.getText() == null) {
						errMsg = E0012 + "\n";
						proxyPortFld.setFocusTraversable(true);
						checkResult = false;
					}

				}

				// フォルダの存在
				try {
					if ("".equals(workPathFld.getText()) || workPathFld.getText() == null) {
						errMsg = E0015+"\n";
						workPathFld.setFocusTraversable(true);
						checkResult = false;
					}
					File tmpfile = new File(workPathFld.getText().replace("\\", ""));
					if (!tmpfile.isDirectory()) {
						errMsg = E0015+"\n";
						workPathFld.setFocusTraversable(true);
						checkResult = false;
					}
				} catch (Exception e) {
					errMsg = E0015+"\n";
					workPathFld.setFocusTraversable(true);
					checkResult = false;
				}

				//ログファイル
				try {
					File tmpfile = new File( System.getProperty("user.dir").replace("\\", "/") + "/"+logFileFld.getText());
					if (!tmpfile.isFile() || !tmpfile.getName().endsWith("log")) {
						errMsg = E0016 +"\n";
						logFileFld.setFocusTraversable(true);
						checkResult = false;
					}

				}catch (Exception e) {
					errMsg = E0016 +"\n";
					logFileFld.setFocusTraversable(true);
					checkResult = false;
				}
				if (!"".equals(errMsg)) {
					Messagebox.Error(errMsg);
				}

				return checkResult;
			}
		});

		Button canelBtn = new BasButton("cancel.png", 16, 16, BUTTON_CANEL);
		canelBtn.setPrefWidth(100);
		canelBtn.setStyle(BUTTON_STYLE);
		canelBtn.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				close();
			}
		});
		BorderPane settingPane = new BorderPane();
		hBox.setPrefWidth(200);
		hBox.getChildren().addAll(saveBtn, canelBtn);
		hBox.setAlignment(Pos.CENTER_RIGHT);
		settingPane.setCenter(tabPane);
		settingPane.setBottom(hBox);
		root.getChildren().add(settingPane);
	}
}