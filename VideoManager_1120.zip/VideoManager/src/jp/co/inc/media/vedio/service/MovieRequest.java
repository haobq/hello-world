
package jp.co.inc.media.vedio.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;MovieRequest complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="MovieRequest"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="Certification" type="{http://vedio.media.inc.co.jp/service}Certification" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Patient_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Movie_index" type="{http://www.w3.org/2001/XMLSchema}int"/&amp;gt;
 *         &amp;lt;element name="Movie_date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Remarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Movie_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="FileCount" type="{http://www.w3.org/2001/XMLSchema}int"/&amp;gt;
 *         &amp;lt;element name="Movie_context" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Movie_size" type="{http://www.w3.org/2001/XMLSchema}long"/&amp;gt;
 *         &amp;lt;element name="SpriteFileNo" type="{http://www.w3.org/2001/XMLSchema}int"/&amp;gt;
 *         &amp;lt;element name="Movie_type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MovieRequest", propOrder = {
    "certification",
    "patientId",
    "movieIndex",
    "movieDate",
    "remarks",
    "movieName",
    "fileCount",
    "movieContext",
    "movieSize",
    "spriteFileNo",
    "movieType"
})
public class MovieRequest {

    @XmlElement(name = "Certification")
    protected Certification certification;
    @XmlElement(name = "Patient_id")
    protected String patientId;
    @XmlElement(name = "Movie_index")
    protected int movieIndex;
    @XmlElement(name = "Movie_date")
    protected String movieDate;
    @XmlElement(name = "Remarks")
    protected String remarks;
    @XmlElement(name = "Movie_name")
    protected String movieName;
    @XmlElement(name = "FileCount")
    protected int fileCount;
    @XmlElement(name = "Movie_context")
    protected byte[] movieContext;
    @XmlElement(name = "Movie_size")
    protected long movieSize;
    @XmlElement(name = "SpriteFileNo")
    protected int spriteFileNo;
    @XmlElement(name = "Movie_type")
    protected String movieType;

    /**
     * certificationプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Certification }
     *     
     */
    public Certification getCertification() {
        return certification;
    }

    /**
     * certificationプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Certification }
     *     
     */
    public void setCertification(Certification value) {
        this.certification = value;
    }

    /**
     * patientIdプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientId() {
        return patientId;
    }

    /**
     * patientIdプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientId(String value) {
        this.patientId = value;
    }

    /**
     * movieIndexプロパティの値を取得します。
     * 
     */
    public int getMovieIndex() {
        return movieIndex;
    }

    /**
     * movieIndexプロパティの値を設定します。
     * 
     */
    public void setMovieIndex(int value) {
        this.movieIndex = value;
    }

    /**
     * movieDateプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMovieDate() {
        return movieDate;
    }

    /**
     * movieDateプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMovieDate(String value) {
        this.movieDate = value;
    }

    /**
     * remarksプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * remarksプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemarks(String value) {
        this.remarks = value;
    }

    /**
     * movieNameプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMovieName() {
        return movieName;
    }

    /**
     * movieNameプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMovieName(String value) {
        this.movieName = value;
    }

    /**
     * fileCountプロパティの値を取得します。
     * 
     */
    public int getFileCount() {
        return fileCount;
    }

    /**
     * fileCountプロパティの値を設定します。
     * 
     */
    public void setFileCount(int value) {
        this.fileCount = value;
    }

    /**
     * movieContextプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getMovieContext() {
        return movieContext;
    }

    /**
     * movieContextプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setMovieContext(byte[] value) {
        this.movieContext = value;
    }

    /**
     * movieSizeプロパティの値を取得します。
     * 
     */
    public long getMovieSize() {
        return movieSize;
    }

    /**
     * movieSizeプロパティの値を設定します。
     * 
     */
    public void setMovieSize(long value) {
        this.movieSize = value;
    }

    /**
     * spriteFileNoプロパティの値を取得します。
     * 
     */
    public int getSpriteFileNo() {
        return spriteFileNo;
    }

    /**
     * spriteFileNoプロパティの値を設定します。
     * 
     */
    public void setSpriteFileNo(int value) {
        this.spriteFileNo = value;
    }

    /**
     * movieTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMovieType() {
        return movieType;
    }

    /**
     * movieTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMovieType(String value) {
        this.movieType = value;
    }

}
