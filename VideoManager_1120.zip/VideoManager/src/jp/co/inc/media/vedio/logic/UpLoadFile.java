package jp.co.inc.media.vedio.logic;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.namespace.QName;

import org.apache.commons.io.FilenameUtils;

import javafx.application.Platform;
import javafx.concurrent.Task;
import jp.co.inc.media.vedio.common.BasConst;
import jp.co.inc.media.vedio.common.BasFrame;
import jp.co.inc.media.vedio.common.MessageConst;
import jp.co.inc.media.vedio.service.LoginRespone;
import jp.co.inc.media.vedio.service.MovieRequest;
import jp.co.inc.media.vedio.service.VedioUploadService;
import jp.co.inc.media.vedio.service.VedioUploadServiceSoap;
import jp.co.inc.media.vedio.utils.FileInfoBean;
import jp.co.inc.media.vedio.utils.Messagebox;

public class UpLoadFile extends Task<String> implements BasConst, MessageConst {

	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(UpLoadFile.class.getName());
    private static final QName SERVICE_NAME = new QName("http://vedio.media.inc.co.jp/service", "VedioUploadService");

	/**
	 * ファイル削除
	 * @param file ファイル削除
	 * @throws IOException ファイル読み異常
	 */
	public static void delete(File file)
			throws IOException {

		if (file.isDirectory()) {
			//directory is empty, then delete it
			if (file.list().length == 0) {
				file.delete();
			} else {
				//list all the directory contents
				String files[] = file.list();
				for (String temp : files) {
					//construct the file structure
					File fileDelete = new File(file, temp);
					//recursive delete
					delete(fileDelete);
				}
				//check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();
				}
			}
		} else {
			//if file, then delete it
			file.delete();
		}
	}

	/**
	 * フォルダを削除
	 * @param folder フォルダ
	 * @throws IOException  ファイル読み異常
	 */
	public static void deletefolder(String folder)
			throws IOException {
		File directory = new File(folder);
		//make sure directory exists
		if (!directory.exists()) {
		} else {
			try {
				delete(directory);
			} catch (IOException e) {
				e.printStackTrace();
				logger.log(Level.SEVERE, THROW_INFO, e);
				Messagebox.Error(e.getMessage());
			}
		}
	}

	/**
	 * 送信処理
	 */
	@Override
	protected String call() throws Exception {

		// フォルダを削除
		deletefolder(mp4Path);

		System.out.println("送信開始時間：" + System.currentTimeMillis());
		double start = System.currentTimeMillis();

		try {

			LoginRespone loginReponse = VedioUploadServiceLogic.getLoginReponse();

			// 連番
			int renBan = 0;
			File dir;
			for (FileInfoBean file : BasFrame.fileInfolist) {
				renBan ++;
				// ステータスが完了の場合
				if (file.getStatus().equals(Status.STATUS_COMPLETED)) {
					continue;
				} else {
					// 送信中に更新
					file.setStatus(Status.STATUS_WORKING);
				}

				if (file.getFileName().equals(BasFrame.sysInfoBean.getSelectedFileName())) {

					// ファイルコピー
					// 病院ID + _ + 患者ID + _ + カレンダー日付 + _ + 連番
					String strUploadFileName = BasFrame.patientInfo.getHospitalId() + "_"
							+ BasFrame.patientInfo.getPatientId() + "_"
							+ BasFrame.datePicker.getValue().toString().replace("-", "") + "_" + renBan + EXTENSION_MP4;

					// 連番
					file.setMovie_index(renBan);
					// アップロードファイル名
					file.setUploadFileName(strUploadFileName);

					// フォルダを作成
					if (!Files.exists(Paths.get(tmpPath))) {
						Files.createDirectory(Paths.get(tmpPath));
					}
					if (!Files.exists(Paths.get(mp4Path))) {
						Files.createDirectory(Paths.get(mp4Path));
					}
					// アップロードファイル
					final Path uploadFilePath = Paths.get(mp4Path + strUploadFileName);
					// 元ファイル
					final Path sourcePath = Paths.get(file.getFilePath());

					try {
						Files.copy(sourcePath, uploadFilePath);
						System.out.println("コピーが成功しました");
					} catch (IOException e) {
						e.printStackTrace();
						logger.log(Level.SEVERE, THROW_INFO, e);
						Messagebox.Error(e.getMessage());
					}

					// ファイル分割
					final FileSplit fileSplit = new FileSplit();
					try {
						fileSplit.split((mp4Path + strUploadFileName), mp4Path, SPLITE_SIZE);
					} catch (Exception e) {
						e.printStackTrace();
						logger.log(Level.SEVERE, THROW_INFO, e);
						Messagebox.Error(e.getMessage());
					}

					// 元ファイル削除
					dir = uploadFilePath.toFile();
					dir.delete();

					// 圧縮」、送信、削除　処理開始
					dir = Paths.get(mp4Path).toFile();
					final File files[] = dir.listFiles();
					int fileCount = 0;
					fileCount = files.length;
					// ファイルソード
					java.util.Arrays.sort(files, new java.util.Comparator<File>() {
						public int compare(File file1, File file2) {
							return file1.getName().compareTo(file2.getName());
						}
					});

					// ファイルサイズ
					long fileSize = 0;
					int intSplitNo = 0;
					for (File f : files) {

						intSplitNo ++;

						String zipFilePath = FilenameUtils.removeExtension(f.getPath())
								+ FilenameUtils.getExtension(f.getName());
						String zipFile = zipFilePath + "/" + FilenameUtils.removeExtension(f.getName())
								+ FilenameUtils.getExtension(f.getName()) + ".zip";

						File newfile = new File(zipFilePath);

						if (newfile.mkdir()) {

							// 圧縮 .zip
							fileSplit.archive(f.getPath(), zipFile);

							fileSize = fileSize + f.length();

							// 進捗バーの更新
							updateProgress(intSplitNo*100/fileCount, 100);
							// 進捗バー表示
							BasFrame.hBoxPrpgress.setVisible(true);
							BasFrame.labelPetcent.setVisible(true);

							// 進捗メッセージの更新
							updateMessage(String.format("進捗：%d", intSplitNo*100/fileCount));
							// 待機
							//TimeUnit.SECONDS.sleep(1);


							URL wsdlURL = VedioUploadService.WSDL_LOCATION;
							System.out.println("URL:"+ wsdlURL);

							try {

								// zipファイルをByte[]に変換
								byte[] media = ZipCompressUtils.readBytesFromFile(zipFile);


								VedioUploadService ss = new VedioUploadService(wsdlURL, SERVICE_NAME);
								System.out.println("ss:");
								VedioUploadServiceSoap port = ss.getVedioUploadServiceSoap12();
								System.out.println("port:" + port);

								MovieRequest req = new MovieRequest();
								System.out.println("req:");

								req.setCertification(loginReponse.getCert());
								req.setPatientId(BasFrame.patientInfo.getPatientId());
								req.setMovieName(strUploadFileName);
								req.setMovieIndex(renBan);
								req.setMovieSize(file.getFileSize());
								req.setMovieDate(BasFrame.datePicker.getValue().toString());
								req.setMovieType(EXTENSION_MP4);
								req.setSpriteFileNo(intSplitNo);
								req.setRemarks(file.getBikou());
								req.setFileCount(fileCount);
								req.setMovieContext(media);

								System.out.println("mediaUpload start:");

								jp.co.inc.media.vedio.service.MovieReponse _mediaUpload__return = port.mediaUpload(req);
								System.out.println("mediaUpload.result=" + _mediaUpload__return);

								System.out.println("mediaUpload end:");

								if(!_mediaUpload__return.getUploadResult().equals(MsgOK)){
								      throw new Exception (E0018);
								}

							} catch (Exception e) {

								Platform.runLater(
										  () -> {

												// 文字置き換え
												if(e.toString().indexOf(FAILED_TO_CREATE_SERVICE)> 0
														|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE)> 0
														|| e.toString().indexOf(ERROR_WRITING_REQUEST_BODY_TO_SERVE)> 0
														) {
													Messagebox.Error(ServiceConstructionException);

												} else {

													Messagebox.Error(e.getMessage());
												}
												logger.log(Level.SEVERE, THROW_INFO, e);
										  }
										);
								return null;
							}

						}
					}



					 // 現在日時情報で初期化されたインスタンスの生成
					 Date dateObj = new Date();
					 SimpleDateFormat format = new SimpleDateFormat( DATE_TYPE_YYYY_MM_DD_HH_MM );

					// 送信時間
					file.setMovie_send_time(format.format( dateObj ));

					// 完に更新
					file.setStatus(Status.STATUS_COMPLETED);


				}

			}

			// フォルダを削除
			deletefolder(mp4Path);

			BasFrame.labelPetcent.setVisible(false);
			// アップロード完了！
			updateMessage(I0004);
			// 待機
			TimeUnit.SECONDS.sleep(1);

			BasFrame.hBoxPrpgress.setVisible(false);

			System.out.println("送信終了時間：" + System.currentTimeMillis());
			double end = System.currentTimeMillis();
			System.out.println("送信時間：" + (end - start)/1000  + "s");


		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);

			e.getStackTrace();
			String repl ="VedioUploadService.BizException:";
			if (e.getMessage().indexOf(repl)>0) {
				int beginIndex = e.getMessage().indexOf(repl);
				String errMsg = e.getMessage().substring(beginIndex);
				int endIndex = errMsg.indexOf("。");
				errMsg = errMsg.substring(0,endIndex).replaceAll(repl, "");
				// 文字置き換え
				if(e.toString().indexOf(FAILED_TO_CREATE_SERVICE)> 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE)> 0
						) {
					Messagebox.Error(ServiceConstructionException);

				} else {

					Messagebox.Error(errMsg);
				}
				return  null;
			}else {

				System.out.println("異常:" + e.getMessage());
				// 文字置き換え
				if(e.toString().indexOf(FAILED_TO_CREATE_SERVICE)> 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE)> 0
						) {
					Messagebox.Error(ServiceConstructionException);

				} else {

					Messagebox.Error(e.getMessage());
				}


				return  null;
			}

		}

		return "Done";
	}

}
