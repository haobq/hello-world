/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.media.vedio.common;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

/**
 * 概要：FRMAE使用する定数を定義
 *
 */
public interface BasConst {

	/** 動画ファイルの拡張子 */
	public static String EXTENSION_MP4 = ".mp4";

	/** 静止画ファイルの拡張子 */
	public static String EXTENSION_GIF = ".gif";
	public static String EXTENSION_JPG = ".jpg";
	public static String EXTENSION_PNG = ".png";
	public static String EXTENSION_JPEG = ".jpeg";
	public static String EXTENSION_BMP = ".bmp";

	/** 動画ファイルのアップロード状況「未処理」 */
	String STATUS_NEW = "未";
	/** 動画ファイルのアップロード状況「処理中」 */
	String STATUS_WORKING = "中";
	/** 動画ファイルのアップロード状況「処理完了」 */
	String STATUS_COMPLETED = "完";
	// ステータス
	public enum Status {
		STATUS_NEW,
		STATUS_WORKING,
		STATUS_COMPLETED;
	}

	/** 動画フォルダの管理用JSON */
	public static String MANAGER_JSON = "Manager.json";
	/** ファイルパスの区切り文字 */
	public static String FILE_SEPARATOR = "/";

	/** ファイル選択 */
	public static String FILE_TITLE_CHECKED = "選択";
	/** ファイル状況 */
	public static String FILE_TITLE_STATAS = "状況 ";
	/** ファイル名称 */
	public static String FILE_TITLE_NAME = "ファイル名称";
	/** ファイル最新更新日時 */
	public static String FILE_TITLE_LASTED_UPDATE = "ファイル最新更新日時";
	/** ファイルサイズ*/
	public static String FILE_TITLE_SIZE = "サイズ(byte)";
	/** ファイル患者ID*/
	public static String FILE_TITLE_PATIENT_ID= "患者ID";
	/** 送信時間*/
	public static String FILE_TITLE_MOVIE_SEND_TIME= "送信時間";
	/** ファイルサイズ*/
	public static String FILE_TITLE_BIKOU = "備考";
	/** アップロードファイル名*/
	public static String FILE_TITLE_UPLOAD_FILE_NAME = "アップロードファイル名";

	/** 訪問日 */
	public static String LABEL_VISIT_DATE = "訪問日:";
	/** 施設 */
	public static String FACILITY_STYLE = "施設選択";

	/** 患者ID */
	public static String PATIENT_TITLE_PATIENT_ID = "患者ID";
	/** 患者名 */
	public static String PATIENT_TITLE_PATIENT_NAME = "患者名 ";
	/** 生年月日 */
	public static String PATIENT_TITLE_BIRTHDAY = "生年月日";
	/** 患者性別 */
	public static String PATIENT_TITLE_SEX = "性別";

	public static String LOGIN_TITLE ="ログイン";

	public static String SEND_HIS_TITLE ="送信履歴";

	public static String SETT1NG_TITLE ="設定";

	public static String SETTING_SCR ="設定画面";

	public static String MENU_TITLE = "マニュアル";
	public static String MENU_VER = "バージョン";
	/** JSONファイル状況 */
	public static String JSON_TITLE_STATAS = "状況 ";
	/** JSONファイル名称 */
	public static String JSON_TITLE_NAME = "ファイル名称";

	/** フォルダ選択ボタン*/
	public static String BUTTON_FOLD_SELECT = "フォルダ選択 ";
	/** 患者検索*/
	public static String TXT_FIND = "患者検索 ";
	/** 患者検索*/
	public static String BUTTON_FIND = "検索";
	/** 保存*/
	public static String BUTTON_SAVE = "保存";
	/** 送信*/
	public static String BUTTON_SEND = "送    信";
	/** キャンセル*/
	public static String BUTTON_CANEL = "キャンセル";
	public static String BUTTON_CONFIG = "確認";
	/** 削除*/
	public static String BUTTON_DELETE = "削    除";
	/** 備考*/
	public static String TEXTARIA_BIKOU = "備考:";
	/** タイトル*/
	public static String LABEL_TITLE = "タイトル:";
	/** 分類*/
	public static String LABEL_BUNRUI = "分類:";
	/** ステータスバー状況 */
	public static String STATUSBAR_TITLE_STATAS = "  状況: ";

	public static String BUTTON_ID_SAVE = "savebtn";
	public static String BUTTON_ID_SEARCH = "searchbtn";
	public static String BUTTON_ID_PLAY = "playbtn";
	public static String BUTTON_ID_PAUSE ="pausebtn";
	public static String BUTTON_ID_STOP ="stopbtn";
	public static String BUTTON_ID_REPEAT = "repeatbtn";

	public static BorderPane topPane = new BorderPane();
	public static BorderPane bottomPane = new BorderPane();
	public static BorderPane rightBottomPane = new BorderPane();

	public static String FAILED_TO_CREATE_SERVICE = "Failed to create service";
	public static String COULD_NOT_SEND_MESSAGE = "Could not send Message";
	public static String ERROR_WRITING_REQUEST_BODY_TO_SERVE = "Error writing request body to serve";


	// サブぺネル
	Pane paneSub1 = new Pane();
	Pane paneSub2 = new Pane();
	Pane paneSub3 = new Pane();
	// メインぺネル
	public static Pane paneMain = new Pane();

	public static String SYSTEM_PATH = System.getProperty("user.dir").replace("\\", "/");
	public static String folderJson  = SYSTEM_PATH + "/conf/folder.json";
	public static String imgFilePath = SYSTEM_PATH + "/img/";
	public static String logFilePath = SYSTEM_PATH + "/conf/logging.properties";
	public static String jsonFolder  = SYSTEM_PATH + "/data/";
	public static String verFilePath = SYSTEM_PATH + "/conf/Version.ini";
    public static String proFilePath = SYSTEM_PATH + "/conf/system.ini";
    public static String pdfFilePath = SYSTEM_PATH + "/conf/Manual.pdf";
    public static String tmpPath     = SYSTEM_PATH + "/tmp/";
    public static String mp4Path     = SYSTEM_PATH + "/tmp/mp4/";
    public static String moviImgPath = SYSTEM_PATH + "/movi_img/";
   public static String lockPath    = SYSTEM_PATH + "/conf/filelock.lock";
    public static String csskPath    = SYSTEM_PATH + "css/style.css";

	/** "確認メッセージタイトル */
	public static String CONFIRMATION_DIALOG_TITLE = "確認メッセージ";
	/** "エラーメッセージタイトル */
	public static String ERROR_DIALOG_TITLE = "エラーメッセージ";

	/** ウィンドウズ幅*/
	public static final double WINDOWS_WHITH = 1100;
	/** ウィンドウズ高さ*/
	public static final double WINDOWS_HEIGHT = 600;
	public static final int SPLASH_WIDTH = 405;
	public static final int SPLASH_HEIGHT = 320;

	public final static String FONT_NAME = "ＭＳ Ｐゴシック";
    public final static String  FONT_BOLD = "bold";
    public final static String  FONT_NORMAL = "normal";

    public final static int FONT_BOLD_STYLE = 1;

    // public final static int LFC_FONT_BOLD_STYLE = 0;
    public final static int FONT_NORM_SIZE = 15;
    public final static int FONT_LIST_SIZE = 12;
    public final static int FONT_TITLE_SIZE = 16;

    // 分割サイズ(20Mbyte)
    public final static long SPLITE_SIZE = 1024 * 30;

	/** 動画サブぺネル１*/
    public final static int MOVI_PANE1 = 0;
	/** 動画サブぺネル２*/
    public final static int MOVI_PANE2 = 1;
	/** 動画サブぺネル３*/
    public final static int MOVI_PANE3 = 2;
	/** 動画メインぺネル*/
    public final static int MOVI_MAIN_PANE = 3;

	/** 送信ボタン*/
    public final static int SEND_ACTION = 0;
	/** 削除ボタン*/
    public final static int DELETE_ACTION = 1;
	/** ファイルリスト選択*/
    public final static int FILE_LIST_SELECT_ACTION = 2;
	/** すべて*/
    public final static int ALL_ACTION = 3;

	/** 送信結果*/
    public final static String MsgOK = "ok";

	/** 動画再生時間(ミリ秒)*/
	public static final double MOVI_RUNTIME = 5000;
	/** 動画スリーブ時間(ミリ秒)*/
	public static final long MOVI_SLEEP = 1000;

	/** 動画設定スリーブ時間(ミリ秒)*/
	public static final long MOVI_SETTING_SLEEP = 100;
	// 一桁のｽﾍﾟｰｽ
	public final static String ONE_SPACE = " ";
	public final static String SYSTEM_NAME = "動画管理システム";

	/** 備考欄最大入力文字数 */
	public  final static int BIKOIU_MAX_LENGTH = 200;

	// DateﾀｲﾌﾟYYYY/MM/DD
	public final static String DATE_TYPE_YYYY_MM_DD = "yyyy/MM/dd";
	// DateﾀｲﾌﾟYYYY/MM
	public final static String DATE_TYPE_YYYY_MM = "yyyy/MM";
	// DateﾀｲﾌﾟHH:MM
	public final static String DATE_TYPE_HH_MM = "HH:mm";
	// Dateﾀｲﾌﾟ"YYYY/MM/DD HH:MM:SS"
	public final static String DATE_TYPE_YYYY_MM_DD_HH_MM = "yyyy/MM/dd HH:mm:ss";
	// Dateﾀｲﾌﾟ"HH:MM:SS"
	public final static String DATE_TYPE_HH_MM_SS = "HH:mm:ss";

	public final static String PICKER_STYLE = "-fx-font-size: " + FONT_LIST_SIZE + "; -fx-font-weight: " + FONT_BOLD;
	public final static String LBL_STYLE = "-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_BOLD;
	public final static String BUTTON_STYLE = "-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_BOLD;
	public final static String RUNTITLE_STYLE = "-fx-font-size: 18; -fx-font-weight: " + FONT_BOLD;
	public final static String SPLASH_STYLE ="-fx-padding: 5; " +
									            "-fx-background-color: cornsilk; " +
									            "-fx-border-width:5; " +
									            "-fx-border-color: " +
									                "linear-gradient(" +
									                    "to bottom, " +
									                    "chocolate, " +
									                    "derive(chocolate, 50%)" +
									                ");";

	public final static String THUMBNAIL_PANE = "-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);";
	public final static String THROW_INFO = "例外のスローを捕捉:";
}
