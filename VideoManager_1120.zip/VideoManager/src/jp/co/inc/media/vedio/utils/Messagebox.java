package jp.co.inc.media.vedio.utils;

import java.util.Optional;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Bounds;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import javafx.stage.Window;
import jp.co.inc.media.vedio.common.BasConst;
import jp.co.inc.media.vedio.common.MessageConst;

public class Messagebox implements BasConst,MessageConst {

	public static void Error(String errMsg) {
		Alert alrt = new Alert(AlertType.ERROR);
		alrt.setTitle(ERROR_DIALOG_TITLE);
		alrt.setHeaderText(null);
		alrt.setContentText(errMsg);
		Optional<ButtonType> result = alrt.showAndWait();
		if (result.get() == ButtonType.OK) {
		}
	}

	public static void Info(String errMsg) {
		Alert alrt = new Alert(AlertType.INFORMATION);
		alrt.setTitle(ERROR_DIALOG_TITLE);
		alrt.setHeaderText(null);
		alrt.setContentText(errMsg);
		Optional<ButtonType> result = alrt.showAndWait();
		if (result.get() == ButtonType.OK) {
		}
	}

	public static Optional<ButtonType> Confirmation(String errMsg) {
		Alert alrt = new Alert(AlertType.CONFIRMATION);
		alrt.setTitle(CONFIRMATION_DIALOG_TITLE);
		alrt.setHeaderText(null);
		alrt.setContentText(errMsg);
		Optional<ButtonType> result = alrt.showAndWait();
		return result;
	}

	public static void Info(Stage parentStage, String infoMsg) {
		Alert dialog = new Alert(AlertType.INFORMATION, infoMsg, new ButtonType[] {
				new ButtonType("確認", ButtonData.OK_DONE) });
		Window owner = parentStage;
		dialog.getDialogPane().layoutBoundsProperty().addListener(
				new ChangeListener<Bounds>() {
					@Override
					public void changed(ObservableValue<? extends Bounds> observable,
							Bounds oldValue, Bounds newValue) {
						if (newValue != null &&
								newValue.getWidth() > 0 && newValue.getHeight() > 0) {
							double x = owner.getX() + owner.getWidth() / 2;
							double y = owner.getY() + owner.getHeight() / 2;
							dialog.setX(x - newValue.getWidth() / 2);
							dialog.setY(y - newValue.getHeight() / 2);
							dialog.getDialogPane()
									.layoutBoundsProperty().removeListener(this);
						}
					}
				});
		dialog.showAndWait();
	}
}
