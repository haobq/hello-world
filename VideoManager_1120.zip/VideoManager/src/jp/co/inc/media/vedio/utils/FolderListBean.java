package jp.co.inc.media.vedio.utils;
/**
 * 格納動画ファイルフォルダと動画ファイルJSON管理クラス
 */
public class FolderListBean {
	String folderPath ="";
	String jsonfilePath = "";

	public FolderListBean(){
		 folderPath ="";
		 jsonfilePath = "";
	}
	public String getFolderPath() {
		return folderPath;
	}
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}
	public String getJsonfilePath() {
		return jsonfilePath;
	}
	public void setJsonfilePath(String jsonfilePath) {
		this.jsonfilePath = jsonfilePath;
	}
}

