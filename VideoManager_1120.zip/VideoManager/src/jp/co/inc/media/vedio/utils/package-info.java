/**
 * @author isss_hao
 *
 */
package jp.co.inc.media.vedio.utils;