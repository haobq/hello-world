
package jp.co.inc.media.vedio.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;DeleteRequest complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="DeleteRequest"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="Certification" type="{http://vedio.media.inc.co.jp/service}Certification" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Patient_id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *         &amp;lt;element name="Movie_index" type="{http://www.w3.org/2001/XMLSchema}int"/&amp;gt;
 *         &amp;lt;element name="Movie_date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeleteRequest", propOrder = {
    "certification",
    "patientId",
    "movieIndex",
    "movieDate"
})
public class DeleteRequest {

    @XmlElement(name = "Certification")
    protected Certification certification;
    @XmlElement(name = "Patient_id")
    protected String patientId;
    @XmlElement(name = "Movie_index")
    protected int movieIndex;
    @XmlElement(name = "Movie_date")
    protected String movieDate;

    /**
     * certificationプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Certification }
     *     
     */
    public Certification getCertification() {
        return certification;
    }

    /**
     * certificationプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Certification }
     *     
     */
    public void setCertification(Certification value) {
        this.certification = value;
    }

    /**
     * patientIdプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientId() {
        return patientId;
    }

    /**
     * patientIdプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientId(String value) {
        this.patientId = value;
    }

    /**
     * movieIndexプロパティの値を取得します。
     * 
     */
    public int getMovieIndex() {
        return movieIndex;
    }

    /**
     * movieIndexプロパティの値を設定します。
     * 
     */
    public void setMovieIndex(int value) {
        this.movieIndex = value;
    }

    /**
     * movieDateプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMovieDate() {
        return movieDate;
    }

    /**
     * movieDateプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMovieDate(String value) {
        this.movieDate = value;
    }

}
