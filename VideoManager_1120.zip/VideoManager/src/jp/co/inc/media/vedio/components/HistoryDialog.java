package jp.co.inc.media.vedio.components;

import java.util.List;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import jp.co.inc.media.vedio.common.BasConst;
import jp.co.inc.media.vedio.common.BasDialog;
import jp.co.inc.media.vedio.common.BasImage;
import jp.co.inc.media.vedio.common.MessageConst;
import jp.co.inc.media.vedio.utils.FileInfoBean;
import jp.co.inc.media.vedio.utils.FolderManager;
import jp.co.inc.media.vedio.utils.JsonListBean;

/**
 * 送信履歴管理のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class HistoryDialog extends BasDialog implements BasConst, MessageConst {
	private List<FileInfoBean> fileInfolist;
	private StackPane paneFileDetail = new StackPane();
	private static final Image imageNew = new BasImage("unreg.png").getImage();
	private static final Image imageWorking = new BasImage("loading.png").getImage();
	private static final Image imageFinish = new BasImage("finish.png").getImage();
	/**
	 * 動画管理用JSONファイルリスト
	 *
	 * @param fileListPane 親パネル名
	 * @param jsonfileList JSONファイルリスト
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void setJsonFileList(List<JsonListBean> jsonfileList, Pane fileListPane) {

		fileListPane.getChildren().clear();
		TableView<JsonListBean> jsonFileTable = new TableView<>();
		ObservableList<JsonListBean> observableList = FXCollections.observableList(jsonfileList);

		TableColumn<JsonListBean, String> fileStatusColumn = new TableColumn<>(JSON_TITLE_STATAS);
		fileStatusColumn.setCellValueFactory(new PropertyValueFactory("status"));

		TableColumn<JsonListBean, String> fileNameColumn = new TableColumn<>(JSON_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory("fileName"));

		jsonFileTable.getColumns().setAll(fileStatusColumn, fileNameColumn);
		jsonFileTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		jsonFileTable.setItems(observableList);
		jsonFileTable.sort();
		fileListPane.getChildren().add(jsonFileTable);

		//選択状態を検知するバインディングの設定
		jsonFileTable_addListener(jsonFileTable, observableList);

	}

	/**
	 * 動画管理用JSONファイル詳細
	 *
	 * @param jsonfileDetail JSONファイル詳細
	 */
	@SuppressWarnings("unchecked")
	private void setJsonFileDetail(List<FileInfoBean> jsonfileDetail) {

		paneFileDetail.getChildren().clear();
		TableView<FileInfoBean> jsonDetailTable = new TableView<>();
		ObservableList<FileInfoBean> observableDetail = FXCollections.observableList(jsonfileDetail);

		final TableColumn<FileInfoBean, Label> fileStatusColumn = new TableColumn<FileInfoBean, Label>(
				FILE_TITLE_STATAS);
		fileStatusColumn.setMaxWidth(45);
		fileStatusColumn.setMinWidth(45);
		final TableColumn<FileInfoBean, String> fileNameColumn = new TableColumn<>(FILE_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory<>("fileName"));
		fileNameColumn.setMaxWidth(200);
		fileNameColumn.setMinWidth(200);
		final TableColumn<FileInfoBean, String> lastedUpdateColumn = new TableColumn<>(FILE_TITLE_LASTED_UPDATE);
		lastedUpdateColumn.setCellValueFactory(new PropertyValueFactory<>("updateDate"));
		lastedUpdateColumn.setMaxWidth(120);
		lastedUpdateColumn.setMinWidth(120);
		final TableColumn<FileInfoBean, String> fileSizeColumn = new TableColumn<>(FILE_TITLE_SIZE);
		fileSizeColumn.setCellValueFactory(new PropertyValueFactory<>("fileSize"));
		fileSizeColumn.setMaxWidth(100);
		fileSizeColumn.setMinWidth(100);
		fileSizeColumn.setStyle("-fx-alignment: CENTER-RIGHT;");
		final TableColumn<FileInfoBean, String> patient_idColumn = new TableColumn<>(FILE_TITLE_PATIENT_ID);
		patient_idColumn.setCellValueFactory(new PropertyValueFactory<>("patient_id"));
		patient_idColumn.setMaxWidth(100);
		patient_idColumn.setMinWidth(100);
		final TableColumn<FileInfoBean, String> movie_send_timeColumn = new TableColumn<>(FILE_TITLE_MOVIE_SEND_TIME);
		movie_send_timeColumn.setCellValueFactory(new PropertyValueFactory<>("movie_send_time"));
		movie_send_timeColumn.setMaxWidth(120);
		movie_send_timeColumn.setMinWidth(120);

		final TableColumn<FileInfoBean, String> fileUploadFileNameColumn = new TableColumn<>(
				FILE_TITLE_UPLOAD_FILE_NAME);
		fileUploadFileNameColumn.setCellValueFactory(new PropertyValueFactory<>("uploadFileName"));
		fileUploadFileNameColumn.setMaxWidth(170);
		fileUploadFileNameColumn.setMinWidth(170);

		final TableColumn<FileInfoBean, String> fileBikouColumn = new TableColumn<>(FILE_TITLE_BIKOU);
		fileBikouColumn.setCellValueFactory(new PropertyValueFactory<>("bikou"));

		jsonDetailTable.getColumns().setAll(fileStatusColumn, fileNameColumn, lastedUpdateColumn, fileSizeColumn,
				patient_idColumn, movie_send_timeColumn, fileUploadFileNameColumn, fileBikouColumn);
		jsonDetailTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		jsonDetailTable.setItems(observableDetail);

		// sort
		jsonDetailTable.sort();
		paneFileDetail.getChildren().add(jsonDetailTable);

		/** ファイルリストクリックイベント処理 */
		setCellValueFactory_his(fileStatusColumn);


	}


	/**
	 * 動画管理用JSONファイルリスト選択時、詳細情報を取得
	 *
	 * @param jsonFileTable 動画管理用JSONファイルリストTABLE
	 * @param fileList 動画管理用JSONファイルリスト
	 */
	private void jsonFileTable_addListener(TableView<JsonListBean> jsonFileTable,
			ObservableList<JsonListBean> fileList) {
		jsonFileTable.getSelectionModel().selectedItemProperty().addListener((ov, old, current) -> {
			String workingDirJson = jsonFolder + current.getFileName();
			try {
				fileInfolist = FolderManager.getJsonInfoBean(workingDirJson);
				setJsonFileDetail(fileInfolist);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * 送信履歴管理画面
	 *
	 * @param owner 親パネル名
	 * @param title 画面名
	 * @param width 画面幅
	 * @param height 画面高
	 */
	public HistoryDialog(Stage owner, String title, int width, int height) {
		super(owner, title, width, height);

		BorderPane listPane = new BorderPane();
		BorderPane topPane = new BorderPane();

		setResizable(true);

		listPane.prefWidthProperty().bind(owner.getScene().widthProperty());
		listPane.prefHeightProperty().bind(owner.getScene().heightProperty());

		HBox hvBoxNote = new HBox();
		Label labFileListTitle = new Label("送信ファイルリスト");
		labFileListTitle.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_BOLD);
		labFileListTitle.setAlignment(Pos.BOTTOM_LEFT);
		hvBoxNote.setAlignment(Pos.BASELINE_LEFT);
		hvBoxNote.setSpacing(20);
		hvBoxNote.getChildren().addAll(labFileListTitle);
		topPane.setTop(hvBoxNote);

		StackPane paneFileList = new StackPane();

		//JSONファイル一覧
		List<JsonListBean> fileList = FolderManager.getJsonListBean(jsonFolder);
		setJsonFileList(fileList, paneFileList);
		topPane.setCenter(paneFileList);

		BorderPane bottomPane = new BorderPane();
		HBox detailBoxNote = new HBox();
		Label labFileDetail = new Label("送信ファイル詳細");
		labFileDetail.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_BOLD);
		labFileDetail.setAlignment(Pos.BOTTOM_LEFT);
		detailBoxNote.setAlignment(Pos.BASELINE_LEFT);
		detailBoxNote.setSpacing(20);
		detailBoxNote.getChildren().addAll(labFileDetail);

		bottomPane.setTop(detailBoxNote);
		bottomPane.setCenter(paneFileDetail);

		SplitPane verticalPane = new SplitPane();
		verticalPane.setOrientation(Orientation.VERTICAL);
		verticalPane.getItems().addAll(topPane, bottomPane);

		//Javafx splitpane 分割 固定
		double posRootLeft[] = { 0.40f, 1.0f };
		verticalPane.setDividerPositions(posRootLeft);
		for (int i = 0; i < verticalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = verticalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootLeft[ind]);
				}
			});
		}

		listPane.setCenter(verticalPane);

		root.getChildren().add(listPane);

		listPane.prefWidthProperty().bind(root.getScene().widthProperty());
		listPane.prefHeightProperty().bind(root.getScene().heightProperty());


	}


	/**
	 * セールファクトリー
	 * @param fileStatusColumn
	 */
	private static void setCellValueFactory_his(TableColumn<FileInfoBean, Label> fileStatusColumn) {
		fileStatusColumn.setCellValueFactory(
			new Callback<TableColumn.CellDataFeatures<FileInfoBean, Label>, ObservableValue<Label>>() {
				@Override
				public ObservableValue<Label> call(TableColumn.CellDataFeatures<FileInfoBean, Label> arg0) {
					FileInfoBean data = arg0.getValue();
					final Label label = new Label();
					label.setTextFill(Color.RED);

					label.setBackground(new Background(
							new BackgroundFill(Color.BLUEVIOLET, new CornerRadii(10), new Insets(5))));
					label.setPrefSize(10, 10);

					if (data.getStatus().equals(Status.STATUS_NEW)) {
						ImageView img = new ImageView(imageNew);
						img.setFitWidth(30);
						img.setFitHeight(30);
						label.setGraphic(img);

					} else if (data.getStatus().equals(Status.STATUS_WORKING)) {
						ImageView img = new ImageView(imageWorking);
						img.setFitWidth(30);
						img.setFitHeight(30);
						label.setGraphic(img);

					} else if (data.getStatus().equals(Status.STATUS_COMPLETED)) {
						ImageView img = new ImageView(imageFinish);
						img.setFitWidth(30);
						img.setFitHeight(30);
						label.setGraphic(img);
					}

					return new SimpleObjectProperty<Label>(label);
				}

			});
	}



}
