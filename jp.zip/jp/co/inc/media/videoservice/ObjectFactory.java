
package jp.co.inc.media.videoservice;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the jp.co.inc.media.videoservice package. 
 * &lt;p&gt;An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: jp.co.inc.media.videoservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SearchPatient }
     * 
     */
    public SearchPatient createSearchPatient() {
        return new SearchPatient();
    }

    /**
     * Create an instance of {@link PatientRequest }
     * 
     */
    public PatientRequest createPatientRequest() {
        return new PatientRequest();
    }

    /**
     * Create an instance of {@link SearchPatientResponse }
     * 
     */
    public SearchPatientResponse createSearchPatientResponse() {
        return new SearchPatientResponse();
    }

    /**
     * Create an instance of {@link ArrayOfPatientResponse }
     * 
     */
    public ArrayOfPatientResponse createArrayOfPatientResponse() {
        return new ArrayOfPatientResponse();
    }

    /**
     * Create an instance of {@link GetFolderSize }
     * 
     */
    public GetFolderSize createGetFolderSize() {
        return new GetFolderSize();
    }

    /**
     * Create an instance of {@link Certification }
     * 
     */
    public Certification createCertification() {
        return new Certification();
    }

    /**
     * Create an instance of {@link GetFolderSizeResponse }
     * 
     */
    public GetFolderSizeResponse createGetFolderSizeResponse() {
        return new GetFolderSizeResponse();
    }

    /**
     * Create an instance of {@link FolderSizeReponse }
     * 
     */
    public FolderSizeReponse createFolderSizeReponse() {
        return new FolderSizeReponse();
    }

    /**
     * Create an instance of {@link GetHospList }
     * 
     */
    public GetHospList createGetHospList() {
        return new GetHospList();
    }

    /**
     * Create an instance of {@link GetHospListResponse }
     * 
     */
    public GetHospListResponse createGetHospListResponse() {
        return new GetHospListResponse();
    }

    /**
     * Create an instance of {@link ArrayOfClinicReponse }
     * 
     */
    public ArrayOfClinicReponse createArrayOfClinicReponse() {
        return new ArrayOfClinicReponse();
    }

    /**
     * Create an instance of {@link GetFacilityList }
     * 
     */
    public GetFacilityList createGetFacilityList() {
        return new GetFacilityList();
    }

    /**
     * Create an instance of {@link GetFacilityListResponse }
     * 
     */
    public GetFacilityListResponse createGetFacilityListResponse() {
        return new GetFacilityListResponse();
    }

    /**
     * Create an instance of {@link ArrayOfFacilityReponse }
     * 
     */
    public ArrayOfFacilityReponse createArrayOfFacilityReponse() {
        return new ArrayOfFacilityReponse();
    }

    /**
     * Create an instance of {@link MediaUpload }
     * 
     */
    public MediaUpload createMediaUpload() {
        return new MediaUpload();
    }

    /**
     * Create an instance of {@link ArrayOfMovieRequest }
     * 
     */
    public ArrayOfMovieRequest createArrayOfMovieRequest() {
        return new ArrayOfMovieRequest();
    }

    /**
     * Create an instance of {@link MediaUploadResponse }
     * 
     */
    public MediaUploadResponse createMediaUploadResponse() {
        return new MediaUploadResponse();
    }

    /**
     * Create an instance of {@link ArrayOfMovieReponse }
     * 
     */
    public ArrayOfMovieReponse createArrayOfMovieReponse() {
        return new ArrayOfMovieReponse();
    }

    /**
     * Create an instance of {@link PatientResponse }
     * 
     */
    public PatientResponse createPatientResponse() {
        return new PatientResponse();
    }

    /**
     * Create an instance of {@link ClinicReponse }
     * 
     */
    public ClinicReponse createClinicReponse() {
        return new ClinicReponse();
    }

    /**
     * Create an instance of {@link FacilityReponse }
     * 
     */
    public FacilityReponse createFacilityReponse() {
        return new FacilityReponse();
    }

    /**
     * Create an instance of {@link MovieRequest }
     * 
     */
    public MovieRequest createMovieRequest() {
        return new MovieRequest();
    }

    /**
     * Create an instance of {@link ArrayOfString }
     * 
     */
    public ArrayOfString createArrayOfString() {
        return new ArrayOfString();
    }

    /**
     * Create an instance of {@link MovieReponse }
     * 
     */
    public MovieReponse createMovieReponse() {
        return new MovieReponse();
    }

    /**
     * Create an instance of {@link ArrayOfBoolean }
     * 
     */
    public ArrayOfBoolean createArrayOfBoolean() {
        return new ArrayOfBoolean();
    }

}
