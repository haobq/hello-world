@javax.xml.bind.annotation.XmlSchema(namespace = "http://media.inc.co.jp/videoservice", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package jp.co.inc.media.videoservice;
