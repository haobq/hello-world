
package jp.co.inc.media.videoservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;FolderSizeReponse complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="FolderSizeReponse"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="Contract_size" type="{http://www.w3.org/2001/XMLSchema}long"/&amp;gt;
 *         &amp;lt;element name="Used_size" type="{http://www.w3.org/2001/XMLSchema}long"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FolderSizeReponse", propOrder = {
    "contractSize",
    "usedSize"
})
public class FolderSizeReponse {

    @XmlElement(name = "Contract_size")
    protected long contractSize;
    @XmlElement(name = "Used_size")
    protected long usedSize;

    /**
     * contractSizeプロパティの値を取得します。
     * 
     */
    public long getContractSize() {
        return contractSize;
    }

    /**
     * contractSizeプロパティの値を設定します。
     * 
     */
    public void setContractSize(long value) {
        this.contractSize = value;
    }

    /**
     * usedSizeプロパティの値を取得します。
     * 
     */
    public long getUsedSize() {
        return usedSize;
    }

    /**
     * usedSizeプロパティの値を設定します。
     * 
     */
    public void setUsedSize(long value) {
        this.usedSize = value;
    }

}
