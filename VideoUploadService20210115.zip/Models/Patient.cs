﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class Patient
    {
        //グループID
        public string Group_id { get; set; }
        //医院ID
        public string Hosp_id { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //患者名
        public string Patient_name { get; set; }
        //患者名カナ　
        public string Patient_kana { get; set; }
        //生年月日　例："大正15年12月11日"
        public string Patient_birthday { get; set; }
        //性別　例："F"
        public string Patient_sex { get; set; }
        //訪問日 例："2000-01-01"
        public string Visit_date { get; set; }
        //訪問先名
        public string Visit_name { get; set; }
        //キー項目
        public string Unique_id { get; set; }
    }
}