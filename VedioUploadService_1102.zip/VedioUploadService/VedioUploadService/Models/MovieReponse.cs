﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class MovieReponse
    {
        //認証情報
        public Certification Certification { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //UserID
        public string User_id { get; set; }
        //アップロード動画ファイル名
        public List<string> Upload_movie_name { get; set; }
        //アップロード結果
        public List<Boolean> Upload_result { get; set; }
    }
}