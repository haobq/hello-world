using System;
using System.IO;
using System.Web.UI.WebControls;
using VideoUploadService.Models;
using VideoUploadService.Models.Common;

namespace VideoUploadService
{
    public partial class Download : System.Web.UI.Page
    {
        readonly String basePath = System.Configuration.ConfigurationManager.AppSettings["DownloadFolder"].ToString();
        private static string winPackageRecognizer = ".msi";
        private static string macPackageRecognizer = ".dmg";
        private static string macManualRecognizer = "mac";
        private static string winManualRecognizer = "win";
        private static string packagePath = "Package";
        private static string instalManualPath = "Manual/install";
        private static string updateManualPath = "Manual/update";

        //パッケージファイル
        string packageFilePath;
        //マニュアルファイル
        private string installManualFilePath;
        private string updateManualFilePath;
        private string thTitleFileName;

        protected void Page_Load(object sender, EventArgs e)
        {
            String osInfo = Request.UserAgent.ToLower();
            thTitleFileName = "ファイル名";

            if (osInfo.IndexOf("windows nt") != -1)
            {
                GetVersionInfo(winPackageRecognizer, winManualRecognizer);
            }
            else if (osInfo.IndexOf("mac os") != -1)
            {
                GetVersionInfo(macPackageRecognizer, macManualRecognizer);
            }
            else
            {
                Label1.Text = "適用なパッケージがありません。";
            }
        }

        /// <summary>
        /// ファイル情報取得
        /// </summary>
        /// <param name="packageRecognizer"></param>
        /// <param name="manualRecognizer"></param>
        private void GetVersionInfo(string packageRecognizer, string manualRecognizer)
        {
            //パッケージ
            VersionInfo packageInfo = Tools.FileInfoGet(basePath + @packagePath, packageRecognizer);
            packageFilePath = packageInfo.FilePath;
            if (!string.IsNullOrEmpty(packageFilePath))
            {
                thTitleFileName = "パッケージ名";
                _ = packageTable.Rows.Add(DrawTableHeader());
                _ = packageTable.Rows.Add(DrawTableRow(packageInfo, Package_Click));
            }
            else
            {
                Label1.Text = "適用なパッケージがありません。";
            }
            //更新手順書
            VersionInfo updateManualInfo = new VersionInfo();
            if (Directory.Exists(basePath + @updateManualPath))
            {
                updateManualInfo = Tools.FileInfoGet(basePath + @updateManualPath, manualRecognizer);
                updateManualFilePath = updateManualInfo.FilePath;
            }

            //インストール手順書
            VersionInfo installManualInfo = new VersionInfo();
            if (Directory.Exists(basePath + @instalManualPath))
            {
                installManualInfo = Tools.FileInfoGet(basePath + @instalManualPath, manualRecognizer);
                installManualFilePath = installManualInfo.FilePath;
            }

            if (!string.IsNullOrEmpty(installManualFilePath) && !string.IsNullOrEmpty(updateManualFilePath))
            {
                thTitleFileName = "手順書";
                _ = manualTable.Rows.Add(DrawTableHeader());
                _ = manualTable.Rows.Add(DrawTableRow(installManualInfo, InstallManual_Click));
                _ = manualTable.Rows.Add(DrawTableRow(updateManualInfo, UpdateManual_Click));
            }
            else if(!string.IsNullOrEmpty(installManualFilePath) && string.IsNullOrEmpty(updateManualFilePath))
            {
                thTitleFileName = "インストール手順書";
                _ = manualTable.Rows.Add(DrawTableHeader());
                _ = manualTable.Rows.Add(DrawTableRow(installManualInfo, InstallManual_Click));
            }
            else if (string.IsNullOrEmpty(installManualFilePath) && !string.IsNullOrEmpty(updateManualFilePath))
            {
                thTitleFileName = "バージョンアップ手順書";
                _ = manualTable.Rows.Add(DrawTableHeader());
                _ = manualTable.Rows.Add(DrawTableRow(updateManualInfo, UpdateManual_Click));
            }
            else
            {
                Label1.Text += " 適用な手順書がありません。";
            }
        }

        /// <summary>
        /// 表のタイトル作成
        /// </summary>
        /// <returns></returns>
        private TableHeaderRow DrawTableHeader()
        {
            TableHeaderRow headerRow = new TableHeaderRow();
            TableHeaderCell headerCell;
            headerCell = new TableHeaderCell();
            headerCell.Text = thTitleFileName;
            headerCell.Width = Unit.Pixel(450);
            headerRow.Cells.Add(headerCell);

            headerCell = new TableHeaderCell();
            headerCell.Text = "バージョン";
            headerCell.Width = Unit.Pixel(150);
            headerRow.Cells.Add(headerCell);

            headerCell = new TableHeaderCell();
            headerCell.Text = "更新日付";
            headerCell.Width = Unit.Pixel(150);
            headerRow.Cells.Add(headerCell);

            return headerRow;
        }

        /// <summary>
        /// 表の行作成
        /// </summary>
        /// <param name="fileInfo"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        private TableRow DrawTableRow(VersionInfo fileInfo, EventHandler handler)
        {
            TableRow row = new TableRow();

            TableCell cell = new TableCell();
            LinkButton linkButton = new LinkButton();
            linkButton.Text = Path.GetFileName(fileInfo.FilePath);
            linkButton.Click += handler;
            //ファイル名
            cell.Controls.Add(linkButton);
            row.Cells.Add(cell);

            //ファイルバージョン
            cell = new TableCell();
            cell.Text = fileInfo.VerNo;
            row.Cells.Add(cell);

            //日付
            cell = new TableCell();
            cell.Text = Tools.FomatDate(fileInfo.LastUpdateDate);
            row.Cells.Add(cell);

            return row;
        }

        /// <summary>
        /// パッケージダウンロード
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Package_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"" + Path.GetFileName(packageFilePath) + "\"");
            Response.WriteFile(packageFilePath);
            Response.End();
        }

        /// <summary>
        /// インストール手順書ダウンロード
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void InstallManual_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"" + Path.GetFileName(installManualFilePath) + "\"");
            Response.WriteFile(installManualFilePath);
            Response.End();
        }

        /// <summary>
        /// 更新手順書ダウンロード
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void UpdateManual_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"" + Path.GetFileName(updateManualFilePath) + "\"");
            Response.WriteFile(updateManualFilePath);
            Response.End();
        }

    }
}