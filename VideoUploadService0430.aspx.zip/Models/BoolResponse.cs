﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class BoolResponse
    {
        public bool Ret { get; set; }
        //エラー
        public ErrorResponse Error { get; set; }
    }
}