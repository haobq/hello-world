﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class FacilityResponse
    {
        //訪問先ID
        public List<Facility> Facilities { get; set; }
        //エラー
        public ErrorResponse Error { get; set; }
    }
}