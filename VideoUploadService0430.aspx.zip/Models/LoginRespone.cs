﻿using System.Collections.Generic;
namespace VideoUploadService.Models
{
    public class LoginRespone
    {
        public Certification Cert { get; set; }
        public List<Clinic> ClinicList { get; set; }
        public List<Facility> FacilityList { get; set; }
        public long VideoMaxSize { get; set; }
        public int VideoSplitSize { get; set; }
        //エラー
        public ErrorResponse Error { get; set; }
    }
}