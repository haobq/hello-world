﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class ClinicResponse
    {
        //医院リスト
        public List<Clinic> Clinics  { get; set; }
        //エラー
        public ErrorResponse Error { get; set; }
    }
}