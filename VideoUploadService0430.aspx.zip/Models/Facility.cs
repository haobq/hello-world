﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class Facility
    {
        //訪問先ID
        public string Visit_id { get; set; }
        //訪問先名
        public string Visit_name { get; set; }
        //訪問先区分
        public string Visit_kbn { get; set; }
    }
}