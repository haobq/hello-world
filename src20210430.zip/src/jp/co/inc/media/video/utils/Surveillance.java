package jp.co.inc.media.video.utils;

import javafx.application.Platform;
import javafx.stage.Stage;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasFrame;
import jp.co.inc.media.video.common.MessageConst;
import jp.co.inc.media.video.frame.CallMainFrame;

/**
 * 概要：運用監視のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class Surveillance  implements BasConst, MessageConst {

	private Stage mainStage = null;
	private boolean msgFlg = true;
	public Surveillance(Stage mainStage) {
		this.mainStage = mainStage;
	}
	
	public void CheckCurrTime(String stauts) {
		double prevTime=SysInfoBean.getStartRunTime();
		double currTime = System.currentTimeMillis();
		if ((currTime -prevTime)<RUN_TIME) {
			SysInfoBean.setStartRunTime(currTime);
		} else {
			System.out.println(stauts+"-----1時間超-----"+(currTime -prevTime));
			if (msgFlg) {
				msgFlg =false;
				Messagebox.Error(mainStage,E0029);
				CallMainFrame.logout();
				Platform.exit();
				Thread start = new Thread(new Runnable() {
					@Override
					public void run() {
						// メモリ解放
						BasFrame.clearMemori();

						// 画面閉じる
						System.exit(0);
					}
				});
				start.start();
			}

		}
	}
}
