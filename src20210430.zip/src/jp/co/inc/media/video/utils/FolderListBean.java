package jp.co.inc.media.video.utils;

/**
 * 概要：格納動画ファイルフォルダと動画ファイルJSON管理クラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class FolderListBean {
	/**作業フォルダーパス */
	String folderPath ="";
	/**作業フォルダーのファイル情報の管理 JSONファイルパス*/
	String jsonfilePath = "";
	public FolderListBean() {
		folderPath = "";
		jsonfilePath = "";
	}

	/**
	 * 作業フォルダーパスを取得する
	 * @return 作業フォルダーパス
	 */
	public String getFolderPath() {
		return folderPath;
	}

	/**
	 * 作業フォルダーパスを設定する
	 * @param folderPath 作業フォルダーパス
	 */
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	/**
	 * 作業フォルダーのファイル情報の管理 JSONファイルパスを取得する
	 * @return 管理 JSONファイルパス
	 */
	public String getJsonfilePath() {
		return jsonfilePath;
	}

	/**
	 * 作業フォルダーのファイル情報の管理 JSONファイルパスを設定する
	 * @param jsonfilePath 管理 JSONファイルパス
	 */
	public void setJsonfilePath(String jsonfilePath) {
		this.jsonfilePath = jsonfilePath;
	}

}

