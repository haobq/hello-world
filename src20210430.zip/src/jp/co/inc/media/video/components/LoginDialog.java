package jp.co.inc.media.video.components;

import java.awt.Robot;
import java.net.ConnectException;
import java.util.logging.Level;

import javax.xml.ws.WebServiceException;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jp.co.inc.media.video.common.BasButton;
import jp.co.inc.media.video.common.BasDialog;
import jp.co.inc.media.video.common.BasFrame;
import jp.co.inc.media.video.frame.CallMainFrame;
import jp.co.inc.media.video.logic.VideoUploadServiceLogic;
import jp.co.inc.media.video.service.LoginRespone;
import jp.co.inc.media.video.utils.FileProperty;
import jp.co.inc.media.video.utils.Messagebox;
import jp.co.inc.media.video.utils.OSDetector;
import jp.co.inc.media.video.utils.PasswordUtil;
import jp.co.inc.media.video.utils.SysInfoBean;

/**
 * 概要：ログイン画面のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class LoginDialog extends BasDialog {

	private static CheckBox checkFld = new CheckBox();
	private static FileProperty filePro;
	private static TextField groupIdFld = new TextField();
	private static TextField userNameFld = new TextField();
	private static PasswordField passwordFld = new PasswordField();
	public static Stage mainStage;

	public LoginDialog(BasFrame callBaseFrm, Stage owner, String title, int width, int height) throws Exception {
		super(owner, title, width, height);
		initStyle(StageStyle.UTILITY);
		filePro = new FileProperty(proFilePath);
		BorderPane loginPane = new BorderPane();
		loginPane.setPrefWidth(width);
		loginPane.setPrefHeight(height);
		GridPane gridpane = new GridPane();
		gridpane.setPadding(new Insets(15));
		gridpane.setHgap(5);
		gridpane.setVgap(5);
		String owned = filePro.getProperty("owned");

		if (OSDetector.isMac()) {
			Label spacedLbl = new Label(" ");
			gridpane.add(spacedLbl, 0, 0);
		}

		if(filePro.getProperty("groupid").isEmpty()) {
			Label groupIdLbl = new Label("グループID: ");
			groupIdLbl.getStyleClass().add("label");
			gridpane.add(groupIdLbl, 0, 1);
			groupIdFld.getStyleClass().add("textfield");
			gridpane.add(groupIdFld, 1, 1);
			groupIdFld.setOnKeyPressed((event) -> {
			    try {
			        Robot eventRobot = new Robot();
			        if (event.getCode().getName() == "Enter") {
			            //エンター押下時
			            eventRobot.keyPress(java.awt.event.KeyEvent.VK_TAB);
			            eventRobot.keyRelease(java.awt.event.KeyEvent.VK_TAB);
			            event.consume();
			        }
			    } catch (Exception e) {
			        e.printStackTrace();
			    }
			});
		}

		Label userNameLbl = new Label("ユーザーID: ");
		//userNameLbl.setStyle(LBL_STYLE);
		userNameLbl.getStyleClass().add("label");
		gridpane.add(userNameLbl, 0, 2);

		Label passwordLbl = new Label("パスワード: ");
		//passwordLbl.setStyle(LBL_STYLE);
		passwordLbl.getStyleClass().add("label");
		gridpane.add(passwordLbl, 0, 3);

	//	userNameFld.setStyle(LBL_STYLE);
		userNameFld.getStyleClass().add("textfield");
		if ("true".equals(owned)) {
			userNameFld.setText(filePro.getProperty("userid"));

		}
		gridpane.add(userNameFld, 1, 2);

	//	passwordFld.setStyle(LBL_STYLE);
		passwordFld.getStyleClass().add("textfield");
		if ("true".equals(owned)) {
			passwordFld.setText(PasswordUtil.decrypt(filePro.getProperty("passwd")));
		}

		gridpane.add(passwordFld, 1, 3);
		checkFld.setPrefWidth(50);

		if ("true".equals(owned)) {
			checkFld.setSelected(true);
		}

		HBox hBox = new HBox();
		Label ownedLbl = new Label("ログイン情報を保存する");
//		ownedLbl.setStyle(LBL_STYLE);
		hBox.getChildren().addAll(checkFld, ownedLbl);
		gridpane.add(hBox, 1, 4);

		HBox hBoxSpace = new HBox();
		Label spacedLbl = new Label("");
		hBoxSpace.getChildren().addAll(spacedLbl);
		gridpane.add(hBoxSpace, 1, 5);

		Button login = new BasButton("config.png", ICON_SIZE, ICON_SIZE, "ログイン");
		login.setStyle(BUTTON_STYLE);
		login.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				login(callBaseFrm, owner);
			}
		});

		userNameFld.setOnKeyPressed((event) -> {
		    try {
		        Robot eventRobot = new Robot();
		        if (event.getCode().getName() == "Enter") {
		            //エンター押下時
		            eventRobot.keyPress(java.awt.event.KeyEvent.VK_TAB);
		            eventRobot.keyRelease(java.awt.event.KeyEvent.VK_TAB);
		            event.consume();
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		});
		passwordFld.setOnKeyPressed((event) -> {
		    try {
		        Robot eventRobot = new Robot();
		        if (event.getCode().getName() == "Enter") {
		            //エンター押下時
		            eventRobot.keyPress(java.awt.event.KeyEvent.VK_TAB);
		            eventRobot.keyRelease(java.awt.event.KeyEvent.VK_TAB);
		            event.consume();
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		});
		checkFld.setOnKeyPressed((event) -> {
		    try {
		        Robot eventRobot = new Robot();
		        if (event.getCode().getName() == "Enter") {
		            //エンター押下時
		            eventRobot.keyPress(java.awt.event.KeyEvent.VK_TAB);
		            eventRobot.keyRelease(java.awt.event.KeyEvent.VK_TAB);
		            event.consume();
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		});
		login.setOnKeyPressed((event) -> {
		    try {
		        if (event.getCode().getName() == "Enter") {
    				login(callBaseFrm, owner);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		});
		gridpane.add(login, 1, 6);
		GridPane.setHalignment(login, HPos.RIGHT);
		loginPane.setCenter(gridpane);
		BorderPane.setAlignment(gridpane, Pos.CENTER);
		root.getChildren().add(loginPane);
	}


	/**
	 * ログイン
	 * @param callBaseFrm BasFrame
	 * @param owner Stage
	 */
	public static void login(BasFrame callBaseFrm, Stage owner) {
		logger.log(Level.INFO, "START -login");

		try {
			FileProperty filePro = new FileProperty(proFilePath);

			// グループID必須チェック
			String groupid;
			if (!groupIdFld.getText().isEmpty()) {
				groupid = groupIdFld.getText();
			}else {
				groupid = filePro.getProperty("groupid");
			}
			if(groupid.isEmpty()) {
				Messagebox.Error(owner, E0012);
				return;
			}

			// ユーザID必須チェック
			if ("".equals(userNameFld.getText())) {
				Messagebox.Error(owner, E0009);
				return;
			}

			// パスワード必須チェック
			if ("".equals(passwordFld.getText())) {
				Messagebox.Error(owner, E0010);
				return;
			}

//			// iniファイルにグループID入力チェック
//			if ("".equals(filePro.getProperty("groupid")) || filePro.getProperty("groupid") == null) {
//				Messagebox.Error(owner, E0012);
//				return;
//			}

			// iniファイルにloginurl入力チェック
			if ("".equals(filePro.getProperty("loginurl")) || filePro.getProperty("loginurl") == null) {
				Messagebox.Error(owner, E0013);
				return;
			}

			// iniファイルにグループID入力チェック
			if ("true".equals(filePro.getProperty("active")) && ("".equals(filePro.getProperty("proxyurl"))
					|| filePro.getProperty("proxyurl") == null)) {
				Messagebox.Error(owner, E0007);
				return;
			}

			// iniファイルにloginurl入力チェック
			if ("true".equals(filePro.getProperty("active")) && ("".equals(filePro.getProperty("proxyport"))
					|| filePro.getProperty("proxyport") == null)) {
				Messagebox.Error(owner, E0008);
				return;
			}

			//ログインサービスを呼び出す
			LoginRespone loginInfo = VideoUploadServiceLogic.LoginManager(callBaseFrm, owner,
					//filePro.getProperty("groupid"),
					groupid,
					userNameFld.getText(), passwordFld.getText());

			if (loginInfo == null || loginInfo.getFacilityList() == null) {
				return;
			}

			// ログイン情報を保存
			SysInfoBean.setLoginInfo(loginInfo);
			// 開始運用時間(ミリ秒）
			SysInfoBean.setStartRunTime(System.currentTimeMillis());
			// ログイン画面非表示
			CallMainFrame.loginDialog.hide();
			// メイン画面呼び出す
			callBaseFrm.start(owner);

		} catch (WebServiceException f) {
			logger.log(Level.SEVERE, THROW_INFO, f);
			f.printStackTrace();
			Messagebox.Error(owner, "E0021",E0021);
		} catch (ConnectException ce) {
			logger.log(Level.SEVERE, THROW_INFO, ce);
			ce.printStackTrace();
			Messagebox.Error(owner, "E0021",E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0001",E0001);
		}


		logger.log(Level.INFO, "END -login");
	}

	/**
	 * iniファイルに書き込む
	 */
	public static void writeIniFile() {
		logger.log(Level.INFO, "START -writeIniFile");

		if (!groupIdFld.getText().isEmpty()) {
			filePro.setProperty("groupid", groupIdFld.getText());
		}

		if (checkFld.isSelected()) {
			filePro.setProperty("owned", "true");
			filePro.setProperty("userid", userNameFld.getText());
			filePro.setProperty("passwd", PasswordUtil.encrypt(passwordFld.getText()));
		} else {
			filePro.setProperty("owned", "false");
			filePro.setProperty("userid", "");
			filePro.setProperty("passwd", "");
		}
		try {
			filePro.storeProperty();
		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.log(Level.INFO, "END -writeIniFile");
	}

}
