@javax.xml.bind.annotation.XmlSchema(namespace = "http://video.media.inc.co.jp/service", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package jp.co.inc.media.video.service;
