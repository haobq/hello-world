
package jp.co.inc.media.video.service;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the jp.co.inc.media.video.service package. 
 * &lt;p&gt;An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: jp.co.inc.media.video.service
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Login }
     * 
     */
    public Login createLogin() {
        return new Login();
    }

    /**
     * Create an instance of {@link LoginResponse }
     * 
     */
    public LoginResponse createLoginResponse() {
        return new LoginResponse();
    }

    /**
     * Create an instance of {@link LoginRespone }
     * 
     */
    public LoginRespone createLoginRespone() {
        return new LoginRespone();
    }

    /**
     * Create an instance of {@link GetVisitList }
     * 
     */
    public GetVisitList createGetVisitList() {
        return new GetVisitList();
    }

    /**
     * Create an instance of {@link Certification }
     * 
     */
    public Certification createCertification() {
        return new Certification();
    }

    /**
     * Create an instance of {@link GetVisitListResponse }
     * 
     */
    public GetVisitListResponse createGetVisitListResponse() {
        return new GetVisitListResponse();
    }

    /**
     * Create an instance of {@link FacilityResponse }
     * 
     */
    public FacilityResponse createFacilityResponse() {
        return new FacilityResponse();
    }

    /**
     * Create an instance of {@link GetMovieList }
     * 
     */
    public GetMovieList createGetMovieList() {
        return new GetMovieList();
    }

    /**
     * Create an instance of {@link GetMovieListResponse }
     * 
     */
    public GetMovieListResponse createGetMovieListResponse() {
        return new GetMovieListResponse();
    }

    /**
     * Create an instance of {@link MovieListResponse }
     * 
     */
    public MovieListResponse createMovieListResponse() {
        return new MovieListResponse();
    }

    /**
     * Create an instance of {@link VideoDelete }
     * 
     */
    public VideoDelete createVideoDelete() {
        return new VideoDelete();
    }

    /**
     * Create an instance of {@link VideoDeleteResponse }
     * 
     */
    public VideoDeleteResponse createVideoDeleteResponse() {
        return new VideoDeleteResponse();
    }

    /**
     * Create an instance of {@link BoolResponse }
     * 
     */
    public BoolResponse createBoolResponse() {
        return new BoolResponse();
    }

    /**
     * Create an instance of {@link VideoUpdate }
     * 
     */
    public VideoUpdate createVideoUpdate() {
        return new VideoUpdate();
    }

    /**
     * Create an instance of {@link VideoUpdateResponse }
     * 
     */
    public VideoUpdateResponse createVideoUpdateResponse() {
        return new VideoUpdateResponse();
    }

    /**
     * Create an instance of {@link ImageUpdate }
     * 
     */
    public ImageUpdate createImageUpdate() {
        return new ImageUpdate();
    }

    /**
     * Create an instance of {@link ImageUpdateResponse }
     * 
     */
    public ImageUpdateResponse createImageUpdateResponse() {
        return new ImageUpdateResponse();
    }

    /**
     * Create an instance of {@link ImageDelete }
     * 
     */
    public ImageDelete createImageDelete() {
        return new ImageDelete();
    }

    /**
     * Create an instance of {@link ImageDeleteResponse }
     * 
     */
    public ImageDeleteResponse createImageDeleteResponse() {
        return new ImageDeleteResponse();
    }

    /**
     * Create an instance of {@link Logout }
     * 
     */
    public Logout createLogout() {
        return new Logout();
    }

    /**
     * Create an instance of {@link LogoutResponse }
     * 
     */
    public LogoutResponse createLogoutResponse() {
        return new LogoutResponse();
    }

    /**
     * Create an instance of {@link SearchPatient }
     * 
     */
    public SearchPatient createSearchPatient() {
        return new SearchPatient();
    }

    /**
     * Create an instance of {@link PatientRequest }
     * 
     */
    public PatientRequest createPatientRequest() {
        return new PatientRequest();
    }

    /**
     * Create an instance of {@link SearchPatientResponse }
     * 
     */
    public SearchPatientResponse createSearchPatientResponse() {
        return new SearchPatientResponse();
    }

    /**
     * Create an instance of {@link PatientResponse }
     * 
     */
    public PatientResponse createPatientResponse() {
        return new PatientResponse();
    }

    /**
     * Create an instance of {@link IsOverCapacity }
     * 
     */
    public IsOverCapacity createIsOverCapacity() {
        return new IsOverCapacity();
    }

    /**
     * Create an instance of {@link IsOverCapacityResponse }
     * 
     */
    public IsOverCapacityResponse createIsOverCapacityResponse() {
        return new IsOverCapacityResponse();
    }

    /**
     * Create an instance of {@link FolderSizeResponse }
     * 
     */
    public FolderSizeResponse createFolderSizeResponse() {
        return new FolderSizeResponse();
    }

    /**
     * Create an instance of {@link GetHospList }
     * 
     */
    public GetHospList createGetHospList() {
        return new GetHospList();
    }

    /**
     * Create an instance of {@link GetHospListResponse }
     * 
     */
    public GetHospListResponse createGetHospListResponse() {
        return new GetHospListResponse();
    }

    /**
     * Create an instance of {@link ClinicResponse }
     * 
     */
    public ClinicResponse createClinicResponse() {
        return new ClinicResponse();
    }

    /**
     * Create an instance of {@link GetFacilityList }
     * 
     */
    public GetFacilityList createGetFacilityList() {
        return new GetFacilityList();
    }

    /**
     * Create an instance of {@link GetFacilityListResponse }
     * 
     */
    public GetFacilityListResponse createGetFacilityListResponse() {
        return new GetFacilityListResponse();
    }

    /**
     * Create an instance of {@link MediaUploadMovi }
     * 
     */
    public MediaUploadMovi createMediaUploadMovi() {
        return new MediaUploadMovi();
    }

    /**
     * Create an instance of {@link MovieRequest }
     * 
     */
    public MovieRequest createMovieRequest() {
        return new MovieRequest();
    }

    /**
     * Create an instance of {@link MediaUploadMoviResponse }
     * 
     */
    public MediaUploadMoviResponse createMediaUploadMoviResponse() {
        return new MediaUploadMoviResponse();
    }

    /**
     * Create an instance of {@link MovieResponse }
     * 
     */
    public MovieResponse createMovieResponse() {
        return new MovieResponse();
    }

    /**
     * Create an instance of {@link MediaUploadImg }
     * 
     */
    public MediaUploadImg createMediaUploadImg() {
        return new MediaUploadImg();
    }

    /**
     * Create an instance of {@link MediaUploadImgResponse }
     * 
     */
    public MediaUploadImgResponse createMediaUploadImgResponse() {
        return new MediaUploadImgResponse();
    }

    /**
     * Create an instance of {@link MediaDelete }
     * 
     */
    public MediaDelete createMediaDelete() {
        return new MediaDelete();
    }

    /**
     * Create an instance of {@link DeleteRequest }
     * 
     */
    public DeleteRequest createDeleteRequest() {
        return new DeleteRequest();
    }

    /**
     * Create an instance of {@link MediaDeleteResponse }
     * 
     */
    public MediaDeleteResponse createMediaDeleteResponse() {
        return new MediaDeleteResponse();
    }

    /**
     * Create an instance of {@link GetNewVersion }
     * 
     */
    public GetNewVersion createGetNewVersion() {
        return new GetNewVersion();
    }

    /**
     * Create an instance of {@link GetNewVersionResponse }
     * 
     */
    public GetNewVersionResponse createGetNewVersionResponse() {
        return new GetNewVersionResponse();
    }

    /**
     * Create an instance of {@link VersionResponse }
     * 
     */
    public VersionResponse createVersionResponse() {
        return new VersionResponse();
    }

    /**
     * Create an instance of {@link MediaDeleteImg }
     * 
     */
    public MediaDeleteImg createMediaDeleteImg() {
        return new MediaDeleteImg();
    }

    /**
     * Create an instance of {@link Img }
     * 
     */
    public Img createImg() {
        return new Img();
    }

    /**
     * Create an instance of {@link MediaDeleteImgResponse }
     * 
     */
    public MediaDeleteImgResponse createMediaDeleteImgResponse() {
        return new MediaDeleteImgResponse();
    }

    /**
     * Create an instance of {@link MediaUploadMoviForIphone }
     * 
     */
    public MediaUploadMoviForIphone createMediaUploadMoviForIphone() {
        return new MediaUploadMoviForIphone();
    }

    /**
     * Create an instance of {@link MediaUploadMoviForIphoneResponse }
     * 
     */
    public MediaUploadMoviForIphoneResponse createMediaUploadMoviForIphoneResponse() {
        return new MediaUploadMoviForIphoneResponse();
    }

    /**
     * Create an instance of {@link ErrorResponse }
     * 
     */
    public ErrorResponse createErrorResponse() {
        return new ErrorResponse();
    }

    /**
     * Create an instance of {@link ArrayOfClinic }
     * 
     */
    public ArrayOfClinic createArrayOfClinic() {
        return new ArrayOfClinic();
    }

    /**
     * Create an instance of {@link Clinic }
     * 
     */
    public Clinic createClinic() {
        return new Clinic();
    }

    /**
     * Create an instance of {@link ArrayOfFacility }
     * 
     */
    public ArrayOfFacility createArrayOfFacility() {
        return new ArrayOfFacility();
    }

    /**
     * Create an instance of {@link Facility }
     * 
     */
    public Facility createFacility() {
        return new Facility();
    }

    /**
     * Create an instance of {@link ArrayOfMovies }
     * 
     */
    public ArrayOfMovies createArrayOfMovies() {
        return new ArrayOfMovies();
    }

    /**
     * Create an instance of {@link Movies }
     * 
     */
    public Movies createMovies() {
        return new Movies();
    }

    /**
     * Create an instance of {@link ArrayOfPatient }
     * 
     */
    public ArrayOfPatient createArrayOfPatient() {
        return new ArrayOfPatient();
    }

    /**
     * Create an instance of {@link Patient }
     * 
     */
    public Patient createPatient() {
        return new Patient();
    }

    /**
     * Create an instance of {@link ArrayOfString }
     * 
     */
    public ArrayOfString createArrayOfString() {
        return new ArrayOfString();
    }

    /**
     * Create an instance of {@link Version }
     * 
     */
    public Version createVersion() {
        return new Version();
    }

}
