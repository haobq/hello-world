
package jp.co.inc.media.video.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;FolderSizeResponse complex typeのJavaクラス。
 * 
 * &lt;p&gt;次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="FolderSizeResponse"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="Contract_size" type="{http://www.w3.org/2001/XMLSchema}long"/&amp;gt;
 *         &amp;lt;element name="Used_size" type="{http://www.w3.org/2001/XMLSchema}long"/&amp;gt;
 *         &amp;lt;element name="Free_size" type="{http://www.w3.org/2001/XMLSchema}long"/&amp;gt;
 *         &amp;lt;element name="CapacityCriticalRate" type="{http://www.w3.org/2001/XMLSchema}int"/&amp;gt;
 *         &amp;lt;element name="Result" type="{http://www.w3.org/2001/XMLSchema}int"/&amp;gt;
 *         &amp;lt;element name="Error" type="{http://video.media.inc.co.jp/service}ErrorResponse" minOccurs="0"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FolderSizeResponse", propOrder = {
    "contractSize",
    "usedSize",
    "freeSize",
    "capacityCriticalRate",
    "result",
    "error"
})
public class FolderSizeResponse {

    @XmlElement(name = "Contract_size")
    protected long contractSize;
    @XmlElement(name = "Used_size")
    protected long usedSize;
    @XmlElement(name = "Free_size")
    protected long freeSize;
    @XmlElement(name = "CapacityCriticalRate")
    protected int capacityCriticalRate;
    @XmlElement(name = "Result")
    protected int result;
    @XmlElement(name = "Error")
    protected ErrorResponse error;

    /**
     * contractSizeプロパティの値を取得します。
     * 
     */
    public long getContractSize() {
        return contractSize;
    }

    /**
     * contractSizeプロパティの値を設定します。
     * 
     */
    public void setContractSize(long value) {
        this.contractSize = value;
    }

    /**
     * usedSizeプロパティの値を取得します。
     * 
     */
    public long getUsedSize() {
        return usedSize;
    }

    /**
     * usedSizeプロパティの値を設定します。
     * 
     */
    public void setUsedSize(long value) {
        this.usedSize = value;
    }

    /**
     * freeSizeプロパティの値を取得します。
     * 
     */
    public long getFreeSize() {
        return freeSize;
    }

    /**
     * freeSizeプロパティの値を設定します。
     * 
     */
    public void setFreeSize(long value) {
        this.freeSize = value;
    }

    /**
     * capacityCriticalRateプロパティの値を取得します。
     * 
     */
    public int getCapacityCriticalRate() {
        return capacityCriticalRate;
    }

    /**
     * capacityCriticalRateプロパティの値を設定します。
     * 
     */
    public void setCapacityCriticalRate(int value) {
        this.capacityCriticalRate = value;
    }

    /**
     * resultプロパティの値を取得します。
     * 
     */
    public int getResult() {
        return result;
    }

    /**
     * resultプロパティの値を設定します。
     * 
     */
    public void setResult(int value) {
        this.result = value;
    }

    /**
     * errorプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ErrorResponse }
     *     
     */
    public ErrorResponse getError() {
        return error;
    }

    /**
     * errorプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ErrorResponse }
     *     
     */
    public void setError(ErrorResponse value) {
        this.error = value;
    }

}
