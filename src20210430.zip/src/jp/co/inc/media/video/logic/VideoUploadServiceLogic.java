package jp.co.inc.media.video.logic;

import java.awt.Desktop;
import java.net.ConnectException;
import java.net.URI;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.namespace.QName;
import javax.xml.ws.WebServiceException;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasFrame;
import jp.co.inc.media.video.common.MessageConst;
import jp.co.inc.media.video.components.HospitalSelect;
import jp.co.inc.media.video.components.LoginDialog;
import jp.co.inc.media.video.frame.CallMainFrame;
import jp.co.inc.media.video.service.Clinic;
import jp.co.inc.media.video.service.ErrorResponse;
import jp.co.inc.media.video.service.LoginRespone;
import jp.co.inc.media.video.service.VersionResponse;
import jp.co.inc.media.video.service.VideoUploadService;
import jp.co.inc.media.video.service.VideoUploadServiceSoap;
import jp.co.inc.media.video.utils.FileProperty;
import jp.co.inc.media.video.utils.Messagebox;
import jp.co.inc.media.video.utils.OSDetector;

/**
 * 概要：サービスのクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class VideoUploadServiceLogic extends VideoUploadService implements BasConst, MessageConst {
	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(VideoUploadServiceLogic.class.getName());
	// サービス
	public static QName SERVICE_NAME = new QName("http://video.media.inc.co.jp/service", "VideoUploadService");
	// レスポンス
	private static LoginRespone loginReponse = null;
	// 医院ID
	private static String hosp_id = null;

	// 医院選択画面Stage
	public static Stage hospitalSelect = new Stage();

	/**
	 * @return hosp_id
	 */
	public static String getHosp_id() {
		return hosp_id;
	}

	/**
	 * @param hosp_id セットする hosp_id
	 */
	public static void setHosp_id(String hosp_id) {
		VideoUploadServiceLogic.hosp_id = hosp_id;
	}

	/**
	 * サービス接続し、ポートを返す。
	 *
	 * @return VideoUploadServiceSoap
	 * @throws ConnectException 接続例外
	 */
	public static VideoUploadServiceSoap getPort() throws ConnectException {
		final URL wsdlURL = VideoUploadService.WSDL_LOCATION;
		VideoUploadServiceSoap port = null;

		final VideoUploadService service = new VideoUploadService(wsdlURL, SERVICE_NAME);
		port = service.getVideoUploadServiceSoap12();
		return port;
	}

	/**
	 * @return loginReponse
	 */
	public static LoginRespone getLoginReponse() {
		return loginReponse;
	}

	/**
	 * @param loginReponse セットする loginReponse
	 */
	public static void setLoginReponse(LoginRespone loginReponse) {
		VideoUploadServiceLogic.loginReponse = loginReponse;
	}

	/**
	 * @param GetNewVersion セットする Version
	 */
	public static jp.co.inc.media.video.service.Version GetNewVersion(Stage owner) {
		String osInfo = "win";
		if (OSDetector.isMac()) {
			osInfo = "mac";
		}
		jp.co.inc.media.video.service.Version version = null;
		try {
			VersionResponse versionResponse = getPort().getNewVersion(osInfo);
			if (SUCCESS.equals(versionResponse.getError().getErrorCode())){
				version = versionResponse.getVer();
			}
		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021", E0021);
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021", E0021);
		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021", E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0001", E0001);
		}
		return version;
	}

	public static LoginRespone LoginManager(BasFrame callBaseFrm, Stage owner, String groupId, String userId,
			String paasword) {
		// 初期化
		setHosp_id(null);

		try {
			// ログレスポンス設定
			LoginRespone login = getPort().login(groupId, userId, paasword, "", SESSION_FLG);
			if (!SUCCESS.equals(login.getError().getErrorCode())) {
				Platform.runLater(() -> {
					ErrorResponse err = login.getError();
					logger.log(Level.SEVERE, err.getErrorMessage(), err.getErrorDetail());
					Messagebox.Error(hospitalSelect, err.getErrorCode(), err.getErrorMessage());
				});
				return null;
			}

			setLoginReponse(login);

			// 最新バージョンチェックを行う
			jp.co.inc.media.video.service.Version version = VideoUploadServiceLogic.GetNewVersion(owner);
			FileProperty filePro = new FileProperty(proFilePath);
			String uriString = filePro.getProperty("loginurl");
			uriString = uriString.replace("VideoUploadService.asmx?WSDL", "Download.aspx");

			FileProperty fileProVer = new FileProperty(verFilePath);
			String ver = fileProVer.getProperty("Ver");
			String update = fileProVer.getProperty("Date");

			if (!ver.equals(version.getVer()) || !update.equals(version.getDate())) {
				String verLocal = ver.substring(0, ver.lastIndexOf("."));
				String verServer = version.getVer().substring(0, version.getVer().lastIndexOf("."));
				boolean result = false;
				if (!verLocal.equals(verServer)) {
					Messagebox.Info(owner, I0014);
					result = true;
				}else {
					result = Messagebox.Confirmation(owner, I0013);
				}
				if (result) {
					Desktop desktop = Desktop.getDesktop();
					URI uri = new URI(uriString);
					desktop.browse(uri);
					// ログアウト
					CallMainFrame.logout();
					CallMainFrame.loginDialog.close();
					owner.close();
					Platform.exit();
					Thread start = new Thread(new Runnable() {
						@Override
						public void run() {
							// メモリ解放
							BasFrame.clearMemori();
						}
					});
					start.start();
					System.exit(0);
				}
			}

			if (SUCCESS.equals(getLoginReponse().getError().getErrorCode())) {
				// iniファイルに書き込む
				LoginDialog.writeIniFile();

				// 訪問先取得
				List<Clinic> clinicReponse = getLoginReponse().getClinicList().getClinic();
				if (clinicReponse != null) {
					// ログイン画面非表示
					CallMainFrame.loginDialog.hide();

					if (getLoginReponse().getClinicList().getClinic().size() > 1) {
						// 医院選択画面表示
						hospitalSelect = new HospitalSelect(callBaseFrm, owner, HOSPITAL_SELECT_TITLE,
								getLoginReponse().getClinicList(), groupId, userId, paasword, 400, 200);
						hospitalSelect.sizeToScene();
						hospitalSelect.show();
						hospitalSelect.setOnCloseRequest(new EventHandler<WindowEvent>() {
							@Override
							public void handle(WindowEvent event) {
								System.out.println("hospitalSelect close");
								// ログアウト
								CallMainFrame.logout();
							}
						});
					} else {
						// 医院ID設定
						setHosp_id(clinicReponse.get(0).getHospId());
					}
				}
			} else {
				Platform.runLater(() -> {
					ErrorResponse err = getLoginReponse().getError();
					logger.log(Level.SEVERE, err.getErrorMessage(), err.getErrorDetail());
					Messagebox.Error(BasFrame.mainStage, err.getErrorCode(), err.getErrorMessage());
				});
				return null;
			}

		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021", E0021);
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021", E0021);
		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021", E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0001", E0001);
		}

		return getLoginReponse();
	}

}
