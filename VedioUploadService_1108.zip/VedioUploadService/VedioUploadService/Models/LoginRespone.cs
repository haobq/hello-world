﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.MobileControls;

namespace VedioUploadService.Models
{
    public class LoginRespone
    {
        public Certification Cert { get; set; }
        public List<ClinicReponse> ClinicList { get; set; }
        public List<FacilityReponse> FacilityList { get; set; }
    }
}