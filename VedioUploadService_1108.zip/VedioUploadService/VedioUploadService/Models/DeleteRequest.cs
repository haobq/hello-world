﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class DeleteRequest
    {
        //認証情報
        public Certification Certification { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //動画ファイル名
        public string Upload_name { get; set; }
    }
}