﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models.Common
{
    public class SqlHelper
    {
        private static readonly string connstr = ConfigurationManager.ConnectionStrings["DB_CONNECTION"].ConnectionString;
        private static bool result = false;
        //動画ファイル登録					
        internal static bool InsertMovie(Movie movie)
        {

            string sql = "INSERT INTO tbl_patient_movie" +
                     "(group_id, " +
                     "hosp_id," +
                     "patient_id," +
                     "vedio_no," +
                     "vedio_kbn," +
                     "mask," +
                     "photo_date," +
                     "remarks," +
                     "vedio_path," +
                     "edit_date," +
                     "edit_user," +
                     "regist_date," +
                     "vedio_tag," +
                     "vedio_size," +
                     "seq_no) " +
                "VALUES(@group_id," +
                        "@hosp_id," +
                        "@patient_id," +
                        "@vedio_no," +
                        "@vedio_kbn," +
                        "@mask," +
                        "@photo_date," +
                        "@remarks," +
                        "@vedio_path," +
                        "@edit_date," +
                        "@edit_user," +
                        "@regist_date," +
                        "@vedio_tag," +
                        "@vedio_size," +
                        "@seq_no)";
            try
            {
                //group_id
                SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
                {
                    Value = movie.Group_id
                };
                //hosp_id
                SqlParameter parameter2 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = movie.Hosp_id
                };
                //patient_id
                SqlParameter parameter3 = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = movie.Patient_id
                };

                //vedio_no
                SqlParameter parameter4 = new SqlParameter("@vedio_no", SqlDbType.NVarChar)
                {
                    Value = movie.Vedio_no
                };

                //vedio_kbn
                SqlParameter parameter5 = new SqlParameter("@vedio_kbn", SqlDbType.NVarChar)
                {
                    Value = movie.Vedio_kbn
                };

                //mask
                SqlParameter parameter6 = new SqlParameter("@mask", SqlDbType.NVarChar)
                {
                    Value = movie.Mask
                };
                //photo_date
                SqlParameter parameter7 = new SqlParameter("@photo_date", SqlDbType.DateTime)
                {
                    Value = movie.Photo_date
                };
                //remarks
                SqlParameter parameter8 = new SqlParameter("@remarks", SqlDbType.NVarChar)
                {
                    Value = movie.Remarks
                };
                //vedio_path
                SqlParameter parameter9 = new SqlParameter("@vedio_path", SqlDbType.NVarChar)
                {
                    Value = movie.Vedio_path
                };
                //edit_date
                SqlParameter parameter10 = new SqlParameter("@edit_date", SqlDbType.DateTime)
                {
                    Value = movie.Edit_date
                };
                //edit_user
                SqlParameter parameter11 = new SqlParameter("@edit_user", SqlDbType.NVarChar)
                {
                    Value = movie.Edit_user
                };
                //regist_date
                SqlParameter parameter12 = new SqlParameter("@regist_date", SqlDbType.DateTime)
                {
                    Value = movie.Regist_date
                };
                //vedio_tag
                SqlParameter parameter13 = new SqlParameter("@vedio_tag", SqlDbType.NVarChar)
                {
                    Value = movie.Vedio_tag
                };

                //vedio_size
                SqlParameter parameter14 = new SqlParameter("@vedio_size", SqlDbType.BigInt)
                {
                    Value = movie.Vedio_size
                };
                //seq_no
                SqlParameter parameter15 = new SqlParameter("@seq_no", SqlDbType.Int)
                {
                    Value = movie.Seq_no
                };
                SqlParameter[] parameters = new SqlParameter[]{
                    parameter1, parameter2,parameter3,parameter4,parameter5,parameter6,parameter7,parameter8,parameter9,parameter10,parameter11,parameter12,parameter13,parameter14,parameter15};
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);

                        int num = cmd.ExecuteNonQuery();

                        if (num > 0)
                        {
                            result = true;
                        }
                    }
                }
            }
            catch (Exception )
            {
              //  string ec = e.Message.ToString();
            }

            return result;
        }

        internal static string GetMedia_auth(string user_id, string hosp_id, string group_id)
        {
            SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "select media_auth from tbl_session where session_flg = '3' and group_id = @group_id and hosp_id = @hosp_id and user_id = @user_id ";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            SqlParameter parameter2 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            SqlParameter parameter3 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };
            parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };
            string media_auth = "";
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        media_auth = (string)reader[0];
                    }
                }
            }
            return media_auth;
        }

        internal static string GetTerminalId(string group_id, string user_id)
        {
            SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "select terminal_id from mst_terminal where mask = '0' and group_id = @group_id and user_id = @user_id";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };
            parameters = new SqlParameter[] { parameter1, parameter2 };
            string terminal_id = "";
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        terminal_id = (string)reader[0];
                    }

                }
            }
            return terminal_id;
        }

        internal static long GetFolderSize(string group_id)
        {
             SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "select index_no from mst_user where group_id = @group_id";

            //SQLインジェクションを防止する
            SqlParameter parameter = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            parameters = new SqlParameter[] { parameter };
            long size = 0;
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        size = (long)reader[0];
                    }
                }
            }
            return size;
        }

        //ユーザID、パスワード、グループIDが正しいかをチェックする。
        internal static bool IsCorrect(string groupId, string userId, string pswd)
        {
            string sql;
            SqlParameter[] parameters;
            if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(pswd))
            {
                //クエリのSQL文を定義する
                sql = "select index_no from mst_user where group_id = @groupId and user_id = @userId and user_pw = @pswd and mask= 0";

                //SQLインジェクションを防止する
                SqlParameter parameter1 = new SqlParameter("@groupId", SqlDbType.NVarChar)
                {
                    Value = groupId ?? ""
                };

                SqlParameter parameter2 = new SqlParameter("@userId", SqlDbType.NVarChar)
                {
                    Value = userId ?? ""
                };

                SqlParameter parameter3 = new SqlParameter("@pswd", SqlDbType.NVarChar)
                {
                    Value = pswd ?? ""
                };

                parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };
            }
            else
            {
                //クエリのSQL文を定義する
                sql = "select index_no from mst_group where group_id = @groupId and mask= 0";

                //SQLインジェクションを防止する
                SqlParameter parameter = new SqlParameter("@groupId", SqlDbType.NVarChar)
                {
                    Value = groupId ?? ""
                };

                parameters = new SqlParameter[] { parameter };
            }
            try
            {
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);

                        try
                        {
                            if (cmd.ExecuteScalar() != null)
                            {
                                return true;
                            }
                        }
                        catch (Exception ex)
                        {
                            ex.Message.ToString();
                        }
                        return false;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }

        }

        internal static bool IsCorrect(string groupId)
        {
            bool flag = IsCorrect(groupId, null, null);

            return flag;
        }


        //サーバ日付を取得する
        public static DateTime? GetSbuTime()
        {
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                DateTime date;

                using (SqlCommand cmd = new SqlCommand("SELECT  GETDATE();", conn))
                {
                    try
                    {
                        if (cmd.ExecuteScalar() != null)
                        {
                            date = (DateTime)cmd.ExecuteScalar();

                            return date.ToLocalTime();

                        }
                    }
                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                    return null;

                }
            }

        }

        /// <summary>
        /// 患者リストを取得
        /// </summary>
        /// <param name="patientRequest"></param>
        /// <returns></returns>
        internal static List<PatientResponse> GetPatient_data(PatientRequest patientRequest)
        {
            string group_id = patientRequest.Certification.Group_id;
            string hosp_id = patientRequest.Certification.Hosp_id;
            string patient_name = patientRequest.Patient_name;
            string visit_id = patientRequest.Visit_id;
            string visit_start = patientRequest.Last_visit;

            string sql = "select tbl_patient.patient_id,";
            sql += "   tbl_patient.patient_name,";
            sql += "   tbl_patient.patient_kana,";
            sql += "   tbl_patient.patient_sex,";
            sql += "   tbl_patient.patient_birthday,";
            sql += "   tbl_patient_visit.hosp_id,";
            sql += "   tbl_patient_visit.visit_id,";
            sql += "   tbl_patient_visit.visit_start,";
            sql += "   tbl_patient.unique_id";
            sql += " from tbl_patient";
            sql += " left join tbl_patient_visit";
            sql += " ON tbl_patient.hosp_id = tbl_patient_visit.hosp_id";
            sql += " and tbl_patient.patient_id = tbl_patient_visit.patient_id";
            sql += " where";
            sql += " tbl_patient.hosp_id =  = @hosp_id";
            sql += " and tbl_patient_visit.visit_id =  = @visit_id";
            sql += " and(patient_name like '%@patient_name%' or  patient_kana like '%@patient_name%')";

            if (Tools.IsCheckParm(visit_start) == false)
            {
                sql += " and tbl_patient_visit.visit_start = @visit_start";
            }

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            SqlParameter parameter2 = new SqlParameter("@patient_name", SqlDbType.NVarChar)
            {
                Value = patient_name
            };
            SqlParameter parameter3 = new SqlParameter("@visit_id", SqlDbType.NVarChar)
            {
                Value = visit_id
            };
            SqlParameter parameter4 = new SqlParameter("@visit_start", SqlDbType.NVarChar)
            {
                Value = visit_start
            };

            SqlParameter[] parameters ;
            if (Tools.IsCheckParm(visit_start) == false)
            {
                parameters = new SqlParameter[] { parameter1, parameter2, parameter3, parameter4 };
            }else
            {
                parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };
            }
            List<PatientResponse> terminals = new List<PatientResponse>();

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        PatientResponse patient = new PatientResponse
                        {
                            Group_id = group_id,
                            Hosp_id = hosp_id,
                            Patient_id = (string)reader[0],
                            Patient_name = (string)reader[1],
                            Patient_kana = (string)reader[2],
                            Patient_sex = (string)reader[3],
                            Patient_birthday = (string)reader[4],
                            Visit_id = (string)reader[5],
                            Last_visit = (string)reader[6],
                            Unique_id = (string)reader[7]
                        };
                        terminals.Add(patient);
                    }
                }
            }
            return terminals;
        }
        /// <summary>
        /// 施設リスト取得する
        /// </summary>
        /// <param name="hosp_id"></param>
        /// <returns></returns>
        internal static List<FacilityReponse> GetFacility_data(string hosp_id)
        {
            string sql = "select visit_id, visit_name";
            sql += " from mst_visit";
            sql += " where";
            sql += " (visit_kbn ='2' or visit_kbn ='3') ";
            sql += " and mask ='0'";
            sql += " and hosp_id = @hosp_id";

            //SQLインジェクションを防止する
            SqlParameter parameter = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter };
            List<FacilityReponse> terminals = new List<FacilityReponse>();

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        FacilityReponse facility = new FacilityReponse();
                        facility.Visit_id = (string)reader[0];
                        facility.Visit_name = (string)reader[1];
                        terminals.Add(facility);
                    }
                }
            }
            return terminals;
        }

        /// <summary>
        /// 認証キーをチェックする
        /// </summary>
        /// <param name="groupID"></param>
        /// <param name="user_id"></param>
        /// <param name="mediaAuth"></param>
        /// <returns></returns>
        internal static bool KEY_CHK(string groupID, string user_id,string mediaAuth)
        {
            //クエリのSQL文を定義する
            string sql = "select media_auth from tbl_session ";
            sql += " WHERE regist_datetime <= getdate()";
            sql += " and regist_datetime >= dateadd(day, -1, getdate())";
            sql += " and session_flg = '3'";
            sql += " and group_id = @group_id";
            sql += " and user_id = @user_id";
            sql += " and media_auth = @mediaAuth";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@groupID", SqlDbType.NVarChar)
            {
                Value = groupID
            };

            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };

            SqlParameter parameter3 = new SqlParameter("@mediaAuth", SqlDbType.NVarChar)
            {
                Value = mediaAuth
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    cmd.Parameters.AddRange(parameters);

                    if (cmd.ExecuteScalar() != null)
                    {

                        return true;

                    }
                }
            }
            return false;
        }

        //tbl_session登録
        internal static bool InsertTblSession(string user_id, string hosp_id,string group_id, string terminal_id)
        {
            bool sqlrtn = false;
            try
            {
                string sqlString = "";
                sqlString = "insert into tbl_session( ";   
                sqlString += "user_id, ";
                sqlString += "group_id, ";
                sqlString += "hosp_id, ";
                sqlString += "terminal_id, ";
                sqlString += "session_flg, ";   
                sqlString += "media_auth, ";
                sqlString += "regist_datetime) ";
                sqlString += "values( ";
                sqlString += "@user_id, ";
                sqlString += "@group_id, ";
                sqlString += "@hosp_id, ";
                sqlString += "@terminal_id, ";
                sqlString += "'3', ";  
                sqlString += "'" +Tools.GenerateAuthKey(20) + "', ";
                sqlString += "getdate()) ";

                SqlParameter parameter1 = new SqlParameter("@user_id", SqlDbType.NVarChar)
                {
                    Value = user_id
                };
                SqlParameter parameter2 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = hosp_id
                };
                SqlParameter parameter3 = new SqlParameter("@group_id", SqlDbType.NVarChar)
                {
                    Value = group_id
                };
                SqlParameter parameter4 = new SqlParameter("@terminal_id", SqlDbType.NVarChar)
                {
                    Value = terminal_id
                };
                SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3, parameter4 };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(sqlString, conn))
                    {
                        cmd.Parameters.AddRange(parameters);

                        int num = cmd.ExecuteNonQuery();

                        if (num > 0)
                        {
                            sqlrtn = true;
                        }
                    }
                }
            }
            catch (Exception)
            {
                //  string ec = e.Message.ToString();
            }
            return sqlrtn;
        }

        //TBL_SESSION削除
        internal static bool DelTblSession(Certification cert)
        {
            bool sqlrtn = false;
            string sql = "";

            //ログアウト時
            sql = "delete tbl_session ";    
            sql += "where ";
            sql += " user_id = @user_id ";
            sql += " and group_id = @group_id ";
            sql += " and session_flg = '3' ";
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = cert.Group_id
            };

            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = cert.User_id
            };
            SqlParameter[] parameters = new SqlParameter[]{ parameter1, parameter2};
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddRange(parameters);

                    int num = cmd.ExecuteNonQuery();

                    if (num > 0)
                    {
                        sqlrtn = true;
                    }
                }
            }

            return sqlrtn;
        }


        /// <summary>
        /// 医院リスト取得する
        /// </summary>
        /// <param name="groupID"></param>
        /// <returns></returns>
        internal static List<ClinicReponse> GetClinic_data(string groupID, string user_id)
        {
            string　sql = "select distinct mst_user_hosp.hosp_id,mst_hosp.hosp_name";
            sql += " from mst_user_hosp";
            sql += " INNER join mst_hosp";
            sql += " ON mst_user_hosp.hosp_id = mst_hosp.hosp_id";
            sql += " where mst_user_hosp.group_id = @group_id";
            sql += " and mst_user_hosp.user_id = @user_id";
            sql += " and mst_hosp.mask = '0'";
            sql += " and mst_user_hosp.effect_date_from <= GETDATE()";
            sql += " and mst_user_hosp.effect_date_to >= GETDATE()";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = groupID
            };
            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 };
            List<ClinicReponse> terminals = new List<ClinicReponse>();

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        ClinicReponse clinicReponse = new ClinicReponse();
                        ClinicReponse hosp = clinicReponse;
                        hosp.Hosp_id = (string)reader[0];
                        hosp.Hosp_name = (string)reader[1];
                        terminals.Add(hosp);
                    }
                }
            }
            return terminals;
        }
    }
}