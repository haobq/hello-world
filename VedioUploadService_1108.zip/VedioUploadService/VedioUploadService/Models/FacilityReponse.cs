﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class FacilityReponse
    {
        //施設ID
        public string Visit_id { get; set; }
        //施設名
        public string Visit_name { get; set; }
    }
}