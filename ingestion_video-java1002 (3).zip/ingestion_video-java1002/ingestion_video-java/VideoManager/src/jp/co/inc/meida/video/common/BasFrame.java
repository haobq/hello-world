/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.meida.video.common;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.util.Callback;
import jp.co.inc.meida.video.utils.ClickableMenu;
import jp.co.inc.meida.video.utils.FileInfoBean;
import jp.co.inc.meida.video.utils.FileProperty;
import jp.co.inc.meida.video.utils.FolderManager;
import jp.co.inc.meida.video.utils.Messagebox;

public class BasFrame extends Application implements MediaPlay, BasConst,MessageConst {

	Scene scene;
	Stage mainStage;

	private static String workingDir = "";
	private static String workingDirJson = "";

	private BorderPane topPane = new BorderPane();
	private BorderPane bottomPane = new BorderPane();
	private BorderPane vediaoPane = new BorderPane();
	private BorderPane rightBottomPane = new BorderPane();


	private BorderPane notePane;
	// サブぺネル
	private Pane bp1 = new Pane();
	private Pane bp2 = new Pane();
	private Pane bp3 = new Pane();
	private Pane bp4 = new Pane();
	private Pane bp5 = new Pane();

	private String strStats = "初期化";

	private StackPane paneFileList;
	private StackPane vbPatientList;
	private HBox hboxButtomMain ;

	// 備考
	private TextArea textArea = new TextArea();	
	
	// カレンダー
	private DatePicker checkInDatePicker;
	// 動画ファイルリストを取得する
	List<FileInfoBean> fileInfolist;
	// ファイルリストテーブル
	private TableView<FileInfoBean> table;
	// 選択した動画ファイルリスト
	private ObservableList<FileInfoBean> selectedFileInfolist;

	// ファイルリストテーブル選択したカラム
	private int selectedRow = 0;
	
	/**
	 * @return selectedRow
	 */
	public int getSelectedRow() {
		return selectedRow;
	}

	/**
	 * @param selectedRow セットする selectedRow
	 */
	public void setSelectedRow(int selectedRow) {
		this.selectedRow = selectedRow;
	}

	// MediaPlayerボリューム
	private static double mediaVolume = 0;

	/**
	 * @return mediaVolume
	 */
	public static double getMediaVolume() {
		return mediaVolume;
	}

	/**
	 * @param mediaVolume セットする mediaVolume
	 */
	public static void setMediaVolume(double mediaVolume) {
		BasFrame.mediaVolume = mediaVolume;

	}

	/**
	 * 画面スタート
	 * @param primaryStage
	 */
	@Override
	public void start(Stage primaryStage) {
		// 初期化
		initUI(primaryStage);
		mainStage = primaryStage;

	}

	/**
	 * メイン
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);

	}

	/**
	 * 画面コントロール設定
	 * @param primaryStage
	 */
	public void initUI(Stage primaryStage) {
		System.out.println("START -initUI");
		
		try {

			// 初期化
			init(primaryStage);
			String proFilePath = System.getProperty("user.dir").replace("\\", "/") + "/conf/system.ini";
			FileProperty filePro;
			try {
				filePro = new FileProperty(proFilePath);
				workingDirJson = filePro.getProperty("WorkingDirJson");
				workingDir = filePro.getProperty("WorkingDir");
				if (workingDir != null) {
					fileInfolist = FolderManager.getFileInfoList(workingDir);
				}else {
					fileInfolist = new ArrayList<FileInfoBean>();
				}
				initScreen(fileInfolist ,paneFileList);



			} catch (Exception e1) {
				Messagebox.Error(primaryStage, e1.getMessage());
			}

			System.out.println("1 " + workingDir);
			System.out.println("2 " + workingDirJson);


		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("END -initUI");
	}

	/**
	 * 状態バーパネル取得
	 * @param strStats
	 */
	private StackPane getBottomRootPane(String strStats, Stage primaryStage) {

		BorderPane borderPane = new BorderPane();

		// 状況
		Label lblStats = new Label(STATUSBAR_TITLE_STATAS);
		lblStats.setPrefWidth(60);
		borderPane.setLeft(lblStats);

		Label sText = new Label(strStats);
		sText.setAlignment(Pos.BASELINE_LEFT);
		borderPane.setCenter(sText);

		// プログレスバー
		ProgressBar progressBar = new ProgressBar();
		progressBar.setPrefHeight(25);
		borderPane.setRight(progressBar);

		StackPane pane = new StackPane(borderPane);

		return pane;
	}

	private StackPane getLeftRootPane(BorderPane topPane, BorderPane bottomPane, Stage primaryStage) {

		// フォルダ選択ボタン
		Button btnSelectFolder = new Button(BUTTON_FOLD_SELECT);

		// フォルダ選択ボタンイベント登録
		btnSelectFolder.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				DirectoryChooser directoryChooser = new DirectoryChooser();
				directoryChooser.setTitle("動画格納フォルダを選択してください");
				directoryChooser.setInitialDirectory(new File(workingDir));
				File file = directoryChooser.showDialog(primaryStage);
				if (file != null) {
					workingDir = file.getAbsolutePath().replace("\\", "/");
					System.out.println("3 file " + workingDir);
					try {
						fileInfolist = FolderManager.getFileInfoList(workingDir);
						initScreen(fileInfolist,paneFileList);
					} catch (Exception e1) {
						Messagebox.Error(primaryStage, e1.getMessage());
					}
				} else {
					Messagebox.Error(primaryStage, E0004);
				}
				strStats = "動画ファイル取得した";
			}
		});

		HBox btnFoldSelect = new HBox();
		btnSelectFolder.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		btnSelectFolder.setAlignment(Pos.TOP_LEFT);
		btnFoldSelect.getChildren().add(btnSelectFolder);
		btnFoldSelect.setAlignment(Pos.TOP_LEFT);
		topPane.setTop(btnFoldSelect);

		// ファイル一覧
		paneFileList = new StackPane();
		//paneFileList.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");
		topPane.setCenter(paneFileList);

		// 検索
		final HBox hvBoxSearch = new HBox();
		// 検索テクストボックス
		TextField txtFind = new TextField();
		txtFind.setPromptText(TXT_FIND);
		txtFind.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		txtFind.prefWidthProperty().bind(hvBoxSearch.widthProperty());
		// 検索ボタン
		final Button btnSearch = new Button();
		Image image = new Image(getClass().getResourceAsStream("../img/search.jpeg"));
		ImageView imgView = new ImageView(image);
		imgView.setFitHeight(20);
		imgView.setFitWidth(20);
		btnSearch.setGraphic(imgView);
		btnSearch.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickBtnSearch(e);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnSearch.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		btnSearch.setPrefWidth(60);
		hvBoxSearch.getChildren().addAll(txtFind, btnSearch);
		bottomPane.setTop(hvBoxSearch);

		vbPatientList = new StackPane();
		vbPatientList.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");
		bottomPane.setCenter(vbPatientList);

		SplitPane liftVerticalPane = new SplitPane();
		liftVerticalPane.setOrientation(Orientation.VERTICAL);
		liftVerticalPane.getItems().addAll(topPane, bottomPane);

		//Javafx splitpane 分割 固定
		double posRootLeft[]  = {0.50f, 0.50f };
		liftVerticalPane.setDividerPositions(posRootLeft);
		for (int i = 0; i < liftVerticalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = liftVerticalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootLeft[ind]);
				}
			});
		}
		StackPane pane = new StackPane(liftVerticalPane);

		return pane;
	}

	/**
	 * メディア メインパネル設定
	 * @param pa パネル
	 * @param mediafile メディアファイル
	 */
	void MediaMainRefresh(Pane pa, File mediafile) {
		System.out.println("START -MediaMainRefresh");

		try {

			// 動画再生クラスをインスタンス化
			Media Video = new Media(mediafile.toURI().toString());
			MediaPlayer Play = new MediaPlayer(Video);
			MediaView mediaView = new MediaView(Play);

			mediaView.setFitWidth(pa.getWidth());
			mediaView.setFitHeight(pa.getHeight());
			mediaView.fitHeightProperty().bind(pa.heightProperty());
			mediaView.fitWidthProperty().bind(pa.widthProperty());

			pa.getChildren().add(mediaView);

			// ボリューム保存
			Play.setVolume(mediaVolume);

			// 画面下に表示する情報バーを作成
			HBox bottomNode = new HBox(10.0);
			bottomNode.getChildren().add(MediaPlay.createButton(Play));        // 再生・停止・繰り返しボタン作成
			bottomNode.getChildren().add(MediaPlay.createTimeSlider(Play));    // 時間表示スライダ作成
			bottomNode.getChildren().add(MediaPlay.createVolumeSlider(Play));  // ボリューム表示スライダ作成

			hboxButtomMain.getChildren().clear();
			hboxButtomMain.getChildren().add(bottomNode);

		} catch (IllegalArgumentException e) {
			//			logger.log(Level.INFO, "例外のスローを捕捉", e);
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		System.out.println("END -MediaMainRefresh");

	}

	/**
	 * コントロールサブパネルを画面に設定
	 * @param pa パネル
	 * @param mediafile メディアファイル
	 */
	private void MediaSet(Pane pa, File mediafile) {
		System.out.println("START -MediaSet");

		try {
			// 動画再生クラスをインスタンス化
			Media Video = new Media(mediafile.toURI().toString());
			MediaPlayer Play = new MediaPlayer(Video);
			MediaView mediaView = new MediaView(Play);

			mediaView.setFitWidth(pa.getWidth());
			mediaView.setFitHeight(pa.getHeight());
			mediaView.fitHeightProperty().bind(pa.heightProperty());
			mediaView.fitWidthProperty().bind(pa.widthProperty());

			pa.getChildren().add(mediaView);

		} catch (IllegalArgumentException e) {
			//			logger.log(Level.INFO, "例外のスローを捕捉", e);
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		System.out.println("END -MediaSet");

	}


	/**
	 * パネルクリア
	 */
	private void mediaSetClear() {
		System.out.println("START -mediaSetClear");


		vediaoPane.getChildren().clear();
		bp1.getChildren().clear();
		bp2.getChildren().clear();
		bp3.getChildren().clear();
		bp4.getChildren().clear();
		bp5.getChildren().clear();

		System.out.println("END -mediaSetClear");

	}

	private StackPane getRightRootPane(Pane bp1,Pane bp2,Pane bp3,Pane bp4,Pane bp5,BorderPane vediaoPane,BorderPane notePane,Stage primaryStage) {
		bp1.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp2.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp3.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp4.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		bp5.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");

		final double posSubMedia[]  = { 0.2f, 0.4f, 0.6f, 0.8f, 1.0f };
		// サムネイルパネルSplitPane
		final SplitPane thumbnailPane = new SplitPane();
		thumbnailPane.setOrientation(Orientation.HORIZONTAL);
		thumbnailPane.getItems().addAll(bp1,bp2,bp3,bp4,bp5);
		thumbnailPane.setDividerPositions(posSubMedia);
		for (int i = 0; i < thumbnailPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = thumbnailPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posSubMedia[ind]);
				}
			});
		}

		notePane = new BorderPane();
		// 備考
		HBox hvBoxNote = new HBox();
		final Label labBikou = new Label(TEXTARIA_BIKOU);
		labBikou.setAlignment(Pos.BOTTOM_LEFT);
		labBikou.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");

		labBikou.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);

		// 保存ボタン
		final Button btnSave = new Button();
		Image image = new Image(getClass().getResourceAsStream("../img/save.png"));
		ImageView imgView = new ImageView(image);
		imgView.setFitHeight(20);
		imgView.setFitWidth(20);
		btnSave.setGraphic(imgView);
		btnSave.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickBtnBikouSave(e);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnSave.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		hvBoxNote.setAlignment(Pos.BASELINE_CENTER);
		hvBoxNote.setSpacing(20);
		hvBoxNote.getChildren().addAll(labBikou,btnSave);

		final BorderPane mediaPane = new BorderPane();
		hboxButtomMain = new HBox();
		hboxButtomMain.setPrefHeight(40);
		mediaPane.setCenter(vediaoPane);
		mediaPane.setBottom(hboxButtomMain);


		textArea = new TextArea();
		textArea.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		textArea.setWrapText(true);
		notePane.setTop(hvBoxNote);
		notePane.setCenter(textArea);

		TextField txtABikou = new TextField("");
		txtABikou.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);

		final SplitPane vediaoHorizonalPane = new SplitPane();
		vediaoHorizonalPane.setOrientation(Orientation.HORIZONTAL);
		vediaoPane.setStyle("-fx-background-radius: 10;-fx-background-color: rgba(0,0,0,3);");
		vediaoHorizonalPane.getItems().addAll(mediaPane, notePane);
		final double posVedio[]  = { 0.75f, 1.0f };
		vediaoHorizonalPane.setDividerPositions(posVedio);
		for (int i = 0; i < vediaoHorizonalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = vediaoHorizonalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posVedio[ind]);
				}
			});
		}

		final SplitPane rightVerticalPane = new SplitPane();
		rightVerticalPane.setOrientation(Orientation.VERTICAL);
		rightVerticalPane.getItems().addAll(thumbnailPane, vediaoHorizonalPane);

		double posRootRight[]  = {0.20f, 0.80f };
		rightVerticalPane.setDividerPositions(posRootRight);
		for (int i = 0; i < rightVerticalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = rightVerticalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootRight[ind]);
				}
			});
		}

		final HBox hvBoxLiftBottom = new HBox();
		final HBox hvBoxRightBottom = new HBox();
		// カレンダーコントロール
		checkInDatePicker = new DatePicker();
		checkInDatePicker.setMinWidth(40);
		checkInDatePicker.setMaxWidth(150);
		checkInDatePicker.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		checkInDatePicker.setPromptText(DATE_TYPE_YYYY_MM_DD.toLowerCase());
		checkInDatePicker.setValue(LocalDate.now());

		final GridPane gridPane = new GridPane();
		gridPane.setHgap(10);
		gridPane.setVgap(10);
		gridPane.add(checkInDatePicker, 0, 0);

		hvBoxLiftBottom.getChildren().add(gridPane);

		// 動画送信 ボタン
		final Button btnSend = new Button(BUTTON_SEND);
		hvBoxLiftBottom.getChildren().add(btnSend);
		btnSend.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickSend(e);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnSend.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);

		// キャンセル ボタン 
		final Button btnCancel = new Button(BUTTON_CANEL);
		hvBoxLiftBottom.getChildren().add(btnCancel);
		btnCancel.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickBtnCancel(e);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnCancel.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);

		// 削除 ボタン
		final Button btnDelete = new Button(BUTTON_DELETE);
		hvBoxLiftBottom.getChildren().add(btnDelete);
		btnDelete.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickBtnDelete(e);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnDelete.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		hvBoxRightBottom.setAlignment(Pos.BASELINE_CENTER);
		hvBoxRightBottom.setPadding(new Insets(5, 5, 5, 5));
		hvBoxLiftBottom.setSpacing(40);
		hvBoxRightBottom.getChildren().addAll(hvBoxLiftBottom);
		rightBottomPane.setCenter(hvBoxRightBottom);

		final BorderPane borderPane = new BorderPane();
		borderPane.setCenter(rightVerticalPane);
		borderPane.setBottom(rightBottomPane);

		final StackPane pane = new StackPane(borderPane);

		return pane;
	}

	/**
	 * 画面レイアウト初期化
	 * @param fileList
	 */
	private void initScreen(List<FileInfoBean> fileList,Pane paneFileList) {
		System.out.println("START -initScreen");

		//初期化
		paneFileList.getChildren().clear();
		table = new TableView<>();
		ObservableList<FileInfoBean> observableList = FXCollections.observableList(fileList);
		final ObservableList<TableColumn<FileInfoBean, ?>> columns = table.getColumns();

		final TableColumn<FileInfoBean, CheckBox> fileCheckBoxColumn = new TableColumn<FileInfoBean, CheckBox>(
				FILE_TITLE_CHECKED);
		fileCheckBoxColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<FileInfoBean, CheckBox>, ObservableValue<CheckBox>>() {

					@Override
					public ObservableValue<CheckBox> call(TableColumn.CellDataFeatures<FileInfoBean, CheckBox> arg0) {
						final FileInfoBean data = arg0.getValue();
						final CheckBox checkBox = new CheckBox();
						checkBox.selectedProperty().setValue(data.isChecked());

						if (data.isFileSended()) {
							// 無効に設定
							checkBox.setDisable(true);
						}

						checkBox.selectedProperty().addListener(new ChangeListener<Boolean>() {
							public void changed(ObservableValue<? extends Boolean> ov, Boolean old_val,
									Boolean new_val) {
								data.setChecked(new_val);
								checkBox.setSelected(new_val);
							}
						});

						return new SimpleObjectProperty<CheckBox>(checkBox);
					}

				});

		// ダブルクリックイベント		
		table.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {

					// チェックボックスを無効の場会、処理しない
					if ( !STATUS_COMPLETED.equals(table.getSelectionModel().getSelectedItem().status)) {
						if (table.getSelectionModel().getSelectedItem().checked.get()) {
							table.getSelectionModel().getSelectedItem().checked.set(false);
							
						} else {
							table.getSelectionModel().getSelectedItem().checked.set(true);
							
						}
						
						// ファイルリスト初期化
						initScreen(fileInfolist, paneFileList);
					}

				}
			}
		});
		
		fileCheckBoxColumn.setMaxWidth(30);

		final TableColumn<FileInfoBean, Label> fileStatusColumn = new TableColumn<FileInfoBean, Label>(
				FILE_TITLE_STATAS);
		fileStatusColumn.setMaxWidth(35);

		final TableColumn<FileInfoBean, String> fileNameColumn = new TableColumn<>(FILE_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory<>("fileName"));

		final TableColumn<FileInfoBean, String> lastedUpdateColumn = new TableColumn<>(FILE_TITLE_LASTED_UPDATE);
		lastedUpdateColumn.setCellValueFactory(new PropertyValueFactory<>("updateDate"));

		final TableColumn<FileInfoBean, String> fileSizeColumn = new TableColumn<>(FILE_TITLE_SIZE);
		fileSizeColumn.setCellValueFactory(new PropertyValueFactory<>("fileSize"));

		final TableColumn<FileInfoBean, String> fileBikouColumn = new TableColumn<>(FILE_TITLE_BIKOU);
		fileBikouColumn.setCellValueFactory(new PropertyValueFactory<>("bikou"));
		
		final TableColumn<FileInfoBean, String> fileUploadFileNameColumn = new TableColumn<>(FILE_TITLE_UPLOAD_FILE_NAME);
		fileUploadFileNameColumn.setCellValueFactory(new PropertyValueFactory<>("uploadFileName"));
		
		/** ファイルリストクリックイベント処理 */
		setCellValueFactory(fileStatusColumn);

		// カラム追加
		columns.add(fileCheckBoxColumn);
		columns.add(fileStatusColumn);
		columns.add(fileNameColumn);
		columns.add(lastedUpdateColumn);
		columns.add(fileSizeColumn);
		columns.add(fileBikouColumn);
		columns.add(fileUploadFileNameColumn);
		table.setItems(observableList);
		// sort
		table.sort();

		table.setMinWidth(300);
		paneFileList.getChildren().add(table);
		paneFileList.prefHeightProperty().bind(table.heightProperty());
		table.prefWidthProperty().bind(paneFileList.widthProperty());

		if (fileList.size() > 0) {
			//選択状態を検知するバインディングの設定
			table_addListener(observableList);

		}

		// ファイル一覧選択
		table.requestFocus();
		table.getSelectionModel().select(getSelectedRow());
		table.getFocusModel().focus(selectedRow);
		
		System.out.println("END -initScreen");
	}

	/**
	 * テーブルリスナー
	 * @param fileList
	 */
	private void table_addListener(final ObservableList<FileInfoBean> fileList) {

		System.out.println("START -table_addListener");

		table.getSelectionModel().selectedItemProperty().addListener((ov, old, current) -> {

			System.out.println("選択したファイル:" + current.filePath);

			if (fileList != null) {
				table_selected(fileList, current);
			}
		});

		System.out.println("END -table_addListener");

	}


	private void table_selected(ObservableList<FileInfoBean> fileList, FileInfoBean current) {
		System.out.println("START -table_selected");

		if (fileList != null) {
			// 初期化

			selectedFileInfolist = FXCollections.observableArrayList();
			for (int count = 0; count < fileList.size(); count++) {
				FileInfoBean fileInfo = new FileInfoBean();
				fileInfo = fileList.get(count);

				if (fileInfo.fileName.equals(current.fileName)) {

					// 選択した列を保存
					setSelectedRow( count);
					
					if (fileList.size() - count >= 5) {
						System.out.println("選択セル 5");
						System.out.println("count:" + count);

						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));

						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;

					} else if (fileList.size() - count == 4) {
						System.out.println("選択セル 4");

						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;

					} else if (fileList.size() - count == 3) {
						System.out.println("選択セル 3");

						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;

					} else if (fileList.size() - count == 2) {
						System.out.println("選択セル 2");

						selectedFileInfolist.add(fileList.get(count++));
						selectedFileInfolist.add(fileList.get(count++));
						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;

					} else if (fileList.size() - count == 1) {
						System.out.println("選択セル 1");

						selectedFileInfolist.add(fileList.get(count++));
						System.out.println("selectedFileInfolistcount:" + selectedFileInfolist.size());
						printFileName();
						mediaRefresh();

						break;
					}

				}

			}

		}

		System.out.println("END -table_selected");


	}

	/**
	 * パネル再設定設定
	 */
	void mediaRefresh() {
		System.out.println("START -mediaRefresh");

		// 動画ファイル
		File file;
		mediaSetClear();
		if (selectedFileInfolist != null) {
			for (int count = 0; count < selectedFileInfolist.size(); count++) {
				// 動画ファイルのパスを取得
				file = new File(selectedFileInfolist.get(count).filePath);

				if (count == 0) {
					// メインパネル設定
					MediaMainRefresh(vediaoPane, file);
					// 動画ファイル設定
					MediaSet(bp1, file);
				} else if (count == 1) {
					// 動画ファイル設定
					MediaSet(bp2, file);

				} else if (count == 2) {
					// 動画ファイル設定
					MediaSet(bp3, file);
				} else if (count == 3) {
					// 動画ファイル設定
					MediaSet(bp4, file);
				} else if (count == 4) {
					// 動画ファイル設定
					MediaSet(bp5, file);

				}
			}
		}

		System.out.println("END -mediaRefresh");


	}

	/**
	 * セールファクトリー
	 * @param fileStatusColumn
	 */
	private void setCellValueFactory(TableColumn<FileInfoBean, Label> fileStatusColumn) {
		fileStatusColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<FileInfoBean, Label>, ObservableValue<Label>>() {

					@Override
					public ObservableValue<Label> call(TableColumn.CellDataFeatures<FileInfoBean, Label> arg0) {
						FileInfoBean data = arg0.getValue();
						final Label label = new Label();
						label.setTextFill(Color.RED);

						label.setBackground(new Background(
								new BackgroundFill(Color.BLUEVIOLET, new CornerRadii(10), new Insets(5))));

						label.setPrefSize(10, 10);

						if (data.getStatus().equals(STATUS_NEW)) {

							final Image imageDecline = new Image(getClass().getResourceAsStream("../img/unreg.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(STATUS_WORKING)) {

							final Image imageDecline = new Image(getClass().getResourceAsStream("../img/loading.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(STATUS_COMPLETED)) {

							final Image imageDecline = new Image(getClass().getResourceAsStream("../img/finish.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);
						}

						return new SimpleObjectProperty<Label>(label);
					}

				});
	}


	/**
	 * 画面コントロール初期化
	 * @param primaryStage
	 * @param boot
	 */
	public void init(Stage primaryStage) {

		SplitPane splitHorizontal = new SplitPane();
		splitHorizontal.setOrientation(Orientation.HORIZONTAL);
		splitHorizontal.setDividerPosition(0, 0.25);
		splitHorizontal.setDividerPosition(1, 0.75);

		splitHorizontal.getItems().add(getLeftRootPane(topPane, bottomPane, primaryStage));
		splitHorizontal.getItems().add(getRightRootPane(bp1,bp2,bp3,bp4,bp5,vediaoPane,notePane,primaryStage));

		BorderPane rootPane = new BorderPane();
		rootPane.setStyle("-fx-border-style: solid; -fx-border-width: 0 0 0 0;");
		rootPane.setCenter(splitHorizontal);
		rootPane.setBottom(getBottomRootPane(strStats, primaryStage));

		// ウィンドウサイズ設定
		StackPane gui = new StackPane(rootPane);
		Scene scene = new Scene(gui, WINDOWS_WHITH, WINDOWS_HEIGHT);
		primaryStage.setMaximized(false);

		rootPane.prefWidthProperty().bind(scene.widthProperty());
		rootPane.prefHeightProperty().bind(scene.heightProperty());

		gui.prefWidthProperty().bind(scene.widthProperty());
		gui.prefHeightProperty().bind(scene.heightProperty());

		MenuBar menuBar = new MenuBar();
		rootPane.setTop(menuBar);

		Menu settingMenu = settingMenu();
		Menu menualMenu = menualMenu();
		Menu historyMenu = historyMenu();
		Menu loginMenu = loginMenu();
		menuBar.getMenus().addAll(settingMenu, menualMenu,historyMenu,loginMenu);

		//ウィンドウタイトル
		primaryStage.setTitle(SYSTEM_NAME);

		//ウィンドウサイズ変更の無効化
		primaryStage.setResizable(true);

		//アイコンの設定
		Image img = new Image(getClass().getResourceAsStream("../img/media.jpg"));
		primaryStage.getIcons().add(img);

		//フルスクリーンモードのオン、オフ
		//フルスクリーンオンの時はescキーで解除できます
		primaryStage.setFullScreen(false);
		primaryStage.setScene(scene);
		primaryStage.show();

	}
	

	private Menu settingMenu() {
		ClickableMenu clickableMenu = new ClickableMenu("設定");
		clickableMenu.setOnAction(evt ->settingHandle());
		return clickableMenu;
	}

	private void settingHandle() {
		Stage settingDialog;
		try {
			settingDialog = new SettingDialog(mainStage);
			settingDialog.sizeToScene();
			settingDialog.show();
		} catch (Exception e) {
			e.printStackTrace();
			Messagebox.Error(mainStage, E0001);
		}

	}

	private Menu menualMenu() {
		ClickableMenu clickableMenu = new ClickableMenu("マニュアル");
		clickableMenu.setOnAction(evt -> menualHandle());
		return clickableMenu;
	}

	private void menualHandle() {
		try {
			Runtime runTime = Runtime.getRuntime();
			String pdfFilePath = System.getProperty("user.dir").replace("\\", "/") + "/conf/Manual.pdf";
			runTime.exec("cmd /c start "+pdfFilePath);
		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	private Menu historyMenu() {
		ClickableMenu clickableMenu = new ClickableMenu("送信履歴");
		clickableMenu.setOnAction(evt -> historyHandle());
		return clickableMenu;
	}

	private void historyHandle() {
		Stage historyDialog = new HistoryDialog(mainStage);
		historyDialog.sizeToScene();
		historyDialog.show();
	}

	private Menu loginMenu() {
		ClickableMenu clickableMenu = new ClickableMenu("ログイン");
		clickableMenu.setOnAction(evt -> loginHandle());
		return clickableMenu;
	}

	private void loginHandle() {
		Stage loginDialog = new LoginDialog(mainStage);
		loginDialog.sizeToScene();
		loginDialog.show();
	}

	/**
	 * 検索処理
	 * @param event
	 * @throws IOException
	 */
	void onClickBtnSearch(ActionEvent event) throws IOException {
		System.out.println("onClickBtnSearch");

	}

	/**
	 * 送信処理
	 * @param event
	 * @throws IOException
	 */
	void onClickSend(ActionEvent event) throws IOException {
		System.out.println("START -onClickSend");



		for (FileInfoBean file : fileInfolist) {

			if (file.isChecked()) {
				
				file.setFileSended(true);
				file.setUploadFileName(checkInDatePicker.getValue().toString());
				file.setUploadFileName("uploadfileName");
				file.setStatus(STATUS_COMPLETED);

				// チェックボックスを無効に設定
				if ( file.getStatus()== STATUS_COMPLETED) {
					file.setFileSended(true);

				}				
			}


		}

		// ファイルリスト初期化
		initScreen(fileInfolist, paneFileList);

		System.out.println("END -onClickSend");
	}

	/**
	 * キャンセル処理
	 * @param event
	 * @throws IOException
	 */
	void onClickBtnCancel(ActionEvent event) throws IOException {
		System.out.println("START -onClickBtnCancel");

		System.out.println("END -onClickBtnCancel");
	}

	/**
	 * 削除処理
	 * @param event
	 * @throws IOException
	 */
	void onClickBtnDelete(ActionEvent event) throws IOException {
		System.out.println("START -onClickBtnDelete");

		System.out.println("END -onClickBtnDelete");
	}
	
	/**
	 * 備考保存処理
	 * @param event
	 * @throws IOException
	 */
	void onClickBtnBikouSave(ActionEvent event) throws IOException {
		System.out.println("START -onClickBtnBikouSave");
		for (FileInfoBean file : fileInfolist) {

			if (file.isChecked()) {
				
				file.setFileSended(true);
				file.setUploadFileName(checkInDatePicker.getValue().toString());
				file.setBikou(textArea.getText());
				file.setStatus(STATUS_COMPLETED);
				file.setUploadFileName("uploadfileName");

				// チェックボックスを無効に設定
				if ( file.getStatus()== STATUS_COMPLETED) {
					file.setFileSended(true);

				}				
			}


		}

		// ファイルリスト初期化
		initScreen(fileInfolist, paneFileList);

	}
	
	/**
	 * ディバグ用
	 */
	void printFileName() {
		// 動画ファイル
		File file;

		if (selectedFileInfolist != null) {
			for (int count = 0; count < selectedFileInfolist.size(); count++) {

				// 動画ファイルのパスを取得
				file = new File(selectedFileInfolist.get(count).filePath);

				System.out.println(file.getName());

			}

		}

	}

}
