package jp.co.inc.meida.video.common;

import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import jp.co.inc.meida.video.utils.FileInfoBean;
import jp.co.inc.meida.video.utils.FolderManager;
import jp.co.inc.meida.video.utils.JsonFileListBean;

public class HistoryDialog extends Stage implements  BasConst,MessageConst{
	private TableView<FileInfoBean> tableDetail;

	private void setJsonFileList(List<JsonFileListBean> fileList,Pane paneFileList) {

		paneFileList.getChildren().clear();
		TableView<JsonFileListBean>  tableList = new TableView<>();
		ObservableList<JsonFileListBean> observableList = FXCollections.observableList(fileList);
		final ObservableList<TableColumn<JsonFileListBean, ?>> columns = tableList.getColumns();

		final TableColumn<JsonFileListBean, Label> fileStatusColumn = new TableColumn<JsonFileListBean, Label>(
				JSON_TITLE_STATAS);
		fileStatusColumn.setMaxWidth(35);

		final TableColumn<JsonFileListBean, String> fileNameColumn = new TableColumn<>(JSON_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory<>("fileName"));

		// カラム追加
		columns.add(fileStatusColumn);
		columns.add(fileNameColumn);

		tableList.setItems(observableList);
	}


	private void setJsonFileDetail(List<FileInfoBean> fileList,Pane paneFileDetail) {

	}
	public HistoryDialog(Stage owner) {
		super();
		initOwner(owner);
		setTitle("送信履歴");
		Group root = new Group();
		Scene scene = new Scene(root, 800, 600, Color.WHITE);
		setScene(scene);
		BorderPane listPane = new BorderPane();
		BorderPane topPane = new BorderPane();
		topPane.setPrefWidth(790);
		topPane.setPrefHeight(260);

		HBox hvBoxNote = new HBox();
		Label labFileListTitle = new Label("送信ファイルリスト");
		labFileListTitle.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		labFileListTitle.setAlignment(Pos.BOTTOM_LEFT);
		hvBoxNote.setAlignment(Pos.BASELINE_LEFT);
		hvBoxNote.setSpacing(20);
		hvBoxNote.getChildren().addAll(labFileListTitle);
		topPane.setTop(hvBoxNote);



		StackPane paneFileList = new StackPane();
		paneFileList.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");
		String path =  System.getProperty("user.dir").replace("\\", "/") + "/data";
		List<JsonFileListBean> fileList = FolderManager.getJsonFileListBean(path);
		setJsonFileList(fileList,paneFileList);
		topPane.setCenter(paneFileList);

		BorderPane bottomPane = new BorderPane();
		HBox detailBoxNote = new HBox();
		Label labFileDetail = new Label("送信ファイル詳細");
		labFileDetail.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_NORM_STYLE);
		labFileDetail.setAlignment(Pos.BOTTOM_LEFT);
		detailBoxNote.setAlignment(Pos.BASELINE_LEFT);
		detailBoxNote.setSpacing(20);
		detailBoxNote.getChildren().addAll(labFileDetail);
		bottomPane.setPrefWidth(790);
		bottomPane.setPrefHeight(280);

		bottomPane.setTop(detailBoxNote);
		StackPane paneFileDetail = new StackPane();
		paneFileDetail.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");
		bottomPane.setCenter(paneFileDetail);

		SplitPane verticalPane = new SplitPane();
		verticalPane.setOrientation(Orientation.VERTICAL);
		verticalPane.getItems().addAll(topPane, bottomPane);

		//Javafx splitpane 分割 固定
		double posRootLeft[]  = {0.40f, 1.0f };
		verticalPane.setDividerPositions(posRootLeft);
		for (int i = 0; i < verticalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = verticalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootLeft[ind]);
				}
			});
		}

		Button config = new Button("確認");
		HBox bottomNode = new HBox(10.0);
		bottomNode.setPadding(new Insets(10, 10, 10, 10));
		bottomNode.setSpacing(40);
		bottomNode.getChildren().addAll(config);
		bottomNode.setAlignment(Pos.CENTER_RIGHT);

		config.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				close();
			}
		});
		listPane.setCenter(verticalPane);
		listPane.setBottom(bottomNode);

		root.getChildren().add(listPane);
	}
	private void getJsonFileListBean(String path) {
		// TODO 自動生成されたメソッド・スタブ

	}
}

