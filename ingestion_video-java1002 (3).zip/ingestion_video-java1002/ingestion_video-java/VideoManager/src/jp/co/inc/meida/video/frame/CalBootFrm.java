/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */

package jp.co.inc.meida.video.frame;

import jp.co.inc.meida.video.common.BasFrame;
import jp.co.inc.meida.video.common.BasInfoBean;
import jp.co.inc.meida.video.common.BootBean;
import jp.co.inc.meida.video.components.ESplash;


public class CalBootFrm extends BasFrame {

	private boolean _isFromFirstBoot = false;

//	CalMainFrm calMainFrm;

	/**
	 * コンストラクタ．     <BR>
	 *
	 *<PRE>
	 * 初期処理(jbInit)を実行する。
	 *</PRE>
	 * @see  #jbInit()
	 *
	 */
	public CalBootFrm(boolean isFromFirstBoot) {
		set_isFromFirstBoot(isFromFirstBoot);
		try {
			BootBean calBootBean = new BootBean();
			calBootBean.readSystemInfo();
			set_isFromFirstBoot(true);
			//初期化処理
			doInitThread();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 初期処理．    <BR>
	 *
	 * @return     なし
	 * @Exception  異常のException
	 *
	 */
	private void jbInit() throws Exception {
//		calMainFrm = new CalMainFrm();
//	    Toolkit tk = Toolkit.getDefaultToolkit();
//	    int xSize = (int) tk.getScreenSize().getWidth();
//	    int ySize = ((int) tk.getScreenSize().getHeight());
//	    calMainFrm.setSize(xSize,ySize);
	}

	public void doInitThread() {
		ThreadCreateMainFrm threadCreateMainFrm = new ThreadCreateMainFrm();
		GetCntrctInstance cntrctInstance = new GetCntrctInstance();
		try {
			threadCreateMainFrm.join();
			cntrctInstance.join();
		} catch (Exception e) {
		}
	}

	class ThreadCreateMainFrm extends Thread {
		public ThreadCreateMainFrm() {
			setPriority(4);
			start();
		}

		public void run() {
			try {
				jbInit();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	class GetCntrctInstance extends Thread {
		public GetCntrctInstance() {
			setPriority(10);
			start();
		}

		public void run() {

		}
	}

	/**
	 * メインメソッド．    <BR>
	 * @param   args  プログラムのパラメータ配列
	 * @return  なし
	 */
	public static void main(String[] args) {
		ESplash esplash = new ESplash();
		esplash.setSize(405, 215);
		esplash.setVisible(true);

		BasInfoBean.setLoadFrm(esplash);
		CalBootFrm lf = new CalBootFrm(false);
		try {
            Thread.sleep(1000*5);//1000 is 1 second
	    } catch (InterruptedException e1) {
	        Thread.currentThread().interrupt();
	        e1.printStackTrace();
	    }
//		lf.setTitle(SYSTEM_NAME);
//	    Toolkit tk = Toolkit.getDefaultToolkit();
//	    int xSize = (int) tk.getScreenSize().getWidth();
//	    int ySize = ((int) tk.getScreenSize().getHeight());
//	    lf.setSize(xSize,ySize);
//		lf.setVisible(true);
//		esplash.setVisible(false);

	}

	public boolean is_isFromFirstBoot() {
		return _isFromFirstBoot;
	}

	public void set_isFromFirstBoot(boolean _isFromFirstBoot) {
		this._isFromFirstBoot = _isFromFirstBoot;
	}
}
