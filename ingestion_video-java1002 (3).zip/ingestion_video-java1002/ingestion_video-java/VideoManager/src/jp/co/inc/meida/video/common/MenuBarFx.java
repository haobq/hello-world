package jp.co.inc.meida.video.common;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.stage.Stage;
import jp.co.inc.meida.video.utils.Messagebox;

public class MenuBarFx  extends MenuBar implements  BasConst,MessageConst{

	//メニューバーに付けるメニュー
	Menu menu1 = null;
	Menu menu2 = null;
	Menu menu3 = null;
	Menu menu4 = null;

	public BasFrame basFrame;
	Stage primaryStage;


	public MenuBarFx(BasFrame basFrame,Stage stage) {
		this.basFrame = basFrame;
		this.setMenuBar();
		this.primaryStage =stage;
	}


	/**
	 * メニューバーにメニューを設置する
	 */
	public void setMenuBar(){

		//menu1にメニューアイテムを登録する
		menu1 = new Menu("設定");
		menu1.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				System.out.println("saaaaaa");
				Messagebox.Error(primaryStage, E0001);

			}

		});

		//menu2にメニューアイテムを登録する
		menu2 = new Menu("マニュアル");
		menu2.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				// TODO 自動生成されたメソッド・スタブ

			}

		});

		//menu3にメニューアイテムを登録する
		menu3 = new Menu("送信履歴");
		menu3.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				// TODO 自動生成されたメソッド・スタブ

			}

		});


		//menu4にメニューアイテムを登録する
		menu4 = new Menu("ログイン");
		menu4.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				// TODO 自動生成されたメソッド・スタブ

			}

		});

		//メニューバーにメニューを登録
		this.getMenus().add( menu1 );
		this.getMenus().add( menu2 );
		this.getMenus().add( menu3 );
		this.getMenus().add( menu4 );
	}
}
