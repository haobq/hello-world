package jp.co.inc.meida.video.common;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.util.Optional;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.Timer;

public class BasButton extends JButton {
	private static final int DELTA = 10;
	private static final double ARC_WIDTH = 32d;
	private static final double ARC_HEIGHT = 32d;
	private int radius;
	private final float[] dist = { 0f, 1f };
	private final Color[] colors = { new Color(0x64_44_05_F7, true), new Color(0xFF_D7_00, true) };
	private final Timer timer1 = new Timer(10, e -> {
		radius = Math.min(200, radius + DELTA);
		repaint();
	});
	private final Timer timer2 = new Timer(10, e -> {
		radius = Math.max(0, radius - DELTA);
		repaint();
	});
	private final Point pt = new Point();
	private transient Shape shape;
	private Rectangle base;

	protected BasButton(String title) {
		super(title);

		MouseAdapter listener = new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				timer2.stop();
				if (!timer1.isRunning()) {
					timer1.start();
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				timer1.stop();
				if (!timer2.isRunning()) {
					timer2.start();
				}
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				update(e);
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				update(e);
			}

			private void update(MouseEvent e) {
				pt.setLocation(e.getPoint());
				repaint();
			}
		};
		addMouseListener(listener);
		addMouseMotionListener(listener);
	}

	@Override
	public void updateUI() {
		super.updateUI();
		setOpaque(false);
		setContentAreaFilled(false);
		setFocusPainted(false);
		setBackground(new Color(6));
		setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		update();
	}

	@Override
	public boolean contains(int x, int y) {
		update();
		return Optional.ofNullable(shape).map(s -> s.contains(x, y)).orElse(false);
	}

	protected void update() {
		if (!getBounds().equals(base)) {
			base = getBounds();
			shape = new RoundRectangle2D.Double(0d, 0d, getWidth() - 1d, getHeight() - 1d, ARC_WIDTH, ARC_HEIGHT);
		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		update();

		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		g2.setComposite(AlphaComposite.Src);
		g2.setPaint(new Color(getModel().isArmed() ? 0xFF_AA_AA : 0xFF_D7_00));
		g2.fill(shape);

		if (radius > 0) {
			int r2 = radius + radius;
			g2.setPaint(new RadialGradientPaint(pt, r2, dist, colors));
			g2.setComposite(AlphaComposite.SrcAtop);
			g2.setClip(shape);
			g2.fill(new Ellipse2D.Double(pt.getX() - radius, pt.getY() - radius, r2, r2));
		}
		g2.dispose();

		super.paintComponent(g);
	}
}