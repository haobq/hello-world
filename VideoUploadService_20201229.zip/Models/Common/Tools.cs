﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace VideoUploadService.Models.Common
{
    public class Tools
    {
        //認証キーに使用する文字
        private static readonly string passwordChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-";
        private static readonly Random r = new Random();
        //パラメータの有無をチェック
        public static bool IsCheckParm(string parm)
        {
            if (string.IsNullOrEmpty(parm))
            {
                return false;
            }
            return true;
        }

        //文字数の範囲をチェック
        public static bool IsCheckStrLen(string str, int length)
        {
            if (str != null && length > 0 && str.Length <= length)
            {
                return true;
            }
            return false;
        }

        //日付が正しいかをチェックする
        public static bool IsCheckDate(string date)
        {
            _ = new DateTime();

            if (!string.IsNullOrEmpty(date) &&

                DateTime.TryParse(date, out _))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// ランダムな文字列を生成する
        /// </summary>
        /// <param name="length">生成する文字列の長さ</param>
        /// <returns>生成された文字列</returns>
        public static string GenerateAuthKey(int length)
        {
            StringBuilder sb = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                //文字の位置をランダムに選択
                int pos = r.Next(passwordChars.Length);
                //選択された位置の文字を取得
                char c = passwordChars[pos];
                //パスワードに追加
                sb.Append(c);
            }
            return sb.ToString();
        }

        //日付の前後妥当性をチェック
        public static bool IsCheckDate(string str1, string str2)
        {

            if (DateTime.TryParse(str1, out DateTime date1) && DateTime.TryParse(str2, out DateTime date2))
            {
                TimeSpan span = date2.Subtract(date1);
                if (span.TotalDays >= 0)
                {
                    return true;
                }
            }
            return false;
        }

        //ユーザID、パスワードをチェックする。
        public static bool IsCorrect(string GroupId, string UserId, string Pswd)
        {
            return SqlHelper.IsCorrect(GroupId, UserId, Pswd);
        }

        //グループIDが正しいかをチェックする。
        public static bool IsCorrect(string GroupId)
        {
            return SqlHelper.IsCorrect(GroupId);
        }

        //時間形式を変更する
        public static string GetTimeStr(string time)
        {
            string validDate = "";

            if (!string.IsNullOrEmpty(time))
            {
                validDate = time.Replace("/", "-").Split(' ')[0];
            }

            return validDate;
        }

        public static string GetString(string value)
        {
            return value ?? "";
        }

        //数値をチェックする
        public static bool IsCheckNum(int num)
        {
            int[] nums = { 1, 2 };

            if (Array.IndexOf(nums, num) < 0)
            {
                return false;
            }
            return true;
        }

        //String To Datime
        public static DateTime ToDateTime(string str)
        {
            System.Globalization.DateTimeFormatInfo dateTimeFormatInfo = new System.Globalization.DateTimeFormatInfo();
            System.Globalization.DateTimeFormatInfo dtFormat = dateTimeFormatInfo;

            dtFormat.ShortDatePattern = "yyyy-MM-dd";

            return Convert.ToDateTime(str, dtFormat);

        }

        internal static List<Movies> GetMovieList(string hosp_id, string patient_id, string movie_index, string movie_type)
        {
            List<Movies> movies = new List<Movies>();
            if(movie_type == "1")
            {
                movies = SqlHelper.GetVideoList(hosp_id, patient_id, movie_index);
            }
            else if (movie_type == "2")
            {
                movies = SqlHelper.GetImageList(hosp_id, patient_id, movie_index);
            }
            else if (movie_type == "3")
            {
                List<Movies> movies1 = SqlHelper.GetVideoList(hosp_id, patient_id, movie_index);
                List<Movies> movies2 = SqlHelper.GetImageList(hosp_id, patient_id, movie_index);
                List<Movies> movies3 = movies1.Concat(movies2).ToList<Movies>();
                IOrderedEnumerable<Movies> sortList = movies3.OrderByDescending(rec => rec.Photo_date).ThenByDescending(rec => rec.Regist_date);
                movies = movies3;
            }
            return movies;
        }

        internal static Img GetImage(Certification cert, string patient_id, int image_no)
        {
            Img image = new Img();
            image = SqlHelper.GetImage(cert, patient_id, image_no);

            return image;
        }

        internal static string GetTerminalId(string group_id, string user_id)
        {
            return SqlHelper.GetTerminalId(group_id, user_id);
        }

        internal static string GetMedia_auth(string user_id, string hosp_id, string group_id,string session_flg)
        {
            return SqlHelper.GetMedia_auth(user_id, hosp_id, group_id, session_flg);
        }

        //動画ファイル登録
        public static bool InsertMovie(MovieRequest movie)
        {
            return SqlHelper.InsertMovie(movie);
        }
        //静止画ファイル登録
        public static bool InsertImg(MovieRequest movie)
        {
            return SqlHelper.InsertImg(movie);
        }
        public static List<Patient> GetPatient_data(PatientRequest patientRequest)
        {
            return SqlHelper.GetPatient_data(patientRequest);
        }
        //動画ファイル格納場所取得
        public static String GetMoviPath(DeleteRequest movie)
        {
            return SqlHelper.GetMoviPath(movie);
        }
        //静止画ファイルインデクス番号取得
        public static int GetImageNo(MovieRequest movie)
        {
            return SqlHelper.GetImageNo(movie);
        }
        //静止画ファイル格納場所取得
        public static String GetImgPath(Img image)
        {
            return SqlHelper.GetImgPath(image);
        }
        //動画ファイル削除
        public static bool DeleteMovie(DeleteRequest movie)
        {
            return SqlHelper.DeleteMovie(movie);
        }

        //静止画ファイル削除
        public static bool DeleteImg(Img image)
        {
            return SqlHelper.DeleteImg(image);
        }
        public static bool InsertTblSession(string user_id, string hosp_id, string group_id, string terminal_id, string session_flg)
        {
            Certification cert = new Certification();
            cert.Group_id = group_id;
            cert.Hosp_id = hosp_id;
            cert.User_id = user_id;
            cert.Session_flg = session_flg;
            SqlHelper.DelTblSession(cert, true);
            return SqlHelper.InsertTblSession(user_id, hosp_id, group_id, terminal_id, session_flg);
        }
        public static bool DeleteTblSession(Certification cert)
        {
            return SqlHelper.DelTblSession(cert,false);
        }

        public static int IsOverCapacity(string group_id)
        {
            return SqlHelper.IsOverCapacity(group_id); 
        }

        //医院の訪問先リスト取得する
        public static List<Facility> GetFacility_data(string hosp_id)
        {
            return SqlHelper.GetFacility_data(hosp_id);
        }

        //訪問日の訪問先リスト取得する
        public static List<Facility> GetFacility_data(string hosp_id, string visitDate, string kbn)
        {
            return SqlHelper.GetFacility_data(hosp_id, visitDate, kbn);
        }

        //医院リスト取得する
        public static List<Clinic> GetClinic_data(string groupID, string user_id)
        {
            return SqlHelper.GetClinic_data(groupID, user_id);
        }

        //認証キーをチェックする
        public static bool KEY_CHK(string groupID, string user_id, string mediaAuth, string session_flg)
        {
            return SqlHelper.KEY_CHK(groupID, user_id, mediaAuth, session_flg);
        }

        //ディレクトリとその中身をすべて削除する
        public static void CleanUp(string targetDirectoryPath)
        {
            if (Directory.Exists(targetDirectoryPath))
            {
                string[] filePaths = Directory.GetFiles(targetDirectoryPath);
                foreach (string filePath in filePaths)
                {
                    File.SetAttributes(filePath, FileAttributes.Normal);
                    File.Delete(filePath);
                }

                string[] directoryPaths = Directory.GetDirectories(targetDirectoryPath);
                foreach (string directoryPath in directoryPaths)
                {
                    CleanUp(directoryPath);
                }
            }

            Directory.Delete(targetDirectoryPath, false);
        }

        /// <summary>
        /// 文字列を暗号化する
        /// </summary>
        /// <param name="sourceString">暗号化する文字列</param>  
        /// <returns>暗号化された文字列</returns>
        public static string GetEncryptString(string sourceString, string groupId, string userId)
        {
            //RijndaelManagedオブジェクトを作成
            System.Security.Cryptography.RijndaelManaged rijndael =
                new System.Security.Cryptography.RijndaelManaged();

            //パスワードから共有キーと初期化ベクタを作成
            GenerateKeyFromPassword(
                GetTmpPassword(groupId, userId), GetTmpSalt(groupId, userId), rijndael.KeySize, out byte[] key, rijndael.BlockSize, out byte[] iv);
            rijndael.Key = key;
            rijndael.IV = iv;

            //文字列をバイト型配列に変換する
            byte[] strBytes = System.Text.Encoding.UTF8.GetBytes(sourceString);

            //対称暗号化オブジェクトの作成
            System.Security.Cryptography.ICryptoTransform encryptor =
                rijndael.CreateEncryptor();
            //バイト型配列を暗号化する
            byte[] encBytes = encryptor.TransformFinalBlock(strBytes, 0, strBytes.Length);
            //閉じる
            encryptor.Dispose();

            //バイト型配列を文字列に変換して返す
            return System.Convert.ToBase64String(encBytes);
        }

        /// <summary>
        /// 暗号化された文字列を復号化する
        /// </summary>
        /// <param name="sourceString">暗号化された文字列</param>
        /// <param name="password">暗号化に使用したパスワード</param>
        /// <returns>復号化された文字列</returns>
        public string GetDecryptString(string sourceString, string groupId, string userId)
        {
            string rtn;
            try
            {
                //RijndaelManagedオブジェクトを作成
                System.Security.Cryptography.RijndaelManaged rijndael =
                  new System.Security.Cryptography.RijndaelManaged();

                //パスワードから共有キーと初期化ベクタを作成
                GenerateKeyFromPassword(
                    GetTmpPassword(groupId, userId), GetTmpSalt(groupId, userId), rijndael.KeySize, out byte[] key, rijndael.BlockSize, out byte[] iv);
                rijndael.Key = key;
                rijndael.IV = iv;

                //文字列をバイト型配列に戻す
                byte[] strBytes = System.Convert.FromBase64String(sourceString);

                //対称暗号化オブジェクトの作成
                System.Security.Cryptography.ICryptoTransform decryptor =
                    rijndael.CreateDecryptor();
                //バイト型配列を復号化する
                //復号化に失敗すると例外CryptographicExceptionが発生
                byte[] decBytes = decryptor.TransformFinalBlock(strBytes, 0, strBytes.Length);

                //閉じる
                decryptor.Dispose();

                //バイト型配列を文字列に戻して返す
                rtn = System.Text.Encoding.UTF8.GetString(decBytes);

            }
            catch (Exception)
            {
                rtn = "複合化に失敗しました";
            }

            return rtn;
        }

        /// <summary>
        /// パスワードから共有キーと初期化ベクタを生成する
        /// </summary>
        /// <param name="password">基になるパスワード</param>
        /// <param name="keySize">共有キーのサイズ（ビット）</param>
        /// <param name="key">作成された共有キー</param>
        /// <param name="blockSize">初期化ベクタのサイズ（ビット）</param>
        /// <param name="iv">作成された初期化ベクタ</param>
        private static void GenerateKeyFromPassword(string password, string saltStr,
            int keySize, out byte[] key, int blockSize, out byte[] iv)
        {
            //パスワードから共有キーと初期化ベクタを作成する
            //saltを決める
            byte[] salt = System.Text.Encoding.UTF8.GetBytes(saltStr);
            //Rfc2898DeriveBytesオブジェクトを作成する
            System.Security.Cryptography.Rfc2898DeriveBytes deriveBytes =
                new System.Security.Cryptography.Rfc2898DeriveBytes(password, salt);
            //反復処理回数を指定する デフォルトで1000回
            deriveBytes.IterationCount = 1000;
            //共有キーと初期化ベクタを生成する
            key = deriveBytes.GetBytes(keySize / 8);
            iv = deriveBytes.GetBytes(blockSize / 8);
        }

        private static string GetTmpPassword(string groupId, string userId)
        {
            return string.Format("with{0}you{1}", groupId, userId);
        }
        private static string GetTmpSalt(string groupId, string userId)
        {
            return string.Format("with{1}you{0}media", groupId, userId);
        }

         public static void WriteLog(string errorCode, Exception e, ILog logger )
        {
            logger.Error("[ErrorCode]\r\n" + errorCode);
            logger.Error("[Message]\r\n" + e.Message);
            logger.Error("[Source]\r\n" + e.Source);
            logger.Error("[StackTrace]\r\n" + e.StackTrace);
        }

        /// <summary>
        /// SHA256でハッシュ化する
        /// </summary>
        /// <param name="pwd"></param>
        /// <param name="salt"></param>
        /// <returns></returns>
        public static string GetHashPassword(string pwd, string salt)
        {
            var result = "";
            var saltAndPwd = String.Concat(pwd, salt);
            var encoder = new System.Text.UTF8Encoding();
            var buffer = encoder.GetBytes(saltAndPwd);
            using (var csp = new System.Security.Cryptography.SHA256CryptoServiceProvider())
            {
                var hash = csp.ComputeHash(buffer);
                result = Convert.ToBase64String(hash);
            }
            return result;
        }

    }
}