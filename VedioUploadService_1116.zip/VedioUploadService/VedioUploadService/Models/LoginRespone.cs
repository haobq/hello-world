﻿using System.Collections.Generic;
namespace VedioUploadService.Models
{
    public class LoginRespone
    {
        public Certification Cert { get; set; }
        public List<ClinicReponse> ClinicList { get; set; }
        public List<FacilityReponse> FacilityList { get; set; }
    }
}