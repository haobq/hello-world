﻿using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VedioUploadService.Models.Common
{
    public class SqlHelper
    {
        private static readonly string connstr = ConfigurationManager.ConnectionStrings["DB_CONNECTION"].ConnectionString;
        private static readonly log4net.ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static bool result = false;
        //動画ファイル登録					
        internal static bool InsertMovie(Movie movie)
        {

            string sql = "INSERT INTO tbl_patient_movie" +
                     "(" +
                     "hosp_id," +
                     "patient_id," +
                     "vedio_no," +
                     "vedio_kbn," +
                     "mask," +
                     "photo_date," +
                     "remarks," +
                     "vedio_path," +
                     "edit_date," +
                     "edit_user," +
                     "regist_date," +
                     "vedio_size" +
                     ") " +
                "VALUES" +
                    "(" +
                    "@hosp_id," +
                    "@patient_id," +
                    "@vedio_no," +
                    "'1'," +
                    "'0'," +
                    "@photo_date," +
                    "@remarks," +
                    "@vedio_path," +
                    "getdate()," +
                    "@edit_user," +
                    "getdate()," +
                    "@vedio_size" +
                    ")";
            try
            {
                //hosp_id
                SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = movie.Hosp_id
                };
                //patient_id
                SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = movie.Patient_id
                };

                //vedio_no
                SqlParameter paramVedio_no = new SqlParameter("@vedio_no", SqlDbType.NVarChar)
                {
                    Value = movie.Vedio_no
                };

                //photo_date
                SqlParameter paramPhoto_date = new SqlParameter("@photo_date", SqlDbType.DateTime)
                {
                    Value = movie.Photo_date
                };
                //remarks
                SqlParameter paramRemarks = new SqlParameter("@remarks", SqlDbType.NVarChar)
                {
                    Value = movie.Remarks
                };
                //vedio_path
                SqlParameter paramVedio_path = new SqlParameter("@vedio_path", SqlDbType.NVarChar)
                {
                    Value = movie.Vedio_path
                };
                //edit_user
                SqlParameter paramEdit_user = new SqlParameter("@edit_user", SqlDbType.NVarChar)
                {
                    Value = movie.Edit_user
                };
                //vedio_size
                SqlParameter paramVedio_size = new SqlParameter("@vedio_size", SqlDbType.BigInt)
                {
                    Value = movie.Vedio_size
                };
                SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramVedio_no,
                    paramPhoto_date,
                    paramRemarks,
                    paramVedio_path,
                    paramEdit_user,
                    paramVedio_size
                };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddRange(parameters);
                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                result = true;
                            }
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception e)
            {
                string ec = e.Message.ToString();
                logger.Error(movie.Hosp_id + "-" + movie.User_id + ":" + e);
            }

            return result;
        }

        //動画ファイル格納場所					
        internal static String GetMoviPath(Movie movie)
        {
            //クエリのSQL文を定義する
            string sql = "select vedio_path FROM tbl_patient_movie where hosp_id = @hosp_id and patient_id = @patient_id and vedio_no = @vedio_no and photo_date = @photo_date ";

            //SQLインジェクションを防止する
            //hosp_id
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = movie.Hosp_id
            };
            //patient_id
            SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
            {
                Value = movie.Patient_id
            };

            //vedio_no
            SqlParameter paramVedio_no = new SqlParameter("@vedio_no", SqlDbType.NVarChar)
            {
                Value = movie.Vedio_no
            };

            //photo_date
            SqlParameter paramPhoto_date = new SqlParameter("@photo_date", SqlDbType.DateTime)
            {
                Value = movie.Photo_date
            };
            SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramVedio_no,
                    paramPhoto_date
                };

            string path = "";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    path = (string)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    string ec = e.Message.ToString();
                    logger.Error(movie.Hosp_id + "-" + movie.User_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }
            }
            return path;
        }

        //動画ファイル削除					
        internal static bool DeleteMovie(Movie movie)
        {

            string sql = "DELETE FROM tbl_patient_movie where hosp_id = @hosp_id and patient_id = @patient_id and vedio_no = @vedio_no and photo_date = @photo_date ";
            try
            {
                //hosp_id
                SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = movie.Hosp_id
                };
                //patient_id
                SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = movie.Patient_id
                };

                //vedio_no
                SqlParameter paramVedio_no = new SqlParameter("@vedio_no", SqlDbType.NVarChar)
                {
                    Value = movie.Vedio_no
                };

                //photo_date
                SqlParameter paramPhoto_date = new SqlParameter("@photo_date", SqlDbType.DateTime)
                {
                    Value = movie.Photo_date
                };

                SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramVedio_no,
                    paramPhoto_date
                };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddRange(parameters);
                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                result = true;
                            }
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(movie.Hosp_id + "-" + movie.User_id + ":" + e);
            }

            return result;
        }

        internal static string GetMedia_auth(string user_id, string hosp_id, string group_id)
        {
            SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "select media_auth from tbl_session where session_flg = '3' and group_id = @group_id and hosp_id = @hosp_id and user_id = @user_id ";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            SqlParameter parameter2 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            SqlParameter parameter3 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };
            parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };
            string media_auth = "";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    media_auth = (string)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }
            }
            return media_auth;

        }

        internal static string GetTerminalId(string group_id, string user_id)
        {
            SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "select terminal_id from mst_terminal where mask = '0' and group_id = @group_id and user_id = @user_id";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };
            parameters = new SqlParameter[] { parameter1, parameter2 };
            string terminal_id = "";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    terminal_id = (string)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(group_id + "-" + user_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }
            }
            return terminal_id;
        }

        internal static long GetFolderSize(string group_id)
        {
            SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "select index_no from mst_user where group_id = @group_id";

            //SQLインジェクションを防止する
            SqlParameter parameter = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            parameters = new SqlParameter[] { parameter };
            long size = 0;

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    size = (long)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(group_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }
            }
            return size;
        }

        //ユーザID、パスワード、グループIDが正しいかをチェックする。
        internal static bool IsCorrect(string groupId, string userId, string pswd)
        {
            bool ret = false;
            string sql;
            SqlParameter[] parameters;
            if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(pswd))
            {
                //クエリのSQL文を定義する
                sql = "select index_no from mst_user where group_id = @groupId and user_id = @userId and user_pw = @pswd and mask= 0";

                //SQLインジェクションを防止する
                SqlParameter parameter1 = new SqlParameter("@groupId", SqlDbType.NVarChar)
                {
                    Value = groupId ?? ""
                };

                SqlParameter parameter2 = new SqlParameter("@userId", SqlDbType.NVarChar)
                {
                    Value = userId ?? ""
                };

                SqlParameter parameter3 = new SqlParameter("@pswd", SqlDbType.NVarChar)
                {
                    Value = pswd ?? ""
                };

                parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };
            }
            else
            {
                //クエリのSQL文を定義する
                sql = "select index_no from mst_group where group_id = @groupId and mask= 0";

                //SQLインジェクションを防止する
                SqlParameter parameter = new SqlParameter("@groupId", SqlDbType.NVarChar)
                {
                    Value = groupId ?? ""
                };

                parameters = new SqlParameter[] { parameter };
            }
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    try
                    {
                        cmd.Parameters.AddRange(parameters);
                        if (cmd.ExecuteScalar() != null)
                        {
                            ret = true;

                        }
                        else
                        {
                            ret = false;
                        }
                    }
                    catch (Exception e)
                    {
                        logger.Error(groupId + "-" + userId + ":" + e);
                    }
                    finally
                    {
                        conn.Close();

                    }
                }
            }
            return ret;

        }

        internal static bool IsCorrect(string groupId)
        {
            bool flag = IsCorrect(groupId, null, null);

            return flag;
        }

        /// <summary>
        /// 患者リストを取得
        /// </summary>
        /// <param name="patientRequest"></param>
        /// <returns></returns>
        internal static List<PatientResponse> GetPatient_data(PatientRequest patientRequest)
        {
            string group_id = patientRequest.Certification.Group_id;
            string hosp_id = patientRequest.Certification.Hosp_id;
            string patient_name = patientRequest.Patient_name;
            string visit_id = patientRequest.Visit_id;
            string first_visit = patientRequest.Last_visit;

            string sql = "select tbl_patient.patient_id,";
            sql += "   IsNull(tbl_patient.patient_name,'') as patient_name,";
            sql += "   IsNull(tbl_patient.patient_kana,'') as patient_kana,";
            sql += "   case when tbl_patient.patient_sex = 'M' then '男'";
            sql += "    when tbl_patient.patient_sex = 'F' then '女'";
            sql += "    when tbl_patient.patient_sex IS NULL then ''";
            sql += "   end  as patient_sex,";
            sql += "   case when tbl_patient.patient_birthday IS NULL then ''  ";
            sql += "   else CONVERT(VARCHAR(10), tbl_patient.patient_birthday, 120) ";
            sql += "   end as patient_birthday,";
            sql += "   IsNull(tbl_patient_visit.visit_id,'') as visit_id,";
            sql += "   CASE WHEN tbl_patient_visit.first_visit IS NULL or tbl_patient_visit.first_visit  = '' THEN '' ELSE CONVERT(  VARCHAR (10), tbl_patient_visit.first_visit, 120) END  as first_visit, ";
            sql += "   IsNull(tbl_patient.unique_id,'') as unique_id";
            sql += " from tbl_patient";
            sql += " left join tbl_patient_visit";
            sql += " ON tbl_patient.hosp_id = tbl_patient_visit.hosp_id";
            sql += " and tbl_patient.patient_id = tbl_patient_visit.patient_id";
            sql += " where";
            sql += " tbl_patient.hosp_id = @hosp_id";

            if (Tools.IsCheckParm(visit_id) == true)
            {
                sql += " and tbl_patient_visit.visit_id =  @visit_id";
            }

            if (Tools.IsCheckParm(patient_name) == true)
            {
                sql += " and(tbl_patient.patient_name like '%@patient_name%' or  tbl_patient.patient_kana like '%@patient_name%')";
            }

            if (Tools.IsCheckParm(first_visit) == true)
            {
                sql += " and first_visit = @first_visit";
            }
            sql += " order by patient_kana asc ";

            //SQLインジェクションを防止する
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            SqlParameter paramePatient_name = new SqlParameter("@patient_name", SqlDbType.NVarChar)
            {
                Value = patient_name
            };
            SqlParameter paramVisit_id = new SqlParameter("@visit_id", SqlDbType.NVarChar)
            {
                Value = visit_id
            };
            SqlParameter parameVisit_start = new SqlParameter("@first_visit", SqlDbType.NVarChar)
            {
                Value = first_visit
            };

            SqlParameter[] parameters = new SqlParameter[] { };
            if (Tools.IsCheckParm(patient_name) == true
                && Tools.IsCheckParm(visit_id) == true
                && Tools.IsCheckParm(first_visit) == true)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramePatient_name, paramVisit_id, parameVisit_start };
            }
            else if (Tools.IsCheckParm(patient_name) == false
               && Tools.IsCheckParm(visit_id) == false
               && Tools.IsCheckParm(first_visit) == false)
            {
                parameters = new SqlParameter[] { paramHosp_id };
            }
            else if (Tools.IsCheckParm(patient_name) == true
                && Tools.IsCheckParm(visit_id) == false
                && Tools.IsCheckParm(first_visit) == false)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramePatient_name };
            }
            else if (Tools.IsCheckParm(patient_name) == true
                && Tools.IsCheckParm(visit_id) == true
                && Tools.IsCheckParm(first_visit) == false)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramePatient_name, paramVisit_id };
            }
            else if (Tools.IsCheckParm(patient_name) == true
                && Tools.IsCheckParm(visit_id) == false
                && Tools.IsCheckParm(first_visit) == true)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramePatient_name, parameVisit_start };
            }
            else if (Tools.IsCheckParm(patient_name) == false
                && Tools.IsCheckParm(visit_id) == true
                && Tools.IsCheckParm(first_visit) == true)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramVisit_id, parameVisit_start };
            }
            else if (Tools.IsCheckParm(patient_name) == false
                && Tools.IsCheckParm(visit_id) == false
                && Tools.IsCheckParm(first_visit) == true)
            {
                parameters = new SqlParameter[] { paramHosp_id, parameVisit_start };
            }
            else if (Tools.IsCheckParm(patient_name) == false
                && Tools.IsCheckParm(visit_id) == true
                && Tools.IsCheckParm(first_visit) == false)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramVisit_id };
            }


            List<PatientResponse> terminals = new List<PatientResponse>();


            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    sql = sql.Replace("@patient_name", patient_name);
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    PatientResponse patient = new PatientResponse
                                    {
                                        Group_id = group_id,
                                        Hosp_id = hosp_id,
                                        Patient_id = (string)reader[0],
                                        Patient_name = (string)reader[1],
                                        Patient_kana = (string)reader[2],
                                        Patient_sex = (string)reader[3],
                                        Patient_birthday = (string)reader[4],
                                        Visit_id = (string)reader[5],
                                        Last_visit = (string)reader[6],
                                        Unique_id = (string)reader[7]
                                    };
                                    terminals.Add(patient);
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(patientRequest.Certification.Hosp_id + "-" + patientRequest.Certification.User_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }
            }
            return terminals;
        }
        /// <summary>
        /// 施設リスト取得する
        /// </summary>
        /// <param name="hosp_id"></param>
        /// <returns></returns>
        internal static List<FacilityReponse> GetFacility_data(string hosp_id)
        {
            string sql = "select visit_id, visit_name";
            sql += " from mst_visit";
            sql += " where";
            sql += " (visit_kbn ='2' or visit_kbn ='3') ";
            sql += " and mask ='0'";
            sql += " and hosp_id = @hosp_id";

            //SQLインジェクションを防止する
            SqlParameter parameter = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter };
            List<FacilityReponse> terminals = new List<FacilityReponse>();
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    FacilityReponse facility = new FacilityReponse();
                                    facility.Visit_id = (string)reader[0];
                                    facility.Visit_name = (string)reader[1];
                                    terminals.Add(facility);
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(hosp_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }
            }
            return terminals;
        }

        /// <summary>
        /// 認証キーをチェックする
        /// </summary>
        /// <param name="groupID"></param>
        /// <param name="user_id"></param>
        /// <param name="mediaAuth"></param>
        /// <returns></returns>
        internal static bool KEY_CHK(string groupID, string user_id, string mediaAuth)
        {
            //クエリのSQL文を定義する
            string sql = "select media_auth from tbl_session ";
            sql += " WHERE regist_datetime <= getdate()";
            sql += " and regist_datetime >= dateadd(day, -1, getdate())";
            sql += " and session_flg = '3'";
            sql += " and group_id = @group_id";
            sql += " and user_id = @user_id";
            sql += " and media_auth = @media_auth";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = groupID ?? ""
            };

            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id ?? ""
            };

            SqlParameter parameter3 = new SqlParameter("@media_auth", SqlDbType.NVarChar)
            {
                Value = mediaAuth ?? ""
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        try
                        {
                            if (cmd.ExecuteScalar() != null)
                            {
                                return true;
                            }
                        }
                        catch (Exception ex)
                        {
                            conn.Close();
                            ex.Message.ToString();
                        }
                        return false;
                    }
                }
                catch (Exception e)
                {
                    logger.Error(groupID + "-" + user_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }
                return false;

            }
        }

        //tbl_session登録
        internal static bool InsertTblSession(string user_id, string hosp_id, string group_id, string terminal_id)
        {
            bool sqlrtn = false;
            try
            {
                string sqlString = "";
                sqlString = "insert into tbl_session( ";
                sqlString += "user_id, ";
                sqlString += "group_id, ";
                sqlString += "hosp_id, ";
                sqlString += "terminal_id, ";
                sqlString += "session_flg, ";
                sqlString += "media_auth, ";
                sqlString += "regist_datetime) ";
                sqlString += "values( ";
                sqlString += "@user_id, ";
                sqlString += "@group_id, ";
                sqlString += "@hosp_id, ";
                sqlString += "@terminal_id, ";
                sqlString += "'3', ";
                sqlString += "'" + Tools.GenerateAuthKey(20) + "', ";
                sqlString += "getdate()) ";

                SqlParameter parameter1 = new SqlParameter("@user_id", SqlDbType.NVarChar)
                {
                    Value = user_id
                };
                SqlParameter parameter2 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = hosp_id
                };
                SqlParameter parameter3 = new SqlParameter("@group_id", SqlDbType.NVarChar)
                {
                    Value = group_id
                };
                SqlParameter parameter4 = new SqlParameter("@terminal_id", SqlDbType.NVarChar)
                {
                    Value = terminal_id
                };
                SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3, parameter4 };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(sqlString, conn))
                        {
                            cmd.Parameters.AddRange(parameters);

                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                sqlrtn = true;
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        logger.Error(hosp_id + "-" + user_id + ":" + e);
                    }
                    finally
                    {
                        conn.Close();
                    }

                }
            }
            catch (Exception e)
            {
                logger.Error(hosp_id + "-" + user_id + ":" + e);
            }
            return sqlrtn;
        }

        //TBL_SESSION削除
        internal static bool DelTblSession(Certification cert)
        {
            bool sqlrtn = false;
            string sql = "";

            //ログアウト時
            sql = "delete tbl_session ";
            sql += "where ";
            sql += " user_id = @user_id ";
            sql += " and group_id = @group_id ";
            sql += " and session_flg = '3' ";
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = cert.Group_id
            };

            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = cert.User_id
            };
            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 };
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);

                        int num = cmd.ExecuteNonQuery();

                        if (num > 0)
                        {
                            sqlrtn = true;
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }

            }
            return sqlrtn;
        }


        /// <summary>
        /// 医院リスト取得する
        /// </summary>
        /// <param name="groupID"></param>
        /// <returns></returns>
        internal static List<ClinicReponse> GetClinic_data(string groupID, string user_id)
        {
            string sql = "select distinct mst_user_hosp.hosp_id,mst_hosp.hosp_name";
            sql += " from mst_user_hosp";
            sql += " INNER join mst_hosp";
            sql += " ON mst_user_hosp.hosp_id = mst_hosp.hosp_id";
            sql += " where mst_user_hosp.group_id = @group_id";
            sql += " and mst_user_hosp.user_id = @user_id";
            sql += " and mst_hosp.mask = '0'";
            sql += " and mst_user_hosp.effect_date_from <= GETDATE()";
            sql += " and mst_user_hosp.effect_date_to >= GETDATE()";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = groupID
            };
            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 };
            List<ClinicReponse> terminals = new List<ClinicReponse>();
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        SqlDataReader reader = cmd.ExecuteReader();
                        try
                        {
                            while (reader.Read())
                            {
                                ClinicReponse clinicReponse = new ClinicReponse();
                                ClinicReponse hosp = clinicReponse;
                                hosp.Hosp_id = (string)reader[0];
                                hosp.Hosp_name = (string)reader[1];
                                terminals.Add(hosp);
                            }
                        }
                        finally
                        {
                            reader.Close();
                        }

                    }
                }
                catch (Exception e)
                {
                    logger.Error(groupID + "-" + user_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }

            }

            return terminals;
        }
    }
}