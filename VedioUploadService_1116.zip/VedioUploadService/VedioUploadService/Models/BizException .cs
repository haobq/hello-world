﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace VedioUploadService
{
    [Serializable()]
    public class BizException : Exception
    {
        public string ErrorCode { get; }

        public BizException()
            : base()
        {
        }

        public BizException(string errorCode,string message)
            : base(message)
        {
            ErrorCode = errorCode;
        }

        public BizException(string errorCode,string message, Exception innerException)
            : base(message, innerException)
        {
            ErrorCode = errorCode;
        }

        //逆シリアル化コンストラクタ。このクラスの逆シリアル化のために必須。
        //アクセス修飾子をpublicにしないこと！（詳細は後述）
        protected BizException(string errorCode,SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            ErrorCode = errorCode;
        }
    }
}