/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.meida.video.common;

import java.awt.Color;

/**
 * 概要：FRMAE使用する定数を定義
 *
 */
public interface BasConst {
	/** 動画ファイルの拡張子 */
	public static String EXTENSION = ".mp4";
	/** 動画ファイルのアップロード状況「未処理」 */
	public static String STATUS_NEW = "未";
	/** 動画ファイルのアップロード状況「処理中」 */
	public static String STATUS_WORKING = "中";
	/** 動画ファイルのアップロード状況「処理完了」 */
	public static String STATUS_COMPLETED = "完";
	/** 動画フォルダの管理用JSON */
	public static String MANAGER_JSON = "Manager.json";
	/** ファイルパスの区切り文字 */
	public static String FILE_SEPARATOR = "/";

	/** ファイル選択 */
	public static String FILE_TITLE_CHECKED = "選択";
	/** ファイル状況 */
	public static String FILE_TITLE_STATAS = "状況 ";
	/** ファイル名称 */
	public static String FILE_TITLE_NAME = "ファイル名称";
	/** ファイル最新更新日時 */
	public static String FILE_TITLE_LASTED_UPDATE = "ファイル最新更新日時";
	/** ファイルサイズ*/
	public static String FILE_TITLE_SIZE = "サイズ(byte)";
	/** ファイルサイズ*/
	public static String FILE_TITLE_BIKOU = "備考";
	/** アップロードファイル名*/
	public static String FILE_TITLE_UPLOAD_FILE_NAME = "アップロードファイル名";
	
	/** JSONファイル状況 */
	public static String JSON_TITLE_STATAS = "状況 ";
	/** JSONファイル名称 */
	public static String JSON_TITLE_NAME = "ファイル名称";

	/** フォルダ選択ボタン*/
	public static String BUTTON_FOLD_SELECT = "フォルダ選択 ";
	/** 患者検索*/
	public static String TXT_FIND = "患者検索 ";
	/** 患者検索*/
	public static String BUTTON_FIND = "検索";
	/** 保存*/
	public static String BUTTON_SAVE = "保存";
	/** 送信*/
	public static String BUTTON_SEND = "送    信";
	/** キャンセル*/
	public static String BUTTON_CANEL = "キャンセル";
	/** 削除*/
	public static String BUTTON_DELETE = "削    除";
	/** 備考*/
	public static String TEXTARIA_BIKOU = "備考";
	/** ステータスバー状況 */
	public static String STATUSBAR_TITLE_STATAS = "  状況: ";

	/** ファイル一覧高さ*/
    public final static int FILE_LIST_HEIGHT = 250;


	/** ウィンドウズ幅*/
	public static final double WINDOWS_WHITH = 1100;
	/** ウィンドウズ高さ*/
	public static final double WINDOWS_HEIGHT = 600;


	public final static String FONT_NAME = "ＭＳ Ｐゴシック";
    public final static String  FONT_NORM_STYLE = "bold";

    public final static int FONT_BOLD_STYLE = 1;

    // public final static int LFC_FONT_BOLD_STYLE = 0;
    public final static int FONT_NORM_SIZE = 15;

    public final static int FONT_TITLE_SIZE = 16;
	/** 画面レイヤ */
	public final static int LEASE_MAIN_LAYER = 0;
	/** 画面タイトルを格納の最大数 */
	public final static int MAX_IFRAME_COUNT = 20;
	// 1列ﾏｽﾀ
	public final static int MST_COLUME_ONE = 1;
	// 2列ﾏｽﾀ
	public final static int MST_COLUME_TWO = 2;
	// 3列ﾏｽﾀ
	public final static int MST_COLUME_THREE = 3;
	// 4列ﾏｽﾀ
	public final static int MST_COLUME_FOUR = 4;
	// 方向区分の左
	public final static int DIRECTION_LEFT = 1;
	// 方向区分の右
	public final static int DIRECTION_RIGHT = 2;
	// 方向区分の上
	public final static int DIRECTION_UP = 3;
	// 方向区分の下
	public final static int DIRECTION_DOWN = 4;

	// 一桁のｽﾍﾟｰｽ
	public final static String ONE_SPACE = " ";
	public final static String SYSTEM_NAME = "動画管理システム";

	// DateﾀｲﾌﾟYYYY/MM/DD
	public final static String DATE_TYPE_YYYY_MM_DD = "yyyy/MM/dd";
	// DateﾀｲﾌﾟYYYY/MM
	public final static String DATE_TYPE_YYYY_MM = "yyyy/MM";
	// DateﾀｲﾌﾟHH:MM
	public final static String DATE_TYPE_HH_MM = "HH:mm";
	// Dateﾀｲﾌﾟ"YYYY/MM/DD HH:MM:SS"
	public final static String DATE_TYPE_YYYY_MM_DD_HH_MM = "yyyy/MM/dd HH:mm:ss";
	// Dateﾀｲﾌﾟ"HH:MM:SS"
	public final static String DATE_TYPE_HH_MM_SS = "HH:mm:ss";

	// 入力可能な文字を羅列した文字列
	public static final String CHARS = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖ" +
			"ﾗﾘﾙﾚﾛﾝｦﾜｧｨｩｪｫｬｭｮｯﾞﾟ､｡ｰABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz" +
			"0123456789!\"#$%&'()-=^~\\|@`[{;+:*]},<.>/?_ ";
	//入力可能な文字を羅列した数字列と文字列
	public static final String ENG_CHAR = "0123456789"
			+ "abcdefghijklmnopqrstuvwxyz"
			+ "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	// 入力可能な文字を羅列した数字列
	public static final String NUM = "0123456789";
	// 入力可能な文字を羅列した数字列
	public static final String MINUS = "-0123456789";
	// 入力可能な文字を羅列した小数列
	public static final String FLOAT = "-0123456789.";
	// 入力可能な文字を羅列した金額列
	public static final String CURRENCY = "0123456789,";
	// 入力可能な文字を羅列した日期列
	public static final String DATE = "0123456789/";
	public static final String TIME = "0123456789:";
	// 入力可能な文字を羅列した電話列
	public static final String TELZIP = "0123456789-%";
	// 全角
	public static final int FULL = 0;
	// 半角
	public static final int HALF = 1;
	// 初期状態データを入力していない
	public static final int BEAN_STATE_NOINPUT = 0;
	// データ入力中
	public static final int BEAN_STATE_INPUTING = 1;
	// データ入力完了（エラー）
	public static final int BEAN_STATE_INPUTERR = 2;
	// データ入力完了（入力完了）
	public static final int BEAN_STATE_SUCCESS = 3;
	// ﾃﾞｰﾀタイプ 整数
	public static final int DATA_NUMERIC = 0;
	// ﾃﾞｰﾀタイプ 小数
	public static final int DATA_FLOAT = 1;
	// ﾃﾞｰﾀタイプ 全角文字
	public static final int DATA_FULL = 2;
	// ﾃﾞｰﾀタイプ 半角文字
	public static final int DATA_HALF = 3;
	// ﾃﾞｰﾀタイプ 金額 カンマあり
	public static final int DATA_AMOUNT = 4;
	// ﾃﾞｰﾀタイプ  電話番号と郵便番号
	public static final int DATA_TEL = 5;
	// ﾃﾞｰﾀタイプ  日付 YYYY/MM/DD
	public static final int DATA_DATE_YMD = 6;
	// ﾃﾞｰﾀタイプ  日付 YYYY/MM
	public static final int DATA_DATE_YM = 7;
	// ﾃﾞｰﾀタイプ  日付 HH:MM:SS
	public static final int DATA_DATE_HMS = 8;
	// ﾃﾞｰﾀタイプ  日付 HH:MM
	public static final int DATA_DATE_HM = 9;
	// ﾃﾞｰﾀタイプ  日付 YYYY/MM/DD HH:MM
	public static final int DATA_DATE_YMDHM = 10;
	// ﾃﾞｰﾀタイプ  日付 YYYY/MM/DD HH:MM:SS
	public static final int DATA_DATE_YMDHMS = 11;
	// ０：文字
	public static final int TABLE_COLUMN_TYPE_TXT = 0;
	// 1：数字
	public static final int TABLE_COLUMN_TYPE_NUM = 1;
	// 2：金額
	public static final int TABLE_COLUMN_TYPE_CUR = 2;
	// ３：電話
	public static final int TABLE_COLUMN_TYPE_TEL = 3;
	// ４：日期
	public static final int TABLE_COLUMN_TYPE_DATE = 4;
	// ５：年月
	public static final int TABLE_COLUMN_TYPE_YM = 5;

	public final static int EXE_OK = 0;
	public final static int EXE_ERR = 1;

	public final static Color BK_COLOR = new Color(153, 176, 255);

	public final static int DATE_ADD_YEAR = 0;
	public final static int DATE_ADD_MONTH = 1;
	public final static int DATE_ADD_DAY = 2;
}
