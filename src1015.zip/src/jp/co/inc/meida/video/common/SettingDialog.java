package jp.co.inc.meida.video.common;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import jp.co.inc.meida.video.utils.FileProperty;

public class SettingDialog extends Stage {

	public SettingDialog(Stage owner) throws Exception {
		super();
		initOwner(owner);
		setTitle("設定画面");
		Group root = new Group();
		Scene scene = new Scene(root, 300, 250, Color.WHITE);
		setScene(scene);

		String proFilePath = System.getProperty("user.dir").replace("\\", "/") + "/conf/system.ini";

		GridPane gridpane = new GridPane();
		gridpane.setPadding(new Insets(5));
		gridpane.setHgap(5);
		gridpane.setVgap(5);

		Label groupNameLbl = new Label("グループID: ");
		gridpane.add(groupNameLbl, 0, 1);

		Label proxyUrlNameLbl = new Label("プロキシURL: ");
		gridpane.add(proxyUrlNameLbl, 0, 2);

		Label proxyPortNameLbl = new Label("プロキシポート: ");
		gridpane.add(proxyPortNameLbl, 0, 3);

		Label proxyUserLbl = new Label("ユーザー名: ");
		gridpane.add(proxyUserLbl, 0, 4);

		Label proxyPasswordLbl = new Label("パスワード: ");
		gridpane.add(proxyPasswordLbl, 0, 5);

		Label proxyActiveLbl = new Label("有効: ");
		gridpane.add(proxyActiveLbl, 0, 6);

		Label workPathLbl = new Label("作業フォルダ: ");
		gridpane.add(workPathLbl, 0, 7);

		FileProperty filePro = new FileProperty(proFilePath);
		String WorkingDirJson = filePro.getProperty("WorkingDirJson");
		final TextField groupNameFld = new TextField(filePro.getProperty("groupid"));
		groupNameFld.setPrefWidth(200);
		gridpane.add(groupNameFld, 1, 1);

		final TextField proxyUrlFld = new TextField(filePro.getProperty("proxyurl"));
		proxyUrlFld.setPrefWidth(200);
		gridpane.add(proxyUrlFld, 1, 2);

		final TextField proxyPortFld = new TextField(filePro.getProperty("proxyport"));
		proxyPortFld.setPrefWidth(200);
		gridpane.add(proxyPortFld, 1, 3);

		final TextField userNameFld = new TextField(filePro.getProperty("proxyuser"));
		userNameFld.setPrefWidth(200);
		gridpane.add(userNameFld, 1, 4);

		final PasswordField passwordFld = new PasswordField();
		passwordFld.setText(filePro.getProperty("password"));
		passwordFld.setPrefWidth(200);
		gridpane.add(passwordFld, 1, 5);

		final CheckBox checkFld = new CheckBox();
		checkFld.setPrefWidth(30);
		String active = filePro.getProperty("active");
		if ("true".equals(active)) {
			checkFld.setSelected(true);
		}
		gridpane.add(checkFld, 1, 6);

		final TextField workPathFld = new TextField(filePro.getProperty("WorkingDir"));
		workPathFld.setPrefWidth(200);
		gridpane.add(workPathFld, 1, 7);

		HBox bottomNode = new HBox(10.0);

		Button saveBtn = new Button("保存");
		saveBtn.setPrefWidth(100);
		saveBtn.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
                try {
            		FileProperty filePro = new FileProperty(proFilePath);
            		filePro.setProperty("WorkingDirJson",WorkingDirJson);
            		filePro.setProperty("WorkingDir", workPathFld.getText().replace("\\", ""));
            		filePro.setProperty("groupid", groupNameFld.getText());
            		filePro.setProperty("proxyurl", proxyUrlFld.getText());
            		filePro.setProperty("proxyport", proxyPortFld.getText());
            		filePro.setProperty("proxyuser", userNameFld.getText());
            		filePro.setProperty("password", passwordFld.getText());
					if (checkFld.isSelected()) {
						filePro.setProperty("active", "true");
					}else {
						filePro.setProperty("active", "false");
					}
            		filePro.storeProperty();
                } catch (Exception e) {
        			e.printStackTrace();
        		}
				close();
			}
		});

		Button canelBtn = new Button("	キャンセル");
		canelBtn.setAlignment(Pos.CENTER);
		canelBtn.setPrefWidth(100);
		canelBtn.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				close();
			}
		});

		bottomNode.getChildren().addAll(saveBtn, canelBtn);
		bottomNode.setAlignment(Pos.CENTER);
		gridpane.add(bottomNode, 1, 8);
		GridPane.setHalignment(saveBtn, HPos.RIGHT);
		root.getChildren().add(gridpane);
	}
}