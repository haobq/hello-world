package jp.co.inc.meida.video.frame;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import jp.co.inc.meida.video.common.BasConst;
import jp.co.inc.meida.video.common.BasFrame;

public class CallMainFrame extends Application implements  BasConst  {

	private boolean _isFromFirstBoot = false;
	
	BasFrame callBaseFrm;
	
	/**
	 * コンストラクタ．     <BR>
	 *
	 *<PRE>
	 * 初期処理(jbInit)を実行する。
	 *</PRE>
	 * @see  #jbInit()
	 *
	 */
//	public CallMainFrame(boolean isFromFirstBoot) {
//		set_isFromFirstBoot(isFromFirstBoot);
//		try {
////			BootBean calBootBean = new BootBean();
////			calBootBean.readSystemInfo();
////			set_isFromFirstBoot(true);
////			//初期化処理
////			doInitThread();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	
//	public void doInitThread() {
//		ThreadCreateMainFrm threadCreateMainFrm = new ThreadCreateMainFrm();
//		GetCntrctInstance cntrctInstance = new GetCntrctInstance();
//		try {
//			threadCreateMainFrm.join();
//			cntrctInstance.join();
//		} catch (Exception e) {
//		}
//	}
//	
//	class ThreadCreateMainFrm extends Thread {
//		public ThreadCreateMainFrm() {
//			setPriority(4);
//			start();
//		}
//
//		public void run() {
//			try {
//				jbInit();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//	}
//	
//	/**
//	 * 初期処理．    <BR>
//	 *
//	 * @return     なし
//	 * @Exception  異常のException
//	 *
//	 */
//	private void jbInit() throws Exception {
//
////	    Toolkit tk = Toolkit.getDefaultToolkit();
////	    int xSize = (int) tk.getScreenSize().getWidth();
////	    int ySize = ((int) tk.getScreenSize().getHeight());
////	    callBaseFrm.setSize(xSize,ySize);
//	}
//	
//	public void set_isFromFirstBoot(boolean _isFromFirstBoot) {
//		this._isFromFirstBoot = _isFromFirstBoot;
//	}
//	
//	class GetCntrctInstance extends Thread {
//		public GetCntrctInstance() {
//			setPriority(10);
//			start();
//		}
//
//		public void run() {
//
//		}
//	}
	
	/**
	 * 画面スタート
	 * @param primaryStage
	 */
	@Override
	public void start(Stage primaryStage) {
		callBaseFrm = new BasFrame();
		callBaseFrm.start( primaryStage );
		
		
		
//		ESplash esplash = new ESplash();
//		esplash.setSize(405, 215);
//		esplash.setVisible(true);
//		BasInfoBean.setLoadFrm(esplash);
		
//		CallMainFrame lf = new CallMainFrame(false);
//		try {
//            Thread.sleep(1000*5);//1000 is 1 second
//	    } catch (InterruptedException e1) {
//	        Thread.currentThread().interrupt();
//	        e1.printStackTrace();
//	    }
//		lf.setTitle(SYSTEM_NAME);
//	    Toolkit tk = Toolkit.getDefaultToolkit();
//	    int xSize = (int) tk.getScreenSize().getWidth();
//	    int ySize = ((int) tk.getScreenSize().getHeight());
//	    lf.setSize(xSize,ySize);
//		lf.setVisible(true);
		
//		esplash.setVisible(false);
		
		
		// 終了 イベント登録
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
		    @Override
		    public void handle(WindowEvent event) {

		        Platform.exit();

		        Thread start = new Thread(new Runnable() {
		            @Override
		            public void run() {


		            	System.out.println("End");
		            }
		        });

		        start.start();
		    }
		});
		
	}

	/**
	 * メイン
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);

	}


	
}

