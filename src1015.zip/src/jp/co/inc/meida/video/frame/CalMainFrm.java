package jp.co.inc.meida.video.frame;

import jp.co.inc.meida.video.common.BasFrame;

public class CalMainFrm extends BasFrame {

	public CalMainFrm(){

	}
}

