package jp.co.inc.meida.video.utils;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Bounds;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import javafx.stage.Window;
import jp.co.inc.meida.video.common.MessageConst;

public class Messagebox implements MessageConst {

	public static void Error(Stage parentStage, String errMsg) {
		Alert dialog = new Alert(AlertType.ERROR, errMsg, new ButtonType[] {
				new ButtonType("確認", ButtonData.OK_DONE) });
		Window owner = parentStage;
		dialog.getDialogPane().layoutBoundsProperty().addListener(
				new ChangeListener<Bounds>() {
					@Override
					public void changed(ObservableValue<? extends Bounds> observable,
							Bounds oldValue, Bounds newValue) {
						if (newValue != null &&
								newValue.getWidth() > 0 && newValue.getHeight() > 0) {
							double x = owner.getX() + owner.getWidth() / 2;
							double y = owner.getY() + owner.getHeight() / 2;
							dialog.setX(x - newValue.getWidth() / 2);
							dialog.setY(y - newValue.getHeight() / 2);
							dialog.getDialogPane()
									.layoutBoundsProperty().removeListener(this);
						}
					}
				});
		dialog.showAndWait();
	}

	public static void Info(Stage parentStage, String infoMsg) {
		Alert dialog = new Alert(AlertType.INFORMATION, infoMsg, new ButtonType[] {
				new ButtonType("確認", ButtonData.OK_DONE) });
		Window owner = parentStage;
		dialog.getDialogPane().layoutBoundsProperty().addListener(
				new ChangeListener<Bounds>() {
					@Override
					public void changed(ObservableValue<? extends Bounds> observable,
							Bounds oldValue, Bounds newValue) {
						if (newValue != null &&
								newValue.getWidth() > 0 && newValue.getHeight() > 0) {
							double x = owner.getX() + owner.getWidth() / 2;
							double y = owner.getY() + owner.getHeight() / 2;
							dialog.setX(x - newValue.getWidth() / 2);
							dialog.setY(y - newValue.getHeight() / 2);
							dialog.getDialogPane()
									.layoutBoundsProperty().removeListener(this);
						}
					}
				});
		dialog.showAndWait();
	}
}
