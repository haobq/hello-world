﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class ClinicReponse
    {
        //医院ID
        public string Hosp_id { get; set; }
        //医院名
        public string Hosp_name { get; set; }
    }
}