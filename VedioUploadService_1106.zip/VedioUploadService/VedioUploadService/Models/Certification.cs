﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class Certification
    {
        //グループID
        public string Group_id { get; set; }
        //医院ID
        public string Hosp_id { get; set; }
        //UserID
        public string User_id { get; set; }
        //セッション内の認証文字列
        public string Media_auth { get; set; }
    }
}