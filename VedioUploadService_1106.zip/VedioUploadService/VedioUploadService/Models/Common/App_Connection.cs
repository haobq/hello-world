﻿using System.Configuration;
using System;
using System.Data;
using System.Data.Odbc;

/// <summary>
/// DB接続関連
/// </summary>
public class App_Connection : System.Web.UI.Page
{
  public OdbcConnection sqlCon = new OdbcConnection(ConfigurationManager.ConnectionStrings["sqlsvr"].ConnectionString);

  OdbcConnection dbCon = null;
  OdbcDataAdapter dbAda = null;
  OdbcCommand dbCom = null;
  Object thisLock = new Object();

  /// <summary>
  /// sqlセレクトアイテム
  /// </summary>
  /// <param name="sentence"></param>
  /// <param name="selectItem"></param>
  /// <returns></returns>
  public string sqlSelect(string sentence, string selectItem)
  {
    string returnItem = "-1";
    lock (thisLock)
    {
      try
      {
        DataTable dataTable = new DataTable();
        dbCon.Open();
        dbCom.Connection = dbCon;
        dbAda.SelectCommand = dbCom;
        dbCom.CommandText = sentence;
        dbAda.Fill(dataTable);

        if (dataTable.Rows.Count <= 0) returnItem = "";
        else returnItem = dataTable.Rows[0][selectItem].ToString();

        dataTable.Dispose();
        dbCon.Close();
      }
      catch (OdbcException ex)
      {
        dbCon.Close();
        // log();
        return returnItem;
      }
    }
    return returnItem;
  }

  /// <summary>
  /// SQLインサート
  /// </summary>
  /// <param name="sentence"></param>
  /// <returns></returns>
  public bool sqlInsert(string sentence)
  {
    lock (thisLock)
    {
      OdbcTransaction dbTra = null;
      try
      {
        dbCon.Open();
        dbCom.CommandText = sentence;
        dbTra = dbCon.BeginTransaction();
        dbCom.Transaction = dbTra;
        dbCom.ExecuteNonQuery();
        dbTra.Commit();
        dbCon.Close();
      }
      catch (Exception ex)
      {
        dbTra.Rollback();
        dbCon.Close();
        // log();
        return false;
      }
    }
    return true;
  }

  /// <summary>
  /// SQLアップデート
  /// </summary>
  /// <param name="sentence"></param>
  /// <returns></returns>
  public bool sqlUpdate(string sentence)
  {
    lock (thisLock)
    {
      OdbcTransaction dbTra = null;
      try
      {
        dbCon.Open();
        dbAda.UpdateCommand = dbCom;
        //dbAda.InsertCommand = dbCom;
        dbCom.CommandText = sentence;
        dbTra = dbCon.BeginTransaction();
        dbCom.Transaction = dbTra;
        dbCom.ExecuteNonQuery();
        dbTra.Commit();
        dbCon.Close();
      }
      catch (Exception ex)
      {
        dbTra.Rollback();
        dbCon.Close();
        // log();
        return false;
      }
    }
    return true;
  }

  /// <summary>
  /// SQLデリート
  /// </summary>
  /// <param name="sentence"></param>
  /// <returns></returns>
  public bool sqlDelete(string sentence)
  {
    lock (thisLock)
    {
      OdbcTransaction dbTra = null;
      try
      {
        dbCon.Open();
        dbCom.CommandText = sentence;
        dbTra = dbCon.BeginTransaction();
        dbCom.Transaction = dbTra;
        dbCom.ExecuteNonQuery();
        dbTra.Commit();
        dbCon.Close();
      }
      catch (Exception ex)
      {
        dbTra.Rollback();
        dbCon.Close();
        //log();
        return false;
      }
    }
    return true;
  }

  /// <summary>
  /// SQLセレクトテーブル
  /// </summary>
  /// <param name="sentence"></param>
  /// <param name="dataTbl"></param>
  /// <returns></returns>
  public bool sqlSelectTable(string sentence, ref DataTable dataTbl)
  {
    lock (thisLock)
    {
      try
      {
        dbCon.Open();
        dbCom.Connection = dbCon;
        dbAda.SelectCommand = dbCom;
        dbCom.CommandText = sentence;
        dbAda.Fill(dataTbl);
        dbCon.Close();
      }
      catch (OdbcException ex)
      {
        dbCon.Close();
        // log();
        return false;
      }
    }
    return true;
  }

  /// <summary>
  /// SQLセレクトデータセット
  /// </summary>
  /// <param name="sentence"></param>
  /// <param name="dataSet"></param>
  /// <param name="tableName"></param>
  /// <returns></returns>
  public bool sqlSelectDataSet(string sentence, ref System.Data.DataSet dataSet, string tableName)
  {
    lock (thisLock)
    {
      try
      {
        dbCon.Open();
        dbCom.Connection = dbCon;
        dbAda.SelectCommand = dbCom;
        dbCom.CommandText = sentence;
        dbAda.Fill(dataSet, tableName);
        dbCon.Close();
      }
      catch (OdbcException ex)
      {
        dbCon.Close();
        // log();
        return false;
      }
    }
    return true;
  }



  ///// <summary>
  ///// DATABASEオープン
  ///// </summary>
  ///// <returns></returns>
  //public bool DataBaseOpen(string server, string database, string user, string password)
  //{
  //  lock (thisLock)
  //  {
  //    try
  //    {
  //      string connectionParamater = string.Format(@"SERVER={0};DRIVER={{SQL Server}};DATABASE={1};UID={2};PWD={3};",
  //                      server, database, user, password);
  //      dbCon = new OdbcConnection();
  //      dbCon.ConnectionString = connectionParamater;
  //      dbAda = new OdbcDataAdapter();
  //      dbCom = new OdbcCommand();

  //      try
  //      {
  //        dbCon.Open();
  //      }
  //      catch (OdbcException ex)
  //      {
  //        ErrorMessage = ex.ToString();
  //        return false;
  //      }

  //      // SQLCommandに接続先を設定
  //      dbCom.Connection = dbCon;

  //      // AdapterのSQL設定
  //      dbAda.SelectCommand = dbCom;
  //      dbAda.UpdateCommand = dbCom;
  //      dbAda.InsertCommand = dbCom;
  //      dbAda.SelectCommand.Connection = dbCon;
  //    }
  //    catch (OdbcException ex)
  //    {
  //      ErrorMessage = ex.ToString();
  //      return false;
  //    }
  //  }
  //  return true;
  //}


}