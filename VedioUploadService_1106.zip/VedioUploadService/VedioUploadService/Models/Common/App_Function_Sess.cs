﻿partial class App_Function
{

  /// <summary>
  /// セッション値の入出力
  /// </summary>
  public ISess<ISessionId> mySession
  {
    get { return this._Sess; }
  }

  private ISess<ISessionId> _Sess;

  protected void setSess(ISess<ISessionId> value) { this._Sess = value; }

  public interface ISess<TSessionId> where TSessionId : ISessionId
  {
    string group_id { get; set; }
    string login_id { get; set; }
    string login_name { get; set; }
    string hosp_id { get; set; }
    string hosp_name { get; set; }
    string terminal_id { get; set; }
    string team_id { get; set; }
    string option_karte_reference { get; set; }
    string option_photo { get; set; }
    string option_profile { get; set; }
    string login_date { get; set; }
  }

  public interface ISessionId
  {
    string group_id { get; }
    string login_id { get; }
    string login_name { get; }
    string hosp_id { get; }
    string hosp_name { get; }
    string terminal_id { get; }
    string team_id { get; }
    string option_karte_reference { get; }
    string option_photo { get; }
    string option_profile { get; }
    string login_date { get; }
  }

}
