﻿partial class App_Function
{

  private class SessionIdImpl : ISessionId
  {
    public string group_id { get; } = CommonSessionIds.group_id;
    public string login_id { get; } = CommonSessionIds.login_id;
    public string login_name { get; } = CommonSessionIds.login_name;
    public string hosp_id { get; } = CommonSessionIds.hosp_id;
    public string hosp_name { get; } = CommonSessionIds.hosp_name;
    public string terminal_id { get; } = CommonSessionIds.terminal_id;
    public string team_id { get; } = CommonSessionIds.team_id;
    public string option_karte_reference { get; } = CommonSessionIds.option_karte_reference;
    public string option_photo { get; } = CommonSessionIds.option_photo;
    public string option_profile { get; } = CommonSessionIds.option_profile;
    public string login_date { get; } = CommonSessionIds.login_date;
  }

  protected static class CommonSessionIds
  {
    public const string group_id = "GROUP_ID";
    public const string login_id = "LOGIN_ID";
    public const string login_name = "LOGIN_NAME";
    public const string hosp_id = "HOSP_ID";
    public const string hosp_name = "HOSP_NAME";
    public const string terminal_id = "TERMINAL_ID";
    public const string team_id = "TEAM_ID";
    public const string option_karte_reference = "OPTION_KARTE_REFERENCE";
    public const string option_photo = "OPTION_PHOTO";
    public const string option_profile = "OPTION_PROFILE";
    public const string login_date = "LOGIN_DATE";
  }

}
