﻿using System;

public static class PostMessageSettings
{
  public static class Target
  {
  }

  public static class WithYou
  {
  }

  public static class MediaApps
  {
    public const string Origin = "*.withyou.media:*";
  }

  public static class Profile
  {
    public static string Target5Url(string baseUriString) { return new Uri(new Uri(baseUriString), "PMIf5").ToString(); }
    public static string GetTarget5Url(string baseUriString) { var uri = new UriBuilder(Target5Url(baseUriString)); uri.Query = "?t=" + DateTime.Now.Ticks.ToString(); return uri.ToString(); }
    public static string Target6Url(string baseUriString) { return new Uri(new Uri(baseUriString), "PMIf6").ToString(); }
    public static string GetTarget6Url(string baseUriString) { var uri = new UriBuilder(Target6Url(baseUriString)); uri.Query = "?t=" + DateTime.Now.Ticks.ToString(); return uri.ToString(); }
  }
}
