﻿partial class App_Function
{

  /// <summary>
  /// セッション値の入出力の実装
  /// </summary>
  protected class SessImpl : ISess<ISessionId>
  {
    private App_Function _parent { get; }
    private ISessionId _sessionId { get; }

    public SessImpl(App_Function parent, ISessionId sessionId)
    {
      this._parent = parent;
      this._sessionId = sessionId;
    }

    public string group_id
    {
      get { return this._parent.getSession(this._sessionId.group_id); }
      set { this._parent.Session[this._sessionId.group_id] = value; }
    }

    public string login_id
    {
      get { return this._parent.getSession(this._sessionId.login_id); }
      set { this._parent.Session[this._sessionId.login_id] = value; }
    }

    public string login_name
    {
      get { return this._parent.getSession(this._sessionId.login_name); }
      set { this._parent.Session[this._sessionId.login_name] = value; }
    }

    public string hosp_id
    {
      get { return this._parent.getSession(this._sessionId.hosp_id); }
      set { this._parent.Session[this._sessionId.hosp_id] = value; }
    }

    public string hosp_name
    {
      get { return this._parent.getSession(this._sessionId.hosp_name); }
      set { this._parent.Session[this._sessionId.hosp_name] = value; }
    }

    public string terminal_id
    {
      get { return this._parent.getSession(this._sessionId.terminal_id); }
      set { this._parent.Session[this._sessionId.terminal_id] = value; }
    }

    public string team_id
    {
      get { return this._parent.getSession(this._sessionId.team_id); }
      set { this._parent.Session[this._sessionId.team_id] = value; }
    }

    public string option_karte_reference
    {
      get { return this._parent.getSession(this._sessionId.option_karte_reference); }
      set { this._parent.Session[this._sessionId.option_karte_reference] = value; }
    }

    public string option_photo
    {
      get { return this._parent.getSession(this._sessionId.option_photo); }
      set { this._parent.Session[this._sessionId.option_photo] = value; }
    }

    public string option_profile
        {
        get { return this._parent.getSession(this._sessionId.option_profile); }
        set { this._parent.Session[this._sessionId.option_profile] = value; }
    }

        public string login_date
    {
      get { return this._parent.getSession(this._sessionId.login_date); }
      set { this._parent.Session[this._sessionId.login_date] = value; }
    }
  }
}
