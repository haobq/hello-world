﻿using System;
using System.Data;
using System.Reflection;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web;

namespace VedioUploadService
{
    public class Login : App_Function
    {
        private const string businessName = "ログイン";

        private String media_auth = "";

        /// <summary>
        /// media_authを取得
        /// </summary>
        /// <param name="str">ID</param>
        /// <returns>nullの場合は空文字を返す</returns>
        public string getMedia_auth()
        {
            return this.media_auth;
        }

        /// <summary>
        /// media_authを設定
        /// </summary>
        /// <param name="str">セッションID</param>
        /// <returns>nullの場合は空文字を返す</returns>
        public string setMedia_auth(string str)
        {
            return this.media_auth = str;
        }

        Boolean sqlrtn;
        int rtn;

        public string groupid = "701701";
        public string terminalid = "";
        public string userid = "testuser003";
        public string password = "Media12@";
        public string pc_name;
        public string remarks;
        public string hdnTmp;
        public string txtUserPw;
        public string txtUserId;

        public void loadLogin(int kubun)
        {
            switch (kubun)
            {
                case -1:
                    doLogout(1, "0");
                    break;
                case 0:
                    doLogin();
                    break;
                case 1:
                    doSetTerminal();
                    break;
                case 2:
                    doGetTerminal();
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// セッションの初期化
        /// </summary>
        /// <remarks>ASP.NETの癖の対応です。</remarks>
        protected void initSession()
        {
            Session.Abandon();
            var c = new System.Web.HttpCookie("ASP.NET_SessionId", "");
            Response.Cookies.Add(c);
        }

        private void debugLogin()
        {
            Session["HOSP_ID"] = "";
            Session["HOSP_NAME"] = "";
            Session["OPTION_KARTE_REFERENCE"] = "";
            Session["OPTION_PHOTO"] = "";
            Session["LOGIN_ID"] = "";
            Session["LOGIN_NAME"] = "";
            Session["LOGIN_DATE"] = "";
            Session["GROUP_ID"] = "";
        }

        private void doLogin1()
        {
            Boolean loginSucceeded = false; //ログインが成功したか
            try
            {

                var sessionState = (SessionStateSection)WebConfigurationManager.GetSection("system.web/sessionState");
                ViewState["mmSessionTimeout"] = Convert.ToInt32(sessionState.Timeout.TotalMinutes);

                 try
                {
                    Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);







                    getSession("");
                }
                catch (System.Web.HttpException ex)
                {
                    // 例外発生時に処理されるコードをここに記述する...
                }
                finally
                {
                    // 例外発生の有無にかかわらず最後に処理されるコードをここに記述する...
                }



                ////debugLogin();
                //mst_user_hosp などを見る必要がある
                System.Text.StringBuilder sqlString = new System.Text.StringBuilder();
                sqlString.AppendLine("SELECT u.user_id ");
                sqlString.AppendLine("     , u.user_name ");
                sqlString.AppendLine("     , u.opt_1 ");
                sqlString.AppendLine("     , u.opt_2 ");
                sqlString.AppendLine("     , u.opt_3 ");
                sqlString.AppendLine("     , u.post ");
                sqlString.AppendLine("     , u.mask ");
                sqlString.AppendLine("     , u.group_id ");
                sqlString.AppendLine("     , u.user_pw ");
                sqlString.AppendLine("     , uh.hosp_id ");
                sqlString.AppendLine("     , uh.job_id ");
                sqlString.AppendLine("     , uh.localuser_id ");
                sqlString.AppendLine("     , hc.hosp_name ");
                sqlString.AppendLine("     , g.license_number ");
                sqlString.AppendLine("  FROM mst_user u ");
                sqlString.AppendLine(" INNER JOIN mst_user_hosp     uh ON uh.group_id = u.group_id AND  uh.user_id = u.user_id ");
                sqlString.AppendLine(" AND uh.product_kbn=1");
                sqlString.AppendLine(" INNER JOIN mst_hosp_contract hc ON hc.hosp_id  = uh.hosp_id ");
                sqlString.AppendLine(" INNER JOIN mst_group         g  ON g.group_id  = u.group_id ");
                sqlString.AppendLine(" WHERE g.mask     = @MASK ");
                sqlString.AppendLine("   AND u.group_id = @GROUPID ");
                sqlString.AppendLine("   AND u.user_id  = @USERID ");
                sqlString.AppendLine(" ORDER BY u.index_no ");

                SqlParameter[] param = new SqlParameter[3];
                param[0] = createSqlParameter("@MASK", SqlDbType.VarChar, '0');
                param[1] = createSqlParameter("@GROUPID", SqlDbType.VarChar, sqlTabooChar(groupid));
                param[2] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(userid.Trim()));

                DataTable dtUser = new DataTable();
                try
                {
                    if (!sqlSelectTable(sqlString.ToString(), param, ref dtUser))
                    {
                        logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": select error", "", "", "");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": " + ex.Message, "", "", "");
                    return;
                }

                string loginName = "";
                if (dtUser.Rows.Count == 0)
                {
                    logLong(3, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": ユーザ情報なし", "", "", "");
                    return;
                }

                string secPass = getEncryptString(password.Trim(), groupid, dtUser.Rows[0]["user_id"].ToString());
                if (secPass != dtUser.Rows[0]["user_pw"].ToString())
                {
                    logLong(3, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": パスワードエラー", "", "", "");
                    return;
                }

                //使用不可
                if (dtUser.Rows[0]["mask"].ToString() != "0")
                {
                    logLong(3, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": パスワードエラー", "", "", "");
                    return;
                }


                sqlString.Clear();
                sqlString.AppendLine("select * from mst_user_hosp ");
                sqlString.AppendLine(" WHERE group_id = @GROUPID ");
                sqlString.AppendLine("   AND user_id  = @USERID ");
                sqlString.AppendLine("   AND product_kbn=1 ");
                Array.Resize(ref param, 2);
                param[0] = createSqlParameter("@GROUPID", SqlDbType.VarChar, sqlTabooChar(groupid));
                param[1] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(userid.Trim()));
                DataTable dt = new DataTable();
                try
                {
                    if (!sqlSelectTable(sqlString.ToString(), param, ref dt))
                    {
                        logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": select error", "", "", "");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": " + ex.Message, "", "", "");
                    return;
                }

                int effectDateCnt = 0;
                string hospId = "";
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    // 日付有効範囲外
                    DateTime dateToday = DateTime.Today;
                    // 規定値（DBがNullまたは不正な日付の場合以下の値とみなす）
                    DateTime effectDateFrom = dateToday;
                    DateTime effectDateTo = DateTime.Parse("9999/12/31");

                    if (!(DateTime.TryParse(dt.Rows[i]["effect_date_from"].ToString(), out effectDateFrom)))
                    {
                        effectDateFrom = dateToday;
                    }
                    if (!(DateTime.TryParse(dt.Rows[i]["effect_date_to"].ToString(), out effectDateTo)))
                    {
                        effectDateTo = DateTime.Parse("9999/12/31");
                    }

                    if (effectDateFrom <= dateToday && effectDateTo >= dateToday)
                    {
                        effectDateCnt += 1;
                        hospId = dt.Rows[i]["hosp_id"].ToString();
                    }
                }

                if (effectDateCnt == 0)
                {
                    logLong(3, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": パスワードエラー", "", "", "");
                    return;
                }

                // ライセンス数チェック
                int intLicenseNumber = int.Parse(dtUser.Rows[0]["license_number"].ToString());
                if (intLicenseNumber <= GetLoginCount(dtUser.Rows[0]["group_id"].ToString(), dtUser.Rows[0]["user_id"].ToString()))
                {
                    logLong(3, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": ライセンス数", "", "", "");
                    return;
                }

                // 多重ログインのチェック
                Session["TERMINAL_ID"] = terminalid;
                string txtTerminalId = getSession("TERMINAL_ID");
                logLong(2, businessName, Request.Path.TrimStart(new char[] { '/' }), "hdnTerminalId：" + terminalid + " SESSION.TERMINAL_ID：" + getSession("TERMINAL_ID"), "", "", "");
                switch (ChkMultiLogin(dtUser.Rows[0]["user_id"].ToString(), dtUser.Rows[0]["hosp_id"].ToString(), dtUser.Rows[0]["group_id"].ToString(), txtTerminalId, "0", true))
                {
                    case (1):
                        logLong(3, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": 多重ログイン", "", "", "");
                        //端末名取得
                        string termName = getTermId(dtUser.Rows[0]["user_id"].ToString(), dtUser.Rows[0]["hosp_id"].ToString(), dtUser.Rows[0]["group_id"].ToString(), txtTerminalId, "0");
                        return;
                    case (2):
                        logLong(3, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": 多重ログイン", "", "", "");
                        //ユーザID取得
                        string userId = getUserId(dtUser.Rows[0]["user_id"].ToString(), dtUser.Rows[0]["hosp_id"].ToString(), dtUser.Rows[0]["group_id"].ToString(), txtTerminalId, "0");
                        return;
                    case (-1):
                        logLong(4, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": その他のエラー", "", "", "");
                        return;
                }

                //ログイン成功
                loginSucceeded = true;

                loginName = dtUser.Rows[0]["user_name"].ToString();
                Session["LOGIN_ID"] = dtUser.Rows[0]["user_id"].ToString();
                Session["LOGIN_NAME"] = loginName;
                Session["LOGIN_DATE"] = DateTime.Now.ToString("yyyy/MM/dd");
                Session["GROUP_ID"] = dtUser.Rows[0]["group_id"].ToString();
                //使用頻度が低いのでSessionじゃなくてもいいような
                Session["OPT_1"] = dtUser.Rows[0]["opt_1"].ToString();
                Session["OPT_2"] = dtUser.Rows[0]["opt_2"].ToString();
                Session["OPT_3"] = dtUser.Rows[0]["opt_3"].ToString();
                Session["POST"] = dtUser.Rows[0]["post"].ToString();

                string job_id = dtUser.Rows[0]["job_id"].ToString();
                if (job_id == "3") Session["guideDr"] = dtUser.Rows[0]["localuser_id"].ToString();
                if (job_id == "4") Session["guideDH1"] = dtUser.Rows[0]["localuser_id"].ToString();

                Session["PRO_LOCALUSER_ID"] = dtUser.Rows[0]["localuser_id"].ToString();
                Session["PRO_JOB_ID"] = dtUser.Rows[0]["job_id"].ToString();

                //switch (dtUser.Rows.Count)
                switch (effectDateCnt)
                {
                    case (1):
                        sqlString.Clear();
                        sqlString.AppendLine("SELECT hc.hosp_id ");
                        sqlString.AppendLine("     , hc.hosp_name ");
                        sqlString.AppendLine("     , mhg.option_karte_reference");
                        sqlString.AppendLine("     , mhg.option_photo");
                        sqlString.AppendLine("     , mhg.option_profile");
                        sqlString.AppendLine("  FROM mst_hosp_contract hc ");
                        sqlString.AppendLine("left join mst_hosp_gw mhg on hc.hosp_id = mhg.hosp_id");
                        sqlString.AppendLine(" WHERE hc.hosp_id = @HOSPID ");

                        Array.Resize(ref param, 1);
                        param[0] = createSqlParameter("@HOSPID", SqlDbType.VarChar, sqlTabooChar(hospId));

                        DataTable dtHosp = new DataTable();
                        sqlSelectTable(sqlString.ToString(), param, ref dtHosp);
                        if (dtHosp.Rows.Count == 0)
                        {
                            logLong(4, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + "エラー : " + sqlString, "", "", "");
                            return;
                        }
                        Session["HOSP_ID"] = dtHosp.Rows[0]["hosp_id"];
                        Session["HOSP_NAME"] = dtHosp.Rows[0]["hosp_name"];
                        Session["OPTION_KARTE_REFERENCE"] = dtHosp.Rows[0]["option_karte_reference"];
                        Session["OPTION_PHOTO"] = dtHosp.Rows[0]["option_photo"];
                        Session["OPTION_PROFILE"] = dtHosp.Rows[0]["option_profile"];

                        loginHistory("0");
                        logLong(2, businessName, Request.Path.TrimStart(new char[] { '/' }), string.Format("ログイン成功：{0}", loginName), "", "", "");

                        Session["GENGO_TBL_KBN"] = "1";
                        Response.Redirect("startMenu.aspx");
                        break;

                    default:

                        if (getSession("HOSP_ID").Length == 0)
                        {
                            //通常
                            Session["GENGO_TBL_KBN"] = "1";
                            Response.Redirect("hospSelect.aspx");
                        }
                        else
                        {
                            //セッションが残っているor2画面起動など
                            sqlString.Clear();
                            sqlString.AppendLine("SELECT hc.hosp_id ");
                            sqlString.AppendLine("     , hc.hosp_name ");
                            sqlString.AppendLine("     , uh.job_id ");
                            sqlString.AppendLine("     , uh.localuser_id ");
                            sqlString.AppendLine("     , mhg.option_karte_reference");
                            sqlString.AppendLine("     , mhg.option_photo");
                            sqlString.AppendLine("     , mhg.option_profile");
                            sqlString.AppendLine("FROM mst_hosp_contract hc ");
                            sqlString.AppendLine("INNER JOIN mst_user_hosp uh ON uh.hosp_id = hc.hosp_id AND  uh.user_id = @USERID");
                            sqlString.AppendLine("AND uh.product_kbn=1");
                            sqlString.AppendLine("left join mst_hosp_gw mhg on hc.hosp_id = mhg.hosp_id");
                            sqlString.AppendLine("WHERE hc.hosp_id = @HOSPID ");
                            //sqlString.AppendLine(string.Format(@" WHERE hc.hosp_id = '{0}'", sqlTabooChar(getSession("HOSP_ID"))));

                            Array.Resize(ref param, 2);
                            param[0] = createSqlParameter("@HOSPID", SqlDbType.VarChar, sqlTabooChar(getSession("HOSP_ID")));
                            param[1] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(userid.Trim()));

                            DataTable dtHosp2 = new DataTable();
                            sqlSelectTable(sqlString.ToString(), param, ref dtHosp2);
                            if (dtHosp2.Rows.Count == 0)
                            {
                                logLong(4, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + "エラー : " + sqlString, "", "", "");
                                return;
                            }
                            Session["HOSP_ID"] = dtHosp2.Rows[0]["hosp_id"];
                            Session["HOSP_NAME"] = dtHosp2.Rows[0]["hosp_name"];
                            Session["OPTION_KARTE_REFERENCE"] = dtHosp2.Rows[0]["option_karte_reference"];
                            Session["OPTION_PHOTO"] = dtHosp2.Rows[0]["option_photo"];
                            Session["OPTION_PROFILE"] = dtHosp2.Rows[0]["option_profile"];
                            string job_id2 = dtHosp2.Rows[0]["job_id"].ToString();
                            if (job_id2 == "3") Session["guideDr"] = dtHosp2.Rows[0]["localuser_id"].ToString();
                            if (job_id2 == "4") Session["guideDH1"] = dtHosp2.Rows[0]["localuser_id"].ToString();

                            loginHistory("0");
                            logLong(2, businessName, Request.Path.TrimStart(new char[] { '/' }), string.Format("ログイン成功：{0}", loginName), "", "", "");

                            Session["GENGO_TBL_KBN"] = "1";
                            Response.Redirect("startMenu.aspx");
                        }

                        break;
                }
            }
            finally
            {
            }
        }



        private void doLogin()
        {


            try
            {
                string userpw = password;
                //Session["LOGIN_ID"] = userid;

                string sqlString = "select *,dbo.SYSDATE() as nowdate from mst_user ";
                //sqlString += "where user_id = '" + userid + "' ";
                //sqlString += " and user_pw = '" + userpw + "' ";
                sqlString += "where user_id = @USERID ";
                sqlString += " and user_pw = @USERPW ";
                //sqlString += " and mask = '0' ";
                //sqlString += " and post = 'AD' ";
                //sqlString += " and post = @POST ";

                //string groupid = "GR1";//ここは直したほうがいい。暗号化・複合化に必要なので、入力画面に足すのが良い。
                string secPass = getEncryptString(userpw, groupid, userid);

                SqlParameter[] param = new SqlParameter[2];
                param[0] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(userid));
                param[1] = createSqlParameter("@USERPW", SqlDbType.VarChar, sqlTabooChar(secPass));
                //param[2] = createSqlParameter("@POST", SqlDbType.VarChar, "AD");

                //初期化
                DataTable dt = new DataTable();
                sqlrtn = sqlSelectTable(sqlString, param, ref dt);
                if (!sqlrtn)
                {
                    //js("alert('ユーザ情報の取得に失敗しました。')");
                    js("setSvgTitleIconColor(1);alertmsg('エラー', '<article>ユーザ情報の取得に失敗しました。</article>',\"<use xmlns:xlink=\'http://www.w3.org/1999/xlink\' xlink:href=" + ResolveUrl("~/Img/icons_system.svg#icon-person") + "></use>\", 'ＯＫ', \"alertclose('')\")");
                    return;
                }

                if (dt.Rows.Count < 1)
                {
                    //js("alert('IDもしくはパスワードが間違っています。')");
                    js("setSvgTitleIconColor(1);alertmsg('ログインエラー', '<article>ログインIDまたはパスワードが間違っています。</article>',\"<use xmlns:xlink=\'http://www.w3.org/1999/xlink\' xlink:href=" + ResolveUrl("~/Img/icons_system.svg#icon-person") + "></use>\",'ＯＫ', \"alertclose('txtId')\")");
                    logLong(1, "サービス管理者　ログイン", "slogin", "ログインNG", "", "", "");
                    //js("fnctxtIdFocus()");

                    return;
                }
                //無効チェック
                if (dt.Rows[0]["mask"].ToString() == "1")
                {
                    js("setSvgTitleIconColor(1);alertmsg('エラー', '<article>ログインIDは利用できません。</article>',\"<use xmlns:xlink=\'http://www.w3.org/1999/xlink\' xlink:href=" + ResolveUrl("~/Img/icons_system.svg#icon-person") + "></use>\",'ＯＫ', \"alertclose('txtId')\")");
                    logLong(1, "サービス管理者　ログイン", "slogin", "ログインNG 利用不可", "", "", "");
                    return;
                }

                //有効期間チェック
                //if (DateTime.Parse(dt.Rows[0]["effect_date_from"].ToString()) > DateTime.Parse(dt.Rows[0]["nowdate"].ToString()) |
                //    DateTime.Parse(dt.Rows[0]["effect_date_to"].ToString()) < DateTime.Parse(dt.Rows[0]["nowdate"].ToString()))
                //{
                //    js("setSvgTitleIconColor(1);alertmsg('エラー', '<article>ログインIDは有効期間外です。</article>',\"<use xmlns:xlink=\'http://www.w3.org/1999/xlink\' xlink:href=" + ResolveUrl("~/Img/icons_system.svg#icon-person") + "></use>\",'ＯＫ', \"alertclose('');\")");
                //    logLong(1, "サービス管理者　ログイン", "slogin", "ログインNG 有効期間外", "", "", "");
                //    return;
                //}

                //メディアログインの場合はチェックしない
                ////パスワードの有効期間は登録してから２ヶ月
                //if (DateTime.Parse(dt.Rows[0]["regist_datetime"].ToString()).AddMonths(2) <= DateTime.Parse(dt.Rows[0]["nowdate"].ToString()))
                //{
                //    js("alertmsg('エラー', 'パスワードの有効期間が切れました。<br />パスワードの変更を行ってください。', 'ＯＫ', \"alertclose('');callPWchange();\")");
                //    logLong(1, "サービス管理者　ログイン", "slogin", "ログインNG 有効期間外", "", "", "");
                //    return;
                //}

                //Session["LOGIN_ID"] = userid;
                //Session["LOGIN_NAME"] = dt.Rows[0]["user_name"].ToString();
                //Session["LOGIN_DATE"] = DateTime.Now.ToString("yyyy/MM/dd");
                ////2018.04.27 v2.3-037 start
                //Session["HOSP_ID"] = "";
                //Session["HOST_NAME"] = "PC_NAME";
                //Session["GROUP_ID"] = "MEDIA";
                //Session["TERMINAL_ID"] = "MEDIA_PC";
                ////2018.04.27 v2.3-037 end

                //mySession.hosp_id = "";
                //mySession.hosp_name = "";
                //mySession.option_karte_reference = "";
                //mySession.option_photo = "";
                //mySession.login_date = "";
                //mySession.login_id = userid;
                //mySession.login_name = "";
                //mySession.group_id = groupid;






                //tbl_sessionチェック
                setMedia_auth(sqlTabooChar(AuthKeyLib.GenerateAuthKey(64)));

                rtn = chkTblSession(groupid, userid, "", getMedia_auth());
                if (rtn < 0)
                {
                    //js("setSvgTitleIconColor(1);alertmsg('エラー', '<article>セッション情報取得エラー。</article>',\"<use xmlns:xlink=\'http://www.w3.org/1999/xlink\' xlink:href=" + ResolveUrl("~/Img/icons_system.svg#icon-person") + "></use>\",'ＯＫ', \"alertclose('');\")");
                    return;
                }
                else if (rtn == 1)
                {
                    //js("alertmsg2('警告', '同じユーザIDで既にログインされています。<br />" +
                    //    "ログイン解除すると、現在ログイン中の端末で<br />" +
                    //    "使用できなくなります。<br />ログイン解除しますか？', 'ＯＫ', 'キャンセル', \"alertclose('');__doPostBack('btnSessionUpd', '');\", \"alertclose('');\", 'divModalBtn2')");

                    //js("setSvgTitleIconColor(1);alertmsg('エラー', '<article>同じユーザIDで既にログインされている為、<br />使用できません。</article>',\"<use xmlns:xlink=\'http://www.w3.org/1999/xlink\' xlink:href=" + ResolveUrl("~/Img/icons_system.svg#icon-person") + "></use>\",'ＯＫ', \"alertclose('');\")");

                }
                else
                {
                    //logLong(2, "サービス管理者　ログイン", "slogin", "セッション登録", "", "", "");
                    //js("__doPostBack('btnCallMenu', '')");
                    //CallMenu();
                }

                //logLong(1, "サービス管理者　ログイン", "slogin", "ログインOK", "", "", "");
                //Response.Redirect("sMenu.aspx");
                return;

            }
            catch (Exception ex)
            {
                //logLong(4, "サービス管理者　ログイン", "slogin", "doLogin() " + ex.Message, "", "", "");
                return;
            }


        }




        /// <summary>
        /// ログアウト App_Functionに入れる？
        /// </summary>
        private void doLogoutA()
        {
            Session.Abandon();
        }

        private void doGetTerminal()
        {
            if (hdnTmp.Length == 0)
            {
            }
            else
            {
                string[] arKey = hdnTmp.Split('|');
                DataTable dtTerminal = new DataTable();
                try
                {
                    System.Text.StringBuilder sqlString = new System.Text.StringBuilder();
                    sqlString.AppendLine("SELECT mask ");
                    sqlString.AppendLine("     , valid_date_from ");
                    sqlString.AppendLine("     , valid_date_to ");
                    sqlString.AppendLine("     , group_id ");
                    sqlString.AppendLine("     , terminal_id ");
                    sqlString.AppendLine("  FROM mst_terminal ");
                    sqlString.AppendLine(" WHERE group_id    = @GROUPID ");
                    sqlString.AppendLine("   AND terminal_id = @TERMID ");

                    SqlParameter[] param = new SqlParameter[2];
                    param[0] = createSqlParameter("@GROUPID", SqlDbType.VarChar, sqlTabooChar(arKey[0]));
                    param[1] = createSqlParameter("@TERMID", SqlDbType.VarChar, sqlTabooChar(arKey[1]));


                    if (!sqlSelectTable(sqlString.ToString(), param, ref dtTerminal))
                    {
                        logLong(4, businessName, "端末情報マスタ", MethodBase.GetCurrentMethod().Name + ": select error", "", "", "");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    logLong(4, businessName, "端末情報マスタ", MethodBase.GetCurrentMethod().Name + ": " + ex.Message, "", "", "");
                    return;
                }

                ViewState["mst_terminal"] = dtTerminal;

                if (dtTerminal.Rows.Count == 0)
                {
                    // 端末データなし
                    return;
                }

                //使用不可
                string mask = dtTerminal.Rows[0]["mask"].ToString();
                if (mask != "0")
                {
                    // mask != 0 の場合はデータなしと同じ
                    return;
                }

                DateTime dateToday = DateTime.Today;
                // 規定値（DBがNullまたは不正な日付の場合以下の値とみなす）
                DateTime dateValidDateFrom = dateToday;
                DateTime dateValidDateTo = DateTime.Parse("9999/12/31");

                if (!(DateTime.TryParse(dtTerminal.Rows[0]["valid_date_from"].ToString(), out dateValidDateFrom)))
                {
                    dateValidDateFrom = dateToday;
                }
                if (!(DateTime.TryParse(dtTerminal.Rows[0]["valid_date_to"].ToString(), out dateValidDateTo)))
                {
                    dateValidDateTo = DateTime.Parse("9999/12/31");
                }

                if (dateToday < dateValidDateFrom || dateValidDateTo < dateToday)
                {
                    // 端末有効期限エラー
                    return;
                }

                groupid = dtTerminal.Rows[0]["group_id"].ToString();
                terminalid = dtTerminal.Rows[0]["terminal_id"].ToString();
                Session["GROUP_ID"] = dtTerminal.Rows[0]["group_id"].ToString();
                Session["TERMINAL_ID"] = dtTerminal.Rows[0]["terminal_id"].ToString();
                return;
            }
        }

        private bool doSetTerminal()
        {
            try
            {
                // 入力されたグループID、ユーザIDの有効性チェック

                System.Text.StringBuilder sqlString = new System.Text.StringBuilder();
                SqlParameter[] param = new SqlParameter[2];
                sqlString.Clear();
                sqlString.AppendLine("select * from mst_user_hosp ");
                sqlString.AppendLine(" WHERE group_id = @GROUPID ");
                sqlString.AppendLine("   AND user_id  = @USERID ");
                sqlString.AppendLine("   AND product_kbn=1 ");
                Array.Resize(ref param, 2);
                param[0] = createSqlParameter("@GROUPID", SqlDbType.VarChar, sqlTabooChar(groupid));
                param[1] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(txtUserId));
                DataTable dt = new DataTable();
                try
                {
                    if (!sqlSelectTable(sqlString.ToString(), param, ref dt))
                    {
                        logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": select error", "", "", "");
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": " + ex.Message, "", "", "");
                    return false;
                }

                int effectDateCnt = 0;
                string hospId = "";
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    // 日付有効範囲外
                    DateTime dateToday = DateTime.Today;
                    // 規定値（DBがNullまたは不正な日付の場合以下の値とみなす）
                    DateTime effectDateFrom = dateToday;
                    DateTime effectDateTo = DateTime.Parse("9999/12/31");

                    if (!(DateTime.TryParse(dt.Rows[i]["effect_date_from"].ToString(), out effectDateFrom)))
                    {
                        effectDateFrom = dateToday;
                    }
                    if (!(DateTime.TryParse(dt.Rows[i]["effect_date_to"].ToString(), out effectDateTo)))
                    {
                        effectDateTo = DateTime.Parse("9999/12/31");
                    }

                    if (effectDateFrom <= dateToday && effectDateTo >= dateToday)
                    {
                        effectDateCnt += 1;
                        hospId = dt.Rows[i]["hosp_id"].ToString();
                    }
                }

                if (effectDateCnt == 0)
                {
                    //logLong(3, businessName, "認証エラー", MethodBase.GetCurrentMethod().Name + ": パスワードエラー", "", "", "");
                    return false;
                }

                //userIdの大文字小文字を区別しないようにするため移動
                //userIdは入力値でなくDBから取得した値を使用してパスワードの検証を行う。
                string secPass = getEncryptString(txtUserPw.Trim(), groupid, dt.Rows[0]["user_id"].ToString());
                DataTable dtUser = GetMstUser(groupid, dt.Rows[0]["user_id"].ToString(), secPass);

                if (dtUser != null)
                {
                    if (dtUser.Rows.Count == 0)
                    {
                        //("ユーザ情報なし");
                        return false;
                    }
                }
                else
                {
                    return false;
                }
                //使用不可
                if (dtUser.Rows[0]["mask"].ToString() != "0")
                {
                    //("使用不可");
                    return false;
                }

                string terminalId = CreateTerminalId();

                System.Web.HttpBrowserCapabilities myBrowserCaps = Request.Browser;
                string userHostName = Request.UserHostName;

                int recCnt = 0;
                DataTable dtTerminal = (DataTable)ViewState["mst_terminal"];
                if (dtTerminal != null)
                {
                    recCnt = dtTerminal.Rows.Count;
                }

                //SqlParameter[] param = null;

                //System.Text.StringBuilder sqlString = new System.Text.StringBuilder();
                if (recCnt == 0)
                {
                    // DBにレコードなし
                    // mst_terminal
                    sqlString.Clear();
                    sqlString.AppendLine("INSERT INTO mst_terminal( ");
                    sqlString.AppendLine("    index_no ");
                    sqlString.AppendLine("  , group_id ");
                    sqlString.AppendLine("  , terminal_id ");
                    sqlString.AppendLine("  , user_id ");
                    sqlString.AppendLine("  , regist_datetime ");
                    sqlString.AppendLine("  , os_name ");
                    sqlString.AppendLine("  , browser_name ");
                    sqlString.AppendLine("  , pc_name ");
                    sqlString.AppendLine("  , remarks ");
                    sqlString.AppendLine("  , valid_date_from ");
                    sqlString.AppendLine("  , valid_date_to ");
                    sqlString.AppendLine("  , terminal_name ");
                    sqlString.AppendLine("  , mask ");
                    sqlString.AppendLine("  , product_kbn ");
                    sqlString.AppendLine(") ");
                    sqlString.AppendLine("VALUES ( ");
                    sqlString.AppendLine("    (SELECT MAX(index_no) + 1 FROM mst_terminal) ");
                    sqlString.AppendLine("  , @GROUPID ");
                    sqlString.AppendLine("  , @TERMID ");
                    sqlString.AppendLine("  , @USERID ");
                    sqlString.AppendLine("  , dbo.SYSDATE() ");
                    sqlString.AppendLine("  , @OSNAME ");
                    sqlString.AppendLine("  , @BROWSER ");
                    sqlString.AppendLine("  , @PCNAME ");
                    sqlString.AppendLine("  , @REMARKS ");
                    sqlString.AppendLine("  , dbo.SYSDATE() ");
                    sqlString.AppendLine("  , @VALIDDATETO ");
                    sqlString.AppendLine("  , @TERMNAME ");
                    sqlString.AppendLine("  , @MASK");
                    sqlString.AppendLine("  , 1");
                    sqlString.AppendLine(") ");

                    Array.Resize(ref param, 10);
                    param[0] = createSqlParameter("@GROUPID", SqlDbType.VarChar, sqlTabooChar(dtUser.Rows[0]["group_id"].ToString()));
                    param[1] = createSqlParameter("@TERMID", SqlDbType.VarChar, sqlTabooChar(terminalId));
                    param[2] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(dtUser.Rows[0]["user_id"].ToString()));
                    param[3] = createSqlParameter("@OSNAME", SqlDbType.VarChar, sqlTabooChar(myBrowserCaps.Platform));
                    param[4] = createSqlParameter("@BROWSER", SqlDbType.VarChar, sqlTabooChar(myBrowserCaps.Browser + " " + myBrowserCaps.Version));
                    param[5] = createSqlParameter("@PCNAME", SqlDbType.VarChar, sqlTabooChar(userHostName));
                    param[6] = createSqlParameter("@VALIDDATETO", SqlDbType.VarChar, "9999/12/31");
                    param[7] = createSqlParameter("@MASK", SqlDbType.VarChar, '0');
                    param[8] = createSqlParameter("@TERMNAME", SqlDbType.VarChar, sqlTabooChar(pc_name));
                    param[9] = createSqlParameter("@REMARKS", SqlDbType.VarChar, sqlTabooChar(remarks));
                }
                else
                {
                    // DBに削除済みレコードあり
                    terminalId = dtTerminal.Rows[0]["terminal_id"].ToString();
                    sqlString.Clear();
                    sqlString.AppendLine("UPDATE mst_terminal ");
                    sqlString.AppendLine("SET user_id         = @USERID ");
                    sqlString.AppendLine("  , regist_datetime = dbo.SYSDATE() ");
                    sqlString.AppendLine("  , os_name         = @OSNAME ");
                    sqlString.AppendLine("  , browser_name    = @BROWSER ");
                    sqlString.AppendLine("  , pc_name         = @PCNAME ");
                    sqlString.AppendLine("  , valid_date_from = dbo.SYSDATE() ");
                    sqlString.AppendLine("  , valid_date_to   = @VALIDDATETO ");
                    sqlString.AppendLine("  , mask            = @MASK ");
                    sqlString.AppendLine("  , terminal_name   = @TERMNAME ");
                    sqlString.AppendLine("  , remarks         = @REMARKS ");
                    sqlString.AppendLine("WHERE group_id    = @GROUPID ");
                    sqlString.AppendLine("  AND terminal_id = @TERMID ");


                    Array.Resize(ref param, 10);
                    param[0] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(dtUser.Rows[0]["user_id"].ToString()));
                    param[1] = createSqlParameter("@OSNAME", SqlDbType.VarChar, sqlTabooChar(myBrowserCaps.Platform));
                    param[2] = createSqlParameter("@BROWSER", SqlDbType.VarChar, sqlTabooChar(myBrowserCaps.Browser + " " + myBrowserCaps.Version));
                    param[3] = createSqlParameter("@PCNAME", SqlDbType.VarChar, sqlTabooChar(userHostName));
                    param[4] = createSqlParameter("@VALIDDATETO", SqlDbType.VarChar, "9999/12/31");
                    param[5] = createSqlParameter("@MASK", SqlDbType.VarChar, '0');
                    param[6] = createSqlParameter("@GROUPID", SqlDbType.VarChar, sqlTabooChar(groupid));
                    param[7] = createSqlParameter("@TERMID", SqlDbType.VarChar, sqlTabooChar(terminalId));
                    param[8] = createSqlParameter("@TERMNAME", SqlDbType.VarChar, sqlTabooChar(pc_name));
                    param[9] = createSqlParameter("@REMARKS", SqlDbType.VarChar, sqlTabooChar(remarks));


                }

                //if (!sqlTran(sqlString.ToString()))
                if (!sqlUpdate(sqlString.ToString(), param))
                {
                    logLong(4, businessName, "端末情報マスタ", MethodBase.GetCurrentMethod().Name + ": " + ((recCnt == 0) ? "insert" : "update") + " error", "", "", "");
                    return false;
                }

                terminalid = terminalId;

                System.Threading.Thread.Sleep(500);
                Session["GROUP_ID"] = dtUser.Rows[0]["group_id"].ToString();
                Session["LOGIN_ID"] = dtUser.Rows[0]["user_id"].ToString();

                return true;
            }
            catch (Exception ex)
            {
                logLong(4, businessName, "端末情報マスタ", MethodBase.GetCurrentMethod().Name + ": " + ex.Message, "", "", "");
                return false;
            }
        }

        /// <summary>
        /// 新規登録用TerminalId生成
        /// </summary>
        /// <returns>TerminalId</returns>
        private string CreateTerminalId()
        {
            string tmpTerminalId = "";

            DataTable dtMstTerminal = new DataTable();
            do
            {
                // システム時刻を渡してランダムな文字列を作成する
                string[] strSeed = { DateTime.Now.ToString("yyyyMMddHHmmssffff") };
                tmpTerminalId = getKey(20, strSeed);
                string sqlString = "";
                sqlString += "SELECT * FROM mst_terminal ";
                //sqlString += string.Format(@" WHERE terminal_id = '{0}' ", tmpTerminalId);
                sqlString += " WHERE terminal_id = @TERMID ";

                SqlParameter[] param = new SqlParameter[1];
                param[0] = createSqlParameter("@TERMID", SqlDbType.VarChar, sqlTabooChar(tmpTerminalId));

                //if (!sqlSelectTable(sqlString, ref dtMstTerminal))
                if (!sqlSelectTable(sqlString, param, ref dtMstTerminal))
                {

                }
            }
            while (dtMstTerminal.Rows.Count != 0);

            return tmpTerminalId;
        }

        /// <summary>
        /// ユーザ情報検索
        /// </summary>
        /// <param name="strGroupID">グループID</param>
        /// <param name="strUserId">ユーザID</param>
        /// <returns>ユーザ情報(DataTable)</returns>
        /// <remarks>「App_Function」に実装する？</remarks>
        private DataTable GetMstUser(string strGroupID, string strUserId, string strUserPw)
        {
            try
            {
                DataTable dtUser = new DataTable();
                System.Text.StringBuilder sqlString = new System.Text.StringBuilder();
                sqlString.AppendLine("SELECT u.* ");
                sqlString.AppendLine("     , g.group_name ");
                sqlString.AppendLine("     , g.license_number ");
                sqlString.AppendLine("  FROM mst_user u ");
                sqlString.AppendLine(" INNER JOIN mst_group g  ON g.group_id = u.group_id ");
                sqlString.AppendLine(" WHERE g.mask     = @MASK ");
                sqlString.AppendLine("   AND u.user_id  = @USERID ");
                sqlString.AppendLine("   AND u.group_id = @GROUPID ");

                int paramcnt = 3;
                SqlParameter[] param = new SqlParameter[paramcnt];
                param[0] = createSqlParameter("@MASK", SqlDbType.VarChar, '0');
                param[1] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(strUserId));
                param[2] = createSqlParameter("@GROUPID", SqlDbType.VarChar, sqlTabooChar(strGroupID));

                if (!(string.IsNullOrEmpty(strUserPw)))
                {
                    //sqlString.AppendLine(string.Format(@"   AND u.user_pw  = '{0}' COLLATE Japanese_CS_AS_KS_WS ", sqlTabooChar(strUserPw)));
                    sqlString.AppendLine("   AND u.user_pw  = @USERPW COLLATE Japanese_CS_AS_KS_WS ");
                    paramcnt += 1;
                    Array.Resize(ref param, paramcnt);
                    param[paramcnt - 1] = createSqlParameter("@USERPW", SqlDbType.VarChar, sqlTabooChar(strUserPw));
                }

                //if (!sqlSelectTable(sqlString.ToString(), ref dtUser))
                if (!sqlSelectTable(sqlString.ToString(), param, ref dtUser))
                {
                    logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": select error", "", "", "");
                    return null;
                }

                return dtUser;

            }
            catch (Exception ex)
            {
                logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": " + ex.Message, "", "", "");
                return null;
            }
        }

        /// <summary>
        /// 同時ログイン数算出
        /// </summary>
        /// <param name="strGroupId">グループID</param>
        /// <param name="strTerminalId">端末ID</param>
        /// <param name="flgWithout">true：算出時、指定の端末IDを除く</param>
        /// <returns>正常時：0以上、エラー時：-1</returns>
        /// <remarks>「App_Function」に実装する？</remarks>
        private int GetLoginCount(string strGroupId, string userid, string strTerminalId = "", bool flgWithout = false)
        {
            int intRet = -1;
            DateTime dateRegistDatetime = DateTime.UtcNow;
            dateRegistDatetime = dateRegistDatetime.AddMinutes(-((double)Session.Timeout + (double)10.0));
            DataTable dtSession = new DataTable();
            System.Text.StringBuilder sqlString = new System.Text.StringBuilder();
            sqlString.AppendLine("SELECT * ");
            sqlString.AppendLine("  FROM tbl_session ");
            sqlString.AppendLine(" WHERE group_id         = @GROUPID ");
            sqlString.AppendLine("   AND user_id         != @USERID");
            sqlString.AppendLine("   AND regist_datetime >= @REGISTDT ");
            sqlString.AppendLine("   AND session_flg = @FLG ");
            sqlString.AppendLine("   AND user_id not in(select 'mediauser' + hosp_id  from mst_group_hosp where group_id = @GROUPID) ");

            int paramcnt = 4;
            SqlParameter[] param = new SqlParameter[paramcnt];
            param[0] = createSqlParameter("@GROUPID", SqlDbType.VarChar, sqlTabooChar(strGroupId));
            param[1] = createSqlParameter("@USERID", SqlDbType.VarChar, sqlTabooChar(userid));
            param[2] = createSqlParameter("@REGISTDT", SqlDbType.VarChar, dateRegistDatetime.ToString("yyyy-MM-dd HH:mm:ss"));
            param[3] = createSqlParameter("@FLG", SqlDbType.VarChar, "0");


            if (flgWithout)
            {
                sqlString.AppendLine("   AND terminal_id　　　 <> @TERMID ");
                paramcnt += 1;
                Array.Resize(ref param, paramcnt);
                param[paramcnt - 1] = createSqlParameter("@TERMID", SqlDbType.VarChar, sqlTabooChar(strTerminalId));
            }

            try
            {

                if (!sqlSelectTable(sqlString.ToString(), param, ref dtSession))
                {
                    logLong(4, businessName, "セッション情報", MethodBase.GetCurrentMethod().Name + ": select error", "", "", "");
                    return intRet;
                }
            }
            catch (Exception ex)
            {
                logLong(4, businessName, "ユーザ情報", MethodBase.GetCurrentMethod().Name + ": " + ex.Message, "", "", "");
                return intRet;
            }
            return dtSession.Rows.Count;
        }

        private string getUserId(string txtUserId, string txtHospId, string txtGroupId, string txtTerminalId, string flg)
        {
            bool sqlrtn = false;
            System.Text.StringBuilder sql = new System.Text.StringBuilder();
            DataTable dt = new DataTable();

            try
            {
                sql.Clear();
                sql.AppendLine("SELECT * FROM tbl_session ");
                sql.AppendLine(string.Format(" WHERE group_id  = '{0}' ", sqlTabooChar(txtGroupId)));
                sql.AppendLine(string.Format("   AND terminal_id = '{0}' ", sqlTabooChar(txtTerminalId)));
                sql.AppendLine(string.Format("   AND session_flg = '{0}' ", sqlTabooChar(flg)));    //0:通常　1：グループ管理者　2：メディア管理者

                sqlrtn = sqlSelectTable(sql.ToString(), ref dt);
                if (!sqlrtn)
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                logLong(4, businessName, "", "SELECT tbl_session error:" + ex.Message, "", "", "");
                return "";
            }

            if (dt.Rows.Count != 0)
            {
                //同じ端末で既に別ユーザでLoginしている
                return dt.Rows[0]["user_id"].ToString();
            }
            return "";
        }

        private string getTermId(string txtUserId, string txtHospId, string txtGroupId, string txtTerminalId, string flg)
        {
            bool sqlrtn = false;
            System.Text.StringBuilder sql = new System.Text.StringBuilder();
            DataTable dt = new DataTable();
            try
            {
                sql.Clear();
                sql.AppendLine("SELECT t.terminal_name ");
                sql.AppendLine("FROM ");
                sql.AppendLine("tbl_session s ");
                sql.AppendLine("LEFT JOIN mst_terminal t ");
                sql.AppendLine("ON ( ");
                sql.AppendLine("s.group_id = t.group_id ");
                sql.AppendLine("AND s.terminal_id = t.terminal_id ) ");
                sql.AppendLine(string.Format(" WHERE s.user_id  = '{0}' ", sqlTabooChar(txtUserId)));
                sql.AppendLine(string.Format("   AND s.group_id = '{0}' ", sqlTabooChar(txtGroupId)));
                sql.AppendLine(string.Format("   AND s.session_flg = '{0}' ", sqlTabooChar(flg)));  //0:通常　1：グループ管理者　2：メディア管理者

                sqlrtn = sqlSelectTable(sql.ToString(), ref dt);
                if (!sqlrtn)
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                logLong(4, businessName, "", "SELECT tbl_session error:" + ex.Message, "", "", "");
                return "";
            }

            if (dt.Rows.Count != 0)
            {
                //同じユーザが別の端末でログインしている
                return dt.Rows[0]["terminal_name"].ToString();
            }
            return "";
        }
    }


}