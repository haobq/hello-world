﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class MovieReponse
    {
        //グループID
        public string Group_id { get; set; }
        //医院ID
        public string Hosp_id { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //UserID
        public string User_id { get; set; }
        //アップロード動画ファイル名
        public List<string> Upload_movie_name { get; set; }
        //アップロード結果
        public string Upload_result { get; set; }
    }
}