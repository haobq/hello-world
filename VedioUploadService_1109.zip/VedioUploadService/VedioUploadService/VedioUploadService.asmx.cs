using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using VedioUploadService.Models;
using VedioUploadService.Models.Common;
using System.IO.Compression;
using System.Web.UI.WebControls;

namespace VedioUploadService
{
    /// <summary>
    /// VedioUploadService の概要の説明です
    /// </summary>
    [WebService(Namespace = "http://vedio.media.inc.co.jp/service")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class VedioUploadService : System.Web.Services.WebService
    {
        /// <summary>
        /// ログイン
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public LoginRespone Login(string group_id, string user_id, string password, string hosp_id)
        {
            string temp_hosp_id = hosp_id;
            LoginRespone cer = new LoginRespone();
            try
            {
                string userpw = password;
                //パスワードSHA256バッシュ
                string secPass = Tools.GetEncryptString(userpw, group_id, user_id);
                Certification cert = new Certification();
                cert.Group_id = group_id;
                cert.Hosp_id = hosp_id;
                cert.User_id = user_id;


                //1.ユーザの存在確認処理を行う​
                if (Tools.IsCorrect(group_id, user_id, secPass) == false)
                {
                    BizException biz = new BizException("UserIdOrPassword", Constants.MsgWrongUserIdOrPassword);
                    throw biz;
                }

                //2.端末ID取得
                string terminal_id = Tools.GetTerminalId(group_id, user_id);

                //3.グループに紐付けた医院リストを取得する
                if (string.IsNullOrEmpty(temp_hosp_id))
                {
                    List<ClinicReponse> clinicList = Tools.GetClinic_data(group_id, user_id);
                    cer.ClinicList = clinicList;
                    if (!clinicList.Any())
                    {
                        BizException biz = new BizException("HospError", Constants.MsgHospError);
                        throw biz;
                    }

                    //医院リスト一つの場合、施設リストを取得する
                    if (clinicList.Count == 1)
                    {
                        hosp_id = clinicList[0].Hosp_id;
                        temp_hosp_id = hosp_id;
                    }
                    else
                    {
                        // 医院リストが複数の場合、画面に戻って医院を選択する
                        cer.Cert = cert;
                        return cer;
                    }
                }

                //4.医院リスト一つの場合、施設リストを取得する
                if (!string.IsNullOrEmpty(temp_hosp_id))
                {
                    List<ClinicReponse> clinicList = Tools.GetClinic_data(group_id, user_id);
                    foreach (ClinicReponse clinic in clinicList)
                    {
                        if (temp_hosp_id.Equals(clinic.Hosp_id))
                        {
                            List<ClinicReponse> temp = new List<ClinicReponse>();
                            temp.Add(clinic);
                            cer.ClinicList = temp;
                            break;
                        }
                    }

                    List<FacilityReponse> facilityList = Tools.GetFacility_data(temp_hosp_id);
                    cer.FacilityList = facilityList;
                    if (!facilityList.Any())
                    {
                        BizException biz = new BizException("FacilityError", Constants.MsgFacilityError);
                        throw biz;
                    }
                }

                //5.セッション情報を追加
                if (Tools.InsertTblSession(user_id, hosp_id, group_id, terminal_id) == false)
                {
                    BizException biz = new BizException("Authentication", Constants.MsgExistedAuthentication);
                    throw biz;
                }
                //6.認証キー取得する
                cert.Media_auth = Tools.GetMedia_auth(user_id, hosp_id, group_id);
                cert.Hosp_id = temp_hosp_id;
                cer.Cert = cert;
                return cer;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                throw biz;
            }

        }


        /// <summary>
        /// 患者検索サービス
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public List<PatientResponse> SearchPatient(PatientRequest request)
        {
            try
            {
                //1.リクエストパラメータのValidation処理を行う​
                if (Tools.IsCorrect(request.Certification.Group_id) == false)
                {
                    BizException biz = new BizException("GroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }

                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth) == false)
                {
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };

                //3.tbl_patientテーブルを下記条件で検索する
                List<PatientResponse> patientList = Tools.GetPatient_data(request);
                return patientList;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                throw biz;
            }

        }
        /// <summary>
        /// 動画ファイル確認フォルダの容量計算
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public FolderSizeReponse GetFolderSize(Certification certification)
        {
            FolderSizeReponse folderSize = new FolderSizeReponse
            {
                Contract_size = 0,
                Used_size = 0
            };
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(certification.Group_id) == false)
                {
                    BizException biz = new BizException("GroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth) == false)
                {
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.契約上の容量を取得する
                //4．使った容量計算
                folderSize.Used_size = Tools.GetFolderSize(certification.Group_id);
                return folderSize;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                throw biz;
            }
        }
        /// <summary>
        /// 医院の一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public List<ClinicReponse> GetHospList(Certification certification)
        {
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(certification.Group_id) == false)
                {
                    BizException biz = new BizException("GroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth) == false)
                {
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.医院の一覧を返す
                List<ClinicReponse> clinicList = Tools.GetClinic_data(certification.Group_id, certification.User_id);
                return clinicList;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                throw biz;
            }
        }

        /// <summary>
        /// 施設一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public List<FacilityReponse> GetFacilityList(Certification certification)
        {
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(certification.Group_id) == false)
                {
                    BizException biz = new BizException("GroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth) == false)
                {
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.施設一覧を返す
                List<FacilityReponse> facilityList = Tools.GetFacility_data(certification.Hosp_id);
                return facilityList;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                throw biz;
            }
        }

        /// <summary>
        /// 動画情報格納
        /// </summary>
        /// <param name="movieRequest"></param>
        /// <returns></returns>
        [WebMethod]
        public MovieReponse MediaUpload(MovieRequest request)
        {
            // ファイル格納フォルダを取得
            String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadFolder"].ToString();
            // ファイル格納暫定フォルダを取得
            String tmp = System.Configuration.ConfigurationManager.AppSettings["UpLoadTempFolder"].ToString();

            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(request.Certification.Group_id) == false)
                {
                    BizException biz = new BizException("GroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth) == false)
                {
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.動画ファイルをフォルダを格納

                // grupId + 病院ID　＋　患者ID
                String kannjyaIdDrect_tmp = tmp + @"\" + request.Certification.Group_id + @"\" + request.Certification.Hosp_id + @"\" + request.Patient_id;
                //　ディレクトリ作成
                if (!Directory.Exists(kannjyaIdDrect_tmp))
                {
                    Directory.CreateDirectory(kannjyaIdDrect_tmp);
                }

                if (request.SpriteFileNo == 1)
                {
                    // 最初分割ファイルの場合、ディレクトリ直下のすべてのファイルを削除
                    Tools.CleanUp(kannjyaIdDrect_tmp);
                }


                // grupId + 病院ID　＋　患者ID
                String kannjyaIdDrect = basePath + @"\" + request.Certification.Group_id + @"\" + request.Certification.Hosp_id + @"\" + request.Patient_id;
                //　ディレクトリ作成
                if (!Directory.Exists(kannjyaIdDrect))
                {
                    Directory.CreateDirectory(kannjyaIdDrect);
                }


                // 患者ID　＋　メディア名称
                String mediaPath = kannjyaIdDrect_tmp + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name);

                // zip動画をローカルに保存
                String mediaPathZip = mediaPath + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + Path.GetExtension(request.Movie_name).Replace(".", "") + ".zip";
                //　ディレクトリ作成
                if (!Directory.Exists(mediaPath))
                {
                    Directory.CreateDirectory(mediaPath);
                }

                // 解凍したファイルフォルダ
                String extractPath = kannjyaIdDrect_tmp + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name);
                //　ディレクトリ作成
                if (!Directory.Exists(extractPath))
                {
                    Directory.CreateDirectory(extractPath);
                }


                // 移動先解凍したファイル
                String moveUnZipFile = mediaPath + @"\" + request.Movie_name;

                // 結合したmp4ファイル
                string file_name = kannjyaIdDrect + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + Path.GetExtension(request.Movie_name);

                //既にmp4ファイルアップされた場合エラーを返却
                if (File.Exists(moveUnZipFile) || File.Exists(file_name))
                {
                    BizException biz = new BizException("AlreadyUpLoaded", Constants.MsgAlreadyUpLoaded);
                    throw biz;

                }
                else
                {
                    // byte[] -> ファイル変換
                    FileStream objfilestream = new FileStream(mediaPathZip, FileMode.Create, FileAccess.ReadWrite);
                    objfilestream.Write(request.Movie_context, 0, request.Movie_context.Length);
                    objfilestream.Close();

                    // Zipファイル解凍
                    ZipFile.ExtractToDirectory(mediaPathZip, extractPath);

                    // Zipフォルダを削除
                    File.Delete(mediaPathZip);

                }

                // DirectoryInfoのインスタンスを生成する
                DirectoryInfo d = new DirectoryInfo(extractPath);

                // ディレクトリ直下のすべてのファイル一覧を取得する
                FileInfo[] fiAlls = d.GetFiles();

                int uploadFilesCount = fiAlls.Length;


                // -------------結合処理
                // 分割したファイルの総合＝＝クライアントで送信したファイル総数
                if (request.FileCount == uploadFilesCount)
                {
                    // 読込バッファサイズ
                    const int READ_BYTE = Constants.ConDIV_BYTE / 10;

                    // 分割ファイルをリストアップ
                    List<string> divFiles = new List<string>();

                    // ディレクトリ直下のすべてのファイル一覧を取得する
                    foreach (FileInfo f in fiAlls)
                    {
                        divFiles.Add(f.FullName);
                    }

                    // 結合先ファイルを開く
                    using (FileStream wf = new FileStream(file_name, FileMode.Create, FileAccess.Write))
                    {
                        int readByte = 0;
                        long leftByte = 0;
                        byte[] readBuf = new byte[READ_BYTE];
                        foreach (string divFile in divFiles)
                        {
                            // 分割ファイルを開く
                            using (FileStream rf = new FileStream(divFile, FileMode.Open, FileAccess.Read))
                            {
                                leftByte = rf.Length;
                                while (leftByte > 0)
                                {
                                    // 分割ファイルから読み込む
                                    readByte = rf.Read(readBuf, 0, (int)Math.Min(READ_BYTE, leftByte));
                                    // 結合先ファイルに書きこむ
                                    wf.Write(readBuf, 0, readByte);
                                    // 読込情報の設定
                                    leftByte -= readByte;
                                }
                            }
                        }
                    }

                    // ディレクトリ直下のすべてのファイルを削除
                    Tools.CleanUp(kannjyaIdDrect_tmp);

                    //4.動画情報をDBに登録処理
                    Movie insertMovie = new Movie();
                    insertMovie.Group_id = request.Certification.Group_id;
                    insertMovie.Hosp_id = request.Certification.Hosp_id;
                    insertMovie.Patient_id = request.Patient_id;
                    //insertMovie.Vedio_no = request.
                    //insertMovie.Vedio_kbn = 11;
                    //insertMovie.Mask = request.Certification.;
                    //insertMovie.Photo_date = request.;
                    insertMovie.Remarks = request.Remarks;
                    //insertMovie.Vedio_path = request.;
                    //insertMovie.Edit_date = request.Movie_date.;
                    //insertMovie.Edit_user = 11;
                    //insertMovie.Regist_date = now();
                    //insertMovie.Vedio_tag = 11;
                    insertMovie.Vedio_size = request.Movie_size;
                    //insertMovie.Seq_no = 11;




                    ////TODO
                    //bool movieRet = Tools.InsertMovie(insertMovie);
                    ////5. 動画情報をDBに登録処理失敗の場合、動画ファイルを削除
                    //if (movieRet == false)
                    //{
                    //    BizException biz = new BizException("ServerError", Constants.MsgFailedRegister);
                    //    throw biz;

                    //    throw biz;
                    //}
                }


                // 結果
                MovieReponse movieReponse = new MovieReponse();
                movieReponse.Upload_result = Constants.MsgOK;

                return movieReponse;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                throw biz;

            }
            catch (Exception)
            {
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                throw biz;
            }
        }

        /// <summary>
        /// 動画情報削除
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public bool MediaDelete(DeleteRequest request)
        {
            bool del = false;
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(request.Certification.Group_id) == false)
                {
                    BizException biz = new BizException("GroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth) == false)
                {
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.動画ファイルをフォルダから削除
                //TODO
                //4.動画情報のDB情報を削除
                //TODO
                return del;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                throw biz;
            }
        }
    }
}
