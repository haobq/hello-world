﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    /// <summary>
    /// 患者検索のREQUSET
    /// </summary>
    public class PatientRequest
    {
        //認証情報
        public Certification Certification { get; set; }
        //施設ID
        public string Visit_id { get; set; }
        //訪問日
        public string Last_visit { get; set; }
        //患者名
        public string Patient_name { get; set; }

    }
}