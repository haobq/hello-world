﻿//using System;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Data;
//using System.Data.Odbc;
//using System.Configuration;
//using System.Reflection;
//using System.Net;

using System;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Reflection;
using System.Net;
using System.Text;

//JSON用
using System.Web.Script.Serialization;
using System.Runtime.Serialization.Json;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// 共通関数
/// </summary>
public class App_Function : System.Web.UI.Page
{
	/// <summary>
	/// web.configの値を呼ぶ
	/// </summary>
	/// <param name="str">ID</param>
	/// <returns>nullの場合は空文字を返す</returns>
	public string getConst(string str)
  {
    var conStr = ConfigurationManager.AppSettings[str];
    return (conStr != null) ? conStr : "";
  }

  /// <summary>
  /// セッション変数内文字列取得
  /// </summary>
  /// <param name="str">セッションID</param>
  /// <returns>nullの場合は空文字を返す</returns>
  public string getSession(string str)
  {
    return (Session[str] != null) ? Session[str].ToString() : "";
  }

  /// <summary>
  /// クエリーストリング取得
  /// </summary>
  /// <param name="str">keys</param>
  /// <returns>nullの場合は空文字を返す</returns>
  /// calendar.aspx?id=001&flg=1&keys=values
  /// 半角英数字以外を使うときはUrlEncodeしてから渡してください
  public string getQueryString(string str)
  {
    return (Request.QueryString[str] != null) ? System.Web.HttpUtility.UrlDecode(Request.QueryString[str]) : "";
  }

	#region DB関連
	//OdbcConnection dbCon = new OdbcConnection(ConfigurationManager.ConnectionStrings["sqlsvr"].ConnectionString);
	//OdbcDataAdapter dbAda = new OdbcDataAdapter();
	//OdbcCommand dbCom = new OdbcCommand();
	//Object thisLock = new Object();

	//OdbcConnection dbCon2 = new OdbcConnection(ConfigurationManager.ConnectionStrings["sqlsvr2"].ConnectionString);
	//OdbcDataAdapter dbAda2 = new OdbcDataAdapter();
	//OdbcCommand dbCom2 = new OdbcCommand();
	//Object thisLock2 = new Object();

	protected SqlConnection dbCon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlsvr"].ConnectionString);
	SqlDataAdapter dbAda = new SqlDataAdapter();
	SqlCommand dbCom = new SqlCommand();
	Object thisLock = new Object();

	SqlConnection dbCon2 = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlsvr"].ConnectionString);
	SqlDataAdapter dbAda2 = new SqlDataAdapter();
	SqlCommand dbCom2 = new SqlCommand();
	Object thisLock2 = new Object();

	/// <summary>
	/// SQLインサート
	/// 　DBはweb.ConfigのConnectionStrings 'sqlsvr2'(GWサーバ)を使用する
	/// </summary>
	/// <param name="p">インサート文（第二引数に何か入れるとエラーログを呼ばない）</param>
	/// <returns></returns>
	public bool Logging(params string[] p)
	{
		var rtn = true;
		lock (thisLock2)
		{
			SqlTransaction dbTra2 = null;
			try
			{
				dbCon2.Open();
				dbCom2.Connection = dbCon2;
				dbCom2.CommandText = p[0];
				dbTra2 = dbCon.BeginTransaction();
				dbCom2.Transaction = dbTra2;
				dbCom2.ExecuteNonQuery();
				dbTra2.Commit();
			}
			catch (Exception ex)
			{
				dbTra2.Rollback();
				if (p.Length == 1)
				{
					logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
					logError(p[0]);
				}
				else
				{
					jsl(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
					jsl(p[0]);
				}
				rtn = false;
			}
			finally
			{
				dbCon2.Close();
			}
		}
		return rtn;
	}

	/// <summary>
	/// sqlセレクトアイテム
	/// </summary>
	/// <param name="sentence"></param>
	/// <param name="selectItem"></param>
	/// <returns></returns>
	public string sqlSelect(string sentence, string selectItem)
	{
		var returnItem = "";
		lock (thisLock)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dbCon.Open();
				dbCom.Connection = dbCon;
				dbAda.SelectCommand = dbCom;
				dbCom.CommandText = sentence;
				dbAda.Fill(dataTable);

				if (dataTable.Rows.Count <= 0) returnItem = "";
				else returnItem = dataTable.Rows[0][selectItem].ToString();

				dataTable.Dispose();
			}
			catch (SqlException ex)
			{
				logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
				logError(sentence);
				returnItem = "";
			}
			finally
			{
				dbCon.Close();
			}
		}
		return returnItem;
	}

	/// <summary>
	/// SQLインサート
	/// </summary>
	/// <param name="p">インサート文（第二引数に何か入れるとエラーログを呼ばない）</param>
	/// <returns></returns>
	public bool sqlInsert(params string[] p)
	{
		var rtn = true;
		lock (thisLock)
		{
			SqlTransaction dbTra = null;
			try
			{
				dbCon.Open();
				dbCom.Connection = dbCon;
				dbCom.CommandText = p[0];
				dbTra = dbCon.BeginTransaction();
				dbCom.Transaction = dbTra;
				dbCom.ExecuteNonQuery();
				dbTra.Commit();
			}
			catch (Exception ex)
			{
				dbTra.Rollback();
				if (p.Length == 1)
				{
					logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
					logError(p[0]);
				}
				else
				{
					jsl(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
					jsl(p[0]);
				}
				rtn = false;
			}
			finally
			{
				dbCon.Close();
			}
		}
		return rtn;
	}

	/// <summary>
	/// SQLアップデート
	/// </summary>
	/// <param name="sentence"></param>
	/// <returns></returns>
	public bool sqlUpdate(string sentence)
	{
		var rtn = true;
		lock (thisLock)
		{
			SqlTransaction dbTra = null;
			try
			{
				dbCon.Open();
				dbCom.Connection = dbCon;
				dbCom.CommandText = sentence;
				dbTra = dbCon.BeginTransaction();
				dbCom.Transaction = dbTra;
				dbCom.ExecuteNonQuery();
				dbTra.Commit();
			}
			catch (Exception ex)
			{
				dbTra.Rollback();
				logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
				logError(sentence);
				rtn = false;
			}
			finally
			{
				dbCon.Close();
			}
		}
		return rtn;
	}

	/// <summary>
	/// SQLアップデート
	/// </summary>
	/// <param name="sentence"></param>
	/// <returns></returns>
	public bool sqlUpdate(string sentence, IEnumerable<SqlParameter> param)
	{
		var rtn = true;
		lock (thisLock)
		{
			SqlTransaction dbTra = null;
			try
			{
				dbCon.Open();
				dbCom.Connection = dbCon;
				dbCom.CommandText = sentence;
				dbCom.Parameters.Clear();
				dbCom.Parameters.AddRange(param.ToArray());
				dbTra = dbCon.BeginTransaction();
				dbCom.Transaction = dbTra;
				dbCom.ExecuteNonQuery();
				dbTra.Commit();
			}
			catch (Exception ex)
			{
				dbTra.Rollback();
				logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
				logError(sentence);
				rtn = false;
			}
			finally
			{
				dbCon.Close();
			}
		}
		return rtn;
	}

	/// <summary>
	/// SQLデリート
	/// </summary>
	/// <param name="sentence"></param>
	/// <returns></returns>
	public bool sqlDelete(string sentence)
	{
		var rtn = true;
		lock (thisLock)
		{
			SqlTransaction dbTra = null;
			try
			{
				dbCon.Open();
				dbCom.Connection = dbCon;
				dbCom.CommandText = sentence;
				dbTra = dbCon.BeginTransaction();
				dbCom.Transaction = dbTra;
				dbCom.ExecuteNonQuery();
				dbTra.Commit();
			}
			catch (Exception ex)
			{
				dbTra.Rollback();
				logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
				logError(sentence);
				rtn = false;
			}
			finally
			{
				dbCon.Close();
			}
		}
		return rtn;
	}

	/// <summary>
	/// SQLトランザクション
	/// </summary>
	/// <param name="p">SQL文</param>
	/// <returns></returns>
	public bool sqlTran(params string[] p)
	{
		var rtn = true;
		lock (thisLock)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dbCon.Open();
				dbCom.Connection = dbCon;
				dbAda.SelectCommand = dbCom;
				dbAda.InsertCommand = dbCom;
				dbAda.UpdateCommand = dbCom;
				dbAda.DeleteCommand = dbCom;

				SqlTransaction dbTra = null;
				dbTra = dbCon.BeginTransaction();
				dbCom.Transaction = dbTra;

				for (var i = 0; i < p.Length; i++)
				{
					try
					{
						dbCom.CommandText = p[i];
						dbCom.ExecuteNonQuery();
					}
					catch (Exception ex)
					{
						dbTra.Rollback();
						logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
						logError(p[i]);
						throw ex;
					}
				}
				dbTra.Commit();
			}
			catch (SqlException ex)
			{
				logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
				rtn = false;
			}
			finally
			{
				dbCon.Close();
			}
		}
		return rtn;
	}

	/// <summary>
	/// SQLセレクトテーブル
	/// </summary>
	/// <param name="sentence"></param>
	/// <param name="dataTbl"></param>
	/// <returns></returns>
	public bool sqlSelectTable(string sentence, ref DataTable dataTbl)
	{
		var rtn = true;
		lock (thisLock)
		{
			try
			{
				dbCon.Open();
				dbCom.Connection = dbCon;
				dbAda.SelectCommand = dbCom;
				dbCom.CommandText = sentence;
				dbAda.Fill(dataTbl);
				dbCon.Close();
			}
			catch (SqlException ex)
			{
				logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
				logError(sentence);
				rtn = false;
			}
			finally
			{
				dbCon.Close();
			}
		}
		return rtn;
	}

	/// <summary>
	/// SQLセレクトデータセット
	/// </summary>
	/// <param name="sentence"></param>
	/// <param name="dataSet"></param>
	/// <param name="tableName"></param>
	/// <returns></returns>
	public bool sqlSelectDataSet(string sentence, ref System.Data.DataSet dataSet, string tableName)
	{
		var rtn = true;
		lock (thisLock)
		{
			try
			{
				dbCon.Open();
				dbCom.Connection = dbCon;
				dbAda.SelectCommand = dbCom;
				dbCom.CommandText = sentence;
				dbAda.Fill(dataSet, tableName);
			}
			catch (SqlException ex)
			{
				logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
				logError(sentence);
				rtn = false;
			}
			finally
			{
				dbCon.Close();
			}
		}
		return rtn;
	}

	/// <summary>
	/// SQLエスケープ
	/// </summary>
	/// <param name="str"></param>
	/// <returns></returns>
	public string sqlTabooChar(string str)
  {
    return str.Replace("'","''");
  }

  //Public Function OracleTabooChar(ByVal value As String) As String

  #endregion

  #region ログ
  public bool logLong(short hospId, short kind,string businessName, string displayName,
    string description,string patientId,string patientName, string exmDate)
  {
    try {
    DateTime dTime = new DateTime();
    string exmDateTmp =(DateTime.TryParse(exmDate, out dTime)) ? dTime.ToString("yyyy/MM/dd") : "1999/01/01";

      var sql = "insert tbl_operation_log values(";
      sql += hospId + ","; //HOSP_ID:numeric(18, 0)
      sql += kind +","; //KIND:smallint
      sql += "SYSDATETIME(),"; //DO_DATE:datetime
      sql += "'" + omitLeftB(sqlTabooChar(businessName), 40) + "',"; //BUSINESS_NAME:varchar(40)
      sql += "'" + omitLeftB(sqlTabooChar(displayName), 20) + "',"; //DISPLAY_NAME:varchar(20)
      sql += "'" + omitLeftB(sqlTabooChar(description), 500) + "',";//DESCRIPTION:varchar(500)
      sql += "'" + omitLeftB(patientId, 10) + "',"; //PATIENT_ID:varchar(10)
      sql += "'" + omitLeftB(sqlTabooChar(patientName), 30) + "',"; //PATIENT_NAME:varchar(30)
      sql += "CONVERT(datetime, '" + exmDateTmp + "'),"; //EXM_DATE:date
      sql += "'" + omitLeftB(getSession("HOST_NAME"), 20) + "',"; //HOST_NAME:varchar(20)
      sql += "'" + omitLeftB(getSession("LOGIN_ID"), 10) + "',"; //LOGIN_ID:varchar(10)
      sql += "'" + omitLeftB(getSession("TEAM_ID"), 10) + "'"; //TEAM_ID:varchar(10)
      sql += ")";

      sqlInsert(sql,"log");
    }

    catch (Exception ex) {
      jsl(ex.ToString());
      return false;
    }
    return true;
  }

  public bool logError(string description)
  {
    logLong(-1, -1, "", "", description, "", "", "");
    return true;
  }

  #endregion



  /// <summary>
  /// ランダムな英数字を生成する。前回の値と別のものを作りたい場合は、第二引数に文字列を渡せば違うものを生成する。
  /// </summary>
  /// <param name="cnt">生成する文字数（255文字まで）</param>
  /// <param name="p">前回の値</param>
  /// <returns>ランダムな英数字</returns>
  public string getKey(byte cnt, params string[] p)
  {
    string tmp = "", pre = "",  pw="";
    if (p.Length > 0) pre = p[0];
    do
    {
      do {
        //128文字が上限なため
        pw = System.Web.Security.Membership.GeneratePassword(128, 0);
        //記号とアンダースコアの置換
        pw = System.Text.RegularExpressions.Regex.Replace(pw, "\\W", "").Replace("_", "");
        tmp += pw;
      } while(cnt >= tmp.Length);
      tmp = tmp.Substring(0, cnt);
    } while (tmp == pre);
    return tmp;
  }

  /// <summary>
  /// バージョンを取得する
  /// </summary>
  /// <returns>バージョン</returns>
  /// <remarks>キャッシュ用。リリース時はバージョンを固定にする</remarks>
  public string getVersion()
  {
    string rtn = "";
    //リリース時に更新日にする
    //rtn = 20140701
    rtn = getKey(8);
    return rtn;
  }

  #region JavaScript
  /// <summary>
  /// JavaScript実行
  /// </summary>
  /// <param name="p">実行させたいJavaScript</param>
  public void js(string p)
  {
    if (p.Substring(p.Length - 1, 1) != ";") p += ";";
    ScriptManager.RegisterStartupScript(Page, Page.GetType(), getKey(16), p, true);
  }

  /// <summary>
  /// JavaScriptのconsole.logを出す。
  /// </summary>
  /// <param name="p">複数出せる</param>
  public void jsl(params string[] p)
  {
    string str = "", tmp = "";
    for (int i = 0; i <= p.Length - 1; i++)
    {
      if (p[i] == null)
        p[i] = "null";
      if (i > 0)
        str += ",";
      tmp = p[i].Replace("\\", "\\\\").Replace("'", "\\'");
      tmp = tmp.Replace("\n", "\\n");
      tmp = tmp.Replace("\r", "\\r");
      tmp = tmp.Replace("\r\n", "\\r\\n");
      str += "'" + tmp + "'";
    }

    js("console.log(" + str + ");");
  }
  #endregion

  #region 文字列
  /// <summary>半角 1 バイト、全角 2 バイトとして、指定された文字列のバイト数を返します。</summary>
  /// <param name="str">バイト数取得の対象となる文字列。</param>
  /// <returns>半角 1 バイト、全角 2 バイトでカウントされたバイト数。</returns>
  public static int LenB(string str)
  {
    return System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(str);
  }


  /// <summary>
  /// 文字列の左端から指定したバイト数までの文字列を返します。
  /// </summary>
  /// <param name="str">取り出す元になる文字列</param>
  /// <param name="cnt">取り出すバイト数</param>
  /// <returns>左端から指定されたバイト数までの文字列</returns>
  public string omitLeftB(string str, int cnt)
  {
    return (LenB(str) >= cnt) ? LeftB(str,cnt): str;
  }

  /// <summary>文字列の左端から指定したバイト数分の文字列を返します。</summary>
  /// <param name="str">取り出す元になる文字列<param>
  /// <param name="cnt">取り出すバイト数</param>
  /// <returns>左端から指定されたバイト数分の文字列</returns>
  public static string LeftB(string str, int cnt)
  {
    return MidB(str, 1, cnt);
  }

  /// <summary>文字列の指定されたバイト位置以降のすべての文字列を返します。</summary>
  /// <param name="str">取り出す元になる文字列。</param>
  /// <param name="iStart">取り出しを開始する位置。</param>
  /// <returns>指定されたバイト位置以降のすべての文字列。</returns>
  public static string MidB(string str, int iStart)
  {
    System.Text.Encoding hEncoding = System.Text.Encoding.GetEncoding("Shift_JIS");
    byte[] btBytes = hEncoding.GetBytes(str);

    return hEncoding.GetString(btBytes, iStart - 1, btBytes.Length - iStart + 1);
  }

  /// <summary>文字列の指定されたバイト位置から、指定されたバイト数分の文字列を返します。</summary>
  /// <param name="str">取り出す元になる文字列。</param>
  /// <param name="iStart">取り出しを開始する位置。</param>
  /// <param name="cnt">取り出すバイト数。</param>
  /// <returns>指定されたバイト位置から指定されたバイト数分の文字列。</returns>
  public static string MidB(string str, int iStart, int cnt)
  {
    System.Text.Encoding hEncoding = System.Text.Encoding.GetEncoding("Shift_JIS");
    byte[] btBytes = hEncoding.GetBytes(str);
    return hEncoding.GetString(btBytes, iStart - 1, cnt);
  }

  /// <summary>文字列の右端から指定されたバイト数分の文字列を返します。</summary>
  /// <param name="str">取り出す元になる文字列。</param>
  /// <param name="cnt">取り出すバイト数。</param>
  /// <returns>右端から指定されたバイト数分の文字列。</returns>
  public static string RightB(string str, int cnt)
  {
    System.Text.Encoding hEncoding = System.Text.Encoding.GetEncoding("Shift_JIS");
    byte[] btBytes = hEncoding.GetBytes(str);

    return hEncoding.GetString(btBytes, btBytes.Length - cnt, cnt);
  }

  /// <summary>
  /// HTMLエンコードと改行の置換
  /// </summary>
  /// <param name="str"></param>
  /// <returns></returns>
  public string getHtmlEncode(string str) {
    var tmp = "";
    tmp = WebUtility.HtmlEncode(str);
    tmp = str.Replace("<br />", Environment.NewLine);
    return tmp;
  }

  /// <summary>
  /// HTMLデコードと改行の置換
  /// </summary>
  /// <param name="str"></param>
  /// <returns></returns>
  public string getHtmlDecode(string str) {
    var tmp = "";
    tmp = str.Replace(Environment.NewLine, "<br />");
    tmp = WebUtility.HtmlDecode(str);
    return tmp;
  }

  #endregion

  /// <summary>
  /// 画像がなければ spacer.png にする
  /// </summary>
  /// <param name="imgUrl"></param>
  /// <returns></returns>
  public string getExistImg(string imgUrl)
  {
    try
    {
      WebRequest req = WebRequest.Create(imgUrl);
      WebResponse res = req.GetResponse();
      res.Close();
    }
    catch (Exception ex)
    {
      logError(MethodBase.GetCurrentMethod().Name + ":" + ex.Message);
      logError(imgUrl);
      imgUrl = ResolveUrl("~/Img/spacer.png");
    }
    return imgUrl;
  }

  /// <summary>
  /// HTMLヘッダー取得
  /// </summary>
  /// <param name="title"></param>
  /// <returns></returns>
  public string getHeader(string title) {
    string str = "<!DOCTYPE html>";
    str += "<html>";
    str += "<head runat='server'>";
    str += getHeaderAjax(title);
    return str;
  }

  /// <summary>
  /// HTMLヘッダー取得(Ajax) Ajax Tool kit を使う場合 <head runat='server'> を直接書かないとダメなため
  /// </summary>
  /// <param name="title"></param>
  /// <returns></returns>
  public string getHeaderAjax(string title)
  {
    string str = "<meta charset='UTF-8' />";
    //ページキャッシュを無効（HTTP/1.0）
    str += "<meta http-equiv='pragma' content='no-cache' />";
    //ページキャッシュを無効（HTTP/1.1）
    str += "<meta http-equiv='cache-control' content='no-cache' />";
    //ページの有効期限
    str += "<meta http-equiv='expires' content='0' />";
    //拡大縮小させない
    str += "<meta name='viewport' content='width=device-width,initial-scale = 1.0,maximum-scale=1.0,user-scalable=0,user-scalable=no' />";
    //拡大縮小を許可する
    //str += "<meta name='viewport' content='width=device-width,initial-scale=1.0' />"
    //iOSでウェブアプリとして表示
    //str += "<meta name='apple-mobile-web-app-capable' content='yes' />"
    str += "<meta name='apple-mobile-web-app-capable' content='no' />";
    //IEは最新版を使う
    str += "<meta http-equiv='X-UA-Compatcntle' content='IE=Edge' />";

    //クロールさせない
    str += "<meta name='ROBOTS' content='NOINDEX, NOFOLLOW' />";
    str += "<meta http-equiv='imagetoolbar' content='no' />";
    str += "<meta http-equiv='imagetoolbar' content='false' />";

    //favicon
    str += "<link rel='shortcut icon' type='image/vnd.microsoft.icon' href='" + ResolveUrl("~/favicon.ico") + "'>";
    str += "<link rel='icon' type='image/vnd.microsoft.icon' href='" + ResolveUrl("~/favicon.ico") + "'>";
    /* favicon その他対応。必要になったらコメントアウト戻す。ResolveUrlもつける。
    str += "<link rel='apple-touch-icon' sizes='57x57' href='/Img/favicons/apple-touch-icon-57x57.png'>";
    str += "<link rel='apple-touch-icon' sizes='60x60' href='/Img/favicons/apple-touch-icon-60x60.png'>";
    str += "<link rel='apple-touch-icon' sizes='72x72' href='/Img/favicons/apple-touch-icon-72x72.png'>";
    str += "<link rel='apple-touch-icon' sizes='76x76' href='/Img/favicons/apple-touch-icon-76x76.png'>";
    str += "<link rel='apple-touch-icon' sizes='114x114' href='/Img/favicons/apple-touch-icon-114x114.png'>";
    str += "<link rel='apple-touch-icon' sizes='120x120' href='/Img/favicons/apple-touch-icon-120x120.png'>";
    str += "<link rel='apple-touch-icon' sizes='144x144' href='/Img/favicons/apple-touch-icon-144x144.png'>";
    str += "<link rel='apple-touch-icon' sizes='152x152' href='/Img/favicons/apple-touch-icon-152x152.png'>";
    str += "<link rel='apple-touch-icon' sizes='180x180' href='/Img/favicons/apple-touch-icon-180x180.png'>";
    str += "<link rel='icon' type='image/png' sizes='192x192' href='/Img/favicons/android-chrome-192x192.png'>";
    str += "<link rel='icon' type='image/png' sizes='48x48' href='/Img/favicons/favicon-48x48.png'>";
    str += "<link rel='icon' type='image/png' sizes='96x96' href='/Img/favicons/favicon-96x96.png'>";
    str += "<link rel='icon' type='image/png' sizes='96x96' href='/Img/favicons/favicon-160x160.png'>";
    str += "<link rel='icon' type='image/png' sizes='96x96' href='/Img/favicons/favicon-196x196.png'>";
    str += "<link rel='icon' type='image/png' sizes='16x16' href='/Img/favicons/favicon-16x16.png'>";
    str += "<link rel='icon' type='image/png' sizes='32x32' href='/Img/favicons/favicon-32x32.png'>";
    str += "<link rel='manifest' href='/Img/favicons/manifest.json'>";
    str += "<meta name='msapplication-TileColor' content='#2d88ef'>";
    str += "<meta name='msapplication-TileImage' content='/Img/favicons/mstile-144x144.png'>";
     */

    //モバイル対応。後で必要になったら作り込む
    //if (Session["IsMobile"] == "1")
    //{
    //  //ipad
    //  str += "<link rel='stylesheet' type='text/css' href='" + ResolveUrl("~/cmnMobile.css") + "?r=" + getVersion() + "' />";
    //}
    //else
    //{
    //  //pc
    //  str += "<link rel='stylesheet' type='text/css' href='" + ResolveUrl("~/cmnPc.css") + "?r=" + getVersion() + "' />";
    //}

    str += "<link rel='stylesheet' type='text/css' href='" + ResolveUrl("~/cmn.css") + "?r=" + getVersion() + "' />";
    str += "<script async src='" + ResolveUrl("~/cmn.js") + "?r=" + getVersion() + "'></script>";
    str += "<script defer src='" + ResolveUrl("~/Scripts/svgxuse.js") + "'></script>";

    //JSON非対応用
    str += "<script type='text/javascript'>!window.JSON && document.write(\"<script src='" + ResolveUrl("~/Scripts/json2.js") + "'><\\/script>\")</script>";

    str += "<title>" + title + "</title>";
    return str;
  }

  /// <summary>
  /// テンキー作成
  /// </summary>
  /// <returns></returns>
  public string getTenKey()
  {
    var keys = new[] { 7, 8, 9, 4, 5, 6, 1, 2, 3, 0 };
    var str = "<script defer src='" + ResolveUrl("~/Scripts/tenkey.js") + "'></script>";
    str += "<div id='divTenKey'>";
    str += "<div onclick='pushTenKeyBS()'>BS</div>";
    str += "<div onclick='clearTenKey()'>Clear</div>";
    for (var i = 0; i < 10; i++)
    {
      str += String.Format("<div onclick = 'pushTenKey(this)'>{0}</div>", keys[i].ToString());
    }
    str += "<div onclick='pushOK()'>OK</div>";
    str += "</div>";
    return str;
  }

	//必要であれば検証するか
	/*
	/// <summary>
	/// パネルオンオフ
	/// </summary>
	/// <param name="p"></param>
	public void turnPnl(params string[] p)
	{
	  try
	  {
		string _id = p[0];
		int n = 0;
		if (p.Length == 1)
		{
		  if (((Panel)FindControl(_id + n.ToString())).Visible == true) n = 1;
		}
		else
		{
		  n = int.Parse(p[1]);
		}
		Panel[] objs = new Panel[3];
		objs[0] = (Panel)FindControl(_id + n.ToString());
		objs[1] = (Panel)FindControl(_id + (1 - n).ToString());
		objs[0].Visible = true;
		objs[1].Visible = false;
	  }
	  catch (Exception ex)
	  {
		jsl(ex.Message);
	  }
	}
	*/
}