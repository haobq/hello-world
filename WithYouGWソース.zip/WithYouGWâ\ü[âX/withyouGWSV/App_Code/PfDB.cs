﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// PfDB の概要の説明です
/// </summary>
public class PfDB : App_Function
{
    public PfDB()
    {
        dbCon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlsvrProfile"].ConnectionString);
    }
}
