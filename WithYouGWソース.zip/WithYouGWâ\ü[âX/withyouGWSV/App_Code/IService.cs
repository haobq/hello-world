﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// メモ: [リファクター] メニューの [名前の変更] コマンドを使用すると、コードと config ファイルの両方で同時にインターフェイス名 "IService" を変更できます。
[ServiceContract]
public interface IService
{

	[OperationContract]
	string GetData(int value);

	[OperationContract]
	CompositeType GetDataUsingDataContract(CompositeType composite);

	// TODO: ここにサービス操作を追加します。
	[OperationContract]
	[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare)]
	bool CheckUser(string hospId, string ipAddress);

	[OperationContract]
	[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare)]
	bool ContactWithYouData(string hospId, string ipAddress, ref string msgUid, ref int fileCount, ref string fileNames);

	[OperationContract]
	[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare)]
	bool GetFile(string hospId, string ipAddress, string msgUid, string fileName, out byte[] data);

	[OperationContract]
	[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare)]
	bool NoticeFileError(string hospId, string ipAddress, string msgUid, string fileName, string errMsg, bool endFlag);

	[OperationContract]
	[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare)]
	bool NoticeFileOK(string hospId, string ipAddress, string msgUid, string fileName, bool endFlag);

	[OperationContract]
	[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare)]
	bool SendData(string hospId, string ipAddress, string msgUid, int dataKind, string fileName, byte[] data, ref string errMsg, bool endFlag, bool startFlag);

	[OperationContract]
	[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare)]
	bool GetProcessedStatus(string hospId, string ipAddress, string msgUid, ref int total, ref int processed);

	//20180417 /S H30改正対応 046
	[OperationContract]
	[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare)]
	bool Ping(string hospId, string ipAddress);
	//20180417 /E H30改正対応 046

}

// サービス操作に複合型を追加するには、以下のサンプルに示すようにデータ コントラクトを使用します。
[DataContract]
public class CompositeType
{
	bool boolValue = true;
	string stringValue = "Hello ";

	[DataMember]
	public bool BoolValue
	{
		get { return boolValue; }
		set { boolValue = value; }
	}

	[DataMember]
	public string StringValue
	{
		get { return stringValue; }
		set { stringValue = value; }
	}
}
[DataContract]
public class test
{

}
