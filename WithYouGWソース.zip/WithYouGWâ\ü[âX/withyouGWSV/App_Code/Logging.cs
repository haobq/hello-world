using System;
using System.IO;

//namespace WithYouGW
//{
	//
	// ���M���O class
	//
	public class Logging
	{
		const string m_defaultDateFormat = "HH:mm:ss.ff";

		private DateTime m_orgDateTime;
		private string m_logDir;
		private StreamWriter m_fileStream = null;
		private string m_dateFormat;
		private string m_prefix;
		private int m_storage_days = 0;

		private string m_logFileName = "";

		public Logging(string prefix)
		{
			m_prefix = prefix;
		}

		~Logging()
		{
			FileClose();
		}

		//
		// ���M���O�J�n
		//
		public bool LoggingStart(string logDir, string dateFormat, int days)
		{
			if (util.CreateDirectory(logDir) == false)
			{
				//MessageBox.Show("���O�t�H���_�̍쐬�Ɏ��s���܂���");
				return false;
			}
			m_logDir = logDir;
			m_dateFormat = dateFormat;
			m_storage_days = days;
			FileOpen();

			return true;
		}
		public bool LoggingStart(string logDir, int days)
		{
			if (days == 0) days = 60;
			return (LoggingStart(logDir, m_defaultDateFormat, days));
		}

		//
		// ���M���O�I��
		//
		public void LoggingEnd()
		{
			m_logDir = "";
			m_dateFormat = "";
			FileClose();
		}

		//
		// ���O�t�@�C���I�[�v��
		//
		private bool FileOpen()
		{
			m_orgDateTime = (DateTime.Now).Date;    // �N�����̐ݒ�

			util.CleanUpFile(m_logDir, m_storage_days);     // ���M���O���Ԃ̊m�F

			// ���O�t�@�C��������
			string format = "yyyyMMdd";
			string suffix = "_WithYouGW.txt";

			m_logFileName = util.FileNameFromDate(m_logDir, format, suffix, true);

			try
			{
				if (m_fileStream != null) FileClose();
				// �ǉ������݁ASJIS
				m_fileStream = new StreamWriter(m_logFileName, true, util.EncodeShiftJis);
			}
			catch (Exception e)
			{
				//MessageBox.Show(e.ToString());
				return false;
			}

			return true;
		}

		//
		// File Close
		//
		public void FileClose()
		{
			if (m_fileStream != null) m_fileStream.Close();
			m_fileStream = null;
		}

		//
		// ���M���O
		//
		public void Str(string format, params object[] arg)
		{
			string logStr = String.Format(format, arg);
			Str(logStr);
		}
		public void Str(string logStr)
		{
			string wk = "";
			if (m_orgDateTime < (DateTime.Now).Date) FileOpen();        // ���t�ύX�Ȃ�

			wk = String.Format("{0} {1}", (DateTime.Now).ToString(m_dateFormat), logStr);
			m_fileStream.WriteLine(wk);
			m_fileStream.Flush();

			//if (mode == false) return;
		}

		public string LogFileName
		{
			get { return m_logFileName; }
			set { m_logFileName = value; }
		}

	}

//}
