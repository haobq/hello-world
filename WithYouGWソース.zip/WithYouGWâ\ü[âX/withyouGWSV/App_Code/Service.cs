﻿using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Net;
using Microsoft.VisualBasic;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Data.SqlClient;

// メモ: [リファクター] メニューの [名前の変更] コマンドを使用すると、コード、svc、および config ファイルで同時にクラス名 "Service" を変更できます。
public class Service : IService
{
	const string EndMark = "END";

	public const string MSG_ERR_FILE_GET_ERROR = "ファイル「{0}」のマスタ設定に失敗しました";
	public const string MSG_ERR_FILE_FORMAT = "ファイル「{0}」が不正なため読み込めませんでした(終了マーク無し)";
	public const string MSG_ERR_REGIST_MASTER = "医院ID「{0}」のマスタ(「{1}」)登録に失敗しました";
	//public const string MSG_ERR_TABLE_ACCESS = "テーブル「{0}」にアクセスできませんでした";
	public const string MSG_ERR_SEND_FILE_INFO = "ファイル「{0}」がクライアントでの情報設定に失敗しました";
	public const string MSG_ERR_FILE_INFO = "ファイル「{0}」の情報取得に失敗しました";
	public const string MSG_ERR_EXCEPTION = "例外発生：{0} {1}";
	public const string MSG_ERR_CREATE_FOLDER = "フォルダ「{0}」の作成に失敗しました";
	public const string MSG_ERR_MOVE_FILE = "ファイル「{0}」の移動に失敗しました";
	public const string MSG_ERR_SET_DB = "DB「{0}」の登録に失敗しました";
	public const string MSG_ERR_GET_FILENAMES = "フォルダ[{0}]のファイル名の取得に失敗しました";

	public const string MSG_INFO_FILE_INFO = "ファイル「{0}」の情報をクライアントに送信しました";
	public const string MSG_INFO_REGIST_MASTER = "医院ID「{0}」のマスタ(「{1}」)を設定しました";
    //20180411 yamada add /S 患者ＩＤ、患者氏名をログに出力する
    //ver2.2管理表No:019
    public const string MSG_INFO_PATIENTINFO = "処理データ：医院ID「{0}」患者ID「{1}」患者氏名「{2}」";
    //20180411 yamada add /E

    //20180416 yamada add /S 患者ＩＤ重複チェック
    //ver2.2管理表No:048
    public const string MSG_ERR_PATIENT_DUPLICATE = "患者IDが既に存在する為変更できません。「{0}」[{1}]→「{2}」";
    //20180416 yamada add　/E

	//20180417 /S H30改正対応 046
	public const string MSG_INFO_PING_RECV = "ping recv. ip: {0}";
	//20180417 /E H30改正対応 046

	public enum eJob { DR = 3, DH = 4 }
	public enum eTenki { Moving = 1, Dead=2 }
	public enum eStatus { Active=1, Normal=2, Err=4 }
	public const bool err = true;
	public const bool noErr = false;

    //20180413 yamada add /S StrConv用ロケール指定
    //ver2.2管理表No:024
    private readonly int _LCID = new System.Globalization.CultureInfo("ja-JP", true).LCID;
    //20180413 yamada add /E


    /// <summary>
    /// 認証チェック
    /// </summary>
    /// <param name="hospId"></param>
    /// <param name="ipAddress"></param>
    /// <returns></returns>
    public bool CheckUser(string hospId, string ipAddress)
	{
        //20180529 upd /S 介護度連携対応
        //bool ret = false;
        //const string sql_template = "select * from mst_hosp_gw where " +
        //							"hosp_id = '{0}' and karte_ip = '{1}' ";

        //try
        //{
        //	// 認証チェック(医院ID、IPアドレスで認証チェック
        //	App_Function fnc = new App_Function();
        //	string sql = string.Format(sql_template, hospId, ipAddress);
        //	if (fnc.sqlSelect(sql, "karte_kbn").Length != 0) ret = true;
        //}
        //catch (Exception ex)
        //{
        //	LogGW(hospId, err, "例外発生：CheckUser() {0}", ex.ToString());
        //	return ret;
        //}

        //return ret;
        string p1;
        return CheckUser2(hospId, ipAddress, out p1);
        //20180529 upd /E 介護度連携対応
    }

    //20180529 add /S 介護度連携対応
    /// <summary>
    /// 認証チェック
    /// </summary>
    /// <param name="hospId"></param>
    /// <param name="ipAddress"></param>
    /// <returns></returns>
    private bool CheckUser2(string hospId, string ipAddress, out string care_renkei)
    {
        care_renkei = "2";

        bool ret = false;
        const string sql_template = "select * from mst_hosp_gw where " +
                                    "hosp_id = '{0}' and karte_ip = '{1}' ";

        try
        {
            // 認証チェック(医院ID、IPアドレスで認証チェック
            App_Function fnc = new App_Function();
            string sql = string.Format(sql_template, hospId, ipAddress);
            var dt = new DataTable();
            ret = fnc.sqlSelectTable(sql, ref dt)
                && 0 < dt.Rows.Count
                && dt.Rows[0]["karte_kbn"].ToString().Length != 0;
            care_renkei = dt.Rows[0]["care_renkei"].ToString();
            dt.Dispose();
        }
        catch (Exception ex)
        {
            LogGW(hospId, err, "例外発生：CheckUser2() {0}", ex.ToString());
            return ret;
        }

        return ret;
    }
    //20180529 add /E 介護度連携対応

    /// <summary>
    /// WithYouデータ問合せ
    /// </summary>
    /// <param name="hospId"></param>
    /// <param name="ipAddress"></param>
    /// <param name="msgUid"></param>
    /// <param name="fileCount"></param>
    /// <param name="fileNames"></param>
    /// <returns></returns>
    public bool ContactWithYouData(string hospId, string ipAddress, ref string msgUid, ref int fileCount, ref string fileNames)
	{
		bool ret = false;
		//fileCount = 0;
		fileCount = -1;
		fileNames = "";

        // 処理順が前後する問題があるためset_timeで昇順にソートで一番古いものを取得 2017.11.14 chg
        //const string sql_template = "select * from tbl_data_set_flg where set_status&1=1 and hosp_id = '{0}'";

        //20200116 /S Profile #425 訪問診療データの処理で、テーブル「tbl_data_set_flg」の検索条件にフラグを追加し、フラグ設定のみ対象とする
        ////20180411 yamada add /S 患者ＩＤ、患者氏名をログに出力する
        ////ver2.2管理表No:019
        ////const string sql_template = "select * from tbl_data_set_flg where set_status&1=1 and hosp_id = '{0}' order by set_time";
        //const string sql_template = "select d.*,p.patient_name from tbl_data_set_flg d, tbl_patient p " + 
        //                            "where d.hosp_id = p.hosp_id and d.patient_id = p.patient_id and d.set_status&1=1 and d.hosp_id = '{0}' order by d.set_time";
        ////20180411 yamada add /E
        const string sql_template = "select d.*,p.patient_name from tbl_data_set_flg d, tbl_patient p " + 
                                    "where d.hosp_id = p.hosp_id and d.patient_id = p.patient_id and d.set_status&1=1 and d.hosp_id = '{0}' and d.data_type = '1' order by d.set_time";
        //20200116 /E

        try
        {
			//LogGW(hospId, "[ContactWithYouData]");

			if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認

			// フラグ確認
			App_Function fnc = new App_Function();
			DataTable dt = new DataTable();
			string sql = string.Format(sql_template, hospId);

			dt = new DataTable();
			ret = fnc.sqlSelectTable(sql, ref dt);
			//if (dt.Rows.Count == 0) return false;
			//2020.01.28 modify
			//if (dt.Rows.Count == 0) return true;
			//2020.02.04 modify
			//if (dt.Rows.Count == 0) return ContactWithYouDataKInputList(hospId, ipAddress, ref msgUid, ref fileCount, ref fileNames);
			if (dt.Rows.Count == 0) {
				var res = ContactWithYouDataKInputList(hospId, ipAddress, ref msgUid, ref fileCount, ref fileNames);
				if (!res || 0 < fileCount) return res;

				res = ContactWithYouDataGeneralDisease(hospId, ipAddress, ref msgUid, ref fileCount, ref fileNames);
				if (!res || 0 < fileCount) return res;

				res = ContactWithYouDataTakingMedicines(hospId, ipAddress, ref msgUid, ref fileCount, ref fileNames);
				if (!res || 0 < fileCount) return res;

				return res;
			}

			string path = dt.Rows[0]["file_path"].ToString();

            //20180411 yamada add /S 患者ＩＤ、患者氏名をログに出力する
            //ver2.2管理表No:019
            string patientId = dt.Rows[0]["patient_id"].ToString();
            string patientName = dt.Rows[0]["patient_name"].ToString();
            //処理データ：医院ID「{0}」患者ID「{1}」患者氏名「{2}」
            LogGW(hospId, MSG_INFO_PATIENTINFO, hospId, patientId, patientName);

            //20180411 yamada add /E

            // path内のファイル名を取得
            string[] files = Directory.GetFiles(path);

			fileCount = files.Length;
			if (fileCount == 0)
			{
				LogGW(hospId, err, MSG_ERR_GET_FILENAMES, path);
				//return false;
				return true;
			}

			for (int i = 0; i < fileCount; i++)
			{
				if (i != 0) fileNames += ",";
				fileNames += Path.GetFileName(files[i]);
			}

			msgUid = dt.Rows[0]["msg_uid"].ToString();
			ret = true;
		}
		catch(Exception ex)
		{
			LogGW(hospId, err, "例外発生：ContactWithYouData() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// ファイル取得
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="ipAddress"></param>
	/// <param name="data"></param>
	/// <returns></returns>
	public bool GetFile(string hospId, string ipAddress, string msgUid, string fileName, out byte[] data)
	{
		bool ret = true;
		data = new byte[1];
		const string sql_template = "select * from tbl_data_set_flg where msg_uid='{0}'";

		try
		{
			if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認

			string sql = string.Format(sql_template, msgUid);
			App_Function fnc = new App_Function();
			string path = fnc.sqlSelect(sql, "file_path");

			if (util.FileToByteArray(out data, Path.Combine(path, fileName)))
			{
				LogGW(hospId, noErr, MSG_INFO_FILE_INFO, fileName);
			}
			else
			{
				LogGW(hospId, err, MSG_ERR_FILE_INFO, fileName);
				ret = false;
			}
			
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：GetFile() {0}", ex.ToString());
			return ret;
		}

		return ret;
	}

	/// <summary>
	/// ファイルエラー通知
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="ipAddress"></param>
	/// <param name="fileName"></param>
	/// <param name="endFlag"></param>
	/// <returns></returns>
	public bool NoticeFileError(string hospId, string ipAddress, string msgUid, string fileName, string errMsg, bool endFlag)
	{
		bool ret = false;
		bool err = true;

		const string sql_template = "insert into tbl_send_result " +
									"(msg_uid, hosp_id, user_id, date_time, file_name, err, message) " +
									"values('{0}', '{1}', '{2}', '{3}', '{4}', '1', '{5}')";

		try
		{
			if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認
			if (!MoveFileSend(hospId, fileName, err, msgUid))        // ファイル移動処理
			{
				LogGW(hospId, MSG_ERR_MOVE_FILE, fileName);
			}

			App_Function fnc = new App_Function();

			string status = "";
			if (endFlag) status = string.Format("set_status = {0}", (int)eStatus.Err);       // 異常終了を設定
			else status = string.Format("set_status = set_status|{0}", (int)eStatus.Err);    // "|4"

			LogGW(hospId, err, MSG_ERR_SEND_FILE_INFO, fileName);

			// 状態更新
			string sql = string.Format("update tbl_data_set_flg set {0} where msg_uid = '{1}'", status, msgUid);
			//20180402 yamada comment
            //LogDBG(hospId, "NoticeFileError sql=[{0}]", sql);
			if(!fnc.sqlUpdate(sql))
			{
				LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_data_set_flg");
				return false;
			}

			// ファイル送信結果設定
			sql = string.Format(sql_template, msgUid, hospId, UserId(msgUid), DateTime.Now, fileName, errMsg);
            //20180402 yamada update /S エラーメッセージを変更
            //LogDBG(hospId, "NoticeFileError sql=[{0}]", sql);
            LogDBG(hospId, "NoticeFileError file_name=[{0}] message=[{1}]", fileName, errMsg);
            //20180402 yamada update /E
            if (!fnc.sqlInsert(sql))
			{
				LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_send_result");
				return false;
			}

		}
		catch(Exception ex)
		{
			LogGW(hospId, err, "例外発生：NoticeFileError() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// ファイルＯＫ通知
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="ipAddress"></param>
	/// <param name="msgUid"></param>
	/// <param name="fileName"></param>
	/// <param name="endFlag"></param>
	/// <returns></returns>
	public bool NoticeFileOK(string hospId, string ipAddress, string msgUid, string fileName, bool endFlag)
	{
		bool ret = false;
		bool err = false;
		int statusInt = 0;
		string sql = "";
		string status = "";

		const string sql_template = "insert into tbl_send_result " +
							"(msg_uid, hosp_id, user_id, date_time, file_name, err) " +
							"values('{0}', '{1}', '{2}', '{3}', '{4}', '0')";

		try
		{
			if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認

			if(!MoveFileSend(hospId, fileName, err, msgUid))        // ファイル移動処理
			{
				LogGW(hospId, MSG_ERR_MOVE_FILE, fileName);
			}

			App_Function fnc = new App_Function();

			// 最終ファイルなら
			if (endFlag)
			{
				// 現在の状態を取得
				sql = string.Format("select * from tbl_data_set_flg where msg_uid='{0}'", msgUid);

				string str = fnc.sqlSelect(sql, "set_status");
				statusInt = util.ToInt(str);

				if ((statusInt & (int)eStatus.Err) == 0)status = string.Format("set_status = {0}", (int)eStatus.Normal);	// 正常終了を設定
				else status = string.Format("set_status = {0}", (int)eStatus.Err);									// 異常終了を設定

				// 状態、エラーメッセージを更新
				sql = string.Format("update tbl_data_set_flg set {0} where msg_uid = '{1}'", status, msgUid);

				if (!fnc.sqlUpdate(sql))
				{
					string msg = string.Format("NoticeFileOK SQL[{0}]", sql);
					LogGW(hospId, err, MSG_ERR_SET_DB, msg);
					return false;
				}
			}

			// ファイル毎に送信結果を保存
			sql = string.Format(sql_template, msgUid, hospId, UserId(msgUid), DateTime.Now, fileName);
			fnc.sqlInsert(sql);

		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：NoticeFileOK() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// 電子カルテデータ送信(GWクライアントからみた送信)
	///		GWサーバでは受信処理
	/// </summary>
	/// <param name="instId"></param>
	/// <param name="ipAddress"></param>
	/// <param name="data"></param>
	/// <param name="errMsg"></param>
	/// <returns></returns>
	public bool SendData(string hospId, string ipAddress, string msgUid, int dataKind, string fileName, byte[] data, ref string errMsg, bool endFlag, bool startFlag)
	{
		bool ret = false;
		bool err = true;
		string str = "";
		string sql = "";
		bool notAll = false;

		DateTime now = DateTime.Now;

		const string sql_template = "insert into tbl_recv_result " +
				"(msg_uid, hosp_id, date_time, file_name, err, message) " +
				"values('{0}', '{1}', '{2}', '{3}', {4}, '{5}')";

		try
		{
            //20180529 upd /S 介護度連携対応
            //if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認
            string care_renkei;
            if (!CheckUser2(hospId, ipAddress, out care_renkei)) return false;        // 認証確認
            //20180529 upd /E 介護度連携対応

            ret = util.ByteArrayToString(data, 0, data.Length, ref str);
			str = str.Replace("\"", "");            // "(ダブルクォート)の削除
			string[] lines = str.Split(new string[] { "\r\n" }, StringSplitOptions.None);   // 改行コードでsplit

			// "END"チェック
			bool set = false;
			if (lines[lines.Length - 2].Length >= 3)
			{
				if (EndMark.CompareTo(lines[lines.Length - 2].Substring(0, 3)) == 0) set = true;
			}

			if (set)
			{
                //20180418 yamada add /S ログ追加 ver2.2 No:048
                LogGW(hospId, "医院ID「{0}」ClientIP「{1}」処理区分「{2}」", hospId, ipAddress, dataKind);
                //20180418 yamada add /E

                // 排他処理はここでおこなう(hospConfig, mstMenu) 17.10.23
                // 患者情報(patientInfo) 患者毎にSetPatientInfo内でおこなう
                switch (dataKind)
				{
					case 1: // 医院情報(医院Ｍ医院固有)
							// hospConfig
						SetExclusive(hospId, "hospConfig", "", "OPEN");
						ret = SetMasterHosp(hospId, lines, msgUid);
						SetExclusive(hospId, "hospConfig", "", "CLOSE");
						break;
					case 2: // 届出情報(医院Ｍ病院加算)
					case 12:
						if (dataKind == 12) notAll = true;
						// hospConfig
						SetExclusive(hospId, "hospConfig", "", "OPEN");
						ret = SetMasterKasan(hospId, lines, notAll, msgUid);
						SetExclusive(hospId, "hospConfig", "", "CLOSE");
						break;
					case 3: // 歯科医師マスタ(医院Mドクター情報)
						// mstMenu
						SetExclusive(hospId, "mstMenu", "", "OPEN");
						ret = SetMasterDoctor(hospId, lines, msgUid);
						SetExclusive(hospId, "mstMenu", "", "CLOSE");
						break;
					case 4: // 歯科衛生士マスタ(ウィンドウ摘要文例M)
							// mstMenu
						SetExclusive(hospId, "mstMenu", "", "OPEN");
						ret = SetMasterDH(hospId, lines, msgUid);
						SetExclusive(hospId, "mstMenu", "", "CLOSE");
						break;
					case 5: // 訪問先マスタ(訪問先Ｍ)
					case 8:
						if (dataKind == 8) notAll = true;
						// mstMenu
						SetExclusive(hospId, "mstMenu", "", "OPEN");
						ret = SetMasterVisit(hospId, lines, notAll, endFlag, startFlag, msgUid);
						SetExclusive(hospId, "mstMenu", "", "CLOSE");
						break;
					case 6: // 訪問理由マスタ(訪問理由Ｍ)
					case 9:
						if (dataKind == 9) notAll = true;
						// mstMenu
						SetExclusive(hospId, "mstMenu", "", "OPEN");
						ret = SetMasterReason(hospId, lines, notAll, endFlag, startFlag, msgUid);
						SetExclusive(hospId, "mstMenu", "", "CLOSE");
						break;
					case 7: // 患者情報(患者情報)
					case 10:
						if (dataKind == 10) notAll = true;
                        //20180529 upd /S 介護度連携対応
                        //ret = SetTablePatient(hospId, lines, notAll, msgUid);
                        ret = SetTablePatient(hospId, care_renkei, lines, notAll, msgUid);
                        //20180529 upd /E 介護度連携対応
                        break;
                    case 11: // 患者情報削除(患者情報)
                        ret = SetTablePatientDelete(hospId, lines);
                        break;

                    //20180411 yamada add /S ユニット病棟マスタ追加
                    //ver2.2管理表No:019

                    case 13: // ユニット病棟マスタ(ユニット病棟M)
                    case 14: 
                        if (dataKind == 14) notAll = true;
                        // mstMenu
                        SetExclusive(hospId, "mstMenu", "", "OPEN");
                        ret = SetMasterVisitUnit(hospId, lines, notAll, endFlag, startFlag, msgUid);
                        SetExclusive(hospId, "mstMenu", "", "CLOSE");
                        break;
                    //20180411 yamada add /E

                    //case 13: // 患者情報変更(患者情報)
                    //	ret = SetTablePatientChange(hospId, lines);
                    //	break;

					//2020.01.31 add
					case 101: //既往歴
						ret = SetTableGeneralDisease(hospId, lines, msgUid);
						break;

					//2020.01.31 add
					case 102: //服用中薬剤
						ret = SetTableTakingMedicines(hospId, lines, msgUid);
						break;

					//2020.02.04 add
					case 201: //既往歴
						ret = SetTableGeneralDiseaseRenkeiData(hospId, lines, msgUid);
						break;

					//2020.02.04 add
					case 202: //服用中薬剤
						ret = SetTableTakingMedicinesRenkeiData(hospId, lines, msgUid);
						break;

                    default:
						// GWクライアントではじくのでdefaultはあり得ない
						break;
				}

				if(!ret) errMsg = string.Format(MSG_ERR_FILE_GET_ERROR, fileName);
			}
			else
			{
				errMsg = string.Format(MSG_ERR_FILE_FORMAT, fileName);
				LogDBG(hospId, "SendData() errMsg=[{0}]", errMsg);
				ret = false;
			}

			if (ret) err = false;	// エラーではないを設定

			MoveFileRecv(hospId, fileName, err, data);

			if (ret)
			{
				sql = string.Format(sql_template, msgUid, hospId, now, fileName, 0, "");
				LogGW(hospId, MSG_INFO_REGIST_MASTER, hospId, fileName);
			}
			else
			{
				//errMsg = string.Format(MSG_ERR_FILE_GET_ERROR, fileName); 
				sql = string.Format(sql_template, msgUid, hospId, now, fileName, 1, errMsg);
				LogGW(hospId, MSG_ERR_REGIST_MASTER, hospId, fileName);
			}

			App_Function fnc = new App_Function();
			fnc.sqlInsert(sql);
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SendData() {0}", ex.ToString());
			errMsg = ex.ToString();
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="ipAddress"></param>
	/// <param name="msgUid"></param>
	/// <param name="total"></param>
	/// <param name="processed"></param>
	/// <returns></returns>
	public bool GetProcessedStatus(string hospId, string ipAddress, string msgUid, ref int total, ref int processed)
	{
		bool ret = false;
		int end_flg = 0;
		total = 0;
		processed = 0;
		string sql = "";
		string sqlTmp = "select * from tbl_processed_status where hosp_id = '{0}' and msg_uid='{1}'";

		try
		{
			if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認

			sql = string.Format(sqlTmp, hospId, msgUid);

			App_Function fnc = new App_Function();

			DataTable dt = new DataTable();
			if (fnc.sqlSelectTable(sql, ref dt))
			{
				if (dt.Rows.Count != 0)
				{
					total = util.ToInt(dt.Rows[0]["total"].ToString());
					processed = util.ToInt(dt.Rows[0]["processed"].ToString());
					end_flg = util.ToInt((string)dt.Rows[0]["end_flg"].ToString());
					if (end_flg == 1) ret = true;
				}
			}	

		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SendData() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	//20180417 /S H30改正対応 046
	/// <summary>
	/// Ping
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="ipAddress"></param>
	/// <returns></returns>
	public bool Ping(string hospId, string ipAddress)
	{
		bool ret = false;

		try
		{
			LogGW(hospId, MSG_INFO_PING_RECV, ipAddress);

			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：Ping() {0}", ex.ToString());
			return ret;
		}

		return ret;
	}
	//20180417 /E H30改正対応 046

	/// <summary>
	/// 
	/// </summary>
	/// <param name="msgUid"></param>
	/// <param name="total"></param>
	/// <param name="processed"></param>
	/// <returns></returns>
	public bool SetProcessedStatus(string hospId, string msgUid, int total, int processed, bool start)
	{
		bool ret = true;
		string sql = "";
		string sqlStart = "insert into tbl_processed_status (hosp_id, msg_uid, total, processed, end_flg) values ('{0}', '{1}', {2}, 0, 0)";
		string sqlProcess = "update tbl_processed_status set processed = {0} where hosp_id='{1}' and msg_uid='{2}'";
		string sqlEnd = "update tbl_processed_status set end_flg = 1 where hosp_id='{0}' and msg_uid='{1}'";

		try {

			App_Function fnc = new App_Function();

			if (start)
			{
				sql = string.Format(sqlStart, hospId, msgUid, total);
				fnc.sqlInsert(sql);
			}
			else
			{
				sql = string.Format(sqlProcess, processed, hospId, msgUid);
				fnc.sqlUpdate(sql);

				if(total <= processed)
				{
					sql = string.Format(sqlEnd, hospId, msgUid);
					fnc.sqlUpdate(sql);
				}
			}
		}
		catch
		{
			// 無処理
		}

		return ret;

	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="displayName"></param>
	/// <param name="caseFlg"></param>
	/// <returns></returns>
	public int SetExclusive(string hospId, string displayName, string patientId, string caseFlg)
	{
		const string exclusive_d = "delete from tbl_exclusive where hosp_id='{0}' and display_name='{1}' and patient_id ='{2}'";
		const string exclusive_i = "insert into tbl_exclusive(group_id, hosp_id, user_id, " +
									"user_name, terminal_id, display_name, patient_id, exm_date, regist_datetime) " +
									"values('{0}', '{1}', 'media@gtwy1234567890', 'media@gtwy1234567890', '', '{2}', '{3}', null, getdate())";
		string sql = "";

		try
		{
			App_Function fnc = new App_Function();

			switch (caseFlg)
			{
				case "OPEN":
					// 強制解除
					sql = string.Format(exclusive_d, hospId, displayName, patientId);
					if(!fnc.sqlDelete(sql)) LogGW(hospId, err, MSG_ERR_SET_DB, sql);

					// 排他設定
					sql = string.Format(exclusive_i, "", hospId, displayName, patientId);
					if(!fnc.sqlInsert(sql))	LogGW(hospId, err, MSG_ERR_SET_DB, sql);
					break;

				case "CLOSE":
					// 排他解除
					sql = string.Format(exclusive_d, hospId, displayName, patientId);
					if (!fnc.sqlDelete(sql)) LogGW(hospId, err, MSG_ERR_SET_DB, sql);
					break;
			}
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetExclusive() {0}", ex.ToString());
		}

		return 0;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="lines"></param>
	/// <returns></returns>
	private bool SetMasterHosp(string hospId, string[] lines, string msgUid)
	{
		bool ret = false;
		string sql = "";

		// CSVデータのインデックス番号
		const int idx_director=3-1, idx_name=4-1, idx_zip=5-1, idx_tel=6-1, 
					idx_fax=7-1, idx_add1=8-1, idx_add2=9-1;

		try
		{
			int total = lines.Length - 3;

			App_Function fnc = new App_Function();

			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			// 基本的に1レコードしかない
			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行以降は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

				string[] elm = elms(lines[i], 16);
				if (EndMark.CompareTo(elm[0]) == 0) break;

				// まずはPRIMARY KEYのみinsertしたレコードを作成(レコードがなければ)
				sql = string.Format("select * from mst_hosp_contract where hosp_id='{0}'", hospId);

				if (fnc.sqlSelect(sql, "hosp_id").Length == 0)
				{
					string mst_hosp_i = "insert into mst_hosp_contract(hosp_id) values ('{0}')";
					sql = string.Format(mst_hosp_i, hospId);

					if(!fnc.sqlInsert(sql))
					{
						LogGW(hospId, err, MSG_ERR_SET_DB, sql);
						//return false;
					}
				}

				// updateでDBに設定
				string mst_hosp_u =
					"update mst_hosp_contract set hosp_name='{0}', zip_code='{1}', address1='{2}', address2='{3}', " +
					"tel_no='{4}', fax_no='{5}', director_name='{6}' " +
					"where hosp_id='{7}'";

				sql = string.Format(mst_hosp_u, elm[idx_name], elm[idx_zip], elm[idx_add1], elm[idx_add2], 
									elm[idx_tel], elm[idx_fax], elm[idx_director], hospId);

				if (!fnc.sqlUpdate(sql)) LogGW(hospId, err, MSG_ERR_SET_DB, sql);

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetMasterHosp() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="lines"></param>
	/// <returns></returns>
	private bool SetMasterKasan(string hospId, string[] lines, bool notAll, string msgUid)
	{
		bool ret = false;
		const string yymmdd = "yyyyMMdd";
		string sql = "";

        // CSVデータのインデックス番号

        //20180313 yamada /S H30改正対応 
        //2018/4/1より前は加算コード2=在宅療養支援歯科診療所
        //2018/4/1から後は加算コード2=在宅療養支援歯科診療所２
        //                加算コード7=在宅療養支援歯科診療所１
        //                加算コード8=院内感染防止届出有無

        //const int idx_date = 1 - 1, idx_kasan2 = 6 - 1, idx_kasan4 = 15 - 1, idx_kasan1 = 23 - 1, idx_kasan5 = 27 - 1, idx_kasan3 = 30 - 1;
        //int[] h_idx = { idx_kasan1, idx_kasan2, idx_kasan3, idx_kasan4, idx_kasan5 };
        //int[] kasanCodes = { 1, 2, 6, 4, 5 };
        //const string endless = "99991231";		// 無期限
        //string[] startDate = new string[5] {"","","","","" };
        //string[] endDate = new string[5] { endless, endless, endless, endless, endless };

        const int idx_date = 1 - 1, idx_kasan2 = 6 - 1, idx_kasan4 = 15 - 1, idx_kasan1 = 23 - 1, idx_kasan5 = 27 - 1, idx_kasan3 = 30 - 1, idx_kasan7 = 6 - 1, idx_kasan8 = 31 - 1;
        int[] h_idx = { idx_kasan1, idx_kasan2, idx_kasan3, idx_kasan4, idx_kasan5, idx_kasan7, idx_kasan8 };
        int[] kasanCodes = { 1, 2, 6, 4, 5, 7, 8 };
        const int kasan2idx = 1, kasan7idx = 5; 
        const string endless = "99991231";      // 無期限
        string[] startDate = new string[] { "", "", "", "", "", "", "" };
        string[] endDate = new string[] { endless, endless, endless, endless, endless , endless, endless };
        //20180313 yamada /E 
        


        //int idx = 1000;

        /* 2017.10.24 chg
		string mst_kasan_i = "insert into mst_kasan (hosp_id, index_no, start_date, end_date, koumoku) " +
					 " values('{0}', {1}, '{2}', '{3}', '{4}')";
		*/
        string mst_kasan_i2 = "insert into mst_kasan (hosp_id, kasan_code, seq_no, index_no, start_date, end_date, koumoku)" + 
					" values('{0}', '{1}', '1', '1', '{2}', '{3}', '{4}' )";
		string mst_kasan_d = "delete from mst_kasan where hosp_id='{0}' and kasan_code={1}";

		int kasanCode = 0;
		// chg end

		string[] heddars = new string[1];
		try
		{
			App_Function fnc = new App_Function();

			// koumokuが「地域医療連携体制加算」はWithYouのみの項目のため、マスタ書き換えはおこなわない
			sql = string.Format("delete from mst_kasan where hosp_id='{0}' and koumoku <>'地域医療連携体制加算'", hospId);
			if(!fnc.sqlDelete(sql)) LogGW(hospId, err, MSG_ERR_SET_DB, sql);

			int total = lines.Length - 3;
			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			for (int i = 0; i < lines.Length; i++)
			{
				// ヘッダより項目名を取得
				if (i == 0)
				{
					heddars = lines[0].Split(',');
					continue;
				}

				// "END"行は保存しない
				if (EndMark.CompareTo(lines[i]) == 0) break;

                //20180313 yamada /S H30改正対応 院内感染防止届出有無追加
                //string[] elm = elms(lines[i], 30);
                string[] elm = elms(lines[i], 31);
                //20180313 yamada /E 

                if (EndMark.CompareTo(elm[0]) == 0) break;

				// 開始年月日,終了年月日、項目名を設定
				for(int j=0;j<h_idx.Length;j++)
				{
					// 加算コード取得 2017.10.24 add
					kasanCode = kasanCodes[j];
					if (kasanCode == 0) continue;
					// add end

					// 開始日時を設定
					if (util.ToInt(elm[h_idx[j]]) != 0)
					{
                        //20180313 yamada /S 在宅療養支援歯科診療所のチェック処理
                        //if (startDate[j].Length == 0) startDate[j] = elm[idx_date];

                        switch (j)
                        {
                            case kasan2idx:     //加算コード２

                                //2018/04/01以前の場合1は在宅療養支援歯科診療所２
                                //2018/04/01以降の場合2は在宅療養支援歯科診療所２
                                if ((string.Compare(elm[idx_date] , "20180401") >= 0 && util.ToInt(elm[h_idx[j]]) == 2) ||
                                    string.Compare(elm[idx_date], "20180401") < 0 && util.ToInt(elm[h_idx[j]]) == 1 )
                                {
                                    if (startDate[kasan2idx].Length == 0)
                                    {
                                        //初回セット
                                        startDate[kasan2idx] = elm[idx_date];
                                    }
                                    else if (startDate[kasan7idx].Length != 0)
                                    {
                                        //既に入っている場合、加算コード２開始日＜加算コード７開始日は開始日を上書きする
                                        if (string.Compare(startDate[kasan2idx], startDate[kasan7idx]) < 0)
                                        {
                                            startDate[kasan2idx] = elm[idx_date];
                                        }
                                    }
                                }
                                break;

                            case kasan7idx:     //加算コード７

                                //2018/04/01以降で1は在宅療養支援歯科診療所１
                                if ((string.Compare(elm[idx_date], "20180401") >= 0 && util.ToInt(elm[h_idx[j]]) == 1))
                                {
                                    if (startDate[kasan7idx].Length == 0)
                                    {
                                        //初回セット
                                        startDate[kasan7idx] = elm[idx_date];
                                    }
                                    else if (startDate[kasan2idx].Length != 0)
                                    {
                                        //既に入っている場合、加算コード７開始日＜加算コード２開始日は開始日を上書きする
                                        if (string.Compare(startDate[kasan7idx], startDate[kasan2idx]) < 0)
                                        {
                                            startDate[kasan7idx] = elm[idx_date];
                                        }
                                    }
                                }

                                break;

                            default:
                                if (startDate[j].Length == 0) startDate[j] = elm[idx_date];
                                break;
                        }
                        //20180313 yamada /E

					}
					else
					{
						// 開始日時が設定されていた場合のみ終了日時を設定
						if (startDate[j].Length != 0)
						{
                            //20180327 yamada /S 終了日が何か設定されていた場合はセットしない
                            if (endDate[j] == endless)
                            {
                                endDate[j] = AddDaysString(elm[idx_date], yymmdd, -1);
                            }
                            //20180327 yamada /E

                            sql = string.Format(mst_kasan_d, hospId, kasanCode);
							if (!fnc.sqlDelete(sql)) LogGW(hospId, err, MSG_ERR_SET_DB, sql);

                            //20180327 yamada /S 加算コード２の時、２と７の開始日をチェックして終了日をセット
                            if (j == kasan2idx )
                            {
                                if(startDate[kasan7idx].Length != 0)
                                {
                                    //加算コード７の開始日があれば、開始日が古い方に終了日を入れる（有効な方の開始日 - 1）
                                    if (string.Compare(startDate[kasan2idx], startDate[kasan7idx]) < 0)
                                    {
                                        endDate[kasan2idx] = AddDaysString(startDate[kasan7idx], yymmdd, -1);
                                        endDate[kasan7idx] = AddDaysString(elm[idx_date], yymmdd, -1);
                                    }
                                    else
                                    {
                                        endDate[kasan2idx] = AddDaysString(elm[idx_date], yymmdd, -1);
                                        endDate[kasan7idx] = AddDaysString(startDate[kasan2idx], yymmdd, -1);
                                    }

                                }

                            }

                            //20180327 yamada /E

                            //LogGW(hospId, err, " ins {0} startDate{1},endDate{2}", j.ToString(), startDate[j], endDate[j]);
                            sql = string.Format(mst_kasan_i2, hospId, kasanCode, startDate[j], endDate[j], heddars[h_idx[j]]);
							if (!fnc.sqlInsert(sql))
							{
								LogGW(hospId, err, MSG_ERR_SET_DB, sql);
								//return false;
							}
							// chg end

							startDate[j] = "";
							endDate[j] = endless;
						}
					}

					SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
				}
			}

			// 開始日時が設定されていて最終日が設定されていないデータの設定
			for(int i=0;i<h_idx.Length; i++)
			{
                if (startDate[i].Length != 0)
				{
					kasanCode = kasanCodes[i];

					sql = string.Format(mst_kasan_d, hospId, kasanCode);
					if(!fnc.sqlDelete(sql)) LogGW(hospId, err, MSG_ERR_SET_DB, sql);

                    //20180313 yamada /S 加算コード２の時加算コード７もチェック
                    if (i == kasan2idx)
                    {
                        if (startDate[kasan7idx].Length != 0)
                        {
                            //加算コード７の開始日があれば、開始日が古い方に終了日を入れる（有効な方の開始日 - 1）
                            if (string.Compare(startDate[kasan2idx], startDate[kasan7idx]) < 0)
                            {
                                endDate[kasan2idx] = AddDaysString(startDate[kasan7idx], yymmdd, -1);
                            }
                            else
                            {
                                endDate[kasan7idx] = AddDaysString(startDate[kasan2idx], yymmdd, -1);
                            }
                        }
                    }
                    //20180313 yamada /E

                    //LogGW(hospId, err, " ins2 {0} startDate{1},endDate{2}", i.ToString(), startDate[i], endDate[i]);
                    sql = string.Format(mst_kasan_i2, hospId, kasanCode, startDate[i], endDate[i], heddars[h_idx[i]]);
					if (!fnc.sqlInsert(sql))
					{
						LogGW(hospId, err, MSG_ERR_SET_DB, sql);
						//return false;
					}
				}
			}

			ret = true;

        }
        catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetMasterKasan() {0}", ex.ToString());
			ret = false;
        }

		return ret;
	}

	// 届け出DBテーブル変更対応 2017.10.24
	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="str"></param>
	/// <returns></returns>
	private int GetKasanCode(string hospId, string str, string msgUid)
	{
		int code = 0;
		string sql = string.Format("select kasan_code from mst_kasan_class where koumoku = '{0}'", str);

		try
		{
			App_Function fnc = new App_Function();

			string codeStr = fnc.sqlSelect(sql, "kasan_code");

			if (codeStr.Length != 0)
			{
				code = util.ToInt(codeStr);
			}
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：GetKasanCode() {0}", ex.ToString());
			code = 0;
		}

		return code;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="lines"></param>
	/// <returns></returns>
	private bool SetMasterDoctor(string hospId, string[] lines, string msgUid)
	{
		bool ret = false;
		string sql = "";
		string doctorCodes = "";
		DataTable dt;

		// CSVデータのインデックス番号
		const int idx_dc=1-1, idx_scrn=2-1, idx_etc=3-1, idx_indx=4-1, idx_mask=5-1;

		try
		{
			App_Function fnc = new App_Function();

			int total = lines.Length - 3;
			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

				string[] elm = elms(lines[i], 12);
				if (EndMark.CompareTo(elm[0]) == 0) break;

				// まずはPRIMARY KEYのみinsertしたレコードを作成(レコードがなければ)
				sql = string.Format("select * from mst_local_user where hosp_id='{0}' and localuser_id={1} and job_id={2}", hospId, elm[idx_dc], (int)eJob.DR);

				if (fnc.sqlSelect(sql, "hosp_id").Length == 0)
				{
					string mst_localuser_i = "insert into mst_local_user(hosp_id, localuser_id, job_id, mask) " +
											 " values('{0}', {1}, {2}, 0)";

					sql = string.Format(mst_localuser_i, hospId, elm[idx_dc], (int)eJob.DR);

					if (!fnc.sqlInsert(sql))
					{
						LogGW(hospId, err, MSG_ERR_SET_DB, sql);
						//return false;
					}
				}

				string scrn = elm[idx_scrn];
				if (elm[idx_scrn].Length > 40) scrn = elm[idx_scrn].Substring(0, 40);

				// updateでDBに設定(localuser_naemとlocal_user_scrnは同じものを設定)
				string mst_doctor_u = "update mst_local_user set localuser_name='{0}', index_no={1}," +
										 " localuser_scrn='{2}', mask=mask|{3} " +
										 " where hosp_id='{4}' and localuser_id='{5}' and job_id={6}";
				sql = string.Format(mst_doctor_u, elm[idx_etc], elm[idx_indx],
									 scrn, elm[idx_mask], hospId, elm[idx_dc], (int)eJob.DR);

				if (!fnc.sqlUpdate(sql))
				{
					LogGW(hospId, err, MSG_ERR_SET_DB, sql);
					//return false;
				}

				if (doctorCodes.Length != 0) doctorCodes += ",";
				doctorCodes += elm[idx_dc];

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}

			// mask設定(WituYouに登録されていて、CSVにデータがない医者はmaskを設定する)
			//LogDBG(hospId, "SetMasterDH() [WithYouに登録されていてCSVにデータがないDRのマスク設定]");
			{
				sql = string.Format("select localuser_id from mst_local_user where hosp_id='{0}' and job_id={1} and localuser_id not in({2})",
										hospId, (int)eJob.DR, doctorCodes);

				dt = new DataTable();
				if (fnc.sqlSelectTable(sql, ref dt))
				{
					for (int i = 0; i < dt.Rows.Count; i++)
					{
						sql = string.Format("update mst_local_user set mask=1 where hosp_id='{0}' and job_id={1} and localuser_id={2}",
												hospId, (int)eJob.DR, dt.Rows[i]["localuser_id"]);

						if (!fnc.sqlUpdate(sql))
						{
							LogGW(hospId, err, MSG_ERR_SET_DB, sql);
							//return false;
						}
					}
				}
			}

			// index_no,doctor_codeで昇順にソート
			//LogDBG(hospId, "SetMasterDoctor() [index_no,localuser_idで昇順にソートしindex_noをふり直し]");
			{
				string mst_doctor_s = "select * from mst_local_user where hosp_id='{0}' and job_id={1} " +
										" ORDER BY index_no, localuser_id";

				sql = string.Format(mst_doctor_s, hospId, (int)eJob.DR);

				dt = new DataTable();
				if (fnc.sqlSelectTable(sql, ref dt))
				{
					if (dt.Rows.Count != 0)
					{
						for (int i = 0; i < dt.Rows.Count; i++)
						{
							string mst_doctor_u2 = "update mst_local_user set index_no={0} where hosp_id='{1}' and job_id={2} and localuser_id={3}";
							sql = string.Format(mst_doctor_u2, i + 1, hospId, (int)eJob.DR, dt.Rows[i]["localuser_id"]);

							if (!fnc.sqlUpdate(sql))
							{
								LogGW(hospId, err, MSG_ERR_SET_DB, sql);
								//return false;
							}
						}
					}
				}
			}
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetMasterDoctor() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}
	
	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="lines"></param>
	/// <returns></returns>
	private bool SetMasterDH(string hospId, string[] lines, string msgUid)
	{
		bool ret = false;
		string sql = "";
		string dhNames = "";
		DataTable dt;

		// CSVデータのインデックス番号
		const int idx_indx=3-1, idx_mask=4-1, idx_bunrei=5-1;

		try
		{
			App_Function fnc = new App_Function();

			int total = lines.Length - 3;
			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

				string[] elm = elms(lines[i], 5);
				if (EndMark.CompareTo(elm[0]) == 0) break;

				string dhName = elm[idx_bunrei];
				if (util.EncodeShiftJis.GetByteCount(dhName) > 40)
				{
					dhName = new String(dhName.TakeWhile((c, j) => util.EncodeShiftJis.GetByteCount(dhName.Substring(0, j + 1)) <= 40).ToArray());
				}

                // まずはPRIMARY KEYのみinsertしたレコードを作成(レコードがなければ)
                //20180329 yamada update /S job_idとmaskをwhereに追加
                //sql = string.Format("select * from mst_local_user where hosp_id='{0}' and localuser_name='{1}' ", hospId, dhName);
                sql = string.Format("select * from mst_local_user where hosp_id='{0}' and localuser_name='{1}' and job_id={2} and mask=0 ", hospId, dhName, (int)eJob.DH);
                //20180329 yamada update /E

                if (fnc.sqlSelect(sql, "localuser_name").Length == 0)
				{
					string mst_localuser_i = "insert into mst_local_user(hosp_id, localuser_id, localuser_name, job_id, mask) " +
											 " select '{0}', isnull(MAX(localuser_id), 0) + 1, '{1}', '{2}', 0 " +
											 " from mst_local_user";

					sql = string.Format(mst_localuser_i, hospId, dhName, (int)eJob.DH);

					if (!fnc.sqlInsert(sql))
					{
						LogGW(hospId, err, MSG_ERR_SET_DB, sql);
						//return false;
					}
				}

                // updateでDBに設定(localuser_naemとlocal_user_scrnは同じものを設定)

                //20180328 yamada update /S where条件にJob_idを追加
                //string mst_localuser_u = "update mst_local_user set localuser_name='{0}',job_id='{1}'," +
                //						 "index_no={2}, localuser_scrn='{3}', mask=mask|{4} " +
                //						 " where hosp_id='{5}' and localuser_name='{6}'";
                //
                //sql = string.Format(mst_localuser_u, dhName, (int)eJob.DH,
                //                    elm[idx_indx], dhName, elm[idx_mask], hospId, dhName);
                string mst_localuser_u = "update mst_local_user set localuser_name='{0}',job_id='{1}'," +
                         "index_no={2}, localuser_scrn='{3}', mask=mask|{4} " +
                         " where hosp_id='{5}' and localuser_name='{6}' and job_id={7}";

                sql = string.Format(mst_localuser_u, dhName, (int)eJob.DH,
                                    elm[idx_indx], dhName, elm[idx_mask], hospId, dhName, (int)eJob.DH);

                if (!fnc.sqlUpdate(sql))
				{
					LogGW(hospId, err, MSG_ERR_SET_DB, sql);
					//return false;
				}

				if (dhNames.Length != 0) dhNames += ",";
				dhNames += string.Format("'{0}'", dhName);

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}

			// mask設定(WituYouに登録されていて、CSVにデータがないDHはmaskを設定する)
			//LogDBG(hospId, "SetMasterDH() [WithYouに登録されていてCSVにデータがないDHのマスク設定]");
			{
				sql = string.Format("select localuser_name from mst_local_user where hosp_id='{0}' and job_id={1} and localuser_name not in({2})",
										hospId, (int)eJob.DH, dhNames);

				dt = new DataTable();
				if (fnc.sqlSelectTable(sql, ref dt))
				{

					for (int i = 0; i < dt.Rows.Count; i++)
					{
						sql = string.Format("update mst_local_user set mask=1 where hosp_id='{0}' and localuser_name='{1}'",
												hospId, dt.Rows[i]["localuser_name"]);

						if (!fnc.sqlUpdate(sql))
						{
							LogGW(hospId, err, MSG_ERR_SET_DB, sql);
							//return false;
						}
					}
				}
			}

			// index_no,localuser_idで昇順にソート
			//LogDBG(hospId, "SetMasterDH() [index_no,localuser_idで昇順にソートしindex_noをふり直し]");
			{
				string mst_localuser_s = "select * from mst_local_user where hosp_id='{0}' and job_id={1} " + 
										" ORDER BY index_no, localuser_id";

				sql = string.Format(mst_localuser_s, hospId, (int)eJob.DH);

				dt = new DataTable();
				if (fnc.sqlSelectTable(sql, ref dt))
				{

					if (dt.Rows.Count != 0)
					{
						for (int i = 0; i < dt.Rows.Count; i++)
						{
							string mst_localuser_u2 = "update mst_local_user set index_no={0} where hosp_id='{1}' and job_id={2} and localuser_id={3}";
							sql = string.Format(mst_localuser_u2, i + 1, hospId, (int)eJob.DH, dt.Rows[i]["localuser_id"]);

							if (!fnc.sqlUpdate(sql))
							{
								LogGW(hospId, err, MSG_ERR_SET_DB, sql);
								//return false;
							}
						}
					}
				}
			}

			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetMasterDH() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="lines"></param>
	/// <returns></returns>
	private bool SetMasterVisit(string hospId, string[] lines, bool notAll, bool end, bool start, string msgUid)
	{
		bool ret = false;
		string sql = "";
		string visitCodes = "";
		const int ryakuLength = 12;
		int[] chg_table = {0, 1, 2, 4, 5, 3 };
		DataTable dt;

        // CSVデータのインデックス番号

        //20180413 yamada add /S 戸数追加
        //ver2.2管理表No:038

        //const int idx_id = 1 - 1, idx_mask = 2 - 1, idx_indx = 3 - 1, idx_scrn = 4 - 1, idx_kbn = 7 - 1, idx_dtl = 8 - 1, idx_rel = 9 - 1;
        const int idx_id = 1 - 1, idx_mask = 2 - 1, idx_indx = 3 - 1, idx_scrn = 4 - 1, idx_kbn = 7 - 1, idx_dtl = 8 - 1, idx_rel = 9 - 1, idx_houses = 10 - 1;
        //20180413 yamada add /E

        try
        {
			App_Function fnc = new App_Function();

            //20180325 yamada comment /S
            //if (start)
            //{
            //	// 再設定するのですべて削除する
            //	sql = string.Format("delete from mst_visit where hosp_id='{0}' and gw_set=1", hospId);
            //	if (!fnc.sqlDelete(sql))
            //	{
            //		LogGW(hospId, err, MSG_ERR_SET_DB, sql);
            //		//return false;
            //	}
            //}
            //20180325 yamada /E

            int total = lines.Length - 3;
			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

                //20180413 yamada add /S 戸数追加
                //ver2.2管理表No:038

                //string[] elm = elms(lines[i], 9);
                string[] elm = elms(lines[i], 10);
                //20180413 yamada add /E

                if (EndMark.CompareTo(elm[0]) == 0) break;
				if (elm[idx_id].Length == 0) continue;

				// 未登録ならinsert,登録済みならupdateを実行
				sql = string.Format("select * from mst_visit where hosp_id='{0}' and visit_id='{1}'", hospId, elm[idx_id]);


                // 訪問先略称生成(訪問先名称の先頭12バイトを使用、2byte文字の途中できれた場合は11バイトを使用
                byte[] ryakuByte = util.EncodeShiftJis.GetBytes(elm[idx_scrn]);
                int length = ryakuByte.Length;
                if (length >= ryakuLength) length = ryakuLength;
                string ryaku = util.EncodeShiftJis.GetString(ryakuByte, 0, length);
                if (ryaku.EndsWith("・")) ryaku = util.EncodeShiftJis.GetString(ryakuByte, 0, ryakuLength - 1);


                if (fnc.sqlSelect(sql, "visit_id").Length == 0)
				{
                    //20180325 yamada update /S Insert時に略称を入れておく。後でUpdateする時には略称はUPDATEしない
                    //string mst_visit_i = "insert into mst_visit (hosp_id,visit_id,mask,gw_set) values ('{0}','{1}',0,1)";
                    //sql = string.Format(mst_visit_i, hospId, elm[idx_id]);
                    string mst_visit_i = "insert into mst_visit (hosp_id,visit_id,visit_abbreviation,mask,gw_set) values ('{0}','{1}','{2}',0,1)";
                    sql = string.Format(mst_visit_i, hospId, elm[idx_id], ryaku);
                    //20180325 yamada update /E

                    if (!fnc.sqlInsert(sql))
					{
						LogGW(hospId, err, MSG_ERR_SET_DB, sql);
						//return false;
					}
				}

				int mask = 0;
				int kbn = util.ToInt(elm[idx_dtl]);
				if (kbn > chg_table.Length) kbn = 0;
				if ((util.ToInt(elm[idx_mask]) == 1) || (kbn == 0))
				{
					mask = 1;
					//LogDBG(hospId, "SetMasterVisit() [maskが1(今回:{0})または訪問先詳細区分が0(今回:{1})なのでmask1]",
					//					elm[idx_mask], elm[idx_dtl]);
				}

                //20180325 yamada comment この処理は上部に移動
                //// 訪問先略称生成(訪問先名称の先頭12バイトを使用、2byte文字の途中できれた場合は11バイトを使用
                //byte[] ryakuByte = util.EncodeShiftJis.GetBytes(elm[idx_scrn]);
                //int length = ryakuByte.Length;
                //if (length >= ryakuLength) length = ryakuLength;
                //string ryaku = util.EncodeShiftJis.GetString(ryakuByte, 0, length);
                //if (ryaku.EndsWith("・")) ryaku = util.EncodeShiftJis.GetString(ryakuByte, 0, ryakuLength - 1);


                //20180413 yamada add /S 戸数追加
                //ver2.2管理表No:038

                //20180420 yamada update /S 戸数空の場合NULLを設定する
                //20180421 yamada update /S 戸数0の場合もNULLを設定する
                //ver2.2 No:090
                string numberofhouses = "";
                if (elm[idx_houses] == "" || elm[idx_houses] == "0")
                {
                    //elm[idx_houses] = "0";
                    numberofhouses = "number_of_house=NULL ";
                }
                else
                {
                    numberofhouses = "number_of_house={8} ";
                }
                //20180421 yamada update /E
                //20180420 yamada update /E
                //20180413 yamada add /E


                // 11.23 一括時もmaskはそのまま設定？に変更
                string mst_visit_u =
						"update mst_visit set index_no={0},visit_name='{1}',visit_kbn='{2}', relation='{3}'," +
                //"mask=mask|{4}, visit_abbreviation='{5}' where hosp_id='{6}' and visit_id='{7}'";


                //20180413 yamada update /S 戸数追加
                //ver2.2管理表No:038

                //20180325 yamada update /S 医院名略称は更新しないようにする
                ////"mask={4}, visit_abbreviation='{5}', gw_set=1 where hosp_id='{6}' and visit_id='{7}'";
                //"mask={4}, gw_set=1 where hosp_id='{6}' and visit_id='{7}'";
                //20180325 yamada update /E

                //20180423 yamada update /S 集合住宅の場合の戸数計算対応。csv訪問先区分詳細→visit_kbn_withへセット
                //ver2.2 No:111
                //20180420 yamada update /S 戸数空の場合NULLを設定する
                //ver2.2 No:090

                //"mask={4}, gw_set=1, number_of_house={8} where hosp_id='{6}' and visit_id='{7}'";
                //"mask={4}, gw_set=1, " + numberofhouses + " where hosp_id='{6}' and visit_id='{7}'";
                "mask={4}, gw_set=1, " + numberofhouses + ", visit_kbn_with='{9}' where hosp_id='{6}' and visit_id='{7}'";

                //20180420 yamada update /E
                //20180423 yamada update /E 

                //20180413 yamada update /E



                // 11.23 maskはそのまま設定？に変更
                if (notAll)
				{
					mst_visit_u =

                    //20180413 yamada update /S 戸数追加
                    //ver2.2管理表No:038

                    //20180325 yamada update /S 医院名略称は更新しないようにする
                    ////"update mst_visit set index_no={0},visit_name='{1}',visit_kbn='{2}', relation='{3}'," +
                    ////"mask={4}, visit_abbreviation='{5}', gw_set=1 where hosp_id='{6}' and visit_id='{7}'";
                    //"update mst_visit set index_no={0},visit_name='{1}',visit_kbn='{2}', relation='{3}'," +
                    //"mask={4},  gw_set=1 where hosp_id='{6}' and visit_id='{7}'";
                    //20180325 yamada update /E

                    "update mst_visit set index_no={0},visit_name='{1}',visit_kbn='{2}', relation='{3}'," +

                    //20180423 yamada update /S 集合住宅の場合の戸数計算対応。csv訪問先区分詳細→visit_kbn_withへセット
                    //ver2.2 No:111

                    //20180420 yamada update /S 戸数空の場合NULLを設定する
                    //ver2.2 No:090

                    //"mask={4},  gw_set=1, number_of_house={8} where hosp_id='{6}' and visit_id='{7}'";
                    //"mask={4},  gw_set=1, " + numberofhouses + " where hosp_id='{6}' and visit_id='{7}'";
                    "mask={4},  gw_set=1, " + numberofhouses + ", visit_kbn_with='{9}' where hosp_id='{6}' and visit_id='{7}'";

                    //20180420 yamada update /E
                    //20180423 yamada update /E 
                    //20180413 yamada update /E
                }

                //20180423 yamada update /S 集合住宅の場合の戸数計算対応。csv訪問先区分→visit_kbn_withへセット
                //ver2.2 No:111

                //20180413 yamada update /S 戸数追加
                //ver2.2管理表No:038

                //医院名略称は更新しないようにしたのでryakuは未使用
                //sql = string.Format(mst_visit_u, elm[idx_indx], elm[idx_scrn], chg_table[kbn], elm[idx_rel],
                //                    mask, ryaku, hospId, elm[idx_id]);
                //sql = string.Format(mst_visit_u, elm[idx_indx], elm[idx_scrn], chg_table[kbn], elm[idx_rel],
                //                    mask, ryaku, hospId, elm[idx_id], elm[idx_houses]);
                sql = string.Format(mst_visit_u, elm[idx_indx], elm[idx_scrn], chg_table[kbn], elm[idx_rel],
                                    mask, ryaku, hospId, elm[idx_id], elm[idx_houses], elm[idx_kbn]);
                
                //20180413 yamada update /E
                //20180423 yamada update /E 

                if (!fnc.sqlUpdate(sql))
				{
					LogGW(hospId, err, MSG_ERR_SET_DB, sql);
					//return false;
				}

				if (visitCodes.Length != 0) visitCodes += ",";
				visitCodes += elm[idx_id];

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}

			// WithYouで登録されたものはmaskを設定する
			sql = string.Format("update mst_visit set mask=1 where hosp_id='{0}' and gw_set is null", hospId);
			if (!fnc.sqlUpdate(sql))
			{
				LogGW(hospId, err, MSG_ERR_SET_DB, sql);
				//return false;
			}

			// 最終時のみindexをふり直し 20171204 add
			//if (end)
			{
				// index_no,visit_idで昇順にソート
				LogDBG(hospId, "SetMasterVisit() [index_no,visit_idで昇順にソートしindex_noをふり直し]");

				// 11.23 mask'1'はみない？に変更
				//string mst_visit_s = "select * from mst_visit where hosp_id='{0}' ORDER BY index_no, cast(visit_id as bigint)";
				string mst_visit_s = "select * from mst_visit where hosp_id='{0}' and mask=0 and gw_set=1 ORDER BY index_no, cast(visit_id as bigint)";
				sql = string.Format(mst_visit_s, hospId);

				dt = new DataTable();
				if (fnc.sqlSelectTable(sql, ref dt))
				{
					if (dt.Rows.Count != 0)
					{
						for (int i = 0; i < dt.Rows.Count; i++)
						{
							string mst_visit_u2 = "update mst_visit set index_no={0} where hosp_id='{1}' and visit_id='{2}'";
							sql = string.Format(mst_visit_u2, i + 1, hospId, dt.Rows[i]["visit_id"]);

							if (!fnc.sqlUpdate(sql))
							{
								LogGW(hospId, err, MSG_ERR_SET_DB, sql);
								//return false;
							}
						}
					}
				}
			}
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetMasterVisit() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

    /// <summary>
    /// ユニット病棟マスタ登録 
    /// 20180413 yamada add 
    /// ver2.2管理表No:038
    /// </summary>
    /// <param name="hospId"></param>
    /// <param name="lines"></param>
    /// <param name="notAll"></param>
    /// <param name="end"></param>
    /// <param name="start"></param>
    /// <param name="msgUid"></param>
    /// <returns></returns>
    private bool SetMasterVisitUnit(string hospId, string[] lines, bool notAll, bool end, bool start, string msgUid)
    {
        bool ret = false;
        string sql = "";
        //string visitCodes = "";
        //int[] chg_table = { 0, 1, 2, 4, 5, 3 };
        DataTable dt;

        // CSVデータのインデックス番号
        const int idx_id = 1 - 1,idx_unitid = 2-1, idx_mask = 3 - 1, idx_indx = 4 - 1, idx_scrn = 5 - 1;

        try
        {
            App_Function fnc = new App_Function();

             int total = lines.Length - 3;
            SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

            for (int i = 0; i < lines.Length; i++)
            {
                // 1行目、"END"行は保存しない
                if (i == 0) continue;
                if (EndMark.CompareTo(lines[i]) == 0) break;

                string[] elm = elms(lines[i], 5);
                if (EndMark.CompareTo(elm[0]) == 0) break;
                if (elm[idx_id].Length == 0) continue;

                // 未登録ならinsert,登録済みならupdateを実行
                sql = string.Format("select * from mst_visit_unit where hosp_id='{0}' and visit_id='{1}' and visit_unit='{2}' ", hospId, elm[idx_id], elm[idx_unitid]);
                if (fnc.sqlSelect(sql, "visit_id").Length == 0)
                {
                    string mst_visit_unit_i = "insert into mst_visit_unit (hosp_id,visit_id,visit_unit,mask,gw_set) values ('{0}','{1}','{2}',0,1)";
                    sql = string.Format(mst_visit_unit_i, hospId, elm[idx_id], elm[idx_unitid]);

                    if (!fnc.sqlInsert(sql))
                    {
                        LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                        //return false;
                    }
                }

                int mask = 0;
                if ((util.ToInt(elm[idx_mask]) == 1))
                {
                    mask = 1;
                }

                string mst_visit_unit_u =
                        "update mst_visit_unit set unit_name='{0}', index_no='{1}', mask={2}, gw_set=1 " +
                        " where hosp_id='{3}' and visit_id='{4}' and visit_unit='{5}' ";

                //トリガーの場合...今のところ同じ
                if (notAll)
                {
                    mst_visit_unit_u =
                        "update mst_visit_unit set unit_name='{0}', index_no='{1}', mask={2}, gw_set=1 " +
                        " where hosp_id='{3}' and visit_id='{4}' and visit_unit='{5}' ";
                }

                sql = string.Format(mst_visit_unit_u, elm[idx_scrn], elm[idx_indx], mask, hospId, elm[idx_id], elm[idx_unitid]);
                if (!fnc.sqlUpdate(sql))
                {
                    LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                    //return false;
                }

                //if (visitCodes.Length != 0) visitCodes += ",";
                //visitCodes += elm[idx_id];

                SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
            }

            // WithYouで登録されたものはmaskを設定する
            sql = string.Format("update mst_visit_unit set mask=1 where hosp_id='{0}' and (gw_set is null or gw_set = 0 )", hospId);
            if (!fnc.sqlUpdate(sql))
            {
                LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                //return false;
            }

            // 最終時のみindexをふり直し
            //if (end)
            {
                // index_no,visit_idで昇順にソート
                LogDBG(hospId, "SetMasterVisitUnit() [visit_id,index_no,visit_unitで昇順にソートしindex_noをふり直し]");

                string mst_visit_unit_s = "select * from mst_visit_unit where hosp_id='{0}' and mask=0 and gw_set=1 ORDER BY cast(visit_id as bigint), index_no, cast(visit_unit as bigint) ";
                sql = string.Format(mst_visit_unit_s, hospId);

                dt = new DataTable();
                if (fnc.sqlSelectTable(sql, ref dt))
                {
                    if (dt.Rows.Count != 0)
                    {

                        int idx = 0;
                        string tempVisitId = "";

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if (dt.Rows[i]["visit_id"].ToString() != tempVisitId  )
                            {
                                tempVisitId = dt.Rows[i]["visit_id"].ToString();
                                idx = 0;
                            }

                            idx += 1;
                            string mst_visit_unit_u2 = "update mst_visit_unit set index_no={0} where hosp_id='{1}' and visit_id='{2}' and visit_unit='{3}' ";
                            sql = string.Format(mst_visit_unit_u2, idx, hospId, dt.Rows[i]["visit_id"], dt.Rows[i]["visit_unit"]);

                            if (!fnc.sqlUpdate(sql))
                            {
                                LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                                //return false;
                            }
                        }
                    }
                }
            }
            ret = true;
        }
        catch (Exception ex)
        {
            LogGW(hospId, err, "例外発生：SetMasterVisitUnit() {0}", ex.ToString());
            ret = false;
        }

        return ret;
    }



    /// <summary>
    /// 訪問理由マスタ設定
    /// </summary>
    /// <param name="hospId"></param>
    /// <param name="str"></param>
    /// <returns></returns>
    private bool SetMasterReason(string hospId, string[] lines, bool notAll, bool end, bool start, string msgUid)
	{
		bool ret = false;
		string sql = "";
		string reasonCodes = "";
		DataTable dt;

		// CSVデータのインデックス番号
		const int idx_id=1-1, idx_mask=2-1, idx_indx=3-1, idx_scrn=4-1;

		LogDBG(hospId, "SetMasterReason()");

		try
		{
			App_Function fnc = new App_Function();

			if (start)
			{
				// 再設定するのですべて削除する
				sql = string.Format("delete from mst_reason where hosp_id='{0}' and gw_set=1", hospId);
				if(!fnc.sqlDelete(sql)) LogGW(hospId, err, MSG_ERR_SET_DB, sql);
			}

			int total = lines.Length - 3;
			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

				string[] elm = elms(lines[i], 6);
				if (EndMark.CompareTo(elm[0]) == 0) break;
				if (elm[idx_id].Length == 0) continue;

				// 未登録ならinsert,登録済みならupdateを実行
				sql = string.Format("select * from mst_reason where hosp_id='{0}' and reason_id='{1}' ", hospId, elm[idx_id]);

				if (fnc.sqlSelect(sql, "reason_id").Length == 0)
				{
					string mst_reason_i = "insert into mst_reason (hosp_id,reason_id,mask,gw_set) values ('{0}','{1}', 0, 1)";
					sql = string.Format(mst_reason_i, hospId, elm[idx_id]);

					if (!fnc.sqlInsert(sql))
					{
						LogGW(hospId, err, MSG_ERR_SET_DB, sql);
						//return false;
					}
				}

				// 11.23 maskはそのまま設定？に変更
				string mst_reason_u =
						//"update mst_reason set index_no={0},reason='{1}',mask=mask|{2}" +
						"update mst_reason set index_no={0},reason='{1}',mask={2}, gw_set=1" +
						" where hosp_id = '{3}' and reason_id='{4}'";
				// 11.23 maskはそのまま設定？に変更
				if (notAll)
				{
					mst_reason_u =
						"update mst_reason set index_no={0},reason='{1}',mask={2}, gw_set=1" +
						" where hosp_id = '{3}' and reason_id='{4}'";
				}

				sql = string.Format(mst_reason_u, elm[idx_indx], elm[idx_scrn], elm[idx_mask], hospId, elm[idx_id]);

				if (!fnc.sqlUpdate(sql))
				{
					LogGW(hospId, err, MSG_ERR_SET_DB, sql);
					return false;
				}

				if (reasonCodes.Length != 0) reasonCodes += ",";
				reasonCodes += elm[idx_id];

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}

			// WithYouで登録されたものはmaskを設定する
			sql = string.Format("update mst_reason set mask=1 where hosp_id='{0}' and gw_set is null", hospId);
			if (!fnc.sqlUpdate(sql))
			{
				LogGW(hospId, err, MSG_ERR_SET_DB, sql);
				//return false;
			}

			//if (end)
			{
				// index_no,reason_idで昇順にソート
				LogDBG(hospId, "SetMasterReason() [index_no,reason_idで昇順にソートしindex_noをふり直し]");

				// 11.23 mask'1'はみない？に変更
				//string mst_reason_s = "select * from mst_reason where hosp_id='{0}' ORDER BY index_no, reason_id";
				string mst_reason_s = "select * from mst_reason where hosp_id='{0}' and mask=0 and gw_set=1 ORDER BY index_no, cast(reason_id as bigint)";
				sql = string.Format(mst_reason_s, hospId);

				LogDBG(hospId, sql);

				dt = new DataTable();
				if (fnc.sqlSelectTable(sql, ref dt))
				{
					if (dt.Rows.Count != 0)
					{
						for (int i = 0; i < dt.Rows.Count; i++)
						{
							string mst_reason_u2 = "update mst_reason set index_no={0} where hosp_id='{1}' and reason_id='{2}'";
							sql = string.Format(mst_reason_u2, i + 1, hospId, dt.Rows[i]["reason_id"]);
							//LogDBG(hospId, sql);
							if (!fnc.sqlUpdate(sql))
							{
								LogGW(hospId, err, MSG_ERR_SET_DB, sql);
								//return false;
							}
						}
					}
				}
			}
			ret = true;
		}
		catch(Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetMasterReason() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

    /// <summary>
    /// 
    /// </summary>
    /// <param name="hospId"></param>
    /// <param name="lines"></param>
    /// <returns></returns>
    //20180529 upd /S 介護度連携対応
    //private bool SetTablePatient(string hospId, string[] lines, bool notAll, string msgUid)
    private bool SetTablePatient(string hospId, string care_renkei, string[] lines, bool notAll, string msgUid)
    //20180529 upd /E 介護度連携対応
    {
        bool ret = false;
		string sql = "";
		string[] sex = { "", "M", "F" };
		//int tenki = 0;
		string tenki = "";
		bool updateFlg = false;
		string[] kaigodo_tbl = { "ZERO", "", "12", "13", "21", "22", "23", "24", "25" };
		DataTable dt;

        // CSVデータのインデックス番号

        //20180413 yamada add /S 患者情報の16番目にユニット病棟コード追加
        //ver2.2管理表No:019
        //idx_unit以降は可変となるので後でIDXを決める

        //const int idx_id = 1 - 1, idx_kana = 2 - 1, idx_name = 3 - 1, idx_sex = 4 - 1, idx_birh = 5 - 1, idx_tel = 6 - 1, idx_zip = 8 - 1,
        //          idx_adr1 = 9 - 1, idx_adr2 = 10 - 1, idx_syoshin = 11 - 1, idx_saisyu = 12 - 1, idx_vc = 13 - 1, idx_rsn = 14 - 1,
        //          idx_kgd = 15 - 1, idx_tenki = 16 - 1, idx_org_id = 17 - 1, idx_delete = 18 - 1;
        int idx_id = 1 - 1, idx_kana = 2 - 1, idx_name = 3 - 1, idx_sex = 4 - 1, idx_birh = 5 - 1, idx_tel = 6 - 1, idx_zip = 8 - 1,
                idx_adr1 = 9 - 1, idx_adr2 = 10 - 1, idx_syoshin = 11 - 1, idx_saisyu = 12 - 1, idx_vc = 13 - 1, idx_rsn = 14 - 1,
                idx_kgd = 15 - 1, idx_unit = 0, idx_tenki = 0, idx_org_id =0, idx_delete = 0;
        //20180413 yamada add /E

        string org_patientId = "";
		string nowPatientId = "";
        string[] heddars = new string[1];

        try
        {
			App_Function fnc = new App_Function();

			int total = lines.Length - 3;
			SetProcessedStatus(hospId, msgUid, total, 0, true);	// true = start

			for (int i = 0; i < lines.Length; i++)
			{
				updateFlg = false;


                //20180413 yamada add /S 1行目 ヘッダより項目名を取得しユニット病棟コード有無をチェック
                //ver2.2管理表No:038
                //if (i == 0) continue;
                // ヘッダより項目名を取得
                if (i == 0)
                {
                    heddars = lines[0].Split(',');

                    //項目名が介護度以上で項目名に「ユニット病棟コード」があるかチェック
                    if (heddars.Length - 1 > idx_kgd)
                    {
                        if (heddars[idx_kgd + 1] == "ユニット病棟コード")
                        {
                            idx_unit = idx_kgd + 1;
                            idx_tenki = idx_unit + 1;
                            idx_org_id = idx_tenki + 1;
                            idx_delete = idx_org_id + 1;

                        }
                        else
                        {
                            idx_unit = 0;
                            idx_tenki = idx_kgd + 1;
                            idx_org_id = idx_tenki + 1;
                            idx_delete = idx_org_id + 1;
                        }
                    }
                    else
                    {
                        idx_unit = 0;
                        idx_tenki = idx_kgd + 1;
                        idx_org_id = idx_tenki + 1;
                        idx_delete = idx_org_id + 1;
                    }
                    //LogGW(hospId, "unit[{0}] tenki[{1}] orgid[{2}] delete[{3}] length[{4}]", idx_unit, idx_tenki, idx_org_id, idx_delete, heddars.Length);

                    continue;
                }
                //20180413 yamada add /E

                //"END"行は保存しない
                if (EndMark.CompareTo(lines[i]) == 0) break;

                //20180413 yamada add /S ユニット病棟コードが追加のためサイズ追加
                //ver2.2管理表No:038
                //string[] elm = elms(lines[i], 18);
                string[] elm = elms(lines[i], 19);
                //20180413 yamada add /E

                if (EndMark.CompareTo(elm[0]) == 0) break;

				org_patientId = elm[idx_org_id];

                //20180411 yamada add /S 処理中の患者ＩＤ、患者氏名をログに出力する
                //ver2.2管理表No:019

                //処理データ：医院ID「{0}」患者ID「{1}」患者氏名「{2}」
                LogGW(hospId, MSG_INFO_PATIENTINFO, hospId, elm[idx_id], elm[idx_name]);
                //20180411 yamada add /E

                // 2017.11.20 患者削除はここで実行
                if (elm[idx_delete].CompareTo("1") == 0)
				{
					SetExclusive(hospId, "patientInfo", elm[idx_id], "OPEN");
					// delete処理
					PatientDelete(hospId, elm[idx_id]);
					SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");

					SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外

					continue;
				}

				if (org_patientId.CompareTo(elm[idx_id]) == 0)
				{
					updateFlg = false;
				}
				else
				{
					if ((org_patientId.Length != 0) && (util.ToInt(org_patientId) != 0)) updateFlg = true;
					else elm[idx_org_id] = elm[idx_id];     // 患者番号の変更以外で使用
				}

				nowPatientId = elm[idx_id];
				SetExclusive(hospId, "patientInfo", elm[idx_id], "OPEN");

				// tbl_patient
				{
					// 患者番号変更以外
					if (!updateFlg)
					{
						// 未登録ならinsert
						sql = string.Format("select * from tbl_patient where hosp_id='{0}' and patient_id='{1}'", hospId, elm[idx_id]);

						dt = new DataTable();
						ret = fnc.sqlSelectTable(sql, ref dt);
						if (dt.Rows.Count == 0)
						{
							string patUid = string.Format("{0}_{1}", elm[idx_id], DateTime.Now.ToString("yyyyMMddHHmmssfff"));
							string tbl_patient_i = "insert into tbl_patient (hosp_id,patient_id, gw_set, unique_id) values ('{0}','{1}', 1, '{2}')";
							sql = string.Format(tbl_patient_i, hospId, elm[idx_id], patUid);

							if (!fnc.sqlInsert(sql))
							{
								LogGW(hospId, err, MSG_ERR_SET_DB, sql);
								SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
								//return false;
							}
						}
						else
						{		
							//tenki = util.ToInt(dt.Rows[0]["patient_state"].ToString());
							tenki = dt.Rows[0]["patient_state"].ToString();
						}

						//}

						// 性別変換
						int index = util.ToInt(elm[idx_sex]);
						if (index >= 3) index = 0;

						// 転帰設定(転居:1,死亡:2) 
						if ((notAll) && (elm.Length >= idx_tenki))
						{
							// 新しい転帰は"死亡"を優先
							//if (util.ToInt(elm[idx_tenki]) == (int)eTenki.Dead) tenki = util.ToInt(elm[idx_tenki]);
							if (util.ToInt(elm[idx_tenki]) == (int)eTenki.Dead) tenki = elm[idx_tenki];
						}

						if (util.ToInt(tenki) == 0) tenki = "";


                        //20180411 yamada add /S 外字が含まれていれば漢字氏名にカナ氏名をセットする
                        //ver2.2管理表No:024
                        //外字チェック
                        string patientName = elm[idx_name];
                        int intret = ChkGaiji(patientName);
                        if (intret == 1)
                        {
                            //外字あれば漢字氏名を全角カナ氏名に置き換え               
                            patientName = Strings.StrConv(elm[idx_kana], VbStrConv.Wide, _LCID);
                            LogGW(hospId, false, "外字有の為カナ氏名へ置き換え「{0}」→「{1}」", elm[idx_name], patientName);

                        }
                        else if (intret < 0)
                        {
                            //LogGW(hospId, err, "例外発生：ChkGaiji()");

                        }
                        //20180411 yamada add /E


                        //string tbl_patient_u =
                        //	"update tbl_patient set patient_name='{0}',patient_kana='{1}',patient_sex='{2}'," +
                        //	"patient_birthday='{3}',patient_state='{4}',zip_code='{5}',address1='{6}',address2='{7}'," +
                        //	"tel_no='{8}', patient_id='{9}', last_visit='{10}' where hosp_id='{11}' and patient_id='{12}'";
                        string tbl_patient_u =
							"update tbl_patient set patient_name='{0}',patient_kana='{1}',patient_sex='{2}'," +
							"patient_birthday='{3}',patient_state='{4}',zip_code='{5}',address1='{6}',address2='{7}'," +
							"tel_no='{8}', patient_id='{9}', last_visit='{10}', gw_set=1 where hosp_id='{11}' and patient_id='{12}'";

                        //20180411 yamada add /S 外字が含まれていれば漢字氏名にカナ氏名をセットする
                        //ver2.2管理表No:024

                        //sql = string.Format(tbl_patient_u, elm[idx_name], elm[idx_kana], sex[index],
                        //                    elm[idx_birh], tenki, elm[idx_zip], elm[idx_adr1], elm[idx_adr2],
                        //                    elm[idx_tel], elm[idx_id], elm[idx_saisyu], hospId, elm[idx_org_id]);
                        sql = string.Format(tbl_patient_u, patientName, elm[idx_kana], sex[index],
                                            elm[idx_birh], tenki, elm[idx_zip], elm[idx_adr1], elm[idx_adr2],
                                            elm[idx_tel], elm[idx_id], elm[idx_saisyu], hospId, elm[idx_org_id]);

                        //20180411 yamada add /E

                        if (!fnc.sqlUpdate(sql))
						{
							LogGW(hospId, err, MSG_ERR_SET_DB, sql);
							SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
						}
					}
					else
					{

                        //20180416 yamada add /S 患者ID変更時存在チェックを行う
                        //ver2.2管理表No:048 

                        sql = string.Format("select * from tbl_patient where hosp_id='{0}' and patient_id='{1}'", hospId, elm[idx_id]);

                        dt = new DataTable();
                        ret = fnc.sqlSelectTable(sql, ref dt);
                        if (dt.Rows.Count > 0)
                        {
                            //患者IDが存在していたらエラーとする
                            LogGW(hospId, err, MSG_ERR_PATIENT_DUPLICATE, sql, elm[idx_org_id],elm[idx_id]);

                            //Withでは既に変更元IDは削除されているのでWithyou側の変更元IDも削除しなければならない。
                            //GWでは削除せずに画面で削除してもらうようにgw_setをNULLに設定する
                            sql = string.Format("update tbl_patient set gw_set=NULL " +
                                "where hosp_id='{0}' and patient_id='{1}'", hospId, elm[idx_org_id]);

                            if (!fnc.sqlUpdate(sql))
                            {
                                LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                                //SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
                                //return false;
                            }
                            SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");

                            //エラーだが、再送しなくて良いのでTrueで返す
                            return true;
                        }

                        LogGW(hospId, "患者ID変更「{0}」→「{1}」", elm[idx_org_id], elm[idx_id]);

                        //20180416 yamada add /E

                        //sql = string.Format("update tbl_patient set patient_id='{0}' " +
                        sql = string.Format("update tbl_patient set patient_id='{0}', gw_set=1 " +
							"where hosp_id='{1}' and patient_id='{2}'", elm[idx_id], hospId, elm[idx_org_id]);

						if (!fnc.sqlUpdate(sql))
						{
							LogGW(hospId, err, MSG_ERR_SET_DB, sql);
							SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
							//return false;
						}
					}
				}

				// tbl_patient_visit
				{
					string today = DateTime.Now.ToString("yyyyMMdd");
					string yesterday = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
					string startDate = "";  // 17.10.30 add
					const string defaultStartDay = "19000101";	// 17.10.30 add

					// 患者番号変更以外
					if (!updateFlg)
					{

                        //20180330 yamada comment /S この部分は将来的に履歴を持つようにすると必要になるのでコメントにしておく
                        //ver2.2管理表番号：009

                        //                  sql = string.Format("select * from tbl_patient_visit where hosp_id='{0}' and patient_id='{1}' and CONVERT(varchar, end_date, 112)='{2}' and CONVERT(varchar, start_date, 112) <> '{3}'",
                        //			hospId, elm[0], "99991231", defaultStartDay); // today); 17.01.01 chg

                        //dt = new DataTable();
                        //ret = fnc.sqlSelectTable(sql, ref dt);
                        //if (dt.Rows.Count != 0)
                        //{
                        //                      ////fnc.sqlSelectTable(sql, ref dt);
                        //                      DateTime start_date = (DateTime)dt.Rows[0]["start_date"];
                        //                      string start = start_date.ToString("yyyyMMdd");

                        //                      // "99991231"の更新
                        //                      sql = string.Format("update tbl_patient_visit set end_date = '{0}' " +
                        //                          " where hosp_id='{1}' and patient_id='{2}' and CONVERT(varchar, start_date, 112)='{3}'",
                        //                          yesterday, hospId, elm[idx_id], start);

                        //                      if (!fnc.sqlUpdate(sql))
                        //                      {
                        //                          LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                        //                          SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
                        //                          //return false;
                        //                      }
                        //                      startDate = today;  // 既に登録されていた時は当日日付を設定 17.01.01 add


                        //                  }
                        //                  else startDate = defaultStartDay;   // 初めての設定時は開始に"19000101"を設定 17.01.01 add


                        //                  //20180328 yamada update /S 余計な括弧が付いてエラーになるので修正
                        //                  //sql = string.Format("select * from tbl_patient_visit where hosp_id = '{0}' and patient_id = '{1}' and CONVERT(varchar, start_date, 112) = '{2}')", hospId, elm[idx_id], startDate);
                        //                  sql = string.Format("select * from tbl_patient_visit where hosp_id = '{0}' and patient_id = '{1}' and CONVERT(varchar, start_date, 112) = '{2}'", hospId, elm[idx_id], startDate);
                        //                  //20180328 yamada update /E
                        //                  dt = new DataTable();
                        //ret = fnc.sqlSelectTable(sql, ref dt);
                        //if (dt.Rows.Count == 0)
                        //{
                        //	string tbl_patient_visit_i = "insert into tbl_patient_visit (hosp_id,patient_id,start_date) " +
                        // "values ('{0}','{1}','{2}')";
                        //	sql = string.Format(tbl_patient_visit_i, hospId, elm[idx_id], startDate); // today); 17.01.01 chg

                        //	if (!fnc.sqlInsert(sql))
                        //	{
                        //		LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                        //		SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
                        //	}
                        //}
                        //                  string reason = elm[idx_rsn];
                        //if (reason.Length >= 200) reason = reason.Substring(0, 200);

                        //string kgd = "1";
                        //for(int j=0;j< kaigodo_tbl.Length; j++)
                        //{
                        //	if (elm[idx_kgd].CompareTo(kaigodo_tbl[j]) == 0)
                        //	{
                        //		kgd = j.ToString();
                        //		break;
                        //	}
                        //}

                        //sql = string.Format("select * from mst_visit where hosp_id='{0}' and visit_id='{1}'",
                        //					hospId, elm[idx_vc]);

                        //string kbn = fnc.sqlSelect(sql, "visit_kbn");
                        //if (kbn.Length == 0) kbn = "0";

                        ////string tbl_patient_visit_u =
                        ////    "update tbl_patient_visit set end_date='{0}',visit_id='{1}',reason='{2}',care_level='{3}', patient_id='{4}', first_visit='{5}', visit_kbn='{6}'" +
                        ////    " where hosp_id='{7}' and patient_id='{8}' and start_date='{9}'";
                        //string tbl_patient_visit_u =
                        //	"update tbl_patient_visit set end_date='{0}',visit_id='{1}',reason='{2}',care_level='{3}', patient_id='{4}', first_visit='{5}', visit_kbn='{6}'" +
                        //	" where hosp_id='{7}' and patient_id='{8}' and CONVERT(varchar, start_date, 112)='{9}'";
                        //sql = string.Format(tbl_patient_visit_u, "99991231", elm[idx_vc], reason, kgd, elm[idx_id], elm[idx_syoshin], kbn,
                        //                                  hospId, elm[idx_org_id], startDate); // today); 17.01.01 chg

                        //                  if (!fnc.sqlUpdate(sql))
                        //                  {
                        //	LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                        //	SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
                        //	//return false;
                        //                  }

                        //20180330 yamada comment /E


                        //20180330 yamada add /S end_date=99991231があったら、start_date=19000101にUPDATEして、それ以外のレコードは全て削除する。ない場合はInsert。
                        //開始日が19000101以外は削除する(現状２レコード以上あるデータが有るため)
                        //ver2.2管理表番号：009

                        sql = string.Format("Delete from tbl_patient_visit where hosp_id='{0}' and patient_id='{1}' and CONVERT(varchar, end_date, 112)<>'{2}' ",
                                hospId, elm[0], "99991231");
                        if (!fnc.sqlDelete(sql))
                        {
                            LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                        }

                        //無ければInsert、あればstart_dateを19000101に更新
                        sql = string.Format("select * from tbl_patient_visit where hosp_id='{0}' and patient_id='{1}' ", hospId, elm[0]); 
                        dt = new DataTable();
                        ret = fnc.sqlSelectTable(sql, ref dt);
                        if (dt.Rows.Count != 0)
                        {

                            // end_date=99991231のデータのstart_dateを19000101に更新
                            sql = string.Format("update tbl_patient_visit set start_date ='{0}' " +
                                " where hosp_id='{1}' and patient_id='{2}' and CONVERT(varchar, end_date, 112)='{3}'",
                                defaultStartDay, hospId, elm[idx_id], "99991231");

                            if (!fnc.sqlUpdate(sql))
                            {
                                LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                                SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
                                //return false;
                            }

                            startDate = defaultStartDay;

                        }
                        else
                        {
                            //20180530 upd /S 介護度連携対応
                            //string tbl_patient_visit_i = "insert into tbl_patient_visit (hosp_id,patient_id,start_date,end_date) values ('{0}','{1}','{2}','{3}')";
                            //sql = string.Format(tbl_patient_visit_i, hospId, elm[idx_id], defaultStartDay, "99991231");
                            var tbl_patient_visit_i = new StringBuilder();
                            tbl_patient_visit_i.AppendLine("insert into tbl_patient_visit (");
                            tbl_patient_visit_i.AppendLine("hosp_id");
                            tbl_patient_visit_i.AppendLine(",patient_id");
                            tbl_patient_visit_i.AppendLine(",start_date");
                            tbl_patient_visit_i.AppendLine(",end_date");
                            tbl_patient_visit_i.AppendLine(",care_level");
                            tbl_patient_visit_i.AppendLine(")");
                            tbl_patient_visit_i.AppendLine("select");
                            tbl_patient_visit_i.AppendFormat("'{0}' hosp_id", hospId).AppendLine();
                            tbl_patient_visit_i.AppendFormat(",'{0}' patient_id", elm[idx_id]).AppendLine();
                            tbl_patient_visit_i.AppendFormat(",'{0}' start_date", defaultStartDay).AppendLine();
                            tbl_patient_visit_i.AppendLine(",'99991231' end_date");
                            tbl_patient_visit_i.AppendLine(",1 care_level");

                            sql = tbl_patient_visit_i.ToString();
                            //20180530 upd /E 介護度連携対応

                            if (!fnc.sqlInsert(sql))
                            {
                                LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                                SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
                            }

                            startDate = defaultStartDay;   // 初めての設定時は開始に"19000101"を設定 17.01.01 add
                        }


                        string reason = elm[idx_rsn];
                        if (reason.Length >= 200) reason = reason.Substring(0, 200);

                        //20180529 upd /S 介護度連携対応
                        //string kgd = "1";
                        var kgd = "";
                        if (care_renkei == "1")
                        {
                            //介護連携あり、の場合
                            kgd = "1";
                            //20180529 upd /E 介護度連携対応
                            for (int j = 0; j < kaigodo_tbl.Length; j++)
                            {
                                if (elm[idx_kgd].CompareTo(kaigodo_tbl[j]) == 0)
                                {
                                    kgd = j.ToString();
                                    break;
                                }
                            }
                            //20180529 add /S 介護度連携対応
                        }
                        //20180529 add /E 介護度連携対応

                        sql = string.Format("select * from mst_visit where hosp_id='{0}' and visit_id='{1}'",
                                            hospId, elm[idx_vc]);

                        string kbn = fnc.sqlSelect(sql, "visit_kbn");
                        if (kbn.Length == 0) kbn = "0";

                        //string tbl_patient_visit_u =
                        //    "update tbl_patient_visit set end_date='{0}',visit_id='{1}',reason='{2}',care_level='{3}', patient_id='{4}', first_visit='{5}', visit_kbn='{6}'" +
                        //    " where hosp_id='{7}' and patient_id='{8}' and start_date='{9}'";


                        //20180413 yamada add /S ユニット病棟コードをtbl_patient_visitに追加登録
                        //ver2.2管理表No:038

                        //ユニット病棟コードがある場合
                        string visitunit = "NULL";
                        if (idx_unit > 0)
                        {

                            //20180423 yamada add /S 空or0の時はNULLをセット
                            //ver2.2 No:114
                            //if (elm[idx_unit] != "")
                            if (elm[idx_unit] == "" || elm[idx_unit] == "0")
                            {
                                visitunit = "NULL";
                            }
                            else
                            {
                                visitunit = elm[idx_unit];
                            }
                            //20180423 yamada add /E
                        }
                        //20180529 del /S 介護度連携対応
                        //string strVisitUnit = "";

                        //if (visitunit == "NULL")
                        //{
                        //    strVisitUnit = "visit_unit=NULL ";
                        //}
                        //else
                        //{
                        //    strVisitUnit = "visit_unit='{9}' ";

                        //}
                        //20180529 del /E 介護度連携対応

                        //string tbl_patient_visit_u =
                        //    "update tbl_patient_visit set visit_id='{0}',reason='{1}',care_level='{2}', patient_id='{3}', first_visit='{4}', visit_kbn='{5}'" +
                        //    " where hosp_id='{6}' and patient_id='{7}' and CONVERT(varchar, start_date, 112)='{8}'";
                        //sql = string.Format(tbl_patient_visit_u, elm[idx_vc], reason, kgd, elm[idx_id], elm[idx_syoshin], kbn,
                        //                                  hospId, elm[idx_org_id], startDate);
                        //string tbl_patient_visit_u =
                        //    "update tbl_patient_visit set visit_id='{0}',reason='{1}',care_level='{2}', patient_id='{3}', first_visit='{4}', visit_kbn='{5}', visit_unit='{9}' " +
                        //    " where hosp_id='{6}' and patient_id='{7}' and CONVERT(varchar, start_date, 112)='{8}'";

                        //20180529 upd /S 介護度連携対応
                        //string tbl_patient_visit_u =
                        //    "update tbl_patient_visit set visit_id='{0}',reason='{1}',care_level='{2}', patient_id='{3}', first_visit='{4}', visit_kbn='{5}', " + strVisitUnit +
                        //    " where hosp_id='{6}' and patient_id='{7}' and CONVERT(varchar, start_date, 112)='{8}'";
                        var tbl_patient_visit_u = new StringBuilder();
                        tbl_patient_visit_u.AppendLine("update tbl_patient_visit set");
                        tbl_patient_visit_u.AppendFormat("visit_id='{0}'", elm[idx_vc]).AppendLine();
                        tbl_patient_visit_u.AppendFormat(",reason='{0}'", reason).AppendLine();

                        if (care_renkei == "1")
                        {
                            //介護連携あり、の場合
                            tbl_patient_visit_u.AppendFormat(",care_level='{0}'", kgd).AppendLine();
                        }
                        //※注意）elseの場合、既存データもしくは前述の insert の値を維持する。

                        tbl_patient_visit_u.AppendFormat(",patient_id='{0}'", elm[idx_id]).AppendLine();
                        tbl_patient_visit_u.AppendFormat(",first_visit='{0}'", elm[idx_syoshin]).AppendLine();
                        tbl_patient_visit_u.AppendFormat(",visit_kbn='{0}'", kbn).AppendLine();

                        if (visitunit == "NULL")
                        {
                            tbl_patient_visit_u.AppendLine(",visit_unit=NULL");
                        }
                        else
                        {
                            tbl_patient_visit_u.AppendFormat(",visit_unit={0}", visitunit).AppendLine();
                        }

                        tbl_patient_visit_u.AppendFormat("where hosp_id='{0}'", hospId).AppendLine();
                        tbl_patient_visit_u.AppendFormat("and patient_id='{0}'", elm[idx_org_id]).AppendLine();
                        tbl_patient_visit_u.AppendFormat("and CONVERT(varchar, start_date, 112)='{0}'", startDate).AppendLine();
                        sql = tbl_patient_visit_u.ToString();
                        //20180529 upd /E 介護度連携対応

                        //20180413 yamada add /E

                        if (!fnc.sqlUpdate(sql))
                        {
                            LogGW(hospId, err, MSG_ERR_SET_DB, sql);
                            SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
                            //return false;
                        }


                    }
                    else
					{

						sql = string.Format("update tbl_patient_visit set patient_id='{0}' " +
							"where hosp_id='{1}' and patient_id='{2}'", elm[idx_id], hospId, elm[idx_org_id]);

						if (!fnc.sqlUpdate(sql))
						{
							LogGW(hospId, err, MSG_ERR_SET_DB, sql);
							SetExclusive(hospId, "patientInfo", elm[idx_id], "CLOSE");
							//return false;
						}
					}

					SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外

					// その他
					{
						if (updateFlg)
						{
							UpdatePatientTable(hospId, elm[idx_id], elm[idx_org_id]);
						}
					}
				}
				SetExclusive(hospId, "patientInfo", nowPatientId, "CLOSE");
			}

			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetTablePatient() {0}", ex.ToString());
			SetExclusive(hospId, "patientInfo", nowPatientId, "CLOSE");
			ret = false;
		}

		SetExclusive(hospId, "patientInfo", nowPatientId, "CLOSE");

		return ret;
	}

	//2020.01.31 add
	private bool SetTableGeneralDisease(string hospId, string[] lines, string msgUid)
	{
		bool ret = false;

		// CSVデータのインデックス番号
		const int idx_patient_id = 1 - 1
			, idx_junbango = 2 - 1
			, idx_kioureki_code = 3 - 1
			//, idx_jiki = 4 - 1
			, idx_keika = 5 - 1
			//, idx_karte_print_flag = 6 - 1
			//, idx_syujutu_umu_flag = 7 - 1
			//, idx_kioureki_nyuuryokubi = 8 - 1
			//, idx_monsinhyou_code = 9 - 1
			//, idx_monsinhyou_seq = 10 - 1
			, idx_remove_flag = 11 - 1
			, idx_update_date = 12 - 1
			//, idx_update_user = 13 - 1
			, idx_user_name = 14 - 1
			, idx_rece_den_code = 15 - 1
			, idx_kioureki_name_karte = 16 - 1;

		var datetimeParse = new Func<string, DateTime>(value => {
			if (string.IsNullOrEmpty(value))
			{
				return DateTime.Now;
			}
			DateTime res;
			var b = DateTime.TryParseExact(value, "yyyyMMdd HH:mm:ss", null, DateTimeStyles.None, out res);
			if (!b)
			{
				return DateTime.Now;
			}
			return res;
		});

		try
		{
			int total = lines.Length - 3;

			var fnc = new PfDB();

			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行以降は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

				string[] elm = elms(lines[i], 16);
				if (EndMark.CompareTo(elm[0]) == 0) break;

				var measure_date = datetimeParse(elm[idx_update_date]).ToString("yyyy/MM/dd");

				var sql_where = new StringBuilder();
				sql_where.AppendFormat("WHERE");
				sql_where.AppendLine().AppendFormat("[hosp_id] = '{0}'", hospId);
				sql_where.AppendLine().AppendFormat("AND [patient_id] = '{0}'", elm[idx_patient_id]);
				//sql_where.AppendLine().AppendFormat("AND [with_seqno] = {0}", elm[idx_junbango]);

				if (!string.IsNullOrEmpty(elm[idx_rece_den_code]))
				{
					sql_where.AppendLine().AppendFormat("AND [disease_cd] = '{0}'", elm[idx_rece_den_code]);
				}
				else
				{
					sql_where.AppendLine().AppendFormat("AND [with_kiorekicd] = {0}", elm[idx_kioureki_code]);
				}

				// まずはPRIMARY KEYのみinsertしたレコードを作成(レコードがなければ)
				var sql = new StringBuilder();
				sql.AppendFormat("select");
				sql.AppendLine().AppendFormat("*");
				sql.AppendLine().AppendFormat("from");
				sql.AppendLine().AppendFormat("tbl_general_disease");
				sql.AppendLine().AppendFormat(sql_where.ToString());

				var dt = new DataTable();
				fnc.sqlSelectTable(sql.ToString(), ref dt);
				if (dt.Rows.Count <= 0)
				{
					//LogGW(hospId, "[SetTableGeneralDisease]insert");

					sql.Clear();
					sql.AppendFormat("INSERT INTO");
					sql.AppendLine().AppendFormat("tbl_general_disease");
					sql.AppendLine().AppendFormat("(");
					sql.AppendLine().AppendFormat("[hosp_id]");
					sql.AppendLine().AppendFormat(",[patient_id]");
					sql.AppendLine().AppendFormat(",[measure_date]");
					sql.AppendLine().AppendFormat(",[seq_no]");
					sql.AppendLine().AppendFormat(",[mask]");
					sql.AppendLine().AppendFormat(",[regist_user]");
					sql.AppendLine().AppendFormat(",[regist_date]");
					sql.AppendLine().AppendFormat(",[medical_history]");
					sql.AppendLine().AppendFormat(",[disease_id]");
					sql.AppendLine().AppendFormat(",[disease_cd]");
					sql.AppendLine().AppendFormat(",[disease_name]");
					sql.AppendLine().AppendFormat(",[medical_facility]");
					sql.AppendLine().AppendFormat(",[with_seqno]");
					sql.AppendLine().AppendFormat(",[with_kiorekicd]");
					sql.AppendLine().AppendFormat(",[with_keika]");
					sql.AppendLine().AppendFormat(")");
					sql.AppendLine().AppendFormat("SELECT");
					sql.AppendLine().AppendFormat("'{0}' [hosp_id]", hospId);
					sql.AppendLine().AppendFormat(",'{0}' [patient_id]", elm[idx_patient_id]);
					sql.AppendLine().AppendFormat(",'{0}' [measure_date]", measure_date);
					sql.AppendLine().AppendFormat(",isnull(");
					sql.AppendLine().AppendFormat("  (SELECT");
					sql.AppendLine().AppendFormat("  max([seq_no])");
					sql.AppendLine().AppendFormat("  FROM");
					sql.AppendLine().AppendFormat("  tbl_general_disease");
					sql.AppendLine().AppendFormat("  WHERE");
					sql.AppendLine().AppendFormat("  [hosp_id] = '{0}'", hospId);
					sql.AppendLine().AppendFormat("  AND [patient_id] = '{0}'", elm[idx_patient_id]);
					sql.AppendLine().AppendFormat("  AND [measure_date] = '{0}'", measure_date);
					sql.AppendLine().AppendFormat("  ), 0) + 1 [seq_no]");
					sql.AppendLine().AppendFormat(",{0} [mask]", elm[idx_remove_flag]);
					sql.AppendLine().AppendFormat(",'{0}' [regist_user]", elm[idx_user_name]);
					sql.AppendLine().AppendFormat(",'{0}' [regist_date]", datetimeParse(elm[idx_update_date]).ToString("yyyy/MM/dd HH:mm:ss"));
					//sql.AppendLine().AppendFormat(",'既往歴' [medical_history]");
					sql.AppendLine().AppendFormat(",isnull(");
					sql.AppendLine().AppendFormat("  (select");
					sql.AppendLine().AppendFormat("  top(1)");
					sql.AppendLine().AppendFormat("  medical_history");
					sql.AppendLine().AppendFormat("  from");
					sql.AppendLine().AppendFormat("  tbl_general_disease");
					sql.AppendLine().AppendFormat("  WHERE");
					sql.AppendLine().AppendFormat("  [hosp_id] = '{0}'", hospId);
					sql.AppendLine().AppendFormat("  AND [patient_id] = '{0}'", elm[idx_patient_id]);
					sql.AppendLine().AppendFormat("  AND [with_kiorekicd] = {0}", elm[idx_kioureki_code]);
					sql.AppendLine().AppendFormat("  order by");
					sql.AppendLine().AppendFormat("  [with_seqno] desc");
					sql.AppendLine().AppendFormat("  ,[seq_no] desc");
					sql.AppendLine().AppendFormat("  ), '既往歴') [medical_history]");
					sql.AppendLine().AppendFormat(",isnull(");
					sql.AppendLine().AppendFormat("  (SELECT");
					sql.AppendLine().AppendFormat("  max([disease_id])");
					sql.AppendLine().AppendFormat("  FROM");
					sql.AppendLine().AppendFormat("  tbl_general_disease");
					//sql.AppendLine().AppendFormat("  WHERE");
					//sql.AppendLine().AppendFormat("  [hosp_id] = '{0}'", hospId);
					//sql.AppendLine().AppendFormat("  AND [patient_id] = '{0}'", elm[idx_patient_id]);
					//sql.AppendLine().AppendFormat("  AND [disease_cd] = '{0}'", elm[idx_rece_den_code]);
					sql.AppendLine().AppendFormat("  ), 0) + 1 [disease_id]");
					sql.AppendLine().AppendFormat(",'{0}' [disease_cd]", elm[idx_rece_den_code]);

					if (string.IsNullOrEmpty(elm[idx_rece_den_code]))
					{
						sql.AppendLine().AppendFormat(",'{0}' [disease_name]", elm[idx_kioureki_name_karte]);
					}
					else
					{
						sql.AppendLine().AppendFormat(",isnull(");
						sql.AppendLine().AppendFormat("  (select");
						sql.AppendLine().AppendFormat("  top(1)");
						sql.AppendLine().AppendFormat("  [006]");
						sql.AppendLine().AppendFormat("  from");
						sql.AppendLine().AppendFormat("  mst_general_disease");
						sql.AppendLine().AppendFormat("  where mask = 0");
						sql.AppendLine().AppendFormat("  and disease_cd = '{0}'", elm[idx_rece_den_code]);
						sql.AppendLine().AppendFormat("  ), '{0}') [disease_name]", elm[idx_kioureki_name_karte]);
					}

					//sql.AppendLine().AppendFormat(", [medical_facility]");
					sql.AppendLine().AppendFormat(",(select");
					sql.AppendLine().AppendFormat("  top(1)");
					sql.AppendLine().AppendFormat("  medical_facility");
					sql.AppendLine().AppendFormat("  from");
					sql.AppendLine().AppendFormat("  tbl_general_disease");
					sql.AppendLine().AppendFormat("  WHERE");
					sql.AppendLine().AppendFormat("  [hosp_id] = '{0}'", hospId);
					sql.AppendLine().AppendFormat("  AND [patient_id] = '{0}'", elm[idx_patient_id]);
					sql.AppendLine().AppendFormat("  AND [with_kiorekicd] = {0}", elm[idx_kioureki_code]);
					sql.AppendLine().AppendFormat("  order by");
					sql.AppendLine().AppendFormat("  [with_seqno] desc");
					sql.AppendLine().AppendFormat("  ,[seq_no] desc");
					sql.AppendLine().AppendFormat("  ) [medical_facility]");
					sql.AppendLine().AppendFormat(",{0} [with_seqno]", elm[idx_junbango]);
					sql.AppendLine().AppendFormat(",{0} [with_kiorekicd]", elm[idx_kioureki_code]);
					sql.AppendLine().AppendFormat(",{0} [with_keika]", elm[idx_keika]);

					if (!fnc.sqlInsert(sql.ToString()))
					{
						//LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_general_disease");
						LogGW(hospId, err, MSG_ERR_SET_DB, sql.ToString().PadRight(400, ' ').Substring(0, 400).TrimEnd());
						//return false;
					}
				}
				else
				{
					//LogGW(hospId, "[SetTableGeneralDisease]update where: {0}", sql_where.ToString());

					//削除されていないレコードを更新する
					// updateでDBに設定
					sql.Clear();
					sql.AppendFormat("UPDATE");
					sql.AppendLine().AppendFormat("tbl_general_disease");
					sql.AppendLine().AppendFormat("SET");
					sql.AppendLine().AppendFormat("[mask] = {0}", elm[idx_remove_flag]);
					sql.AppendLine().AppendFormat(",[regist_user] = '{0}'", elm[idx_user_name]);
					sql.AppendLine().AppendFormat(",[regist_date] = '{0}'", datetimeParse(elm[idx_update_date]).ToString("yyyy/MM/dd HH:mm:ss"));
					sql.AppendLine().AppendFormat(",[with_keika] = {0}", elm[idx_keika]);
					sql.AppendLine().AppendFormat(sql_where.ToString());
					//sql.AppendLine().AppendFormat("AND ([mask] is null or [mask] = 0)");
					sql.AppendLine().AppendFormat("AND [seq_no]");
					sql.AppendLine().AppendFormat("    = (select max([seq_no])");
					sql.AppendLine().AppendFormat("        from tbl_general_disease");
					sql.AppendLine().AppendFormat(sql_where.ToString());
					sql.AppendLine().AppendFormat("        )");

					if (!fnc.sqlUpdate(sql.ToString())) LogGW(hospId, err, MSG_ERR_SET_DB, sql.ToString().PadRight(400, ' ').Substring(0, 400).TrimEnd()); //LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_general_disease");
				}

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}

			//LogGW(hospId, "[SetTableGeneralDisease] ret = true;");
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetTableGeneralDisease() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	//2020.01.31 add
	private bool SetTableTakingMedicines(string hospId, string[] lines, string msgUid)
	{
		bool ret = false;

		// CSVデータのインデックス番号
		const int idx_patient_id = 1 - 1
			, idx_junbango = 2 - 1
			, idx_yakka_code = 3 - 1
			//, idx_fukuyou_kaisibi = 4 - 1
			//, idx_fukuyou_syuuryoubi = 5 - 1
			, idx_fukuyou_kubun = 6 - 1
			//, idx_monsinhyou_code = 7 - 1
			, idx_remove_flag = 8 - 1
			, idx_update_date = 9 - 1
			//, idx_update_user = 10 - 1
			//, idx_tyouzaibi = 11 - 1
			//, idx_okusuritetyou_yomikomi_flag = 12 - 1
			, idx_user_name = 13 - 1
			, idx_medicine_name = 14 - 1;

		var datetimeParse = new Func<string, DateTime>(value => {
			if (string.IsNullOrEmpty(value))
			{
				return DateTime.Now;
			}
			DateTime res;
			var b = DateTime.TryParseExact(value, "yyyyMMdd HH:mm:ss", null, DateTimeStyles.None, out res);
			if (!b)
			{
				return DateTime.Now;
			}
			return res;
		});

		try
		{
			int total = lines.Length - 3;

			var fnc = new PfDB();

			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行以降は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

				string[] elm = elms(lines[i], 13);
				if (EndMark.CompareTo(elm[0]) == 0) break;

				var measure_date = datetimeParse(elm[idx_update_date]).ToString("yyyy/MM/dd");

				var medical_history = "";
				switch (elm[idx_fukuyou_kubun])
				{
					case "1":
						medical_history = "服用中";
						break;
					case "2":
						medical_history = "服用終了";
						break;
				}

				var sql_where = new StringBuilder();
				sql_where.AppendFormat("WHERE");
				sql_where.AppendLine().AppendFormat("[hosp_id] = '{0}'", hospId);
				sql_where.AppendLine().AppendFormat("AND [patient_id] = '{0}'", elm[idx_patient_id]);
				//sql_where.AppendLine().AppendFormat("AND [with_seqno] = {0}", elm[idx_junbango]);
				sql_where.AppendLine().AppendFormat("AND [yakka_code] = '{0}'", elm[idx_yakka_code]);

				// まずはPRIMARY KEYのみinsertしたレコードを作成(レコードがなければ)
				var sql = new StringBuilder();
				sql.AppendFormat("select");
				sql.AppendLine().AppendFormat("*");
				sql.AppendLine().AppendFormat("from");
				sql.AppendLine().AppendFormat("tbl_taking_medicines");
				sql.AppendLine().AppendFormat(sql_where.ToString());

				var dt = new DataTable();
				fnc.sqlSelectTable(sql.ToString(), ref dt);
				if (dt.Rows.Count <= 0)
				{
					sql.Clear();
					sql.AppendLine().AppendFormat("INSERT INTO");
					sql.AppendLine().AppendFormat("tbl_taking_medicines");
					sql.AppendLine().AppendFormat("(");
					sql.AppendLine().AppendFormat("[hosp_id]");
					sql.AppendLine().AppendFormat(",[patient_id]");
					sql.AppendLine().AppendFormat(",[measure_date]");
					sql.AppendLine().AppendFormat(",[seq_no]");
					sql.AppendLine().AppendFormat(",[mask]");
					sql.AppendLine().AppendFormat(",[regist_user]");
					sql.AppendLine().AppendFormat(",[regist_date]");
					sql.AppendLine().AppendFormat(",[medical_history]");
					sql.AppendLine().AppendFormat(",[medicine_id]");
					sql.AppendLine().AppendFormat(",[yakka_code]");
					sql.AppendLine().AppendFormat(",[medicine_name]");
					sql.AppendLine().AppendFormat(",[medical_facility]");
					sql.AppendLine().AppendFormat(",[with_seqno]");
					sql.AppendLine().AppendFormat(")");
					sql.AppendLine().AppendFormat("SELECT");
					sql.AppendLine().AppendFormat("'{0}' [hosp_id]", hospId);
					sql.AppendLine().AppendFormat(",'{0}' [patient_id]", elm[idx_patient_id]);
					sql.AppendLine().AppendFormat(",'{0}' [measure_date]", measure_date);
					sql.AppendLine().AppendFormat(",isnull(");
					sql.AppendLine().AppendFormat("  (SELECT");
					sql.AppendLine().AppendFormat("  max([seq_no])");
					sql.AppendLine().AppendFormat("  FROM");
					sql.AppendLine().AppendFormat("  tbl_taking_medicines");
					sql.AppendLine().AppendFormat("  WHERE");
					sql.AppendLine().AppendFormat("  [hosp_id] = '{0}'", hospId);
					sql.AppendLine().AppendFormat("  AND [patient_id] = '{0}'", elm[idx_patient_id]);
					sql.AppendLine().AppendFormat("  AND [measure_date] = '{0}'", measure_date);
					sql.AppendLine().AppendFormat("  ), 0) + 1 [seq_no]");
					sql.AppendLine().AppendFormat(",{0} [mask]", elm[idx_remove_flag]);
					sql.AppendLine().AppendFormat(",'{0}' [regist_user]", elm[idx_user_name]);
					sql.AppendLine().AppendFormat(",'{0}' [regist_date]", datetimeParse(elm[idx_update_date]).ToString("yyyy/MM/dd HH:mm:ss"));
					sql.AppendLine().AppendFormat(",'{0}' [medical_history]", medical_history);
					//sql.AppendLine().AppendFormat(",isnull(");
					//sql.AppendLine().AppendFormat("  (select");
					//sql.AppendLine().AppendFormat("  top(1)");
					//sql.AppendLine().AppendFormat("  medical_history");
					//sql.AppendLine().AppendFormat("  from");
					//sql.AppendLine().AppendFormat("  tbl_taking_medicines");
					//sql.AppendLine().AppendFormat("  WHERE");
					//sql.AppendLine().AppendFormat("  [hosp_id] = '{0}'", hospId);
					//sql.AppendLine().AppendFormat("  AND [patient_id] = '{0}'", elm[idx_patient_id]);
					//sql.AppendLine().AppendFormat("  AND [yakka_code] = '{0}'", elm[idx_yakka_code]);
					//sql.AppendLine().AppendFormat("  order by");
					//sql.AppendLine().AppendFormat("  [with_seqno] desc");
					//sql.AppendLine().AppendFormat("  ,[seq_no] desc");
					//sql.AppendLine().AppendFormat("  ), '{0}') [medical_history]", medical_history);
					sql.AppendLine().AppendFormat(",isnull(");
					sql.AppendLine().AppendFormat("  (SELECT");
					sql.AppendLine().AppendFormat("  max([medicine_id])");
					sql.AppendLine().AppendFormat("  FROM");
					sql.AppendLine().AppendFormat("  tbl_taking_medicines");
					//sql.AppendLine().AppendFormat("  WHERE");
					//sql.AppendLine().AppendFormat("  [hosp_id] = '{0}'", hospId);
					//sql.AppendLine().AppendFormat("  AND [patient_id] = '{0}'", elm[idx_patient_id]);
					//sql.AppendLine().AppendFormat("  AND [yakka_code] = '{0}'", elm[idx_yakka_code]);
					sql.AppendLine().AppendFormat("  ), 0) + 1 [medicine_id]");
					sql.AppendLine().AppendFormat(",'{0}' [yakka_code]", elm[idx_yakka_code]);

					var medicine_name = elm[idx_medicine_name];
					if (string.IsNullOrEmpty(medicine_name))
					{
						medicine_name = "(該当なし)";
					}
					else
					{
						medicine_name = new String(medicine_name.TakeWhile((c, j) => util.EncodeShiftJis.GetByteCount(medicine_name.Substring(0, j + 1)) <= 64).ToArray());
					}

					sql.AppendLine().AppendFormat(",isnull(");
					sql.AppendLine().AppendFormat("  (select");
					sql.AppendLine().AppendFormat("  top(1)");
					sql.AppendLine().AppendFormat("  [005]");
					sql.AppendLine().AppendFormat("  from");
					sql.AppendLine().AppendFormat("  mst_medicine");
					sql.AppendLine().AppendFormat("  where mask = 0");
					sql.AppendLine().AppendFormat("  and yakka_code = '{0}'", elm[idx_yakka_code]);
					sql.AppendLine().AppendFormat("  ), '{0}') [medicine_name]", medicine_name);

					//sql.AppendLine().AppendFormat(", [medical_facility]");
					sql.AppendLine().AppendFormat(",(select");
					sql.AppendLine().AppendFormat("  top(1)");
					sql.AppendLine().AppendFormat("  medical_facility");
					sql.AppendLine().AppendFormat("  from");
					sql.AppendLine().AppendFormat("  tbl_taking_medicines");
					sql.AppendLine().AppendFormat("  WHERE");
					sql.AppendLine().AppendFormat("  [hosp_id] = '{0}'", hospId);
					sql.AppendLine().AppendFormat("  AND [patient_id] = '{0}'", elm[idx_patient_id]);
					sql.AppendLine().AppendFormat("  AND [yakka_code] = '{0}'", elm[idx_yakka_code]);
					sql.AppendLine().AppendFormat("  order by");
					sql.AppendLine().AppendFormat("  [with_seqno] desc");
					sql.AppendLine().AppendFormat("  ,[seq_no] desc");
					sql.AppendLine().AppendFormat("  ) [medical_facility]");
					sql.AppendLine().AppendFormat(",{0} [with_seqno]", elm[idx_junbango]);

					if (!fnc.sqlInsert(sql.ToString()))
					{
						LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_taking_medicines");
						//return false;
					}
				}
				else
				{
					//削除されていないレコードを更新する
					// updateでDBに設定
					sql.Clear();
					sql.AppendFormat("UPDATE");
					sql.AppendLine().AppendFormat("tbl_taking_medicines");
					sql.AppendLine().AppendFormat("SET");
					sql.AppendLine().AppendFormat("[mask] = {0}", elm[idx_remove_flag]);
					sql.AppendLine().AppendFormat(",[regist_user] = '{0}'", elm[idx_user_name]);
					sql.AppendLine().AppendFormat(",[regist_date] = '{0}'", datetimeParse(elm[idx_update_date]).ToString("yyyy/MM/dd HH:mm:ss"));
					sql.AppendLine().AppendFormat(",[medical_history] = '{0}'", medical_history);
					sql.AppendLine().AppendFormat(sql_where.ToString());
					//sql.AppendLine().AppendFormat("AND ([mask] is null or [mask] = 0)");
					sql.AppendLine().AppendFormat("AND [seq_no]");
					sql.AppendLine().AppendFormat("    = (select max([seq_no])");
					sql.AppendLine().AppendFormat("        from tbl_taking_medicines");
					sql.AppendLine().AppendFormat(sql_where.ToString());
					sql.AppendLine().AppendFormat("        )");

					if (!fnc.sqlUpdate(sql.ToString())) LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_taking_medicines");
				}

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetTableTakingMedicines() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	//2020.02.04 add
	private bool SetTableGeneralDiseaseRenkeiData(string hospId, string[] lines, string msgUid)
	{
		bool ret = false;

		// CSVデータのインデックス番号
		const int idx_patient_id = 1 - 1
			, idx_measure_date = 2 - 1
			, idx_seq_no = 3 - 1
			//, idx_mask = 4 - 1
			//, idx_regist_user = 5 - 1
			//, idx_regist_date = 6 - 1
			//, idx_medical_history = 7 - 1
			//, idx_disease_cd = 8 - 1
			//, idx_disease_name = 9 - 1
			//, idx_medical_facility = 10 - 1
			, idx_with_seqno = 11 - 1
			, idx_with_kiorekicd = 12 - 1
			, idx_with_keika = 13 - 1
		//, idx_icd10 = 14 - 1
		//, idx_disease_name_kana = 15 - 1
		//, idx_withyou_status = 16 - 1
		//, idx_with_status = 17 - 1
		//, idx_with_mod_usercd = 18 - 1
		//, idx_with_mod_username = 19 - 1
		//, idx_with_mod_date = 20 - 1;
		;

		try
		{
			int total = lines.Length - 3;

			var fnc = new PfDB();

			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			var sql = new StringBuilder();
			sql.AppendFormat("UPDATE");
			sql.AppendLine().AppendFormat("tbl_general_disease");
			sql.AppendLine().AppendFormat("SET");
			sql.AppendLine().AppendFormat(" [with_seqno] = @with_seqno");
			sql.AppendLine().AppendFormat(",[with_kiorekicd] = @with_kiorekicd");
			sql.AppendLine().AppendFormat(",[with_keika] = @with_keika");
			sql.AppendLine().AppendFormat("WHERE");
			sql.AppendLine().AppendFormat("[hosp_id] = @hosp_id");
			sql.AppendLine().AppendFormat("and [patient_id] = @patient_id");
			sql.AppendLine().AppendFormat("and [measure_date] = @measure_date");
			sql.AppendLine().AppendFormat("and [seq_no] >= @seq_no");

			var stringOrDBNull = new Func<string, object>(value => string.IsNullOrEmpty(value) ? DBNull.Value : (object)value);
			var parseDateTimeOrDBNull = new Func<string, object>(value => {
				DateTime res;
				return DateTime.TryParse(value, out res) ? (object)res : DBNull.Value;
			});
			var parseIntOrDBNull = new Func<string, object>(value => {
				int res;
				return int.TryParse(value, out res) ? (object)res : DBNull.Value;
			});
			var parseShortOrDBNull = new Func<string, object>(value => {
				short res;
				return short.TryParse(value, out res) ? (object)res : DBNull.Value;
			});

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行以降は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

				string[] elm = elms(lines[i], 20);
				if (EndMark.CompareTo(elm[0]) == 0) break;

				var param = new[] {
					new SqlParameter("@hosp_id", SqlDbType.VarChar) { Value = hospId },
					new SqlParameter("@patient_id", SqlDbType.VarChar) { Value = elm[idx_patient_id] },
					new SqlParameter("@measure_date", SqlDbType.DateTime) { Value = parseDateTimeOrDBNull(elm[idx_measure_date]) },
					new SqlParameter("@seq_no", SqlDbType.Int) { Value = parseIntOrDBNull(elm[idx_seq_no]) },
					new SqlParameter("@with_seqno", SqlDbType.SmallInt) { Value = parseShortOrDBNull(elm[idx_with_seqno]) },
					new SqlParameter("@with_kiorekicd", SqlDbType.SmallInt) { Value = parseShortOrDBNull(elm[idx_with_kiorekicd]) },
					new SqlParameter("@with_keika", SqlDbType.SmallInt) { Value = parseShortOrDBNull(elm[idx_with_keika]) },
				};

				if (!fnc.sqlUpdate(sql.ToString(), param)) LogGW(hospId, err, MSG_ERR_SET_DB, sql.ToString().PadRight(400, ' ').Substring(0, 400).TrimEnd()); //LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_general_disease");

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}

			//LogGW(hospId, "[SetTableGeneralDiseaseRenkeiData] ret = true;");
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetTableGeneralDiseaseRenkeiData() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	//2020.02.04 add
	private bool SetTableTakingMedicinesRenkeiData(string hospId, string[] lines, string msgUid)
	{
		bool ret = false;

		// CSVデータのインデックス番号
		const int idx_patient_id = 1 - 1
			, idx_measure_date = 2 - 1
			, idx_seq_no = 3 - 1
			//, idx_mask = 4 - 1
			//, idx_regist_user = 5 - 1
			//, idx_regist_date = 6 - 1
			, idx_medical_history = 7 - 1
			//, idx_yakka_code = 8 - 1
			//, idx_medicine_name = 9 - 1
			//, idx_medical_facility = 10 - 1
			, idx_with_seqno = 11 - 1;
		//, idx_withyou_status = 12 - 1
		//, idx_with_status = 13 - 1
		//, idx_with_mod_usercd = 14 - 1
		//, idx_with_mod_username = 15 - 1
		//, idx_with_mod_date = 16 - 1;

		try
		{
			int total = lines.Length - 3;

			var fnc = new PfDB();

			SetProcessedStatus(hospId, msgUid, total, 0, true); // true = start

			var sql = new StringBuilder();
			sql.AppendFormat("UPDATE");
			sql.AppendLine().AppendFormat("tbl_taking_medicines");
			sql.AppendLine().AppendFormat("SET");
			sql.AppendLine().AppendFormat(" [with_seqno] = @with_seqno");
			sql.AppendLine().AppendFormat(",[medical_history] = @medical_history");
			sql.AppendLine().AppendFormat("WHERE");
			sql.AppendLine().AppendFormat("[hosp_id] = @hosp_id");
			sql.AppendLine().AppendFormat("and [patient_id] = @patient_id");
			sql.AppendLine().AppendFormat("and [measure_date] = @measure_date");
			sql.AppendLine().AppendFormat("and [seq_no] >= @seq_no");

			var stringOrDBNull = new Func<string, object>(value => string.IsNullOrEmpty(value) ? DBNull.Value : (object)value);
			var parseDateTimeOrDBNull = new Func<string, object>(value => {
				DateTime res;
				return DateTime.TryParse(value, out res) ? (object)res : DBNull.Value;
			});
			var parseIntOrDBNull = new Func<string, object>(value => {
				int res;
				return int.TryParse(value, out res) ? (object)res : DBNull.Value;
			});
			var parseShortOrDBNull = new Func<string, object>(value => {
				short res;
				return short.TryParse(value, out res) ? (object)res : DBNull.Value;
			});

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行以降は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

				string[] elm = elms(lines[i], 16);
				if (EndMark.CompareTo(elm[0]) == 0) break;

				object medical_history = DBNull.Value;
				switch (elm[idx_medical_history])
				{
					case "1":
						medical_history = "服用中";
						break;
					case "2":
						medical_history = "服用終了";
						break;
				}

				var param = new[] {
					new SqlParameter("@hosp_id", SqlDbType.VarChar) { Value = hospId },
					new SqlParameter("@patient_id", SqlDbType.VarChar) { Value = elm[idx_patient_id] },
					new SqlParameter("@measure_date", SqlDbType.DateTime) { Value = parseDateTimeOrDBNull(elm[idx_measure_date]) },
					new SqlParameter("@seq_no", SqlDbType.Int) { Value = parseIntOrDBNull(elm[idx_seq_no]) },
					new SqlParameter("@with_seqno", SqlDbType.SmallInt) { Value = parseShortOrDBNull(elm[idx_with_seqno]) },
					new SqlParameter("@medical_history", SqlDbType.VarChar) { Value = medical_history },
				};

				if (!fnc.sqlUpdate(sql.ToString(), param)) LogGW(hospId, err, MSG_ERR_SET_DB, sql.ToString().PadRight(400, ' ').Substring(0, 400).TrimEnd()); //LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_taking_medicines");

				SetProcessedStatus(hospId, msgUid, total, i, false);  // false = start以外
			}

			//LogGW(hospId, "[SetTableTakingMedicinesRenkeiData] ret = true;");
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetTableTakingMedicinesRenkeiData() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

    /// <summary>
    /// 外字チェック
    /// 20180411 yamada add ver2.2管理表No:024
    /// </summary>
    /// <param name="instr"></param>
    /// <returns>0:外字なし,1:外字あり,-1:エラー</returns>
    private int ChkGaiji(string instr)
    {
        int ret = 0;
        try
        {
            string wideString = Strings.StrConv(instr, VbStrConv.Wide, _LCID);

            for (int i = 1; i <= wideString.Length ; i++)
            {
                //文字を列からUTF8のバイト列に変換
                byte[] data = Encoding.GetEncoding("Shift_JIS").GetBytes(Strings.Mid(wideString, i, 1));
                //LogGW("-", false, "moji[{0}]",Strings.Mid(wideString, i, 1));
                //16進数に変換
                string hexText = BitConverter.ToString(data).Replace("-","");
                //LogGW("-", false, hexText);


                //漢字コード判定
                if ((string.Compare(hexText, "8140") >= 0 && string.Compare(hexText, "8147") <= 0) ||
                    (string.Compare(hexText, "8149") >= 0 && string.Compare(hexText, "81FC") <= 0) ||
                    (string.Compare(hexText, "824F") >= 0 && string.Compare(hexText, "829A") <= 0) ||
                    (string.Compare(hexText, "829F") >= 0 && string.Compare(hexText, "82F1") <= 0) ||
                    (string.Compare(hexText, "8340") >= 0 && string.Compare(hexText, "8396") <= 0) ||
                    (string.Compare(hexText, "839F") >= 0 && string.Compare(hexText, "83D6") <= 0) ||
                    (string.Compare(hexText, "8440") >= 0 && string.Compare(hexText, "8491") <= 0) ||
                    (string.Compare(hexText, "849F") >= 0 && string.Compare(hexText, "84BE") <= 0) ||
                    (string.Compare(hexText, "889F") >= 0 && string.Compare(hexText, "9872") <= 0) ||
                    (string.Compare(hexText, "989F") >= 0 && string.Compare(hexText, "EAA2") <= 0))
                {
                    //漢字の場合は何もしない
                }
                else
                {
                    //外字判定の場合
                    ret = 1;
                    break;
                }

            }

        }
        catch (Exception ex)
        {
            LogGW("-", err, "例外発生：ChkGaiji() {0}", ex.ToString());
            ret = -1;
        }
        return ret;
    }




    /// <summary>
    /// 
    /// </summary>
    /// <param name="hospId"></param>
    /// <param name="patientId"></param>
    /// <param name="orgPatientId"></param>
    /// <returns></returns>
    private bool UpdatePatientTable(string hospId, string patientId, string orgPatientId)
	{
		bool ret = true;
		string sql = "";
		string sqlTemplate = "update {0} set patient_id='{1}' where hosp_id='{2}' and patient_id='{3}'";
		string[] dbTables = new[] { "tbl_coop_hosp", "tbl_coop_info", "tbl_home_cure", "tbl_improve", "tbl_improve_detail",
									"tbl_improve_plan", "tbl_improve_done", "tbl_improve_do_detail", "tbl_med_explain", "tbl_med_info",
									"tbl_first_visit", "tbl_first_visit_state", "tbl_patient_image", "tbl_plan" ,
									"tbl_guide_dh", "tbl_guide_plan", "tbl_platform",
									"tbl_visit_schedule", "tbl_visit_time"	};

		try
		{
			App_Function fnc = new App_Function();
			for (int i = 0; i < dbTables.Length; i++)
			{
				sql = string.Format(sqlTemplate, dbTables[i], patientId, hospId, orgPatientId);
				if (!fnc.sqlUpdate(sql)) LogGW(hospId, err, MSG_ERR_SET_DB, sql);
			}
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：UpdatePatientTable() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}


	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="lines"></param>
	/// <returns></returns>
	private bool SetTablePatientDelete(string hospId, string[] lines)
	{
		bool ret = false;
		string sql = "";
		DataTable dt;

		// CSVデータのインデックス番号
		const int idx_id=1-1;

		string sqlTemplate = "delete from {0} where hosp_id='{1}' and patient_id='{2}'";
		string[] dbTables = new[] { "tbl_patient", "tbl_patient_visit", 
									"tbl_coop_hosp", "tbl_coop_info", "tbl_home_cure", "tbl_improve", "tbl_improve_detail",
									"tbl_improve_plan", "tbl_improve_done", "tbl_improve_do_detail", "tbl_med_explain", "tbl_med_info",
									"tbl_first_visit", "tbl_first_visit_state", "tbl_patient_image", "tbl_plan" ,
									"tbl_guide_dh", "tbl_guide_plan", "tbl_platform",
									"tbl_visit_schedule", "tbl_visit_time" };

		try
		{
			App_Function fnc = new App_Function();

			for (int i = 0; i < lines.Length; i++)
			{
				// 1行目、"END"行は保存しない
				if (i == 0) continue;
				if (EndMark.CompareTo(lines[i]) == 0) break;

                //20180413 yamada update /S ユニット病棟コードが追加のためサイズ追加
                //ver2.2管理表No:038

                //string[] elm = elms(lines[i], 16);
                string[] elm = elms(lines[i], 19);
                //20180413 yamada update /E

                if (EndMark.CompareTo(elm[0]) == 0) break;

                //20180411 yamada add /S 処理中の患者ＩＤ、患者氏名をログに出力する
                //ver2.2管理表No:019

                //患者削除データ：医院ID「{0}」患者ID「{1}」
                LogGW(hospId, "患者削除データ：医院ID「{0}」患者ID「{1}」", hospId,elm[idx_id]);
                //20180411 yamada add /E

                for (int j = 0; j < dbTables.Length; j++)
				{
					sql = string.Format(sqlTemplate, dbTables[j], hospId, elm[idx_id]);
					if (!fnc.sqlDelete(sql))
					{
						LogGW(hospId, err, MSG_ERR_SET_DB, sql);
					}
				}
			}
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：SetTablePatientDelete() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="patientId"></param>
	/// <returns></returns>
	private bool PatientDelete(string hospId, string patientId)
	{
		bool ret = false;
		string sql = "";

		string sqlTemplate = "delete from {0} where hosp_id='{1}' and patient_id='{2}'";
		string[] dbTables = new[] { "tbl_patient", "tbl_patient_visit",
									"tbl_coop_hosp", "tbl_coop_info", "tbl_home_cure", "tbl_improve", "tbl_improve_detail",
									"tbl_improve_plan", "tbl_improve_done", "tbl_improve_do_detail", "tbl_med_explain", "tbl_med_info",
									"tbl_first_visit", "tbl_first_visit_state", "tbl_patient_image", "tbl_plan" ,
									"tbl_guide_dh", "tbl_guide_plan", "tbl_platform",
									"tbl_visit_schedule", "tbl_visit_time" };

		try
		{
			App_Function fnc = new App_Function();

			for (int j = 0; j < dbTables.Length; j++)
			{
				sql = string.Format(sqlTemplate, dbTables[j], hospId, patientId);
				if (!fnc.sqlDelete(sql))
				{
					LogGW(hospId, err, MSG_ERR_SET_DB, sql);
				}
			}
			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：PatientDelete() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="msgUid"></param>
	/// <returns></returns>
	private string UserId(string msgUid)
	{
		string ret = "";

		try
		{
			string sql = string.Format("select user_id from tbl_data_set_flg where msg_uid='{0}'", msgUid);
			App_Function fnc = new App_Function();
			ret = fnc.sqlSelect(sql, "user_id");
		}
		catch { }

		return ret;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="fileName"></param>
	/// <param name="err"></param>
	/// <param name="msgUid"></param>
	/// <returns></returns>
	private bool MoveFileSend(string hospId, string fileName, bool err, string msgUid)
	{
		bool ret = false;
		string baseDir = "";
		string destPath = "";
		string[] elms = fileName.Split('_');

		try
		{
			if (err) baseDir = ConfigurationManager.AppSettings["err_folder"];
			else baseDir = ConfigurationManager.AppSettings["done_folder"];

			// 例) err\20170525\hosp1\Send
			destPath = string.Format(@"{0}\{1}\{2}\Send", baseDir, elms[1], hospId);

			App_Function fnc = new App_Function();
			string sql = string.Format("select * from tbl_data_set_flg where msg_uid='{0}'", msgUid);
			string path = fnc.sqlSelect(sql, "file_path");

			bool create = false;
			if(!Directory.Exists(destPath))
			{
				//LogDBG(hospId, "パス無しなので作成({0})", destPath);
				try
				{
					Directory.CreateDirectory(destPath);
				}
				catch (Exception ex)
				{
					err = true;
					LogGW(hospId, err, ex.Message);
					LogGW(hospId, err, MSG_ERR_CREATE_FOLDER, destPath);
				}
			}

			ret = util.MoveFile(Path.Combine(path, fileName), destPath, create);

			CleanUpDirectory(hospId);
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：MoveFileSend() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="fileName"></param>
	/// <param name="err"></param>
	/// <param name="byteArray"></param>
	/// <returns></returns>
	private bool MoveFileRecv(string hospId, string fileName, bool err, byte[] byteArray)
	{
		bool ret = false;
		string baseDir = "";
		string destPath = "";
		string[] elms = fileName.Split('_');

		try
		{
			if (err) baseDir = ConfigurationManager.AppSettings["err_folder"];
			else baseDir = ConfigurationManager.AppSettings["done_folder"];

			// 例) err\20170525\hosp1\Recv
			destPath = string.Format(@"{0}\{1}\{2}\Recv", baseDir, elms[2].Substring(0,8), hospId);

			//string dbg_path = @"//wyfile01.file.core.windows.net/wyfiledev01/aa";
			//try
			//{
			//	Directory.CreateDirectory(dbg_path);
			//}
			//catch (Exception ex)
			//{
			//	string aa = string.Format("path[{0}] err[{1}]", dbg_path, ex.Message);
			//	LogGW(hospId, err, ex.Message);
			//}

			if (!Directory.Exists(destPath))
			{
				//LogDBG(hospId, "パス無しなので作成({0})", destPath);
				try
				{
					Directory.CreateDirectory(destPath);
				}
				catch(Exception ex)
				{
					err = true;
					LogGW(hospId, err, ex.Message);
					LogGW(hospId, err, MSG_ERR_CREATE_FOLDER, destPath);
				}
			}

			// 対象フォルダにファイルを作成
			string fullPath = Path.Combine(destPath, fileName);
			if (!util.ByteArrayToFile(byteArray, fullPath))
			{
				LogGW(hospId, MSG_ERR_MOVE_FILE, fileName);
			}

			//string msg = "";
			//if (err) msg = "エラーフォルダ"; else msg = "実行済みフォルダ";

			CleanUpDirectory(hospId);
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：MoveFileRecv() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="hospId"></param>
	public void CleanUpDirectory(string hospId)
	{
		try
		{
			string doneDir = ConfigurationManager.AppSettings["err_folder"];
			string errDir = ConfigurationManager.AppSettings["done_folder"];

			string days = ConfigurationManager.AppSettings["storage_days"];
			string lastDirName = "";

			int storageDays = util.ToInt(ConfigurationManager.AppSettings["storage_days"]);

			string[] dirs = Directory.GetDirectories(doneDir);
			foreach (string dir in dirs)
			{
				try
				{
					lastDirName = Path.GetFileName(dir);
					DateTime createDate = DateTime.ParseExact(lastDirName, "yyyyMMdd", CultureInfo.InvariantCulture);

					if (createDate.AddDays(storageDays) <= DateTime.Now)
					{
						try
						{
							Directory.Delete(dir, true);
						}
						catch { }   // 無処理
					}
				}
				catch { }	// 無処理
			}

			dirs = Directory.GetDirectories(errDir);
			foreach (string dir in dirs)
			{
				try
				{
					lastDirName = Path.GetFileName(dir);
					DateTime createDate = DateTime.ParseExact(lastDirName, "yyyyMMdd", CultureInfo.InvariantCulture);

					if (createDate.AddDays(storageDays) <= DateTime.Now)
					{
						try
						{
							Directory.Delete(dir, true);
						}
						catch { }   // 無処理
					}
				}
				catch { }   // 無処理
			}
		}
		catch (Exception ex)
		{
			// 無処理
		}

	}

	/// <summary>
	/// 電カルからのデータ(1行文字列)が期待する要素数に満たない場合に""設定して返却する
	///		要素のインデックス境界エラーの抑止をおこなう
	/// </summary>
	/// <param name="line"></param>
	/// <param name="max"></param>
	/// <returns></returns>
	private string[] elms(string line, int max)
	{
		int maxWk = max;
		string[] array = line.Split(',');

		if (array.Length == max) return array;
		else
		{
			if (max < array.Length) maxWk = array.Length;
            //20180323 yamada update /S バグ修正
            //string[] array2 = new string[max];       
            string[] array2 = new string[maxWk];
            //20180323 /E
            for (int i = 0; i < array2.Length; i++) array2[i] = "";
			for (int i = 0; i < array.Length; i++)
			{
				if(array.Length >= i) array2[i] = array[i];
			}
			return array2;
		}
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="date"></param>
	/// <param name="format"></param>
	/// <param name="days"></param>
	/// <returns></returns>
	private string AddDaysString(string date, string format, int days)
	{
		DateTime dt = DateTime.ParseExact(date, format, CultureInfo.InvariantCulture).AddDays(days);
		return dt.ToString(format);
	}

	/// <summary>
	/// GWの通常ログ
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="err"></param>
	/// <param name="logStr"></param>
	private void LogGW(string hospId, bool err,  string logStr)
	{
		int errSet = 0;
		if (err) errSet = 1;

		try
		{
            //20180416 yamada add /S サーバIPアドレス取得
            //ver2.2管理表No:047

            IPAddress[] lIp = Dns.GetHostAddresses(Dns.GetHostName());
            string ipaddress = "";
            // IPv4を抽出する必要がある
            foreach (var iIp in lIp)
            {
                if (iIp.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    ipaddress = iIp.ToString();
                }
            }

            ////ドメイン名で出力するようにしてみる
            //string ipaddress = "";
            //string[] domainname = System.Web.HttpContext.Current.Request.ServerVariables.GetValues("SERVER_NAME");
            //if (domainname.Length > 0)
            //{
            //    ipaddress = domainname[0];
            //}

            //20180416 yamada add /E



            string logStrWork2 = logStr.Replace("'", "/");
			App_Function fnc2 = new App_Function();

            //20180416 yamada update /S サーバIPアドレス取得
            //ver2.2管理表No:047

            //string sql2 = string.Format(@"insert into gw_server_log values ('{0}','{1}', {2}, '{3}')", hospId, DateTime.Now, errSet, logStrWork2);
            string sql2 = string.Format(@"insert into gw_server_log values ('{0}','{1}', {2}, '{3}','{4}')", hospId, DateTime.Now, errSet, logStrWork2, ipaddress);
            //20180416 yamada update /E

            fnc2.sqlInsert(sql2);


		}
		catch (Exception ex)
        {

        }
	}

	/// <summary>
	/// GWの通常ログ(フォーマット指定有り)
	///		string.Formatの指定が可能  例) LogGW(hospId, "{0},{1}", str1, str2)
	/// </summary>
	/// <param name="hospId"></param>
	/// <param name="err"></param>
	/// <param name="format"></param>
	/// <param name="arg"></param>
	private void LogGW(string hospId, bool err, string format, params object[] arg)
	{
		string logStr = string.Format(format, arg);
		LogGW(hospId, err, logStr);
	}
	private void LogGW(string hospId, string logStr) { LogGW(hospId, false, logStr); }
	private void LogErr(string hospId, string logStr) { LogGW(hospId, true, logStr); }
	private void LogGW(string hospId, string format, params object[] arg) { LogGW(hospId, false, format, arg); }

	private void LogDBG(string hospId, bool err, string logStr)
	{
		App_Function fnc = new App_Function();

		string sql = "select * from gw_dbg_flg where flg = 1";
		if((fnc.sqlSelect(sql, "flg").Length) != 0)
		{
			LogGW(hospId, err, "..."+logStr);
		}
	}
	private void LogDBG(string hospId, string format, params object[] arg)
	{
		string logStr = string.Format(format, arg);
		LogDBG(hospId, false, logStr);
	}

	public string GetData(int value)
	{
		return string.Format("You entered: {0}", value);
	}

	public CompositeType GetDataUsingDataContract(CompositeType composite)
	{
		if (composite == null)
		{
			throw new ArgumentNullException("composite");
		}
		if (composite.BoolValue)
		{
			composite.StringValue += "Suffix";
		}
		return composite;
	}

	//2020.01.28 add
	private bool ContactWithYouDataKInputList(string hospId, string ipAddress, ref string msgUid, ref int fileCount, ref string fileNames)
	{
		bool ret = false;
		//fileCount = 0;
		fileCount = -1;
		fileNames = "";

		const string sql_template = "select d.* from tbl_data_set_flg d " +
			"where d.set_status&{0}={0} and d.hosp_id = '{1}' and d.data_type = '2' order by d.set_time desc";

		string sql_template_upd = "update tbl_data_set_flg set set_status = '{2}' " +
			"where hosp_id = '{1}' " +
			"and set_status&{0}={0} " +
			"and set_time < '{3}' " +
			"and data_type = '2' ";

		try
		{
			//LogGW(hospId, "[ContactWithYouDataKInputList]");

			if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認

			// フラグ確認
			App_Function fnc = new App_Function();
			string sql = string.Format(sql_template
				, (int)eStatus.Active
				, hospId);

			var dt = new DataTable();
			ret = fnc.sqlSelectTable(sql, ref dt);
			//if (dt.Rows.Count == 0) return false;
			if (dt.Rows.Count == 0) return true;

			var data_set_flg = new {
				set_time = dt.Rows[0].Field<DateTime>("set_time"),
				file_path = dt.Rows[0].Field<string>("file_path"),
				msg_uid = dt.Rows[0].Field<string>("msg_uid"),
			};

			//訪問日一覧
			var visitDates = dt.AsEnumerable()
				.Select(s => s.Field<string>("file_path"))
				.Where(p => !string.IsNullOrEmpty(p) && Regex.IsMatch(p, @"\d{8}$"))
				.Select(s => Regex.Match(s, @"\d{8}$").Value.Insert(6, "-").Insert(4, "-"))
				.Distinct()
				.OrderBy(ks => ks)
				.ToArray();

			//同医院、同訪問日の過去データを無効にする
			//eStatus.Normal
			// 状態、Normal
			// 正常終了を設定
			sql = string.Format(sql_template_upd
				, (int)eStatus.Active
				, hospId
				, (int)eStatus.Normal
				, data_set_flg.set_time);

			if (!fnc.sqlUpdate(sql))
			{
				LogGW(hospId, err, MSG_ERR_SET_DB, "tbl_data_set_flg");
				return false;
			}

			//CSV出力
			var lFileNames = new List<string>();
			foreach (var visitDate in visitDates)
			{
				//データ取得
				sql = "";
				sql += "select ";
				sql += "  p.visit_date ";
				sql += "  , p.patient_id ";
				sql += "  , p2.patient_name ";
				sql += "  , p2.patient_kana ";
				sql += "  , vs.visit_config ";

				//sql += "  , v.visit_name ";
				sql += "  , case ";
				sql += "      when pv.visit_id is null or pv.visit_id =''";
				sql += "        then '訪問先区分のみ登録：' + (select vk.kbn_name from mst_visit_kbn vk where vk.visit_kbn = pv.visit_kbn)";
				sql += "      when pv.visit_id is not null";
				sql += "        then v.visit_name";
				sql += "    end visit_name";

				sql += "  , u.unit_name ";

				sql += "  , case when IsNull(dr.localuser_scrn,'') ='' then ";
				sql += "    vs.dr_id else p.dr_id end dr_id ";
				sql += "  , case when IsNull(dr.localuser_scrn,'') ='' then ";
				sql += "    dr2.localuser_scrn else dr.localuser_scrn end dr_name ";
				sql += "  , case when IsNull(spdh.localuser_scrn,'') ='' then";
				sql += "    vs.support_dh_id else p.support_dh_id end support_dh_id ";
				sql += "  , case when IsNull(spdh.localuser_scrn,'') ='' then";
				sql += "    spdh2.localuser_scrn else spdh.localuser_scrn end support_dh_name";
				sql += "  , case when IsNull(dh.localuser_scrn,'') ='' then";
				sql += "    vs.dh_id else p.dh_id end dh_id ";
				sql += "  , case when IsNull(dh.localuser_scrn,'') ='' then";
				sql += "    dh2.localuser_scrn else dh.localuser_scrn end dh_name";

				//sql += "  , dr.localuser_scrn dr_name ";
				//sql += "  , spdh.localuser_name support_dh_name ";
				//sql += "  , dh.localuser_name dh_name ";

				//sql += "  , p.dr_start ";
				sql += "  , case ";
				sql += "    when Isnull(p.dr_start, '') <> '' ";
				sql += "      then p.dr_start ";
				sql += "    else vs.dr_start ";
				sql += "    end dr_start ";
				//sql += "  , p.dr_end ";
				sql += "  , case ";
				sql += "    when Isnull(p.dr_end, '') <> '' ";
				sql += "      then p.dr_end ";
				sql += "    else vs.dr_end ";
				sql += "    end dr_end ";

				//sql += "  , case p.dr_min ";
				//sql += "    when 0 then null ";
				//sql += "    else p.dr_min end dr_min ";
				sql += "  , case ";
				sql += "    when p.dr_min = 0 ";
				sql += "    or p.dr_min is null ";
				sql += "      then case vs.dr_min ";
				sql += "      when 0 then null ";
				sql += "      else vs.dr_min ";
				sql += "      end ";
				sql += "    else case p.dr_min ";
				sql += "      when 0 then null ";
				sql += "      else p.dr_min ";
				sql += "      end ";
				sql += "    end dr_min ";

				//sql += "  , p.dh_start ";
				sql += "  , case ";
				sql += "    when Isnull(p.dh_start, '') <> '' ";
				sql += "      then p.dh_start ";
				sql += "    else vs.dh_start ";
				sql += "    end dh_start ";

				//sql += "  , p.dh_end ";
				sql += "  , case ";
				sql += "    when Isnull(p.dh_end, '') <> '' ";
				sql += "      then p.dh_end ";
				sql += "    else vs.dh_end ";
				sql += "    end dh_end ";

				//sql += "  , case p.dh_min ";
				//sql += "    when 0 then null ";
				//sql += "    else p.dh_min end dh_min ";
				sql += "  , case ";
				sql += "    when p.dh_min = 0 ";
				sql += "    or p.dh_min is null ";
				sql += "      then case vs.dh_min ";
				sql += "      when 0 then null ";
				sql += "      else vs.dh_min ";
				sql += "      end ";
				sql += "    else case p.dh_min ";
				sql += "      when 0 then null ";
				sql += "      else p.dh_min ";
				sql += "      end ";
				sql += "    end dh_min ";

				sql += "  , '0' state_code ";

				sql += "  , case ";
				sql += "      when pv.visit_id is null or pv.visit_id =''";
				sql += "        then '0000000000' + pv.visit_kbn";
				sql += "      when pv.visit_id is not null";
				sql += "        then pv.visit_id";
				sql += "    end visit_id";
				sql += "  , pv.visit_unit ";
				sql += "  , case when v.index_no is null then '99999' else v.index_no end index_no_v";
				sql += "  , u.index_no index_no_u ";
				sql += "  , case IsNull(p.dr_start, '') ";
				sql += "    when '' then IsNull(p.dh_start,'') ";
				sql += "    else IsNull(p.dr_start,'') ";
				sql += "    end start_time ";
				sql += "  , isnull(convert(varchar, v.number_of_house), '') as number_of_house ";
				sql += "  , pv.visit_kbn ";
				sql += "  , min.minTime ";
				sql += "  , '0' performance ";
				sql += "  , '0' convinience ";

				sql += "  , case when Isnull(p.dr_id, '') <> '' then '0' else vs.state_code  end dr_state ";
				sql += "  , case when Isnull(p.dh_id, '') <> '' then '0' else vs.state_code  end dh_state ";

				sql += "from ";
				sql += "  tbl_platform p ";
				sql += "  left outer join tbl_visit_schedule vs ";
				sql += "    on p.hosp_id = vs.hosp_id ";
				sql += "    and p.visit_date = vs.visit_date ";
				sql += "    and p.patient_id = vs.patient_id ";
				sql += "    and p.dr_id != vs.dr_id ";
				sql += "  left outer join mst_local_user dr2 ";
				sql += "    on vs.hosp_id = dr2.hosp_id ";
				sql += "    and vs.dr_id = dr2.localuser_id ";
				sql += "    and dr2.job_id = '3' ";
				sql += "  left outer join mst_local_user spdh2 ";
				sql += "    on vs.hosp_id = spdh2.hosp_id ";
				sql += "    and vs.support_dh_id = spdh2.localuser_id ";
				sql += "    and spdh2.job_id = '4' ";
				sql += "  left outer join mst_local_user dh2 ";
				sql += "    on vs.hosp_id = dh2.hosp_id ";
				sql += "    and vs.dh_id = dh2.localuser_id ";
				sql += "    and dh2.job_id = '4'";
				sql += "  left outer join tbl_patient p2 ";
				sql += "    on p.hosp_id = p2.hosp_id ";
				sql += "    and p.patient_id = p2.patient_id ";
				sql += "  left outer join tbl_patient_visit pv ";
				sql += "    on p2.hosp_id = pv.hosp_id ";
				sql += "    and p2.patient_id = pv.patient_id ";
				sql += "  left outer join mst_visit v ";
				sql += "    on pv.hosp_id = v.hosp_id ";
				sql += "    and pv.visit_id = v.visit_id ";
				sql += "    and v.mask = '0' ";
				sql += "  left outer join mst_visit_unit u ";
				sql += "    on pv.hosp_id = u.hosp_id ";
				sql += "    and pv.visit_id = u.visit_id ";
				sql += "    and pv.visit_unit = u.visit_unit ";
				sql += "    and u.mask = '0' ";
				sql += "  left outer join mst_local_user dr ";
				sql += "    on p.hosp_id = dr.hosp_id ";
				sql += "    and p.dr_id = dr.localuser_id ";
				sql += "    and dr.job_id = '3' ";
				sql += "  left outer join mst_local_user spdh ";
				sql += "    on p.hosp_id = spdh.hosp_id ";
				sql += "    and p.support_dh_id = spdh.localuser_id ";
				sql += "    and spdh.job_id = '4' ";
				sql += "  left outer join mst_local_user dh ";
				sql += "    on p.hosp_id = dh.hosp_id ";
				sql += "    and p.dh_id = dh.localuser_id ";
				sql += "    and dh.job_id = '4' ";
				sql += "  , ( ";
				sql += "      select ";
				sql += "        p.visit_date ";
				sql += "        , case ";
				sql += "            when pv.visit_id is null or pv.visit_id =''";
				sql += "              then '0000000000' + pv.visit_kbn";
				sql += "            when pv.visit_id is not null";
				sql += "              then pv.visit_id";
				sql += "          end visit_id";
				sql += "        , IsNull(pv.visit_unit, '') visit_unit ";
				sql += "        , min(  ";
				sql += "          case  ";
				sql += "            when Isnull(p.dr_start, '') != '' ";
				sql += "              then p.dr_start ";
				sql += "            when Isnull(p.dh_start, '') != '' ";
				sql += "              then p.dh_start ";
				sql += "            end ";
				sql += "        ) minTime ";
				sql += "      from ";
				sql += "        (select hosp_id,patient_id,dr_start,dh_start,visit_date ";
				sql += "          from tbl_platform where mask = '0' ";
				sql += string.Format("          and hosp_id = '{0}' ", hospId);
				sql += string.Format("          and visit_date = '{0}' ", visitDate);
				sql += "          union ";
				sql += "          select hosp_id,patient_id,dr_start,dh_start,visit_date ";
				sql += "          from tbl_visit_schedule where state_code in ('1','3') ";
				sql += string.Format("          and hosp_id = '{0}' ", hospId);
				sql += string.Format("          and visit_date = '{0}' ", visitDate);
				sql += "        ) p ";
				sql += "        left outer join tbl_patient p2 ";
				sql += "          on p.hosp_id = p2.hosp_id ";
				sql += "          and p.patient_id = p2.patient_id ";
				sql += "        left outer join tbl_patient_visit pv ";
				sql += "          on p2.hosp_id = pv.hosp_id ";
				sql += "          and p2.patient_id = pv.patient_id ";
				sql += "      group by ";
				sql += "        p.visit_date ";
				sql += "        , pv.visit_kbn ";
				sql += "        , pv.visit_id ";
				sql += "        , pv.visit_unit ";
				sql += "    ) min ";

				sql += "where ";

				sql += string.Format("   p.visit_date = '{0}' ", visitDate);
				sql += string.Format("  and p.hosp_id = '{0}' ", hospId);
				sql += "  and p.mask = '0' ";
				sql += "  and p.visit_date = min.visit_date ";
				sql += "  and case ";
				sql += "      when pv.visit_id is null or pv.visit_id =''";
				sql += "        then '0000000000' + pv.visit_kbn";
				sql += "      when pv.visit_id is not null";
				sql += "        then pv.visit_id";
				sql += "      end = min.visit_id ";
				sql += "  and IsNull(pv.visit_unit, '') = min.visit_unit";
				//if (!string.IsNullOrEmpty(visit_id))
				//{
				//	sql += "  and case ";
				//	sql += "      when pv.visit_id is null or pv.visit_id =''";
				//	sql += "        then '0000000000' + pv.visit_kbn";
				//	sql += "      when pv.visit_id is not null";
				//	sql += "        then pv.visit_id";
				//	sql += "    end in (" + visit_id + ") ";
				//}

				sql += "  union ";
				sql += "select ";
				sql += "  tvs.visit_date ";
				sql += "  , tvs.patient_id ";
				sql += "  , tvs.patient_name ";
				sql += "  , tvs.patient_kana ";
				sql += "  , tvs.visit_config ";

				//sql += "  , tvs.visit_name ";
				sql += "  , case ";
				sql += "      when tvs.visit_id is null or tvs.visit_id =''";
				sql += "        then '訪問先区分のみ登録：' + (select vk.kbn_name from mst_visit_kbn vk where vk.visit_kbn = tvs.visit_kbn2)";
				sql += "      when tvs.visit_id is not null";
				sql += "        then tvs.visit_name";
				sql += "    end visit_name";

				sql += "  , mvu.unit_name ";
				sql += "  , tvs.dr_id ";
				sql += "  , tvs.dr_name ";
				sql += "  , tvs.support_dh_id ";
				sql += "  , tvs.support_dh_name ";
				sql += "  , tvs.dh_id ";
				sql += "  , tvs.dh_name ";
				sql += "  , tvs.dr_start ";
				sql += "  , tvs.dr_end ";
				sql += "  , case tvs.dr_min ";
				sql += "    when 0 then null ";
				sql += "    else tvs.dr_min end dr_min ";
				sql += "  , tvs.dh_start ";
				sql += "  , tvs.dh_end ";
				sql += "  , case tvs.dh_min ";
				sql += "    when 0 then null ";
				sql += "    else tvs.dh_min end dh_min ";
				sql += "  , tvs.state_code ";

				sql += "  , case ";
				sql += "      when tvs.visit_id is null or tvs.visit_id =''";
				sql += "        then '0000000000' + tvs.visit_kbn2";
				sql += "      when tvs.visit_id is not null";
				sql += "        then tvs.visit_id";
				sql += "    end visit_id";

				sql += "  , mvu.visit_unit ";
				sql += "  , case when tvs.index_no_v is null then '99999' else tvs.index_no_v end index_no_v";
				sql += "  , mvu.index_no index_no_u ";
				sql += "  , tvs.start_time ";
				sql += "  , tvs.number_of_house ";
				sql += "  , tvs.visit_kbn ";
				sql += "  , min.minTime ";
				sql += "  , '1' performance ";
				sql += "  , case tvs.state_code when 3 then 1 else 0 end convinience ";

				sql += "  , tvs.state_code dr_state ";
				sql += "  , tvs.state_code dh_state ";

				sql += "from ";
				sql += "  ( ";
				sql += "    select ";
				sql += "      v.patient_id ";
				sql += "      , v.visit_date ";
				sql += "      , p.patient_name ";
				sql += "      , p.patient_kana ";
				sql += "      , m.visit_name ";
				sql += "      , v.dr_id ";
				sql += "      , u.localuser_scrn as dr_name ";
				sql += "      , v.support_dh_id ";
				sql += "      , u3.localuser_scrn as support_dh_name ";
				sql += "      , v.dh_id ";
				sql += "      , u2.localuser_scrn as dh_name ";
				sql += "      , v.dr_start ";
				sql += "      , v.dr_end ";
				sql += "      , v.dr_min ";
				sql += "      , v.dh_start ";
				sql += "      , v.dh_end ";
				sql += "      , v.dh_min ";
				sql += "      , state_code ";
				sql += "      , pv.visit_id ";
				sql += "      , m.index_no index_no_v ";
				sql += "      , case IsNull(v.dr_start, '')";
				sql += "        when '' then IsNull(v.dh_start,'') ";
				sql += "        else IsNull(v.dr_start,'') ";
				sql += "        end start_time ";
				sql += "      , isnull(convert(varchar, m.number_of_house), '') as number_of_house ";
				sql += "      , pv.visit_kbn ";
				sql += "      , pv.visit_kbn visit_kbn2 ";
				sql += "      , v.hosp_id ";
				sql += "      , v.visit_config ";
				sql += "    from ";
				sql += "      tbl_patient p ";
				sql += "      , tbl_visit_config c ";
				sql += "      , tbl_visit_schedule v ";
				sql += "      left outer join tbl_patient_visit pv ";
				sql += "        on v.hosp_id = pv.hosp_id ";
				sql += "        and v.patient_id = pv.patient_id ";
				sql += "      left outer join mst_visit m ";
				sql += "        on pv.visit_id = m.visit_id ";
				sql += "        and m.hosp_id = pv.hosp_id ";
				sql += "      left outer join mst_local_user u ";
				sql += "        on v.dr_id = u.localuser_id ";
				sql += "        and v.hosp_id = u.hosp_id ";
				sql += "        and u.job_id = '3' ";
				sql += "      left outer join mst_local_user u3 ";
				sql += "        on v.support_dh_id = u3.localuser_id ";
				sql += "        and v.hosp_id = u3.hosp_id ";
				sql += "        and u3.job_id = '4' ";
				sql += "      left outer join mst_local_user u2 ";
				sql += "        on v.dh_id = u2.localuser_id ";
				sql += "        and v.hosp_id = u2.hosp_id ";
				sql += "        and u2.job_id = '4' ";
				sql += "    where ";
				sql += string.Format("      v.hosp_id = '{0}' ", hospId);
				sql += string.Format("      and v.visit_date = '{0}' ", visitDate);
				sql += "      and v.state_code in ('1', '3') ";
				sql += "      and v.hosp_id = p.hosp_id ";
				sql += "      and v.patient_id = p.patient_id ";
				sql += "      and v.hosp_id = c.hosp_id ";
				sql += "      and v.visit_config = c.visit_config ";
				sql += "  ) tvs ";
				sql += "  , tbl_patient_visit pv ";
				sql += "  left outer join mst_visit_unit mvu ";
				sql += "    on pv.hosp_id = mvu.hosp_id ";
				sql += "    and pv.visit_id = mvu.visit_id ";
				sql += "    and pv.visit_unit = mvu.visit_unit ";
				sql += "  , ( ";
				sql += "      select ";
				sql += "        v.visit_date ";
				sql += "        , case ";
				sql += "            when pv.visit_id is null or pv.visit_id =''";
				sql += "              then '0000000000' + pv.visit_kbn";
				sql += "            when pv.visit_id is not null";
				sql += "              then pv.visit_id";
				sql += "          end visit_id";
				sql += "        , IsNull(pv.visit_unit, '') visit_unit ";
				sql += "        , min( ";
				sql += "          case ";
				sql += "            when Isnull(v.dr_start, '') != '' ";
				sql += "              then v.dr_start ";
				sql += "            when Isnull(v.dh_start, '') != '' ";
				sql += "              then v.dh_start ";
				sql += "            end ";
				sql += "        ) minTime ";
				sql += "      from ";
				sql += "        (select hosp_id,patient_id,dr_start,dh_start,visit_date ";
				sql += "          from tbl_platform where mask= '0' ";
				sql += string.Format("          and hosp_id = '{0}' ", hospId);
				sql += string.Format("          and visit_date = '{0}' ", visitDate);
				sql += "          union ";
				sql += "          select hosp_id,patient_id,dr_start,dh_start,visit_date ";
				sql += "          from tbl_visit_schedule where state_code in ('1','3') ";
				sql += string.Format("          and hosp_id = '{0}' ", hospId);
				sql += string.Format("          and visit_date = '{0}' ", visitDate);
				sql += "        ) v ";
				sql += "        left outer join tbl_patient p ";
				sql += "          on v.hosp_id = p.hosp_id ";
				sql += "          and v.patient_id = p.patient_id ";
				sql += "        left outer join tbl_patient_visit pv ";
				sql += "          on p.hosp_id = pv.hosp_id ";
				sql += "          and p.patient_id = pv.patient_id ";
				sql += "      group by ";
				sql += "        v.visit_date ";
				sql += "        , pv.visit_kbn ";
				sql += "        , pv.visit_id ";
				sql += "        , pv.visit_unit ";
				sql += "    ) min ";
				sql += "where ";
				sql += "  tvs.hosp_id = pv.hosp_id ";
				sql += "  and tvs.visit_date = min.visit_date ";
				sql += "  and case ";
				sql += "      when tvs.visit_id is null or tvs.visit_id =''";
				sql += "        then '0000000000' + tvs.visit_kbn2";
				sql += "      when tvs.visit_id is not null";
				sql += "        then tvs.visit_id";
				sql += "      end  = min.visit_id ";
				sql += "  and IsNull(mvu.visit_unit, '') = min.visit_unit ";
				sql += "  and tvs.patient_id = pv.patient_id ";
				sql += "  and tvs.visit_date between pv.start_date and pv.end_date ";
				sql += "  and tvs.patient_id not in ";
				sql += "    (select patient_id ";
				sql += "      from tbl_platform ";
				sql += string.Format("      where hosp_id = '{0}' ", hospId);
				sql += string.Format("      and visit_date = '{0}' ", visitDate);
				sql += "      and mask = '0') ";
				//if (!string.IsNullOrEmpty(visit_id))
				//{
				//	sql += "  and case ";
				//	sql += "      when pv.visit_id is null or pv.visit_id =''";
				//	sql += "        then '0000000000' + pv.visit_kbn";
				//	sql += "      when pv.visit_id is not null";
				//	sql += "        then pv.visit_id";
				//	sql += "    end in (" + visit_id + ") ";
				//}
				sql += "order by ";
				sql += "  minTime";
				sql += "  , index_no_v  ";
				sql += "  , index_no_u ";
				sql += "  , visit_kbn ";
				sql += "  , convinience ";
				sql += "  , start_time ";
				sql += "  , performance desc ";
				sql += "  , patient_id asc ";

				dt = new DataTable();
				ret = fnc.sqlSelectTable(sql, ref dt);
				if (dt.Rows.Count == 0) return true;

				#region 2020/02/07 追記

				DataTable dt2 = new DataTable();
				List<string> patient = new List<string>();
				DataRow[] rows = null;
				dt2 = dt.Clone();
				try
				{
					for (int i = 0; i < dt.Rows.Count; i++)
					{
						if (patient.IndexOf(dt.Rows[i]["patient_id"].ToString()) > -1) continue;
						rows = dt.Select("patient_id = '" + dt.Rows[i]["patient_id"].ToString() + "' and visit_config <> '" + dt.Rows[i]["visit_config"].ToString() + "'");
						if (rows.Length > 0)
						{
							if (string.IsNullOrEmpty(dt.Rows[i]["dr_name"].ToString()))
							{
								//DRのデータを設定
								dt.Rows[i]["dr_name"] = rows[0]["dr_name"];
								dt.Rows[i]["support_dh_name"] = rows[0]["support_dh_name"];
								dt.Rows[i]["dr_start"] = rows[0]["dr_start"];
								dt.Rows[i]["dr_end"] = rows[0]["dr_end"];
								dt.Rows[i]["dr_min"] = rows[0]["dr_min"];
								dt.Rows[i]["dr_state"] = rows[0]["dr_state"];
							}
							else if (string.IsNullOrEmpty(dt.Rows[i]["dh_name"].ToString()))
							{
								//DHのデータを設定
								dt.Rows[i]["dh_name"] = rows[0]["dh_name"];
								dt.Rows[i]["dh_start"] = rows[0]["dh_start"];
								dt.Rows[i]["dh_end"] = rows[0]["dh_end"];
								dt.Rows[i]["dh_min"] = rows[0]["dh_min"];
								dt.Rows[i]["dh_state"] = rows[0]["dh_state"];
							}
							dt2.ImportRow(dt.Rows[i]);
						}
						else
						{
							dt2.ImportRow(dt.Rows[i]);
						}
						patient.Add(dt.Rows[i]["patient_id"].ToString());
					}
				}
				catch (Exception ex)
				{
					LogGW(hospId, ex.Message + ':' + ex.StackTrace);
				}

				//「患者都合で診療無し」のときにDr/DH情報削除
				for (int i = 0; i < dt2.Rows.Count; i++)
				{
					if (!DBNull.Value.Equals(dt2.Rows[i]["dr_state"]) && dt2.Rows[i]["dr_state"].ToString() == "3")
					{
						dt2.Rows[i]["dr_id"] = DBNull.Value;
						dt2.Rows[i]["dr_name"] = DBNull.Value;
						dt2.Rows[i]["support_dh_id"] = DBNull.Value;
						dt2.Rows[i]["support_dh_name"] = DBNull.Value;
						dt2.Rows[i]["dr_start"] = DBNull.Value;
						dt2.Rows[i]["dr_end"] = DBNull.Value;
						dt2.Rows[i]["dr_min"] = DBNull.Value;
					}
					if (!DBNull.Value.Equals(dt2.Rows[i]["dh_state"]) && dt2.Rows[i]["dh_state"].ToString() == "3")
					{
						dt2.Rows[i]["dh_id"] = DBNull.Value;
						dt2.Rows[i]["dh_name"] = DBNull.Value;
						dt2.Rows[i]["dh_start"] = DBNull.Value;
						dt2.Rows[i]["dh_end"] = DBNull.Value;
						dt2.Rows[i]["dh_min"] = DBNull.Value;
					}
				}
				#endregion


				//var headers = new[] {
				//	"訪問日",
				//	"順番号",
				//	"患者番号",
				//	"患者氏名",
				//	"患者カナ",
				//	"歯科医師コード",
				//	"歯科医師名",
				//	"補助歯科衛生士コード",
				//	"補助歯科衛生士名",
				//	"診療開始時刻",
				//	"診療終了時刻",
				//	"診療時間",
				//	"指導歯科衛生士コード",
				//	"指導歯科衛生士名",
				//	"指導開始時刻",
				//	"指導終了時刻",
				//	"指導時間",
				//	"実績ステータス",
				//	"訪問先名",
				//	"病棟ユニット名",
				//	"戸数",
				//};

				var getStatus = new Func<DataRow, string>(r => {
					if ((r.Field<string>("dr_state") == "0" && r.Field<string>("dh_state") == "0") ||
					(r.Field<string>("dr_state") == "0" && r.Field<string>("dh_state") == "3") ||
					(r.Field<string>("dr_state") == "3" && r.Field<string>("dh_state") == "0") ||
					(r.Field<string>("dr_state") == "0" && string.IsNullOrEmpty(r.Field<string>("dh_state"))) ||
					(r.Field<string>("dh_state") == "0" && string.IsNullOrEmpty(r.Field<string>("dr_state"))))
					{
						return "あり";
					}
					else if (r.Field<string>("dr_state") == "0" && r.Field<string>("dh_state") != "0")
					{
						return "DHなし";
					}
					else if (r.Field<string>("dh_state") == "0" && r.Field<string>("dr_state") != "0")
					{
						return "Drなし";
					}
					else if (r.Field<string>("dr_state") == "3" && r.Field<string>("dh_state") == "3")
					{
						//患者都合でなし
						return "―";
					}
					return "";
				});

				var nullableDateTimeToStringOrEmpty = new Func<DateTime?, string, string>((value, format) => {
					if (value.HasValue) return value.Value.ToString(format);
					return "";
				});

				var nullableIntToStringOrEmpty = new Func<int?, string>(value => {
					if (value.HasValue) return value.Value.ToString();
					return "";
				});

				//var rows = dt.AsEnumerable().Select(s => new [] {
				var rows2 = dt2.AsEnumerable().Select(s => new [] {
					//0訪問日
					nullableDateTimeToStringOrEmpty(s.Field<DateTime?>("visit_date"), "yyyy/MM/dd"),

					//1順番号
					"",

					//2患者番号
					s.Field<string>("patient_id"),

					//3患者氏名
					s.Field<string>("patient_name"),

					//4患者カナ
					s.Field<string>("patient_kana"),

					//5歯科医師コード
					s.Field<string>("dr_id"),

					//6歯科医師名
					s.Field<string>("dr_name"),

					//7補助歯科衛生士コード
					s.Field<string>("support_dh_id"),

					//8補助歯科衛生士名
					s.Field<string>("support_dh_name"),

					//9診療開始時刻
					s.Field<string>("dr_start"),

					//10診療終了時刻
					s.Field<string>("dr_end"),

					//11診療時間
					nullableIntToStringOrEmpty(s.Field<int?>("dr_min")),

					//12指導歯科衛生士コード
					s.Field<string>("dh_id"),

					//13指導歯科衛生士名
					s.Field<string>("dh_name"),

					//14指導開始時刻
					s.Field<string>("dh_start"),

					//15指導終了時刻
					s.Field<string>("dh_end"),

					//16指導時間
					nullableIntToStringOrEmpty(s.Field<int?>("dh_min")),

					//17実績ステータス
					getStatus(s),

					//18訪問先名
					s.Field<string>("visit_name"),

					//19病棟ユニット名
					s.Field<string>("unit_name"),

					//20戸数
					s.Field<string>("number_of_house"),
				});

				//フォルダー作成
				Directory.CreateDirectory(data_set_flg.file_path);

				//CSV出力
				var fileName = string.Format("{0}_{1}_カルテ入力リスト.csv"
					, hospId
					, visitDate.Replace("/", "")
					);
				var filePath = Path.Combine(data_set_flg.file_path, fileName);
				using (var writer = new CsvWriter(filePath))
				{
					//writer.WriteLine(headers);

					//訪問日毎の患者番号
					var patientId = new Dictionary<string, IList<string>>();

					//訪問日毎の順番号
					var junbango = new Dictionary<string, int>();

					foreach (var row in rows2)
					{
						//訪問日毎の患者番号
						if (!patientId.ContainsKey(row[0]))
						{
							patientId[row[0]] = new List<string>();
						}

						//実績ステータスが「患者都合でなし」の場合、
						//同じ患者番号で、既に行があった場合は、この「患者都合でなし」の行のデータを使用しない
						if (row[17] == "―" && patientId[row[0]].Contains(row[2]))
						{
							continue;
						}

						//訪問日毎の患者番号を保持
						if (!patientId[row[0]].Contains(row[2]))
						{
							patientId[row[0]].Add(row[2]);
						}

						//訪問日毎の順番号
						if (!junbango.ContainsKey(row[0]))
						{
							junbango[row[0]] = 0;
						}
						row[1] = (++junbango[row[0]]).ToString();

						writer.WriteLine(row);
					}

					writer.WriteEOF();
				}

				lFileNames.Add(fileName);
			}

			fileCount = lFileNames.Count;
			fileNames = string.Join(",", lFileNames);
			msgUid = data_set_flg.msg_uid;

			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：ContactWithYouDataKInputList() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	//2020.02.04 add
	private bool ContactWithYouDataGeneralDisease(string hospId, string ipAddress, ref string msgUid, ref int fileCount, ref string fileNames)
	{
		bool ret = false;
		//fileCount = 0;
		fileCount = -1;
		fileNames = "";

		const string sql_template = "select d.* from tbl_data_set_flg d " +
			"where d.set_status&{0}={0} and d.hosp_id = '{1}' and d.data_type = '4' order by d.set_time";

		try
		{
			//LogGW(hospId, "[ContactWithYouDataGeneralDisease]");

			if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認

			// フラグ確認
			var WyDB = new App_Function();
			string sql = string.Format(sql_template
				, (int)eStatus.Active
				, hospId);

			var dt = new DataTable();
			ret = WyDB.sqlSelectTable(sql, ref dt);
			//LogGW(hospId, "[ContactWithYouDataGeneralDisease] dt.Rows.Count: {0}", dt.Rows.Count);
			//if (dt.Rows.Count == 0) return false;
			if (dt.Rows.Count == 0) return true;

			var data_set_flg = new
			{
				//set_time = dt.Rows[0].Field<DateTime>("set_time"),
				file_path = dt.Rows[0].Field<string>("file_path"),
				msg_uid = dt.Rows[0].Field<string>("msg_uid"),
			};

			//CSV出力
			{
				var PfDB = new PfDB();

				//データ取得
				var sq = new StringBuilder();
				sq.AppendFormat("select");
				sq.AppendLine().AppendFormat("*");
				sq.AppendLine().AppendFormat("from");
				sq.AppendLine().AppendFormat("tbl_general_disease_with");
				sq.AppendLine().AppendFormat("where hosp_id = '{0}'", hospId);
				sq.AppendLine().AppendFormat("and msg_uid = '{0}'", data_set_flg.msg_uid);
				sq.AppendLine().AppendFormat("order by");
				sq.AppendLine().AppendFormat("patient_id");
				sq.AppendLine().AppendFormat(",measure_date");
				sq.AppendLine().AppendFormat(",seq_no");

				dt = new DataTable();
				ret = PfDB.sqlSelectTable(sq.ToString(), ref dt);
				if (dt.Rows.Count == 0) return true;

				//var headers = new[] {
				//	"患者番号",
				//	"データ日付",
				//	"通番",
				//	"マスク",
				//	"登録・更新者",
				//	"登録・更新日",
				//	"現病/既往歴区分",
				//	"傷病名コード",
				//	"疾患名",
				//	"診断した医療機関名",
				//	"With順番号",
				//	"With既往歴コード",
				//	"With経過",
				//	"ICD-10(2003)",
				//	"疾患名カナ",
				//	"WithYou更新ステータス",
				//	"With更新ステータス",
				//	"With更新者（職員CD）",
				//	"With更新者（職員氏名）",
				//	"With更新日時",
				//};

				var nullableDateTimeToStringOrEmpty = new Func<DateTime?, string, string>((value, format) => {
					if (value.HasValue) return value.Value.ToString(format);
					return "";
				});

				var nullableIntToStringOrEmpty = new Func<int?, string>(value => {
					if (value.HasValue) return value.Value.ToString();
					return "";
				});

				var nullableShortToStringOrEmpty = new Func<short?, string>(value => {
					if (value.HasValue) return value.Value.ToString();
					return "";
				});

				var rows = dt.AsEnumerable().Select(s => new[] {
					s.Field<string>("patient_id"),
					nullableDateTimeToStringOrEmpty(s.Field<DateTime?>("measure_date"), "yyyy/MM/dd"),
					nullableIntToStringOrEmpty(s.Field<int?>("seq_no")),
					nullableShortToStringOrEmpty(s.Field<short?>("mask")),
					s.Field<string>("regist_user"),
					nullableDateTimeToStringOrEmpty(s.Field<DateTime?>("regist_date"), "yyyy/MM/dd HH:mm:ss"),
					s.Field<string>("medical_history"),
					s.Field<string>("disease_cd"),
					s.Field<string>("disease_name"),
					s.Field<string>("medical_facility"),
					nullableShortToStringOrEmpty(s.Field<short?>("with_seqno")),
					nullableShortToStringOrEmpty(s.Field<short?>("with_kiorekicd")),
					nullableShortToStringOrEmpty(s.Field<short?>("with_keika")),
					s.Field<string>("icd10"),
					s.Field<string>("disease_name_kana"),
					nullableShortToStringOrEmpty(s.Field<short?>("withyou_status")),
					nullableShortToStringOrEmpty(s.Field<short?>("with_status")),
					s.Field<string>("with_mod_usercd"),
					s.Field<string>("with_mod_username"),
					nullableDateTimeToStringOrEmpty(s.Field<DateTime?>("with_mod_date"), "yyyy/MM/dd HH:mm:ss"),
				});

				//フォルダー作成
				Directory.CreateDirectory(data_set_flg.file_path);

				//CSV出力
				var fileName = string.Format("{0}_{1}_WithYou連携データ疾患.csv"
					, hospId
					, DateTime.Now.ToString("yyyyMMddHHmmss")
					);
				var filePath = Path.Combine(data_set_flg.file_path, fileName);
				using (var writer = new CsvWriter(filePath))
				{
					//writer.WriteLine(headers);

					foreach (var row in rows)
					{
						writer.WriteLine(row);
					}

					writer.WriteEOF();
				}

				fileCount = 1;
				fileNames = fileName;
				msgUid = data_set_flg.msg_uid;
			}

			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：ContactWithYouDataGeneralDisease() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

	//2020.02.04 add
	private bool ContactWithYouDataTakingMedicines(string hospId, string ipAddress, ref string msgUid, ref int fileCount, ref string fileNames)
	{
		bool ret = false;
		//fileCount = 0;
		fileCount = -1;
		fileNames = "";

		const string sql_template = "select d.* from tbl_data_set_flg d " +
			"where d.set_status&{0}={0} and d.hosp_id = '{1}' and d.data_type = '5' order by d.set_time";

		try
		{
			//LogGW(hospId, "[ContactWithYouDataTakingMedicines]");

			if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認

			// フラグ確認
			var WyDB = new App_Function();
			string sql = string.Format(sql_template
				, (int)eStatus.Active
				, hospId);

			var dt = new DataTable();
			ret = WyDB.sqlSelectTable(sql, ref dt);
			//LogGW(hospId, "[ContactWithYouDataGeneralDisease] dt.Rows.Count: {0}", dt.Rows.Count);
			//if (dt.Rows.Count == 0) return false;
			if (dt.Rows.Count == 0) return true;

			var data_set_flg = new
			{
				//set_time = dt.Rows[0].Field<DateTime>("set_time"),
				file_path = dt.Rows[0].Field<string>("file_path"),
				msg_uid = dt.Rows[0].Field<string>("msg_uid"),
			};

			//CSV出力
			{
				var PfDB = new PfDB();

				//データ取得
				var sq = new StringBuilder();
				sq.AppendFormat("select");
				sq.AppendLine().AppendFormat("*");
				sq.AppendLine().AppendFormat("from");
				sq.AppendLine().AppendFormat("tbl_taking_medicines_with");
				sq.AppendLine().AppendFormat("where hosp_id = '{0}'", hospId);
				sq.AppendLine().AppendFormat("and msg_uid = '{0}'", data_set_flg.msg_uid);
				sq.AppendLine().AppendFormat("order by");
				sq.AppendLine().AppendFormat("patient_id");
				sq.AppendLine().AppendFormat(",measure_date");
				sq.AppendLine().AppendFormat(",seq_no");

				dt = new DataTable();
				ret = PfDB.sqlSelectTable(sq.ToString(), ref dt);
				if (dt.Rows.Count == 0) return true;

				//var headers = new[] {
				//	"患者番号",
				//	"データ日付",
				//	"通番",
				//	"マスク",
				//	"登録・更新者",
				//	"登録・更新日",
				//	"服用状況",
				//	"薬価コード",
				//	"薬剤名",
				//	"処方医療機関名",
				//	"With順番号",
				//	"WithYou更新ステータス",
				//	"With更新ステータス",
				//	"With更新者（職員CD）",
				//	"With更新者（職員氏名）",
				//	"With更新日時",
				//};

				var nullableDateTimeToStringOrEmpty = new Func<DateTime?, string, string>((value, format) => {
					if (value.HasValue) return value.Value.ToString(format);
					return "";
				});

				var nullableIntToStringOrEmpty = new Func<int?, string>(value => {
					if (value.HasValue) return value.Value.ToString();
					return "";
				});

				var nullableShortToStringOrEmpty = new Func<short?, string>(value => {
					if (value.HasValue) return value.Value.ToString();
					return "";
				});

				var rows = dt.AsEnumerable().Select(s => new[] {
					s.Field<string>("patient_id"),
					nullableDateTimeToStringOrEmpty(s.Field<DateTime?>("measure_date"), "yyyy/MM/dd"),
					nullableIntToStringOrEmpty(s.Field<int?>("seq_no")),
					nullableShortToStringOrEmpty(s.Field<short?>("mask")),
					s.Field<string>("regist_user"),
					nullableDateTimeToStringOrEmpty(s.Field<DateTime?>("regist_date"), "yyyy/MM/dd HH:mm:ss"),
					nullableShortToStringOrEmpty(s.Field<short?>("medical_history")),
					s.Field<string>("yakka_code"),
					s.Field<string>("medicine_name"),
					s.Field<string>("medical_facility"),
					nullableShortToStringOrEmpty(s.Field<short?>("with_seqno")),
					nullableShortToStringOrEmpty(s.Field<short?>("withyou_status")),
					nullableShortToStringOrEmpty(s.Field<short?>("with_status")),
					s.Field<string>("with_mod_usercd"),
					s.Field<string>("with_mod_username"),
					nullableDateTimeToStringOrEmpty(s.Field<DateTime?>("with_mod_date"), "yyyy/MM/dd HH:mm:ss"),
				});

				//フォルダー作成
				Directory.CreateDirectory(data_set_flg.file_path);

				//CSV出力
				var fileName = string.Format("{0}_{1}_WithYou連携データ服用中薬剤.csv"
					, hospId
					, DateTime.Now.ToString("yyyyMMddHHmmss")
					);
				var filePath = Path.Combine(data_set_flg.file_path, fileName);
				using (var writer = new CsvWriter(filePath))
				{
					//writer.WriteLine(headers);

					foreach (var row in rows)
					{
						writer.WriteLine(row);
					}

					writer.WriteEOF();
				}

				fileCount = 1;
				fileNames = fileName;
				msgUid = data_set_flg.msg_uid;
			}

			ret = true;
		}
		catch (Exception ex)
		{
			LogGW(hospId, err, "例外発生：ContactWithYouDataTakingMedicines() {0}", ex.ToString());
			ret = false;
		}

		return ret;
	}

}
