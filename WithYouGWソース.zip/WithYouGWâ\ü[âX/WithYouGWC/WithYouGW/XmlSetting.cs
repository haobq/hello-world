using System;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace WithYouGW
{

	public class MSConfig : XmlConfig
	{
		public MSConfig(string fileName)
			: base(fileName)
		{
		}

		public override void DefaultSet()
		{
			Config defaultSet = new Config();

			//defaultSet.main.BaseDir = ".";
			//defaultSet.main.ErrFilePath = "err";
			//defaultSet.main.LogPath = "log";
			//defaultSet.main.ListMax = 10000;

			//ConfigFileName = DefaultName;
			WriteConfig(defaultSet);
		}
	}

	/// <summary>
	/// 
	/// </summary>
	public class Config
	{
		public Config(){}

		public Init init = new Init();
		public DBSetting DB = new DBSetting();
		public GWServer gwserver = new GWServer();
	}

	public class Init
	{
		public string hosp_id;			// ��@ID
		//public string temp_folder;		// �e���|�����t�H���_
		//public string log_folder;       // ���O�t�H���_
		public int log_storage_days;    // ���O�ۑ�����
		//public string done_folder;      // �����ς݃t�H���_
		//public string error_folder;		// �G���[�t�H���_
		//public ulong ListMax;
		public string user_id;
		public int dbg;

		public Init(){}
	}

	public class DBSetting
	{
		//public string server_ip;
		//public string database_name;
		//public string user_name;
		//public string password;
		public int interval;

		public DBSetting() { }
	}

	public class GWServer
	{
		public string url;
		public int interval;

		public GWServer() { }
	}

	/// <summary>
	/// XmlSetting �̊T�v�̐����ł��B
	/// </summary>
	public class XmlConfig
	{
		internal const string DefaultName = "setting.xml";
		private string m_fileName;
		private string m_errMsg;

		public XmlConfig(string fileName){
			ConfigFileName = fileName;
		}

		/// <summary>
		/// config�t�@�C���f�[�^�̃V���A���C�Y
		/// </summary>
		/// <param name="setting"></param>
		/// <returns></returns>
		public bool WriteConfig(Config config)
		{
			try
			{
				XmlSerializer serializer = new XmlSerializer(typeof(Config));
				StreamWriter writer = new StreamWriter(File.Create(ConfigFileName), System.Text.Encoding.GetEncoding((int)Encode.ShiftJis));
				serializer.Serialize(writer, config);
				writer.Close();
			}
			catch(Exception e)
			{
				ErrorMessage = e.ToString();
				return false;
			}

			return true;
		}

		/// <summary>
		/// config�t�@�C���f�[�^�̃f�V���A���C�Y
		/// </summary>
		/// <param name="setting"></param>
		/// <returns></returns>
		public bool ReadConfig(out Config config)
		{
			config = new Config();

			if(File.Exists(ConfigFileName) == false)
			{
				//if(ConfigFileName == "") ConfigFileName = DefaultName;
				//DefaultSet();

				return false;
			}

			try{
				FileStream fs = new FileStream(ConfigFileName, FileMode.Open);
				XmlSerializer serializer = new XmlSerializer(typeof(Config));
				config = (Config)serializer.Deserialize(fs);
				//config.main.SetPath();
/*
				config.server.SetPath(config.main.BaseDir);
				config.client.SetPath(config.main.BaseDir);
*/
				fs.Close();
			}
			catch(Exception e)
			{
				ErrorMessage = e.ToString();
				return false;
			}

			return true;
		}

		/// <summary>
		/// config�t�@�C���̃f�t�H���g�ݒ�
		/// ���̂͌p�����Őݒ肷��
		/// </summary>
		public virtual void DefaultSet()
		{
		}

		/// <summary>
		/// config�t�@�C����
		/// </summary>
		public string ConfigFileName
		{
			set{ m_fileName = value; }
			get{ return m_fileName; }
		}

		/// <summary>
		/// �G���[���b�Z�[�W
		/// </summary>
		public string ErrorMessage
		{
			set{ m_errMsg = value; }
			get{ return m_errMsg; } 
		}

	}


}
