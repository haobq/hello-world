//using System;
//using System.Data;
//using System.Data.Odbc;
//using System.Collections.Generic;

//namespace WithYouGW
//{
//	public class DBAccessWith : DBAccessBase
//	{

//		public DBAccessWith(string conStr)
//		{
//			if (!DataBaseOpen(conStr))
//			{
//			}
//		}

//		public List<Dictionary<string, object>> GetGengouM()
//		{
//			List<Dictionary<string, object>> objList = new List<Dictionary<string, object>>();

//			const string SQL_TEMPLATE = "SELECT �����R�[�h, ��������, �����J�n�N���� " + 
//										"  FROM ECDB.dbo.����M " + 
//										" ORDER BY �����J�n�N���� ";

//			try
//			{
//				DataTable dt;
//				SqlSelect(SQL_TEMPLATE, out dt);

//				if (dt.Rows.Count != 0)
//				{
//					for (int i = 0; i < dt.Rows.Count; i++)
//					{
//						Dictionary<string, object> objDict = new Dictionary<string, object>();
//						int iColumnCount = dt.Rows.Count;
//						for (int j = 0; j <= iColumnCount - 1; j++)
//						{
//							// �悭�킩��Ȃ����؁@ikeda
//							objDict.Add(dt.Columns[j], dt.Rows.[j][0]);
//							//objDict.Add(dr.GetName(j), dr.GetValue(j));
//						}
//						objList.Add(objDict);
//					}
//				}
//			}
//			catch(Exception ex)
//			{
//			/*
//				using (con == GetConnectionWithOpen())
//			{
//				using (SqlCommand cmd = new SqlCommand())
//				{
//					cmd.Connection = con;
//					cmd.CommandText = SQL_TEMPLATE;
//					using (SqlDataReader dr = cmd.ExecuteReader())
//					{
//						if (dr.HasRows)
//						{
//							while (dr.Read())
//							{
//								Dictionary<string, object> objDict = new Dictionary<string, object>();
//								int iColumnCount = dr.FieldCount;
//								for (int i = 0; i <= iColumnCount - 1; i++)
//								{
//									objDict.Add(dr.GetName(i), dr.GetValue(i));
//								}
//								objList.Add(objDict);
//							}
//						}
//					}
//				}
//			*/
//			}

//			return objList;
//		}

//		public string GetYYMM(System.DateTime shinryouNengappi)
//		{
//			string strYYMM = null;

//			const string SQL_TEMPLATE = "SELECT TOP 1 DB�������� " + 
//										"FROM ECDB.dbo.��@�l�}�X�^�Ǘ� " + 
//										"WHERE �J�n�N����<='{0}' " + 
//										"ORDER BY �J�n�N���� DESC ";

//			try
//			{
//				string sql = string.Format(SQL_TEMPLATE, shinryouNengappi);

//				DataTable dt;
//				SqlSelect(SQL_TEMPLATE, out dt);

//				if (dt.Rows.Count != 0)
//				{
//					strYYMM = dt.Rows[0]["DB��������"].ToString();
//				}
//				else
//				{
//					//�G���[
//					//throw new Exception(string.Format("��@�l�}�X�^�Ǘ�����DB�������̂̎擾�Ɏ��s���܂����B�f�ÔN����=[{0}]", shinryouNengappi.ToString("yyyy/MM/dd")));
//				}

//			}
//			catch (Exception ex)
//			{
//				//�G���[
//				//throw new Exception(string.Format("��@�l�}�X�^�Ǘ�����DB�������̂̎擾�Ɏ��s���܂����B�f�ÔN����=[{0}]", shinryouNengappi.ToString("yyyy/MM/dd")));
//			}

//			return strYYMM;
//		}


//		public List<HenkanMaster> GetWithYouRenkeiHenkanMaster()
//		{
//			List<HenkanMaster> lstHenkanMaster = new List<HenkanMaster>();

//			const string SQL_TEMPLATE = "SELECT [�}�X�^�Ǘ��R�[�h] " +
//										"      ,[�I�[�_�[�R�[�h] " +
//										"      ,[���ԍ�] " +
//										"      ,[���u�R�[�h] " +
//										"      ,[��\�R�[�h] " +
//										"      ,[�ϊ����] " +
//										"  FROM ECDOC.dbo.[WithYou�A�g�ϊ��}�X�^] " +
//										" WHERE [�}�X�N] = 0";

//			try
//			{
//				DataTable dt;
//				SqlSelect(SQL_TEMPLATE, out dt);

//				Form1.LoggingDisplay("WithYou�A�g�ϊ��}�X�^({0})", dt.Rows.Count);
//				if (dt.Rows.Count != 0)
//				{
//					for (int i = 0; i < dt.Rows.Count; i++)
//					{
//						string b1 = dt.Rows[i]["�}�X�^�Ǘ��R�[�h"].ToString();
//						string b2 = dt.Rows[i]["�I�[�_�[�R�[�h"].ToString();
//						string b3 = dt.Rows[i]["���ԍ�"].ToString();
//						string b4 = dt.Rows[i]["���u�R�[�h"].ToString();
//						string b5 = dt.Rows[i]["��\�R�[�h"].ToString();
//						string b6 = dt.Rows[i]["�ϊ����"].ToString();
//						Form1.LoggingDisplay("{0},{1},{2},{3},{4},{5}", b1, b2, b3, b4, b5, b6);

//						/*
//						HenkanMaster objHenkanMaster = new HenkanMaster();
//						objHenkanMaster.MasterKanriCode = dr.GetValue(dr.GetOrdinal("�}�X�^�Ǘ��R�[�h"));
//						objHenkanMaster.OrderCode = dr.GetValue(dr.GetOrdinal("�I�[�_�[�R�[�h"));
//						objHenkanMaster.Junbangou = dr.GetValue(dr.GetOrdinal("���ԍ�"));
//						objHenkanMaster.SyochiCode = dr.GetValue(dr.GetOrdinal("���u�R�[�h"));
//						objHenkanMaster.DaihyouCode = dr.GetValue(dr.GetOrdinal("��\�R�[�h"));
//						objHenkanMaster.HenkanSyubetsu = dr.GetValue(dr.GetOrdinal("�ϊ����"));
//						*/

//						HenkanMaster objHenkanMaster = new HenkanMaster(this);
//						objHenkanMaster.MasterKanriCode = dt.Rows[i]["�}�X�^�Ǘ��R�[�h"].ToString();
//						objHenkanMaster.OrderCode = dt.Rows[i]["�}�X�^�Ǘ��R�[�h"].ToString();
//						objHenkanMaster.Junbangou = util.ToShort(dt.Rows[i]["���ԍ�"].ToString());
//						objHenkanMaster.SyochiCode = util.ToInt(dt.Rows[i]["���u�R�[�h"].ToString());
//						objHenkanMaster.DaihyouCode = util.ToInt(dt.Rows[i]["��\�R�[�h"].ToString());
//						objHenkanMaster.HenkanSyubetsu = util.ToShort(dt.Rows[i]["�ϊ����"].ToString());
//						lstHenkanMaster.Add(objHenkanMaster);
//					}
//				}

//			}
//			catch(Exception ex)
//			{
//				//Throw New Exception("WithYou�A�g�ϊ��}�X�^�̎擾�Ɏ��s���܂����B")
//			}

//			return lstHenkanMaster;
//		}

//		public string GetWithYouBunsyoRenkeiPath()
//		{
//			string renkeiPath = "";

//			const string SQL_TEMPLATE = "SELECT TOP 1 [WithYou�����A�g�p�X] " +
//												   "  FROM ECDB.dbo.��@�l��@�ŗL ";
//			try
//			{
//				DataTable dt;
//				SqlSelect(SQL_TEMPLATE, out dt);

//				Form1.LoggingDisplay("ECDB.dbo.��@�l��@�ŗL({0})", dt.Rows.Count);
//				if (dt.Rows.Count != 0)
//				{
//					for (int i = 0; i < dt.Rows.Count; i++)
//					{
//						string b1 = dt.Rows[i]["WithYou�����A�g�p�X"].ToString();
//						Form1.LoggingDisplay("{0}", b1);
//					}
//				}

//			}
//			catch(Exception ex)
//			{
//			}

//			return renkeiPath;
//		}

//		public int GetMaxJunbangou(int patientNo, DateTime date, int documentNo)
//		{
//			int maxNo = 0;

//			//const string SQL_TEMPLATE = "SELECT TOP 1 ���ԍ� " +
//			//							   "  FROM ECDOC.dbo.WithYou�����A�g " +
//			//							   " WHERE ���Ҕԍ� = @KanjaBangou " +
//			//							   "   AND �f�Ó� = @ShinryouNengappi " +
//			//							   "   AND �����ԍ� = @BunsyoBangou " +
//			//							   " ORDER BY ���ԍ� DESC ";

//			const string SQL_TEMPLATE = "select * from ECDOC.dbo.WithYou�����A�g where ���Ҕԍ�='360'";

//			try
//			{
//				DataTable dt;
//				SqlSelect(SQL_TEMPLATE, out dt);

//				Form1.LoggingDisplay("���ԍ�({0})", dt.Rows.Count);
//				if (dt.Rows.Count != 0)
//				{
//					for (int i = 0; i < dt.Rows.Count; i++)
//					{
//						//string b1 = dt.Rows[i]["���ԍ�"].ToString();
//						//Form1.LoggingDisplay("{0},{1},{2},{3}", patientNo, date, documentNo, b1);
//						string b1 = dt.Rows[i]["�����ԍ�"].ToString();
//						//Form1.LoggingDisplay("{0},{1},{2},{3}", patientNo, date, documentNo, b1);
//						Form1.LoggingDisplay("{0}", b1);
//					}
//				}
//			}
//			catch (Exception ex)
//			{
//			}

//			return maxNo;
//		}

//		public bool InsertIntoWithYouBunsyoRenkei(string pdfFilePath, TeikyouBunsyo teikyouBunsyo)
//		{
//			bool ret = true;
//			/*
//			const string SQL_TEMPLATE = "INSERT INTO ECDOC.dbo.[WithYou�����A�g] " +
//											"           ([���Ҕԍ�] " +
//											"           ,[�f�Ó�] " +
//											"           ,[�����ԍ�] " +
//											"           ,[���ԍ�] " +
//											"           ,[PDF�p�X] " +
//											"           ,[�捞�t���O] " +
//											"           ,[PdfRpt_UID] " +
//											"           ,[�폜�t���O]) " +
//											"     VALUES " +
//											"           (@KanjaBangou " +
//											"           ,@ShinryouNengappi " +
//											"           ,@BunsyoBangou " +
//											"           ,@Junbangou " +
//											"           ,@PdfPath " +
//											"           ,0 " +
//											"           ,0 " +
//											"           ,0)";
//			*/
//			const string SQL_TEMPLATE = "INSERT INTO ECDOC.dbo.[WithYou�����A�g] " +
//								"           ([���Ҕԍ�] " +
//								"           ,[�f�Ó�] " +
//								"           ,[�����ԍ�] " +
//								"           ,[���ԍ�] " +
//								"           ,[PDF�p�X] " +
//								"           ,[�捞�t���O] " +
//								"           ,[PdfRpt_UID] " +
//								"           ,[�폜�t���O]) " +
//								"     VALUES " +
//								"           ({0} " +
//								"           ,{1} " +
//								"           ,{2} " +
//								"           ,{3} " +
//								"           ,{4} " +
//								"           ,0 " +
//								"           ,0 " +
//								"           ,0)";

//			try
//			{

//				//�ő叇�ԍ����擾����
//				int iMaxJunbangou = GetMaxJunbangou(teikyouBunsyo.KanjaBangou, teikyouBunsyo.Houmonbi, Convert.ToInt32(teikyouBunsyo.BunsyoCode));

//				string sql = string.Format(SQL_TEMPLATE, teikyouBunsyo.KanjaBangou,	teikyouBunsyo.Houmonbi, 
//											teikyouBunsyo.BunsyoCode, iMaxJunbangou+1, pdfFilePath);

//				ret = SqlInsert(SQL_TEMPLATE);

//				return true;
//			}
//			catch (Exception ex)
//			{
//				/*
//				dynamic objAppLogger = LoggerAppcation.GetInstance();
//				objAppLogger.WriteLog(ex.Message);

//				dynamic objErrLogger = LoggerError.GetInstance();
//				objErrLogger.WriteLog(ex);

//				//Windows�̃G���[���b�Z�[�W��ECLOG�ɏ�������
//				Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, teikyouBunsyo.KanjaBangou);
//				*/
//				return false;
//			}
//		}

//		public int GetKarute1Count(int kanjaBangou, System.DateTime shinryouNengappi, string yymm)
//		{
//			int iRecordCount = 0;
//			bool ret = true;

//			const string SQL_TEMPLATE = "SELECT COUNT(���Ҕԍ�) " + 
//										"  FROM ECDB{0}.dbo.[�J���e1] " + 
//										"  WHERE [�f�ÔN����] = {1} " + 
//										"    AND [���Ҕԍ�] = {2} " + 
//										"    AND [�폜�t���O] = 0 ";

//			string sql = string.Format(SQL_TEMPLATE, yymm, kanjaBangou, shinryouNengappi);

//			DataTable dt;
//			ret = SqlSelect(SQL_TEMPLATE, out dt);
//			if (dt.Rows.Count != 0)
//			{
//				iRecordCount = util.ToInt(dt.Rows[0][0].ToString());
//			}
//			else iRecordCount = 0;

//			//using (con == GetConnectionWithOpen())
//			//{
//			//	using (SqlCommand cmd = new SqlCommand())
//			//	{
//			//		cmd.Connection = con;
//			//		cmd.CommandText = string.Format(SQL_TEMPLATE, yymm);
//			//		cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
//			//		cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

//			//		using (SqlDataReader dr = cmd.ExecuteReader())
//			//		{
//			//			if (dr.HasRows)
//			//			{
//			//				dr.Read();
//			//				iRecordCount = dr.GetSqlInt32(0);
//			//			}
//			//			else
//			//			{
//			//				iRecordCount = 0;
//			//			}
//			//		}
//			//	}
//			//}

//			return iRecordCount;
//		}


//		public void UpdateRenkeiDataSyoriKubun(/*SqlConnection con, SqlTransaction tran,*/ int kanjaBangou, System.DateTime shinryouNengappi)
//		{
//			bool ret = true;
//			/*
//			const string SQL_TEMPLATE = "UPDATE ECDOC.dbo.[WithYou�A�g�f�[�^] " + 
//										"   SET [�����敪] = 2 " + 
//										" WHERE [���Ҕԍ�] = @KanjaBangou " + 
//										"   AND [�f�ÔN����] = @ShinryouNengappi " + 
//										"   AND [�����敪] = 1 ";
//			*/
//			const string SQL_TEMPLATE = "UPDATE ECDOC.dbo.[WithYou�A�g�f�[�^] " +
//							"   SET [�����敪] = 2 " +
//							" WHERE [���Ҕԍ�] = @KanjaBangou " +
//							"   AND [�f�ÔN����] = @ShinryouNengappi " +
//							"   AND [�����敪] = 1 ";

//			try
//			{
//				string sql = string.Format(SQL_TEMPLATE, kanjaBangou, shinryouNengappi);

//				DataTable dt;
//				ret = SqlUpdate(SQL_TEMPLATE);
//				//if (dt.Rows.Count != 0)
//				//{
//				//	iRecordCount = util.ToInt(dt.Rows[0][0].ToString());
//				//}
//				//else iRecordCount = 0;

//				//using (SqlCommand cmd = new SqlCommand())
//				//{
//				//	cmd.Connection = con;
//				//	cmd.Transaction = tran;
//				//	cmd.CommandText = SQL_TEMPLATE;
//				//	cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
//				//	cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

//				//	cmd.ExecuteNonQuery();
//				//}
//			}
//			catch(Exception ex)
//			{

//			}
//		}


//		public void UpdateBunsyoRenkeiSakujoFlag(/*SqlConnection con, SqlTransaction tran,*/ int kanjaBangou, System.DateTime shinryouNengappi)
//		{
//			bool ret = true;
//			const string SQL_TEMPLATE = "UPDATE ECDOC.dbo.[WithYou�����A�g] " +
//										"   SET [�폜�t���O] = 1 " +
//										" WHERE [���Ҕԍ�] = {0} " +
//										"   AND [�f�Ó�] = '{1}' " +
//										"   AND [�捞�t���O] = 0 ";


//			try
//			{
//				string sql = string.Format(SQL_TEMPLATE, kanjaBangou, shinryouNengappi);

//				DataTable dt;
//				ret = SqlUpdate(SQL_TEMPLATE);

//				//using (SqlCommand cmd = new SqlCommand())
//				//{
//				//	cmd.Connection = con;
//				//	cmd.Transaction = tran;
//				//	cmd.CommandText = SQL_TEMPLATE;
//				//	cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
//				//	cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

//				//	cmd.ExecuteNonQuery();
//				//}
//			}
//			catch (Exception ex)
//			{

//			}
//		}

//		public short GetMaxJunbangou1(/*SqlConnection con, SqlTransaction tran,*/ int kanjaBangou, System.DateTime shinryouNengappi)
//		{
//			bool ret = true;
//			short shMaxJunbangou1 = 0;

//			const string SQL_TEMPLATE = "SELECT TOP 1 ���ԍ�1 " + 
//										"  FROM ECDOC.dbo.WithYou�A�g�f�[�^ " + 
//										" WHERE ���Ҕԍ� = {0} " + 
//										"   AND �f�ÔN���� = '{1}' " + 
//										" ORDER BY ���ԍ�1 DESC ";

//			try
//			{
//				string sql = string.Format(SQL_TEMPLATE, kanjaBangou, shinryouNengappi);

//				DataTable dt;
//				ret = SqlSelect(SQL_TEMPLATE, out dt);
//				if (dt.Rows.Count != 0)
//				{
//					shMaxJunbangou1 = util.ToShort(dt.Rows[0]["���ԍ�1"].ToString());
//				}
//				else shMaxJunbangou1 = 0;


//				//using (SqlCommand cmd = new SqlCommand())
//				//{
//				//	cmd.Connection = con;
//				//	cmd.Transaction = tran;
//				//	cmd.CommandText = SQL_TEMPLATE;
//				//	cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
//				//	cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

//				//	using (SqlDataReader dr = cmd.ExecuteReader())
//				//	{
//				//		if (dr.HasRows)
//				//		{
//				//			dr.Read();
//				//			shMaxJunbangou1 = dr.GetValue(dr.GetOrdinal("���ԍ�1"));
//				//		}
//				//		else
//				//		{
//				//			shMaxJunbangou1 = 0;
//				//		}
//				//	}
//				//}
//			}
//			catch(Exception ex)
//			{

//			}

//			return shMaxJunbangou1;
//		}


//		public static int InsertIntoWithYouRenkeiData(/*SqlConnection con, SqlTransaction tran,*/ List<CsvRecord> lstCsvData, string masterKanriCode, short junbangou1)
//		{
//			const short SYORI_KUBUN_SHINKI = 1;
//			const string SQL_TEMPLATE = "INSERT INTO ECDOC.dbo.[WithYou�A�g�f�[�^] " + 
//										"           ([���Ҕԍ�] " + 
//										"           ,[�f�ÔN����] " + 
//										"           ,[���ԍ�1] " + 
//										"           ,[���ԍ�2] " + 
//										"           ,[���u�R�[�h] " + 
//										"           ,[��\�R�[�h] " + 
//										"           ,[�I�[�_�[�R�[�h] " + 
//										"           ,[�f�Ís�ז���] " + 
//										"           ,[��] " + 
//										"           ,[�l1] " + 
//										"           ,[�l2] " + 
//										"           ,[�q���m��] " + 
//										"           ,[�R�����g] " + 
//										"           ,[�쐬����] " + 
//										"           ,[�����敪] " + 
//										"           ,[�f�Ë敪] " + 
//										"           ,[�f�Ë敪����] " + 
//										"           ,[�h�N�^�[�R�[�h] " + 
//										"           ,[�h�N�^�[��]) " + 
//										"     VALUES " + 
//										"           (@KanjaBangou " + 
//										"           ,@ShinryouNengappi " + 
//										"           ,@Junbangou1 " + 
//										"           ,@Junbangou2 " + 
//										"           ,@SyochiCode " + 
//										"           ,@DaihyouCode " + 
//										"           ,@OrderCode " + 
//										"           ,@ShinryouKouiMeisyou " + 
//										"           ,@Kaisuu " + 
//										"           ,@Atai1 " + 
//										"           ,@Atai2 " + 
//										"           ,@EiseishiMei " + 
//										"           ,@Comment " + 
//										"           ,@SakuseiJikan " + 
//										"           ,@SyoriKubun " + 
//										"           ,@ShinryouKubun " + 
//										"           ,@ShinryouKubunMeisyou " + 
//										"           ,@DoctorCode " + 
//										"           ,@DoctorName) ";

//			int iTourokuKensuu = 0;

//			string sql = string.Format(SQL_TEMPLATE);


//			using (SqlCommand cmd = new SqlCommand())
//			{
//				cmd.Connection = con;
//				cmd.Transaction = tran;
//				cmd.CommandText = SQL_TEMPLATE;
//				short iJunbangou2 = 0;
//				foreach (CsvRecord rec in lstCsvData)
//				{
//					//WithYou�A�g�ϊ��}�X�^�̃I�[�_�[�R�[�h����v���郌�R�[�h�������J��Ԃ�
//					string strOrderCode = string.Right("0000000000" + rec.ShinryouKouiCode, 10) + string.Right("00" + rec.HosokuCode, 2);
//					dynamic lstHenkanMaster = HenkanMaster.GetHenkanMasterByOrderCode(masterKanriCode, strOrderCode);
//					foreach (HenkanMaster itm in lstHenkanMaster)
//					{
//						iJunbangou2 += 1;
//						cmd.Parameters.Clear();
//						cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = rec.KanjaBangou;
//						cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = rec.Houmonbi;
//						cmd.Parameters.Add("@Junbangou1", SqlDbType.SmallInt).Value = junbangou1;
//						cmd.Parameters.Add("@Junbangou2", SqlDbType.SmallInt).Value = iJunbangou2;
//						cmd.Parameters.Add("@SyochiCode", SqlDbType.Int).Value = itm.SyochiCode;
//						cmd.Parameters.Add("@DaihyouCode", SqlDbType.Int).Value = itm.DaihyouCode;
//						cmd.Parameters.Add("@OrderCode", SqlDbType.VarChar).Value = strOrderCode;
//						//�f�Ís�׃R�[�h�{�⑫�R�[�h
//						cmd.Parameters.Add("@ShinryouKouiMeisyou", SqlDbType.VarChar).Value = rec.ShinryouKouiName;
//						cmd.Parameters.Add("@Kaisuu", SqlDbType.SmallInt).Value = 1;
//						//�񐔂�1�Œ�
//						if (string.IsNullOrEmpty(rec.KaishiJikoku))
//						{
//							//�J�n�����Ȃ��̏ꍇ��NULL
//							cmd.Parameters.Add("@Atai1", SqlDbType.Real).Value = DBNull.Value;
//						}
//						else
//						{
//							cmd.Parameters.Add("@Atai1", SqlDbType.Real).Value = float.Parse(rec.KaishiJikoku.Replace(":", ""));
//						}
//						if (string.IsNullOrEmpty(rec.SyuuryouJikoku))
//						{
//							//�I�������Ȃ��̏ꍇ��NULL
//							cmd.Parameters.Add("@Atai2", SqlDbType.Real).Value = DBNull.Value;
//						}
//						else
//						{
//							cmd.Parameters.Add("@Atai2", SqlDbType.Real).Value = float.Parse(rec.SyuuryouJikoku.Replace(":", ""));
//						}
//						cmd.Parameters.Add("@EiseishiMei", SqlDbType.VarChar).Value = rec.ShikaEiseishiName;
//						cmd.Parameters.Add("@Comment", SqlDbType.VarChar).Value = rec.ShikaEiseishiName;
//						cmd.Parameters.Add("@SakuseiJikan", SqlDbType.DateTime).Value = System.DateTime.Now;
//						cmd.Parameters.Add("@SyoriKubun", SqlDbType.SmallInt).Value = SYORI_KUBUN_SHINKI;
//						cmd.Parameters.Add("@ShinryouKubun", SqlDbType.SmallInt).Value = DBNull.Value;
//						cmd.Parameters.Add("@ShinryouKubunMeisyou", SqlDbType.VarChar).Value = DBNull.Value;
//						cmd.Parameters.Add("@DoctorCode", SqlDbType.Int).Value = rec.ShikaIshiCode;
//						cmd.Parameters.Add("@DoctorName", SqlDbType.VarChar).Value = rec.ShikaIshiName;

//						cmd.ExecuteNonQuery();

//						iTourokuKensuu += 1;
//					}
//				}
//			}

//			return iTourokuKensuu;
//		}

//		public void InsertIntoEclog(Eclog objEclog)
//		{
//			try
//			{
//				const int LENGTH_LOG_NAIYOU = 500;
//				const string SQL_TEMPLATE_1 = "INSERT INTO [ECLOG].[dbo].[���O�t�@�C��] " + "           ([���O���] " + "           ,[���t����] " + "           ,[�E��CD] " + "           ,[�E������] " + "           ,[TSE�ڑ�] " + "           ,[����PC��] " + "           ,[����PC��] " + "           ,[EXE��] " + "           ,[��ʖ�] " + "           ,[���Ҕԍ�] " + "           ,[���҃J�i����] " + "           ,[���Ҋ�������] " + "           ,[�t�@�C����] " + "           ,[���O���e]) " + "SELECT TOP 1  " + "\t\t@LogSyubetsu AS [���O���] " + "      ,GETDATE() AS [���t����] " + "      ,S.[�E��CD] " + "      ,S.[�E������] " + "      ,@TseSetsuzoku AS [TSE�ڑ�] " + "      ,@DousaPcMei AS [����PC��] " + "      ,@SousaPcMei AS [����PC��] " + "      ,@ExeMei AS [EXE��] " + "      ,@GamenMei AS [��ʖ�] ";
//				const string SQL_TEMPLATE_2_KANJABANGOU_ARI = "      ,K1.[���Ҕԍ�] " + "      ,K1.[�J�i����] " + "      ,K1.[��������] ";
//				const string SQL_TEMPLATE_2_KANJABANGOU_NASHI = "      ,0 AS [���Ҕԍ�] " + "      ,'' AS [�J�i����] " + "      ,'' AS [��������] ";
//				const string SQL_TEMPLATE_3 = "      ,@FileMei AS [�t�@�C����] " + "      ,@LogNaiyou AS [���O���e] " + "  FROM ECDB.dbo.�E���l AS S ";
//				const string SQL_TEMPLATE_3_JOIN = "INNER JOIN ���Ҋ�{1 AS K1 ON K1.���Ҕԍ� = @KanjaBangou ";
//				const string SQL_TEMPLATE_4 = "WHERE S.�E��CD = @SyokuinCode ";


//				StringBuilder sbSQL = new StringBuilder();
//				if (objEclog.KanjaBangou == 0)
//				{
//					//���Ҕԍ��Ȃ�
//					sbSQL.Append(SQL_TEMPLATE_1);
//					sbSQL.Append(SQL_TEMPLATE_2_KANJABANGOU_NASHI);
//					sbSQL.Append(SQL_TEMPLATE_3);
//					sbSQL.Append(SQL_TEMPLATE_4);
//				}
//				else
//				{
//					//���Ҕԍ�����
//					sbSQL.Append(SQL_TEMPLATE_1);
//					sbSQL.Append(SQL_TEMPLATE_2_KANJABANGOU_ARI);
//					sbSQL.Append(SQL_TEMPLATE_3);
//					sbSQL.Append(SQL_TEMPLATE_3_JOIN);
//					sbSQL.Append(SQL_TEMPLATE_4);
//				}


//				using (con == GetConnectionWithOpen())
//				{
//					using (SqlCommand cmd = new SqlCommand())
//					{
//						cmd.Connection = con;
//						cmd.CommandText = sbSQL.ToString();
//						cmd.Parameters.Add("@LogSyubetsu", SqlDbType.SmallInt).Value = objEclog.LogSyubetsu;
//						cmd.Parameters.Add("@TseSetsuzoku", SqlDbType.SmallInt).Value = objEclog.TseSetsuzoku;
//						cmd.Parameters.Add("@DousaPcMei", SqlDbType.VarChar).Value = objEclog.DousaPcMei;
//						cmd.Parameters.Add("@SousaPcMei", SqlDbType.VarChar).Value = objEclog.SousaPcMei;
//						cmd.Parameters.Add("@ExeMei", SqlDbType.VarChar).Value = objEclog.ExeMei;
//						cmd.Parameters.Add("@GamenMei", SqlDbType.VarChar).Value = Eclog.GamenMei;
//						cmd.Parameters.Add("@FileMei", SqlDbType.VarChar).Value = Eclog.FileMei;
//						cmd.Parameters.Add("@LogNaiyou", SqlDbType.VarChar).Value = Common.SubstringByte(objEclog.LogNaiyou, 0, LENGTH_LOG_NAIYOU);
//						cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = objEclog.KanjaBangou;
//						cmd.Parameters.Add("@SyokuinCode", SqlDbType.VarChar).Value = objEclog.SyokuinCode;

//						cmd.ExecuteNonQuery();
//					}
//				}

//				return;
//			}
//			catch (Exception ex)
//			{
//				dynamic objAppLogger = LoggerAppcation.GetInstance();
//				objAppLogger.WriteLog(ex.Message);

//				dynamic objErrLogger = LoggerError.GetInstance();
//				objErrLogger.WriteLog(ex);

//				return;
//			}
//		}

//		public static string GetKanjaShimei(int kanjaBangou)
//		{
//			string strKanjaShimei = null;

//			const string SQL_TEMPLATE = "SELECT [�J�i����], [��������] " + 
//										"  FROM ECDB.dbo.[���Ҋ�{1] " + 
//										" WHERE [���Ҕԍ�] = {0} ";

//			try
//			{
//				string sql = string.Format();

//				using (con == GetConnectionWithOpen())
//				{
//					using (SqlCommand cmd = new SqlCommand())
//					{
//						cmd.Connection = con;
//						cmd.CommandText = SQL_TEMPLATE;
//						cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;

//						using (SqlDataReader dr = cmd.ExecuteReader())
//						{
//							if (dr.HasRows)
//							{
//								dr.Read();
//								if (Information.IsDBNull(dr.GetValue(dr.GetOrdinal("��������"))) || string.IsNullOrEmpty(dr.GetValue(dr.GetOrdinal("��������"))))
//								{
//									strKanjaShimei = dr.GetValue(dr.GetOrdinal("�J�i����"));
//								}
//								else
//								{
//									strKanjaShimei = dr.GetValue(dr.GetOrdinal("��������"));
//								}
//							}
//							else
//							{
//								strKanjaShimei = "";
//							}
//						}
//					}
//				}
//			}
//			catch(Exception ex)
//			{

//			}

//			return strKanjaShimei;
//		}


//		//2016/10/07 ogasawara add S WithEpoch�Ή�
//		public static void ReadWithYouRenkeiKankyouSettei()
//		{
//			List<HenkanMaster> lstHenkanMaster = new List<HenkanMaster>();

//			const string SQL_TEMPLATE = "SELECT [NAME],[VALUE] " + "  FROM [ECDOC].[dbo].[WithYou�A�g���ݒ�] " + " WHERE [SECTION] = 'ZOKUSEI'";

//			using (con == GetConnectionWithOpen())
//			{
//				using (SqlCommand cmd = new SqlCommand())
//				{
//					cmd.Connection = con;
//					cmd.CommandText = SQL_TEMPLATE;
//					using (SqlDataReader dr = cmd.ExecuteReader())
//					{
//						if (dr.HasRows)
//						{
//							while (dr.Read())
//							{
//								string strName = dr.GetValue(dr.GetOrdinal("NAME"));
//								string strValue = dr.GetValue(dr.GetOrdinal("VALUE"));
//								WithYouRenkeiKankyouSettei.Add(strName, strValue);
//							}
//						}
//						else
//						{
//							//�G���[
//							throw new Exception("WithYou�A�g���ݒ�̎擾�Ɏ��s���܂����B");
//						}
//					}
//				}
//			}
//		}
//		//2016/10/07 ogasawara add E


//		//2016/10/20 ogasawara add S WithEpoch�Ή�(MD-�d�l-D095)
//		public static void ReadOptionFlag()
//		{
//			const string SQL_TEMPLATE = "SELECT TOP 1 �@�\����t���O, �@�\����t���O2 " + "FROM ��@�l�I�v�V���� " + "WHERE �J�n��<=GETDATE() ORDER BY �J�n�� DESC ";

//			using (con == GetConnectionWithOpen())
//			{
//				using (SqlCommand cmd = new SqlCommand())
//				{
//					cmd.Connection = con;
//					cmd.CommandText = SQL_TEMPLATE;
//					using (SqlDataReader dr = cmd.ExecuteReader())
//					{
//						if (dr.HasRows)
//						{
//							dr.Read();
//							OptionFlag.SetKinouSeigyoFlag1(dr.GetString(dr.GetOrdinal("�@�\����t���O")));
//							OptionFlag.SetKinouSeigyoFlag2(dr.GetString(dr.GetOrdinal("�@�\����t���O2")));
//						}
//						else
//						{
//							//�G���[
//							throw new Exception("��@�l�I�v�V�����̎擾�Ɏ��s���܂����B");
//						}
//					}
//				}
//			}
//		}
//		//2016/10/20 ogasawara add E

//		//2016/10/20 ogasawara add S WithEpoch�Ή�(MD-�d�l-D095)
//		public static void UpdateLocalDrive(string driveLetter)
//		{
//			const string SQL_TEMPLATE = "UPDATE [ECDOC].[dbo].[WithYou�A�g���ݒ�] " + "   SET [VALUE] = @DriveLetter " + " WHERE [SECTION] = 'ZOKUSEI' " + "   AND [NAME] = 'LOCALDRIVE' ";

//			using (con == GetConnectionWithOpen())
//			{
//				using (SqlCommand cmd = new SqlCommand())
//				{
//					cmd.Connection = con;
//					cmd.CommandText = SQL_TEMPLATE;
//					cmd.Parameters.Add("@DriveLetter", SqlDbType.VarChar).Value = driveLetter;

//					cmd.ExecuteNonQuery();
//				}
//			}
//		}
//		//2016/10/20 ogasawara add E

//	}
//}

