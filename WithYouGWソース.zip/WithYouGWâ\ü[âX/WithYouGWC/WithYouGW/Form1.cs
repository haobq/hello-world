﻿using System;
using System.Data;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Linq;
using System.Xml;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Net;
using System.Collections;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text.RegularExpressions;

// 備忘録
// 参照よりサービス参照の追加をおこないサーバ側webサービスの
// http://xxx/xxx/Service.svc?wsdl　を追加する事によりwebサービスの関数が使用可能
// wsdlはService.svcにアクセスした時に表示されるページに情報がある
//
// "複数のエンドポイント構成ｘｘ"のエラーが出た場合は、同じエントリポイントが
// 設定されている可能性があるので"App.config"ファイルの中を確認してみる
// サーバを変更した場合、"参照の再構成"で同期がとれるが、上記エラーが発生する
//
// 受信メッセージの最大メッセージ サイズ クォータ(65536) を超えました。このクォータを増やすには、
// 適切なバインド要素の MaxReceivedMessageSize プロパティを使用してください。

//<? xml version="1.0" encoding="utf-8"?>
//<configuration>
//  <system.net>
//	<defaultProxy>
//      <proxy
//		usesystemdefault = "false"
//		proxyaddress="http://172.24.134.8:3128"  
//        bypassonlocal="true"  
//      />  
//      <bypasslist>  
//        <add address = "[a-z]+\.contoso\.com" />
//	  </ bypasslist >
//	</ defaultProxy >
//  </ system.net >
//  < system.serviceModel >
//	< bindings >
//	  < basicHttpBinding >
//		< binding name="BasicHttpBinding_IService" />
//        <binding name = "BasicHttpsBinding_IService" maxReceivedMessageSize="211010048" sendTimeout="00:05:00" >
//	    <readerQuotas maxDepth = "211010048" maxStringContentLength="2000000"
//         maxArrayLength="2000000" maxBytesPerRead="2000000" maxNameTableCharCount="2000000" />
//        <security mode = "Transport" />
//		</ binding >
//	  </ basicHttpBinding >
//	</ bindings >
//	< client >
//	  < endpoint address="https://dev.withyou.media:8443/Service.svc"
//       binding="basicHttpBinding" bindingConfiguration="BasicHttpsBinding_IService"
//       contract="ServiceReference1.IService" name="BasicHttpsBinding_IService" />
//    </client>
//  </system.serviceModel>
//</configuration>


namespace WithYouGW
{
    public partial class Form1 : Form
    {
		//2020.02.02 add
		private Thread m_in_InitDM = null;
		private Thread m_in_withyou = null;
        private Thread m_in_with = null;
		//public static Config m_config;
		static Logging m_log;
		static bool m_logDisplay = true;
		private ServiceReference1.ServiceClient m_client1;
		private ServiceReference1.ServiceClient m_client2;
		static ReadIniData m_iniData = new ReadIniData();           // Iniファイル読込み
		private bool m_testKankyo = false;
		private string m_proxyAddress = "";

		private string m_hospId = "";
		private string m_ipAddress = "";
		private Global gb = new Global();
		private string m_create_csv_lastdate;
		private bool visuble = false;

		public Form1(string args)
        {

			InitializeComponent();

			//string iniDir = @"D:\ENV";
			//if (Global.DBG_FLG) iniDir = @"c:\ENV";

			// 起動パラメータよりDBアクセス情報を取得
			string[] prms = args.Split('･');
			if (prms.Length < 3)
			{
				MessageBox.Show("起動パラメータが設定されていません", "WithYou");
				notifyIcon1.Visible = false;
				Environment.Exit(0x8020);   // 強制終了		
				return;
			}

			Global.prm_db_server = prms[0];
			Global.prm_db_user = prms[1];
			Global.prm_db_password = prms[2];

			// 設定情報チェック(チェックのみ)
			bool err = false;
			DBAccess.GetOutputPath(ref err);

			if (!err) DBAccess.GetStorageDays(ref err);
			if (!err) DBAccess.GetKrtInterval(ref err);
			if (err)
			{
				string msg = string.Format(Global.MSG_ERR_SETTING_READ_ERROR, "WithYou連携環境設定");
				MessageBox.Show(msg, "WithYou");
				notifyIcon1.Visible = false;
				Environment.Exit(0x8020);   // 強制終了		
				return;
			}

			m_hospId = DBAccess.GetHospID();
			if (m_hospId.Length == 0)
			{
				MessageBox.Show(Global.MSG_ERR_NOENTRY_USERID, "WithYou");
				notifyIcon1.Visible = false;
				Environment.Exit(0x8020);   // 強制終了		
				return;
			}

			string xml = Path.Combine(util.ExeCurrentDir, "WithYouGWC.exe.config");
			XmlDocument document = new XmlDocument();

			// ファイルから読み込む
			document.Load(xml);
			if(document.InnerXml.Contains("test.withyou"))
			{
				this.Text += " テスト環境";
				//m_testKankyo = true;
			}
			else if(document.InnerXml.Contains("dev.withyou"))
			{
				this.Text += " 開発環境";
			}

			button3.Visible = false;
			button5.Visible = false;

			this.notifyIcon1 = new NotifyIcon(this.components);
			string icon = Path.Combine(util.ExeCurrentDir, "WithYou_icon.ico");
			this.notifyIcon1.Icon = new System.Drawing.Icon(icon);
			this.notifyIcon1.Visible = true;
			this.notifyIcon1.Text = "WithYouGWC";
			this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;

            string domain = Environment.UserDomainName;
            if (domain.CompareTo(Global.EPOCH_DOMAIN) == 0)
            {
                this.Activate();
                this.StartPosition = FormStartPosition.Manual;
                this.MaximumSize = new System.Drawing.Size(603, 423);
                this.MinimumSize = new System.Drawing.Size(128, 34);
                this.SizeChanged += new EventHandler(Form1_SizeChanged);
                this.MinimizeBox = false;
                this.ShowInTaskbar = false;
                this.notifyIcon1.Click += new EventHandler(NotifyIcon1_Click);
                this.WindowState = FormWindowState.Normal;
                FormSizeChg();
            }
            else
            {
                this.StartPosition = FormStartPosition.WindowsDefaultLocation;
                this.ShowInTaskbar = false;
                this.WindowState = FormWindowState.Minimized;
                this.notifyIcon1.Click += new EventHandler(NotifyIcon1_Click);
                this.SetAutoSizeMode(AutoSizeMode.GrowOnly);
                this.MinimizeBox = false;
            }

            InterfaceMain();
		}

		void InterfaceMain()
		{
			bool err = false;
			int days = DBAccess.GetStorageDays(ref err);

			m_log = new WithYouGW.Logging(IniFile.init.LogFolder, "", days, listBox1, 1000);

			if (!m_log.LoggingStart())
			{
				MessageBox.Show(Global.MSG_ERR_LOG_FOLDER_CREATE_ERROR, "WithYou");
				notifyIcon1.Visible = false;
				Environment.Exit(0x8020);   // 強制終了	
				return;
			}

			LoggingDisplay(Global.MSG_INFO_START);

			m_client1 = new ServiceReference1.ServiceClient();
			m_client2 = new ServiceReference1.ServiceClient();

			// テスト環境以外はプロキシサーバの設定が必要
			if (!m_testKankyo)
			{
				bool ret = false;
				string domain = Environment.UserDomainName;
				if (domain.CompareTo(Global.EPOCH_DOMAIN) == 0)
				{
					m_proxyAddress = DBAccess.GetEpochProxyServer(ref ret);
				}
				else m_proxyAddress = DBAccess.GetWithProxyServer(ref ret);

				if (ret)
				{
					MessageBox.Show(Global.MSG_ERR_NOENTRY_PROXYSERVER, "WithYou");
					notifyIcon1.Visible = false;
					Environment.Exit(0x8020);   // 強制終了		
					return;
				}
				else
				{
					if (m_proxyAddress.Length != 0)
					{
						BasicHttpBinding binding = (BasicHttpBinding)m_client1.Endpoint.Binding;
						binding.BypassProxyOnLocal = true;
						binding.UseDefaultWebProxy = false;
						binding.ProxyAddress = new Uri(m_proxyAddress);
						m_client1.Endpoint.Binding = binding;

						BasicHttpBinding binding2 = (BasicHttpBinding)m_client2.Endpoint.Binding;
						binding2.BypassProxyOnLocal = true;
						binding2.UseDefaultWebProxy = false;
						binding2.ProxyAddress = new Uri(m_proxyAddress);
						m_client2.Endpoint.Binding = binding2;
					}
				}
			}

			string exception = "";
			if (!CurrentIPAddress(ref exception))
			{
				string msg = Global.MSG_ERR_DONOT_CONNECT_GWSV;
				if (exception.Length != 0)
				{
					//aaaa 20180223 ネットーワークエラーの時は、同じメッセージを出す。
					//if (exception.Contains(Global.ENDPOINT) == true)
					//{
					msg = string.Format(Global.MSG_ERR_NETWORK_ERR);
					//}
				}

				string domain = Environment.UserDomainName;
				if (domain.CompareTo(Global.EPOCH_DOMAIN) == 0)
				{
					//MessageBox.Show("epoch", "WithYou");
				}
				else MessageBox.Show(msg, "WithYou");

				LoggingDisplay(msg);
				notifyIcon1.Visible = false;
				Environment.Exit(0x8020);   // 強制終了		
				return;
			}

			ThreadStart();
		}

		/// <summary>
		/// 
		/// </summary>
        private void ThreadStart()
        {
			//2020.02.02 add
			if (m_in_InitDM == null)
			{
				m_in_InitDM = new Thread(new ThreadStart(MonitorInitDM));
				m_in_InitDM.Start();
			}

			if (m_in_withyou == null)
			{
				m_in_withyou = new Thread(new ThreadStart(MonitorWithYouMain));
				m_in_withyou.Start();
			}

			if (m_in_with == null)
			{
				m_in_with = new Thread(new ThreadStart(MonitorWithMain));
				m_in_with.Start();
			}
		}

		#region WithYou側

		/// <summary>
		/// WithYou監視メイン
		/// </summary>
		private void MonitorWithYouMain()
		{
			string msgUid = "";
			int fileCount = 0;
			string fileNames = "";
			bool err = false;
			int interval = DBAccess.GetServerInterval(ref err);
			int reconnect = DBAccess.GetReConnect(ref err);

			// Webサーバ接続
			m_client1 = new ServiceReference1.ServiceClient();
			if (m_proxyAddress.Length != 0)
			{
				BasicHttpBinding binding = (BasicHttpBinding)m_client1.Endpoint.Binding;
				binding.BypassProxyOnLocal = true;
				binding.UseDefaultWebProxy = false;
				binding.ProxyAddress = new Uri(m_proxyAddress);
				m_client1.Endpoint.Binding = binding;
			}


			//int cnt = 0;
			DateTime d = DateTime.Now;
            bool net_err = false;
			// WithYouに問合せをおこなう
			for (;;)
			{
				try
				{
                    //2018.04.11 changed ネットワーク接続チェック
                    if (m_client1.Ping(m_hospId, m_ipAddress))
                    {
                        //2018.04.20 再接続メッセージ表示
                        if(net_err)
                        {
                            LoggingDisplay(Global.MSG_INFO_RECONNECT);
                            net_err = false;
                        }
                        d = DateTime.Now;
                    }
                    else
                    {
                        LoggingDisplay(Global.MSG_ERR_NETWORK_ERR_PROCESSED);
                        net_err = true;
                        if (DateTime.Now > d.AddSeconds(reconnect))
                        {
                            //aaaa 20180228 ネットーワークエラーの時は、ポップアップメッセージを出す。
                            //MessageBox.Show(Global.MSG_ERR_NETWORK_ERR_PROCESSED, "WithYou");
                            //2018.04.20 changedポップアップで出すメッセージの変更
                            MessageBox.Show(Global.MSG_ERR_NETWORK_ERR_CHK, "WithYou");
                            d = DateTime.Now;
                        }
                        Thread.Sleep(1000 * interval);
                        continue;
                    }

                    //LoggingDisplay("[MonitorWithYouMain] doing. m_client1.ContactWithYouData()");
                    // ファイルがあるかどうか問合せ(エラーの場合は何もしない)
                    if (m_client1.ContactWithYouData(m_hospId, m_ipAddress, ref msgUid, ref fileCount, ref fileNames))
                    {
                        //if (cnt != 0) { LoggingDisplay(Global.MSG_INFO_RECONNECT); }
                        //初期化
                        //cnt = 0;
                        d = DateTime.Now;
						if (fileCount > 0)
						{
							if (GetFiles(msgUid, fileCount, fileNames))
								continue;       // フィル処理後、すぐに次の問合せをおこなう
						}
					}
				}
				catch(Exception ex)
				{
					LoggingDisplay(Global.MSG_ERR_EXCEPTION, "MonitorWithYouMain", ex.Message);
				}

				// GWサーバ監視インターバル時間
				Thread.Sleep(1000 * interval);
			}
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="msgUid"></param>
		/// <param name="count"></param>
		/// <param name="fileNames"></param>
		/// <returns></returns>
		private bool GetFiles(string msgUid, int count, string fileNames)
		{
			bool ret = true;
			string ext = "";
			bool endFlg = false;
			Byte[] mybytearray;

			LoggingDisplay(Global.MSG_INFO_LOAD_WITHYOUFILE_START);

			try
			{
				string[] fileName = SortFileName(fileNames).Split(',');
				for (int i = 0; i < count; i++)
				{
					if (i == count - 1) endFlg = true;
					LogDBG("WebAPI(GetFile)コール msgUid[{0}], fileName[{1}]", msgUid, fileName[i]);
					if (!m_client1.GetFile(out mybytearray, m_hospId, m_ipAddress, msgUid, fileName[i]))
					{
						LoggingDisplay(Global.MSG_ERR_FILE_GET_ERROR, fileName[i]);
						m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName[i], Global.MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT, true);
						continue;       // 次のファイルを実行
					}

					ext = Path.GetExtension(fileName[i]);
                    //2020.01.22 add
                    var filename = Path.GetFileNameWithoutExtension(fileName[i]);
					if (ext.ToLower().CompareTo(".pdf") == 0)
						WriteOfferDocument(mybytearray, msgUid, fileName[i], endFlg);
                    //2020.01.22 add
                    else if(Regex.IsMatch(filename, @"_患者状態情報$"))
                        WriteConditionData(mybytearray, msgUid, fileName[i], endFlg);
                    else if (Regex.IsMatch(filename, @"_患者SOAP情報$"))
                        WriteSOAPData(mybytearray, msgUid, fileName[i], endFlg);
                    else if (Regex.IsMatch(filename, @"_カルテ入力リスト$"))
                        WriteKarteData(mybytearray, msgUid, fileName[i], endFlg);
					//2020.02.04 add
					else if (Regex.IsMatch(filename, @"_WithYou連携データ疾患$"))
						WriteGeneralDiseaseData(mybytearray, msgUid, fileName[i], endFlg);
					else if (Regex.IsMatch(filename, @"_WithYou連携データ服用中薬剤$"))
						WriteTakingMedicinesData(mybytearray, msgUid, fileName[i], endFlg);
					else WriteClinicalData(mybytearray, msgUid, fileName[i], endFlg);
				}
			}
			catch (Exception ex)
			{
				LoggingDisplay(Global.MSG_ERR_EXCEPTION, "GetFiles", ex.Message);
				ret = false;
			}

			LoggingDisplay(Global.MSG_INFO_LOAD_WITHYOUFILE_COMPLETED);

			return ret;
		}

		/// <summary>
		/// ファイル名をCSVファイル、PDFファイルの順にソートしなおす
		/// </summary>
		/// <param name="fileNames"></param>
		/// <returns></returns>
		public string SortFileName(string fileNames)
		{
			string pdfFiles = "";
			string csvFiles = "";
			string delimiter = "";

			string[] wkFileName = fileNames.Split(',');

			for (int i = 0; i < wkFileName.Length; i++)
			{
				if (Path.GetExtension(wkFileName[i]).ToLower().CompareTo(".pdf") == 0)
				{
					if (pdfFiles.Length != 0) pdfFiles += ",";
					pdfFiles += wkFileName[i];
				}
				else
				{
					if (csvFiles.Length != 0) csvFiles += ",";
					csvFiles += wkFileName[i];
				}
			}

			if ((pdfFiles.Length != 0) && (csvFiles.Length != 0))
			{
				delimiter = ",";
			}

			return csvFiles + delimiter + pdfFiles;
		} 

		/// <summary>
		/// 提供文書ファイル情報DB書込み
		/// </summary>
		/// <param name="fileName"></param>
		/// <returns></returns>
		private bool WriteOfferDocument(byte [] byteArray, string msgUid, string fileName, bool endFlg)
		{
			string[] elms = fileName.Split('_');
			string fullPath = Path.Combine(IniFile.init.ProcFolder, fileName);

			// 電カル用提供文書ファイルの作成(同じファイル名が存在した場合はあえて上書き)
			if (!util.ByteArrayToFile(byteArray, fullPath))
			{
				LoggingDisplay(Global.MSG_ERR_PDF_CREATE_ERROR, fileName);
				m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, Global.MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT, true);
				return false;
			}

			// 電子カルテロジック呼び出し(MD-仕様-D096)
			string err = "";
			Torikomi.eTorikomiKekkaType kekka = Torikomi.ProcessPdfFile(fullPath, ref err);

			if (kekka == Torikomi.eTorikomiKekkaType.Success)
			{
				LogDBG("WebApi(NoticeFileOK)コール fileName[{0}]", fileName);
				m_client1.NoticeFileOK(m_hospId, m_ipAddress, msgUid, fileName, endFlg);
			}
			else
			{
				LogDBG("WebApi(NoticeFileError)コール fileName[{0}]", fileName);
				m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, err, endFlg);
			}

			return true;
		}

		/// <summary>
		/// 訪問診療データcsvファイル情報DB書込み
		/// </summary>
		/// <param name="fileName"></param>
		/// <returns></returns>
		private bool WriteClinicalData(byte[] byteArray, string msgUid, string fileName, bool endFlg)
		{

			string fullPath = Path.Combine(IniFile.init.ProcFolder, fileName);

			// 訪問診療データファイルの作成
			if (!util.ByteArrayToFile(byteArray, fullPath))
			{
                //2020.01.22 modify
                //LoggingDisplay(Global.MSG_ERR_CSV_CREATE_ERROR, fileName);
                LoggingDisplay(Global.MSG_ERR_CSV_CREATE_ERROR_CLINICAL, fileName);
				m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, Global.MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT, true);
				return false;
			}

			// 電子カルテロジック呼び出し(MD-仕様-D096)
			string err = "";
            //2020.01.22 modify
            //Torikomi.eTorikomiKekkaType kekka = Torikomi.ProcessCsvFile(fullPath, ref err);
            Torikomi.eTorikomiKekkaType kekka = Torikomi.ProcessCsvFileClinical(fullPath, ref err);

			if (kekka == Torikomi.eTorikomiKekkaType.Success)
			{
				LogDBG("WebApi(NoticeFileOK)コール fileName[{0}]", fileName);
				m_client1.NoticeFileOK(m_hospId, m_ipAddress, msgUid, fileName, endFlg);
			}
			else
			{
				LogDBG("WebApi(NoticeFileError)コール fileName[{0}]", fileName);
				m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, err, endFlg);
			}

			return true;
		}

        //2020.01.22 add
        /// <summary>
        /// 患者状態データcsvファイル情報DB書込み
        /// </summary>
        /// <returns></returns>
        private bool WriteConditionData(byte[] byteArray, string msgUid, string fileName, bool endFlg)
        {
            string fullPath = Path.Combine(IniFile.init.ProcFolder, fileName);

            // 患者状態データファイルの作成
            if (!util.ByteArrayToFile(byteArray, fullPath))
            {
                LoggingDisplay(Global.MSG_ERR_CSV_CREATE_ERROR_CONDITION, fileName);
                m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, Global.MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT, true);
                return false;
            }

            // 電子カルテロジック呼び出し(MD-仕様-D096)
            string err = "";
            Torikomi.eTorikomiKekkaType kekka = Torikomi.ProcessCsvFileCondition(fullPath, ref err);

            if (kekka == Torikomi.eTorikomiKekkaType.Success)
            {
                LogDBG("WebApi(NoticeFileOK)コール fileName[{0}]", fileName);
                m_client1.NoticeFileOK(m_hospId, m_ipAddress, msgUid, fileName, endFlg);
            }
            else
            {
                LogDBG("WebApi(NoticeFileError)コール fileName[{0}]", fileName);
                m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, err, endFlg);
            }

            return true;
        }

        //2020.01.22 add
        /// <summary>
        /// 患者SOAPデータcsvファイル情報DB書込み
        /// </summary>
        /// <returns></returns>
        private bool WriteSOAPData(byte[] byteArray, string msgUid, string fileName, bool endFlg)
        {
            string fullPath = Path.Combine(IniFile.init.ProcFolder, fileName);

            // 患者SOAPデータファイルの作成
            if (!util.ByteArrayToFile(byteArray, fullPath))
            {
                LoggingDisplay(Global.MSG_ERR_CSV_CREATE_ERROR_SOAP, fileName);
                m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, Global.MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT, true);
                return false;
            }

            // 電子カルテロジック呼び出し(MD-仕様-D096)
            string err = "";
            Torikomi.eTorikomiKekkaType kekka = Torikomi.ProcessCsvFileSOAP(fullPath, ref err);

            if (kekka == Torikomi.eTorikomiKekkaType.Success)
            {
                LogDBG("WebApi(NoticeFileOK)コール fileName[{0}]", fileName);
                m_client1.NoticeFileOK(m_hospId, m_ipAddress, msgUid, fileName, endFlg);
            }
            else
            {
                LogDBG("WebApi(NoticeFileError)コール fileName[{0}]", fileName);
                m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, err, endFlg);
            }

            return true;
        }

        //2020.01.24 add
        /// <summary>
        /// カルテ入力リストcsvファイル情報DB書込み
        /// </summary>
        /// <returns></returns>
        private bool WriteKarteData(byte[] byteArray, string msgUid, string fileName, bool endFlg)
        {
            string fullPath = Path.Combine(IniFile.init.ProcFolder, fileName);

            // カルテ入力リストファイルの作成
            if (!util.ByteArrayToFile(byteArray, fullPath))
            {
                LoggingDisplay(Global.MSG_ERR_CSV_CREATE_ERROR_KARTE, fileName);
                m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, Global.MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT, true);
                return false;
            }

            // 電子カルテロジック呼び出し(MD-仕様-D096)
            string err = "";
            Torikomi.eTorikomiKekkaType kekka = Torikomi.ProcessCsvFileKarte(fullPath, ref err);

            if (kekka == Torikomi.eTorikomiKekkaType.Success)
            {
                LogDBG("WebApi(NoticeFileOK)コール fileName[{0}]", fileName);
                m_client1.NoticeFileOK(m_hospId, m_ipAddress, msgUid, fileName, endFlg);
            }
            else
            {
                LogDBG("WebApi(NoticeFileError)コール fileName[{0}]", fileName);
                m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, err, endFlg);
            }

            return true;
        }

		//2020.02.04 add
		/// <summary>
		/// WithYou連携データ疾患csvファイル情報DB書込み
		/// </summary>
		/// <returns></returns>
		private bool WriteGeneralDiseaseData(byte[] byteArray, string msgUid, string fileName, bool endFlg)
		{
			string fullPath = Path.Combine(IniFile.init.ProcFolder, fileName);

			// WithYou連携データ疾患ファイルの作成
			if (!util.ByteArrayToFile(byteArray, fullPath))
			{
				LoggingDisplay(Global.MSG_ERR_CSV_CREATE_ERROR_GENERALDISEASE, fileName);
				m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, Global.MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT, true);
				return false;
			}

			// 電子カルテロジック呼び出し(MD-仕様-D096)
			string err = "";
			Torikomi.eTorikomiKekkaType kekka = Torikomi.ProcessCsvFileGeneralDisease(fullPath, ref err);

			if (kekka == Torikomi.eTorikomiKekkaType.Success)
			{
				LogDBG("WebApi(NoticeFileOK)コール fileName[{0}]", fileName);
				m_client1.NoticeFileOK(m_hospId, m_ipAddress, msgUid, fileName, endFlg);
			}
			else
			{
				LogDBG("WebApi(NoticeFileError)コール fileName[{0}]", fileName);
				m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, err, endFlg);
			}

			return true;
		}

		//2020.02.04 add
		/// <summary>
		/// WithYou連携データ服用中薬剤csvファイル情報DB書込み
		/// </summary>
		/// <returns></returns>
		private bool WriteTakingMedicinesData(byte[] byteArray, string msgUid, string fileName, bool endFlg)
		{
			string fullPath = Path.Combine(IniFile.init.ProcFolder, fileName);

			// WithYou連携データ服用中薬剤ファイルの作成
			if (!util.ByteArrayToFile(byteArray, fullPath))
			{
				LoggingDisplay(Global.MSG_ERR_CSV_CREATE_ERROR_TAKINGMEDICINES, fileName);
				m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, Global.MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT, true);
				return false;
			}

			// 電子カルテロジック呼び出し(MD-仕様-D096)
			string err = "";
			Torikomi.eTorikomiKekkaType kekka = Torikomi.ProcessCsvFileTakingMedicines(fullPath, ref err);

			if (kekka == Torikomi.eTorikomiKekkaType.Success)
			{
				LogDBG("WebApi(NoticeFileOK)コール fileName[{0}]", fileName);
				m_client1.NoticeFileOK(m_hospId, m_ipAddress, msgUid, fileName, endFlg);
			}
			else
			{
				LogDBG("WebApi(NoticeFileError)コール fileName[{0}]", fileName);
				m_client1.NoticeFileError(m_hospId, m_ipAddress, msgUid, fileName, err, endFlg);
			}

			return true;
		}

		/// <summary>
		/// 接続可能なIPアドレスを特定する
		/// </summary>
		/// <returns></returns>
		bool CurrentIPAddress(ref string message)
		{
			bool ret = false;
			string ipAddr = "";

			// 物理インターフェース情報をすべて取得
			var interfaces = NetworkInterface.GetAllNetworkInterfaces();

			// 各インターフェースごとの情報を調べる
			foreach (var adapter in interfaces)
			{
				// 有効なインターフェースのみを対象とする
				if (adapter.OperationalStatus != OperationalStatus.Up) continue;

				// インターフェースに設定されたIPアドレス情報を取得
				var properties = adapter.GetIPProperties();

				// 設定されているすべてのユニキャストアドレスについて
				foreach (var unicast in properties.UnicastAddresses)
				{
					if (unicast.Address.AddressFamily == AddressFamily.InterNetwork)
					{
						// IPv4アドレス
						ipAddr = unicast.Address.ToString();

						if (m_client1.CheckUser(m_hospId, ipAddr, ref message))
						//if (m_client.CheckUser(m_hospId, ipAddr))
						{
							m_ipAddress = ipAddr;
							LoggingDisplay(Global.MSG_INFO_CONNECT_SERVER_CURRENT_IP, ipAddr);
							return true;
						}
						else
						{
							if (message.Length != 0)
							{
								//MessageBox.Show(message);
								LoggingDisplay(Global.MSG_ERR_EXCEPTION, "CurrentIPAddress" ,message);
								return false;
							}
						}
						//break;
					}
					//else if (unicast.Address.AddressFamily == AddressFamily.InterNetworkV6)
					//{
					//	ipAddr = unicast.Address.ToString();
					//	LoggingDisplay(ipAddr);
					//	// IPv6アドレス
					//	//ipaddress.Add(unicast.Address);
					//}
				}
			}
			return ret;
		}
		#endregion

		#region 電カル側

		/// <summary>
		/// 電子カルテ監視メイン
		/// </summary>
		private void MonitorWithMain()
        {
            bool err = false;
			int interval = DBAccess.GetKrtInterval(ref err);

			// 出力先フォルダ設定
			string outputPath = DBAccess.GetOutputPath(ref err);
			string csvPath = string.Format(@"\\{0}\{1}", Common.GetDBServerName(), outputPath);
			string csvPath2 = string.Format(@"{0}GW", csvPath);  // トリガ時に使用するフォルダ

			util.CreateDirectory(csvPath2);

			m_create_csv_lastdate = "";

			// path内のファイル名を取得
			string []fileNames = Directory.GetFiles(csvPath);
			foreach (string file in fileNames)
			{
				// LCKファイルの更新日付を取得
				if (Path.GetExtension(file).CompareTo(Global.C_LCK_Extension) == 0)
				{
					string []elm = Path.GetFileNameWithoutExtension(file).Split('_');
					m_create_csv_lastdate = elm[1];
					break;
				}
			}
            LogDBG("最終CSV作成日時[{0}]", m_create_csv_lastdate);

			// WithYouの取込フラグ監視
			for (;;)
            {
				try
				{
					MonitorCsvOutPath(csvPath);
					MonitorWithDB(csvPath2);
				}
				catch(Exception ex)
				{
					LoggingDisplay(Global.MSG_ERR_EXCEPTION, "MonitorWithMain", ex.Message);
				}

				// 電子カルテ監視インターバル時間
				Thread.Sleep(1000 * interval);
			}
        }

		/// <summary>
		/// 電カルによるファイル出力フォルダの監視
		/// </summary>
		/// <param name="csvPath"></param>
		/// <returns></returns>
		private bool MonitorCsvOutPath(string csvPath)
		{
			//LoggingDisplay($"[MonitorCsvOutPath] csvPath: {csvPath}");

			bool ret = true;
			//bool firstSet = false;
			bool allSet = false;
			
			// path内のファイル名を取得
			string []fileNames = Directory.GetFiles(csvPath);
			foreach (string file in fileNames)
			{
				// ".LCK"があり"取込中"または"作成中"があった場合は終了
				if (Path.GetExtension(file).CompareTo(Global.C_LCK_Extension) == 0)
				{
					// "作成完了"ファイルのチェック
					if (file.IndexOf(Global.C_SakuseiEndFileName) > 0)
					{
						string[] elm = Path.GetFileNameWithoutExtension(file).Split('_');

						if (m_create_csv_lastdate.Length == 0)
						{
							m_create_csv_lastdate = elm[1];
							allSet = true;
                            LogDBG("初回データ取込み");
							break;
						}

						if (m_create_csv_lastdate.CompareTo(elm[1]) == 0)
						{
                            LogDBG("前回取込みと変更無しのため処理なし");
							return false;   // 変更なしなので処理なし
						}
						else
						{
							m_create_csv_lastdate = elm[1];
                            LogDBG("取込み日時更新[{0}]", m_create_csv_lastdate);
							break;
						}
					}
					else
					{
                        LogDBG("作成完了以外のLCKファイルが存在するため処理なし");
						return false;		// 作成完了以外のLCKファイルがあったため処理なし
					}
				}
			}
			if (fileNames.Length == 0) return false;

			int kind = 0;
			string patientFileName = "";
			fileNames = Directory.GetFiles(csvPath);

			foreach (var file in fileNames)
			{
				if ((kind = FileKind(file)) != 0)
				{
					// 2017.08.22 仕様変更 Outputフォルダの全てを送信する
					// 患者情報ファイルは最後に送信
					if (kind == (int)Global.eFileName.patient)
					{
						patientFileName = file;
						continue;
					}
					else
					{
                        SendFileData(file, kind, false, false);
					}
				}

			}

            if (patientFileName.Length != 0)
            {
                SendFileData(patientFileName, (int)Global.eFileName.patient, true, true);

                //2020.01.17 added
                InitDM.doing(this, false);
            }

			return ret;
		}

        /// <summary>
        /// 電子カルテDBを参照し、set_flgがたっていたらファイルに吐き出し
        /// </summary>
        /// <param name="csvPath"></param>
        /// <returns></returns>
        private bool MonitorWithDB(string csvPath)
        {
            bool ret = true;
            int kind = 0;

            // DB参照でレコード単位の変更があれば出力フォルダにファイル作成
            IEnumerable<string> patientIds;
            if (WithYouRenkeiCSV.CSVMakeProcessRecord(csvPath, out patientIds))
            {
                //2019.08.01 mod sugano　WITHYOU-395対応
                //同時刻に作成されたCSVファイルの送信順がおかしくなる件の対応
                string[] fileNames = Directory.GetFiles(csvPath);
                foreach (var file in fileNames)
                {
                    if ((kind = FileKind(file)) != 0)
                    {
                        //患者は後で送るからスキップする
                        if (kind != (int)Global.eFileName.patient)
                        {
                            kind = ConvertKind(kind);
                            SendFileData(file, kind, true, true);
                        }
                    }
                }

                //患者情報送信
                string fileHeaderName = Global.C_CSV_KanjaInfo + "*";
                // path内のファイル名を取得
                string[] fileNamesKanja = Directory.GetFiles(csvPath, fileHeaderName);
                foreach (var file in fileNamesKanja)
                {
                    if ((kind = FileKind(file)) != 0)
                    {
                        kind = ConvertKind(kind);
                        SendFileData(file, kind, true, true);
                    }
                }

                //2020.01.17 added
                if (patientIds != null && patientIds.Any())
                {
                    InitDM.doing(this, false, patientIds);
                }
            }

            return ret;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        private int ConvertKind(int kind)
		{
			//2020.02.04 add
			if (100 <= kind) return kind;

            //int ret = kind;
            //20180412 changed
            //const int kindRecord = 3;
            const int kindRecord = 4;

            if (kind == (int)Global.eFileName.kasan) kind = (int)Global.eFileName.kasan_record;
			else kind += kindRecord;

			return kind;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="fileName"></param>
		/// <returns></returns>
		private int FileKind(string fileName)
		{
			int kind = 0;

			string[] elms = fileName.Split('_');
			if (elms.Length != 3) return 0;

			//2020.01.31 add
			switch (elms[1])
			{
				case "既往歴": return (int)Global.eFileName.kioureki;
				case "服用中薬剤": return (int)Global.eFileName.fukuyoutyuu_yakuzai;
			}

			//2020.02.04 add
			switch (elms[1])
			{
				case "既往歴REC": return (int)Global.eFileName.kioureki_record;
				case "服用中薬剤REC": return (int)Global.eFileName.fukuyoutyuu_yakuzai_record;
			}

			for (int i = 0; i < gb.mst_withfile.Length; i++)
			{
				if (gb.mst_withfile[i].CompareTo(elms[1]) == 0)
				{
					kind = i;
					break;
				}
			}

			return kind;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		private bool SendFileData(string fullPath, int kind, bool endFlag, bool startFlag)
		{
			bool ret = true;
			int total = 0;
			int processed = 0;
			bool errDisplay = true;
            bool inierr = false;
            int interval = DBAccess.GetServerInterval(ref inierr);
            int reconnect = DBAccess.GetReConnect(ref inierr);
            int retry_cnt = DBAccess.GetReTryCnt(ref inierr);

            string fileName = Path.GetFileName(fullPath);

			string[] elms = fileName.Split('_');
			if (elms.Length != 3) return false;

			Byte[] data;
			util.FileToByteArray(out data, fullPath);

			LoggingDisplay(Global.MSG_INFO_CSV_PROCESS_START, fileName);

			Thread.Sleep(1000 * 1);	// uid担保のため

			string err = "";
			string date = DateTime.Now.ToString("yyyyMMddHHmmss");
			string msgUid = string.Format("{0}_{1}", m_hospId, date);

			//2020.02.02 modify
			////2018.04.13 added
			//int sendkind = gb.srv_kind[kind];
			int sendkind = 0;
			if (kind < gb.srv_kind.Length)
			{
				sendkind = gb.srv_kind[kind];
			}
			else
			{
				sendkind = kind;
			}

			LogDBG("WebAPI(SendData)コール fileName[{0}], kind[{1}], sendkind[{2}]", fileName, kind, sendkind);

			bool retry = true;
            DateTime d = DateTime.Now;
            while (retry)
			{
                //2018.04.11 changed ネットワーク接続チェック
                if (m_client2.Ping(m_hospId, m_ipAddress))
                {
                    d = DateTime.Now;
                }
                else
                {
                    LoggingDisplay(Global.MSG_ERR_NETWORK_ERR_SEND);
                    //2018.04.20 changed MonitorWithyouMainでポップアップメッセージが出るからここでは出さない
                    //if (DateTime.Now > d.AddSeconds(reconnect))
                    //{
                    //    //aaaa 20180228 ネットーワークエラーの時は、ポップアップメッセージを出す。
                    //    MessageBox.Show(Global.MSG_ERR_NETWORK_ERR_PROCESSED, "WithYou");
                    //    d = DateTime.Now;
                    //}
                    Thread.Sleep(1000 * interval);
                    continue;
                }
                //ret = m_client2.SendData(m_hospId, m_ipAddress, msgUid, kind, fileName, data, ref err, endFlag, startFlag);
                ret = m_client2.SendData(m_hospId, m_ipAddress, msgUid, sendkind, fileName, data, ref err, endFlag, startFlag);
                if (ret == false)
				{
					if (err.Contains(Global.CHANEL) == true)
					{
						//LoggingDisplay(err);
		
						int zenkai = 0;
						int cnt = 0;
						for (;;)
						{
							ServiceReference1.ServiceClient sc = new ServiceReference1.ServiceClient();
							if (m_proxyAddress.Length != 0)
							{
								BasicHttpBinding binding = (BasicHttpBinding)sc.Endpoint.Binding;
								binding.BypassProxyOnLocal = true;
								binding.UseDefaultWebProxy = false;
								binding.ProxyAddress = new Uri(m_proxyAddress);
								sc.Endpoint.Binding = binding;
							}

							ret = sc.GetProcessedStatus(m_hospId, m_ipAddress, msgUid, ref total, ref processed);

							if (ret)
							{
								LoggingDisplay(Global.MSG_INFO_CSV_SEND_OK, fileName);

                                //2018.07.11 added タイムアウト後にサーバ登録処理が正常に終わったらファイルを消す
                                if (kind >= (int)Global.eFileName.visit_record)
                                {
                                    Torikomi.MoveToDoneFolder(fullPath);
                                    DBAccess.ChangeIDMask(kind);
                                }
                                retry = false;
								break;
							}
							else
							{
								if ((total == 0) && (processed == 0))
								{
									if (errDisplay) {
										//aaaa 20180228 ネットーワークエラーの時は、ポップアップメッセージを出す。
										LoggingDisplay(Global.MSG_ERR_NETWORK_ERR_PROCESSED);
										MessageBox.Show(Global.MSG_ERR_NETWORK_ERR_PROCESSED, "WithYou");
										//string domain = Environment.UserDomainName;
										//if (domain.CompareTo(Global.EPOCH_DOMAIN) == 0)
										//{
										//	//MessageBox.Show("epoch", "WithYou");
										//}
										//else MessageBox.Show(Global.MSG_ERR_NETWORK_ERR_PROCESSED, "WithYou");
										errDisplay = false;
									}
									retry = true;
									Thread.Sleep(1000 * 5);
								}
								else
								{
									if (zenkai == processed) cnt++;
									else
									{
										zenkai = processed;
										cnt = 0;
									}
									if (cnt == 3)
									{
										// エラーとする
										string msg = string.Format(Global.MSG_ERR_REGIST_MASTER, m_hospId, fileName);
										LoggingDisplay(msg);
                                        if (kind >= (int)Global.eFileName.visit_record)
                                        {
                                            Torikomi.MoveToErrorFolder(fullPath);
                                            DBAccess.ChangeIDError(kind);
                                        }
										retry = false;
										break;
									}
									else Thread.Sleep(1000 * 10);
								}
							}
						}
					}
					else if(err.Contains(Global.MASTER) == true)
					{
                        //2018.04.16 changed 一定回数リトライしてもダメな場合は送らなくする
                        bool retry_ret = false;
                        for (int j = 0; j < retry_cnt; j++)
                        {
                            LoggingDisplay("CSV送信リトライ回数:{0}", (j + 1).ToString());
                            retry_ret = m_client2.SendData(m_hospId, m_ipAddress, msgUid, sendkind, fileName, data, ref err, endFlag, startFlag);
                            if (retry_ret) break;
                        }
                        if (retry_ret)
                        {
                            LoggingDisplay(Global.MSG_INFO_CSV_SEND_OK, fileName);
                            if (kind >= (int)Global.eFileName.visit_record)
                            {
                                Torikomi.MoveToDoneFolder(fullPath);
                                DBAccess.ChangeIDMask(kind);
                            }
                        }
                        else
                        {
                            LoggingDisplay(err);
                            //With側のトリガーテーブルに送らないフラグ(異常終了)を立てる
                            if (kind >= (int)Global.eFileName.visit_record)
                            {
                                Torikomi.MoveToErrorFolder(fullPath);
                                DBAccess.ChangeIDError(kind);
                            }
                        }
                        ret = retry_ret;
                        retry = false;
                    }
					else
					{
						//LoggingDisplay(Global.MSG_ERR_FILE_SEND_ERROR, fileName, err);
						LoggingDisplay(err);
                        if (kind >= (int)Global.eFileName.visit_record)
                        {
                            Torikomi.MoveToErrorFolder(fullPath);
                            DBAccess.ChangeIDError(kind);
                        }
                        retry = false;
					}
				}
				else
				{
					//ret = m_client2.GetProcessedStatus(m_hospId, m_ipAddress, msgUid, ref total, ref processed);
					LoggingDisplay(Global.MSG_INFO_CSV_SEND_OK, fileName);
					if (kind >= (int)Global.eFileName.visit_record)
					{
						Torikomi.MoveToDoneFolder(fullPath);
						DBAccess.ChangeIDMask(kind);
					}
					retry = false;
				}
			}

			LoggingDisplay(Global.MSG_INFO_CSV_PROCESS_COMPLETED, fileName);
            
			return ret;
		}
		#endregion

		/// <summary>
		/// 終了ボタン
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button1_Click(object sender, EventArgs e)
		{
			// 終了確認ダイアログ表示
			if (MessageBox.Show(
					"本当に終了しますか？  ", "WithYou",
					MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				notifyIcon1.Visible = false;
                this.Hide();
                Environment.Exit(0x8020);   // 強制終了			
			}
		}

		/// <summary>
		/// 画面非表示ボタン
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button2_Click(object sender, EventArgs e)
		{
            string domain = Environment.UserDomainName;
            if (domain.CompareTo(Global.EPOCH_DOMAIN) == 0)
            {
                this.WindowState = FormWindowState.Normal;
                FormSizeChg();
            }
            else
            {
                this.Hide();
                visuble = false;
            }
                
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button3_Click(object sender, EventArgs e)
		{
			//try
			//{
			//	// DEBUG用
			//	// 出力先フォルダ設定
			//	string outputPath = DBAccess.GetOutputPath();
			//	string csvPath = string.Format(@"\\{0}\{1}", Common.GetDBServerName(), outputPath);
			//	WithYouRenkeiCSV.CSVMakeProcess(csvPath);
			//	//
			//	//MonitorWithMain();
			//}
			//catch (Exception ex)
			//{
			//	string a = ex.ToString();
			//}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button4_Click(object sender, EventArgs e)
		{
			//bool ret = m_client.NoticeFileOK(m_hospId, m_ipAddress, m_msgUid, m_fileName, true);
			//LoggingDisplay("NoticeFileOK=[{0}]", ret);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button5_Click(object sender, EventArgs e)
		{
			if(Global.DBG_FLG) util.ExecProcess("notepad", false, m_log.LogFileName);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void listBox1_DoubleClick(object sender, EventArgs e)
		{
			if (Global.DBG_FLG) util.ExecProcess("notepad", false, m_log.LogFileName);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (e.CloseReason == CloseReason.UserClosing)　e.Cancel = true;
            string domain = Environment.UserDomainName;
            if (domain.CompareTo(Global.EPOCH_DOMAIN) == 0)
            {
                this.WindowState = FormWindowState.Normal;
                FormSizeChg();
            }
            else
            {
                this.Hide();
                visuble = false;
            }
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void NotifyIcon1_Click(object sender, EventArgs e)
		{
			switch (((MouseEventArgs)e).Button)
			{
				case MouseButtons.Left:
					break;
				default:
					return;
			}

			if (visuble)
			{
				this.Hide();
				visuble = false;
			}
			else
			{
				this.WindowState = FormWindowState.Normal;
				this.Show();
				this.Activate();
				visuble = true;
			}
		}

		//
		// ロギング
		//
		public static void LogDBG(string format, params object[] arg)
		{
			//if (Form1.m_config.init.dbg == 1)
			if (Global.DBG_FLG)
			{
				LoggingDisplay("..." + format, arg);
			}
			//else { 
			//	LoggingDisplay("..." + format, arg);
			//}
		}
		public void LoggingS(string format, params object[] arg) { m_log.Str(format, false, arg); }
		public static void Logging(string format, params object[] arg) { m_log.Str(format, m_logDisplay, arg); }
		public static void LoggingDisplay(string format, params object[] arg) { m_log.Str(format, true, arg); }
		//public static Config GWConfig { get { return m_config; } }
		public static ReadIniData GWConfig { get { return m_iniData; } }

		private void endToolStripMenuItem_Click_1(object sender, EventArgs e)
		{
			// 終了確認ダイアログ表示
			if (MessageBox.Show(
					"本当に終了しますか？  ", "WithYou",
					MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				notifyIcon1.Visible = false;
				Environment.Exit(0x8020);   // 強制終了			
			}
		}

		private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
		{
			return;
		}
        private void FormSizeChg()
        {
            this.Width = 128;
            this.Height = 34;
            int screen_width = Screen.PrimaryScreen.WorkingArea.Width;
            int screen_height = Screen.PrimaryScreen.WorkingArea.Height;

            this.Left = screen_width - this.Width;
            this.Top = screen_height - this.Height;
        }
        private void Form1_SizeChanged(object sender, System.EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.WindowState = FormWindowState.Normal;
                FormSizeChg();
            }
        }

		#region 一括既往歴・服用中薬剤情報取得

		private void MonitorInitDM()
		{
			InitDM.doing(this, true);
		}

		private static class InitDM
		{

			public static bool doing(Form1 form1, bool isManageFlag, IEnumerable<string> patientIds)
			{
				try
				{
					var rtn = true;

					//2020.02.12 modify
					//isManageFlag == true、且つ、IsDoing == true、の場合、後続処理可能
					//isManageFlag == false、且つ、IsDoing == false、の場合、後続処理可能
					//-> isManageFlag と IsDoing が異なる場合、処理中止
					//LoggingDisplay($"[InitDM.doing] isManageFlag: {isManageFlag}");
					//処理が可能か確認
					var isdoing = IsDoing();
					if (isManageFlag != isdoing) return true;

					//出力先フォルダーを準備
					var err = false;
					var csvPath = GetCreateOutputPath(out err);

					//出力と送信
					rtn = WithYouRenkeiCSV.CSVMakeInitDM(csvPath, patientIds);
					if (rtn)
					{
						var fileNames = Directory.GetFiles(csvPath);
						var resSend = true;
						foreach (var file in fileNames)
						{
							var fileName = Path.GetFileName(file);
							//LoggingDisplay($"[InitDM.doing] fileName: {fileName}");
							var kind = form1.FileKind(fileName);
							//LoggingDisplay($"[InitDM.doing] kind: {kind}");
							if (kind != 0)
							{
								//kind = form1.ConvertKind(kind);
								resSend = form1.SendFileData(file, kind, true, true);
								if (!resSend) { break; }
							}
						}

						if (isManageFlag && resSend)
						{
							//処理済フラグを設定
							rtn = DBAccess.UpdateDoneInitDM();
						}
					}

					return rtn;
				}
				catch (Exception ex)
				{
					LoggingDisplay(Global.MSG_ERR_EXCEPTION, "InitDM.doing", ex.ToString());
					return false;
				}
			}

			public static bool doing(Form1 form1, bool isManageFlag)
			{
				return doing(form1, isManageFlag, null);
			}

			public static bool IsDoing()
			{
				return DBAccess.GetDoingInitDM();
			}

			private static string GetCreateOutputPath(out bool err)
			{
				err = false;
				string outputPath = DBAccess.GetOutputPath(ref err);
				string csvPath = string.Format(@"\\{0}\{1}", Common.GetDBServerName(), outputPath);
				string csvPath3 = string.Format(@"{0}GW_INIT_DM", csvPath);
				util.CreateDirectory(csvPath3);
				return csvPath3;
			}

		}

		#endregion

    }
}