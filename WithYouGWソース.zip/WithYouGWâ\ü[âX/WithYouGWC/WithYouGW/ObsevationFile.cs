﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Data;
using System.Collections;

namespace LinkAxisGW
{
	// GetPatient用検索条件フラグ
	enum SearchFlg{
		HospPatientID = 1,		// 病院IDと患者IDで検索
		PatInfo = 2				// 患者カナ名、誕生日、性別で検索(複数データが戻る可能性あり)
	};

	public class StudyInfo
	{
		string m_suid="";
		int m_counter = 0;
		Hashtable seidList = new Hashtable();

		public StudyInfo(string suid)
		{
			m_suid = suid;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="seid"></param>
		public void SetSEID(string seid)
		{
			if (seidList.ContainsValue(seid) == true)
			{
				return;
			}
			else
			{
				seidList.Add(m_counter, seid);
				m_counter++;
			}
		}

		/// <summary>
		/// メタファイル設定用文字列作成
		/// SUID(SEUID1;SEUID2・・)
		/// </summary>
		/// <returns></returns>
		public string CreateMetaString()
		{
			string str = "";
			string seid = "";

			//int i = 0;
			foreach (string value in seidList.Values)
			{
				if (seid.Length != 0) seid += ';';
				seid += value;
			}

			str = string.Format("{0}({1})",m_suid, seid);

			return str;
		}


	}

	/// <summary>
	/// 
	/// </summary>
	public class FileInfo
	{
		public FTPSSendV1.CompressSend cmpFtp;

		string m_zipFileName = "";
		string m_metaFileName = "";
		string m_zipFileFullPath = "";
		string m_metaFileFullPath = "";
		string m_zipBasePath;

		string m_dataPath = "";
		string m_dataFullPath = "";

		string m_metaString = "";
		string m_addString = "";

		/// <summary>
		/// 
		/// </summary>
		/// <param name="prefix"></param>
		/// <param name="hospID"></param>
		/// <param name="patientID"></param>
		/// <param name="chikiID"></param>
		/// <param name="category"></param>
		/// <param name="basePath"></param>
		public FileInfo(string prefix, string hospID, string patientID, string chikiID, string category, string methID, string basePath)
		{
			string now = NowTime();
			string today = Today();
			string time = Time();
			
			string work = "";
			if(prefix.CompareTo("DCM") == 0) work = "D";
			else work = "J";

			cmpFtp = new FTPSSendV1.CompressSend();

			// ファイル名
			m_zipFileName = string.Format(@"{0}_{1}_{2}.zip", prefix, chikiID, now);
			m_metaFileName = string.Format(@"{0}_{1}_{2}.meta", prefix, chikiID, now);
			
			// フルパス名
			m_zipFileFullPath = string.Format(@"{0}\{1}", basePath, m_zipFileName);
			m_metaFileFullPath = string.Format(@"{0}\{1}", basePath, m_metaFileName);

			// zip用保存カレントパス // perfixはZIP保存ファイルにはいれないように変更
			//m_dataPath = string.Format(@"{0}\{1}\{2}", chikiID, prefix, today);
			m_dataPath = string.Format(@"{0}\{1}\", chikiID, today);
			string workPath = string.Format("{0}{1}", work, time);
			//dataFullPath = string.Format(@"{0}\{1}", basePath, dataPath);
			//zipBasePath = string.Format(@"{0}\{1}\", basePath, chikiID);	// Compress関数に渡すzipのオリジナルパス
			m_dataFullPath = string.Format(@"{0}\{1}\{2}", basePath, workPath, m_dataPath);
			m_zipBasePath = string.Format(@"{0}\{1}\", basePath, workPath);

			// 施設ID,患者ID,地域ID,日付,パス,カテゴリ
			m_metaString = string.Format("{0},{1},{2},{3},{4},{5}", hospID, patientID, chikiID, today, m_zipFileName, category);

			// DJPEG時はカテゴリの後ろにMETH_ID,REGIST_USERの情報を追加
			if (prefix.CompareTo("DJPG") == 0)
			{
				m_metaString += string.Format(",{0},", methID);
			}
			else m_metaString += string.Format(",,");
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public bool CreateDir()
		{
			bool ret = true;
			ret = util.CreateDirectory(m_dataFullPath);
			return ret;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public bool SendFile()
		{
			bool ret = true;

			// メタファイル作成
			if (m_addString.Length != 0) m_metaString += m_addString;
			if (CreateMetaFile() == false)
			{
				return false;
			}

			// Zipファイル作成
			if (CreateZipFile() == false)
			{
				return false;
			}

			// FTP送信
			if (FtpFile() == false)
			{
				return false;
			}

			// フォルダ削除
			if (ClearDir() == false) return false;

			return ret;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public bool ClearDir()
		{
			bool ret = true;

			// zip用フォルダ削除
			try
			{
				Directory.Delete(m_zipBasePath, true);
			}
			catch { ret = false; }

			File.Delete(m_zipFileFullPath);
			File.Delete(m_metaFileFullPath);

			return ret;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		private bool CreateMetaFile()
		{
			bool ret = true;

			if (!util.StringToFile(m_metaString, m_metaFileFullPath))
			{
				ret = false;
			}

			return ret;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		private bool CreateZipFile()
		{
			bool ret = true;

			cmpFtp.CompressFile(m_zipBasePath, m_zipFileFullPath);

			return ret;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		private bool FtpFile()
		{
			bool ret = true;

			// 中央側ではmetaファイルを発見し、zipファイルを特定のため先にzipファイルを送信する

			// zipファイル送信
			if (cmpFtp.ftpssend(m_zipFileFullPath, "192.168.0.220", "ftpuser", "ftptest-001") == -1)
			{
				ret = false;
			}

			// metaファイル送信
			if (cmpFtp.ftpssend(m_metaFileFullPath, "192.168.0.220", "ftpuser", "ftptest-001") == -1)
			{
				ret = false;
			}

			// DEBUG
			//cmpFtp.CompressFile(zipBasePath, zipFileFullPath);

			return ret;
		}

		/// <summary>
		/// 本日日付(yyyyMMdd形式)
		/// </summary>
		/// <returns></returns>
		private string Today()
		{
			string today = util.NowDate("yyyyMMdd");
			return today;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		private string NowTime()
		{
			string now = util.NowDate("yyyyMMddHHmmss");
			return now;
		}

		private string Time()
		{
			string time = util.NowDate("HHmmss");
			return time;
		}

		public string DataPath { get { return m_dataPath; } }
		public string DataFullPath { get { return m_dataFullPath; } }
		public string AddMetaString { set { m_addString = value; } }
	}

	/// <summary>
	/// ファイル監視クラス
	/// ※ このクラスは他のファイル監視システムにも処理を反映する
	/// </summary>
	class ObsevationFile
	{
		public Form1 m_parent;
		public FTPSSendV1.GetPatient m_getPatient;
		public string m_tmpPath = "";

		// プロパティ
		public Config ConfigFile { get { return m_parent.m_config; } }

		// Logging
		public void Logging(string str) { m_parent.LoggingS(str); }
		public void Logging(string format, params object[] arg) { m_parent.LoggingS(format, arg); }
	}

	// DICOM解析機能(患者IDの変換処理)
	/// <summary>
	/// DICOMファイル監視
	/// DICOMファイルのJPEG化をおこないOriginalDICOMファイルとともに上位GWに送信する
	/// </summary>
	class ObservationFileDicom : ObsevationFile
	{
		public bool m_idChange = true;		// DICOMをオリジナルで送信ならfalse,IDを書き換えるならtrue

		FileInfo dcmInfo = null;
		FileInfo djpgInfo = null;
		Hashtable suidList = new Hashtable();

		public ObservationFileDicom(Form1 p)
		{
			m_parent = p;
			m_getPatient = new FTPSSendV1.GetPatient();

			// tmpフォルダ作成
			m_tmpPath = string.Format(@"{0}", ConfigFile.main.TmpPath);
			if (util.CreateDirectory(m_tmpPath) == false)
			{
				Logging("TempPathフォルダ作成エラー");
				// MessageBox表示
				return;
			}
		}

		//
		// 患者名はかさならない考慮が必要
		// 地域IDはUIDなのでかさならないはずだが、DICOMの患者ID欄の幅を超える可能性があるので
		// その場合どうすれば良いか検討する必要がある
		//
		public void Start()
		{
			DicomAnalize dcmAnalize = new DicomAnalize();
			string sql = "";
			string hospID = ConfigFile.main.HospitalID;

			string patientID = "";
			string patientIDWork = "";
			string chikiID = "";

			suidList = new Hashtable();


			//
			// 中央GWにファイルを送る契機：
			//  1. ファイル取得でファイルが0個の場合で以前のファイルがある場合(case1処理)
			//  2. ファイル処理中で対象DICOMの患者IDが変わった時(case2処理)
			//
			for (; ; )
			{
				chikiID = "";

				// DICOMファイルを取得
				string[] files = System.IO.Directory.GetFiles(ConfigFile.main.DicomPath, "*.dcm");
				if (files.Length == 0)
				{

					// 未送信ファイルがある場合は、FTP送信をおこなう(case1処理)
					SendFile();

					// リトライタイミング用スリープ
					Thread.Sleep(2000);
					continue;
				}
				else
				{
					// 最初のみファイルコピー中の時間を考慮して、再度ファイル一覧を取得
					Thread.Sleep(5000);
					files = System.IO.Directory.GetFiles(ConfigFile.main.DicomPath, "*.dcm");

					Logging("ファイル数[{0}]", files.Length);

					// 地域ID管理サーバへのPing処理??
					// Pingが通らない場合は、以下の処理をやってもエラーとなるだけなので


					for (int i = 0; i < files.Length; i++)
					{
						if (dcmAnalize.SetDicom(files[i]) == false)
						{
							dcmAnalize.Dispose();
							MoveErrorFile("★Error! DICOMファイル以外のため退避", files[i]);
							continue;
						}

						//
						// DICOMタグデータ抜き出し
						//
						dcmAnalize.GetTagDataTrimEnd("00100020", ref patientID);
						patientID = patientID.Replace("^", "");

						string modality = "";
						dcmAnalize.GetTagDataTrimEnd("00080060", ref modality);

						// 患者IDが前回と同じ時
						if ((patientID.CompareTo(patientIDWork) == 0))
						{
							// 承諾患者か?
							if (chikiID.Length == 0)
							{
								// 許容患者でないため処理中止
								dcmAnalize.Dispose();
								File.Delete(files[i]);
								continue;
							}
							else
							{
								// 処理続行
							}
						}
						else
						{
							// 未送信ファイルがある場合は、FTP送信をおこなう(case2処理)
							SendFile();

							// DEBUG
							//patientID = "99000007";

							// 承諾済み患者の場合
							if (GetChikiID(hospID, patientID, ref chikiID) == true)
							{
								const string kindDicom = "00004";
								const string kindImage = "00001";

								dcmInfo = new FileInfo("DCM", hospID, patientID, chikiID, kindDicom, modality, m_tmpPath);	// とりあえずmodalityをそのまま送る
								djpgInfo = new FileInfo("DJPG", hospID, patientID, chikiID, kindImage,"", m_tmpPath);

								if (dcmInfo.CreateDir() == false)
								{
									dcmAnalize.Dispose();
									MoveErrorFile("★Error! tmpフォルダ作成失敗", files[i]);
									continue;
								}

								if (djpgInfo.CreateDir() == false)
								{
									dcmAnalize.Dispose();
									MoveErrorFile("★Error! tmpフォルダ作成失敗", files[i]);
									continue;
								}
							}
							else
							{
								patientIDWork = patientID;
								dcmAnalize.Dispose();
								Logging(@"地域IDなし又は同意無しのため未送信:患者ID[{0}]", patientID);	// 最初のみロギング
								File.Delete(files[i]);
								continue;
							}
						}
						patientIDWork = patientID;

						string patientName = "";
						dcmAnalize.GetTagDataTrimEnd("00100010", ref patientName);

						string patientSex = "";
						dcmAnalize.GetTagData("00100040", ref patientSex);
						patientSex = patientSex.TrimEnd();

						string birthDate = "";
						dcmAnalize.GetTagData("00100030", ref birthDate);

						string accessionNo = "";
						dcmAnalize.GetTagDataTrimEnd("00080050", ref accessionNo);

						string studyDate = "";
						string studyDateTitle = "";
						dcmAnalize.GetTagData("00080020", ref studyDate);
						studyDateTitle = studyDate;

						string studyTime = "";
						dcmAnalize.GetTagData("00080030", ref studyTime);
						string[] work = studyTime.Split('.');
						studyDate = string.Format("{0} {1}", studyDate, work[0]);

						//string modality = "";
						//dcmAnalize.GetTagDataTrimEnd("00080060", ref modality);

						string suid = "";
						string suidTail = "";
						dcmAnalize.GetTagDataTrimEnd("0020000d", ref suid);
						suidTail = UidTail(suid);

						string seuid = "";
						string seuidTail = "";
						dcmAnalize.GetTagDataTrimEnd("0020000e", ref seuid);
						seuidTail = UidTail(seuid);

						string sopuid = "";
						dcmAnalize.GetTagDataTrimEnd("00080018", ref sopuid);
						Logging("    sopuid=[{0}]", sopuid);

						string acNo = "";
						dcmAnalize.GetTagData("00200012", ref acNo);
						if (acNo.Length <= 8) acNo = string.Format("{0:00000000}", util.ToInt(acNo));
						else acNo = string.Format("{0:0000000000000}", util.ToInt(acNo));

						string instanceNo = "";
						dcmAnalize.GetTagData("00200013", ref instanceNo);
						if (instanceNo.Length <= 8) instanceNo = string.Format("{0:00000000}", util.ToInt(instanceNo));
						else instanceNo = string.Format("{0:00000000000000}", util.ToInt(instanceNo));

						/* とりあえず不要
						string numberOfFrame = "";
						dcmAnalize.GetTagData("00280008", ref numberOfFrame);
						int frame = util.ToInt(numberOfFrame);
						*/

						string photo = "";
						dcmAnalize.GetTagDataTrimEnd("00280004", ref photo);


						// suid,seidリスト作成
						SetSuidList(suid, seuid);

						// DICOMファイル保存
						{
							// DICOMテンポラリファイル名(ファイル名は無加工)
							string tmpDcmNameWork = string.Format(@"{0}\work{1}", dcmInfo.DataFullPath, util.GetFileName(files[i]));
							string tmpDcmName = string.Format(@"{0}\{1}", dcmInfo.DataFullPath, util.GetFileName(files[i]));

							// ID更新と名前匿名
							if (m_idChange)
							{
								// 患者IDを地域IDに変更して保存
								if (dcmAnalize.ChangeTagData("00100020", chikiID, tmpDcmNameWork) == false)
								{
									dcmAnalize.Dispose();
									MoveErrorFile("★Error! ファイル変換失敗", files[i]);
									continue;
								}
								dcmAnalize.Dispose();

								// 名前の匿名化(chikiIDを設定)
								{
									DicomAnalize dcmAnalize2 = new DicomAnalize();
									if (dcmAnalize2.SetDicom(tmpDcmNameWork) == false)
									{
										dcmAnalize2.Dispose();
										MoveErrorFile("★Error! DICOMファイル以外のため退避", files[i]);
										continue;
									}
									if (dcmAnalize2.ChangeTagData("00100010", chikiID, tmpDcmName) == false)
									{
										dcmAnalize2.Dispose();
										MoveErrorFile("★Error! ファイル変換失敗", files[i]);
										continue;
									}
									dcmAnalize2.Dispose();

									File.Delete(tmpDcmNameWork);
								}

							}
							else
							{
								dcmAnalize.Dispose();

								// DICOMファイルを無処理でコピー
								util.CopyFile(files[i], tmpDcmName);
							}
						}

						// JPEGファイルの保存
						{
							string jpg = "";
							if (instanceNo.CompareTo("00000000") == 0)
							{
								jpg = string.Format("S{0}_{1}.jpg", acNo, sopuid);
							}
							else
							{
								// instanceNoが有効な場合はsopUidよりそれを優先する
								//jpg = string.Format("S{0}_{1}_{2}.jpg", seuid, acNo, instanceNo);
								jpg = string.Format("S{0}_{1}_{2}.jpg", acNo, instanceNo, sopuid);
							}

							string paramater = "";

							// 地域ID\DJPG\日付\SUID_TAIL\SEID_TAIL
							string jpegFilePath = string.Format(@"{0}\{1}\{2}", djpgInfo.DataFullPath, suidTail, seuidTail); //"1.3.12.2.1107.5.1.4.54664");
							string jpegFileName = string.Format(@"{0}\{1}", jpegFilePath, jpg);

							// JPEG保存フォルダ作成
							if (util.CreateDirectory(jpegFilePath) == false)
							{
								int aa = 1;
							}

							// とりあえず"thumbnail"は保存しない
							if ((string.Compare(photo, "RGB") == 0))
							{
								paramater = string.Format("--quiet --write-jpeg +ca {0} {1}", files[i], jpegFileName);		// カラー
								//thmbnailParamater = string.Format("--scale-x-size 160 --quiet --write-jpeg +ca {0} {1}", files[i], thumbnailFileName);
							}
							else if ((string.Compare(photo, "YBR_FULL_422") == 0))
							{
								paramater = string.Format("--quiet --write-jpeg +ca {0} {1}", files[i], jpegFileName);		// カラー
								//thmbnailParamater = string.Format("--scale-x-size 160 --quiet --write-jpeg +ca {0} {1}", files[i], thumbnailFileName);
							}
							else
							{
								paramater = string.Format("--quiet --write-jpeg +Wi 1 {0} {1}", files[i], jpegFileName);	// モノクロ
								//thmbnailParamater = string.Format("--scale-x-size 160 --quiet --write-jpeg +Wi 1 {0} {1}", files[i], thumbnailFileName);	// モノクロ
							}

							// JPEG化実行
							int exitCode = 0;
							if ((util.ExecProcessNoConsole(".\\dcmj2pnm.exe", true, ref exitCode, paramater) == false) || (exitCode != 0))
							{
								dcmAnalize.Dispose();
								string errFilePath = string.Format("{0}/{1}/{2}", ConfigFile.main.ErrFilePath, NowDate(), patientID);
								if (File.Exists(errFilePath) == false) util.CreateDirectory(errFilePath);
								util.MoveFile(files[i], errFilePath);
								Logging("Error!! DICOM->JPEG変換エラー[{0}/{1}]", errFilePath, Path.GetFileName(files[i]));
								continue;
							}

							//util.MoveFile(workFileName, jpegFileName);
						}

						// ファイル削除
						File.Delete(files[i]);

					}
				}
				//break;	// DEBUG用　ループ止め
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="filename"></param>
		void MoveErrorFile(string message, string filename)
		{
			string errFilePath = string.Format(@"{0}\{1}", ConfigFile.main.ErrFilePath, NowDate());
			if (File.Exists(errFilePath) == false) util.CreateDirectory(errFilePath);
			util.MoveFile(filename, errFilePath);
			Logging(@"{0} {1}\{2}]", message, errFilePath, Path.GetFileName(filename));

			m_parent.DisplayErrorFile();
		}

		/// <summary>
		/// UIDの最終文字列を取得
		/// </summary>
		/// <param name="uid"></param>
		/// <returns></returns>
		string UidTail(string uid)
		{
			string work = Path.GetExtension(uid);
			string work2 = work.TrimStart('.');

			return work2;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="suid"></param>
		/// <returns></returns>
		bool SetSuidList(string suid, string seuid)
		{
			bool ret = true;

			// suidList構成
			// key:suid
			// value:StudyInfo

			// SUIDが初出の場合はリストに追加
			if (suidList.ContainsKey(suid) == false)
			{
				StudyInfo work = new StudyInfo(suid);
				work.SetSEID(seuid);
				suidList.Add(suid, work);
			}
			else
			{
				((StudyInfo)suidList[suid]).SetSEID(seuid);
			}

			return ret;
		
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		bool SendFile()
		{
			bool ret = true;

			// DICOMファイル送信
			if (dcmInfo != null)
			{
				if (!dcmInfo.SendFile())
				{
				}
				dcmInfo = null;
			}

			// DJPEGファイル送信
			if (djpgInfo != null)
			{
				djpgInfo.AddMetaString = SuidMetaString();
				if (!djpgInfo.SendFile())
				{
				}
				djpgInfo = null;
			}

			suidList.Clear();

			// リトライファイル送信
			// 前回ファイルが残っていたらFTP送信

			return ret;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		string SuidMetaString()
		{
			string work = "";

			int i = 0;
			foreach (StudyInfo si in suidList.Values)
			{
				if(i!=0)work += ',';
				work += si.CreateMetaString();
				i++;
			}

			return work;
		}

		/// <summary>
		/// 現在日付(yyyy/MM/dd形式)
		/// </summary>
		/// <returns></returns>
		private string NowDate()
		{
			string now = util.NowDate("yyyy/MM/dd");
			return now;
		}

		/// <summary>
		/// ID連携サーバに地域IDを問い合わせる
		/// </summary>
		/// <param name="hospID">施設ID</param>
		/// <param name="karteID">カルテID</param>
		/// <param name="chikiID">地域ID</param>
		/// <returns>処理結果</returns>
		bool GetChikiID(string hospID, string karteID, ref string chikiID)
		{
			bool ret = true;
			chikiID = "";

			// 地域IDWebサーバに問い合わせ
			string []para = {hospID, karteID};
			//chikiID = m_getPatient.SearchID((int)SearchFlg.HospPatientID, para);
			// DEBUG
			chikiID = "90000007";

			if (chikiID.Length == 0) ret = false;
			Logging("hospID[{0}],patID[{1}]->regionID[{2}]", hospID, karteID, chikiID);

			return ret;
		}
	}
}
