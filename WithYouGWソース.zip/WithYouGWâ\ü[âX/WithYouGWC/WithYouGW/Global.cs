﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace WithYouGW
{
	// 定数
	class Global		
	{
		public const string C_TorikomiFileName = "取込中_";
		public const string C_SakuseiStartFileName = "作成中_";
		public const string C_SakuseiEndFileName = "作成完了_";
		public const string C_CSV_KanjaInfo = "WithYou取込_患者情報_";
		public const string C_CSV_HoumonsakiM = "WithYou取込_訪問先Ｍ_";
        //2018.04.12 added
        public const string C_CSV_HoumonsakiUnitM = "WithYou取込_訪問先ユニット病棟M_";
        public const string C_CSV_HoumonRiyuM = "WithYou取込_訪問理由Ｍ_";
		public const string C_CSV_Byouinkasan = "WithYou取込_医院Ｍ病院加算_";
		public const string C_CSV_Iinkoyu = "WithYou取込_医院Ｍ医院固有_";
		public const string C_CSV_IinMDoctorInfo = "WithYou取込_医院Mドクター情報_";
		public const string C_CSV_WinTekiyoM = "WithYou取込_ウィンドウ摘要文例M_";
		public const string C_CSV_KanjaInfoDelete = "WithYou取込_患者情報削除_";

        //2020.01.17 add
        public const string C_CSV_MedicalHistory = "WithYou取込_既往歴_";
        public const string C_CSV_TakenMedicine = "WithYou取込_服用中薬剤_";

        //2020.02.04 add
        public const string C_CSV_MedicalHistoryRecord = "WithYou取込_既往歴REC_";
        public const string C_CSV_TakenMedicineRecord = "WithYou取込_服用中薬剤REC_";

		// 区分が情報のアプリケーションログメッセージ
		public const string MSG_INFO_START = "起動しました";
		public const string MSG_INFO_LOAD_WITHYOUFILE_START = "WithYouファイルの取込みを開始しました";
		public const string MSG_INFO_LOAD_WITHYOUFILE_COMPLETED = "WithYouファイルの取込みを終了しました";
		public const string MSG_INFO_CONNECT_SERVER_CURRENT_IP = "カレントIPアドレス[{0}]でサーバにアクセスしました";
		//public const string MSG_INFO_CSV_COMPLETE = "CSVファイルの作成を完了しました";
		public const string MSG_INFO_CSV_PROCESS_START = "「{0}」の処理を開始しました";
		public const string MSG_INFO_CSV_SEND_OK = "「{0}」の情報をサーバに送信しました";
		public const string MSG_INFO_CSV_PROCESS_COMPLETED = "「{0}」の処理を終了しました";
		public const string MSG_INFO_MASTER_CREATE = "マスタファイル「{0}」を作成しました";
		public const string MSG_INFO_PDF_COPY_COMPLETED = "「{0}」をコピーしました";
		public const string MSG_INFO_RENKEI_DATA_REGIST_START = "順番号1「{0}」の登録処理を開始します";
        //2020.01.22 add
        public const string MSG_INFO_RENKEI_DATA_2_REGIST_START = "順番号1「{0}」の登録処理を開始します";
        //2020.01.22 add
        public const string MSG_INFO_RENKEI_DATA_SOAP_REGIST_START = "順番号「{0}」の登録処理を開始します";
        //2020.01.24 add
        public const string MSG_INFO_RENKEI_DATA_KARTE_REGIST_START = "順番号「{0}」の登録処理を開始します";
        //2020.02.04 add
        public const string MSG_INFO_RENKEI_DATA_GENERALDISEASE_REGIST_START = "順番号「{0}」の登録処理を開始します";
        //2020.02.04 add
        public const string MSG_INFO_RENKEI_DATA_TAKINGMEDICINES_REGIST_START = "順番号「{0}」の登録処理を開始します";
		public const string MSG_INFO_TOUROKU_KENSUU = "{0}件の処理コードを登録しました";
		public const string MSG_INFO_RENKEI_DATA_REGIST_COMPLETED = "順番号1「{0}」を登録しました";
        //2020.01.22 add
        public const string MSG_INFO_RENKEI_DATA_2_REGIST_COMPLETED = "順番号1「{0}」を登録しました";
        //2020.01.22 add
        public const string MSG_INFO_RENKEI_DATA_SOAP_REGIST_COMPLETED = "順番号「{0}」を登録しました";
        //2020.01.24 add
        public const string MSG_INFO_RENKEI_DATA_KARTE_REGIST_COMPLETED = "履歴番号「{0}」を登録しました";
        //2020.02.04 add
        public const string MSG_INFO_RENKEI_DATA_GENERALDISEASE_REGIST_COMPLETED = "順番号「{0}」を登録しました";
        //2020.02.04 add
        public const string MSG_INFO_RENKEI_DATA_TAKINGMEDICINES_REGIST_COMPLETED = "順番号「{0}」を登録しました";
		public const string MSG_INFO_FILE_MOVE_COMPLETED = "対象ファイルを移動しました";
		//aaaa 2018.03.01 追加
		public const string MSG_INFO_RECONNECT = "ネットワーク障害から復帰しました";

		// 区分がエラーのアプリケーションログメッセージ
		//public const string MSG_ERR_DONOT_CONNECT_GWSV = "WithYouサーバに接続できないため、終了しました";
		public const string MSG_ERR_DONOT_CONNECT_GWSV = "WithYouサーバに接続できないため、終了しました。\nマスタメンテの「医院情報」の「ユーザID」が正しく設定されていることを確認して下さい。";
		public const string MSG_ERR_NETWORK_ERR = "ネットワーク障害が発生しているため、終了しました。弊社サポートラインに連絡して下さい。";
		public const string MSG_ERR_FILE_GET_ERROR = "ファイル「{0}」の取得に失敗しました";
		public const string MSG_ERR_SETTING_READ_ERROR = "設定情報「{0}」が読み込めないため、終了しました";
		public const string MSG_ERR_LOG_FOLDER_CREATE_ERROR = "ログフォルダの作成に失敗したため、終了しました";
		public const string MSG_ERR_PDF_CREATE_ERROR = "提供文書文書ファイル「{0}」の生成に失敗しました";
        //2020.01.22 modify
        //public const string MSG_ERR_CSV_CREATE_ERROR = "訪問診療データ「{0}」の生成に失敗しました";
        public const string MSG_ERR_CSV_CREATE_ERROR_CLINICAL = "訪問診療データ「{0}」の生成に失敗しました";
        //2020.01.22 add
        public const string MSG_ERR_CSV_CREATE_ERROR_CONDITION = "患者状態データ「{0}」の生成に失敗しました";
        //2020.01.22 add
        public const string MSG_ERR_CSV_CREATE_ERROR_SOAP = "患者SOAPデータ「{0}」の生成に失敗しました";
        //2020.01.24 add
        public const string MSG_ERR_CSV_CREATE_ERROR_KARTE = "カルテ入力リスト「{0}」の生成に失敗しました";
        //2020.02.04 add
        public const string MSG_ERR_CSV_CREATE_ERROR_GENERALDISEASE = "WithYou連携データ疾患「{0}」の生成に失敗しました";
        //2020.02.04 add
        public const string MSG_ERR_CSV_CREATE_ERROR_TAKINGMEDICINES = "WithYou連携データ服用中薬剤「{0}」の生成に失敗しました";
		public const string MSG_ERR_DB_ACCESS_ERROR = "電子カルテのデータベースにアクセスできませんでした";
		public const string MSG_ERR_MASTER_CREATE_ERR = "マスタファイル「{0}」の生成に失敗しました";
		public const string MSG_ERR_EXCEPTION = "例外発生：{0}「{1}」";
        //2020.01.22 modify
        //public const string MSG_ERR_CSV_READ_ERROR = "訪問診療データ「{0}」が読み込めませんでした";
        public const string MSG_ERR_CSV_READ_ERROR_CLINICAL = "訪問診療データ「{0}」が読み込めませんでした";
        //2020.01.22 add
        public const string MSG_ERR_CSV_READ_ERROR_CONDITION = "患者状態データ「{0}」が読み込めませんでした";
        //2020.01.22 add
        public const string MSG_ERR_CSV_READ_ERROR_SOAP = "患者SOAPデータ「{0}」が読み込めませんでした";
        //2020.01.24 add
        public const string MSG_ERR_CSV_READ_ERROR_KARTE = "カルテ入力リスト「{0}」が読み込めませんでした";
        //2020.02.04 add
        public const string MSG_ERR_CSV_READ_ERROR_GENERALDISEASE = "WithYou連携データ疾患「{0}」が読み込めませんでした";
        //2020.02.04 add
        public const string MSG_ERR_CSV_READ_ERROR_TAKINGMEDICINES = "WithYou連携データ服用中薬剤「{0}」が読み込めませんでした";
		public const string MSG_ERR_PDF_COPY_ERROR = "文書ファイル「{0}」がコピーできませんでした";
		public const string MSG_ERR_PDF_REGIST_ERROR = "提供文書連携データ「{0}」が登録できませんでした";
		public const string MSG_ERR_RENKEI_DATA_REGIST_ERROR = "WithYou連携データが登録できませんでした";
        //2020.01.22 add
        public const string MSG_ERR_RENKEI_DATA_2_REGIST_ERROR = "WithYou連携データ2が登録できませんでした";
        //2020.01.22 add
        public const string MSG_ERR_RENKEI_DATA_SOAP_REGIST_ERROR = "WithYou連携データSOAPが登録できませんでした";
        //2020.01.24 add
        public const string MSG_ERR_RENKEI_DATA_KARTE_REGIST_ERROR = "WithYouカルテ入力リストが登録できませんでした";
        //2020.02.04 add
        public const string MSG_ERR_RENKEI_DATA_GENERALDISEASE_REGIST_ERROR = "WithYou連携データ疾患が登録できませんでした";
        //2020.02.04 add
        public const string MSG_ERR_RENKEI_DATA_TAKINGMEDICINES_REGIST_ERROR = "WithYou連携データ服用中薬剤が登録できませんでした";
		public const string MSG_ERR_PDF_MOVE_ERROR = "文書ファイル「{0}」が移動できませんでした";
        //2020.01.22 modify
        //public const string MSG_ERR_CSV_MOVE_ERROR = "訪問診療データ「{0}」が移動できませんでした";
        public const string MSG_ERR_CSV_MOVE_ERROR_CLINICAL = "訪問診療データ「{0}」が移動できませんでした";
        //2020.01.22 add
        public const string MSG_ERR_CSV_MOVE_ERROR_CONDITION = "患者状態データ「{0}」が移動できませんでした";
        //2020.01.22 add
        public const string MSG_ERR_CSV_MOVE_ERROR_SOAP = "患者SOAPデータ「{0}」が移動できませんでした";
        //2020.01.24 add
        public const string MSG_ERR_CSV_MOVE_ERROR_KARTE = "カルテ入力リスト「{0}」が移動できませんでした";
        //2020.02.04 add
        public const string MSG_ERR_CSV_MOVE_ERROR_GENERALDISEASE = "WithYou連携データ疾患「{0}」が移動できませんでした";
        //2020.02.04 add
        public const string MSG_ERR_CSV_MOVE_ERROR_TAKINGMEDICINES = "WithYou連携データ服用中薬剤「{0}」が移動できませんでした";
        //2020.01.22 modify
        //public const string MSG_ERR_INVALID_CONTENTS = "訪問診療データ「{0}」が不正なため読み込めませんでした";
        public const string MSG_ERR_INVALID_CONTENTS_CLINICAL = "訪問診療データ「{0}」が不正なため読み込めませんでした";
        //2020.01.22 add
        public const string MSG_ERR_INVALID_CONTENTS_CONDITION = "患者状態データ「{0}」が不正なため読み込めませんでした";
        //2020.01.22 add
        public const string MSG_ERR_INVALID_CONTENTS_SOAP = "患者SOAPデータ「{0}」が不正なため読み込めませんでした";
        //2020.01.24 add
        public const string MSG_ERR_INVALID_CONTENTS_KARTE = "カルテ入力リスト「{0}」が不正なため読み込めませんでした";
        //2020.02.04 add
        public const string MSG_ERR_INVALID_CONTENTS_GENERALDISEASE = "WithYou連携データ疾患「{0}」が不正なため読み込めませんでした";
        //2020.02.04 add
        public const string MSG_ERR_INVALID_CONTENTS_TAKINGMEDICINES = "WithYou連携データ服用中薬剤「{0}」が不正なため読み込めませんでした";
		public const string MSG_ERR_NOENTRY_USERID = "医院情報のユーザIDが設定されていないため、終了しました";
		public const string MSG_ERR_NOENTRY_PROXYSERVER = "プロキシサーバアドレスが設定されていないため、終了しました";
		public const string MSG_ERR_NETWORK_ERR_PROCESSED = "ネットワーク障害が発生しているため、サーバと通信ができませんでした";
        //2018.04.20 add
        public const string MSG_ERR_NETWORK_ERR_SEND = "ネットワーク障害が発生しているため、サーバにファイルを送信できませんでした";
        public const string MSG_ERR_NETWORK_ERR_CHK = "ネットワーク障害が発生しています。弊社サポートラインに連絡して下さい。";

        // サーバがわで発生するエラーを代替えしてクライアントで表示 2017.12.30
        public const string MSG_ERR_REGIST_MASTER = "医院ID「{0}」のマスタ(「{1}」)登録に失敗しました";

		//// 区分が警告のアプリケーションログメッセージ
		public const string MSG_WARN_TOUROKUZUMI = "患者番号「{0}」、患者氏名「{1}」、訪問日「{2}」は既にカルテ登録されているため、取込処理は行いませんでした。";

		// WithYouRenkeiCSVのメッセージ(DBG用)
		public const string MSG_WARN_TORIKOMICYU = "WithYouで取込中です。";
		public const string MSG_WARN_SAKUSEICYU = "他ＰＣでＣＳＶファイルを作成中です。";

		// GWサーバへの通知用メッセージ
		public const string MSG_NOTICE_FILE_GET_ERROR_IN_CLIENT = "クライアントでファイルの取得に失敗しました";
		public const string MSG_NOTICE_FILE_FORMAT_ERROR_IN_CLIENT = "クライアントでファイルの取得に失敗しました(ファイル名フォーマット異常)";
		public const string MSG_NOTICE_FILE_ENDMARK_ERROR_IN_CLIENT = "クライアントでファイルの取得に失敗しました(終了マーク無し)";

		public const string EPOCH_DOMAIN = "WITH-EPOCH";

		public const string END_MARK = "END";
		//public const string INI_FILENAME = "WithYouGWC.xml";
		public const string INI_FILENAME = "WithYouGWC.ini";	// 名称変更
		public const int DEFAULT_INTERVAL = 180;
		public const string CHANEL = "要求チャネル";
		public const string ENDPOINT = "エンドポイント";
		public const string MASTER = "マスタ";

		public const string C_LCK_Extension = ".LCK";
		public const string C_CSV_Extension = ".CSV";

		// 2017.12.29 add
		public const int INI_LOG_STORAGE_DAYS = 365;		// ログ保存日数
		public const int INI_KRT_INTERVAL = 60;				// カルテアクセスインターバル時間(秒)
		public const int INI_GWSV_INTERVAL = 60;            // GWサーバアクセスインターバル時間(秒)
        //aaaa 2018.03.01
        //public const int INI_RECONNECT = 120;				// WithYouへの通信障害リトライ時間(分)
        public const int INI_RECONNECT = 7200;				// WithYouへの通信障害リトライ時間(秒)
        // add end
        //2018.04.12 added
        public const int INI_RETRY_CNT = 10;				// WithYouへのファイル送信時のリトライ回数

        public const bool DBG_FLG = false;   // trueはローカル時、falseはリリース時

		public static string prm_db_server = "";
		public static string prm_db_user = "";
		public static string prm_db_password = "";

        //--------------------------------------

        //2018.04.12 changed 訪問先ユニット追加
        public enum eFileName
        {
            none = 0, koyu, kasan, doctor, dh, visit, reason, patient, visit_unit,
            visit_record, reason_record, patient_record, visit_unit_record, patient_delete_record, kasan_record

            //2020.01.31 add
            , kioureki = 101
            //2020.01.31 add
            , fukuyoutyuu_yakuzai = 102

            //2020.02.04 add
            , kioureki_record = 201
            //2020.02.04 add
            , fukuyoutyuu_yakuzai_record = 202
        }
        public int[] srv_kind = new int[15]
        {0, 1, 2, 3, 4 ,5, 6, 7, 13, 8, 9, 10, 14, 11, 12};

        // 電カル出力ファイル名特定用文字列
        //2018.04.12 changed 訪問先ユニット追加
        public string[] mst_withfile = new string[10]
					{"none", "医院Ｍ医院固有", "医院Ｍ病院加算", "医院Mドクター情報", "ウィンドウ摘要文例M",
                        "訪問先Ｍ","訪問理由Ｍ","患者情報","訪問先ユニット病棟M", "患者情報削除"};

		// 仕様追加 2017.12.26
		public string dbUser = "";
		public string dbPassword = "";
		public string userName = "";

	}
}
