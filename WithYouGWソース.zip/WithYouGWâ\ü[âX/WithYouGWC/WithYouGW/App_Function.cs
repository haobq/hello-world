using System;
using System.Data;
using System.Data.Odbc;


namespace WithYouGW
{
	public class App_Connection
	{

	}

	public class DBConnection
	{
		OdbcConnection m_dbCon = null;
		OdbcDataAdapter m_dbAda = null;
		OdbcCommand m_dbCom = null;
		private string m_errMsg;
		Object thisLock = new Object();

		public DBConnection(string server, string database, string user, string password)
		{
			string connectionParamater = string.Format(@"SERVER={0};DRIVER={{SQL Server}};DATABASE={1};UID={2};PWD={3};",
								server, database, user, password);
			m_dbCon = new OdbcConnection();
			m_dbCon.ConnectionString = connectionParamater;
			m_dbAda = new OdbcDataAdapter();
			m_dbCom = new OdbcCommand();
		}

		public DBConnection(string paramater)
		{
			m_dbCon = new OdbcConnection();
			m_dbCon.ConnectionString = paramater;
			m_dbAda = new OdbcDataAdapter();
			m_dbCom = new OdbcCommand();
		}

		/// <summary>
		/// DATABASE�I�[�v��
		/// </summary>
		/// <returns></returns>
		public bool DataBaseOpen(string server, string database, string user, string password)
		{
			lock (thisLock)
			{
				try
				{
					string connectionParamater = string.Format(@"SERVER={0};DRIVER={{SQL Server}};DATABASE={1};UID={2};PWD={3};",
													server, database, user, password);
					m_dbCon = new OdbcConnection();
					m_dbCon.ConnectionString = connectionParamater;
					m_dbAda = new OdbcDataAdapter();
					m_dbCom = new OdbcCommand();

					try
					{
						m_dbCon.Open();
					}
					catch (OdbcException ex)
					{
						ErrorMessage = ex.ToString();
						return false;
					}

					// SQLCommand�ɐڑ����ݒ�
					m_dbCom.Connection = m_dbCon;

					// Adapter��SQL�ݒ�
					m_dbAda.SelectCommand = m_dbCom;
					m_dbAda.UpdateCommand = m_dbCom;
					m_dbAda.InsertCommand = m_dbCom;
					m_dbAda.SelectCommand.Connection = m_dbCon;
				}
				catch (OdbcException ex)
				{
					ErrorMessage = ex.ToString();
					return false;
				}
			}
			return true;
		}

		/// <summary>
		/// 
		/// </summary>
		public void DataBaseClose()
		{
			if (m_dbCon != null) m_dbCon.Close();
			if (m_dbAda != null) m_dbAda.Dispose();
			if (m_dbCom != null) m_dbCom.Dispose();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sentences"></param>
		/// <param name="dataTbl"></param>
		/// <returns></returns>
		public bool SQLSelectTable(string sentences, ref DataTable dataTbl)
		{
			lock (thisLock)
			{
				try
				{
					m_dbCon.Open();
					m_dbCom.Connection = m_dbCon;
					m_dbAda.SelectCommand = m_dbCom;
					m_dbCom.CommandText = sentences;
					m_dbAda.Fill(dataTbl);
					m_dbCon.Close();
				}
				catch (OdbcException ex)
				{
					ErrorMessage = ex.ToString();
					m_dbCon.Close();
					// log();
					return false;
				}
			}

			return true;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sentences"></param>
		/// <param name="selectItem"></param>
		/// <returns></returns>
		public string SQLSelect(string sentences, string selectItem)
		{
			string returnItem = "-1";

			lock (thisLock)
			{
				try
				{
					DataTable dataTable = new DataTable();
					m_dbCon.Open();
					m_dbCom.Connection = m_dbCon;
					m_dbAda.SelectCommand = m_dbCom;
					m_dbCom.CommandText = sentences;
					m_dbAda.Fill(dataTable);

					if (dataTable.Rows.Count <= 0) returnItem = "";
					else returnItem = dataTable.Rows[0][selectItem].ToString();

					dataTable.Dispose();
					m_dbCon.Close();
				}
				catch (OdbcException ex)
				{
					ErrorMessage = ex.ToString();
					m_dbCon.Close();
					// log();
					return returnItem;
				}
			}
			return returnItem;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sentences"></param>
		/// <param name="dataSet"></param>
		/// <param name="tableName"></param>
		/// <returns></returns>
		public bool SQLSelectDataset(string sentences, ref System.Data.DataSet dataSet, string tableName)
		{
			lock (thisLock)
			{
				try
				{
					m_dbCon.Open();
					m_dbCom.Connection = m_dbCon;
					m_dbAda.SelectCommand = m_dbCom;
					m_dbCom.CommandText = sentences;
					m_dbAda.Fill(dataSet, tableName);
					m_dbCon.Close();
				}
				catch (OdbcException ex)
				{
					ErrorMessage = ex.ToString();
					m_dbCon.Close();
					// log();
					return false;
				}
			}
			return true;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sentences"></param>
		/// <returns></returns>
		public bool SqlInsert(string sentences)
		{
			lock (thisLock)
			{
				OdbcTransaction dbTra = null;
				try
				{
					m_dbCon.Open();
					m_dbCom.CommandText = sentences;
					dbTra = m_dbCon.BeginTransaction();
					m_dbCom.Transaction = dbTra;
					m_dbCom.ExecuteNonQuery();
					dbTra.Commit();
					m_dbCon.Close();
				}
				catch (Exception ex)
				{
					dbTra.Rollback();
					ErrorMessage = ex.ToString();
					m_dbCon.Close();
					// log();
					return false;
				}
			}
			return true;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sentences"></param>
		/// <returns></returns>
		public bool SQLUpdate(string sentences)
		{
			lock (thisLock)
			{
				OdbcTransaction dbTra = null;
				try
				{
					m_dbCon.Open();
					m_dbAda.UpdateCommand = m_dbCom;
					m_dbAda.InsertCommand = m_dbCom;
					m_dbCom.CommandText = sentences;
					dbTra = m_dbCon.BeginTransaction();
					m_dbCom.Transaction = dbTra;
					m_dbCom.ExecuteNonQuery();
					dbTra.Commit();
					m_dbCon.Close();
				}
				catch (Exception ex)
				{
					dbTra.Rollback();
					ErrorMessage = ex.ToString();
					m_dbCon.Close();
					// log();
					return false;
				}


			
			}
			return true;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sentences"></param>
		/// <returns></returns>
		public bool SqlDelete(string sentences)
		{
			lock (thisLock)
			{
				OdbcTransaction dbTra = null;
				try
				{
					m_dbCon.Open();
					m_dbCom.CommandText = sentences;
					dbTra = m_dbCon.BeginTransaction();
					m_dbCom.Transaction = dbTra;
					m_dbCom.ExecuteNonQuery();
					dbTra.Commit();
					m_dbCon.Close();
				}
				catch (Exception ex)
				{
					dbTra.Rollback();
					ErrorMessage = ex.ToString();
					m_dbCon.Close();
					//log();
					return false;
				}
			}
			return true;
		}

		/// <summary>
		/// �G���[���b�Z�[�W
		/// </summary>
		public string ErrorMessage
		{
			set { m_errMsg = value; }
			get { return m_errMsg; }
		}

	}
}

