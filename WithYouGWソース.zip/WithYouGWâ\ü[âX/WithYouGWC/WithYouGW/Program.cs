﻿using System;
using System.Collections.Generic;
using System.Linq;
//using System.Threading.Tasks;
using System.Windows.Forms;

namespace WithYouGW
{
    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {

			string arg = "";

			// 起動パラメータ設定
			if (args.Length != 0) arg = args[0];

			// 2重起動チェック
			if (util.IsExecCurrentProcess())
			{
				//MessageBox.Show("既に起動しています");
				return;
			}
			Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(arg));
        }
	}
}
