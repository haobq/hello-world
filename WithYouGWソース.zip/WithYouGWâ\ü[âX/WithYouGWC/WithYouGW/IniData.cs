using System;
using System.IO;
using System.Runtime.InteropServices;

namespace WithYouGW
{

	// Ini�t�@�C���Ǎ��݃N���X
	// ���Ŏg�p����ꍇ��enum�l, section, param, �v���p�e�B��ύX����
	// enum, param, �v���p�e�B�͕K��1:1
	enum eIniData
	{
		LogStoraygeDays,	// ���O�ۑ�����
		DBInterval,			// DB�Ď��C���^�[�o��
		GWServerInterval,	// GW�T�[�o�Ď��C���^�[�o��
		MAX
	};

	public class ReadIniData : IniFileAccess
	{
		static string [][] param = new string[][] {
			new string[] { "init", "log_storage_days", "30"},
			new string[] { "DB", "interval", "60"},
			new string[] { "gwserver", "interval", "60"},
		};

		string [] m_iniData;

		// Ini�t�@�C���f�[�^�Ǐo��
		public bool ReadAllData(string fileName)
		{
			if(File.Exists(fileName) == false) return false;

			m_iniFileName = fileName;

			m_iniData = new string [(int)eIniData.MAX];

			for(int i=0;i<(int)eIniData.MAX;i++)
			{
				GetValue(param[i], ref m_iniData[i]);
			}
			return true;
		}

		// �v���p�e�B
		//public int logStorageDays { get {
		//		int ret = 30;
		//		try {
		//			ret = Convert.ToInt32(m_iniData[(int)eIniData.LogStoraygeDays]);
		//		}
		//		catch(Exception ex)
		//		{ }
		//		return ret;
		//	} }
		//public int DBInterval { get {
		//		int ret = 60;
		//		try
		//		{
		//			ret = Convert.ToInt32(m_iniData[(int)eIniData.DBInterval]);
		//		}
		//		catch (Exception ex)
		//		{ }
		//		return ret;
		//	} }
		//public int gwsvInterval { get {
		//		int ret = 60;
		//		try
		//		{
		//			ret = Convert.ToInt32(m_iniData[(int)eIniData.GWServerInterval]);
		//		}
		//		catch (Exception ex)
		//		{ }
		//		return ret;
		//	} }
	}

	// Ini�t�@�C�������݃N���X
	public class SetIniData : IniFileAccess
	{
	}

	// INI�t�@�C���A�N�Z�X���N���X
	enum eIniParam
	{
		SectionName,
		KeyName,
		Default,
		MAX
	};


	public class IniFileAccess
	{

		//
		// DLL��`
		//
		[DllImport("kernel32", EntryPoint="GetPrivateProfileString")]	// GetPrivateProfileString
		private static extern uint GetPrivateProfileString(string sectionName, string keyName, string defaultString,
														System.Text.StringBuilder returnString, uint size, string fileName ); 

		[DllImport("kernel32", EntryPoint="WritePrivateProfileString")]	// WritePrivateProfileString
		private static extern uint WritePrivateProfileString(string sectionName, string keyName, string value, string fileName);

		const int m_buffLength = 256;
		internal string m_iniFileName;

		//
		// Ini�t�@�C���f�[�^�擾
		//
		internal uint GetValue(string section, string key, string def, ref string value)
		{
			string [] param = new string [] {section, key, def};
			return( GetValue(param, ref value) );
		}
		internal uint GetValue(string [] param, ref string value)
		{
			uint ret = 0;

			System.Text.StringBuilder workData = new System.Text.StringBuilder(m_buffLength);
			ret = GetPrivateProfileString(param[(int)eIniParam.SectionName], param[(int)eIniParam.KeyName],
								param[(int)eIniParam.Default], workData, (uint)workData.Capacity, m_iniFileName);
			value = workData.ToString();

			return ret;
		}
		// static
		static internal uint GetValue(string section, string key, string def, string fileName, ref string value)
		{
			uint ret = 0;

			System.Text.StringBuilder workData = new System.Text.StringBuilder(m_buffLength);
			ret = GetPrivateProfileString(section, key, def, workData, (uint)workData.Capacity, fileName);
			value = workData.ToString();

			return ret;
		}

		//
		// Ini�t�@�C���f�[�^�ݒ�
		//
		internal uint SetValue(string section, string key, string value)
		{
			string [] param = new string [] { section, key };
			return( SetValue(param, value) );
		}
		internal uint SetValue(string [] param, string value)
		{
			return( WritePrivateProfileString(param[(int)eIniParam.SectionName], param[(int)eIniParam.KeyName], value, m_iniFileName) );
		}
		// static
		static internal uint SetValue(string section, string key, string value, string fileName)
		{
			return( WritePrivateProfileString(section, key, value, fileName) );
		}

		// Ini�t�@�C����
		public string iniFileName
		{
			set { m_iniFileName = value; }
			get { return m_iniFileName; }
		}
	}
}
