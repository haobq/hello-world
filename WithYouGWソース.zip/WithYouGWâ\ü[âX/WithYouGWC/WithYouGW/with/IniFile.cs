﻿using System.IO;

namespace WithYouGW
{
	public class IniFile
	{
		private const string INI_FILE_NAME = "WithYou.ini";
		public static string GetIniPath()
		{
			string INI_FOLDER = @"D:\Env";

			string strIniPath = Path.Combine(INI_FOLDER, INI_FILE_NAME);
			return strIniPath;
		}

		public static IniSectionInit init { get { return new IniSectionInit(GetIniPath(), "init"); } }

		public static void CheckValues()
		{
			init.CheckValues();
		}
	}
}
