﻿using System;
using System.IO;
using System.Data.SqlClient;
using System.Collections.Generic;
using Microsoft.CSharp;
using System.Linq;

namespace WithYouGW
{
	public partial class Torikomi
	{
		public enum eTorikomiKekkaType
		{
			Success,        //成功
			InvalidData,    //データ不良
			Registered,     //カルテ登録済
			OtherError      //エラー
		}

        //2020.01.22 modify
        //public static eTorikomiKekkaType ProcessCsvFile(string csvFilePath, ref string errMessage)
		// 他のクラスから呼び出すためpublicに変更、errMessage追加 ikeda 2016/06/01
		//private static TorikomiKekkaType ProcessCsvFile(string csvFilePath)
        public static eTorikomiKekkaType ProcessCsvFileClinical(string csvFilePath, ref string errMessage)
		{
			//dynamic objAppLogger = LoggerAppcation.GetInstance();
			//dynamic strCsvFileName = Path.GetFileName(csvFilePath);
			string strCsvFileName = Path.GetFileName(csvFilePath);

			try
			{
				//CSVファイルの内容を読み込む
                //2020.01.22 modify
                //List<CsvRecord> lstCsvData = new List<CsvRecord>();
                List<CsvRecordClinical> lstCsvData = new List<CsvRecordClinical>();
				try
				{
                    //2020.01.22 modify
                    //lstCsvData = ReadCsvFile(csvFilePath);
                    lstCsvData = ReadCsvFileClinical(csvFilePath);
				}
				catch (Exception ex)
				{
					//テキストログファイルへの出力
                    //2020.01.22 modify
                    //string strLogMessage = string.Format(Global.MSG_ERR_CSV_READ_ERROR, strCsvFileName);
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_READ_ERROR_CLINICAL, strCsvFileName);
					//objAppLogger.WriteLog(strLogMessage);
					LoggingDisplay(strLogMessage);
					//ECLOGへの出力
					int iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName);
					//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
					//CSVファイルをエラーフォルダに移動する
					MoveToErrorFolder(csvFilePath);
					throw;
				}

				//CSVファイルを正常に読み込めなかった場合は「データ不良」
				if (lstCsvData.Count <= 0)
				{
					MoveToErrorFolder(csvFilePath);
                    //2020.01.22 modify
					// エラーメッセージ設定 ikeda 2016/06/01
                    //errMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS, csvFilePath);
                    errMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_CLINICAL, csvFilePath);
					LoggingDisplay(errMessage);
					return eTorikomiKekkaType.InvalidData;
				}

				//CSVファイルを処理済みフォルダに移動する
				try
				{
					MoveToDoneFolder(csvFilePath);
				}
				catch (Exception ex)
				{
					//テキストログファイルへの出力
                    //2020.01.22 modify
                    //string strLogMessage = string.Format(Global.MSG_ERR_CSV_MOVE_ERROR, Path.GetFileName(csvFilePath));
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_MOVE_ERROR_CLINICAL, Path.GetFileName(csvFilePath));
					//objAppLogger.WriteLog(strLogMessage);
					LoggingDisplay(strLogMessage);
					//ECLOGへの出力
					//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData[0].KanjaBangou);
					throw;
				}
				//objAppLogger.WriteLog(LoggerAppcation.MSG_INFO_FILE_MOVE_COMPLETED);
				Form1.LoggingDisplay(Global.MSG_INFO_FILE_MOVE_COMPLETED);

				//カルテ登録有無チェック
				string strYYMM = DBAccess.GetYYMM((DateTime)lstCsvData[0].Houmonbi);
				int iKarute1Count = DBAccess.GetKarute1Count((int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi, strYYMM);
				//登録済みの場合は処理終了
				if (iKarute1Count > 0)
				{
					string strLogMessage = string.Format(Global.MSG_WARN_TOUROKUZUMI, (int)lstCsvData[0].KanjaBangou, (string)lstCsvData[0].KanjaShimei, lstCsvData[0].Houmonbi.ToString("yyyy/MM/dd"));
					//objAppLogger.WriteLog(strLogMessage);
					LoggingDisplay(strLogMessage);
					//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData[0].KanjaBangou);
					errMessage = strLogMessage;			// エラーメッセージ設定 ikeda 2016/06/01
					return eTorikomiKekkaType.Registered;
				}

				using (SqlConnection con = DBAccess.GetConnectionWithOpen())
				{
					//トランザクション開始
					using (SqlTransaction tran = con.BeginTransaction())
					{
						try
						{

							//WithYou連携データの同一患者番号および診療年月日のレコードの処理区分を1から2に変更する
							DBAccess.UpdateRenkeiDataSyoriKubun(con, tran, (int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi);

							//登録済みの文書連携テーブルの取り込み前のデータの削除フラグを1に更新する
							DBAccess.UpdateBunsyoRenkeiSakujoFlag(con, tran, (int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi);

							//CSVの順番号が0の場合はここで処理を終了する
							if ((int)lstCsvData[0].Junbangou == 0)
							{
								//トランザクション完了
								tran.Commit();
								return eTorikomiKekkaType.Success;
							}

							//CSVの内容をWithYou連携データに登録する際の順番号1の値を取得する
                            //2020.01.22 modify
                            //int newJunbangou1 = DBAccess.GetMaxJunbangou1(con, tran, (int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi) + 1;
                            int newJunbangou1 = DBAccess.GetMaxJunbangou1RenkeiData(con, tran, (int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi) + 1;

							//WithYou連携データに登録する
							//objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_REGIST_START, newJunbangou1));
							LoggingDisplay(Global.MSG_INFO_RENKEI_DATA_REGIST_START, newJunbangou1);
							int iTourokuKensuu = DBAccess.InsertIntoWithYouRenkeiData(con, tran, lstCsvData, strYYMM, (short)newJunbangou1);

							//トランザクション完了
							tran.Commit();
							//objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
							//objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_REGIST_COMPLETED, newJunbangou1));
							LoggingDisplay(string.Format(Global.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
							LoggingDisplay(string.Format(Global.MSG_INFO_RENKEI_DATA_REGIST_COMPLETED, newJunbangou1));

							return eTorikomiKekkaType.Success;

						}
						catch (Exception ex)
						{
							//トランザクションロールバック
							tran.Rollback();
							//objAppLogger.WriteLog(LoggerAppcation.MSG_ERR_RENKEI_DATA_REGIST_ERROR);
							LoggingDisplay(Global.MSG_ERR_RENKEI_DATA_REGIST_ERROR);
							//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, Global.MSG_ERR_RENKEI_DATA_REGIST_ERROR, (int)lstCsvData[0].KanjaBangou);
							//CSVファイルを処理済みフォルダからエラーフォルダに移動する
							MoveToErrorFolderFromDoneFolder(csvFilePath);
							throw;
						}
					}
				}

			}
			catch (Exception ex)
			{
				//objAppLogger.WriteLog(ex.Message);

				//dynamic objErrLogger = LoggerError.GetInstance();
				//objErrLogger.WriteLog(ex);
				LoggingDisplay(ex.ToString());

				//WindowsのエラーメッセージをECLOGに書き込む
				//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName));
				// エラーメッセージ設定 ikeda 2016/06/01
				errMessage = Global.MSG_ERR_RENKEI_DATA_REGIST_ERROR;	
				return eTorikomiKekkaType.OtherError;
			}
		}

        //2020.01.22 add
        public static eTorikomiKekkaType ProcessCsvFileCondition(string csvFilePath, ref string errMessage)
        {
            //dynamic objAppLogger = LoggerAppcation.GetInstance();
            //dynamic strCsvFileName = Path.GetFileName(csvFilePath);
            string strCsvFileName = Path.GetFileName(csvFilePath);

            try
            {
                //CSVファイルの内容を読み込む
                var lstCsvData = new List<CsvRecordCondition>();
                try
                {
                    lstCsvData = ReadCsvFileCondition(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_READ_ERROR_CONDITION, strCsvFileName);
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    int iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName);
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                    //CSVファイルをエラーフォルダに移動する
                    MoveToErrorFolder(csvFilePath);
                    throw;
                }

                //CSVファイルを正常に読み込めなかった場合は「データ不良」
                if (lstCsvData.Count <= 0)
                {
                    MoveToErrorFolder(csvFilePath);
                    // エラーメッセージ設定
                    errMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_CONDITION, csvFilePath);
                    LoggingDisplay(errMessage);
                    return eTorikomiKekkaType.InvalidData;
                }

                //CSVファイルを処理済みフォルダに移動する
                try
                {
                    MoveToDoneFolder(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_MOVE_ERROR_CONDITION, Path.GetFileName(csvFilePath));
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData[0].KanjaBangou);
                    throw;
                }
                //objAppLogger.WriteLog(LoggerAppcation.MSG_INFO_FILE_MOVE_COMPLETED);
                Form1.LoggingDisplay(Global.MSG_INFO_FILE_MOVE_COMPLETED);

                //カルテ登録有無チェック
                string strYYMM = DBAccess.GetYYMM(lstCsvData[0].Houmonbi);
                int iKarute1Count = DBAccess.GetKarute1Count(lstCsvData[0].KanjaBangou, lstCsvData[0].Houmonbi, strYYMM);
                //登録済みの場合は処理終了
                if (iKarute1Count > 0)
                {
                    string strLogMessage = string.Format(Global.MSG_WARN_TOUROKUZUMI, (int)lstCsvData[0].KanjaBangou, (string)lstCsvData[0].KanjaShimei, lstCsvData[0].Houmonbi.ToString("yyyy/MM/dd"));
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData[0].KanjaBangou);
                    errMessage = strLogMessage;         // エラーメッセージ設定
                    return eTorikomiKekkaType.Registered;
                }

                using (SqlConnection con = DBAccess.GetConnectionWithOpen())
                //トランザクション開始
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    try
                    {
                        //WithYou連携データ2の同一患者番号および診療年月日のレコードの処理区分を1から2に変更する
                        DBAccess.UpdateRenkeiData2SyoriKubun(con, tran, (int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi);

                        //CSVの順番号が0の場合はここで処理を終了する
                        if ((int)lstCsvData[0].Junbangou == 0)
                        {
                            //トランザクション完了
                            tran.Commit();
                            return eTorikomiKekkaType.Success;
                        }

                        //CSVの内容をWithYou連携データ2に登録する際の順番号1の値を取得する
                        int newJunbangou1 = DBAccess.GetMaxJunbangou1RenkeiData2(con, tran, (int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi) + 1;

                        //WithYou連携データ2に登録する
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_2_REGIST_START, newJunbangou1));
                        LoggingDisplay(Global.MSG_INFO_RENKEI_DATA_2_REGIST_START, newJunbangou1);
                        int iTourokuKensuu = DBAccess.InsertIntoWithYouRenkeiData2(con, tran, lstCsvData, strYYMM, (short)newJunbangou1);

                        //トランザクション完了
                        tran.Commit();
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_2_REGIST_COMPLETED, newJunbangou1));
                        LoggingDisplay(string.Format(Global.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        LoggingDisplay(string.Format(Global.MSG_INFO_RENKEI_DATA_2_REGIST_COMPLETED, newJunbangou1));

                        return eTorikomiKekkaType.Success;
                    }
                    catch (Exception ex)
                    {
                        //トランザクションロールバック
                        tran.Rollback();
                        //objAppLogger.WriteLog(LoggerAppcation.MSG_ERR_RENKEI_DATA_2_REGIST_ERROR);
                        LoggingDisplay(Global.MSG_ERR_RENKEI_DATA_2_REGIST_ERROR);
                        //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, Global.MSG_ERR_RENKEI_DATA_2_REGIST_ERROR, (int)lstCsvData[0].KanjaBangou);
                        //CSVファイルを処理済みフォルダからエラーフォルダに移動する
                        MoveToErrorFolderFromDoneFolder(csvFilePath);
                        throw;
                    }
                }

            }
            catch (Exception ex)
            {
                //objAppLogger.WriteLog(ex.Message);

                //dynamic objErrLogger = LoggerError.GetInstance();
                //objErrLogger.WriteLog(ex);
                LoggingDisplay(ex.ToString());

                //WindowsのエラーメッセージをECLOGに書き込む
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName));
                // エラーメッセージ設定
                errMessage = Global.MSG_ERR_RENKEI_DATA_2_REGIST_ERROR;
                return eTorikomiKekkaType.OtherError;
            }
        }

        //2020.01.22 add
        public static eTorikomiKekkaType ProcessCsvFileSOAP(string csvFilePath, ref string errMessage)
        {
            //dynamic objAppLogger = LoggerAppcation.GetInstance();
            //dynamic strCsvFileName = Path.GetFileName(csvFilePath);
            string strCsvFileName = Path.GetFileName(csvFilePath);

            try
            {
                //CSVファイルの内容を読み込む
                var lstCsvData = new List<CsvRecordSOAP>();
                try
                {
                    lstCsvData = ReadCsvFileSOAP(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_READ_ERROR_SOAP, strCsvFileName);
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    int iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName);
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                    //CSVファイルをエラーフォルダに移動する
                    MoveToErrorFolder(csvFilePath);
                    throw;
                }

                //CSVファイルを正常に読み込めなかった場合は「データ不良」
                if (lstCsvData.Count <= 0)
                {
                    MoveToErrorFolder(csvFilePath);
                    // エラーメッセージ設定
                    errMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_SOAP, csvFilePath);
                    LoggingDisplay(errMessage);
                    return eTorikomiKekkaType.InvalidData;
                }

                //CSVファイルを処理済みフォルダに移動する
                try
                {
                    MoveToDoneFolder(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_MOVE_ERROR_SOAP, Path.GetFileName(csvFilePath));
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData[0].KanjaBangou);
                    throw;
                }
                //objAppLogger.WriteLog(LoggerAppcation.MSG_INFO_FILE_MOVE_COMPLETED);
                Form1.LoggingDisplay(Global.MSG_INFO_FILE_MOVE_COMPLETED);

                //カルテ登録有無チェック
                string strYYMM = DBAccess.GetYYMM(lstCsvData[0].Houmonbi);
                int iKarute1Count = DBAccess.GetKarute1Count(lstCsvData[0].KanjaBangou, lstCsvData[0].Houmonbi, strYYMM);
                //登録済みの場合は処理終了
                if (iKarute1Count > 0)
                {
                    string strLogMessage = string.Format(Global.MSG_WARN_TOUROKUZUMI, (int)lstCsvData[0].KanjaBangou, (string)lstCsvData[0].KanjaShimei, lstCsvData[0].Houmonbi.ToString("yyyy/MM/dd"));
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData[0].KanjaBangou);
                    errMessage = strLogMessage;         // エラーメッセージ設定
                    return eTorikomiKekkaType.Registered;
                }

                using (SqlConnection con = DBAccess.GetConnectionWithOpen())
                //トランザクション開始
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    try
                    {
                        //WithYou連携データSOAPの同一患者番号および診療年月日のレコードの処理区分を1から2に変更する
                        DBAccess.UpdateRenkeiDataSOAPSyoriKubun(con, tran, (int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi);

                        //CSVの順番号が0の場合はここで処理を終了する
                        if ((int)lstCsvData[0].Junbangou == 0)
                        {
                            //トランザクション完了
                            tran.Commit();
                            return eTorikomiKekkaType.Success;
                        }

                        //CSVの内容をWithYou連携データSOAPに登録する際の順番号1の値を取得する
                        int newJunbangou1 = DBAccess.GetMaxJunbangou1RenkeiDataSOAP(con, tran, (int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi) + 1;

                        //WithYou連携データSOAPに登録する
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_SOAP_REGIST_START, newJunbangou1));
                        LoggingDisplay(Global.MSG_INFO_RENKEI_DATA_SOAP_REGIST_START, newJunbangou1);
                        int iTourokuKensuu = DBAccess.InsertIntoWithYouRenkeiDataSOAP(con, tran, lstCsvData, (short)newJunbangou1);

                        //トランザクション完了
                        tran.Commit();
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_SOAP_REGIST_COMPLETED, newJunbangou1));
                        LoggingDisplay(string.Format(Global.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        LoggingDisplay(string.Format(Global.MSG_INFO_RENKEI_DATA_SOAP_REGIST_COMPLETED, newJunbangou1));

                        return eTorikomiKekkaType.Success;
                    }
                    catch (Exception ex)
                    {
                        //トランザクションロールバック
                        tran.Rollback();
                        //objAppLogger.WriteLog(LoggerAppcation.MSG_ERR_RENKEI_DATA_SOAP_REGIST_ERROR);
                        LoggingDisplay(Global.MSG_ERR_RENKEI_DATA_SOAP_REGIST_ERROR);
                        //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, Global.MSG_ERR_RENKEI_DATA_SOAP_REGIST_ERROR, (int)lstCsvData[0].KanjaBangou);
                        //CSVファイルを処理済みフォルダからエラーフォルダに移動する
                        MoveToErrorFolderFromDoneFolder(csvFilePath);
                        throw;
                    }
                }

            }
            catch (Exception ex)
            {
                //objAppLogger.WriteLog(ex.Message);

                //dynamic objErrLogger = LoggerError.GetInstance();
                //objErrLogger.WriteLog(ex);
                LoggingDisplay(ex.ToString());

                //WindowsのエラーメッセージをECLOGに書き込む
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName));
                // エラーメッセージ設定
                errMessage = Global.MSG_ERR_RENKEI_DATA_SOAP_REGIST_ERROR;
                return eTorikomiKekkaType.OtherError;
            }
        }

        //2020.01.24 add
        public static eTorikomiKekkaType ProcessCsvFileKarte(string csvFilePath, ref string errMessage)
        {
            //dynamic objAppLogger = LoggerAppcation.GetInstance();
            //dynamic strCsvFileName = Path.GetFileName(csvFilePath);
            string strCsvFileName = Path.GetFileName(csvFilePath);

            try
            {
                //CSVファイルの内容を読み込む
                var lstCsvData = new List<CsvRecordKarte>();
                try
                {
                    lstCsvData = ReadCsvFileKarte(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_READ_ERROR_KARTE, strCsvFileName);
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    int iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName);
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                    //CSVファイルをエラーフォルダに移動する
                    MoveToErrorFolder(csvFilePath);
                    throw;
                }

                //CSVファイルを正常に読み込めなかった場合は「データ不良」
                if (lstCsvData.Count <= 0)
                {
                    MoveToErrorFolder(csvFilePath);
                    // エラーメッセージ設定
                    errMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_KARTE, csvFilePath);
                    LoggingDisplay(errMessage);
                    return eTorikomiKekkaType.InvalidData;
                }

                //CSVファイルを処理済みフォルダに移動する
                try
                {
                    MoveToDoneFolder(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_MOVE_ERROR_KARTE, Path.GetFileName(csvFilePath));
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData[0].KanjaBangou);
                    throw;
                }
                //objAppLogger.WriteLog(LoggerAppcation.MSG_INFO_FILE_MOVE_COMPLETED);
                Form1.LoggingDisplay(Global.MSG_INFO_FILE_MOVE_COMPLETED);

                ////カルテ登録有無チェック
                //string strYYMM = DBAccess.GetYYMM((DateTime)lstCsvData[0].Houmonbi);
                //int iKarute1Count = DBAccess.GetKarute1Count((int)lstCsvData[0].KanjaBangou, (DateTime)lstCsvData[0].Houmonbi, strYYMM);
                ////登録済みの場合は処理終了
                //if (iKarute1Count > 0)
                //{
                //    string strLogMessage = string.Format(Global.MSG_WARN_TOUROKUZUMI, (int)lstCsvData[0].KanjaBangou, (string)lstCsvData[0].KanjaShimei, lstCsvData[0].Houmonbi.ToString("yyyy/MM/dd"));
                //    //objAppLogger.WriteLog(strLogMessage);
                //    LoggingDisplay(strLogMessage);
                //    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData[0].KanjaBangou);
                //    errMessage = strLogMessage;         // エラーメッセージ設定
                //    return eTorikomiKekkaType.Registered;
                //}

                using (SqlConnection con = DBAccess.GetConnectionWithOpen())
                //トランザクション開始
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    try
                    {
                        var iTourokuKensuu = 0;

                        //訪問日一覧
                        var Houmonbis = lstCsvData
                            .Select(s => s.Houmonbi)
                            .Distinct()
                            .ToArray();

                        foreach (var Houmonbi in Houmonbis)
                        {
                            //訪問日で絞ったデータ
                            var lst = lstCsvData.Where(p => p.Houmonbi == Houmonbi);

                            short newRirekibangou = 0;

                            //削除する前に
                            //CSVの順番号が0より大きいデータがある場合は処理する。
                            //CSVの順番号が0より大きいデータがない場合は登録しないので処理しない。
                            if (lst.Any(p => 0 < p.Junbangou))
                            {
                                //CSVの内容をWithYouカルテ入力リストに登録する際の履歴番号の値を取得する
                                newRirekibangou = (short)(DBAccess.GetMaxRirekibangouKarteNyuuryokuList(con, tran, Houmonbi) + 1);
                            }

                            //WithYouカルテ入力リストの同一診療年月日のレコードを削除する
                            DBAccess.RemoveWithYouKarteNyuuryokuList(con, tran, Houmonbi);

                            //CSVの順番号が0より大きいデータがない場合はここで処理を終了する
                            if (!lst.Any(p => 0 < p.Junbangou))
                            {
                                continue;
                            }

                            //WithYouカルテ入力リストに登録する
                            //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_KARTE_REGIST_START, newJunbangou1));
                            LoggingDisplay(Global.MSG_INFO_RENKEI_DATA_KARTE_REGIST_START, newRirekibangou);
                            iTourokuKensuu += DBAccess.InsertIntoWithYouKarteNyuuryokuList(con, tran, lst, newRirekibangou);

                            LoggingDisplay(string.Format(Global.MSG_INFO_RENKEI_DATA_KARTE_REGIST_COMPLETED, newRirekibangou));
                        }

                        //トランザクション完了
                        tran.Commit();
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_KARTE_REGIST_COMPLETED, newJunbangou1));
                        LoggingDisplay(string.Format(Global.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));

                        return eTorikomiKekkaType.Success;
                    }
                    catch (Exception ex)
                    {
                        //トランザクションロールバック
                        tran.Rollback();
                        //objAppLogger.WriteLog(LoggerAppcation.MSG_ERR_RENKEI_DATA_KARTE_REGIST_ERROR);
                        LoggingDisplay(Global.MSG_ERR_RENKEI_DATA_KARTE_REGIST_ERROR);
                        //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, Global.MSG_ERR_RENKEI_DATA_KARTE_REGIST_ERROR, (int)lstCsvData[0].KanjaBangou);
                        //CSVファイルを処理済みフォルダからエラーフォルダに移動する
                        MoveToErrorFolderFromDoneFolder(csvFilePath);
                        throw;
                    }
                }

            }
            catch (Exception ex)
            {
                //objAppLogger.WriteLog(ex.Message);

                //dynamic objErrLogger = LoggerError.GetInstance();
                //objErrLogger.WriteLog(ex);
                LoggingDisplay(ex.ToString());

                //WindowsのエラーメッセージをECLOGに書き込む
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName));
                // エラーメッセージ設定
                errMessage = Global.MSG_ERR_RENKEI_DATA_KARTE_REGIST_ERROR;
                return eTorikomiKekkaType.OtherError;
            }
        }

        //2020.02.04 add
        public static eTorikomiKekkaType ProcessCsvFileGeneralDisease(string csvFilePath, ref string errMessage)
        {
            //dynamic objAppLogger = LoggerAppcation.GetInstance();
            //dynamic strCsvFileName = Path.GetFileName(csvFilePath);
            string strCsvFileName = Path.GetFileName(csvFilePath);

            try
            {
                //CSVファイルの内容を読み込む
                var lstCsvData = Enumerable.Empty<CsvRecordGeneralDisease>();
                try
                {
                    lstCsvData = ReadCsvFileGeneralDisease(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_READ_ERROR_GENERALDISEASE, strCsvFileName);
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    int iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName);
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                    //CSVファイルをエラーフォルダに移動する
                    MoveToErrorFolder(csvFilePath);
                    throw;
                }

                //CSVファイルを正常に読み込めなかった場合は「データ不良」
                if (lstCsvData == null || !lstCsvData.Any())
                {
                    MoveToErrorFolder(csvFilePath);
                    // エラーメッセージ設定
                    errMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_GENERALDISEASE, csvFilePath);
                    LoggingDisplay(errMessage);
                    return eTorikomiKekkaType.InvalidData;
                }

                //CSVファイルを処理済みフォルダに移動する
                try
                {
                    MoveToDoneFolder(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_MOVE_ERROR_GENERALDISEASE, Path.GetFileName(csvFilePath));
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData.First().KanjaBangou);
                    throw;
                }
                //objAppLogger.WriteLog(LoggerAppcation.MSG_INFO_FILE_MOVE_COMPLETED);
                Form1.LoggingDisplay(Global.MSG_INFO_FILE_MOVE_COMPLETED);

                ////カルテ登録有無チェック
                //string strYYMM = DBAccess.GetYYMM((DateTime)lstCsvData.First().Houmonbi);
                //int iKarute1Count = DBAccess.GetKarute1Count((int)lstCsvData.First().KanjaBangou, (DateTime)lstCsvData.First().Houmonbi, strYYMM);
                ////登録済みの場合は処理終了
                //if (iKarute1Count > 0)
                //{
                //    string strLogMessage = string.Format(Global.MSG_WARN_TOUROKUZUMI, (int)lstCsvData.First().KanjaBangou, (string)lstCsvData.First().KanjaShimei, lstCsvData.First().Houmonbi.ToString("yyyy/MM/dd"));
                //    //objAppLogger.WriteLog(strLogMessage);
                //    LoggingDisplay(strLogMessage);
                //    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData.First().KanjaBangou);
                //    errMessage = strLogMessage;         // エラーメッセージ設定
                //    return eTorikomiKekkaType.Registered;
                //}

                using (SqlConnection con = DBAccess.GetConnectionWithOpen())
                //トランザクション開始
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    try
                    {
                        ////登録済みのWithYou連携データ疾患の取り込み前のデータの削除フラグを1に更新する
                        //DBAccess.UpdateWithYouGeneralDiseaseSakujoFlag(con, tran, (int)lstCsvData.First().KanjaBangou);

                        //WithYou連携データ疾患に登録する
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_GENERALDISEASE_REGIST_START, newJunbangou1));
                        LoggingDisplay(Global.MSG_INFO_RENKEI_DATA_GENERALDISEASE_REGIST_START);
                        var iTourokuKensuu = DBAccess.MergeIntoWithYouGeneralDisease(con, tran, lstCsvData);

                        //トランザクション完了
                        tran.Commit();
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_GENERALDISEASE_REGIST_COMPLETED, newJunbangou1));
                        LoggingDisplay(string.Format(Global.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        //LoggingDisplay(string.Format(Global.MSG_INFO_RENKEI_DATA_REGIST_COMPLETED, newJunbangou1));

                        return eTorikomiKekkaType.Success;
                    }
                    catch (Exception ex)
                    {
                        //トランザクションロールバック
                        tran.Rollback();
                        //objAppLogger.WriteLog(LoggerAppcation.MSG_ERR_RENKEI_DATA_GENERALDISEASE_REGIST_ERROR);
                        LoggingDisplay(Global.MSG_ERR_RENKEI_DATA_GENERALDISEASE_REGIST_ERROR);
                        //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, Global.MSG_ERR_RENKEI_DATA_GENERALDISEASE_REGIST_ERROR, (int)lstCsvData.First().KanjaBangou);
                        //CSVファイルを処理済みフォルダからエラーフォルダに移動する
                        MoveToErrorFolderFromDoneFolder(csvFilePath);
                        throw;
                    }
                }

            }
            catch (Exception ex)
            {
                //objAppLogger.WriteLog(ex.Message);

                //dynamic objErrLogger = LoggerError.GetInstance();
                //objErrLogger.WriteLog(ex);
                LoggingDisplay(ex.ToString());

                //WindowsのエラーメッセージをECLOGに書き込む
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName));
                // エラーメッセージ設定
                errMessage = Global.MSG_ERR_RENKEI_DATA_GENERALDISEASE_REGIST_ERROR;
                return eTorikomiKekkaType.OtherError;
            }
        }

        //2020.02.04 add
        public static eTorikomiKekkaType ProcessCsvFileTakingMedicines(string csvFilePath, ref string errMessage)
        {
            //dynamic objAppLogger = LoggerAppcation.GetInstance();
            //dynamic strCsvFileName = Path.GetFileName(csvFilePath);
            string strCsvFileName = Path.GetFileName(csvFilePath);

            try
            {
                //CSVファイルの内容を読み込む
                var lstCsvData = Enumerable.Empty<CsvRecordTakingMedicines>();
                try
                {
                    lstCsvData = ReadCsvFileTakingMedicines(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_READ_ERROR_TAKINGMEDICINES, strCsvFileName);
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    int iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName);
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                    //CSVファイルをエラーフォルダに移動する
                    MoveToErrorFolder(csvFilePath);
                    throw;
                }

                //CSVファイルを正常に読み込めなかった場合は「データ不良」
                if (lstCsvData == null || !lstCsvData.Any())
                {
                    MoveToErrorFolder(csvFilePath);
                    // エラーメッセージ設定
                    errMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_TAKINGMEDICINES, csvFilePath);
                    LoggingDisplay(errMessage);
                    return eTorikomiKekkaType.InvalidData;
                }

                //CSVファイルを処理済みフォルダに移動する
                try
                {
                    MoveToDoneFolder(csvFilePath);
                }
                catch (Exception ex)
                {
                    //テキストログファイルへの出力
                    string strLogMessage = string.Format(Global.MSG_ERR_CSV_MOVE_ERROR_TAKINGMEDICINES, Path.GetFileName(csvFilePath));
                    //objAppLogger.WriteLog(strLogMessage);
                    LoggingDisplay(strLogMessage);
                    //ECLOGへの出力
                    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData.First().KanjaBangou);
                    throw;
                }
                //objAppLogger.WriteLog(LoggerAppcation.MSG_INFO_FILE_MOVE_COMPLETED);
                Form1.LoggingDisplay(Global.MSG_INFO_FILE_MOVE_COMPLETED);

                ////カルテ登録有無チェック
                //string strYYMM = DBAccess.GetYYMM((DateTime)lstCsvData.First().Houmonbi);
                //int iKarute1Count = DBAccess.GetKarute1Count((int)lstCsvData.First().KanjaBangou, (DateTime)lstCsvData.First().Houmonbi, strYYMM);
                ////登録済みの場合は処理終了
                //if (iKarute1Count > 0)
                //{
                //    string strLogMessage = string.Format(Global.MSG_WARN_TOUROKUZUMI, (int)lstCsvData.First().KanjaBangou, (string)lstCsvData.First().KanjaShimei, lstCsvData.First().Houmonbi.ToString("yyyy/MM/dd"));
                //    //objAppLogger.WriteLog(strLogMessage);
                //    LoggingDisplay(strLogMessage);
                //    //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, (int)lstCsvData.First().KanjaBangou);
                //    errMessage = strLogMessage;         // エラーメッセージ設定
                //    return eTorikomiKekkaType.Registered;
                //}

                using (SqlConnection con = DBAccess.GetConnectionWithOpen())
                //トランザクション開始
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    try
                    {
                        ////登録済みのWithYou連携データ服用中薬剤の取り込み前のデータの削除フラグを1に更新する
                        //DBAccess.UpdateWithYouTakingMedicinesSakujoFlag(con, tran, (int)lstCsvData.First().KanjaBangou);

                        //WithYou連携データ服用中薬剤に登録する
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_TAKINGMEDICINES_REGIST_START, newJunbangou1));
                        LoggingDisplay(Global.MSG_INFO_RENKEI_DATA_TAKINGMEDICINES_REGIST_START);
                        var iTourokuKensuu = DBAccess.MergeIntoWithYouTakingMedicines(con, tran, lstCsvData);

                        //トランザクション完了
                        tran.Commit();
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        //objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_RENKEI_DATA_TAKINGMEDICINES_REGIST_COMPLETED, newJunbangou1));
                        LoggingDisplay(string.Format(Global.MSG_INFO_TOUROKU_KENSUU, iTourokuKensuu));
                        //LoggingDisplay(string.Format(Global.MSG_INFO_RENKEI_DATA_REGIST_COMPLETED, newJunbangou1));

                        return eTorikomiKekkaType.Success;
                    }
                    catch (Exception ex)
                    {
                        //トランザクションロールバック
                        tran.Rollback();
                        //objAppLogger.WriteLog(LoggerAppcation.MSG_ERR_RENKEI_DATA_TAKINGMEDICINES_REGIST_ERROR);
                        LoggingDisplay(Global.MSG_ERR_RENKEI_DATA_TAKINGMEDICINES_REGIST_ERROR);
                        //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, Global.MSG_ERR_RENKEI_DATA_TAKINGMEDICINES_REGIST_ERROR, (int)lstCsvData.First().KanjaBangou);
                        //CSVファイルを処理済みフォルダからエラーフォルダに移動する
                        MoveToErrorFolderFromDoneFolder(csvFilePath);
                        throw;
                    }
                }

            }
            catch (Exception ex)
            {
                //objAppLogger.WriteLog(ex.Message);

                //dynamic objErrLogger = LoggerError.GetInstance();
                //objErrLogger.WriteLog(ex);
                LoggingDisplay(ex.ToString());

                //WindowsのエラーメッセージをECLOGに書き込む
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, CommonWithYouTorikomi.GetKanjaBangouFromFileName(strCsvFileName));
                // エラーメッセージ設定
                errMessage = Global.MSG_ERR_RENKEI_DATA_TAKINGMEDICINES_REGIST_ERROR;
                return eTorikomiKekkaType.OtherError;
            }
        }

		// 他のクラスから呼び出すためpublicに変更 ikeda 2016/06/01
		//private static TorikomiKekkaType ProcessPdfFile(string pdfFilePath)
		public static eTorikomiKekkaType ProcessPdfFile(string pdfFilePath, ref string errMessage)
		{
			//dynamic objAppLogger = LoggerAppcation.GetInstance();
			string strPdfFileName = Path.GetFileName(pdfFilePath);
			try
			{
				string strPdfFileNameWithoutExtension = Path.GetFileNameWithoutExtension(pdfFilePath);
				TeikyouBunsyo objTeikyouBunsyo = GetTeikyouBunsyoInfo(strPdfFileNameWithoutExtension);

				//取り込むPDFファイルを文書連携フォルダ(ECDIR\PDFfromWithYou)にコピーする
				// ikeda debug
				string strDBServerPath = "\\\\" + Common.GetDBServerName();
				string strWithYouRenkeiPath = CommonWithYouTorikomi.GetWithYouBunsyoRenkeiPath();
				string strDestinationPathWithoutServer = Path.Combine(strWithYouRenkeiPath, strPdfFileName);
				string strDestinationPathWithServer = strDBServerPath + strDestinationPathWithoutServer;
				try
				{
					File.Copy(pdfFilePath, strDestinationPathWithServer, true);
				}
				catch (Exception ex)
				{
					string strLogMessage = string.Format(Global.MSG_ERR_PDF_COPY_ERROR, strPdfFileName);
					//objAppLogger.WriteLog(strLogMessage);
					LoggingDisplay(strLogMessage);
					//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, objTeikyouBunsyo.KanjaBangou);
					MoveToErrorFolder(pdfFilePath);
					throw;
				}
				//objAppLogger.WriteLog(string.Format(LoggerAppcation.MSG_INFO_PDF_COPY_COMPLETED, strPdfFileName));
				LoggingDisplay(string.Format(Global.MSG_INFO_PDF_COPY_COMPLETED, strPdfFileName));

				//処理が完了したPDFファイルを処理済みフォルダに移動する
				try
				{
					MoveToDoneFolder(pdfFilePath);
				}
				catch (Exception ex)
				{
					string strLogMessage = string.Format(Global.MSG_ERR_PDF_MOVE_ERROR, strPdfFileName);
					//objAppLogger.WriteLog(strLogMessage);
					LoggingDisplay(strLogMessage);
					//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, objTeikyouBunsyo.KanjaBangou);
					throw;
				}
				//objAppLogger.WriteLog(LoggerAppcation.MSG_INFO_FILE_MOVE_COMPLETED);
				LoggingDisplay(Global.MSG_INFO_FILE_MOVE_COMPLETED);

				//取り込む提供文書の情報をWithYou文書連携テーブルに登録する
				bool bIsSuccess = DBAccess.InsertIntoWithYouBunsyoRenkei(strDestinationPathWithoutServer, objTeikyouBunsyo);
				if (!bIsSuccess)
				{
					string strLogMessage = string.Format(Global.MSG_ERR_PDF_REGIST_ERROR, strPdfFileName);
					//objAppLogger.WriteLog(strLogMessage);
					LoggingDisplay(strLogMessage);
					//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, objTeikyouBunsyo.KanjaBangou);

					//PDFファイルを処理済みフォルダからエラーフォルダに移動する
					MoveToErrorFolderFromDoneFolder(pdfFilePath);

					//文書連携フォルダのPDFファイルは削除する
					File.Delete(strDestinationPathWithServer);
				}

				return eTorikomiKekkaType.Success;
			}
			catch (Exception ex)
			{
				//objAppLogger.WriteLog(ex.Message);
				//dynamic objErrLogger = LoggerError.GetInstance();
				//objErrLogger.WriteLog(ex);
				//objAppLogger.WriteLog(ex.Message);
				LoggingDisplay(ex.Message);

				//WindowsのエラーメッセージをECLOGに書き込む
				//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, CommonWithYouTorikomi.GetKanjaBangouFromFileName(strPdfFileName));
				// エラーメッセージ設定 ikeda 2016/06/01
				errMessage = string.Format(Global.MSG_ERR_PDF_MOVE_ERROR, strPdfFileName);

				return eTorikomiKekkaType.OtherError;
			}

		}

		//処理済みフォルダへファイルを移動する
		public static void MoveToDoneFolder(string sourcePath)
		{
			string strFileName = Path.GetFileName(sourcePath);
			string strDestPath = Path.Combine(IniFile.init.DoneFolder, strFileName);

			//上書きコピー後、コピー元を削除する
			File.Copy(sourcePath, strDestPath, true);
			File.Delete(sourcePath);
		}

		//エラーフォルダへファイルを移動する
		public static void MoveToErrorFolder(string sourcePath)
		{
			string strFileName = Path.GetFileName(sourcePath);
			string strDestPath = Path.Combine(IniFile.init.ErrorFolder, strFileName);

			//上書きコピー後、コピー元を削除する
			File.Copy(sourcePath, strDestPath, true);
			File.Delete(sourcePath);
		}

		//処理済みフォルダからエラーフォルダへファイルを移動する
		private static void MoveToErrorFolderFromDoneFolder(string sourcePath)
		{
			string strFileName = Path.GetFileName(sourcePath);
			string strDoneFilePath = Path.Combine(IniFile.init.DoneFolder, strFileName);
			string strErrorFilePath = Path.Combine(IniFile.init.ErrorFolder, strFileName);

			//上書きコピー後、コピー元を削除する
			File.Copy(strDoneFilePath, strErrorFilePath, true);
			File.Delete(strDoneFilePath);
		}

        //2020.01.22 modify
        //private static List<CsvRecord> ReadCsvFile(string csvFilePath)
        private static List<CsvRecordClinical> ReadCsvFileClinical(string csvFilePath)
		{
			//CSVファイルの内容を読み込む
            //2020.01.22 modify
            //List<CsvRecord> lstCsvData = new List<CsvRecord>();
            List<CsvRecordClinical> lstCsvData = new List<CsvRecordClinical>();

			//CSVファイルの最終行がENDになっているかチェックする
			if (!IsValidLastLine(csvFilePath))
			{
				//dynamic objAppLogger = LoggerAppcation.GetInstance();
				string strFileName = Path.GetFileName(csvFilePath);
                //2020.01.22 modify
                //string strLogMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS, strFileName);
                string strLogMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_CLINICAL, strFileName);
				//objAppLogger.WriteLog(strLogMessage);
				//dynamic iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strFileName);
				//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
				Form1.LoggingDisplay(strLogMessage);

				return lstCsvData;
			}
			
			using (Microsoft.VisualBasic.FileIO.TextFieldParser parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(csvFilePath, System.Text.Encoding.GetEncoding("Shift_JIS")))
			{
				parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
				parser.SetDelimiters(",");

				while (!parser.EndOfData)
				{
					string[] fields = parser.ReadFields();
					// 1行読み込み
					//CSVファイルの最終行に到達したら処理を抜ける
					if (fields[0] == Global.END_MARK)
					{
						break; // TODO: might not be correct. Was : Exit While
					}
                    //2020.01.22 modify
                    //CsvRecord rec = new CsvRecord();
                    var rec = new CsvRecordClinical();
					rec.KanjaBangou = int.Parse(fields[0]);
					rec.KanjaShimei = fields[1];
					rec.Houmonbi = System.DateTime.Parse(fields[2]);
					rec.Junbangou = int.Parse(fields[3]);
					rec.ShinryouKouiCode = fields[4];
					rec.KasanCode = fields[5];
					rec.ShinryouKouiName = fields[6];
					if (string.IsNullOrEmpty(fields[7]))
					{
						rec.ShikaIshiCode = 0;
					}
					else
					{
						rec.ShikaIshiCode = int.Parse(fields[7]);
					}
					rec.ShikaIshiName = fields[8];
					if (string.IsNullOrEmpty(fields[9]))
					{
						rec.ShikaEiseishiCode = 0;
					}
					else
					{
						rec.ShikaEiseishiCode = int.Parse(fields[9]);
					}
					rec.ShikaEiseishiName = fields[10];
					rec.KaishiJikoku = fields[11];
					rec.SyuuryouJikoku = fields[12];
					rec.HosokuCode = fields[13];
					rec.HosokuJouhou = fields[14];
					rec.KaruteKisaiNaiyou = fields[15];
					rec.BunsyoFileName = fields[16];

					lstCsvData.Add(rec);
				}
			}
			return lstCsvData;
		}

        //2020.01.22 add
        private static List<CsvRecordCondition> ReadCsvFileCondition(string csvFilePath)
        {
            //CSVファイルの内容を読み込む
            List<CsvRecordCondition> lstCsvData = new List<CsvRecordCondition>();

            //CSVファイルの最終行がENDになっているかチェックする
            if (!IsValidLastLine(csvFilePath))
            {
                //dynamic objAppLogger = LoggerAppcation.GetInstance();
                string strFileName = Path.GetFileName(csvFilePath);
                string strLogMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_CONDITION, strFileName);
                //objAppLogger.WriteLog(strLogMessage);
                //dynamic iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strFileName);
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                Form1.LoggingDisplay(strLogMessage);

                return lstCsvData;
            }

            using (Microsoft.VisualBasic.FileIO.TextFieldParser parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(csvFilePath, System.Text.Encoding.GetEncoding("Shift_JIS")))
            {
                parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
                parser.SetDelimiters(",");

                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    // 1行読み込み
                    //CSVファイルの最終行に到達したら処理を抜ける
                    if (fields[0] == Global.END_MARK)
                    {
                        break; // TODO: might not be correct. Was : Exit While
                    }
                    var rec = new CsvRecordCondition();
                    rec.KanjaBangou = int.Parse(fields[0]);
                    rec.KanjaShimei = fields[1];
                    rec.Houmonbi = System.DateTime.Parse(fields[2]);
                    rec.Junbangou = int.Parse(fields[3]);
                    rec.OrderCode = fields[4];
                    rec.ShinryouKouiName = fields[5];
                    rec.Article = fields[6];

                    lstCsvData.Add(rec);
                }
            }
            return lstCsvData;
        }

        //2020.01.22 add
        private static List<CsvRecordSOAP> ReadCsvFileSOAP(string csvFilePath)
        {
            //CSVファイルの内容を読み込む
            List<CsvRecordSOAP> lstCsvData = new List<CsvRecordSOAP>();

            //CSVファイルの最終行がENDになっているかチェックする
            if (!IsValidLastLine(csvFilePath))
            {
                //dynamic objAppLogger = LoggerAppcation.GetInstance();
                string strFileName = Path.GetFileName(csvFilePath);
                string strLogMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_SOAP, strFileName);
                //objAppLogger.WriteLog(strLogMessage);
                //dynamic iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strFileName);
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                Form1.LoggingDisplay(strLogMessage);

                return lstCsvData;
            }

            using (Microsoft.VisualBasic.FileIO.TextFieldParser parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(csvFilePath, System.Text.Encoding.GetEncoding("Shift_JIS")))
            {
                parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
                parser.SetDelimiters(",");

                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    // 1行読み込み
                    //CSVファイルの最終行に到達したら処理を抜ける
                    if (fields[0] == Global.END_MARK)
                    {
                        break; // TODO: might not be correct. Was : Exit While
                    }
                    var rec = new CsvRecordSOAP();
                    rec.KanjaBangou = int.Parse(fields[0]);
                    rec.KanjaShimei = fields[1];
                    rec.Houmonbi = System.DateTime.Parse(fields[2]);
                    rec.Junbangou = int.Parse(fields[3]);
                    rec.Kind = fields[4];
                    rec.Article = fields[5];

                    lstCsvData.Add(rec);
                }
            }
            return lstCsvData;
        }

        //2020.01.24 add
        private static List<CsvRecordKarte> ReadCsvFileKarte(string csvFilePath)
        {
            //CSVファイルの内容を読み込む
            List<CsvRecordKarte> lstCsvData = new List<CsvRecordKarte>();

            //CSVファイルの最終行がENDになっているかチェックする
            if (!IsValidLastLine(csvFilePath))
            {
                //dynamic objAppLogger = LoggerAppcation.GetInstance();
                string strFileName = Path.GetFileName(csvFilePath);
                string strLogMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_KARTE, strFileName);
                //objAppLogger.WriteLog(strLogMessage);
                //dynamic iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strFileName);
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                Form1.LoggingDisplay(strLogMessage);

                return lstCsvData;
            }

            using (Microsoft.VisualBasic.FileIO.TextFieldParser parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(csvFilePath, System.Text.Encoding.GetEncoding("Shift_JIS")))
            {
                parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
                parser.SetDelimiters(",");

                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    // 1行読み込み
                    //CSVファイルの最終行に到達したら処理を抜ける
                    if (fields[0] == Global.END_MARK)
                    {
                        break; // TODO: might not be correct. Was : Exit While
                    }
                    int ri;
                    var rec = new CsvRecordKarte();
                    rec.Houmonbi = DateTime.Parse(fields[0]);
                    rec.Junbangou = int.Parse(fields[1]);
                    rec.KanjaBangou = fields[2];
                    rec.KanjaShimei = fields[3];
                    rec.KanjaKana = fields[4];
                    rec.ShikaIshiCode = int.TryParse(fields[5], out ri) ? ri : (int?)null;
                    rec.ShikaIshiName = fields[6];
                    rec.HojoShikaEiseishiCode = int.TryParse(fields[7], out ri) ? ri : (int?)null;
                    rec.HojoShikaEiseishiName = fields[8];
                    rec.ShinryouKaishiJikoku = fields[9];
                    rec.ShinryouSyuuryouJikoku = fields[10];
                    rec.ShinryouJikan = int.TryParse(fields[11], out ri) ? ri : (int?)null;
                    rec.ShidouShikaEiseishiCode = int.TryParse(fields[12], out ri) ? ri : (int?)null;
                    rec.ShidouShikaEiseishiName = fields[13];
                    rec.ShidouKaishiJikoku = fields[14];
                    rec.ShidouSyuuryouJikoku = fields[15];
                    rec.ShidouJikan = int.TryParse(fields[16], out ri) ? ri : (int?)null;
                    rec.JissekiStatus = fields[17];
                    rec.VisitName = fields[18];
                    rec.UnitName = fields[19];
                    rec.KoSuu = int.TryParse(fields[20], out ri) ? ri : (int?)null;

                    lstCsvData.Add(rec);
                }
            }
            return lstCsvData;
        }

        //2020.02.04 add
        private static IEnumerable<CsvRecordGeneralDisease> ReadCsvFileGeneralDisease(string csvFilePath)
        {
            //CSVファイルの内容を読み込む
            var lstCsvData = new List<CsvRecordGeneralDisease>();

            //CSVファイルの最終行がENDになっているかチェックする
            if (!IsValidLastLine(csvFilePath))
            {
                //dynamic objAppLogger = LoggerAppcation.GetInstance();
                string strFileName = Path.GetFileName(csvFilePath);
                string strLogMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_GENERALDISEASE, strFileName);
                //objAppLogger.WriteLog(strLogMessage);
                //dynamic iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strFileName);
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                Form1.LoggingDisplay(strLogMessage);

                return lstCsvData;
            }

            var parseNullableDateTime = new Func<string, DateTime?>(value => {
                DateTime res;
                return DateTime.TryParse(value, out res) ? res : (DateTime?)null;
            });

            var parseNullableInt = new Func<string, int?>(value => {
                int res;
                return int.TryParse(value, out res) ? res : (int?)null;
            });

            var parseNullableShort = new Func<string, short?>(value => {
                short res;
                return short.TryParse(value, out res) ? res : (short?)null;
            });

            using (Microsoft.VisualBasic.FileIO.TextFieldParser parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(csvFilePath, System.Text.Encoding.GetEncoding("Shift_JIS")))
            {
                parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
                parser.SetDelimiters(",");

                while (!parser.EndOfData)
                {
                    var fields = parser.ReadFields();
                    // 1行読み込み
                    //CSVファイルの最終行に到達したら処理を抜ける
                    if (fields[0] == Global.END_MARK)
                    {
                        break; // TODO: might not be correct. Was : Exit While
                    }

                    var rec = new CsvRecordGeneralDisease();
                    rec.patient_id = fields[0];
                    rec.measure_date = parseNullableDateTime(fields[1]);
                    rec.seq_no = parseNullableInt(fields[2]);
                    rec.mask = parseNullableShort(fields[3]);
                    rec.regist_user = fields[4];
                    rec.regist_date = parseNullableDateTime(fields[5]);
                    rec.medical_history = fields[6];
                    rec.disease_cd = fields[7];
                    rec.disease_name = fields[8];
                    rec.medical_facility = fields[9];
                    rec.with_seqno = parseNullableShort(fields[10]);
                    rec.with_kiorekicd = parseNullableShort(fields[11]);
                    rec.with_keika = parseNullableShort(fields[12]);
                    rec.icd10 = fields[13];
                    rec.disease_name_kana = fields[14];
                    rec.withyou_status = parseNullableShort(fields[15]);
                    rec.with_status = parseNullableShort(fields[16]);
                    rec.with_mod_usercd = fields[17];
                    rec.with_mod_username = fields[18];
                    rec.with_mod_date = parseNullableDateTime(fields[19]);

                    lstCsvData.Add(rec);
                }
            }
            return lstCsvData;
        }

        //2020.02.04 add
        private static IEnumerable<CsvRecordTakingMedicines> ReadCsvFileTakingMedicines(string csvFilePath)
        {
            //CSVファイルの内容を読み込む
            var lstCsvData = new List<CsvRecordTakingMedicines>();

            //CSVファイルの最終行がENDになっているかチェックする
            if (!IsValidLastLine(csvFilePath))
            {
                //dynamic objAppLogger = LoggerAppcation.GetInstance();
                string strFileName = Path.GetFileName(csvFilePath);
                string strLogMessage = string.Format(Global.MSG_ERR_INVALID_CONTENTS_TAKINGMEDICINES, strFileName);
                //objAppLogger.WriteLog(strLogMessage);
                //dynamic iKanjaBangou = CommonWithYouTorikomi.GetKanjaBangouFromFileName(strFileName);
                //Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, strLogMessage, iKanjaBangou);
                Form1.LoggingDisplay(strLogMessage);

                return lstCsvData;
            }

            var parseNullableDateTime = new Func<string, DateTime?>(value => {
                DateTime res;
                return DateTime.TryParse(value, out res) ? res : (DateTime?)null;
            });

            var parseNullableInt = new Func<string, int?>(value => {
                int res;
                return int.TryParse(value, out res) ? res : (int?)null;
            });

            var parseNullableShort = new Func<string, short?>(value => {
                short res;
                return short.TryParse(value, out res) ? res : (short?)null;
            });

            using (Microsoft.VisualBasic.FileIO.TextFieldParser parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(csvFilePath, System.Text.Encoding.GetEncoding("Shift_JIS")))
            {
                parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
                parser.SetDelimiters(",");

                while (!parser.EndOfData)
                {
                    var fields = parser.ReadFields();
                    // 1行読み込み
                    //CSVファイルの最終行に到達したら処理を抜ける
                    if (fields[0] == Global.END_MARK)
                    {
                        break; // TODO: might not be correct. Was : Exit While
                    }

                    var rec = new CsvRecordTakingMedicines();
                    rec.patient_id = fields[0];
                    rec.measure_date = parseNullableDateTime(fields[1]);
                    rec.seq_no = parseNullableInt(fields[2]);
                    rec.mask = parseNullableShort(fields[3]);
                    rec.regist_user = fields[4];
                    rec.regist_date = parseNullableDateTime(fields[5]);
                    rec.medical_history = parseNullableShort(fields[6]);
                    rec.yakka_code = fields[7];
                    rec.medicine_name = fields[8];
                    rec.medical_facility = fields[9];
                    rec.with_seqno = parseNullableShort(fields[10]);
                    rec.withyou_status = parseNullableShort(fields[11]);
                    rec.with_status = parseNullableShort(fields[12]);
                    rec.with_mod_usercd = fields[13];
                    rec.with_mod_username = fields[14];
                    rec.with_mod_date = parseNullableDateTime(fields[15]);

                    lstCsvData.Add(rec);
                }
            }
            return lstCsvData;
        }

		private static bool IsValidLastLine(string filepath)
		{
			string[] lines = System.IO.File.ReadAllLines(filepath, System.Text.Encoding.GetEncoding("Shift_JIS"));
			if (lines[lines.Length - 1] == Global.END_MARK)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		private static TeikyouBunsyo GetTeikyouBunsyoInfo(string pdfFileNameWithoutExtension)
		{
			string[] s = pdfFileNameWithoutExtension.Split('_');
			TeikyouBunsyo objTeikyouBunsyo = new TeikyouBunsyo();
			objTeikyouBunsyo.KanjaBangou = util.ToInt(s[0]);
			objTeikyouBunsyo.Houmonbi = System.DateTime.ParseExact(s[1], "yyyyMMdd", null);
			objTeikyouBunsyo.BunsyoCode = s[2].ToString();
			objTeikyouBunsyo.BunsyoName = s[3].ToString();

			return objTeikyouBunsyo;
		}

		public static void LoggingDisplay(string format, params object[] arg) { Form1.LoggingDisplay(format, true, arg); }
	}
}