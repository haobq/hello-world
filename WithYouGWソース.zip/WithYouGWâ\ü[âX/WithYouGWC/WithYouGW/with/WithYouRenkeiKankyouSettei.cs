﻿using System.Collections.Generic;

//2016/10/07 ogasawara add S WithEpoch対応
public class WithYouRenkeiKankyouSettei
{

	private const string VALUE_WITH_EPOCH = "1";

	private static Dictionary<string, string> m_Record = new Dictionary<string, string>();
	public static void Add(string name, string value)
	{
		m_Record.Add(name, value);
	}

	//2016/10/20 ogasawara del S WithEpoch対応(MD-仕様-D095)
	//Public Shared Function IsWithEpoch() As Boolean
	//    Return If(m_Record("SYSTEM") = VALUE_WITH_EPOCH, True, False)
	//End Function
	//2016/10/20 ogasawara del E

	//2016/10/20 ogasawara mod S WithEpoch対応(MD-仕様-D095)
	public static string GetWithEpochClientFolderPath()
	{
		return m_Record["LOCALINPUT"];
	}
	//2016/10/20 ogasawara mod E

	//2016/10/20 ogasawara add S WithEpoch対応(MD-仕様-D095)
	public static string GetWithEpochClientDrive()
	{
		return m_Record["LOCALDRIVE"];
	}
	//2016/10/20 ogasawara add E
}
//2016/10/07 ogasawara add E


