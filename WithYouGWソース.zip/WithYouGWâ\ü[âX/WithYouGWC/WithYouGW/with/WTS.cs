﻿using System;
using System.Diagnostics;
using System.Text;
using System.Runtime.InteropServices;
using System.Management;

namespace WithYouGW
{
	public class WTS
	{

		//*********************************************
		//**　　 ターミナルサービスの情報の種類の定義
		//*********************************************
		public enum WTS_INFO_CLASS
		{
			WTSInitialProgram,
			WTSApplicationName,
			WTSWorkingDirectory,
			WTSOEMId,
			WTSSessionId,
			WTSUserName,
			WTSWinStationName,
			WTSDomainName,
			WTSConnectState,
			WTSClientBuildNumber,
			WTSClientName,
			WTSClientDirectory,
			WTSClientProductId,
			WTSClientHardwareId,
			WTSClientAddress,
			WTSClientDisplay,
			WTSClientProtocolType
		}

		//*********************************************
		//**　　 APIの定義
		//*********************************************

		[DllImport("kernel32.dll")]
		private static extern int lstrlen(int Ptr);

		[DllImport("kernel32.dll")]
		private static extern int lstrcpy(int lpString1, int lpString2);

		[DllImport("wtsapi32.dll")]
		private static extern int WTSOpenServer(int pServerName);

		[DllImport("wtsapi32.dll")]
		private static extern void WTSFreeMemory(ref int pMemory);

		[DllImport("wtsapi32.dll")]
		private static extern bool WTSQuerySessionInformation(int hServer, int SessionId, WTS_INFO_CLASS WTSInfoClass, ref int ppBuffer, ref int pBytesReturned);

		//*********************************************
		//**　　 ターミナルサービスより情報を取得
		//*********************************************
		public bool Get_WTSQuerySessionInformation(WTS_INFO_CLASS inWTSInfoClass, ref string wtsClientName)
		{
			string l_strRet = "";

			int hServer = 0;
			bool blnRet = false;
			int dwBytesReturned = 0;
			int lpBuffer = 0;

			hServer = WTSOpenServer(0);

			//API「WTSQuerySessionInformation」でターミナルサービスの情報を取得
			blnRet = WTSQuerySessionInformation(hServer, getTermSessionID(), inWTSInfoClass, ref lpBuffer, ref dwBytesReturned);
			if (blnRet)
			{
				l_strRet = GetStringFromPointer(lpBuffer);

				WTSFreeMemory(ref lpBuffer);
			}

			wtsClientName = l_strRet;

			return blnRet;
		}

		//*********************************************
		//**　　 ポインタから文字列取得
		//*********************************************
		private string GetStringFromPointer(int inPointer)
		{
			string l_strRet = "";

			//文字長取得
			int l_intLen = lstrlen(inPointer);
			if ((l_intLen > 0))
			{
				byte[] bytAry = new byte[l_intLen];

				GCHandle gch = GCHandle.Alloc(bytAry, GCHandleType.Pinned);
				int address = gch.AddrOfPinnedObject().ToInt32();

				lstrcpy(address, inPointer);
				gch.Free();

				Conv_UTF8_to_SJIS(bytAry, ref l_strRet);
			}

			return l_strRet;
		}


		//*********************************************
		//**　　 エンコード変換
		//*********************************************
		private void Conv_UTF8_to_SJIS(byte[] inByte, ref string otStr)
		{
			Encoding strSJIS = Encoding.GetEncoding("Shift-JIS");
			Encoding strUTF8 = Encoding.UTF8;

			byte[] asciiBytes = Encoding.Convert(strUTF8, strSJIS, inByte);
			char[] chrSJIS = new char[strSJIS.GetCharCount(asciiBytes, 0, asciiBytes.Length - 1) + 1];
			strSJIS.GetChars(asciiBytes, 0, asciiBytes.Length, chrSJIS, 0);
			otStr = new string(chrSJIS);
		}

		//*********************************************
		//**　　 プロセスよりセッションIDを取得
		//*********************************************

		private int getTermSessionID()
		{
			const string con_SessionId = "SessionId";

			//object obj32Proc = null;
			//object objProperty = null;
			//int intCount = 0;

			string strSQL = "SELECT " + con_SessionId + " FROM Win32_Process WHERE handle = " + Process.GetCurrentProcess().Id;

			// 処理変更 ikeda 2017/06/01 S
			ManagementObjectSearcher mos = new ManagementObjectSearcher();
			ManagementObjectCollection moc;

			mos.Query.QueryString = strSQL;
			moc = mos.Get();

			foreach (ManagementObject mo in moc)
			{
				return util.ToInt(mo[con_SessionId].ToString());
			}
			// ikeda E

			//	foreach (object obj32Proc in Interaction.GetObject("winmgmts:").ExecQuery(strSQL))
			//	{
			//		foreach (object objProperty_loopVariable in obj32Proc.Properties_)
			//		{
			//			objProperty = objProperty_loopVariable;
			//			if ((objProperty.Name.ToString == con_SessionId))
			//			{
			//				return Convert.ToInt32(objProperty.Value);
			//			}
			//		}
			//		break; // TODO: might not be correct. Was : Exit For
			//	}

			return 0;
		}

	}
}
