﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using System.IO;

namespace WithYouGW
{
	public class Ecloga
	{
		//ECLOGに登録するときのログ種別
		//1.認証ログ　2.アクセスログ　3.操作ログ　4.エラーログ
		public enum LogSyubetsuType
		{
			NinsyouLog = 1,
			AccessLog = 2,
			SousaLog = 3,
			ErrorLog = 4
		}

		public enum TseSetsuzokuType
		{
			NotTse = 0,
			Tse = 1
		}

		private static string m_SyokuinCode = "";
		private static string m_ExeName = "";
		private static string m_ServerName = "";
		private static string m_ClientName = "";

		//値が固定の項目
		//public const string GamenMei = "frmTorikomi";		//[画面名]
		public const string GamenMei = "WithYouGWC";		//[画面名] ikeda chg 2016/06/12 
		public const string FileMei = "";					//[ファイル名](空文字固定)

		//値が出力ごとに変わる項目
		public LogSyubetsuType LogSyubetsu { get; set; }	//[ログ種別]
		public string LogNaiyou { get; set; }				//[ログ内容]
		public int KanjaBangou { get; set; }				//[患者番号]

		//値がプログラム起動時に決まる項目
		public string SyokuinCode							//[職員CD]
		{
			get
			{
				if (string.IsNullOrEmpty(m_SyokuinCode))
				{
					/* exe起動でなく引数がないため削除 ikeda 2016/06/01 職員コードはどうするか？
					//コマンドライン引数から取得する
					m_SyokuinCode = Environment.GetCommandLineArgs()(1);
					*/
					//m_SyokuinCode = Form1.GWConfig.init.user_id;
				}
				return m_SyokuinCode;
			}
		}

		public short TseSetsuzoku           //[TSE接続]
		{
			get
			{
				if (string.IsNullOrEmpty(SousaPcMei))
				{
					return 0;
				}
				else
				{
					return 1;
				}
			}
		}

		public string DousaPcMei            //[動作PC名]
		{
			get
			{
				if (string.IsNullOrEmpty(m_ServerName))
				{
					m_ServerName = Environment.MachineName;
				}
				return m_ServerName;
			}
		}

		public string SousaPcMei            //[操作PC名]
		{
			get
			{
				if (string.IsNullOrEmpty(m_ClientName))
				{
					WTS objWTS = new WTS();
					objWTS.Get_WTSQuerySessionInformation(WTS.WTS_INFO_CLASS.WTSClientName, ref m_ClientName);
					//コンソールログインの場合は結果が空文字のままになるため、便宜的にログイン先のPC名を設定する
					if (string.IsNullOrEmpty(m_ClientName))
					{
						m_ClientName = DousaPcMei;
					}
				}

				if (m_ClientName == DousaPcMei)
				{
					return "";
				}
				else
				{
					return m_ClientName;
				}
			}
		}

		public string ExeMei            //[EXE名]
		{
			get
			{
				if (string.IsNullOrEmpty(m_ExeName))
				{
					dynamic strAppPath = Assembly.GetExecutingAssembly().Location;
					//m_ExeName = Path.GetFileNameWithoutExtension(strAppPath);
				}
				return m_ExeName;
			}
		}
		/*
		public static void WriteLog(LogSyubetsuType syubetsu, string naiyou, int kanjaBangou = 0)
		{
			Eclog objEclog = new Eclog();
			objEclog.LogSyubetsu = syubetsu;
			objEclog.LogNaiyou = naiyou;            //ログ内容
			objEclog.KanjaBangou = kanjaBangou;		//患者番号なしは0をセット

			DBAccess.InsertIntoEclog(objEclog);
		}
		*/
	}
}
