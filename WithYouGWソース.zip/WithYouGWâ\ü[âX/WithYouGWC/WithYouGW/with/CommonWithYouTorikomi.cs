﻿namespace WithYouGW
{
	public class CommonWithYouTorikomi
	{
		//ECDB.医院Ｍ医院固有のWithYou文書連携パス
		private static string m_WithYouBunsyoRenkeiPath = "";
		public static string GetWithYouBunsyoRenkeiPath()
		{
			if (string.IsNullOrEmpty(m_WithYouBunsyoRenkeiPath))
			{
				m_WithYouBunsyoRenkeiPath = DBAccess.GetWithYouBunsyoRenkeiPath();
			}

			return m_WithYouBunsyoRenkeiPath;
		}

		public static int GetKanjaBangouFromFileName(string filename)
		{
			string[] s = filename.Split('_');
			int iKanjaBangou = util.ToInt(s[0]);
			//dynamic iKanjaBangou = int.Parse(s[0]);
			return iKanjaBangou;
		}
	}
}
