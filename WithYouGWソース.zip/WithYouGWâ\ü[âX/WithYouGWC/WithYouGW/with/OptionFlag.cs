﻿using System.Collections.Generic;

public class OptionFlag
{
	//private const string VALUE_BLANK = " ";
	//private const string VALUE_NASHI = "0";
	//private const int OPTION_FLAG_WITHYOU_MENU = 205;
	//private const string VALUE_WITH_EPOCH_ZOKUSEI_RENKEI = "3";

	//private const string VALUE_WITH_EPOCH_ZOKUSEI_AND_KARTE_RENKEI = "4";
	//private static List<string> m_lstm_KinouSeigyoFlag = new List<string>(new string[] { "", "" });

	//private static string GetValue(int num, int keta)
	//{
	//	string strOptionFlag = VALUE_NASHI;
	//	if (m_lstm_KinouSeigyoFlag[num - 1].Length >= keta)
	//	{
	//		strOptionFlag = m_lstm_KinouSeigyoFlag[num - 1].Substring(keta - 1, 1);
	//		if (strOptionFlag == VALUE_BLANK)
	//		{
	//			//オプションフラグが未設定の場合は0とみなす
	//			strOptionFlag = VALUE_NASHI;
	//		}
	//	}
	//	return strOptionFlag;
	//}

	//public static void SetKinouSeigyoFlag1(string val)
	//{
	//	m_lstm_KinouSeigyoFlag[0] = val;
	//}

	//public static void SetKinouSeigyoFlag2(string val)
	//{
	//	m_lstm_KinouSeigyoFlag[1] = val;
	//}

	//public static bool IsWithEpoch()
	//{
	//	string strOptionFlag = GetValue(2, OPTION_FLAG_WITHYOU_MENU);
	//	if ((strOptionFlag == VALUE_WITH_EPOCH_ZOKUSEI_RENKEI) || (strOptionFlag == VALUE_WITH_EPOCH_ZOKUSEI_AND_KARTE_RENKEI))
	//	{
	//		return true;
	//	}
	//	else
	//	{
	//		return false;
	//	}
	//}
}
