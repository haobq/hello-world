﻿//using System;

//namespace WithYouGW
//{
//	//アプリケーションログ出力クラス
//	public class LoggerAppcation //: LoggerBase
//	{

//		//ログ出力先フォルダおよびファイル名

//		private const string LOG_BASENAME = "訪問データ文書登録";
//		//区分が情報のアプリケーションログメッセージ
//		public const string MSG_INFO_START = "起動しました";
//		public const string MSG_INFO_EXIT = "終了しました";
//		public const string MSG_INFO_CHECK_SHARE_FOLDER = "共有フォルダをチェック";
//		public const string MSG_INFO_CSV_PROCESS_START = "「{0}」の処理を開始しました";
//		public const string MSG_INFO_PDF_COPY_COMPLETED = "「{0}」をコピーしました";
//		public const string MSG_INFO_PDF_REGIST_COMPLETED = "「{0}」を登録しました";
//		public const string MSG_INFO_RENKEI_DATA_REGIST_START = "順番号1「{0}」の登録処理を開始します";
//		public const string MSG_INFO_TOUROKU_KENSUU = "{0}件の処理コードを登録しました";
//		public const string MSG_INFO_RENKEI_DATA_REGIST_COMPLETED = "順番号1「{0}」を登録しました";
//		public const string MSG_INFO_FILE_MOVE_COMPLETED = "対象ファイルを移動しました";
//		public const string MSG_INFO_CSV_PROCESS_COMPLETED = "「{0}」の処理を終了しました";

//		public const string MSG_INFO_ALL_PROCESS_COMPLETED = "すべての処理を完了しました";
//		//区分がエラーのアプリケーションログメッセージ
//		public const string MSG_ERR_SETTING_READ_ERROR = "設定ファイル「{0}」が読み込めないため、終了しました";
//		public const string MSG_ERR_FOLDER_ACCESS_ERROR = "フォルダ「{0}」にアクセスできないため、終了しました";
//		public const string MSG_ERR_DB_ACCESS_ERROR = "データベースにアクセスできませんでした";
//		public const string MSG_ERR_TABLE_ACCESS_ERROR = "テーブル「{0}」にアクセスできませんでした";
//		public const string MSG_ERR_CSV_READ_ERROR = "訪問診療データ「{0}」が読み込めませんでした";
//		public const string MSG_ERR_PDF_COPY_ERROR = "文書ファイル「{0}」がコピーできませんでした";
//		public const string MSG_ERR_PDF_REGIST_ERROR = "提供文書連携データ「{0}」が登録できませんでした";
//		public const string MSG_ERR_RENKEI_DATA_REGIST_ERROR = "WithYou連携データが登録できませんでした";
//		public const string MSG_ERR_PDF_MOVE_ERROR = "文書ファイル「{0}」が移動できませんでした";
//		public const string MSG_ERR_CSV_MOVE_ERROR = "訪問診療データ「{0}」が移動できませんでした";
//		public const string MSG_ERR_COMMANDLINE_ERROR = "コマンドライン引数が正しくないため、終了しました";
//		public const string MSG_ERR_DUPLICATE_ERROR = "二重起動のため、終了しました";

//		public const string MSG_ERR_INVALID_CONTENTS = "訪問診療データ「{0}」が不正なため読み込めませんでした";
//		//区分が警告のアプリケーションログメッセージ

//		public const string MSG_WARN_TOUROKUZUMI = "患者番号「{0}」、患者氏名「{1}」、訪問日「{2}」は既にカルテ登録されているため、取込処理は行いませんでした。";
//		//画面表示用のメッセージ
//		public const string MSG_ERR_COMMANDLINE_ERROR_FOR_MSGBOX = "コマンドライン引数が正しくないため、終了します。";
//		public const string MSG_ERR_DUPLICATE_ERROR_FOR_MSGBOX = "二重起動のため、終了します。";
//		public const string MSG_ERR_SETTING_READ_ERROR_FOR_MSGBOX = "設定ファイル「{0}」が読み込めないため、終了します。";

//		public const string MSG_ERR_FOLDER_ACCESS_ERROR_FOR_MSGBOX = "フォルダ「{0}」にアクセスできないため、終了します。";
//		// アプリケーションで唯一のインスタンス

//		private static LoggerAppcation m_Logger = new LoggerAppcation();
//		// コンストラクタ
//		// ログ出力先とファイル名を設定してインスタンスを作成する
//		//private LoggerAppcation() : base(IniFile.init.LogFolder, LOG_BASENAME, BaseNamePosition.Right, FileNameExtension.Txt)
//		//{
//		//}

//		//// インスタンスを取得する
//		//public static LoggerAppcation GetInstance()
//		//{
//		//	return m_Logger;
//		//}

//		////// エラーログを出力する
//		//public void WriteLog(string logMessage)
//		//{
//		//	const string DATE_FORMAT = "HH:mm:ss";
//		//	this.WriteLine(string.Format("{0} {1}", DateTime.Now.ToString(DATE_FORMAT), logMessage));
//		//}

//	}
//}

