using System;
using System.IO;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace WithYouGW
{
	public partial class WithYouRenkeiCSV
	{

		// CSV�쐬���C������
		//   CSV�쐬�͓d�q�J���e���s���̂ł��̏�����DBG�p����
		public static bool CSVMakeProcess(string csvPath)
		{
			//string csvPath = "";
			string[] fileNames;
			bool blnSuccessFlg = true;

			// path���̃t�@�C�������擾
			fileNames = Directory.GetFiles(csvPath);
			foreach (string file in fileNames)
			{
				// ".LCK"������"�捞��"�܂���"�쐬��"���������ꍇ�͏I��
				if (Path.GetExtension(file).CompareTo(Global.C_LCK_Extension) == 0)
				{
					if (file.IndexOf(Global.C_TorikomiFileName) > 0)
					{
						Form1.LoggingDisplay(Global.MSG_WARN_TORIKOMICYU);// �捞���̃G���[��Ԃ�
						return false;
					}
					else if (file.IndexOf(Global.C_SakuseiStartFileName) > 0)
					{
						Form1.LoggingDisplay(Global.MSG_WARN_SAKUSEICYU); // �쐬���̃G���[��Ԃ�
						return false;
					}
				}
			}

			// CSV�쐬����
			{

				// �@�u�쐬���t�@�C���v�쐬
				DateTime date = p_GetCreateDate();
				string createDate = DateTime.Now.ToString("yyyyMMddHHmmss");
				string date_ymd = DateTime.Now.ToString("yyyyMMdd");
				string startFileName = string.Format(@"{0}\{1}{2}{3}", csvPath, Global.C_SakuseiStartFileName, createDate, Global.C_LCK_Extension);
				using (FileStream hStream = File.Create(startFileName))
				{
					if (hStream != null) hStream.Close();
				}

				// �A�u�쐬�����t�@�C���v�̍폜
				// �B�uCSV�t�@�C���v�̍폜
				util.DeleteFiles(fileNames);

				//	�C�eCSV�t�@�C���쐬����
				string csv_tmplate = string.Format(@"{0}\{1}{2}{3}", csvPath, "{0}", createDate, Global.C_CSV_Extension);
				string csvFileName = "";

				if (blnSuccessFlg == true)
				{
					// ���ȉq���m�}�X�^(�E�B���h�E�E�v����M)
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_WinTekiyoM);
					p_CSV_WinTekiyoM(csvFileName, date_ymd);
				}

				if (blnSuccessFlg == true)
				{
					// �͏o���}�X�^
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_Byouinkasan);
					p_CSVMake_ByoinKasan(csvFileName, date_ymd);
				}
				if (blnSuccessFlg == true)
				{
					// ��@���}�X�^
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_Iinkoyu);
					p_CSVMake_Iinkoyu(csvFileName, date_ymd);
				}
				if (blnSuccessFlg == true)
				{
					// ���Ȉ�t�}�X�^
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_IinMDoctorInfo);
					p_CSVMake_IinMDoctorInfo(csvFileName, date_ymd);
				}

				if (blnSuccessFlg == true)
				{
					// �K���}�X�^
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_HoumonsakiM);
					p_CSVMake_HoumonsakiM(csvFileName, date_ymd);
				}
				if (blnSuccessFlg == true)
				{
					// �K�◝�R�}�X�^
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_HoumonRiyuM);
					p_CSVMake_HoumonRiyuM(csvFileName, date_ymd);
				}

				if (blnSuccessFlg == true)
				{
					// ���ҏ��
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_KanjaInfo);
					blnSuccessFlg = p_CSVMake_KanjeInfo(csvFileName, date_ymd);
				}

				// �D�u�쐬�����t�@�C���v���쐬
				string endFileName = string.Format(@"{0}\{1}{2}{3}", csvPath, Global.C_SakuseiEndFileName, createDate, Global.C_LCK_Extension);
				using (FileStream hStream = File.Create(endFileName))
				{
					if (hStream != null) hStream.Close();
				}

				// �E�u�쐬���t�@�C���v���폜
				File.Delete(startFileName);
			}

			//if (blnSuccessFlg) Form1.LogDBG(Global.MSG_INFO_CSV_COMPLETE);

			return true;
		}

		// CSV�쐬���C������(���R�[�h�P��)
		public static bool CSVMakeProcessRecord(string csvPath, out IEnumerable<string> patientIds)
		{
            patientIds = null;

			bool blnSuccessFlg = true;

			DateTime date = p_GetCreateDate();
			string createDate = DateTime.Now.ToString("yyyyMMddHHmmss");
			string date_ymd = DateTime.Now.ToString("yyyyMMdd");

			string csv_tmplate = string.Format(@"{0}\{1}{2}{3}", csvPath, "{0}", createDate, Global.C_CSV_Extension);
			string csvFileName = "";
            bool inierr = false;
            int retry_cnt = DBAccess.GetReTryCnt(ref inierr);

            // �K���}�X�^
            for (int i = 0; i <= retry_cnt; i++)
            {
                if (i > 0) Form1.LoggingDisplay("CSV�쐬���g���C�񐔁F{0}", i.ToString());
                csvFileName = string.Format(csv_tmplate, Global.C_CSV_HoumonsakiM);
                blnSuccessFlg = p_CSVMake_HoumonsakiMRecord(csvFileName, date_ymd);
                if (blnSuccessFlg) break;
            }
            if (!blnSuccessFlg) DBAccess.ChangeIDError(Convert.ToInt32(Global.eFileName.visit_record));

            // 2018.04.12 added �K��惆�j�b�g�a��M
            for (int i = 0; i <= retry_cnt; i++)
            {
                if (i > 0) Form1.LoggingDisplay("CSV�쐬���g���C�񐔁F{0}", i.ToString());
                csvFileName = string.Format(csv_tmplate, Global.C_CSV_HoumonsakiUnitM);
                blnSuccessFlg = p_CSVMake_HoumonsakiUnitMRecord(csvFileName, date_ymd);
                if (blnSuccessFlg) break;
            }
            if (!blnSuccessFlg) DBAccess.ChangeIDError(Convert.ToInt32(Global.eFileName.visit_unit_record));

            // �K�◝�R�}�X�^
            for (int i = 0; i <= retry_cnt; i++)
            {
                if (i > 0) Form1.LoggingDisplay("CSV�쐬���g���C�񐔁F{0}", i.ToString());
                csvFileName = string.Format(csv_tmplate, Global.C_CSV_HoumonRiyuM);
                blnSuccessFlg = p_CSVMake_HoumonRiyuMRecord(csvFileName, date_ymd);
                if (blnSuccessFlg) break;
            }
            if (!blnSuccessFlg) DBAccess.ChangeIDError(Convert.ToInt32(Global.eFileName.reason_record));

            // ���ҏ��n�͂܂Ƃ߂ď�������
            // ���ҏ��
            for (int i = 0; i <= retry_cnt; i++)
            {
                if (i > 0) Form1.LoggingDisplay("CSV�쐬���g���C�񐔁F{0}", i.ToString());
                csvFileName = string.Format(csv_tmplate, Global.C_CSV_KanjaInfo);
                blnSuccessFlg = p_CSVMake_KanjeInfoRecord(csvFileName, date_ymd, out patientIds);
                if (blnSuccessFlg) break;
            }
            if (!blnSuccessFlg) DBAccess.ChangeIDError(Convert.ToInt32(Global.eFileName.patient_record));

            //// ���ҏ��폜
            //csvFileName = string.Format(csv_tmplate, Global.C_CSV_KanjaInfoDelete);
            //blnSuccessFlg = p_CSVMake_KanjeInfoDeleteRecord(csvFileName, date_ymd);

            // �͏o���
            for (int i = 0; i <= retry_cnt; i++)
            {
                if (i > 0) Form1.LoggingDisplay("CSV�쐬���g���C�񐔁F{0}", i.ToString());
                csvFileName = string.Format(csv_tmplate, Global.C_CSV_Byouinkasan);
                blnSuccessFlg = p_CSVMake_ByoinKasanRecord(csvFileName, date_ymd);
                if (blnSuccessFlg) break;
            }
            if (!blnSuccessFlg) DBAccess.ChangeIDError(Convert.ToInt32(Global.eFileName.kasan));

			//2020.02.12 add
			//InitDM�̊J�n�����𓾂�
			var isInitDMDoing = DBAccess.GetDoingInitDM();

			//2020.02.12 modify
			//InitDM���J�n���Ȃ��ꍇ�ɏ�������
			if (!isInitDMDoing)
			{
				//2020.02.04 add
				// ������
				for (int i = 0; i <= retry_cnt; i++)
				{
					if (i > 0) Form1.LoggingDisplay("CSV�쐬���g���C�񐔁F{0}", i.ToString());
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_MedicalHistoryRecord);
					blnSuccessFlg = p_CSVMake_MedicalHistoryRecord(csvFileName);
					if (blnSuccessFlg) break;
				}
				if (!blnSuccessFlg) DBAccess.ChangeIDError(Convert.ToInt32(Global.eFileName.kioureki_record));
			}

			//2020.02.12 modify
			//InitDM���J�n���Ȃ��ꍇ�ɏ�������
			if (!isInitDMDoing)
			{
				//2020.02.04 add
				// ���p�����
				for (int i = 0; i <= retry_cnt; i++)
				{
					if (i > 0) Form1.LoggingDisplay("CSV�쐬���g���C�񐔁F{0}", i.ToString());
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_TakenMedicineRecord);
					blnSuccessFlg = p_CSVMake_TakenMedicineRecord(csvFileName);
					if (blnSuccessFlg) break;
				}
				if (!blnSuccessFlg) DBAccess.ChangeIDError(Convert.ToInt32(Global.eFileName.fukuyoutyuu_yakuzai_record));
			}

			return true;
		}

		// �쐬�������擾(�T�[�o�̓��t)
		private static DateTime p_GetCreateDate()
		{
			DateTime ret = new DateTime();

			try
			{
				ret = DBAccess.GetCreateDate();
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_GetCreateDate", ex.ToString());
			}

			return ret;
		}

		// ���ҏ��CSV�쐬
		private static bool p_CSVMake_KanjeInfo(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetKanjaJouhou(strsakuseiDate);
				foreach (string line in csvData)
				{ Form1.LogDBG(line); }

				util.StringsToFile(csvData, strfileName);
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_KanjeInfo", ex.ToString());
				ret = false;
			}

			return ret;
		}

		// ���ҏ��CSV�쐬(���R�[�h�P��)
		private static bool p_CSVMake_KanjeInfoRecord(string strfileName, string strsakuseiDate, out IEnumerable<string> patientIds)
		{
            patientIds = null;

			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetKanjaJouhouRecord(strsakuseiDate, out patientIds);
				//if (csvData.Count != 0)
				if(csvData.Count >2)	// �w�b�_�ƃG���h�����̎��͏������Ȃ� 2017.12.30
				{
					Form1.LogDBG("���ҏ��CSV");
					foreach (string line in csvData)
					{ Form1.LogDBG(line); }

					if (util.StringsToFile(csvData, strfileName))
						Form1.LoggingDisplay(Global.MSG_INFO_MASTER_CREATE, Path.GetFileName(strfileName));
					else
					{
						Form1.LoggingDisplay(Global.MSG_ERR_MASTER_CREATE_ERR, Path.GetFileName(strfileName));
						ret = false;
					}
				}
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_KanjeInfoRecord", ex.ToString());
				ret = false;
			}

			return ret;
		}

		//// ���ҏ��폜CSV�쐬(���R�[�h�P��)
		//private static bool p_CSVMake_KanjeInfoDeleteRecord(string strfileName, string strsakuseiDate)
		//{
		//	bool ret = true;
		//	List<string> csvData;

		//	try
		//	{
		//		csvData = DBAccess.GetKanjaJouhouDeleteRecord(strsakuseiDate);
		//		if (csvData.Count != 0)
		//		{
		//			Form1.LogDBG("���ҏ��폜CSV");
		//			foreach (string line in csvData)
		//			{ Form1.LogDBG(line); }

		//			if (util.StringsToFile(csvData, strfileName))
		//				Form1.LoggingDisplay(Global.MSG_INFO_MASTER_CREATE, Path.GetFileName(strfileName));
		//			else
		//			{
		//				Form1.LoggingDisplay(Global.MSG_ERR_MASTER_CREATE_ERR, Path.GetFileName(strfileName));
		//				ret = false;
		//			}
		//		}
		//	}
		//	catch (Exception ex)
		//	{
		//		Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, ex.ToString());
		//		ret = false;
		//	}

		//	return ret;
		//}

		// ���ȉq���m�}�X�^(�E�B���h�E�E�v����M)CSV�쐬
		private static bool p_CSV_WinTekiyoM(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetWinTekiyoM(strsakuseiDate);
				foreach (string line in csvData)
				{
					Form1.LogDBG(line);
				}

				util.StringsToFile(csvData, strfileName);

			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSV_WinTekiyoM", ex.ToString());
				ret = false;
			}

			return ret;
		}

		// �K���M CSV�쐬
		private static bool p_CSVMake_HoumonsakiM(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetHoumonsakiM(strsakuseiDate);
				//Form1.LogDBG("�K���CSV");
				foreach (string line in csvData)
				{
					Form1.LogDBG(line);
				}

				util.StringsToFile(csvData, strfileName);
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_HoumonsakiM", ex.ToString());
				ret = false;
			}

			return ret;
		}

		// �K���M CSV�쐬(���R�[�h�P��)
		private static bool p_CSVMake_HoumonsakiMRecord(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetHoumonsakiMRecord(strsakuseiDate);
				if (csvData.Count != 0)
				{
					//Form1.LogDBG("�K���CSV");
					foreach (string line in csvData)
					{ Form1.LogDBG(line); }

					if (util.StringsToFile(csvData, strfileName))
						Form1.LoggingDisplay(Global.MSG_INFO_MASTER_CREATE, Path.GetFileName(strfileName));
					else
					{
						Form1.LoggingDisplay(Global.MSG_ERR_MASTER_CREATE_ERR, Path.GetFileName(strfileName));
						ret = false;
					}
				}
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_HoumonsakiMRecord", ex.ToString());
				ret = false;
			}

			return ret;
		}

        // �K��惆�j�b�g�a��M CSV�쐬(���R�[�h�P��)
        private static bool p_CSVMake_HoumonsakiUnitMRecord(string strfileName, string strsakuseiDate)
        {
            bool ret = true;
            List<string> csvData;

            try
            {
                csvData = DBAccess.GetHoumonsakiUnitMRecord(strsakuseiDate);
                if (csvData.Count != 0)
                {
                    //Form1.LogDBG("�K��惆�j�b�g�a��MCSV");
                    foreach (string line in csvData)
                    { Form1.LogDBG(line); }

                    if (util.StringsToFile(csvData, strfileName))
                        Form1.LoggingDisplay(Global.MSG_INFO_MASTER_CREATE, Path.GetFileName(strfileName));
                    else
                    {
                        Form1.LoggingDisplay(Global.MSG_ERR_MASTER_CREATE_ERR, Path.GetFileName(strfileName));
                        ret = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_HoumonsakiUnitMRecord", ex.ToString());
                ret = false;
            }

            return ret;
        }

        // �K�◝�RM CSV�쐬
        private static bool p_CSVMake_HoumonRiyuM(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetHoumonRiyuM(strsakuseiDate);
				
				//Form1.LogDBG("�K�◝�RCSV");
				foreach (string line in csvData)
				{ Form1.LogDBG(line); }

				util.StringsToFile(csvData, strfileName);
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_HoumonRiyuM", ex.ToString());
				ret = false;
			}

			return ret;
		}

		//// �K�◝�RM CSV�쐬(���R�[�h�P��)
		private static bool p_CSVMake_HoumonRiyuMRecord(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetHoumonRiyuMRecord(strsakuseiDate);
				if (csvData.Count != 0)
				{
					//Form1.LogDBG("�K�◝�RCSV");
					foreach (string line in csvData)
					{ Form1.LogDBG(line); }
					if (util.StringsToFile(csvData, strfileName))
						Form1.LoggingDisplay(Global.MSG_INFO_MASTER_CREATE, Path.GetFileName(strfileName));
					else
					{
						Form1.LoggingDisplay(Global.MSG_ERR_MASTER_CREATE_ERR, Path.GetFileName(strfileName));
						ret = false;
					}
				}
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_HoumonRiyuMRecord", ex.ToString());
				ret = false;
			}

			return ret;
		}

		// ��@�l�a�@���Z CSV�쐬(���R�[�h�P��)
		private static bool p_CSVMake_ByoinKasan(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetByoinKasan(strsakuseiDate);
				//Form1.LogDBG("��@�l�a�@���ZCSV");
				foreach (string line in csvData)
				{ Form1.LogDBG(line); }

				util.StringsToFile(csvData, strfileName);
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_ByoinKasan", ex.ToString());
				ret = false;
			}

			return ret;
		}

		// ��@�l�a�@���Z CSV�쐬
		private static bool p_CSVMake_ByoinKasanRecord(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetByoinKasanRecord(strsakuseiDate);
				if (csvData.Count != 0)
				{
					//Form1.LogDBG("��@M�a�����ZCSV");
					foreach (string line in csvData)
					{ Form1.LogDBG(line); }

					if (util.StringsToFile(csvData, strfileName))
						Form1.LoggingDisplay(Global.MSG_INFO_MASTER_CREATE, Path.GetFileName(strfileName));
					else
					{
						Form1.LoggingDisplay(Global.MSG_ERR_MASTER_CREATE_ERR, Path.GetFileName(strfileName));
						ret = false;
					}
				}
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_ByoinKasanRecord", ex.ToString());
				ret = false;
			}

			return ret;
		}

		// ��@M��@�ŗL�A��@M�K��f�Ðݒ� CSV�쐬
		private static bool p_CSVMake_Iinkoyu(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetIinkoyu(strsakuseiDate);
				foreach (string line in csvData)
				{ Form1.LogDBG(line); }

				util.StringsToFile(csvData, strfileName);
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_Iinkoyu", ex.ToString());
				ret = false;
			}

			return ret;
		}

		// ��@M�h�N�^�[���  CSV�쐬
		private static bool p_CSVMake_IinMDoctorInfo(string strfileName, string strsakuseiDate)
		{
			bool ret = true;
			List<string> csvData;

			try
			{
				csvData = DBAccess.GetIinMDoctorInfo(strsakuseiDate);
				//Form1.LogDBG("��@M�h�N�^�[���CSV");
				foreach (string line in csvData)
				{ Form1.LogDBG(line); }

				util.StringsToFile(csvData, strfileName);
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_IinMDoctorInfo", ex.ToString());
				ret = false;
			}

			return ret;
		}

		public static bool CSVMakeInitDM(string csvPath, IEnumerable<string> patientIds)
		{
			try
			{
				// path���̃t�@�C�������擾
				var fileNames = Directory.GetFiles(csvPath);
				foreach (string file in fileNames)
				{
					// ".LCK"������"�捞��"�܂���"�쐬��"���������ꍇ�͏I��
					if (Path.GetExtension(file).CompareTo(Global.C_LCK_Extension) == 0)
					{
						if (file.IndexOf(Global.C_TorikomiFileName) > 0)
						{
							Form1.LoggingDisplay(Global.MSG_WARN_TORIKOMICYU);// �捞���̃G���[��Ԃ�
							return false;
						}
						else if (file.IndexOf(Global.C_SakuseiStartFileName) > 0)
						{
							Form1.LoggingDisplay(Global.MSG_WARN_SAKUSEICYU); // �쐬���̃G���[��Ԃ�
							return false;
						}
					}
				}

				// CSV�쐬����
				{
					// �@�u�쐬���t�@�C���v�쐬
					DateTime date = p_GetCreateDate();
					string createDate = DateTime.Now.ToString("yyyyMMddHHmmss");
					string date_ymd = DateTime.Now.ToString("yyyyMMdd");
					string startFileName = string.Format(@"{0}\{1}{2}{3}", csvPath, Global.C_SakuseiStartFileName, createDate, Global.C_LCK_Extension);
					using (FileStream hStream = File.Create(startFileName))
					{
						if (hStream != null) hStream.Close();
					}

					// �A�u�쐬�����t�@�C���v�̍폜
					// �B�uCSV�t�@�C���v�̍폜
					util.DeleteFiles(fileNames);

					//	�C�eCSV�t�@�C���쐬����
					string csv_tmplate = string.Format(@"{0}\{1}{2}{3}", csvPath, "{0}", createDate, Global.C_CSV_Extension);
					string csvFileName = "";

					//������
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_MedicalHistory);
					var res = p_CSVMake_MedicalHistory(csvFileName, patientIds);
					if (!res) return false;

					//���p�����
					csvFileName = string.Format(csv_tmplate, Global.C_CSV_TakenMedicine);
					res = p_CSVMake_TakenMedicine(csvFileName, patientIds);
					if (!res) return false;

					// �D�u�쐬�����t�@�C���v���쐬
					string endFileName = string.Format(@"{0}\{1}{2}{3}", csvPath, Global.C_SakuseiEndFileName, createDate, Global.C_LCK_Extension);
					using (FileStream hStream = File.Create(endFileName))
					{
						if (hStream != null) hStream.Close();
					}

					// �E�u�쐬���t�@�C���v���폜
					File.Delete(startFileName);
				}

				//if (blnSuccessFlg) Form1.LogDBG(Global.MSG_INFO_CSV_COMPLETE);

				return true;
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "CSVMakeInitDM", ex.ToString());
				return false;
			}
		}

        private static bool p_CSVMake_MedicalHistory(string strfileName, IEnumerable<string> patientIds)
        {
            try
            {
				//Form1.LoggingDisplay($"[p_CSVMake_MedicalHistory] strfileName: {strfileName}");
				//Form1.LoggingDisplay($"[p_CSVMake_MedicalHistory] patientIds?.Count: {patientIds?.Count()}");
				//Form1.LoggingDisplay($"[p_CSVMake_MedicalHistory] patientIds?.FirstOrDefault: {patientIds?.FirstOrDefault()}");
				var csvData = DBAccess.GetMedicalHistory(patientIds);
				//Form1.LoggingDisplay($"[p_CSVMake_MedicalHistory] csvData.Count: {csvData.Count()}");
				if (csvData == null || !csvData.Any()) return true;
				foreach (var line in csvData)
                {
                    Form1.LogDBG(line);
                }

                util.StringsToFile(csvData.ToList(), strfileName);

                return true;
            }
            catch (Exception ex)
            {
                Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_MedicalHistory", ex.ToString());
                return false;
            }
        }

		//2020.02.04 add
		private static bool p_CSVMake_MedicalHistoryRecord(string strfileName)
		{
			try
			{
				//Form1.LoggingDisplay($"[p_CSVMake_MedicalHistoryRecord] strfileName: {strfileName}");
				var csvData = DBAccess.GetMedicalHistoryRecord();
				//Form1.LoggingDisplay($"[p_CSVMake_MedicalHistoryRecord] csvData.Count: {csvData.Count()}");
				if (csvData.Count() > 2)  // �w�b�_�ƃG���h�����̎��͏������Ȃ�
				{
					Form1.LogDBG("������CSV");
					foreach (string line in csvData)
					{
						Form1.LogDBG(line);
					}

					if (util.StringsToFile(csvData.ToList(), strfileName))
						Form1.LoggingDisplay(Global.MSG_INFO_MASTER_CREATE, Path.GetFileName(strfileName));
					else
					{
						Form1.LoggingDisplay(Global.MSG_ERR_MASTER_CREATE_ERR, Path.GetFileName(strfileName));
						return false;
					}
				}

				return true;
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_MedicalHistoryRecord", ex.ToString());
				return false;
			}
		}

        private static bool p_CSVMake_TakenMedicine(string strfileName, IEnumerable<string> patientIds)
        {
            try
            {
				//Form1.LoggingDisplay($"[p_CSVMake_TakenMedicine] strfileName: {strfileName}");
				//Form1.LoggingDisplay($"[p_CSVMake_TakenMedicine] patientIds?.Count: {patientIds?.Count()}");
				//Form1.LoggingDisplay($"[p_CSVMake_TakenMedicine] patientIds?.FirstOrDefault: {patientIds?.FirstOrDefault()}");
				var csvData = DBAccess.GetTakenMedicine(patientIds);
				//Form1.LoggingDisplay($"[p_CSVMake_TakenMedicine] csvData.Count: {csvData.Count()}");
				if (csvData == null || !csvData.Any()) return true;
				foreach (var line in csvData)
                {
                    Form1.LogDBG(line);
                }

                util.StringsToFile(csvData.ToList(), strfileName);

                return true;
            }
            catch (Exception ex)
            {
                Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_TakenMedicine", ex.ToString());
                return false;
            }
        }

		//2020.02.04 add
		private static bool p_CSVMake_TakenMedicineRecord(string strfileName)
		{
			try
			{
				//Form1.LoggingDisplay($"[p_CSVMake_TakenMedicineRecord] strfileName: {strfileName}");
				var csvData = DBAccess.GetTakenMedicineRecord();
				//Form1.LoggingDisplay($"[p_CSVMake_TakenMedicineRecord] csvData.Count: {csvData.Count()}");
				if (csvData.Count() > 2)  // �w�b�_�ƃG���h�����̎��͏������Ȃ�
				{
					Form1.LogDBG("���p�����CSV");
					foreach (string line in csvData)
					{
						Form1.LogDBG(line);
					}

					if (util.StringsToFile(csvData.ToList(), strfileName))
						Form1.LoggingDisplay(Global.MSG_INFO_MASTER_CREATE, Path.GetFileName(strfileName));
					else
					{
						Form1.LoggingDisplay(Global.MSG_ERR_MASTER_CREATE_ERR, Path.GetFileName(strfileName));
						return false;
					}
				}

				return true;
			}
			catch (Exception ex)
			{
				Form1.LoggingDisplay(Global.MSG_ERR_EXCEPTION, "p_CSVMake_TakenMedicineRecord", ex.ToString());
				return false;
			}
		}

	}
}