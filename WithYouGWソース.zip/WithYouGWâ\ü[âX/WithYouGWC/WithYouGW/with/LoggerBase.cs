﻿//using System;
//using System.IO;
//using System.Reflection;

//// ログ出力処理の基本クラス
//public class LoggerBase
//{
//	//ログファイル名の共通部分の位置
//	protected enum BaseNamePosition
//	{
//		Left,
//		Right
//	}

//	//ログファイル名の拡張子
//	protected enum FileNameExtension
//	{
//		Log,
//		Txt
//	}

//	private string m_CustomLocation;				// ログファイル出力フォルダ
//	private string m_BaseFileName;					// ログファイル名の共通部分
//	private BaseNamePosition m_BaseNamePosition;	// ログファイル名の共通部分の位置
//	private FileNameExtension m_FileNameExtension;	// ログファイル名の拡張子
//	private object m_LockObj = new object();		// ロック処理用インスタンス

//	// コンストラクタ
//	// m_CustomLocationとm_BaseFileNameに値をセットする必要があるため、
//	// 引数なしのコンストラクタはPrivateにしておく

//	private LoggerBase()
//	{
//	}

//	// コンストラクタ
//	// 継承したクラスからのみ呼び出される前提なのでProtected
//	protected LoggerBase(string strCustomLocation, string strBaseFileName, BaseNamePosition eBaseNamePosition = BaseNamePosition.Left, FileNameExtension eFileNameExtension = FileNameExtension.Log)
//	{
//		m_CustomLocation = strCustomLocation;
//		m_BaseFileName = strBaseFileName;
//		m_BaseNamePosition = eBaseNamePosition;
//		m_FileNameExtension = eFileNameExtension;
//	}

//	// ログ出力処理
//	protected void WriteLine(string strMessage)
//	{
//		const string LOG_FILENAME_DELIMITER = "_";
//		const string LOG_FILENAME_DATE_FORMAT = "yyyyMMdd";

//		//拡張子の設定
//		string strLogFileNameExtension = null;
//		if (m_FileNameExtension == FileNameExtension.Log)
//		{
//			strLogFileNameExtension = ".log";
//		}
//		else
//		{
//			strLogFileNameExtension = ".txt";
//		}

//		// ログファイル名の設定
//		string strLogFileName = null;
//		if (m_BaseNamePosition == BaseNamePosition.Left)
//		{
//			strLogFileName = m_BaseFileName + LOG_FILENAME_DELIMITER + DateTime.Today.ToString(LOG_FILENAME_DATE_FORMAT) + strLogFileNameExtension;
//		}
//		else
//		{
//			strLogFileName = DateTime.Today.ToString(LOG_FILENAME_DATE_FORMAT) + LOG_FILENAME_DELIMITER + m_BaseFileName + strLogFileNameExtension;
//		}

//		// ログファイル出力先フォルダとログファイル名を結合し、ログファイルのパスを取得する
//		if (string.IsNullOrEmpty(m_CustomLocation))
//		{
//			//ログ出力先が設定されていない場合はEXEファイルと同じディレクトリに出力する
//			m_CustomLocation = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
//		}
//		else
//		{
//			//ログ出力先が設定されている場合はディレクトリが存在するかチェックし、存在しなければ作成する
//			if (!Directory.Exists(m_CustomLocation))
//			{
//				Directory.CreateDirectory(m_CustomLocation);
//			}
//		}
//		string strLogFilePath = null;
//		strLogFilePath = Path.Combine(m_CustomLocation, strLogFileName);

//		// 下位クラスをSingletonパターンで実装することでログファイルへの同時アクセスを防ぐことができる
//		lock (m_LockObj)
//		{
//			// ログファイルのパスを指定して、StreamWriterのインスタンスを作成する
//			using (StreamWriter sw = new StreamWriter(strLogFilePath, true))
//			{
//				// 存在する場合は追加で書き込み
//				sw.AutoFlush = true;
//				sw.WriteLine(strMessage);
//			}
//		}
//	}

//}


