﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

public class IniSectionInit
{
	[DllImport("KERNEL32.DLL", CharSet = CharSet.Ansi)]
	private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, System.Text.StringBuilder lpReturnedString, int nSize, string lpFileName);

	[DllImport("KERNEL32.DLL", CharSet = CharSet.Ansi)]
	private static extern int WritePrivateProfileString(string lpAppName, string lpKeyName, string lpString, string lpFileName);

	//値の最大サイズ
	const int MAX_VALUE_LENGTH = 1024;
	//キーが見つらなかった場合に返される値のデフォルト値(他の値と偶然一致しないようなランダムな文字列を設定)
	const string KEY_NOT_FOUND_VALUE = "HY5EAOARNKJOOIEMCMGVPJNVUYAD568A";

	const string INVALID_ERROR_MSG_FORMAT = "{0}の設定が正しくありません。{1}=[{2}]";

	public const string COPY_FLAG_ON = "1";
	private string m_IniFilePath;

	private string m_SectionName;
	private string m_ProcFolder;
	private string m_LogFolder;
	private string m_DoneFolder;
	private string m_ErrorFolder;
	private string m_CopyFlag;

	private string m_CopyFolder;

	public string ProcFolder
	{
		get { return m_ProcFolder; }
	}
	public string LogFolder
	{
		get { return m_LogFolder; }
	}
	public string DoneFolder
	{
		get { return m_DoneFolder; }
	}
	public string ErrorFolder
	{
		get { return m_ErrorFolder; }
	}
	public string CopyFlag
	{
		get { return m_CopyFlag; }
	}
	public string CopyFolder
	{
		get { return m_CopyFolder; }
	}

	//iniファイルから指定したセクションおよびキーの値を文字列形式で取得する
	private string GetIniFileString(string key, string defaultValue = KEY_NOT_FOUND_VALUE)
	{
		System.Text.StringBuilder strSb = new System.Text.StringBuilder(MAX_VALUE_LENGTH);
		GetPrivateProfileString(m_SectionName, key, defaultValue, strSb, strSb.Capacity, m_IniFilePath);

		return strSb.ToString();
	}

	private void WriteIniFileString(string key, string value)
	{
		int ret = 0;
		ret = WritePrivateProfileString(m_SectionName, key, value, m_IniFilePath);
		if (ret == 0)
		{
			int hResult = Marshal.GetHRForLastWin32Error();
			Marshal.ThrowExceptionForHR(hResult);
		}
	}

	public IniSectionInit(string iniFilePath, string sectionName)
	{
		m_IniFilePath = iniFilePath;
		m_SectionName = sectionName;

		m_ProcFolder = GetIniFileString("proc_folder", "");
		m_LogFolder = GetIniFileString("log_folder", "");
		m_DoneFolder = GetIniFileString("done_folder", "");
		m_ErrorFolder = GetIniFileString("error_folder", "");
		m_CopyFlag = GetIniFileString("copy_flag", "");
		m_CopyFolder = GetIniFileString("copy_folder", "");
	}

	public void CheckValues()
	{
		//iniファイルから読み込んだ内容をチェックする
		if (string.IsNullOrEmpty(m_ProcFolder))
		{
			throw new Exception(string.Format(INVALID_ERROR_MSG_FORMAT, Path.GetFileName(m_IniFilePath), "proc_folder", m_ProcFolder));
		}

		if (string.IsNullOrEmpty(m_LogFolder))
		{
			throw new Exception(string.Format(INVALID_ERROR_MSG_FORMAT, Path.GetFileName(m_IniFilePath), "log_folder", m_LogFolder));
		}

		if (string.IsNullOrEmpty(m_DoneFolder))
		{
			throw new Exception(string.Format(INVALID_ERROR_MSG_FORMAT, Path.GetFileName(m_IniFilePath), "done_folder", m_DoneFolder));
		}

		if (string.IsNullOrEmpty(m_ErrorFolder))
		{
			throw new Exception(string.Format(INVALID_ERROR_MSG_FORMAT, Path.GetFileName(m_IniFilePath), "error_folder", m_ErrorFolder));
		}

		if (string.IsNullOrEmpty(m_CopyFlag))
		{
			throw new Exception(string.Format(INVALID_ERROR_MSG_FORMAT, Path.GetFileName(m_IniFilePath), "copy_flag", m_CopyFlag));
		}

		if (m_CopyFlag == COPY_FLAG_ON)
		{
			if (string.IsNullOrEmpty(m_CopyFolder))
			{
				throw new Exception(string.Format(INVALID_ERROR_MSG_FORMAT, Path.GetFileName(m_IniFilePath), "copy_folder", m_CopyFolder));
			}
		}
	}

}
