﻿
//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Data;
//using System.Diagnostics;

////エラーログ出力クラス
//public class LoggerError : LoggerBase
//{

//	//ログ出力先フォルダおよびファイル名
//	//ikeda debug 
//	//Private Const LOG_OUTPUT_DIR As String = @"D:\ECDIR\Log\dotnet"
//	private const string LOG_OUTPUT_DIR = @"c:\ECDIR\Log\dotnet";

//	private const string LOG_BASENAME = "WithYouTorikomi";
//	// アプリケーションで唯一のインスタンス

//	private static LoggerError m_Logger = new LoggerError();
//	// コンストラクタ
//	//ログ出力先とファイル名を設定してインスタンスを作成する
//	private LoggerError() : base(LOG_OUTPUT_DIR, LOG_BASENAME, BaseNamePosition.Left, FileNameExtension.Log)
//	{
//	}

//	// インスタンスを取得する
//	public static LoggerError GetInstance()
//	{
//		return m_Logger;
//	}

//	// エラーログを出力する
//	public void WriteLog(Exception ex)
//	{
//		const string DATE_FORMAT = "yyyy/MM/dd HH:mm:ss.fff";
//		dynamic logMessage = string.Format("予期しないエラーが発生しました。エラーメッセージ=[{0}] スタックトレース=[{1}]", ex.Message, ex.StackTrace);
//		this.WriteLine(string.Format("{0} [異常] {1}", DateTime.Now.ToString(DATE_FORMAT), logMessage));
//	}

//}
