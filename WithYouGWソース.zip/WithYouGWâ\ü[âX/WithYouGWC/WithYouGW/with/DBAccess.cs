using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualBasic;
using System.Windows.Forms;
using System.Linq;

namespace WithYouGW
{
	public class TeikyouBunsyo
	{
		public int KanjaBangou { get; set; }
		public System.DateTime Houmonbi { get; set; }
		public string BunsyoCode { get; set; }
		public string BunsyoName { get; set; }
	}

    //2020.01.22 modify
    //public class CsvRecord
    public class CsvRecordClinical
	{
		public int KanjaBangou { get; set; }
		public string KanjaShimei { get; set; }
		public System.DateTime Houmonbi { get; set; }
		public int Junbangou { get; set; }
		public string ShinryouKouiCode { get; set; }
		public string KasanCode { get; set; }
		public string ShinryouKouiName { get; set; }
		public int ShikaIshiCode { get; set; }
		public string ShikaIshiName { get; set; }
		public int ShikaEiseishiCode { get; set; }
		public string ShikaEiseishiName { get; set; }
		public string KaishiJikoku { get; set; }
		public string SyuuryouJikoku { get; set; }
		public string HosokuCode { get; set; }
		public string HosokuJouhou { get; set; }
		public string KaruteKisaiNaiyou { get; set; }
		public string BunsyoFileName { get; set; }
	}

    //2020.01.22 add
    public class CsvRecordCondition
    {
        public int KanjaBangou { get; set; }
        public string KanjaShimei { get; set; }
        public System.DateTime Houmonbi { get; set; }
        public int Junbangou { get; set; }
        public string OrderCode { get; set; }
        public string ShinryouKouiName { get; set; }
        public string Article { get; set; }
    }

    //2020.01.22 add
    public class CsvRecordSOAP
    {
        public int KanjaBangou { get; set; }
        public string KanjaShimei { get; set; }
        public System.DateTime Houmonbi { get; set; }
        public int Junbangou { get; set; }
        public string Kind { get; set; }
        public string Article { get; set; }
    }

    //2020.01.24 add
    public class CsvRecordKarte
    {
        public System.DateTime Houmonbi { get; set; }
        public int Junbangou { get; set; }
        public string KanjaBangou { get; set; }
        public string KanjaShimei { get; set; }
        public string KanjaKana { get; set; }
        public int? ShikaIshiCode { get; set; }
        public string ShikaIshiName { get; set; }
        public int? HojoShikaEiseishiCode { get; set; }
        public string HojoShikaEiseishiName { get; set; }
        public string ShinryouKaishiJikoku { get; set; }
        public string ShinryouSyuuryouJikoku { get; set; }
        public int? ShinryouJikan { get; set; }
        public int? ShidouShikaEiseishiCode { get; set; }
        public string ShidouShikaEiseishiName { get; set; }
        public string ShidouKaishiJikoku { get; set; }
        public string ShidouSyuuryouJikoku { get; set; }
        public int? ShidouJikan { get; set; }
        public string JissekiStatus { get; set; }
        public string VisitName { get; set; }
        public string UnitName { get; set; }
        public int? KoSuu { get; set; }
    }

	//2020.02.04 add
	public class CsvRecordGeneralDisease
	{
		public string patient_id { get; set; }
		public DateTime? measure_date { get; set; }
		public int? seq_no { get; set; }
		public short? mask { get; set; }
		public string regist_user { get; set; }
		public DateTime? regist_date { get; set; }
		public string medical_history { get; set; }
		public string disease_cd { get; set; }
		public string disease_name { get; set; }
		public string medical_facility { get; set; }
		public short? with_seqno { get; set; }
		public short? with_kiorekicd { get; set; }
		public short? with_keika { get; set; }
		public string icd10 { get; set; }
		public string disease_name_kana { get; set; }
		public short? withyou_status { get; set; }
		public short? with_status { get; set; }
		public string with_mod_usercd { get; set; }
		public string with_mod_username { get; set; }
		public DateTime? with_mod_date { get; set; }
	}

	//2020.02.04 add
	public class CsvRecordTakingMedicines
	{
		public string patient_id { get; set; }
		public DateTime? measure_date { get; set; }
		public int? seq_no { get; set; }
		public short? mask { get; set; }
		public string regist_user { get; set; }
		public DateTime? regist_date { get; set; }
		public short? medical_history { get; set; }
		public string yakka_code { get; set; }
		public string medicine_name { get; set; }
		public string medical_facility { get; set; }
		public short? with_seqno { get; set; }
		public short? withyou_status { get; set; }
		public short? with_status { get; set; }
		public string with_mod_usercd { get; set; }
		public string with_mod_username { get; set; }
		public DateTime? with_mod_date { get; set; }
	}

	public class TorikomiKekkaInfo
	{
		public int KanjaBangou { get; set; }
		public string KanjaShimei { get; set; }
		public DateTime Houmonbi { get; set; }
		public Torikomi.eTorikomiKekkaType TorikomiKekka { get; set; }
		public string FileName { get; set; }
	}
	
	public class HenkanMaster
	{
		public string MasterKanriCode { get; set; }
		public string OrderCode { get; set; }
		public short Junbangou { get; set; }
		public int SyochiCode { get; set; }
		public int DaihyouCode { get; set; }
		public short HenkanSyubetsu { get; set; }

		private static List<HenkanMaster> m_HenkanMasterList;
		public static List<HenkanMaster> GetHenkanMasterByOrderCode(string masterKanriCode, string orderCode)
		{
			if (m_HenkanMasterList == null)
			{
				//WithYou�A�g�ϊ��}�X�^�̓��e���擾����
				m_HenkanMasterList = DBAccess.GetWithYouRenkeiHenkanMaster();
			}

			List<HenkanMaster> lstHenkanMasterList = new List<HenkanMaster>();
			foreach(HenkanMaster itm in m_HenkanMasterList)
			{
				if ((itm.MasterKanriCode == masterKanriCode) && (itm.OrderCode == orderCode))
				{
					lstHenkanMasterList.Add((HenkanMaster)itm.MemberwiseClone());
				}
			}

			return lstHenkanMasterList;
		}
	}

	public class DBAccessBase
	{
		static public string m_changeIDs_visit = "";
        //2018.04.12 added
        static public string m_changeIDs_visit_unit = "";
        static public string m_changeIDs_reason = "";
		static public string m_changeIDs_patient = "";
		static public string m_deleteIDs_patient = "";
		static public string m_changeIDs_kasan = "";

		private static string GetDBConnectionString(string initialCatalog)
		{

			const string CON_STR_TEMPLATE = "Data Source={0};User ID={1};Password={2};Initial Catalog={3}";
			//const string DB_USERID = "sa";
			//const string DB_PASSWORD = "";

			string strConStr = null;

			string strDBServerName = "";
			
			if (Global.DBG_FLG)
				strDBServerName = Common.GetDBServerNameDebug();
			else strDBServerName = Common.GetDBServerName();

			//strConStr = string.Format(CON_STR_TEMPLATE, strDBServerName, DB_USERID, DB_PASSWORD, initialCatalog);
			//strConStr = string.Format(CON_STR_TEMPLATE, Global.prm_db_server, Global.prm_db_user, Global.prm_db_password, initialCatalog);
			strConStr = string.Format("Data Source={0};User ID={1};Password={2};Initial Catalog=ECDB", 
				 Global.prm_db_server, Global.prm_db_user, Global.prm_db_password);

			//strConStr = string.Format(CON_STR_TEMPLATE, , DB_USERID, DB_PASSWORD, initialCatalog);

			// debug�p
			if (Global.DBG_FLG)
				//strConStr = "Data Source=172.17.5.201;User ID=sa;Password=Media12@;Initial Catalog=ECDB";
				strConStr = string.Format("Data Source={0};User ID={1};Password=Media12@;Initial Catalog=ECDB",
				Global.prm_db_server, Global.prm_db_user, Global.prm_db_password);

			return strConStr;
		}

		public static string GetECDBConnectionString()
		{
			return GetDBConnectionString("ECDB");
		}

		public static SqlConnection GetConnectionWithOpen()
		{
			SqlConnection con = new SqlConnection();
			con.ConnectionString = GetECDBConnectionString();

			try
			{
				con.Open();
			}
			catch (Exception ex)
			{
				//dynamic objAppLogger = LoggerAppcation.GetInstance();
				//objAppLogger.WriteLog(LoggerAppcation.MSG_ERR_DB_ACCESS_ERROR);
				//dynamic objErrLogger = LoggerError.GetInstance();
				//objErrLogger.WriteLog(ex);
				Form1.LoggingDisplay(Global.MSG_ERR_DB_ACCESS_ERROR);

				throw;
			}
			return con;
		}
	}

	public class DBAccess : DBAccessBase
	{
		/*
		public static List<Dictionary<string, object>> GetGengouM()
		{
			List<Dictionary<string, object>> objList = new List<Dictionary<string, object>>();

			const string SQL_TEMPLATE = "SELECT �����R�[�h, ��������, �����J�n�N���� " + 
										"  FROM ECDB.dbo.����M " + 
										" ORDER BY �����J�n�N���� ";

			using (SqlConnection con = GetConnectionWithOpen())
			{
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.CommandText = SQL_TEMPLATE;
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						if (dr.HasRows)
						{
							while (dr.Read())
							{
								Dictionary<string, object> objDict = new Dictionary<string, object>();
								int iColumnCount = dr.FieldCount;
								for (int i = 0; i <= iColumnCount - 1; i++)
								{
									objDict.Add(dr.GetName(i), dr.GetValue(i));
								}
								objList.Add(objDict);
							}
						}
					}
				}
			}

			return objList;
		}
		*/

		public static string GetYYMM(System.DateTime shinryouNengappi)
		{
			string strYYMM = null;

			const string SQL_TEMPLATE = "SELECT TOP 1 DB�������� " +
										"FROM ECDB.dbo.��@�l�}�X�^�Ǘ� " +
										"WHERE �J�n�N����<=@ShinryouNengappi " +
										"ORDER BY �J�n�N���� DESC ";

			using (SqlConnection con = GetConnectionWithOpen())
			{
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.CommandText = SQL_TEMPLATE;
					cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						if (dr.HasRows)
						{
							dr.Read();
							strYYMM = (string)dr.GetSqlString(dr.GetOrdinal("DB��������"));
						}
						else
						{
							//�G���[
							throw new Exception(string.Format("��@�l�}�X�^�Ǘ�����DB�������̂̎擾�Ɏ��s���܂����B�f�ÔN����=[{0}]", shinryouNengappi.ToString("yyyy/MM/dd")));
						}
					}
				}
			}

			return strYYMM;
		}

		//2020.02.18
		public static IEnumerable<string> GetAllYYMM()
		{
			const string SQL_TEMPLATE = "SELECT DB�������� " +
										"FROM ECDB.dbo.��@�l�}�X�^�Ǘ� " +
										"ORDER BY �J�n�N���� DESC ";

			using (var con = GetConnectionWithOpen())
			using (var cmd = new SqlCommand(SQL_TEMPLATE, con))
			using (var adpt = new SqlDataAdapter(cmd))
			using (var dt = new DataTable())
			{
				adpt.Fill(dt);
				if (dt?.Rows?.Count <= 0)
				{
					//�G���[
					throw new Exception("��@�l�}�X�^�Ǘ�����DB�������̂̎擾�Ɏ��s���܂����B�f�ÔN����=�S�f�[�^");
				}
				return dt.AsEnumerable()
					.Select(s => s.Field<string>("DB��������"))
					.ToArray();
			}
		}

		public static List<HenkanMaster> GetWithYouRenkeiHenkanMaster()
		{
			List<HenkanMaster> lstHenkanMaster = new List<HenkanMaster>();

			const string SQL_TEMPLATE = "SELECT [�}�X�^�Ǘ��R�[�h] " +
										"      ,[�I�[�_�[�R�[�h] " +
										"      ,[���ԍ�] " +
										"      ,[���u�R�[�h] " +
										"      ,[��\�R�[�h] " +
										"      ,[�ϊ����] " +
										"  FROM ECDOC.dbo.[WithYou�A�g�ϊ��}�X�^] " +
										" WHERE [�}�X�N] = 0";

			using (SqlConnection con = GetConnectionWithOpen())
			{
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.CommandText = SQL_TEMPLATE;
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						if (dr.HasRows)
						{
							while (dr.Read())
							{
								HenkanMaster objHenkanMaster = new HenkanMaster();
								objHenkanMaster.MasterKanriCode = (string)dr.GetValue(dr.GetOrdinal("�}�X�^�Ǘ��R�[�h"));
								objHenkanMaster.OrderCode = (string)dr.GetValue(dr.GetOrdinal("�I�[�_�[�R�[�h"));
								objHenkanMaster.Junbangou = (short)dr.GetValue(dr.GetOrdinal("���ԍ�"));
								objHenkanMaster.SyochiCode = (int)dr.GetValue(dr.GetOrdinal("���u�R�[�h"));
								objHenkanMaster.DaihyouCode = (int)dr.GetValue(dr.GetOrdinal("��\�R�[�h"));
								objHenkanMaster.HenkanSyubetsu = (short)dr.GetValue(dr.GetOrdinal("�ϊ����"));
								lstHenkanMaster.Add(objHenkanMaster);
							}
						}
						else
						{
							//�G���[
							throw new Exception("WithYou�A�g�ϊ��}�X�^�̎擾�Ɏ��s���܂����B");
						}
					}
				}
			}

			return lstHenkanMaster;
		}

		public static string GetWithYouBunsyoRenkeiPath()
		{
			string strRenkeiPath = null;

			const string SQL_TEMPLATE = "SELECT TOP 1 [WithYou�����A�g�p�X] " +
										"  FROM ECDB.dbo.��@�l��@�ŗL ";

			using (SqlConnection con = GetConnectionWithOpen())
			{
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.CommandText = SQL_TEMPLATE;
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						if (dr.HasRows)
						{
							dr.Read();
							strRenkeiPath = (string)dr.GetValue(dr.GetOrdinal("WithYou�����A�g�p�X"));
						}
						else
						{
							throw new Exception("WithYou�����A�g�p�X�̎擾�Ɏ��s���܂����B");
						}
					}
				}
			}

			return strRenkeiPath;
		}

		public static int GetMaxJunbangou(int kanjaBangou, System.DateTime shinryouNengappi, int bunsyoBangou)
		{
			int iMaxJunbangou = 0;

			const string SQL_TEMPLATE = "SELECT TOP 1 ���ԍ� " +
										"  FROM ECDOC.dbo.WithYou�����A�g " +
										" WHERE ���Ҕԍ� = @KanjaBangou " +
										"   AND �f�Ó� = @ShinryouNengappi " +
										"   AND �����ԍ� = @BunsyoBangou " +
										" ORDER BY ���ԍ� DESC ";

			using (SqlConnection con = GetConnectionWithOpen())
			{
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.CommandText = SQL_TEMPLATE;
					cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
					cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;
					cmd.Parameters.Add("@BunsyoBangou", SqlDbType.Int).Value = bunsyoBangou;

					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						if (dr.HasRows)
						{
							dr.Read();
							iMaxJunbangou = (int)dr.GetSqlInt32(dr.GetOrdinal("���ԍ�"));
						}
						else
						{
							iMaxJunbangou = 0;
						}
					}
				}
			}

			return iMaxJunbangou;
		}

		public static bool InsertIntoWithYouBunsyoRenkei(string pdfFilePath, TeikyouBunsyo teikyouBunsyo)
		{
			try
			{
				const string SQL_TEMPLATE = "INSERT INTO ECDOC.dbo.[WithYou�����A�g] " +
					"           ([���Ҕԍ�] " +
					"           ,[�f�Ó�] " +
					"           ,[�����ԍ�] " +
					"           ,[���ԍ�] " +
					"           ,[PDF�p�X] " +
					"           ,[�捞�t���O] " +
					"           ,[PdfRpt_UID] " +
					"           ,[�폜�t���O]) " +
					"     VALUES " +
					"           (@KanjaBangou " +
					"           ,@ShinryouNengappi " +
					"           ,@BunsyoBangou " +
					"           ,@Junbangou " +
					"           ,@PdfPath " +
					"           ,0 " +
					"           ,0 " +
					"           ,0)";

				//�ő叇�ԍ����擾����
				int iMaxJunbangou = GetMaxJunbangou(teikyouBunsyo.KanjaBangou, teikyouBunsyo.Houmonbi, Convert.ToInt32(teikyouBunsyo.BunsyoCode));

				using (SqlConnection con = GetConnectionWithOpen())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.CommandText = SQL_TEMPLATE;
						cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = teikyouBunsyo.KanjaBangou;
						cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = teikyouBunsyo.Houmonbi;
						cmd.Parameters.Add("@BunsyoBangou", SqlDbType.Int).Value = Convert.ToInt32(teikyouBunsyo.BunsyoCode);
						cmd.Parameters.Add("@Junbangou", SqlDbType.Int).Value = iMaxJunbangou + 1;
						cmd.Parameters.Add("@PdfPath", SqlDbType.VarChar).Value = pdfFilePath;

						cmd.ExecuteNonQuery();
					}
				}

				return true;
			}
			catch (Exception ex)
			{
				//dynamic objAppLogger = LoggerAppcation.GetInstance();
				//objAppLogger.WriteLog(ex.Message);

				//dynamic objErrLogger = LoggerError.GetInstance();
				//objErrLogger.WriteLog(ex);
				Form1.LoggingDisplay(ex.Message);

				//Windows�̃G���[���b�Z�[�W��ECLOG�ɏ�������
				//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, teikyouBunsyo.KanjaBangou);

				return false;
			}
		}

		public static int GetKarute1Count(int kanjaBangou, System.DateTime shinryouNengappi, string yymm)
		{
			int iRecordCount = 0;

			const string SQL_TEMPLATE = "SELECT COUNT(���Ҕԍ�) " +
										"  FROM ECDB{0}.dbo.[�J���e1] " +
										"  WHERE [�f�ÔN����] = @ShinryouNengappi " +
										"    AND [���Ҕԍ�] = @KanjaBangou " +
										"    AND [�폜�t���O] = 0 ";

			using (SqlConnection con = GetConnectionWithOpen())
			{
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.CommandText = string.Format(SQL_TEMPLATE, yymm);
					cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
					cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						if (dr.HasRows)
						{
							dr.Read();
							iRecordCount = (int)dr.GetSqlInt32(0);
						}
						else
						{
							iRecordCount = 0;
						}
					}
				}
			}

			return iRecordCount;
		}

		public static void UpdateRenkeiDataSyoriKubun(SqlConnection con, SqlTransaction tran, int kanjaBangou, System.DateTime shinryouNengappi)
		{
			const string SQL_TEMPLATE = "UPDATE ECDOC.dbo.[WithYou�A�g�f�[�^] " +
										"   SET [�����敪] = 2 " +
										" WHERE [���Ҕԍ�] = @KanjaBangou " +
										"   AND [�f�ÔN����] = @ShinryouNengappi " +
										"   AND [�����敪] = 1 ";

			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				cmd.CommandText = SQL_TEMPLATE;
				cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
				cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

				cmd.ExecuteNonQuery();
			}
		}

        //2020.01.22 add
        public static void UpdateRenkeiData2SyoriKubun(SqlConnection con, SqlTransaction tran, int kanjaBangou, System.DateTime shinryouNengappi)
        {
            const string SQL_TEMPLATE = "UPDATE ECDOC.dbo.[WithYou�A�g�f�[�^2] " +
                                        "   SET [�����敪] = 2 " +
                                        " WHERE [���Ҕԍ�] = @KanjaBangou " +
                                        "   AND [�f�ÔN����] = @ShinryouNengappi " +
                                        "   AND [�����敪] = 1 ";

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
                cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

                cmd.ExecuteNonQuery();
            }
        }

        //2020.01.22 add
        public static void UpdateRenkeiDataSOAPSyoriKubun(SqlConnection con, SqlTransaction tran, int kanjaBangou, System.DateTime shinryouNengappi)
        {
            const string SQL_TEMPLATE = "UPDATE ECDOC.dbo.[WithYou�A�g�f�[�^SOAP] " +
                                        "   SET [�����敪] = 2 " +
                                        " WHERE [���Ҕԍ�] = @KanjaBangou " +
                                        "   AND [�f�ÔN����] = @ShinryouNengappi " +
                                        "   AND [�����敪] = 1 ";

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
                cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

                cmd.ExecuteNonQuery();
            }
        }

        //2020.01.24 add
        public static void RemoveWithYouKarteNyuuryokuList(SqlConnection con, SqlTransaction tran, DateTime shinryouNengappi)
        {
            const string SQL_TEMPLATE = "DELETE ECDOC.dbo.[WithYou�J���e���̓��X�g] " +
                                        " WHERE [�f�ÔN����] = @ShinryouNengappi ";

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

                cmd.ExecuteNonQuery();
            }
        }

		public static void UpdateBunsyoRenkeiSakujoFlag(SqlConnection con, SqlTransaction tran, int kanjaBangou, System.DateTime shinryouNengappi)
		{
			const string SQL_TEMPLATE = "UPDATE ECDOC.dbo.[WithYou�����A�g] " +
										"   SET [�폜�t���O] = 1 " +
										" WHERE [���Ҕԍ�] = @KanjaBangou " +
										"   AND [�f�Ó�] = @ShinryouNengappi " +
										"   AND [�捞�t���O] = 0 ";

			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				cmd.CommandText = SQL_TEMPLATE;
				cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
				cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

				cmd.ExecuteNonQuery();
			}
		}

        //2020.01.22 modify
        //public static short GetMaxJunbangou1(SqlConnection con, SqlTransaction tran, int kanjaBangou, System.DateTime shinryouNengappi)
        public static short GetMaxJunbangou1RenkeiData(SqlConnection con, SqlTransaction tran, int kanjaBangou, System.DateTime shinryouNengappi)
		{
			short shMaxJunbangou1 = 0;

			const string SQL_TEMPLATE = "SELECT TOP 1 ���ԍ�1 " +
										"  FROM ECDOC.dbo.WithYou�A�g�f�[�^ " +
										" WHERE ���Ҕԍ� = @KanjaBangou " +
										"   AND �f�ÔN���� = @ShinryouNengappi " +
										" ORDER BY ���ԍ�1 DESC ";
			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				cmd.CommandText = SQL_TEMPLATE;
				cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
				cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

				using (SqlDataReader dr = cmd.ExecuteReader())
				{
					if (dr.HasRows)
					{
						dr.Read();
						shMaxJunbangou1 = (short)dr.GetValue(dr.GetOrdinal("���ԍ�1"));
					}
					else
					{
						shMaxJunbangou1 = 0;
					}
				}
			}

			return shMaxJunbangou1;
		}

        //2020.01.22 add
        public static short GetMaxJunbangou1RenkeiData2(SqlConnection con, SqlTransaction tran, int kanjaBangou, System.DateTime shinryouNengappi)
        {
            short shMaxJunbangou1 = 0;

            const string SQL_TEMPLATE = "SELECT TOP 1 ���ԍ�1 " +
                                        "  FROM ECDOC.dbo.WithYou�A�g�f�[�^2 " +
                                        " WHERE ���Ҕԍ� = @KanjaBangou " +
                                        "   AND �f�ÔN���� = @ShinryouNengappi " +
                                        " ORDER BY ���ԍ�1 DESC ";
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
                cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        dr.Read();
                        shMaxJunbangou1 = (short)dr.GetValue(dr.GetOrdinal("���ԍ�1"));
                    }
                    else
                    {
                        shMaxJunbangou1 = 0;
                    }
                }
            }

            return shMaxJunbangou1;
        }

        //2020.01.22 add
        public static short GetMaxJunbangou1RenkeiDataSOAP(SqlConnection con, SqlTransaction tran, int kanjaBangou, System.DateTime shinryouNengappi)
        {
            short shMaxJunbangou1 = 0;

            const string SQL_TEMPLATE = "SELECT TOP 1 ���ԍ� " +
                                        "  FROM ECDOC.dbo.WithYou�A�g�f�[�^SOAP " +
                                        " WHERE ���Ҕԍ� = @KanjaBangou " +
                                        "   AND �f�ÔN���� = @ShinryouNengappi " +
                                        " ORDER BY ���ԍ� DESC ";
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = kanjaBangou;
                cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        dr.Read();
                        shMaxJunbangou1 = (short)dr.GetValue(dr.GetOrdinal("���ԍ�"));
                    }
                    else
                    {
                        shMaxJunbangou1 = 0;
                    }
                }
            }

            return shMaxJunbangou1;
        }

        //2020.01.24 add
        public static short GetMaxRirekibangouKarteNyuuryokuList(SqlConnection con, SqlTransaction tran, DateTime shinryouNengappi)
        {
            short shMaxRirekibangou = 0;

            const string SQL_TEMPLATE = "SELECT TOP 1 ����ԍ� " +
                                        "  FROM ECDOC.dbo.WithYou�J���e���̓��X�g " +
                                        " WHERE �f�ÔN���� = @ShinryouNengappi " +
                                        " ORDER BY ����ԍ� DESC ";
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = shinryouNengappi;

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        dr.Read();
                        shMaxRirekibangou = (short)dr.GetValue(dr.GetOrdinal("����ԍ�"));
                    }
                    else
                    {
                        shMaxRirekibangou = 0;
                    }
                }
            }

            return shMaxRirekibangou;
        }

        //2020.01.22 modify
        //public static int InsertIntoWithYouRenkeiData(SqlConnection con, SqlTransaction tran, List<CsvRecord> lstCsvData, string masterKanriCode, short junbangou1)
        public static int InsertIntoWithYouRenkeiData(SqlConnection con, SqlTransaction tran, List<CsvRecordClinical> lstCsvData, string masterKanriCode, short junbangou1)
		{
			const short SYORI_KUBUN_SHINKI = 1;
			const string SQL_TEMPLATE =
				"INSERT INTO ECDOC.dbo.[WithYou�A�g�f�[�^] " +
				"           ([���Ҕԍ�] " +
				"           ,[�f�ÔN����] " +
				"           ,[���ԍ�1] " +
				"           ,[���ԍ�2] " +
				"           ,[���u�R�[�h] " +
				"           ,[��\�R�[�h] " +
				"           ,[�I�[�_�[�R�[�h] " +
				"           ,[�f�Ís�ז���] " +
				"           ,[��] " +
				"           ,[�l1] " +
				"           ,[�l2] " +
				"           ,[�q���m��] " +
				"           ,[�R�����g] " +
				"           ,[�쐬����] " +
				"           ,[�����敪] " +
				"           ,[�f�Ë敪] " +
				"           ,[�f�Ë敪����] " +
				"           ,[�h�N�^�[�R�[�h] " +
				"           ,[�h�N�^�[��]) " +
				"     VALUES " +
				"           (@KanjaBangou " +
				"           ,@ShinryouNengappi " +
				"           ,@Junbangou1 " +
				"           ,@Junbangou2 " +
				"           ,@SyochiCode " +
				"           ,@DaihyouCode " +
				"           ,@OrderCode " +
				"           ,@ShinryouKouiMeisyou " +
				"           ,@Kaisuu " +
				"           ,@Atai1 " +
				"           ,@Atai2 " +
				"           ,@EiseishiMei " +
				"           ,@Comment " +
				"           ,@SakuseiJikan " +
				"           ,@SyoriKubun " +
				"           ,@ShinryouKubun " +
				"           ,@ShinryouKubunMeisyou " +
				"           ,@DoctorCode " +
				"           ,@DoctorName) ";

			int iTourokuKensuu = 0;

			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				cmd.CommandText = SQL_TEMPLATE;
				short iJunbangou2 = 0;
                //2020.01.22 modify
                //foreach (CsvRecord rec in lstCsvData)
                foreach (var rec in lstCsvData)
				{
					//WithYou�A�g�ϊ��}�X�^�̃I�[�_�[�R�[�h����v���郌�R�[�h�������J��Ԃ�
					// C#��Strings.Right�����̏������Ȃ��̂Ŏ��� ikeda 2016/06/01 S
					//string strOrderCode = Strings.Right("0000000000" + rec.ShinryouKouiCode, 10) + Strings.Right("00" + rec.HosokuCode, 2);
					string s1 = "0000000000" + rec.ShinryouKouiCode;
					string s2 = "00" + rec.HosokuCode;
					string strOrderCode = s1.Substring(s1.Length - 10, 10) + s2.Substring(s2.Length - 2, 2);
					// ikeda E
					List<HenkanMaster> lstHenkanMaster = HenkanMaster.GetHenkanMasterByOrderCode(masterKanriCode, strOrderCode);
					foreach (HenkanMaster itm in lstHenkanMaster)
					{
						iJunbangou2 += 1;
						cmd.Parameters.Clear();
						cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = rec.KanjaBangou;
						cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = rec.Houmonbi;
						cmd.Parameters.Add("@Junbangou1", SqlDbType.SmallInt).Value = junbangou1;
						cmd.Parameters.Add("@Junbangou2", SqlDbType.SmallInt).Value = iJunbangou2;
						cmd.Parameters.Add("@SyochiCode", SqlDbType.Int).Value = itm.SyochiCode;
						cmd.Parameters.Add("@DaihyouCode", SqlDbType.Int).Value = itm.DaihyouCode;
						cmd.Parameters.Add("@OrderCode", SqlDbType.VarChar).Value = strOrderCode;
                        //�f�Ís�׃R�[�h�{�⑫�R�[�h
                        // 2019.08.08 mod sugano 64�o�C�g�Ő؂��Ă���
                        if (util.GetStringByteLength(rec.ShinryouKouiName) > 64)
                        {
                            byte[] kouiByte = util.EncodeShiftJis.GetBytes(rec.ShinryouKouiName);
                            string koui = util.EncodeShiftJis.GetString(kouiByte, 0, 64);
                            if (koui.EndsWith("�E")) koui = util.EncodeShiftJis.GetString(kouiByte, 0, 63);
                            cmd.Parameters.Add("@ShinryouKouiMeisyou", SqlDbType.VarChar).Value = koui;
                        }
                        else
                        {
                            cmd.Parameters.Add("@ShinryouKouiMeisyou", SqlDbType.VarChar).Value = rec.ShinryouKouiName;
                        }
						cmd.Parameters.Add("@Kaisuu", SqlDbType.SmallInt).Value = 1;
						//�񐔂�1�Œ�
						if (string.IsNullOrEmpty(rec.KaishiJikoku))
						{
							//�J�n�����Ȃ��̏ꍇ��NULL
							cmd.Parameters.Add("@Atai1", SqlDbType.Real).Value = DBNull.Value;
						}
						else
						{
							cmd.Parameters.Add("@Atai1", SqlDbType.Real).Value = float.Parse(rec.KaishiJikoku.Replace(":", ""));
						}
						if (string.IsNullOrEmpty(rec.SyuuryouJikoku))
						{
							//�I�������Ȃ��̏ꍇ��NULL
							cmd.Parameters.Add("@Atai2", SqlDbType.Real).Value = DBNull.Value;
						}
						else
						{
							cmd.Parameters.Add("@Atai2", SqlDbType.Real).Value = float.Parse(rec.SyuuryouJikoku.Replace(":", ""));
						}
						cmd.Parameters.Add("@EiseishiMei", SqlDbType.VarChar).Value = rec.ShikaEiseishiName;
						cmd.Parameters.Add("@Comment", SqlDbType.VarChar).Value = rec.ShikaEiseishiName;
						cmd.Parameters.Add("@SakuseiJikan", SqlDbType.DateTime).Value = System.DateTime.Now;
						cmd.Parameters.Add("@SyoriKubun", SqlDbType.SmallInt).Value = SYORI_KUBUN_SHINKI;
						cmd.Parameters.Add("@ShinryouKubun", SqlDbType.SmallInt).Value = DBNull.Value;
						cmd.Parameters.Add("@ShinryouKubunMeisyou", SqlDbType.VarChar).Value = DBNull.Value;
						cmd.Parameters.Add("@DoctorCode", SqlDbType.Int).Value = rec.ShikaIshiCode;

                        // WithYou�̈�t����40byte�̂���20byte�ŋ�؂� 2017.12.30 add
                        //if (rec.ShikaIshiName.Length > 20)
                        // 2019.08.01 mod sugano �����񒷂���Ȃ���byte���Ń`�F�b�N����
                        if (util.GetStringByteLength(rec.ShikaIshiName) > 20)
                        {
							string doctor = rec.ShikaIshiName;
							const int ryakuLength = 20;

							// �K��旪�̐���(�K��於�̂̐擪12�o�C�g���g�p�A2byte�����̓r���ł��ꂽ�ꍇ��11�o�C�g���g�p
							byte[] ryakuByte = util.EncodeShiftJis.GetBytes(doctor);
							int length = ryakuByte.Length;
							if (length >= ryakuLength) length = ryakuLength;
							string ryaku = util.EncodeShiftJis.GetString(ryakuByte, 0, length);
							if (ryaku.EndsWith("�E")) ryaku = util.EncodeShiftJis.GetString(ryakuByte, 0, ryakuLength - 1);
							cmd.Parameters.Add("@DoctorName", SqlDbType.VarChar).Value = ryaku;
						}
						else cmd.Parameters.Add("@DoctorName", SqlDbType.VarChar).Value = rec.ShikaIshiName;

						cmd.ExecuteNonQuery();

						iTourokuKensuu += 1;
					}
				}
			}

			return iTourokuKensuu;
		}

        //2020.01.22 add
        public static int InsertIntoWithYouRenkeiData2(SqlConnection con, SqlTransaction tran, List<CsvRecordCondition> lstCsvData, string masterKanriCode, short junbangou1)
        {
            const short SYORI_KUBUN_SHINKI = 1;
            const string SQL_TEMPLATE =
                "INSERT INTO ECDOC.dbo.[WithYou�A�g�f�[�^2] " +
                "           ([���Ҕԍ�] " +
                "           ,[�f�ÔN����] " +
                "           ,[���ԍ�1] " +
                "           ,[���ԍ�2] " +
                "           ,[���u�R�[�h] " +
                "           ,[��\�R�[�h] " +
                "           ,[�I�[�_�[�R�[�h] " +
                "           ,[�f�Ís�ז���] " +
                "           ,[��] " +
                "           ,[�L��] " +
                "           ,[�쐬����] " +
                "           ,[�����敪]) " +
                "     VALUES " +
                "           (@KanjaBangou " +
                "           ,@ShinryouNengappi " +
                "           ,@Junbangou1 " +
                "           ,@Junbangou2 " +
                "           ,@SyochiCode " +
                "           ,@DaihyouCode " +
                "           ,@OrderCode " +
                "           ,@ShinryouKouiMeisyou " +
                "           ,@Kaisuu " +
                "           ,@Article " +
                "           ,@SakuseiJikan " +
                "           ,@SyoriKubun) ";

            int iTourokuKensuu = 0;

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                short iJunbangou2 = 0;
                foreach (var rec in lstCsvData)
                {
                    //WithYou�A�g�ϊ��}�X�^�̃I�[�_�[�R�[�h����v���郌�R�[�h�������J��Ԃ�
                    string s1 = new string('0', 12) + rec.OrderCode;
                    string strOrderCode = s1.Substring(s1.Length - 12, 12);
                    List<HenkanMaster> lstHenkanMaster = HenkanMaster.GetHenkanMasterByOrderCode(masterKanriCode, strOrderCode);
                    foreach (HenkanMaster itm in lstHenkanMaster)
                    {
                        iJunbangou2 += 1;
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = rec.KanjaBangou;
                        cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = rec.Houmonbi;
                        cmd.Parameters.Add("@Junbangou1", SqlDbType.SmallInt).Value = junbangou1;
                        cmd.Parameters.Add("@Junbangou2", SqlDbType.SmallInt).Value = iJunbangou2;
                        cmd.Parameters.Add("@SyochiCode", SqlDbType.Int).Value = itm.SyochiCode;
                        cmd.Parameters.Add("@DaihyouCode", SqlDbType.Int).Value = itm.DaihyouCode;
                        cmd.Parameters.Add("@OrderCode", SqlDbType.VarChar).Value = string.IsNullOrEmpty(strOrderCode) ? DBNull.Value : (object)strOrderCode;
                        //�f�Ís�׃R�[�h�{�⑫�R�[�h
                        // 2019.08.08 mod sugano 64�o�C�g�Ő؂��Ă���
                        if (util.GetStringByteLength(rec.ShinryouKouiName) > 64)
                        {
                            byte[] kouiByte = util.EncodeShiftJis.GetBytes(rec.ShinryouKouiName);
                            string koui = util.EncodeShiftJis.GetString(kouiByte, 0, 64);
                            if (koui.EndsWith("�E")) koui = util.EncodeShiftJis.GetString(kouiByte, 0, 63);
                            cmd.Parameters.Add("@ShinryouKouiMeisyou", SqlDbType.VarChar).Value = koui;
                        }
                        else
                        {
                            cmd.Parameters.Add("@ShinryouKouiMeisyou", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.ShinryouKouiName) ? DBNull.Value : (object)rec.ShinryouKouiName;
                        }
                        //�񐔂�1�Œ�
                        cmd.Parameters.Add("@Kaisuu", SqlDbType.SmallInt).Value = 1;
                        string article = null;
                        if (!string.IsNullOrEmpty(rec.Article))
                        {
                            article = rec.Article
                                .Replace("@@", "\r\n")
                                .Replace(@"\@\@", "@@")
                                ;
                        }
                        cmd.Parameters.Add("@Article", SqlDbType.VarChar).Value = string.IsNullOrEmpty(article) ? "" : (object)article;
                        cmd.Parameters.Add("@SakuseiJikan", SqlDbType.DateTime).Value = System.DateTime.Now;
                        cmd.Parameters.Add("@SyoriKubun", SqlDbType.SmallInt).Value = SYORI_KUBUN_SHINKI;

                        cmd.ExecuteNonQuery();

                        iTourokuKensuu += 1;
                    }
                }
            }

            return iTourokuKensuu;
        }

        //2020.01.22 add
        public static int InsertIntoWithYouRenkeiDataSOAP(SqlConnection con, SqlTransaction tran, List<CsvRecordSOAP> lstCsvData, short junbangou1)
        {
            const short SYORI_KUBUN_SHINKI = 1;
            const string SQL_TEMPLATE =
                "INSERT INTO ECDOC.dbo.[WithYou�A�g�f�[�^SOAP] " +
                "           ([���Ҕԍ�] " +
                "           ,[�f�ÔN����] " +
                "           ,[���ԍ�] " +
                "           ,[�敪] " +
                "           ,[�L��] " +
                "           ,[�쐬����] " +
                "           ,[�����敪]) " +
                "     VALUES " +
                "           (@KanjaBangou " +
                "           ,@ShinryouNengappi " +
                "           ,@Junbangou1 " +
                "           ,@Kind " +
                "           ,@Article " +
                "           ,@SakuseiJikan " +
                "           ,@SyoriKubun) ";

            int iTourokuKensuu = 0;

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                foreach (var rec in lstCsvData)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = rec.KanjaBangou;
                    cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = rec.Houmonbi;
                    cmd.Parameters.Add("@Junbangou1", SqlDbType.Int).Value = junbangou1;
                    cmd.Parameters.Add("@Kind", SqlDbType.Char).Value = rec.Kind;
                    string article = null;
                    if (!string.IsNullOrEmpty(rec.Article))
                    {
                        article = rec.Article
                            .Replace("@@", "\r\n")
                            .Replace(@"\@\@", "@@")
                            ;
                    }
                    cmd.Parameters.Add("@Article", SqlDbType.NText).Value = string.IsNullOrEmpty(article) ? "" : (object)article;
                    cmd.Parameters.Add("@SakuseiJikan", SqlDbType.DateTime).Value = System.DateTime.Now;
                    cmd.Parameters.Add("@SyoriKubun", SqlDbType.SmallInt).Value = SYORI_KUBUN_SHINKI;

                    cmd.ExecuteNonQuery();

                    iTourokuKensuu += 1;
                }
            }

            return iTourokuKensuu;
        }

        //2020.01.24 add
        public static int InsertIntoWithYouKarteNyuuryokuList(SqlConnection con, SqlTransaction tran, IEnumerable<CsvRecordKarte> lstCsvData, short rirekibangou)
        {
            const string SQL_TEMPLATE =
                "INSERT INTO ECDOC.dbo.[WithYou�J���e���̓��X�g] " +
                "           ([�f�ÔN����] " +
                "           ,[���ԍ�] " +
                "           ,[���Ҕԍ�] " +
                "           ,[���Ҏ���] " +
                "           ,[���҃J�i] " +
                "           ,[�h�N�^�[�R�[�h] " +
                "           ,[�h�N�^�[��] " +
                "           ,[�⏕�q���m��] " +
                "           ,[�f�ÊJ�n����] " +
                "           ,[�f�ÏI������] " +
                "           ,[�f�Î���] " +
                "           ,[�w���q���m��] " +
                "           ,[�w���J�n����] " +
                "           ,[�w���I������] " +
                "           ,[�w������] " +
                "           ,[���уX�e�[�^�X] " +
                "           ,[�K��於] " +
                "           ,[�a�����j�b�g��] " +
                "           ,[�ː�] " +
                "           ,[����ԍ�]) " +
                "     VALUES " +
                "           (@ShinryouNengappi " +
                "           ,@Junbangou " +
                "           ,@KanjaBangou " +
                "           ,@KanjaShimei " +
                "           ,@KanjaKana " +
                "           ,@ShikaIshiCode " +
                "           ,@ShikaIshiName " +
                "           ,@HojoShikaEiseishiName " +
                "           ,@ShinryouKaishiJikoku " +
                "           ,@ShinryouSyuuryouJikoku " +
                "           ,@ShinryouJikan " +
                "           ,@ShidouShikaEiseishiName " +
                "           ,@ShidouKaishiJikoku " +
                "           ,@ShidouSyuuryouJikoku " +
                "           ,@ShidouJikan " +
                "           ,@JissekiStatus " +
                "           ,@VisitName " +
                "           ,@UnitName " +
                "           ,@KoSuu " +
                "           ,@RirekiBangou) ";

            int iTourokuKensuu = 0;

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Transaction = tran;
                cmd.CommandText = SQL_TEMPLATE;
                foreach (var rec in lstCsvData)
                {
                    int ri;
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@ShinryouNengappi", SqlDbType.DateTime).Value = rec.Houmonbi;
                    cmd.Parameters.Add("@Junbangou", SqlDbType.SmallInt).Value = (short)rec.Junbangou;
                    cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = Convert.ToInt32(rec.KanjaBangou);
                    cmd.Parameters.Add("@KanjaShimei", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.KanjaShimei) ? DBNull.Value : (object)rec.KanjaShimei;
                    cmd.Parameters.Add("@KanjaKana", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.KanjaKana) ? DBNull.Value : (object)rec.KanjaKana;
                    cmd.Parameters.Add("@ShikaIshiCode", SqlDbType.Int).Value = rec.ShikaIshiCode.HasValue ? (object)rec.ShikaIshiCode.Value : DBNull.Value;
                    cmd.Parameters.Add("@ShikaIshiName", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.ShikaIshiName) ? DBNull.Value : (object)Common.SubstringByte(rec.ShikaIshiName, 0, 20);
                    cmd.Parameters.Add("@HojoShikaEiseishiName", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.HojoShikaEiseishiName) ? DBNull.Value : (object)rec.HojoShikaEiseishiName;
                    cmd.Parameters.Add("@ShinryouKaishiJikoku", SqlDbType.Real).Value = int.TryParse(rec.ShinryouKaishiJikoku.Replace(":", ""), out ri) ? (object)ri : DBNull.Value;
                    cmd.Parameters.Add("@ShinryouSyuuryouJikoku", SqlDbType.Real).Value = int.TryParse(rec.ShinryouSyuuryouJikoku.Replace(":", ""), out ri) ? (object)ri : DBNull.Value;
                    cmd.Parameters.Add("@ShinryouJikan", SqlDbType.Int).Value = rec.ShinryouJikan.HasValue ? (object)rec.ShinryouJikan.Value : DBNull.Value;
                    cmd.Parameters.Add("@ShidouShikaEiseishiName", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.ShidouShikaEiseishiName) ? DBNull.Value : (object)rec.ShidouShikaEiseishiName;
                    cmd.Parameters.Add("@ShidouKaishiJikoku", SqlDbType.Real).Value = int.TryParse(rec.ShidouKaishiJikoku.Replace(":", ""), out ri) ? (object)ri : DBNull.Value;
                    cmd.Parameters.Add("@ShidouSyuuryouJikoku", SqlDbType.Real).Value = int.TryParse(rec.ShidouSyuuryouJikoku.Replace(":", ""), out ri) ? (object)ri : DBNull.Value;
                    cmd.Parameters.Add("@ShidouJikan", SqlDbType.Int).Value = rec.ShidouJikan.HasValue ? (object)rec.ShidouJikan.Value : DBNull.Value;
                    cmd.Parameters.Add("@JissekiStatus", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.JissekiStatus) ? "" : rec.JissekiStatus;
                    cmd.Parameters.Add("@VisitName", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.VisitName) ? DBNull.Value : (object)rec.VisitName;
                    cmd.Parameters.Add("@UnitName", SqlDbType.VarChar).Value = string.IsNullOrEmpty(rec.UnitName) ? DBNull.Value : (object)rec.UnitName;
                    cmd.Parameters.Add("@KoSuu", SqlDbType.SmallInt).Value = rec.KoSuu.HasValue ? (object)rec.KoSuu.Value : DBNull.Value;
                    cmd.Parameters.Add("@RirekiBangou", SqlDbType.SmallInt).Value = rirekibangou;

                    cmd.ExecuteNonQuery();

                    iTourokuKensuu += 1;
                }
            }

            return iTourokuKensuu;
        }

		//2020.02.04 add
		public static int MergeIntoWithYouGeneralDisease(SqlConnection con, SqlTransaction tran, IEnumerable<CsvRecordGeneralDisease> lstCsvData)
		{
			const string SQL_TEMPLATE =
				"select * from ECDOC.dbo.[WithYou�A�g�f�[�^����] " +
				"where [patient_id] = @patient_id " +
				"and [measure_date] = @measure_date " +
				"and [seq_no] = @seq_no ";

			const string SQL_TEMPLATE_INS =
				"insert into ECDOC.dbo.[WithYou�A�g�f�[�^����] ( " +
				" [patient_id] " +
				",[measure_date] " +
				",[seq_no] " +
				",[mask] " +
				",[regist_user] " +
				",[regist_date] " +
				",[medical_history] " +
				",[disease_cd] " +
				",[disease_name] " +
				",[medical_facility] " +
				",[with_seqno] " +
				",[with_kiorekicd] " +
				",[with_keika] " +
				",[icd10] " +
				",[disease_name_kana] " +
				",[withyou_status] " +
				",[with_status] " +
				",[with_mod_usercd] " +
				",[with_mod_username] " +
				",[with_mod_date] " +
				") VALUES ( " +
				" @patient_id " +
				",@measure_date " +
				",@seq_no " +
				",@mask " +
				",@regist_user " +
				",@regist_date " +
				",@medical_history " +
				",@disease_cd " +
				",@disease_name " +
				",@medical_facility " +
				",@with_seqno " +
				",@with_kiorekicd " +
				",@with_keika " +
				",@icd10 " +
				",@disease_name_kana " +
				",@withyou_status " +
				",@with_status " +
				",@with_mod_usercd " +
				",@with_mod_username " +
				",@with_mod_date " +
				") ";

			const string SQL_TEMPLATE_UPD =
				"update ECDOC.dbo.[WithYou�A�g�f�[�^����] set " +
				"[mask] = @mask " +
				"where [patient_id] = @patient_id " +
				"and [measure_date] = @measure_date " +
				"and [seq_no] = @seq_no ";

			var stringOrDBNull = new Func<string, object>(value => string.IsNullOrEmpty(value) ? DBNull.Value : (object)value);
			var stringOrEmpty = new Func<string, string>(value => string.IsNullOrEmpty(value) ? string.Empty : value);
			var nullableDateTimeOrDBNull = new Func<DateTime?, object>(value => value.HasValue ? (object)value : DBNull.Value);
			var nullableShortOrDBNull = new Func<short?, object>(value => value.HasValue ? (object)value : DBNull.Value);
			var stringToNarrowOrDBNull = new Func<string, object>(value => string.IsNullOrEmpty(value) ? DBNull.Value : (object)Strings.StrConv(value, VbStrConv.Narrow));

			int iTourokuKensuu = 0;

			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				foreach (var rec in lstCsvData)
				{
					cmd.Parameters.Clear();
					cmd.Parameters.Add("@patient_id", SqlDbType.Int).Value = int.Parse(rec.patient_id);
					cmd.Parameters.Add("@measure_date", SqlDbType.DateTime).Value = rec.measure_date;
					cmd.Parameters.Add("@seq_no", SqlDbType.Int).Value = rec.seq_no;
					cmd.Parameters.Add("@mask", SqlDbType.SmallInt).Value = rec.mask.GetValueOrDefault();
					cmd.Parameters.Add("@regist_user", SqlDbType.VarChar).Value = stringOrDBNull(rec.regist_user);
					cmd.Parameters.Add("@regist_date", SqlDbType.DateTime).Value = nullableDateTimeOrDBNull(rec.regist_date);
					cmd.Parameters.Add("@medical_history", SqlDbType.VarChar).Value = stringOrDBNull(rec.medical_history);
					cmd.Parameters.Add("@disease_cd", SqlDbType.VarChar).Value = stringOrEmpty(rec.disease_cd);
					cmd.Parameters.Add("@disease_name", SqlDbType.VarChar).Value = stringOrDBNull(rec.disease_name);
					cmd.Parameters.Add("@medical_facility", SqlDbType.VarChar).Value = stringOrDBNull(rec.medical_facility);
					cmd.Parameters.Add("@with_seqno", SqlDbType.SmallInt).Value = nullableShortOrDBNull(rec.with_seqno);
					cmd.Parameters.Add("@with_kiorekicd", SqlDbType.SmallInt).Value = nullableShortOrDBNull(rec.with_kiorekicd);
					cmd.Parameters.Add("@with_keika", SqlDbType.SmallInt).Value = nullableShortOrDBNull(rec.with_keika);
					cmd.Parameters.Add("@icd10", SqlDbType.VarChar).Value = stringOrEmpty(rec.icd10);
					cmd.Parameters.Add("@disease_name_kana", SqlDbType.VarChar).Value = stringToNarrowOrDBNull(rec.disease_name_kana);
					cmd.Parameters.Add("@withyou_status", SqlDbType.SmallInt).Value = rec.withyou_status.GetValueOrDefault();
					cmd.Parameters.Add("@with_status", SqlDbType.SmallInt).Value = rec.with_status.GetValueOrDefault();
					cmd.Parameters.Add("@with_mod_usercd", SqlDbType.VarChar).Value = stringOrDBNull(rec.with_mod_usercd);
					cmd.Parameters.Add("@with_mod_username", SqlDbType.VarChar).Value = stringOrDBNull(rec.with_mod_username);
					cmd.Parameters.Add("@with_mod_date", SqlDbType.DateTime).Value = nullableDateTimeOrDBNull(rec.with_mod_date);

					//select
					bool hasRows;
					cmd.CommandText = SQL_TEMPLATE;
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						hasRows = dr.HasRows;
					}
					if (hasRows)
					{
						//update
						cmd.CommandText = SQL_TEMPLATE_UPD;
						cmd.ExecuteNonQuery();
					}
					else
					{
						//insert
						cmd.CommandText = SQL_TEMPLATE_INS;
						cmd.ExecuteNonQuery();
					}

					iTourokuKensuu += 1;
				}
			}

			return iTourokuKensuu;
		}

		//2020.02.04 add
		public static int MergeIntoWithYouTakingMedicines(SqlConnection con, SqlTransaction tran, IEnumerable<CsvRecordTakingMedicines> lstCsvData)
		{
			const string SQL_TEMPLATE =
				"select * from ECDOC.dbo.[WithYou�A�g�f�[�^���p�����] " +
				"where [patient_id] = @patient_id " +
				"and [measure_date] = @measure_date " +
				"and [seq_no] = @seq_no ";

			const string SQL_TEMPLATE_INS =
				"insert into ECDOC.dbo.[WithYou�A�g�f�[�^���p�����] ( " +
				" [patient_id] " +
				",[measure_date] " +
				",[seq_no] " +
				",[mask] " +
				",[regist_user] " +
				",[regist_date] " +
				",[medical_history] " +
				",[yakka_code] " +
				",[medicine_name] " +
				",[medical_facility] " +
				",[with_seqno] " +
				",[withyou_status] " +
				",[with_status] " +
				",[with_mod_usercd] " +
				",[with_mod_username] " +
				",[with_mod_date] " +
				") VALUES ( " +
				" @patient_id " +
				",@measure_date " +
				",@seq_no " +
				",@mask " +
				",@regist_user " +
				",@regist_date " +
				",@medical_history " +
				",@yakka_code " +
				",@medicine_name " +
				",@medical_facility " +
				",@with_seqno " +
				",@withyou_status " +
				",@with_status " +
				",@with_mod_usercd " +
				",@with_mod_username " +
				",@with_mod_date " +
				") ";

			const string SQL_TEMPLATE_UPD =
				"update ECDOC.dbo.[WithYou�A�g�f�[�^���p�����] set " +
				"[mask] = @mask " +
				"where [patient_id] = @patient_id " +
				"and [measure_date] = @measure_date " +
				"and [seq_no] = @seq_no ";

			var stringOrDBNull = new Func<string, object>(value => string.IsNullOrEmpty(value) ? DBNull.Value : (object)value);
			var nullableDateTimeOrDBNull = new Func<DateTime?, object>(value => value.HasValue ? (object)value : DBNull.Value);
			var nullableShortOrDBNull = new Func<short?, object>(value => value.HasValue ? (object)value : DBNull.Value);
			var stringToNarrowOrDBNull = new Func<string, object>(value => string.IsNullOrEmpty(value) ? DBNull.Value : (object)Strings.StrConv(value, VbStrConv.Narrow));

			int iTourokuKensuu = 0;

			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				foreach (var rec in lstCsvData)
				{
					cmd.Parameters.Clear();
					cmd.Parameters.Add("@patient_id", SqlDbType.Int).Value = int.Parse(rec.patient_id);
					cmd.Parameters.Add("@measure_date", SqlDbType.DateTime).Value = rec.measure_date;
					cmd.Parameters.Add("@seq_no", SqlDbType.Int).Value = rec.seq_no;
					cmd.Parameters.Add("@mask", SqlDbType.SmallInt).Value = rec.mask.GetValueOrDefault();
					cmd.Parameters.Add("@regist_user", SqlDbType.VarChar).Value = stringOrDBNull(rec.regist_user);
					cmd.Parameters.Add("@regist_date", SqlDbType.DateTime).Value = nullableDateTimeOrDBNull(rec.regist_date);
					cmd.Parameters.Add("@medical_history", SqlDbType.SmallInt).Value = nullableShortOrDBNull(rec.medical_history);
					cmd.Parameters.Add("@yakka_code", SqlDbType.VarChar).Value = rec.yakka_code;
					cmd.Parameters.Add("@medicine_name", SqlDbType.VarChar).Value = stringOrDBNull(rec.medicine_name);
					cmd.Parameters.Add("@medical_facility", SqlDbType.VarChar).Value = stringOrDBNull(rec.medical_facility);
					cmd.Parameters.Add("@with_seqno", SqlDbType.SmallInt).Value = nullableShortOrDBNull(rec.with_seqno);
					cmd.Parameters.Add("@withyou_status", SqlDbType.SmallInt).Value = rec.withyou_status.GetValueOrDefault();
					cmd.Parameters.Add("@with_status", SqlDbType.SmallInt).Value = rec.with_status.GetValueOrDefault();
					cmd.Parameters.Add("@with_mod_usercd", SqlDbType.VarChar).Value = stringOrDBNull(rec.with_mod_usercd);
					cmd.Parameters.Add("@with_mod_username", SqlDbType.VarChar).Value = stringOrDBNull(rec.with_mod_username);
					cmd.Parameters.Add("@with_mod_date", SqlDbType.DateTime).Value = nullableDateTimeOrDBNull(rec.with_mod_date);

					//select
					bool hasRows;
					cmd.CommandText = SQL_TEMPLATE;
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						hasRows = dr.HasRows;
					}
					if (hasRows)
					{
						//update
						cmd.CommandText = SQL_TEMPLATE_UPD;
						cmd.ExecuteNonQuery();
					}
					else
					{
						//insert
						cmd.CommandText = SQL_TEMPLATE_INS;
						cmd.ExecuteNonQuery();
					}

					iTourokuKensuu += 1;
				}
			}

			return iTourokuKensuu;
		}

		/*
		public static void InsertIntoEclog(Eclog objEclog)
		{
			try
			{
				const int LENGTH_LOG_NAIYOU = 500;
				const string SQL_TEMPLATE_1 =
					"INSERT INTO [ECLOG].[dbo].[���O�t�@�C��] " +
					"           ([���O���] " +
					"           ,[���t����] " +
					"           ,[�E��CD] " +
					"           ,[�E������] " +
					"           ,[TSE�ڑ�] " +
					"           ,[����PC��] " +
					"           ,[����PC��] " +
					"           ,[EXE��] " +
					"           ,[��ʖ�] " +
					"           ,[���Ҕԍ�] " +
					"           ,[���҃J�i����] " +
					"           ,[���Ҋ�������] " +
					"           ,[�t�@�C����] " +
					"           ,[���O���e]) " +
					"SELECT TOP 1  " +
					"      @LogSyubetsu AS [���O���] " +
					"      ,GETDATE() AS [���t����] " +
					"      ,S.[�E��CD] " +
					"      ,S.[�E������] " +
					"      ,@TseSetsuzoku AS [TSE�ڑ�] " +
					"      ,@DousaPcMei AS [����PC��] " +
					"      ,@SousaPcMei AS [����PC��] " +
					"      ,@ExeMei AS [EXE��] " +
					"      ,@GamenMei AS [��ʖ�] ";
				const string SQL_TEMPLATE_2_KANJABANGOU_ARI =
					"      ,K1.[���Ҕԍ�] " +
					"      ,K1.[�J�i����] " +
					"      ,K1.[��������] ";
				const string SQL_TEMPLATE_2_KANJABANGOU_NASHI =
					"      ,0 AS [���Ҕԍ�] " +
					"      ,'' AS [�J�i����] " +
					"      ,'' AS [��������] ";
				const string SQL_TEMPLATE_3 =
					"      ,@FileMei AS [�t�@�C����] " +
					"      ,@LogNaiyou AS [���O���e] " +
					"  FROM ECDB.dbo.�E���l AS S ";
				const string SQL_TEMPLATE_3_JOIN =
					"INNER JOIN ���Ҋ�{1 AS K1 ON K1.���Ҕԍ� = @KanjaBangou ";
				const string SQL_TEMPLATE_4 =
					"WHERE S.�E��CD = @SyokuinCode ";

				StringBuilder sbSQL = new StringBuilder();
				if (objEclog.KanjaBangou == 0)
				{
					//���Ҕԍ��Ȃ�
					sbSQL.Append(SQL_TEMPLATE_1);
					sbSQL.Append(SQL_TEMPLATE_2_KANJABANGOU_NASHI);
					sbSQL.Append(SQL_TEMPLATE_3);
					sbSQL.Append(SQL_TEMPLATE_4);
				}
				else
				{
					//���Ҕԍ�����
					sbSQL.Append(SQL_TEMPLATE_1);
					sbSQL.Append(SQL_TEMPLATE_2_KANJABANGOU_ARI);
					sbSQL.Append(SQL_TEMPLATE_3);
					sbSQL.Append(SQL_TEMPLATE_3_JOIN);
					sbSQL.Append(SQL_TEMPLATE_4);
				}

				using (SqlConnection con = GetConnectionWithOpen())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.CommandText = sbSQL.ToString();
						cmd.Parameters.Add("@LogSyubetsu", SqlDbType.SmallInt).Value = objEclog.LogSyubetsu;
						cmd.Parameters.Add("@TseSetsuzoku", SqlDbType.SmallInt).Value = objEclog.TseSetsuzoku;
						cmd.Parameters.Add("@DousaPcMei", SqlDbType.VarChar).Value = objEclog.DousaPcMei;
						cmd.Parameters.Add("@SousaPcMei", SqlDbType.VarChar).Value = objEclog.SousaPcMei;
						cmd.Parameters.Add("@ExeMei", SqlDbType.VarChar).Value = objEclog.ExeMei;
						cmd.Parameters.Add("@GamenMei", SqlDbType.VarChar).Value = Eclog.GamenMei;
						cmd.Parameters.Add("@FileMei", SqlDbType.VarChar).Value = Eclog.FileMei;
						cmd.Parameters.Add("@LogNaiyou", SqlDbType.VarChar).Value = Common.SubstringByte(objEclog.LogNaiyou, 0, LENGTH_LOG_NAIYOU);
						cmd.Parameters.Add("@KanjaBangou", SqlDbType.Int).Value = objEclog.KanjaBangou;
						cmd.Parameters.Add("@SyokuinCode", SqlDbType.VarChar).Value = objEclog.SyokuinCode;

						cmd.ExecuteNonQuery();
					}
				}

				return;
			}
			catch (Exception ex)
			{
				//dynamic objAppLogger = LoggerAppcation.GetInstance();
				//objAppLogger.WriteLog(ex.Message);

				//dynamic objErrLogger = LoggerError.GetInstance();
				//objErrLogger.WriteLog(ex);
				Form1.LoggingDisplay(ex.Message);

				return;
			}
		}
		*/

		public static List<string> GetKanjaJouhou(string strsakuseiDate)
		{

			const string SQL_TEMPLATE = "SELECT KIHON.*,HOUMON.�K���R�[�h AS �K���R�[�h2,HOUMON.�K�◝�R AS �K�◝�R" +
										" FROM" +
										" (SELECT R.���Ҕԍ� AS ���Ҕԍ�," +
										" R.�K���R�[�h AS �K���R�[�h," +
										" R.�K�◝�R AS �K�◝�R" +
										" FROM �K�◚�� AS R" +
										" LEFT JOIN �K���l AS M" +
										" ON R.�K���R�[�h = M.�K���R�[�h" +
										" WHERE R.�K����ԊJ�n�� <= @StartDate" +
										" AND R.�K����ԏI���� >= @EndDate" +
										" AND M.�K���敪 <> @Kubun) AS HOUMON" +
										" LEFT JOIN ���Ҋ�{1 AS KIHON" +
										" ON KIHON.���Ҕԍ� = HOUMON.���Ҕԍ�" +
										" WHERE KIHON.��Q�敪 in(4,5,6) AND ھ��ē]�A <> 2" +
										" ORDER BY KIHON.���Ҕԍ�";

			const string HEADDAR = "���Ҕԍ�,�J�i����,��������,����,���N����,�d�b�ԍ�(����),�d�b�ԍ�(�g��),�X�֔ԍ�,�Z���P,�Z���Q,���f��,�ŏI�f�Ó�,�K���R�[�h,�K�◝�R,���x";

			List<string> csvData = new List<string>();
			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;
						cmd.Parameters.Add("@StartDate", SqlDbType.VarChar).Value = strsakuseiDate;
						cmd.Parameters.Add("@EndDate", SqlDbType.VarChar).Value = strsakuseiDate;
						cmd.Parameters.Add("@Kubun", SqlDbType.Int).Value = 9;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								csvData.Add(HEADDAR);

								while (dr.Read())
								{
									line = "";
									string tel1 = "", tel2 = "";
									line += string.Format("\"{0}\",", GetDataValue(dr, "���Ҕԍ�", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�J�i����", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "��������", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "����", "0"));
									line += string.Format("\"{0}\",", GetDataValueDate(dr, "�a����", ""));
									GetKanjaKihon14(GetDataValue(dr, "���Ҕԍ�", "0"), ref tel1, ref tel2);
									line += string.Format("\"{0}\",", tel1);                                // �d�b�ԍ�(����)
									line += string.Format("\"{0}\",", tel2);                                // �d�b�ԍ�(�g��)
									line += string.Format("\"{0}\",", GetDataValue(dr, "�X�֔ԍ�", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�Z��1", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�Z��2", ""));
									line += string.Format("\"{0}\",", GetDataValueDate(dr, "���f��", ""));
									line += string.Format("\"{0}\",", GetDataValueDate(dr, "�ŏI�f�Ó�", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K���R�[�h2", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K�◝�R", ""));
									string kaigodo = GetKaigodo(GetDataValue(dr, "���Ҕԍ�", "0"), strsakuseiDate);
									line += string.Format("\"{0}\"", kaigodo);  // ���x

									csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}

				}
			}
			return csvData;
		}

		public static List<string> GetWinTekiyoM(string strsakuseiDate)
		{
			const string SQL_TEMPLATE = "SELECT* FROM ECDB{0}.dbo.�E�B���h�E�E�v����M WHERE �����N�R�[�h = 3 ORDER BY �����N�R�[�h,���ރR�[�h,���ԍ�";
			const string HEADDAR = "�����N�R�[�h,���ރR�[�h,���ԍ�,�}�X�N,����";

			List<string> csvData = new List<string>();
			string line = "";

			string yymm = GetYYMM(DateTime.ParseExact(strsakuseiDate, "yyyyMMdd", null));

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = string.Format(SQL_TEMPLATE, yymm);

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								csvData.Add(HEADDAR);
								while (dr.Read())
								{
									line = "";
									line += string.Format("\"{0}\",", GetDataValue(dr, "�����N�R�[�h", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "���ރR�[�h", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "���ԍ�", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�}�X�N", "0"));
									line += string.Format("\"{0}\"", GetDataValue(dr, "����", ""));
									csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}
				}
			}

			return csvData;
		}

		public static List<string> GetHoumonsakiM(string strsakuseiDate)
		{

			const string SQL_TEMPLATE = "SELECT * FROM �K���l ORDER BY �K���R�[�h";
			const string HEADDAR = "�K���R�[�h,�}�X�N,��ʕ\����,�K��於�̉�ʗp,�K��於�̃J���e�p,�K��於�̃��Z�v�g�p,�K���敪,�K���敪�ڍ�,���ʂ̊֌W";

			List<string> csvData = new List<string>();
			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								csvData.Add(HEADDAR);
								while (dr.Read())
								{
									line = "";
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K���R�[�h", "0"));
									line += string.Format("\"{0}\",", GetDataValueBool(dr, "�}�X�N", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "��ʕ\����", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K��於�̉�ʗp", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K��於�̃J���e�p", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K��於�̃��Z�v�g�p", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K���敪", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K���敪�ڍ�", "0"));
									line += string.Format("\"{0}\"", GetDataValue(dr, "���ʂ̊֌W", "0"));
									csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}
				}
			}

			return csvData;
		}

        public static List<string> GetHoumonRiyuM(string strsakuseiDate)
		{
			const string SQL_TEMPLATE = "SELECT * FROM �K�◝�R�l ORDER BY �K�◝�R�R�[�h";
			const string HEADDAR = "�K�◝�R�R�[�h,�}�X�N,��ʕ\����,�K�◝�R��ʗp,�K�◝�R�J���e�p,�K�◝�R���Z�v�g�p";

			List<string> csvData = new List<string>();
			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								csvData.Add(HEADDAR);

								while (dr.Read())
								{
									line = "";
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K�◝�R�R�[�h", "0"));
									line += string.Format("\"{0}\",", GetDataValueBool(dr, "�}�X�N", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "��ʕ\����", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K�◝�R��ʗp", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K�◝�R�J���e�p", ""));
									line += string.Format("\"{0}\"", GetDataValue(dr, "�K�◝�R���Z�v�g�p", ""));
									csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}
				}
			}
			return csvData;
		}

		public static List<string> GetByoinKasan(string strsakuseiDate)
		{

			const string SQL_TEMPLATE = "SELECT * FROM ��@�l�a�@���Z ORDER BY �J�n�N����";

			List<string> csvData = new List<string>();
			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								string headder = "";
								for (int i = 0; i < dr.FieldCount; i++)
								{
									if (i != 0) headder += ",";
									headder += dr.GetName(i);
								}
								csvData.Add(headder);

								while (dr.Read())
								{
									line = "";
									line += string.Format("\"{0}\",", GetDataValueDate(dr, "�J�n�N����", "0"));
									for (int i = 1; i < dr.FieldCount; i++)
									{
										if (i == dr.FieldCount - 1)
											line += string.Format("\"{0}\"", GetDataValue(dr, dr.GetName(i), "0"));
										else line += string.Format("\"{0}\",", GetDataValue(dr, dr.GetName(i), "0"));
									}
									csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}
				}
			}

			return csvData;
		}

		public static List<string> GetIinkoyu(string strsakuseiDate)
		{

			const string SQL_TEMPLATE = "SELECT ���R�[�h, ��Ë@�փR�[�h, �@����, ��@����, �X�֔ԍ�, �d�b�ԍ�, FAX�ԍ�, ��@�Z���P, ��@�Z���Q" +
										" FROM ��@�l��@�ŗL";

			const string SQL_TEMPLATE2 = "SELECT �X�֔ԍ� AS �K��X�֔ԍ�, �d�b�ԍ� AS �K��d�b�ԍ�, FAX�ԍ� AS �K��FAX�ԍ�, ��@�Z���P AS �K���@�Z���P, ��@�Z���Q AS �K���@�Z���Q, ���Ȑf�Ï��񋟏��g�p�L��, �Ǘ��w���v�揑�g�p�L��" +
										" FROM ��@M�K��f�Ðݒ�" +
										" ORDER BY �o�^�ԍ� DESC";

			const string HEADDAR = "���R�[�h,��Ë@�փR�[�h,�@����,��@����,�X�֔ԍ�,�d�b�ԍ�,FAX�ԍ�,��@�Z���P,��@�Z���Q,�K��X�֔ԍ�,�K��d�b�ԍ�,�K��FAX�ԍ�,�K���@�Z���P,�K���@�Z���Q,���Ȑf�Ï��񋟏��g�p�L��,�Ǘ��w���v�揑�g�p�L��";

			List<string> csvData = new List<string>();
			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						csvData.Add(HEADDAR);

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								line += string.Format("\"{0}\",", GetDataValue(dr, "���R�[�h", "0"));
								line += string.Format("\"{0}\",", GetDataValue(dr, "��Ë@�փR�[�h", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "�@����", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "��@����", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "�X�֔ԍ�", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "�d�b�ԍ�", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "FAX�ԍ�", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "��@�Z���P", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "��@�Z���Q", ""));
							}
							else
							{
								// ��@M��@�ŗL�̃��R�[�h�����݂��Ȃ��ꍇ(�O�̂���)
								for (int i = 0; i <= 8; i++) line += string.Format("\"\",");
							}
						}
					}

					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE2;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								line += string.Format("\"{0}\",", GetDataValue(dr, "�K��X�֔ԍ�", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "�K��d�b�ԍ�", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "�K��FAX�ԍ�", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "�K���@�Z���P", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "�K���@�Z���Q", ""));
								line += string.Format("\"{0}\",", GetDataValue(dr, "���Ȑf�Ï��񋟏��g�p�L��", "0"));
								line += string.Format("\"{0}\"", GetDataValue(dr, "�Ǘ��w���v�揑�g�p�L��", "0"));
							}
							else
							{
								// ���R�[�h�����݂��Ȃ��ꍇ�A��@M��@�ŗL�ɐݒ肪����΁A��@M�K��f�Ðݒ�̃��R�[�h�ɋ󔒂�ݒ肷��
								for (int i = 0; i <= 6; i++)
								{
									if (i == 6) line += string.Format("\"\"");
									line += string.Format("\"\",");
								}
							}
							csvData.Add(line);
							csvData.Add("END\r\n");
						}
					}
				}
			}

			return csvData;
		}

		public static List<string> GetIinMDoctorInfo(string strsakuseiDate)
		{

			const string SQL_TEMPLATE = "SELECT * FROM ��@M�h�N�^�[���  ORDER BY �h�N�^�[�R�[�h";
			const string HEADDAR = "�h�N�^�[�R�[�h, �S�����ʗp, �S���セ�̑�, ��ʕ\������, �}�X�N, ���W���a���Œ�L��, �f�Ñ�ԍ�, �\��䒠�ԍ�, ��܈ꗗ�\����, �ی��I����ʕ\���L��, �E��CD, SOAP���Ꮙ���\��";

			List<string> csvData = new List<string>();
			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								csvData.Add(HEADDAR);

								while (dr.Read())
								{
									line = "";
									line += string.Format("\"{0}\",", GetDataValue(dr, "�h�N�^�[�R�[�h", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�S�����ʗp", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�S���セ�̑�", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "��ʕ\������", "0"));
									line += string.Format("\"{0}\",", GetDataValueBool(dr, "�}�X�N", "0"));
									line += string.Format("\"{0}\",", GetDataValueBool(dr, "���W���a���Œ�L��", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�f�Ñ�ԍ�", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�\��䒠�ԍ�", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "��܈ꗗ�\����", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�ی��I����ʕ\���L��", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�E��CD", ""));
									line += string.Format("\"{0}\"", GetDataValue(dr, "SOAP���Ꮙ���\��", "0"));
									csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}
				}
			}

			return csvData;
		}

		public static List<string> GetKanjaJouhouRecord(string strsakuseiDate, out IEnumerable<string> patientIds)
		{
            patientIds = null;

			const string SQL_TEMPLATE1 = "SELECT patient_id, delete_flg, no FROM ECDOC.dbo.WithYou_data_set_patient WHERE status = '0' order by set_time";

            
            //2018.04�D12 changed 
            const string SQL_TEMPLATE2 = "SELECT KIHON.*,HOUMON.�K���R�[�h AS �K���R�[�h2,HOUMON.���j�b�g�a���R�[�h AS ���j�b�g�a���R�[�h,HOUMON.�K�◝�R AS �K�◝�R, CHANGE.org_patient_id AS �����Ҕԍ�" +
										" FROM" +
										" (SELECT R.���Ҕԍ� AS ���Ҕԍ�," +
										" R.�K���R�[�h AS �K���R�[�h," +
                                        " R.���j�b�g�a���R�[�h AS ���j�b�g�a���R�[�h," +
                                        " R.�K�◝�R AS �K�◝�R" +
										" FROM �K�◚�� AS R" +
										" LEFT JOIN �K���l AS M" +
										" ON R.�K���R�[�h = M.�K���R�[�h" +
										" WHERE R.�K����ԊJ�n�� <= @StartDate" +
										" AND R.�K����ԏI���� >= @EndDate" +
										" AND M.�K���敪 <> @Kubun) AS HOUMON" +
										" LEFT JOIN ���Ҋ�{1 AS KIHON" +
										" ON KIHON.���Ҕԍ� = HOUMON.���Ҕԍ�" +
										" LEFT JOIN (select * from ECDOC.dbo.WithYou_data_set_patient where status=0 and no ={1}) AS CHANGE" +
										//" LEFT JOIN ECDOC.dbo.WithYou_data_set_patient AS CHANGE" +
										" ON KIHON.���Ҕԍ� = CHANGE.patient_id" +
										" WHERE KIHON.��Q�敪 in(4,5,6) " + //AND ھ��ē]�A <> 2" +
										" AND KIHON.���Ҕԍ� = '{0}'";

			const string HEADDAR = "���Ҕԍ�,�J�i����,��������,����,���N����,�d�b�ԍ�(����),�d�b�ԍ�(�g��),�X�֔ԍ�,�Z���P,�Z���Q,���f��,�ŏI�f�Ó�,�K���R�[�h,�K�◝�R,���x,���j�b�g�a���R�[�h,�]�A,�����Ҕԍ�,�폜�t���O";

			List<string> csvData = new List<string>();
			string deleteFlags = "";
			string numbers = "";
            //2018.06.27 add
            string optionFlg = GetOptionFlg(strsakuseiDate,59);

            m_changeIDs_patient = GetChangeRecordsPatient(SQL_TEMPLATE1, ref deleteFlags, ref numbers);
			string[] patientId = m_changeIDs_patient.Split(',');
			string[] deleteFlag = deleteFlags.Split(',');
			string[] number = numbers.Split(',');

			if (m_changeIDs_patient.Length == 0) return csvData;

			var rtnPatientIds = new List<string>();

			csvData.Add(HEADDAR);

			for (int i = 0; i < patientId.Length; i++)
			{
				//Form1.LoggingDisplay("[GetKanjaJouhouRecord] patientId: {0}", patientId[i]);
				//Form1.LoggingDisplay("[GetKanjaJouhouRecord] no: {0}", number[i]);
				//Form1.LoggingDisplay("[GetKanjaJouhouRecord] strsakuseiDate: {0}", strsakuseiDate);
				//Form1.LoggingDisplay("[GetKanjaJouhouRecord] Kubun: 9");
				// �폜���͊���ID�ƍ폜�t���O�݂̂�ݒ�
				string line = "";
				if (deleteFlag[i] == "1")
				{
					line = "";
					line += string.Format("\"{0}\",", patientId[i]);
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
                    //2018.04.12 added
                    line += string.Format("\"{0}\",", "");
					line += string.Format("\"{0}\",", "");
                    line += string.Format("\"{0}\",", "");
                    line += string.Format("\"{0}\"", "1");

					csvData.Add(line);
					rtnPatientIds.Add(patientId[i]);
					continue;
				}

				using (SqlConnection con = DBAccess.GetConnectionWithOpen())
				{
					//�g�����U�N�V�����J�n
					using (SqlTransaction tran = con.BeginTransaction())
					{
						using (SqlCommand cmd = new SqlCommand())
						{
							cmd.Connection = con;
							cmd.Transaction = tran;
							//cmd.CommandText = string.Format(SQL_TEMPLATE2, m_changeIDs_patient);
							cmd.CommandText = string.Format(SQL_TEMPLATE2, patientId[i], number[i]);

							Form1.LogDBG("sql[{0}], startdate[{1}]", cmd.CommandText, strsakuseiDate);

							cmd.Parameters.Add("@StartDate", SqlDbType.VarChar).Value = strsakuseiDate;
							cmd.Parameters.Add("@EndDate", SqlDbType.VarChar).Value = strsakuseiDate;
							cmd.Parameters.Add("@Kubun", SqlDbType.Int).Value = 9;

							using (SqlDataReader dr = cmd.ExecuteReader())
							{
								if (dr.HasRows)
								{
									//csvData.Add(HEADDAR);

									while (dr.Read())
									{
										line = "";
										string tel1 = "", tel2 = "";
										string patId = GetDataValue(dr, "���Ҕԍ�", "0");
										line += string.Format("\"{0}\",", patId);
										line += string.Format("\"{0}\",", GetDataValue(dr, "�J�i����", ""));
										line += string.Format("\"{0}\",", GetDataValue(dr, "��������", ""));
										line += string.Format("\"{0}\",", GetDataValue(dr, "����", "0"));
										line += string.Format("\"{0}\",", GetDataValueDate(dr, "�a����", ""));
										GetKanjaKihon14(GetDataValue(dr, "���Ҕԍ�", "0"), ref tel1, ref tel2);
										line += string.Format("\"{0}\",", tel1);                                // �d�b�ԍ�(����)
										line += string.Format("\"{0}\",", tel2);                                // �d�b�ԍ�(�g��)
										line += string.Format("\"{0}\",", GetDataValue(dr, "�X�֔ԍ�", ""));
										line += string.Format("\"{0}\",", GetDataValue(dr, "�Z��1", ""));
										line += string.Format("\"{0}\",", GetDataValue(dr, "�Z��2", ""));
										line += string.Format("\"{0}\",", GetDataValueDate(dr, "���f��", ""));
										line += string.Format("\"{0}\",", GetDataValueDate(dr, "�ŏI�f�Ó�", ""));
										line += string.Format("\"{0}\",", GetDataValue(dr, "�K���R�[�h2", "0"));
                                        line += string.Format("\"{0}\",", GetDataValue(dr, "�K�◝�R", ""));
                                        //2018.06.27 add �I�v�V�����t���O(60�Ԗ�)�ŉ��A�g����̏ꍇ�̂݉��x�𑗐M
                                        if (optionFlg == "1")
                                        {
                                            string kaigodo = GetKaigodo(GetDataValue(dr, "���Ҕԍ�", "0"), strsakuseiDate);
                                            //line += string.Format("\"{0}\"", kaigodo);  // ���x
                                            line += string.Format("\"{0}\",", kaigodo);
                                        }else line += string.Format("\"{0}\",", "");
                                        //2018.04.12 added
                                        line += string.Format("\"{0}\",", GetDataValue(dr, "���j�b�g�a���R�[�h", ""));
                                        line += string.Format("\"{0}\",", GetDataValue(dr, "ھ��ē]�A", "0"));
										string orgPatId = GetDataValue(dr, "�����Ҕԍ�", "");

										if (orgPatId.Length == 0) line += string.Format("\"{0}\",", patId);
										else line += string.Format("\"{0}\",", orgPatId);

										line += string.Format("\"{0}\"", "0");  // �폜�t���O=0

										//if (deleteFlag.Length < index)
										//	line += string.Format("\"{0}\"", deleteFlag[i]);
										//else line += string.Format("\"{0}\"", "0");

										csvData.Add(line);
									}

									rtnPatientIds.Add(patientId[i]);
								}
								else
								{
									NoSetPatientData(patientId[i]);
								}
							}
						}
					}
				}
			}
			csvData.Add("END\r\n");

			patientIds = rtnPatientIds.OrderBy(k => k).Distinct().ToArray();

			return csvData;
		}

		public static List<string> GetHoumonRiyuMRecord(string strsakuseiDates)
		{
			const string SQL_TEMPLATE1 = "SELECT reason_id FROM ECDOC.dbo.WithYou_data_set_reason WHERE status='0'";
			const string SQL_TEMPLATE2 = "SELECT * FROM �K�◝�R�l ORDER BY �K�◝�R�R�[�h";
			//const string SQL_TEMPLATE2 = "SELECT * FROM �K�◝�R�l WHERE �K�◝�R�R�[�h in({0})";
			const string HEADDAR = "�K�◝�R�R�[�h,�}�X�N,��ʕ\����,�K�◝�R��ʗp,�K�◝�R�J���e�p,�K�◝�R���Z�v�g�p";
			List<string> csvData = new List<string>();

			m_changeIDs_reason = GetChangeRecords(SQL_TEMPLATE1);
			if (m_changeIDs_reason.Length == 0) return csvData;

			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE2;
						//cmd.CommandText = string.Format(SQL_TEMPLATE2, m_changeIDs_reason);

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								csvData.Add(HEADDAR);

								while (dr.Read())
								{
									line = "";
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K�◝�R�R�[�h", "0"));
									line += string.Format("\"{0}\",", GetDataValueBool(dr, "�}�X�N", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "��ʕ\����", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K�◝�R��ʗp", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K�◝�R�J���e�p", ""));
									line += string.Format("\"{0}\"", GetDataValue(dr, "�K�◝�R���Z�v�g�p", ""));
									csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}
				}
			}

			return csvData;
		}

		public static List<string> GetHoumonsakiMRecord(string strsakuseiDate)
		{
			const string SQL_TEMPLATE1 = "SELECT visit_id FROM ECDOC.dbo.WithYou_data_set_visit WHERE status='0'";
			const string SQL_TEMPLATE2 = "SELECT * FROM �K���l ORDER BY �K���R�[�h";
			//const string SQL_TEMPLATE2 = "SELECT * FROM �K���l WHERE �K���R�[�h in ({0})";
			const string HEADDAR = "�K���R�[�h,�}�X�N,��ʕ\����,�K��於�̉�ʗp,�K��於�̃J���e�p,�K��於�̃��Z�v�g�p,�K���敪,�K���敪�ڍ�,���ʂ̊֌W,�ː�";

			List<string> csvData = new List<string>();

			//string codes = GetChangeRecords(SQL_TEMPLATE1);
			m_changeIDs_visit = GetChangeRecords(SQL_TEMPLATE1);

			if (m_changeIDs_visit.Length == 0) return csvData;

			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE2;
						//cmd.CommandText = string.Format(SQL_TEMPLATE2, m_changeIDs_visit);

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								csvData.Add(HEADDAR);
								while (dr.Read())
								{
									line = "";
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K���R�[�h", "0"));
									line += string.Format("\"{0}\",", GetDataValueBool(dr, "�}�X�N", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "��ʕ\����", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K��於�̉�ʗp", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K��於�̃J���e�p", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K��於�̃��Z�v�g�p", ""));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K���敪", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "�K���敪�ڍ�", "0"));
									line += string.Format("\"{0}\",", GetDataValue(dr, "���ʂ̊֌W", "0"));
                                    line += string.Format("\"{0}\"", GetDataValue(dr, "�ː�", ""));
                                    csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}
				}
			}

			return csvData;
		}

        public static List<string> GetHoumonsakiUnitMRecord(string strsakuseiDate)
        {
            //2018.04.23 �g���K�[�ł͂��ׂẴf�[�^�𑗂邽��visit_id,unit_id�͂��ׂ�0������̂�
            //visit_id�͖�������unit_id�����ŊǗ�����B
            const string SQL_TEMPLATE1 = "SELECT unit_id FROM ECDOC.dbo.WithYou_data_set_visit_unit WHERE status='0'";
            const string SQL_TEMPLATE2 = "SELECT * FROM �K��惆�j�b�g�a��M ORDER BY �K���R�[�h,���j�b�g�a���R�[�h";
            const string HEADDAR = "�K���R�[�h,���j�b�g�a���R�[�h,�}�X�N,��ʕ\����,���j�b�g�a����";

            List<string> csvData = new List<string>();

            //string codes = GetChangeRecords(SQL_TEMPLATE1);
            m_changeIDs_visit_unit = GetChangeRecords(SQL_TEMPLATE1);
            if (m_changeIDs_visit_unit.Length == 0) return csvData;

            string line = "";

            using (SqlConnection con = DBAccess.GetConnectionWithOpen())
            {
                //�g�����U�N�V�����J�n
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.Transaction = tran;
                        cmd.CommandText = SQL_TEMPLATE2;
                        //cmd.CommandText = string.Format(SQL_TEMPLATE2, m_changeIDs_visit);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                csvData.Add(HEADDAR);
                                while (dr.Read())
                                {
                                    line = "";
                                    line += string.Format("\"{0}\",", GetDataValue(dr, "�K���R�[�h", "0"));
                                    line += string.Format("\"{0}\",", GetDataValue(dr, "���j�b�g�a���R�[�h", "0"));
                                    line += string.Format("\"{0}\",", GetDataValueBool(dr, "�}�X�N", "0"));
                                    line += string.Format("\"{0}\",", GetDataValue(dr, "��ʕ\����", "0"));
                                    line += string.Format("\"{0}\"", GetDataValue(dr, "���j�b�g�a����", ""));
                                    csvData.Add(line);
                                }
                            }
                            csvData.Add("END\r\n");
                        }
                    }
                }
            }

            return csvData;
        }

        public static List<string> GetByoinKasanRecord(string strsakuseiDate)
		{
			const string SQL_TEMPLATE1 = "SELECT no FROM ECDOC.dbo.WithYou_data_set_kasan WHERE status='0'";
			const string SQL_TEMPLATE2 = "SELECT * FROM ��@�l�a�@���Z ORDER BY �J�n�N����";

			List<string> csvData = new List<string>();

			m_changeIDs_kasan = GetChangeRecords(SQL_TEMPLATE1);
			if (m_changeIDs_kasan.Length == 0) return csvData;

			string line = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE2;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								string headder = "";
								for (int i = 0; i < dr.FieldCount; i++)
								{
									if (i != 0) headder += ",";
									headder += dr.GetName(i);
								}
								csvData.Add(headder);

								while (dr.Read())
								{
									line = "";
									line += string.Format("\"{0}\",", GetDataValueDate(dr, "�J�n�N����", "0"));
									for (int i = 1; i < dr.FieldCount; i++)
									{
										if (i == dr.FieldCount - 1)
											line += string.Format("\"{0}\"", GetDataValue(dr, dr.GetName(i), "0"));
										else line += string.Format("\"{0}\",", GetDataValue(dr, dr.GetName(i), "0"));
									}
									csvData.Add(line);
								}
							}
							csvData.Add("END\r\n");
						}
					}
				}
			}

			return csvData;
		}

		public static DateTime GetCreateDate()
		{

			const string SQL_TEMPLATE = "SELECT GETDATE() as �T�[�o���t";

			DateTime date = new DateTime();

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								date = dr.GetDateTime(0);
							}
						}
					}
				}
			}

			return date;
		}

		public static string GetOutputPath(ref bool err)
		{
			const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'ZOKUSEI' AND NAME = 'PATH'";

			string path = "";
			err = false;

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								path = GetDataValue(dr, dr.GetName(0), "");
							}
							else err = true;
						}
					}
				}
			}

			return path;
		}

		// 2017.12.30 add
		public static int GetStorageDays(ref bool err)
		{
			const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'WITHYOUGW' AND NAME = 'LOG_STORAGE'";

			int days = 0;
			err = false;

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								days = util.ToInt(GetDataValue(dr, dr.GetName(0), ""));
							}
							else err = true;
						}
					}
				}
			}

			if(days == 0) days = Global.INI_LOG_STORAGE_DAYS;

			return days;
		}

		// 2017.12.30 add
		public static int GetKrtInterval(ref bool err)
		{
			const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'WITHYOUGW' AND NAME = 'KRT_INTERVAL'";

			int interval = 0;
			err = false;

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								interval = util.ToInt(GetDataValue(dr, dr.GetName(0), ""));
							}
							else err = true;
						}
					}
				}
			}

			if (interval == 0) interval = Global.INI_KRT_INTERVAL;

			return interval;
		}

		// 2017.12.30 add
		public static int GetServerInterval(ref bool err)
		{
			const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'WITHYOUGW' AND NAME = 'SV_INTERVAL'";

			int interval = 0;
			err = false;

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								interval = util.ToInt(GetDataValue(dr, dr.GetName(0), ""));
							}
							else err = true;
						}
					}
				}
			}

			if (interval == 0) interval = Global.INI_GWSV_INTERVAL;

			return interval;
		}

		// 2018.03.01 add
		public static int GetReConnect(ref bool err)
		{
			const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'WITHYOUGW' AND NAME = 'RE_CONNECT'";

			int reconnect = 0;
			err = false;

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								reconnect = util.ToInt(GetDataValue(dr, dr.GetName(0), ""));
							}
							else err = true;
						}
					}
				}
			}

			if (reconnect == 0) reconnect = Global.INI_RECONNECT;

			return reconnect;
		}

        // 2018.04.16 add
        public static int GetReTryCnt(ref bool err)
        {
            const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'WITHYOUGW' AND NAME = 'RETRY_CNT'";

            int retry_cnt = 0;
            err = false;

            using (SqlConnection con = DBAccess.GetConnectionWithOpen())
            {
                //�g�����U�N�V�����J�n
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.Transaction = tran;
                        cmd.CommandText = SQL_TEMPLATE;

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                dr.Read();
                                retry_cnt = util.ToInt(GetDataValue(dr, dr.GetName(0), ""));
                            }
                            else err = true;
                        }
                    }
                }
            }

            if (retry_cnt == 0) retry_cnt = Global.INI_RETRY_CNT;

            return retry_cnt;
        }

        public static string GetWithProxyServer(ref bool err)
		{
			const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'WITHYOUGW' AND NAME = 'WITH_PROXY'";

			string proxy = "";
			err = false;

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								proxy = GetDataValue(dr, dr.GetName(0), "");
							}
							else err = true;
						}
					}
				}
			}

			return proxy;
		}

		public static string GetEpochProxyServer(ref bool err)
		{
			const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'WITHYOUGW' AND NAME = 'EPOCH_PROXY'";

			string proxy = "";
			err = false;

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								proxy = GetDataValue(dr, dr.GetName(0), "");
							}
							else err = true;
						}
					}
				}
			}

			return proxy;
		}

        public static bool GetDoingInitDM(/*ref bool err*/)
        {
            const string SQL_TEMPLATE = "SELECT VALUE, NAME FROM ECDOC.dbo.WithYou�A�g���ݒ� WHERE SECTION = 'WITHYOUGW' AND NAME = 'INIT_DM'";

            var rtn = true;
            //err = false;

            using (SqlConnection con = DBAccess.GetConnectionWithOpen())
            {
                //�g�����U�N�V�����J�n
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.Transaction = tran;
                        cmd.CommandText = SQL_TEMPLATE;

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                dr.Read();
                                var value = GetDataValue(dr, dr.GetName(0), "");
                                rtn = value != "��";
                            }
                            //else err = true;
                        }
                    }
                }
            }

            return rtn;
        }

		public static bool UpdateDoneInitDM()
		{
			try
			{
				const string SQL_TEMPLATE = "SELECT * FROM ECDOC.dbo.[WithYou�A�g���ݒ�] " +
					"WHERE SECTION = @SECTION " +
					"AND NAME = @NAME ";

				const string SQL_TEMPLATE_INS = "INSERT INTO ECDOC.dbo.[WithYou�A�g���ݒ�] ( " +
					"SECTION " +
					",NAME " +
					",VALUE " +
					") " +
					"VALUES ( " +
					"@SECTION " +
					",@NAME " +
					",@VALUE " +
					") ";

				const string SQL_TEMPLATE_UPD = "UPDATE ECDOC.dbo.[WithYou�A�g���ݒ�] SET " +
					"VALUE = @VALUE " +
					"WHERE SECTION = @SECTION " +
					"AND NAME = @NAME ";

				using (SqlConnection con = GetConnectionWithOpen())
				using (SqlTransaction tran = con.BeginTransaction())
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.Transaction = tran;
					cmd.Parameters.Add("@SECTION", SqlDbType.VarChar).Value = "WITHYOUGW";
					cmd.Parameters.Add("@NAME", SqlDbType.VarChar).Value = "INIT_DM";
					cmd.Parameters.Add("@VALUE", SqlDbType.VarChar).Value = "��";

					//select
					bool hasRows;
					cmd.CommandText = SQL_TEMPLATE;
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						hasRows = dr.HasRows;
					}
					if (hasRows)
					{
						//update
						cmd.CommandText = SQL_TEMPLATE_UPD;
						cmd.ExecuteNonQuery();
					}
					else
					{
						//insert
						cmd.CommandText = SQL_TEMPLATE_INS;
						cmd.ExecuteNonQuery();
					}

					tran.Commit();
				}

				return true;
			}
			catch (Exception ex)
			{
				//dynamic objAppLogger = LoggerAppcation.GetInstance();
				//objAppLogger.WriteLog(ex.Message);

				//dynamic objErrLogger = LoggerError.GetInstance();
				//objErrLogger.WriteLog(ex);
				Form1.LoggingDisplay(ex.Message);

				//Windows�̃G���[���b�Z�[�W��ECLOG�ɏ�������
				//Eclog.WriteLog(Eclog.LogSyubetsuType.ErrorLog, ex.Message, teikyouBunsyo.KanjaBangou);

				return false;
			}
		}

		private static bool GetKanjaKihon14(string kanjabango, ref string tel1, ref string tel2)
		{

			const string SQL_TEMPLATE = "SELECT * FROM ���Ҋ�{14" +
										" WHERE ���Ҕԍ� = @kanjabango" +
										" AND ��ʃt���O IN(1,2)" +
										" ORDER BY id DESC";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					try
					{
						using (SqlCommand cmd = new SqlCommand())
						{
							cmd.Connection = con;
							cmd.Transaction = tran;
							cmd.CommandText = SQL_TEMPLATE;
							cmd.Parameters.Add("@kanjabango", SqlDbType.VarChar).Value = kanjabango;

							using (SqlDataReader dr = cmd.ExecuteReader())
							{
								while (dr.Read())
								{
									switch (Convert.ToInt32(GetDataValue(dr, "��ʃt���O", "0")))
									{
										case 1:
											if (tel1.Length == 0)
												tel1 = GetDataValue(dr, "�d�b�ԍ��\���p", "");
											break;
										case 2:
											if (tel2.Length == 0)
												tel2 = GetDataValue(dr, "�d�b�ԍ��\���p", "");
											break;
									}
									if (tel1.Length != 0 && tel2.Length != 0)
										break;
								}
							}
						}
					}
					catch (Exception ex)
					{
						string a = ex.ToString();
					}
				}
			}

			return true;
		}

		private static string GetKaigodo(string kanjabango, string date)
		{
			string ret = "";

			const string SQL_TEMPLATE = "SELECT ���x" +
										" FROM {0}" +
										" WHERE ���p�Ҕԍ� = @kanjabango" +
										"  AND �F��J�n�� <= @startdate" +
										" AND �F��I���� >= @enddate";

			string dbname = DB_GetFQN("kg����ی��f�[�^", "KGDB200");
			string sql = string.Format(SQL_TEMPLATE, dbname, kanjabango, date, date);

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					try
					{
						using (SqlCommand cmd = new SqlCommand())
						{
							cmd.Connection = con;
							cmd.Transaction = tran;
							cmd.CommandText = sql;

							cmd.Parameters.Add("@kanjabango", SqlDbType.VarChar).Value = kanjabango;
							cmd.Parameters.Add("@startdate", SqlDbType.VarChar).Value = date;
							cmd.Parameters.Add("@enddate", SqlDbType.VarChar).Value = date;

							using (SqlDataReader dr = cmd.ExecuteReader())
							{
								if (dr.HasRows)
								{
									dr.Read();
									ret = GetDataValue(dr, "���x", "");
								}
								else
								{
									ret = "";
								}
							}
						}
					}
					catch (Exception ex)
					{
						string a = ex.ToString();
					}
				}
			}

			return ret;
		}

        //2018.06.27 add 
        private static string GetOptionFlg(string sDate,int num)
        {
            string ret = "";
            string optionFlg = "";

            const string SQL_TEMPLATE = "SELECT A.�@�\����t���O FROM {0} A" +
                                        " INNER JOIN (SELECT MAX(���ԍ�) AS ���ԍ� FROM {1}" +
                                        " WHERE �J�n�� <= @startdate) B" +
                                        " ON A.���ԍ� = B.���ԍ�";
            string dbname = DB_GetFQN("��@�l�I�v�V����", "ECDB");
            string sql = string.Format(SQL_TEMPLATE, dbname, dbname);

            using (SqlConnection con = DBAccess.GetConnectionWithOpen())
            {
                //�g�����U�N�V�����J�n
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            cmd.Connection = con;
                            cmd.Transaction = tran;
                            cmd.CommandText = sql;

                            cmd.Parameters.Add("@startdate", SqlDbType.VarChar).Value = sDate;

                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                if (dr.HasRows)
                                {
                                    dr.Read();
                                    optionFlg = GetDataValue(dr, "�@�\����t���O", "");
                                    if (optionFlg.Length > num)
                                    {
                                        ret = optionFlg.Substring(num, 1);
                                    }
                                }
                                else
                                {
                                    ret = "";
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        string a = ex.ToString();
                    }
                }
            }

            return ret;
        }

        public static string DB_GetFQN(string table_name, string db_name)
		{
			string functionReturnValue = null;
			functionReturnValue = "[" + DB_GetDbAddName(db_name) + db_name + "].[DBO].[" + table_name + "]";
			return functionReturnValue;
		}

		private static string DB_GetDbAddName(string target_db)
		{
			string functionReturnValue = null;
			string str_tmp = null;
			str_tmp = Strings.StrConv(Strings.Trim(target_db), Constants.vbLowerCase);
			if (str_tmp.Length != 0)
			{
				switch (str_tmp)
				{
					//DB�t�����̂��s�v��DB�͏��O
					case "ecid":
						break;
					case "master":
						break;
					case "model":
						break;
					case "pubs":
						break;
					case "northwind":
						break;
					case "tempdb":
						break;
					default:
						//DB�t�����̕K�v 
						//functionReturnValue = DB_ADD_NAME;	// DB�t�����̕s�v ikeda 2016.06.09 DEL
						functionReturnValue = "";
						break;
				}
			}
			return functionReturnValue;
		}

		private static string GetDataValue(SqlDataReader dr, string ordinal, string defaultSet)
		{
			string ret = "";
			ret = dr.GetValue(dr.GetOrdinal(ordinal)).ToString();
			if (ret.Length == 0) ret = defaultSet;

			return ret;
		}

		private static string GetDataValueBool(SqlDataReader dr, string ordinal, string defaultSet)
		{
			string ret = "";
			bool ret2 = (bool)dr.GetValue(dr.GetOrdinal(ordinal));
			ret = util.CastInt(ret2).ToString();
			if (ret.Length == 0) ret = defaultSet;

			return ret;
		}

		private static string GetDataValueDate(SqlDataReader dr, string ordinal, string defaultSet)
		{
			string ret = "";
			//DateTime date = (DateTime)dr.GetValue(dr.GetOrdinal(ordinal));
            var value = dr.GetValue(dr.GetOrdinal(ordinal));
            if (value == null || value == DBNull.Value)
            {
                return defaultSet;
            }
            var date = (DateTime)value;
			ret = date.ToString("yyyyMMdd");
			// "18991230"��"00000000"�ɕύX
			if ("18991230" == ret) ret = "00000000";

			return ret;
		}

        private static string GetDataValueDateTime(SqlDataReader dr, string ordinal, string defaultSet)
        {
            string ret = "";
            var value = dr.GetValue(dr.GetOrdinal(ordinal));
            if (value == null || value == DBNull.Value)
            {
                return defaultSet;
            }
            var date = (DateTime)value;
            var dt = date.ToString("yyyyMMdd");
            var tm = date.ToString("HH:mm:ss");
            // "18991230"��"00000000"�ɕύX
            if ("18991230" == dt) dt = "00000000";
            ret = $"{dt} {tm}";

            return ret;
        }

		public static string GetChangeRecords(string sql)
		{
			string changeRecords = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.CommandText = sql;

					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						while (dr.Read())
						{
							if (changeRecords.Length == 0)
							{
								if (dr.GetValue(0).ToString().Length != 0)
								{
									changeRecords += dr.GetValue(0).ToString();
								}
							}
							else
							{
								if (dr.GetValue(0).ToString().Length != 0)
								{
									changeRecords += ',';
									changeRecords += dr.GetValue(0).ToString();
								}
							}
						}
					}
				}

			}
			return changeRecords;
		}

		//
		public static string GetHospID()
		{
			
			const string SQL_TEMPLATE = "SELECT ���[�UID FROM ECDB.dbo.��@M��@�ŗL";

			string userID = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = SQL_TEMPLATE;

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								dr.Read();
								userID = GetDataValue(dr, dr.GetName(0), "");
							}
						}
					}
				}
			}

			return userID;
		}

        public static string GetChangeRecordsPatient(string sql, ref string deleteFlg, ref string numbers)
		{
			string changeRecords = "";

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.CommandText = sql;

					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						while (dr.Read())
						{
							if (changeRecords.Length == 0)
							{
								if (dr.GetValue(0).ToString().Length != 0)
								{
									changeRecords += dr.GetValue(0).ToString();
									if (dr.GetValue(1).ToString().Length != 0)
									{
										deleteFlg += dr.GetValue(1).ToString();
										numbers += dr.GetValue(2).ToString();
									}
								}
							}
							else
							{
								if (dr.GetValue(0).ToString().Length != 0)
								{
									changeRecords += ',';
									changeRecords += dr.GetValue(0).ToString();
									if (dr.GetValue(1).ToString().Length != 0)
									{
										deleteFlg += ',';
										numbers += ',';
									}
									deleteFlg += dr.GetValue(1).ToString();
									numbers += dr.GetValue(2).ToString();
								}
							}
						}
					}
				}

			}
			return changeRecords;
		}

		public static void ChangeIDMask(int kind)
		{
			//2020.02.04 modify
			////2018.04.12 changed 
			//int idx = kind - (int)Global.eFileName.visit_record;
			//if (kind == (int)Global.eFileName.patient_delete_record) idx = 4;
			//if (kind == (int)Global.eFileName.kasan) idx = 5;
			var idx = -1;
			switch (kind)
			{
				case (int)Global.eFileName.patient_delete_record: idx = 4; break;
				case (int)Global.eFileName.kasan: idx = 5; break;
				case (int)Global.eFileName.kioureki_record: idx = 6; break;
				case (int)Global.eFileName.fukuyoutyuu_yakuzai_record: idx = 7; break;
				default:
					if ((int)Global.eFileName.kioureki <= kind) idx = -1;
					else idx = kind - (int)Global.eFileName.visit_record;
					break;
			}

			//2020.02.04 modify
			//string[] changeIDs = { m_changeIDs_visit, m_changeIDs_reason, m_changeIDs_patient, m_changeIDs_visit_unit, m_deleteIDs_patient, m_changeIDs_kasan };
			////string[] changeIDs = { m_changeIDs_visit, m_changeIDs_reason, m_changeIDs_patient, m_changeIDs_kasan };
			//string[] sql = new string[6];
			//sql[0] = string.Format("update ECDOC.dbo.WithYou_data_set_visit set status=1 where visit_id in ({0})", m_changeIDs_visit);
			//sql[1] = string.Format("update ECDOC.dbo.WithYou_data_set_reason set status=1 where reason_id in ({0})", m_changeIDs_reason);
			//sql[2] = string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=1 where patient_id in ({0}) and status=0", m_changeIDs_patient);
			//sql[3] = string.Format("update ECDOC.dbo.WithYou_data_set_visit_unit set status=1 where unit_id in ({0})", m_changeIDs_visit_unit);
			//sql[4] = string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=1 where patient_id in ({0})", m_deleteIDs_patient);
			//sql[5] = string.Format("update ECDOC.dbo.WithYou_data_set_kasan set status=1 where no in ({0})", m_changeIDs_kasan);
			var changeIDs = new[] {
				/*0*/m_changeIDs_visit,
				/*1*/m_changeIDs_reason,
				/*2*/m_changeIDs_patient,
				/*3*/m_changeIDs_visit_unit,
				/*4*/m_deleteIDs_patient,
				/*5*/m_changeIDs_kasan,
				/*6*/"dummy.exists.",
				/*7*/"dummy.exists.",
			};
			var sqls = new string[] { };
			switch (idx)
			{
				case 0:
					sqls = new[] {
						string.Format("update ECDOC.dbo.WithYou_data_set_visit set status=1 where visit_id in ({0})", m_changeIDs_visit),
					};
					break;
				case 1:
					sqls = new[] {
						string.Format("update ECDOC.dbo.WithYou_data_set_reason set status=1 where reason_id in ({0})", m_changeIDs_reason),
					};
					break;
				case 2:
					sqls = new[] {
						string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=1 where patient_id in ({0}) and status=0", m_changeIDs_patient),
					};
					break;
				case 3:
					sqls = new[] {
						string.Format("update ECDOC.dbo.WithYou_data_set_visit_unit set status=1 where unit_id in ({0})", m_changeIDs_visit_unit),
					};
					break;
				case 4:
					sqls = new[] {
						string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=1 where patient_id in ({0})", m_deleteIDs_patient),
					};
					break;
				case 5:
					sqls = new[] {
						string.Format("update ECDOC.dbo.WithYou_data_set_kasan set status=1 where no in ({0})", m_changeIDs_kasan),
					};
					break;
				case 6:
					sqls = new[] {
						string.Format("update ECDOC.dbo.WithYou�A�g�f�[�^���� set withyou_status = 1 where with_status = 1 and withyou_status = 0"),
						string.Format("update ECDOC.dbo.WithYou_data_set_disease set status=1 where status=0"),
					};
					break;
				case 7:
					sqls = new[] {
						string.Format("update ECDOC.dbo.WithYou�A�g�f�[�^���p����� set withyou_status = 1 where with_status = 1 and withyou_status = 0"),
						string.Format("update ECDOC.dbo.WithYou_data_set_medicines set status=1 where status=0"),
					};
					break;
			}

			//2020.02.04 modify
			//if (changeIDs[idx].Length == 0) return;
			//using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			//{
			//	//�g�����U�N�V�����J�n
			//	using (SqlTransaction tran = con.BeginTransaction())
			//	{
			//		using (SqlCommand cmd = new SqlCommand())
			//		{
			//			cmd.Connection = con;
			//			cmd.Transaction = tran;
			//			cmd.CommandText = sql[idx];
			//			cmd.ExecuteNonQuery();
			//			tran.Commit();
			//		}
			//	}
			//}
			if (0 <= idx)
			{
				if (changeIDs[idx].Length == 0) return;
				using (SqlConnection con = DBAccess.GetConnectionWithOpen())
				using (SqlTransaction tran = con.BeginTransaction())
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.Transaction = tran;

					foreach (var sql in sqls)
					{
						cmd.CommandText = sql;
						cmd.ExecuteNonQuery();
					}

					tran.Commit();
				}
			}

            if (idx == 0) m_changeIDs_visit = "";
            if (idx == 1) m_changeIDs_reason = "";
			if (idx == 2) m_changeIDs_patient = "";
            if (idx == 3) m_changeIDs_visit_unit = "";
            if (idx == 4) m_deleteIDs_patient = "";
			if (idx == 5) m_changeIDs_kasan = "";
		}

        public static void ChangeIDError(int kind)
        {
			//2020.02.04 modify
			////2018.04.12 changed 
			//int idx = kind - (int)Global.eFileName.visit_record;
			//if (kind == (int)Global.eFileName.patient_delete_record) idx = 4;
			//if (kind == (int)Global.eFileName.kasan) idx = 5;
			var idx = -1;
			switch (kind)
			{
				case (int)Global.eFileName.patient_delete_record: idx = 4; break;
				case (int)Global.eFileName.kasan: idx = 5; break;
				case (int)Global.eFileName.kioureki_record: idx = 6; break;
				case (int)Global.eFileName.fukuyoutyuu_yakuzai_record: idx = 7; break;
				default:
					if ((int)Global.eFileName.kioureki <= kind) idx = -1;
					else idx = kind - (int)Global.eFileName.visit_record;
					break;
			}

			//2020.02.04 modify
			//string[] changeIDs = { m_changeIDs_visit, m_changeIDs_reason, m_changeIDs_patient, m_changeIDs_visit_unit, m_deleteIDs_patient, m_changeIDs_kasan };
			////string[] changeIDs = { m_changeIDs_visit, m_changeIDs_reason, m_changeIDs_patient, m_changeIDs_kasan };
			//string[] sql = new string[6];
			//sql[0] = string.Format("update ECDOC.dbo.WithYou_data_set_visit set status=4 where visit_id in ({0}) and status=0", m_changeIDs_visit);
			//sql[1] = string.Format("update ECDOC.dbo.WithYou_data_set_reason set status=4 where reason_id in ({0}) and status=0", m_changeIDs_reason);
			//sql[2] = string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=4 where patient_id in ({0}) and status=0", m_changeIDs_patient);
			//sql[3] = string.Format("update ECDOC.dbo.WithYou_data_set_visit_unit set status=4 where unit_id in ({0}) and status=0", m_changeIDs_visit_unit);
			//sql[4] = string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=4 where patient_id in ({0}) and status=0", m_deleteIDs_patient);
			//sql[5] = string.Format("update ECDOC.dbo.WithYou_data_set_kasan set status=4 where no in ({0}) and status=0", m_changeIDs_kasan);
			var changeIDs = new[] {
				/*0*/m_changeIDs_visit,
				/*1*/m_changeIDs_reason,
				/*2*/m_changeIDs_patient,
				/*3*/m_changeIDs_visit_unit,
				/*4*/m_deleteIDs_patient,
				/*5*/m_changeIDs_kasan,
				/*6*/"dummy.exists.",
				/*7*/"dummy.exists.",
			};
			var sql = new[] {
				/*0*/string.Format("update ECDOC.dbo.WithYou_data_set_visit set status=4 where visit_id in ({0}) and status=0", m_changeIDs_visit),
				/*1*/string.Format("update ECDOC.dbo.WithYou_data_set_reason set status=4 where reason_id in ({0}) and status=0", m_changeIDs_reason),
				/*2*/string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=4 where patient_id in ({0}) and status=0", m_changeIDs_patient),
				/*3*/string.Format("update ECDOC.dbo.WithYou_data_set_visit_unit set status=4 where unit_id in ({0}) and status=0", m_changeIDs_visit_unit),
				/*4*/string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=4 where patient_id in ({0}) and status=0", m_deleteIDs_patient),
				/*5*/string.Format("update ECDOC.dbo.WithYou_data_set_kasan set status=4 where no in ({0}) and status=0", m_changeIDs_kasan),
				/*6*/string.Format("update ECDOC.dbo.WithYou_data_set_disease set status=4 where status=0"),
				/*7*/string.Format("update ECDOC.dbo.WithYou_data_set_medicines set status=4 where status=0"),
			};

			//2020.02.04 modify
			//if (changeIDs[idx].Length == 0) return;
			//using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			//{
			//    //�g�����U�N�V�����J�n
			//    using (SqlTransaction tran = con.BeginTransaction())
			//    {
			//        using (SqlCommand cmd = new SqlCommand())
			//        {
			//            cmd.Connection = con;
			//            cmd.Transaction = tran;
			//            cmd.CommandText = sql[idx];
			//            cmd.ExecuteNonQuery();
			//            tran.Commit();
			//        }
			//    }
			//}
			if (0 <= idx)
			{
				if (changeIDs[idx].Length == 0) return;
				using (SqlConnection con = DBAccess.GetConnectionWithOpen())
				using (SqlTransaction tran = con.BeginTransaction())
				using (SqlCommand cmd = new SqlCommand())
				{
					cmd.Connection = con;
					cmd.Transaction = tran;
					cmd.CommandText = sql[idx];
					cmd.ExecuteNonQuery();
					tran.Commit();
				}
			}

            if (idx == 0) m_changeIDs_visit = "";
            if (idx == 1) m_changeIDs_reason = "";
            if (idx == 2) m_changeIDs_patient = "";
            if (idx == 3) m_changeIDs_visit_unit = "";
            if (idx == 4) m_deleteIDs_patient = "";
            if (idx == 5) m_changeIDs_kasan = "";
        }

        public static void NoSetPatientData(string patientID)
		{
			//Form1.LoggingDisplay("[NoSetPatientData] patientID: {0}", patientID);
			string sql = string.Format("update ECDOC.dbo.WithYou_data_set_patient set status=2 where patient_id = {0}", patientID);
			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			{
				//�g�����U�N�V�����J�n
				using (SqlTransaction tran = con.BeginTransaction())
				{
					using (SqlCommand cmd = new SqlCommand())
					{
						cmd.Connection = con;
						cmd.Transaction = tran;
						cmd.CommandText = sql;
						cmd.ExecuteNonQuery();
						tran.Commit();
					}
				}
			}
		}

		//2020.02.04 add
		private static void NoSetMedicalHistoryData()
		{
			var sql = string.Format("update ECDOC.dbo.WithYou_data_set_disease set status=1 where status=0");
			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			using (SqlTransaction tran = con.BeginTransaction())
			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				cmd.CommandText = sql;
				cmd.ExecuteNonQuery();
				tran.Commit();
			}
		}

		//2020.02.04 add
		private static void NoSetTakenMedicineData()
		{
			var sql = string.Format("update ECDOC.dbo.WithYou_data_set_medicines set status=1 where status=0");
			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			using (SqlTransaction tran = con.BeginTransaction())
			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				cmd.CommandText = sql;
				cmd.ExecuteNonQuery();
				tran.Commit();
			}
		}

		public static IEnumerable<string> GetMedicalHistory(IEnumerable<string> patientIds)
		{
			const string SQL_TEMPLATE = "SELECT " +
				"t.* " +
				",ms.[�E������] " +
				",mk.[���Z�dCD] " +
				",mk.[�����𖼃J���e�p] " +
				"FROM " +
				"ECDB.dbo.[���Ҋ�{1������] t " +
				"LEFT JOIN " +
				"(select " +
				"[�E��CD] " +
				",max([�E������]) [�E������] " +
				"from " +
				"ECDB.dbo.[�E��M] " +
				"group by " +
				"[�E��CD] " +
				") ms  " +
				"ON ms.[�E��CD] = t.[�X�V��] " +
				"LEFT JOIN " +
				"ECDB.dbo.[������M] mk " +
				"ON mk.[�������R�[�h] = t.[�������R�[�h] " +
				//"WHERE t.�폜�t���O <> 1 " +
				"ORDER BY t.���Ҕԍ�, t.���ԍ� ";

			const string SQL_TEMPLATE_patientId = "SELECT " +
				"t.* " +
				",ms.[�E������] " +
				",mk.[���Z�dCD] " +
				",mk.[�����𖼃J���e�p] " +
				"FROM " +
				"ECDB.dbo.[���Ҋ�{1������] t " +
				"LEFT JOIN " +
				"(select " +
				"[�E��CD] " +
				",max([�E������]) [�E������] " +
				"from " +
				"ECDB.dbo.[�E��M] " +
				"group by " +
				"[�E��CD] " +
				") ms  " +
				"ON ms.[�E��CD] = t.[�X�V��] " +
				"LEFT JOIN " +
				"ECDB.dbo.[������M] mk " +
				"ON mk.[�������R�[�h] = t.[�������R�[�h] " +
				//"WHERE t.�폜�t���O <> 1 " +
				//"AND t.���Ҕԍ� = '{0}' " +
				"WHERE t.���Ҕԍ� = '{0}' " +
				"ORDER BY t.���ԍ� ";

			const string HEADDAR = "���Ҕԍ�,���ԍ�,�������R�[�h,����,�o��,�J���e�󎚃t���O,��p�L���{�t���O,��������͓�,��f�\�R�[�h,��f�\SEQ,�폜�t���O,�X�V����,�X�V��,�E������,���Z�dCD,�����𖼃J���e�p";

			var fmtLine = new Func<SqlDataReader, string>(dr => {
				var line = new StringBuilder();
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "���Ҕԍ�", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "���ԍ�", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�������R�[�h", ""));
				line.AppendFormat("\"{0}\",", GetDataValueDate(dr, "����", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�o��", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�J���e�󎚃t���O", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "��p�L���t���O", ""));
				line.AppendFormat("\"{0}\",", GetDataValueDate(dr, "��������͓�", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "��f�\�R�[�h", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "��f�\SEQ", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�폜�t���O", ""));
				line.AppendFormat("\"{0}\",", GetDataValueDateTime(dr, "�X�V����", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�X�V��", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�E������", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "���Z�dCD", ""));
				line.AppendFormat("\"{0}\"", GetDataValue(dr, "�����𖼃J���e�p", ""));
				return line.ToString();
			});

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			using (SqlTransaction tran = con.BeginTransaction())
			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;

				if (patientIds == null || !patientIds.Any())
				{
					cmd.CommandText = SQL_TEMPLATE;

					var csvData = new List<string>();
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						if (dr.HasRows)
						{
							csvData.Add(HEADDAR);
							while (dr.Read())
							{
								csvData.Add(fmtLine(dr));
							}
							csvData.Add("END\r\n");
						}
					}
					return csvData.ToArray();
				}

				{
					var csvData = new List<string>();
					var cnt = 0;
					foreach (var patientId in patientIds)
					{
						cmd.CommandText = string.Format(SQL_TEMPLATE_patientId, patientId);

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								if (cnt <= 0)
								{
									csvData.Add(HEADDAR);
									cnt++;
								}
								while (dr.Read())
								{
									csvData.Add(fmtLine(dr));
									cnt++;
								}
							}
						}
					}
					if (0 < cnt)
					{
						csvData.Add("END\r\n");
						cnt++;
					}
					return csvData.ToArray();
				}
			}
		}

		//2020.02.04 add
		public static IEnumerable<string> GetMedicalHistoryRecord()
		{
			const string SQL_TEMPLATE1 = "SELECT status FROM ECDOC.dbo.WithYou_data_set_disease WHERE status='0'";
			const string SQL_TEMPLATE2 = "SELECT * FROM ECDOC.dbo.WithYou�A�g�f�[�^���� where with_status = 1 and withyou_status = 0 order by patient_id, measure_date, seq_no";
			const string HEADDAR = "���Ҕԍ�,�f�[�^���t,�ʔ�,�}�X�N,�o�^�E�X�V��,�o�^�E�X�V��,���a/�������敪,���a���R�[�h,������,�f�f������Ë@�֖�,With���ԍ�,With�������R�[�h,With�o��,ICD-10(2003),�������J�i,WithYou�X�V�X�e�[�^�X,With�X�V�X�e�[�^�X,With�X�V�ҁi�E��CD�j,With�X�V�ҁi�E�������j,With�X�V����";

			var csvData = new List<string>();

			var m_changeIDs_disease = GetChangeRecords(SQL_TEMPLATE1);
			if (m_changeIDs_disease.Length == 0) return csvData;

			var datetimeToStringOrEmpty = new Func<SqlDataReader, string, string, string>((dr, ordinal, format) => {
				var value = dr.GetValue(dr.GetOrdinal(ordinal));
				if (value == null || value == DBNull.Value)
				{
					return "";
				}
				var date = (DateTime)value;
				return date.ToString(format);
			});

			var fmtLine = new Func<SqlDataReader, string>(dr => {
				var line = new StringBuilder();
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "patient_id", ""));
				line.AppendFormat("\"{0}\",", datetimeToStringOrEmpty(dr, "measure_date", "yyyy/MM/dd"));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "seq_no", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "mask", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "regist_user", ""));
				line.AppendFormat("\"{0}\",", datetimeToStringOrEmpty(dr, "regist_date", "yyyy/MM/dd HH:mm:ss"));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "medical_history", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "disease_cd", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "disease_name", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "medical_facility", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_seqno", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_kiorekicd", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_keika", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "icd10", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "disease_name_kana", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "withyou_status", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_status", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_mod_usercd", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_mod_username", ""));
				line.AppendFormat("\"{0}\"", datetimeToStringOrEmpty(dr, "with_mod_date", "yyyy/MM/dd HH:mm:ss"));
				return line.ToString();
			});

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			using (SqlTransaction tran = con.BeginTransaction())
			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				cmd.CommandText = SQL_TEMPLATE2;

				using (SqlDataReader dr = cmd.ExecuteReader())
				{
					if (dr.HasRows)
					{
						csvData.Add(HEADDAR);
						while (dr.Read())
						{
							csvData.Add(fmtLine(dr));
						}
					}
					else
					{
						NoSetMedicalHistoryData();
					}
					csvData.Add("END\r\n");
				}
			}

			return csvData;
		}

		public static IEnumerable<string> GetTakenMedicine(IEnumerable<string> patientIds)
		{
			var yymms = GetAllYYMM();

			var sqltmpl = new StringBuilder();
			sqltmpl.AppendFormat("SELECT");
			sqltmpl.AppendLine().AppendFormat("t.*");
			sqltmpl.AppendLine().AppendFormat(",ms.[�E������]");
			sqltmpl.AppendLine().AppendFormat(",coalesce(");
			sqltmpl.AppendLine().AppendFormat("    {0}", string.Join(",", yymms.Select(s => $"[my{s}].[���i����]").ToArray()));
			sqltmpl.AppendLine().AppendFormat("    ) [���i����]");
			sqltmpl.AppendLine().AppendFormat("FROM");
			sqltmpl.AppendLine().AppendFormat("ECDB.dbo.[���Ҋ�{1���p�����] t");
			sqltmpl.AppendLine().AppendFormat("LEFT JOIN");
			sqltmpl.AppendLine().AppendFormat("(select");
			sqltmpl.AppendLine().AppendFormat("[�E��CD]");
			sqltmpl.AppendLine().AppendFormat(",max([�E������]) [�E������]");
			sqltmpl.AppendLine().AppendFormat("from");
			sqltmpl.AppendLine().AppendFormat("ECDB.dbo.[�E��M]");
			sqltmpl.AppendLine().AppendFormat("group by");
			sqltmpl.AppendLine().AppendFormat("[�E��CD]");
			sqltmpl.AppendLine().AppendFormat(") ms");
			sqltmpl.AppendLine().AppendFormat("ON ms.[�E��CD] = t.[�X�V��]");

			foreach (var yymm in yymms)
			{
				sqltmpl.AppendLine().AppendFormat("LEFT JOIN");
				sqltmpl.AppendLine().AppendFormat("ECDB{0}.dbo.[��M] [my{0}]", yymm);
				sqltmpl.AppendLine().AppendFormat("ON [my{0}].[�򉿃R�[�h] = t.[�򉿃R�[�h]", yymm);
			}

			const string HEADDAR = "���Ҕԍ�,���ԍ�,�򉿃R�[�h,���p�J�n��,���p�I����,���p�敪,��f�\�R�[�h,�폜�t���O,�X�V����,�X�V��,���ܓ�,����蒠�Ǎ��t���O,�E������,��ܖ�";

			var fmtLine = new Func<SqlDataReader, string>(dr => {
				var line = new StringBuilder();
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "���Ҕԍ�", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "���ԍ�", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�򉿃R�[�h", ""));
				line.AppendFormat("\"{0}\",", GetDataValueDate(dr, "���p�J�n��", ""));
				line.AppendFormat("\"{0}\",", GetDataValueDate(dr, "���p�I����", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "���p�敪", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "��f�\�R�[�h", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�폜�t���O", ""));
				line.AppendFormat("\"{0}\",", GetDataValueDateTime(dr, "�X�V����", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�X�V��", ""));
				line.AppendFormat("\"{0}\",", GetDataValueDate(dr, "���ܓ�", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "����蒠�Ǎ��t���O", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "�E������", ""));
				line.AppendFormat("\"{0}\"", GetDataValue(dr, "���i����", ""));
				return line.ToString();
			});

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			using (SqlTransaction tran = con.BeginTransaction())
			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;

				if (patientIds == null || !patientIds.Any())
				{
					var sqltmpl2 = new StringBuilder(sqltmpl.ToString());
					//sqltmpl.AppendLine().AppendFormat("WHERE t.�폜�t���O <> 1");
					sqltmpl2.AppendLine().AppendFormat("ORDER BY t.���Ҕԍ�, t.���ԍ�");

					cmd.CommandText = sqltmpl2.ToString();

					var csvData = new List<string>();
					using (SqlDataReader dr = cmd.ExecuteReader())
					{
						if (dr.HasRows)
						{
							csvData.Add(HEADDAR);
							while (dr.Read())
							{
								csvData.Add(fmtLine(dr));
							}
							csvData.Add("END\r\n");
						}
					}
					return csvData.ToArray();
				}

				{
					var sqltmpl2 = new StringBuilder(sqltmpl.ToString());
					//sqltmpl2.AppendLine().AppendFormat("WHERE t.�폜�t���O <> 1");
					//sqltmpl2.AppendLine().AppendFormat("AND t.���Ҕԍ� = '{0}'");
					sqltmpl2.AppendLine().AppendFormat("WHERE t.���Ҕԍ� = @patientId");
					sqltmpl2.AppendLine().AppendFormat("ORDER BY t.���ԍ�");

					cmd.CommandText = sqltmpl2.ToString();

					var csvData = new List<string>();
					var cnt = 0;
					foreach (var patientId in patientIds)
					{
						cmd.Parameters.Clear();
						cmd.Parameters.Add(new SqlParameter("@patientId", SqlDbType.VarChar) { Value = patientId });

						using (SqlDataReader dr = cmd.ExecuteReader())
						{
							if (dr.HasRows)
							{
								if (cnt <= 0)
								{
									csvData.Add(HEADDAR);
									cnt++;
								}
								while (dr.Read())
								{
									csvData.Add(fmtLine(dr));
									cnt++;
								}
							}
						}
					}
					if (0 < cnt)
					{
						csvData.Add("END\r\n");
						cnt++;
					}
					return csvData.ToArray();
				}
			}
		}

		//2020.02.04 add
		public static IEnumerable<string> GetTakenMedicineRecord()
		{
			const string SQL_TEMPLATE1 = "SELECT status FROM ECDOC.dbo.WithYou_data_set_medicines WHERE status='0'";
			const string SQL_TEMPLATE2 = "SELECT * FROM ECDOC.dbo.WithYou�A�g�f�[�^���p����� where with_status = 1 and withyou_status = 0 order by patient_id, measure_date, seq_no";
			const string HEADDAR = "���Ҕԍ�,�f�[�^���t,�ʔ�,�}�X�N,�o�^�E�X�V��,�o�^�E�X�V��,���p��,�򉿃R�[�h,��ܖ�,������Ë@�֖�,With���ԍ�,WithYou�X�V�X�e�[�^�X,With�X�V�X�e�[�^�X,With�X�V�ҁi�E��CD�j,With�X�V�ҁi�E�������j,With�X�V����";

			var csvData = new List<string>();

			var m_changeIDs_medicines = GetChangeRecords(SQL_TEMPLATE1);
			if (m_changeIDs_medicines.Length == 0) return csvData;

			var datetimeToStringOrEmpty = new Func<SqlDataReader, string, string, string>((dr, ordinal, format) => {
				var value = dr.GetValue(dr.GetOrdinal(ordinal));
				if (value == null || value == DBNull.Value)
				{
					return "";
				}
				var date = (DateTime)value;
				return date.ToString(format);
			});

			var fmtLine = new Func<SqlDataReader, string>(dr => {
				var line = new StringBuilder();
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "patient_id", ""));
				line.AppendFormat("\"{0}\",", datetimeToStringOrEmpty(dr, "measure_date", "yyyy/MM/dd"));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "seq_no", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "mask", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "regist_user", ""));
				line.AppendFormat("\"{0}\",", datetimeToStringOrEmpty(dr, "regist_date", "yyyy/MM/dd HH:mm:ss"));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "medical_history", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "yakka_code", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "medicine_name", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "medical_facility", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_seqno", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "withyou_status", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_status", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_mod_usercd", ""));
				line.AppendFormat("\"{0}\",", GetDataValue(dr, "with_mod_username", ""));
				line.AppendFormat("\"{0}\"", datetimeToStringOrEmpty(dr, "with_mod_date", "yyyy/MM/dd HH:mm:ss"));
				return line.ToString();
			});

			using (SqlConnection con = DBAccess.GetConnectionWithOpen())
			using (SqlTransaction tran = con.BeginTransaction())
			using (SqlCommand cmd = new SqlCommand())
			{
				cmd.Connection = con;
				cmd.Transaction = tran;
				cmd.CommandText = SQL_TEMPLATE2;

				using (SqlDataReader dr = cmd.ExecuteReader())
				{
					if (dr.HasRows)
					{
						csvData.Add(HEADDAR);
						while (dr.Read())
						{
							csvData.Add(fmtLine(dr));
						}
					}
					else
					{
						NoSetTakenMedicineData();
					}
					csvData.Add("END\r\n");
				}
			}

			return csvData;
		}

	}
}
 