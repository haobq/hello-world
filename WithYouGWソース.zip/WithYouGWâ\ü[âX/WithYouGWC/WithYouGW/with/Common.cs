﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;


namespace WithYouGW
{
	public class Common
	{
		//ECDB.txt、ECDB.iniに設定されている値
		private static string m_DBServerName = "";
		public enum WarekiType
		{
			Nengappi = 1,
			Nengetsu = 2,
			Nen = 3
		}

		//ECDB.txtの指定行から値を取得する
		private static string GetValueFromECDBtxt(int lineNumber)
		{

			string ECDB_TXT_PATH = @"D:\ENV\ECDB.txt";
			if(Global.DBG_FLG)
				ECDB_TXT_PATH = @"c:\ENV\ECDB.txt";

			string tmpValue = null;
			string strValue = "";
			using (StreamReader objStreamReader = new StreamReader(ECDB_TXT_PATH, System.Text.Encoding.Default))
			{
				for (int i = 1; i <= lineNumber - 1; i++)
				{
					tmpValue = objStreamReader.ReadLine();
				}
				strValue = objStreamReader.ReadLine().Trim();
			}

			return strValue;
		}

		//ECDB.txtの9行目からDBサーバー名を取得する(DBG時用)
		public static string GetDBServerNameDebug()
		{
			if (string.IsNullOrEmpty(m_DBServerName))
			{
				const int ECDB_TXT_LINE_NUMBER_DB_SERVER = 9;
				m_DBServerName = GetValueFromECDBtxt(ECDB_TXT_LINE_NUMBER_DB_SERVER);
			}

			return "172.17.5.201";
		}

		//ECDB.txtの9行目からDBサーバー名を取得する
		public static string GetDBServerName()
		{
			if (string.IsNullOrEmpty(m_DBServerName))
			{
				const int ECDB_TXT_LINE_NUMBER_DB_SERVER = 9;
				m_DBServerName = GetValueFromECDBtxt(ECDB_TXT_LINE_NUMBER_DB_SERVER);
			}

			return m_DBServerName;
		}

		/// <summary>
		/// 文字列からバイト数を指定して部分文字列を取得する。
		/// </summary>
		/// <param name="value">対象文字列</param>
		/// <param name="startIndex">開始位置（バイト数）</param>
		/// <param name="length">長さ（バイト数）</param>
		/// <returns>部分文字列</returns>
		/// <remarks>文字列は <c>Shift_JIS</c> でエンコーディングして処理を行います。</remarks>
		public static string SubstringByte(string value, int startIndex, int length)
		{
			if (startIndex < 0)
			{
				throw new ArgumentOutOfRangeException("開始位置が0未満です。");
			}

			if (length < 0)
			{
				throw new ArgumentOutOfRangeException("部分文字列の長さが0未満です。");
			}

			Encoding sjisEnc = Encoding.GetEncoding("Shift_JIS");
			byte[] byteArray = sjisEnc.GetBytes(value);

			if (byteArray.Length < startIndex + length)
			{
				length = byteArray.Length - startIndex;
			}

			string cut = sjisEnc.GetString(byteArray, startIndex, length);

			//2020.02.13 remove
			//// 最初の文字が全角の途中で切れていた場合はカット
			//string left = sjisEnc.GetString(byteArray, 0, startIndex + 1);
			//char first = value[left.Length - 1];
			//if (0 < cut.Length && !(first == cut[0]))
			//{
			//	cut = cut.Substring(1);
			//}

			// 最後の文字が全角の途中で切れていた場合はカット
			var left = sjisEnc.GetString(byteArray, 0, startIndex + length);

			char last = value[left.Length - 1];
			if (0 < cut.Length && !(last == cut[cut.Length - 1]))
			{
				cut = cut.Substring(0, cut.Length - 1);
			}

			return cut;
		}
	}
}
