using System;
using System.IO;
using System.Windows.Forms;

namespace WithYouGW
{
	//
	// ���M���O class
	//
	public class Logging
	{
		const  string 		m_defaultDateFormat = "HH:mm:ss.ff";

		private DateTime	m_orgDateTime;
		private string		m_logDir;
		private string		m_dateFormat;
		private ListBox		m_list = null;
		private int			m_listMax;
		private int			m_storage_days = 0;

		private string		m_logFileName = "";
		private object		m_lockObj = new object();

		public Logging(string logDir, string dateFormat, int days, ListBox list, int listMax)
		{
			m_logDir = logDir;
			if (dateFormat.Length == 0) m_dateFormat = m_defaultDateFormat;
			else m_dateFormat = dateFormat;
			m_storage_days = days;
			m_list = list;
			m_listMax = listMax;

			m_orgDateTime = (DateTime.Now).Date;    // �N�����̐ݒ�
		}

		public bool LoggingStart()
		{
			const string format = "yyyyMMdd";
			const string suffix = "WithYouGW.txt";

			if (util.CreateDirectory(m_logDir) == false)
			{
				//MessageBox.Show("���O�t�H���_�̍쐬�Ɏ��s���܂���");
				return false;
			}

			m_orgDateTime = (DateTime.Now).Date;

			// "WithYouGW.txt"�̂݊��ԊO�̃t�@�C���폜
			util.CleanUpFile(m_logDir, suffix, m_storage_days);

			m_logFileName = util.FileNameFromDate(m_logDir, format, suffix, true);

			return true;
		}

		~Logging()
		{
			//FileClose();
		}

		//
		// ���M���O
		//
		public void Str(string format, bool mode, params object [] arg)
		{
			string logStr = String.Format(format, arg);
			Str(logStr, mode);
		}

		public void Str(string logStr, bool mode)
		{
			string wk = "";
			if(m_orgDateTime < (DateTime.Now).Date) LoggingStart();		// ���t�ύX�Ȃ�

			wk = String.Format("{0} {1}",(DateTime.Now).ToString(m_dateFormat), logStr);

			lock (m_lockObj)
			{
				// ���O�t�@�C���̃p�X���w�肵�āAStreamWriter�̃C���X�^���X���쐬����
				using (StreamWriter sw = new StreamWriter(m_logFileName, true))
				{
					// ���݂���ꍇ�͒ǉ��ŏ�������
					sw.AutoFlush = true;
					sw.WriteLine(wk);
				}
			}

			if (mode == false) return;

			if (m_list.InvokeRequired)  // �X���b�h���قȂ�ꍇ�̑Ώ�
			{
				m_list.Invoke(new MethodInvoker(delegate
				{
					if (m_list.Items.Count >= m_listMax) m_list.Items.Clear();
					m_list.Items.Add(wk);
					m_list.SetSelected(m_list.Items.Count - 1, true);
				}));
			}
			else
			{
				if (m_list.Items.Count >= m_listMax) m_list.Items.Clear();
				m_list.Items.Add(wk);
				m_list.SetSelected(m_list.Items.Count - 1, true);
			}
		}

		public string LogFileName
		{
			get{ return m_logFileName; }
			set{ m_logFileName = value; }
		}

	}

}
