using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Services;
using VideoUploadService.Models;
using VideoUploadService.Models.Common;
using System.IO.Compression;
using log4net;
using Version = VideoUploadService.Models.Version;

namespace VideoUploadService
{
    /// <summary>
    /// VideoUploadService の概要の説明です
    /// </summary>
    [WebService(Namespace = "http://video.media.inc.co.jp/service")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class VideoUploadService : System.Web.Services.WebService
    {
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// ログイン
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public LoginRespone Login(string group_id, string user_id, string password, string hosp_id, string session_flg)
        {
            string temp_hosp_id = hosp_id;
            LoginRespone cer = new LoginRespone();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                string userpw = password;
                //パスワードSHA256バッシュ
                string secPass = Tools.GetEncryptString(userpw, group_id, user_id);
                Certification cert = new Certification
                {
                    Group_id = group_id,
                    Hosp_id = hosp_id,
                    User_id = user_id,
                    Session_flg = session_flg
                };
                //1.グループIDの存在確認処理を行う​
                if (Tools.IsCorrect(group_id) == false)
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgGroudIdError);
                    BizException biz = new BizException("MsgGroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.ユーザの存在確認処理を行う​
                if (Tools.IsCorrect(group_id, user_id, secPass) == false)
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgWrongUserIdOrPassword);
                    BizException biz = new BizException("MsgWrongUserIdOrPassword", Constants.MsgWrongUserIdOrPassword);
                    throw biz;
                }

                //3.端末ID取得
                string terminal_id = Tools.GetTerminalId(group_id, user_id);
                if (string.IsNullOrEmpty(terminal_id))
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgNotUseTerminalId);
                    BizException biz = new BizException("MsgNotUseTerminalId", Constants.MsgNotUseTerminalId);
                    throw biz;
                }

                //4.グループに紐付けた医院リストを取得する
                if (string.IsNullOrEmpty(temp_hosp_id))
                {
                    List<Clinic> clinicList = Tools.GetClinic_data(group_id, user_id);
                    cer.ClinicList = clinicList;
                    if (!clinicList.Any())
                    {
                        logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgHospError);
                        BizException biz = new BizException("MsgHospError", Constants.MsgHospError);
                        throw biz;
                    }

                    //医院リスト一つの場合、訪問先リストを取得する
                    if (clinicList.Count == 1)
                    {
                        hosp_id = clinicList[0].Hosp_id;
                        temp_hosp_id = hosp_id;
                    }
                    else
                    {
                        // 医院リストが複数の場合、画面に戻って医院を選択する
                        cer.Cert = cert;
                        cer.Error = error;
                        return cer;
                    }
                }

                //5.医院リスト一つの場合、訪問先リストを取得する
                if (!string.IsNullOrEmpty(temp_hosp_id))
                {
                    List<Clinic> clinicList = Tools.GetClinic_data(group_id, user_id);
                    foreach (Clinic clinic in clinicList)
                    {
                        if (temp_hosp_id.Equals(clinic.Hosp_id))
                        {
                            List<Clinic> temp = new List<Clinic>
                            {
                                clinic
                            };
                            cer.ClinicList = temp;
                            break;
                        }
                    }

                    List<Facility> facilityList = Tools.GetFacility_data(temp_hosp_id);
                    cer.FacilityList = facilityList;
                    if (!facilityList.Any())
                    {
                        logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgFacilityError);
                        BizException biz = new BizException("MsgFacilityError", Constants.MsgFacilityError);
                        throw biz;
                    }
                }

                //動画アップロード最大サイズを取得
                string videoMaxSizeStr = System.Configuration.ConfigurationManager.AppSettings["VideoMaxSize"];
                if (string.IsNullOrEmpty(videoMaxSizeStr) || !long.TryParse(videoMaxSizeStr, out long videoMaxSize))
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgVideoMaxSizeSetError);
                    BizException biz = new BizException("MsgVideoMaxSizeSetError", Constants.MsgVideoMaxSizeSetError);
                    throw biz;
                }

                //ファイル分割サイズを取得
                string videoSplitSizeStr = System.Configuration.ConfigurationManager.AppSettings["VideoSplitSize"];
                if (string.IsNullOrEmpty(videoSplitSizeStr) || !int.TryParse(videoSplitSizeStr, out int videoSplitSize))
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgVideoSplitSizeSetError);
                    BizException biz = new BizException("MsgVideoSplitSizeSetError", Constants.MsgVideoSplitSizeSetError);
                    throw biz;
                }

                cer.VideoMaxSize = videoMaxSize;
                cer.VideoSplitSize = videoSplitSize;

                //6.セッション情報を追加
                if (Tools.InsertTblSession(user_id, hosp_id, group_id, terminal_id, session_flg) == false)
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgInsertFailed);
                    BizException biz = new BizException("MsgInsertFailed", Constants.MsgInsertFailed);
                    throw biz;
                }
                //7.認証キー取得する
                cert.Media_auth = Tools.GetMedia_auth(user_id, hosp_id, group_id, session_flg);
                cert.Hosp_id = temp_hosp_id;
                cer.Cert = cert;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            cer.Error = error;
            return cer;

        }
        /// <summary>
        /// 訪問日の訪問先リスト取得する
        /// </summary>
        /// <param name="certification"></param>
        /// <param name="visitDate"></param>
        /// <returns></returns>
        [WebMethod]
        public FacilityResponse GetVisitList(Certification certification, string visitDate, string kbn)
        {
            FacilityResponse facilityResponse = new FacilityResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                //1. tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }

                string temp_hosp_id = certification.Hosp_id;
                List<Facility> facilityList = Tools.GetFacility_data(temp_hosp_id, visitDate, kbn);
                facilityResponse.Facilities = facilityList;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            facilityResponse.Error = error;
            return facilityResponse;
        }

        /// <summary>
        /// 動画・写真の情報取得
        /// </summary>
        /// <param name="certification"></param>
        /// <param name="patient_id"></param>
        /// <param name="movie_index"></param>
        /// <param name="movie_type"></param>
        /// <returns></returns>
        [WebMethod]
        public MovieListResponse GetMovieList(Certification cert, string patient_id, string movie_type, string movie_index)
        {
            MovieListResponse movieList = new MovieListResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                //1. tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(cert.Group_id, cert.User_id, cert.Media_auth, cert.Session_flg) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2. 動画・写真の情報取得
                if (string.IsNullOrEmpty(movie_type))
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgMoviType);
                    BizException biz = new BizException("MsgMoviType", Constants.MsgMoviType);
                    throw biz;
                }
                movieList.Movies = Tools.GetMovieList(cert.Hosp_id, patient_id, movie_index, movie_type);
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            movieList.Error = error;
            return movieList;
        }

        /// <summary>
        /// 動画削除
        /// </summary>
        /// <param name="certification"></param>
        /// <param name="patient_id"></param>
        /// <param name="video_no"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolResponse VideoDelete(Certification cert, string patient_id, int video_no)
        {
            BoolResponse boolResponse = new BoolResponse
            {
                Ret = false
            };
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };

            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(cert.Group_id, cert.User_id, cert.Media_auth, cert.Session_flg) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.動画の情報取得
                List<Movies> movies = Tools.GetMovieList(cert.Hosp_id, patient_id, video_no.ToString(), "1");
                if (movies == null || movies.Count != 1)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgMoviNoData);
                    BizException biz = new BizException("MsgMoviNoData", Constants.MsgMoviNoData);
                    throw biz;
                }

                DeleteRequest request = new DeleteRequest
                {
                    Certification = cert,
                    Patient_id = patient_id,
                    Movie_index = movies[0].Movie_no,
                    Video_path = movies[0].Movie_path,
                    Movie_date = movies[0].Photo_date
                };
                // 動画ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadMoviFolder"].ToString();
                //3.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFolderNoExist);
                    BizException biz = new BizException("MsgFolderNoExist", Constants.MsgFolderNoExist);
                    throw biz;
                }
                //4.動画ファイルをフォルダから削除
                String mibiePath = movies[0].Movie_path;
                if (string.IsNullOrEmpty(mibiePath))
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFailedGetPath);
                    BizException biz = new BizException("MsgFailedGetPath", Constants.MsgFailedGetPath);
                    throw biz;
                }

                try
                {
                    // 5.動画ファイル削除
                    File.Delete(basePath + @"\" + mibiePath);
                }
                catch (Exception)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgDelMoviFileFailed);
                    BizException biz = new BizException("MsgDelMoviFileFailed", Constants.MsgDelMoviFileFailed);
                    throw biz;
                }

                //6.動画情報のDB情報を削除
                bool movieRet = Tools.DeleteMovie(request);
                if (movieRet == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("MsgFailedDelete", Constants.MsgFailedDelete);
                    throw biz;
                }

                boolResponse.Ret = true;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            boolResponse.Error = error;
            return boolResponse;
        }
        /// <summary>
        /// 動画DB情報更新
        /// </summary>
        /// <param name="cert"></param>
        /// <param name="patient_id"></param>
        /// <param name="video_no"></param>
        /// <param name="title"></param>
        /// <param name="video_tag"></param>
        /// <param name="remarks"></param>
        /// <param name="video_Kbn"></param>
        /// <param name="mask"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolResponse VideoUpdate(Certification cert, string patient_id, int video_no, string title, string video_tag, string remarks, string video_Kbn, string mask)
        {
            BoolResponse boolResponse = new BoolResponse
            {
                Ret = false
            };
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(cert.Group_id, cert.User_id, cert.Media_auth, cert.Session_flg) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.更新のデータの整合性チェック
                if (string.IsNullOrEmpty(cert.Hosp_id) || string.IsNullOrEmpty(cert.User_id) || video_no < 0)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFailedUpdate);
                    BizException biz = new BizException("MsgFailedUpdate", Constants.MsgFailedUpdate);
                    throw biz;
                }
                if (!string.IsNullOrEmpty(mask) && mask != "1" && mask != "0" && mask.ToLower() != "null")
                {
                    logger.Error(cert.Hosp_id + "-" + patient_id + "-" + video_no + ":" + Constants.MsgFailedMask);
                    BizException biz = new BizException("MsgFailedMask", Constants.MsgFailedMask);
                    throw biz;
                }
                //3.DBに更新
                if (Tools.VideoUpdate(cert, patient_id, video_no, title, video_tag, remarks, video_Kbn, mask) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + patient_id + "-" + video_no + ":" + Constants.MsgFailedUpdate);
                    BizException biz = new BizException("MsgFailedUpdate", Constants.MsgFailedUpdate);
                    throw biz;
                }
                boolResponse.Ret = true;

            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            boolResponse.Error = error;
            return boolResponse;
        }
        /// <summary>
        ///  静止画DB情報更新
        /// </summary>
        /// <param name="cert"></param>
        /// <param name="patient_id"></param>
        /// <param name="image_no"></param>
        /// <param name="title"></param>
        /// <param name="image_tag"></param>
        /// <param name="remarks"></param>
        /// <param name="image_Kbn"></param>
        /// <param name="mask"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolResponse ImageUpdate(Certification cert, string patient_id, int image_no, string title, string image_tag, string remarks, string image_Kbn, string mask)
        {
            BoolResponse boolResponse = new BoolResponse
            {
                Ret = false
            };
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(cert.Group_id, cert.User_id, cert.Media_auth, cert.Session_flg) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.更新のデータの整合性チェック
                if (string.IsNullOrEmpty(cert.Hosp_id) || string.IsNullOrEmpty(cert.User_id) || image_no < 0)
                {
                    BizException biz = new BizException("MsgFailedUpdate", Constants.MsgFailedUpdate);
                    throw biz;
                }
                if (!string.IsNullOrEmpty(mask) && mask != "1" && mask != "0" && mask.ToLower() != "null")
                {
                    logger.Error(cert.Hosp_id + "-" + patient_id + "-" + image_no + ":" + Constants.MsgFailedMask);
                    BizException biz = new BizException("MsgFailedMask", Constants.MsgFailedMask);
                    throw biz;
                }
                //3.DBに更新
                if (Tools.ImageUpdate(cert, patient_id, image_no, title, image_tag, remarks, image_Kbn, mask) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + patient_id + "-" + image_no + ":" + Constants.MsgFailedUpdate);
                    BizException biz = new BizException("MsgFailedUpdate", Constants.MsgFailedUpdate);
                    throw biz;
                }
                boolResponse.Ret = true;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            boolResponse.Error = error;
            return boolResponse;
        }
        /// <summary>
        /// 静止画削除
        /// </summary>
        /// <param name="certification"></param>
        /// <param name="patient_id"></param>
        /// <param name="image_no"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolResponse ImageDelete(Certification cert, string patient_id, int image_no)
        {
            BoolResponse boolResponse = new BoolResponse
            {
                Ret = false
            };
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };

            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(cert.Group_id, cert.User_id, cert.Media_auth, cert.Session_flg) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.静止画の情報取得
                Img image = Tools.GetImage(cert, patient_id, image_no);
                image.Certification = cert;
                if (image == null)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgMoviNoData);
                    BizException biz = new BizException("MsgMoviNoData", Constants.MsgMoviNoData);
                    throw biz;
                }

                //3. 静止画ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadImgFolder"].ToString();
                //4.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFolderNoExist);
                    BizException biz = new BizException("MsgFolderNoExist", Constants.MsgFolderNoExist);
                    throw biz;
                }
                //5.静止画ファイルをフォルダから削除
                String mibiePath = image.Image_path;
                if (string.IsNullOrEmpty(mibiePath))
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFailedGetPath);
                    BizException biz = new BizException("MsgFailedGetPath", Constants.MsgFailedGetPath);
                    throw biz;
                }

                try
                {
                    //6.静止画ファイル削除
                    File.Delete(basePath + @"\" + mibiePath);
                }
                catch (Exception)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgDelImgFileFailed);
                    BizException biz = new BizException("MsgDelImgFileFailed", Constants.MsgDelImgFileFailed);
                    throw biz;
                }

                //7.静止画情報のDB情報を削除
                bool movieRet = Tools.DeleteImg(image);
                if (movieRet == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("MsgFailedDelete", Constants.MsgFailedDelete);
                    throw biz;
                }

                boolResponse.Ret = true;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            boolResponse.Error = error;
            return boolResponse;
        }

        /// <summary>
        /// ログアウト
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolResponse Logout(Certification certification)
        {
            BoolResponse boolResponse = new BoolResponse
            {
                Ret = false
            };
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }

                //2.セッション情報を削除
                if (Tools.DeleteTblSession(certification) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("MsgFailedDelete", Constants.MsgFailedDelete);
                    throw biz;
                }

                boolResponse.Ret = true;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            boolResponse.Error = error;
            return boolResponse;

        }

        /// <summary>
        /// 患者検索サービス
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public PatientResponse SearchPatient(PatientRequest request)
        {
            PatientResponse patientRes = new PatientResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }

                //2.tbl_patientテーブルを下記条件で検索する
                patientRes.Patients = Tools.GetPatient_data(request);
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            finally
            {
            }
            patientRes.Error = error;
            return patientRes;
        }
        /// <summary>
        /// 動画ファイル確認フォルダの容量計算
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public FolderSizeResponse IsOverCapacity(Certification certification)
        {
            FolderSizeResponse folderSizeRes = new FolderSizeResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            //0:容量超えない
            int ret = 0;

            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(certification.Group_id) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgGroudIdError);
                    BizException biz = new BizException("MsgGroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //3.動画・静止画契約容量使用率の閾値を取得
                string capacityCriticalRateStr = System.Configuration.ConfigurationManager.AppSettings["CapacityCriticalRate"];
                if (string.IsNullOrEmpty(capacityCriticalRateStr) || !int.TryParse(capacityCriticalRateStr, out int capacityCriticalRate))
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgCapacityCriticalSetError);
                    BizException biz = new BizException("MsgCapacityCriticalSetError", Constants.MsgCapacityCriticalSetError);
                    throw biz;
                }

                //4.契約上の容量を超えているかを返す（true:超える；false:超えていない）
                long fsize = Tools.IsOverCapacity(certification.Group_id);
                long vsize = Tools.VideoCapacity(certification.Group_id);
                long isize = Tools.ImageCapacity(certification.Group_id);

                if (fsize == 0)
                {
                    //2:設定していない
                    ret = 2;
                }
                else
                {
                    if (fsize < (isize + vsize))
                    {
                        //1:容量超える
                        ret = 1;
                    }
                }
                folderSizeRes.Contract_size = fsize;
                folderSizeRes.Used_size = isize + vsize;
                folderSizeRes.Free_size = fsize - isize - vsize;
                folderSizeRes.CapacityCriticalRate = capacityCriticalRate;
                folderSizeRes.Result = ret;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            folderSizeRes.Error = error;
            return folderSizeRes;
        }

        /// <summary>
        /// 医院の一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public ClinicResponse GetHospList(Certification certification)
        {
            ClinicResponse clinicResponse = new ClinicResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.医院の一覧を返す
                List<Clinic> clinicList = Tools.GetClinic_data(certification.Group_id, certification.User_id);
                clinicResponse.Clinics = clinicList;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            clinicResponse.Error = error;
            return clinicResponse;
        }

        /// <summary>
        /// 訪問先一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public FacilityResponse GetFacilityList(Certification certification)
        {
            FacilityResponse facilityResponse = new FacilityResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };

            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.訪問先一覧を返す
                List<Facility> facilityList = Tools.GetFacility_data(certification.Hosp_id);
                facilityResponse.Facilities = facilityList;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            facilityResponse.Error = error;
            return facilityResponse;
        }

        /// <summary>
        /// 動画ファイル最大インデクス番号取得
        /// </summary>
        /// <param name="movieRequest"></param>
        /// <returns></returns>
        public MovieResponse GetMaxVideo_no(MovieRequest request)
        {
            MovieResponse movieResponse = new MovieResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }

                //2.動画ファイル最大インデクス番号取得
                movieResponse.Video_no = Tools.GetMaxVideo_no(request);
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            movieResponse.Error = error;
            return movieResponse;
        }

        /// <summary>
        /// 動画情報格納
        /// </summary>
        /// <param name="movieRequest"></param>
        /// <returns></returns>
        [WebMethod]
        public MovieResponse MediaUploadMovi(MovieRequest request)
        {

            MovieResponse movieResponse = new MovieResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };

            try
            {

                if (string.IsNullOrEmpty(request.Millisecond))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgMillisecondl);
                    BizException biz = new BizException("MsgMillisecondl", Constants.MsgMillisecondl);
                    throw biz;
                }

                // ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadMoviFolder"];
                if (basePath == null)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgMoviNotSettedConfig);
                    BizException biz = new BizException("MsgMoviNotSettedConfig", Constants.MsgMoviNotSettedConfig);
                    throw biz;
                }
                basePath = basePath.ToString().Replace("//", "\\\\");

                // ファイル格納暫定フォルダを取得
                String tmp = System.Configuration.ConfigurationManager.AppSettings["UpLoadTempFolder"];
                if (tmp == null)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgtmpNotSettedConfig);
                    BizException biz = new BizException("MsgtmpNotSettedConfig", Constants.MsgtmpNotSettedConfig);
                    throw biz;
                }
                tmp = tmp.ToString().Replace("//", "\\\\") + @"\" + request.Millisecond + "-" + request.Certification.Hosp_id + "-" + request.Certification.User_id;

                //ファイル分割サイズを取得
                string videoSplitSizeStr = System.Configuration.ConfigurationManager.AppSettings["VideoSplitSize"];
                if (string.IsNullOrEmpty(videoSplitSizeStr) || !int.TryParse(videoSplitSizeStr, out int videoSplitSize))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgVideoSplitSizeSetError);
                    BizException biz = new BizException("MsgVideoSplitSizeSetError", Constants.MsgVideoSplitSizeSetError);
                    throw biz;
                }

                //0.ディレクトリ作成
                if (!Directory.Exists(basePath))
                {
                    Directory.CreateDirectory(basePath);
                }

                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.動画ファイルをフォルダを格納

                // grupId + 病院ID　＋　患者ID
                String kannjyaIdDrect = basePath + @"\" + request.Certification.Group_id + @"\" + request.Certification.Hosp_id + @"\" + request.Patient_id;
                //　ディレクトリ作成
                if (!Directory.Exists(kannjyaIdDrect))
                {
                    Directory.CreateDirectory(kannjyaIdDrect);
                }

                // 患者ID　＋　メディア名称
                String mediaPath = tmp + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name);

                // zip動画をローカルに保存
                String mediaPathZip = mediaPath + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + Path.GetExtension(request.Movie_name).Replace(".", "") + ".zip";
                //　ディレクトリ作成
                if (!Directory.Exists(mediaPath))
                {
                    Directory.CreateDirectory(mediaPath);
                }

                // 解凍したファイルフォルダ
                String extractPath = tmp + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name);
                //　ディレクトリ作成
                if (!Directory.Exists(extractPath))
                {
                    Directory.CreateDirectory(extractPath);
                }


                // 移動先解凍したファイル
                String moveUnZipFile = mediaPath + @"\" + request.Movie_name;

                // byte[] -> ファイル変換
                FileStream objfilestream = new FileStream(mediaPathZip, FileMode.Create, FileAccess.ReadWrite);
                objfilestream.Write(request.Movie_context, 0, request.Movie_context.Length);
                objfilestream.Close();

                // Zipファイル解凍
                ZipFile.ExtractToDirectory(mediaPathZip, extractPath);

                // Zipフォルダを削除
                File.Delete(mediaPathZip);

                // DirectoryInfoのインスタンスを生成する
                DirectoryInfo d = new DirectoryInfo(extractPath);

                // ディレクトリ直下のすべてのファイル一覧を取得する
                FileInfo[] fiAlls = d.GetFiles();

                int uploadFilesCount = fiAlls.Length;


                // 結合処理
                // 分割したファイルの総合＝＝クライアントで送信したファイル総数
                if (request.FileCount == uploadFilesCount)
                {
                    // 読込バッファサイズ
                    int READ_BYTE = videoSplitSize / 10;

                    // 分割ファイルをリストアップ
                    List<string> divFiles = new List<string>();

                    // ディレクトリ直下のすべてのファイル一覧を取得する
                    foreach (FileInfo f in fiAlls)
                    {
                        divFiles.Add(f.FullName);
                    }

                    // 結合した動画ファイル
                    string file_name = kannjyaIdDrect + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + Path.GetExtension(request.Movie_name);
                    // tempフォルダで結合したファイル名
                    string file_name_tmp = tmp + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + Path.GetExtension(request.Movie_name);


                    // 結合先ファイルを開く
                    using (FileStream wf = new FileStream(file_name_tmp, FileMode.Create, FileAccess.Write))
                    {
                        int readByte = 0;
                        long leftByte = 0;
                        byte[] readBuf = new byte[READ_BYTE];
                        foreach (string divFile in divFiles)
                        {
                            // 分割ファイルを開く
                            using FileStream rf = new FileStream(divFile, FileMode.Open, FileAccess.Read);
                            leftByte = rf.Length;
                            while (leftByte > 0)
                            {
                                try
                                {
                                    // 分割ファイルから読み込むGetFolderSize
                                    readByte = rf.Read(readBuf, 0, (int)Math.Min(READ_BYTE, leftByte));
                                    // 結合先ファイルに書きこむ
                                    wf.Write(readBuf, 0, readByte);
                                    // 読込情報の設定
                                    leftByte -= readByte;
                                }
                                catch (Exception e)
                                {
                                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                                    BizException biz1 = new BizException("MsgFileConnect", Constants.MsgFileConnect);
                                    throw biz1;
                                }

                            }
                        }
                    }

                    // ファイルの移動
                    File.Move(file_name_tmp, file_name);

                    // ディレクトリ直下のすべてのファイルを削除
                    try
                    {
                        Tools.CleanUp(tmp);
                    }
                    catch (Exception) { }

                    // 4. ファイルサイズチェック
                    FileInfo file = new FileInfo(file_name);
                    if (file.Length != request.Movie_size)
                    {
                        try
                        {
                            // 動画ファイルを削除
                            File.Delete(file_name);
                        }
                        catch (Exception e)
                        {
                            logger.Error(Constants.MsgDelMoviFileFailed + "-" + request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                            BizException biz1 = new BizException("MsgDelMoviFileFailed", Constants.MsgDelMoviFileFailed);
                            throw biz1;
                        }
                        logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFileSizeNotEqual);
                        BizException biz = new BizException("MsgFileSizeNotEqual", Constants.MsgFileSizeNotEqual);
                        throw biz;
                    }


                    MovieResponse res = GetMaxVideo_no(request);
                    int max = res.Video_no;

                    string file_new_name = kannjyaIdDrect + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + "_" + String.Format("{0:0000}", max) + Path.GetExtension(request.Movie_name);
                    movieResponse.Video_no = max;

                    // ファイルの名称変更
                    FileInfo fino = new FileInfo(file_name);
                    fino.MoveTo(file_new_name);

                    // 5.動画情報をDBに登録処理
                    Certification cer = new Certification
                    {
                        Group_id = request.Certification.Group_id,
                        Hosp_id = request.Certification.Hosp_id,
                        User_id = request.Certification.User_id,
                        Media_auth = request.Certification.Media_auth
                    };

                    MovieRequest insertMovie = new MovieRequest
                    {
                        Certification = cer,
                        Patient_id = request.Patient_id,
                        Video_no = max.ToString(),
                        Movie_date = request.Movie_date,
                        Remarks = request.Remarks,
                        Video_path = file_new_name.Replace(basePath, "").Replace(@"\", "/").Substring(1),
                        Edit_user = request.Certification.User_id,
                        Movie_size = request.Movie_size,
                        Video_tag = request.Video_tag,
                        Title = request.Title
                    };
                    //insert
                    bool movieRet = Tools.InsertMovie(insertMovie);
                    // 6. 動画情報をDBに登録処理失敗の場合、動画ファイルを削除
                    if (movieRet == false)
                    {
                        try
                        {
                            // 動画ファイルを削除
                            File.Delete(file_new_name);
                        }
                        catch (Exception e)
                        {
                            logger.Error(Constants.MsgDelMoviFileFailed + "-" + request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                            BizException biz1 = new BizException("MsgDelMoviFileFailed", Constants.MsgDelMoviFileFailed);
                            throw biz1;
                        }

                        logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedRegister);
                        BizException biz = new BizException("MsgFailedRegister", Constants.MsgFailedRegister);
                        throw biz;
                    }
                }
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();

            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            movieResponse.Error = error;
            return movieResponse;
        }

        /// <summary>
        /// 静止画情報格納
        /// </summary>
        /// <param name="movieRequest"></param>
        /// <returns></returns>
        [WebMethod]
        public MovieResponse MediaUploadImg(MovieRequest request)
        {
            DateTime photo_date = DateTime.Parse(request.Movie_date);
            MovieResponse movieResponse = new MovieResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };

            try
            {
                // ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadImgFolder"];
                if (basePath == null)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgimgNotSettedConfig);
                    BizException biz = new BizException("MsgimgNotSettedConfig", Constants.MsgimgNotSettedConfig);
                    throw biz;
                }
                basePath = basePath.ToString().Replace("//", "\\\\");

                //0.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    Directory.CreateDirectory(basePath);
                }
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.静止画ファイルをフォルダを格納
                int iImageNo = Tools.GetImageNo(request);
                // イメージ番号を設定（削除処理用)
                movieResponse.Image_no = iImageNo;

                // 病院ID　＋　患者ID
                String folderPath = basePath + @"\" + request.Certification.Hosp_id + @"\" + request.Patient_id + @"\" + photo_date.ToString("yyyy_M_d") + @"\" + "img";
                //　ディレクトリ作成
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // 静止画ファイル
                string fileExt = (Path.GetExtension(request.Movie_name)).ToLower();
                string fileName = Path.GetFileNameWithoutExtension(request.Movie_name) + fileExt;
                string filePath = folderPath + @"\" + fileName;
                //既に静止画ファイルアップされた場合
                if (File.Exists(filePath))
                {
                    filePath = folderPath + @"\" + Path.GetFileNameWithoutExtension(fileName) + "_" + String.Format("{0:0000}", iImageNo) + fileExt;

                }

                // byte[] -> ファイル変換
                FileStream objfilestream = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite);
                objfilestream.Write(request.Movie_context, 0, request.Movie_context.Length);
                objfilestream.Close();


                //4.静止画情報をDBに登録処理
                Certification cer = new Certification
                {
                    Group_id = request.Certification.Group_id,
                    Hosp_id = request.Certification.Hosp_id,
                    User_id = request.Certification.User_id,
                    Media_auth = request.Certification.Media_auth
                };

                MovieRequest insertMovie = new MovieRequest
                {
                    Certification = cer,
                    Patient_id = request.Patient_id,
                    Image_no = iImageNo,
                    Movie_date = DateTime.Now.ToString(),
                    Remarks = request.Remarks,
                    Video_path = filePath.Replace(basePath, "").Replace(@"\", "/").Substring(1),
                    Edit_user = request.Certification.User_id,
                    Movie_size = request.Movie_size,
                    Video_tag = request.Video_tag,
                    Title = request.Title
                };
                //insert
                bool movieRet = Tools.InsertImg(insertMovie);

                //5. 静止画情報をDBに登録処理失敗の場合、動画ファイルを削除
                if (movieRet == false)
                {
                    try
                    {
                        // 静止画ファイルを削除
                        File.Delete(filePath);
                    }
                    catch (Exception)
                    {
                        logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgDelImgFileFailed);
                        BizException biz1 = new BizException("MsgDelImgFileFailed", Constants.MsgDelImgFileFailed);
                        throw biz1;
                    }

                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedRegister);
                    BizException biz = new BizException("MsgFailedRegister", Constants.MsgFailedRegister);
                    throw biz;
                }
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();

            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            movieResponse.Error = error;
            return movieResponse;
        }

        /// <summary>
        /// 動画情報削除
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolResponse MediaDelete(DeleteRequest request)
        {
            BoolResponse boolResponse = new BoolResponse
            {
                Ret = false
            };
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            bool del = false;
            try
            {
                // ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadMoviFolder"].ToString();
                //0.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFolderNoExist);
                    BizException biz = new BizException("MsgFolderNoExist", Constants.MsgFolderNoExist);
                    throw biz;
                }
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.動画ファイルをフォルダから削除
                String mibiePath = Tools.GetMoviPath(request);
                if (string.IsNullOrEmpty(mibiePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedGetPath);
                    BizException biz = new BizException("MsgFailedGetPath", Constants.MsgFailedGetPath);
                    throw biz;
                }

                try
                {
                    // ファイル削除
                    File.Delete(basePath + @"\" + mibiePath);
                }
                catch (Exception)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgDelMoviFileFailed);
                    BizException biz = new BizException("MsgDelMoviFileFailed", Constants.MsgDelMoviFileFailed);
                    throw biz;
                }

                //4.動画情報のDB情報を削除
                bool movieRet = Tools.DeleteMovie(request);
                if (movieRet == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("MsgFailedDelete", Constants.MsgFailedDelete);
                    throw biz;
                }
                boolResponse.Ret = del;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(Constants.MsgInternalServerError + "-" + request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            boolResponse.Error = error;
            return boolResponse;
        }

        /// <summary>
        /// 最新バージョン情報取得
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public VersionResponse GetNewVersion(string osInfo)
        {
            VersionResponse versionResponse = new VersionResponse();
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            Version version = new Version();
            try
            {
                string basePath = System.Configuration.ConfigurationManager.AppSettings["DownloadFolder"].ToString();
                string winPackageRecognizer = ".msi";
                string macPackageRecognizer = ".dmg";
                string packagePath = "Package";
                if (osInfo.ToLower().IndexOf("win") != -1)
                {
                    var winPackageInfo = Tools.FileInfoGet(basePath + @packagePath, winPackageRecognizer);
                    //最新バージョン番号取得
                    version.Ver = winPackageInfo.VerNo;
                    //最新更新日取得
                    version.Date = Tools.FomatDate(winPackageInfo.LastUpdateDate);
                }
                else if (osInfo.ToLower().IndexOf("mac") != -1)
                {
                    var macPackageInfo = Tools.FileInfoGet(basePath + @packagePath, macPackageRecognizer);
                    //最新バージョン番号取得
                    version.Ver = macPackageInfo.VerNo;
                    //最新更新日取得
                    version.Date = Tools.FomatDate(macPackageInfo.LastUpdateDate);
                }
                else
                {
                    logger.Error("osInfo:" + osInfo + Constants.MsgNotPackage);
                    BizException biz = new BizException("MsgNotPackage", Constants.MsgNotPackage);
                    throw biz;
                }
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception ex)
            {
                logger.Error("osInfo:" + osInfo + "-" + ex);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = ex.ToString();
            }
            versionResponse.Ver = version;
            versionResponse.Error = error;
            return versionResponse;
        }

        /// <summary>
        /// 静止画情報削除
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolResponse MediaDeleteImg(Img request)
        {
            BoolResponse boolResponse = new BoolResponse
            {
                Ret = false
            };
            ErrorResponse error = new ErrorResponse
            {
                ErrorCode = Constants.MsgOK
            };
            bool del = false;
            try
            {
                // ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadImgFolder"].ToString();
                //0.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFolderNoExist);
                    BizException biz = new BizException("MsgFolderNoExist", Constants.MsgFolderNoExist);
                    throw biz;
                }
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("MsgUnauthorized", Constants.MsgUnauthorized);
                    throw biz;
                }
                //2.静止画ファイルをフォルダから削除
                String mibiePath = Tools.GetImgPath(request);
                if (string.IsNullOrEmpty(mibiePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedGetPath);
                    BizException biz = new BizException("MsgFailedGetPath", Constants.MsgFailedGetPath);
                    throw biz;
                }

                try
                {
                    // ファイル削除
                    File.Delete(basePath + @"\" + mibiePath);
                }
                catch (Exception)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgDelImgFileFailed);
                    BizException biz = new BizException("MsgDelImgFileFailed", Constants.MsgDelImgFileFailed);
                    throw biz;
                }

                //4.静止画情報のDB情報を削除
                bool movieRet = Tools.DeleteImg(request);
                if (movieRet == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("MsgFailedDelete", Constants.MsgFailedDelete);
                    throw biz;
                }
                boolResponse.Ret = del;
            }
            catch (BizException bz)
            {
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
                error.ErrorDetail = bz.ToString();
            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgInternalServerError + Environment.NewLine + e);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
                error.ErrorDetail = e.ToString();
            }
            boolResponse.Error = error;
            return boolResponse;
        }
    }
}
