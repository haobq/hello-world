﻿namespace VideoUploadService.Models.Common
{
    public class Constants
    {
        #region メッセージ
        // メッセージ
        public const string MsgOK = "0";
        public const string MsgHospError = "医院データが取得できません。";
        public const string MsgFacilityError = "訪問先を取得できません。";
        public const string MsgGroudIdError = "グループIDが不正です。";
        public const string MsgExistedAuthentication = "有効な認証データが既にあります。";
        public const string MsgInsertFailed = "セッション情報の追加が失敗しました。";
        public const string MsgUnauthorized = "サーバーとの接続が切れましたので再ログインして下さい。";
        public const string MsgWrongUserIdOrPassword = "ユーザID／パスワードが不正です。";
        public const string MsgNotUseTerminalId = "この端末IDは利用できません。";
        public const string MsgFailedRegister = "データ登録に失敗しました。";
        public const string MsgFailedDelete = "データ削除に失敗しました。";
        public const string MsgFailedUpdate = "データ更新に失敗しました。";
        public const string MsgFailedMask = "非表示フラグのパラメータが不正です。";
        public const string MsgFailedGetPath = "ファイル格納場所が見つかりません。";
        public const string MsgInternalServerError = "サーバ側で何らかのエラーが発生しました。";
        public const string MsgSqlError = "データ取得時にエラーが発生しました。";
        public const string MsgDelMoviFileFailed = "動画ファイルの削除に失敗しました。";
        public const string MsgDelImgFileFailed = "静止画ファイルの削除に失敗しました。";
        public const string MsgFolderNoExist = "作業用フォルダが存在していません。";
        public const string MsgFileSizeNotEqual = "アップロード処理時,ファイルサイズが不一致です。";
        public const string MsgMillisecondl = "ローカルPC側から渡った日時引数が設定されていません。";
        public const string MsgFileConnect = "ファイル結合処理でエラーが発生しました。";
        public const string MsgMoviType = "動画/静止画の区分がありません。";
        public const string MsgMoviNoData = "動画/静止画データがありません。";
        public const string MsgMoviNotSettedConfig = "Web.configファイルに動画格納フォルダが未設定です。";
        public const string MsgimgNotSettedConfig = "Web.configファイルに静止画格納フォルダが未設定です。";
        public const string MsgtmpNotSettedConfig = "Web.configファイルにTMPフォルダが未設定です。";
        public const string MsgVideoMaxSizeSetError = "Web.configファイルに「動画アップロード最大サイズ」が未設定、或は設定不正です。";
        public const string MsgVideoSplitSizeSetError = "Web.configファイルに「動画ファイルの分割サイズ」が未設定、或は設定不正です。";
        public const string MsgCapacityCriticalSetError = "Web.configファイルに「動画・静止画契約容量使用率の閾値」が未設定、或は設定不正です。";
        public const string MsgNotPackage = "適用なパッケージがありません。";

        #endregion

    }
}