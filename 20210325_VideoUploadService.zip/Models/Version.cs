﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class Version
    {
        //バージョン
        public string Ver { get; set; }
        //最新更新日
        public string Date { get; set; }
    }

    public class VersionInfo
    {
        //バージョン
        public string VerNo { get; set; }
        //最新更新日
        public string LastUpdateDate { get; set; }
        //ファイルパス
        public string FilePath { get; set; }
    }
}