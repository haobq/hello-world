﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class FolderSizeResponse
    {
        public long Contract_size { get; set; }
        public long Used_size { get; set; }
        public long Free_size { get; set; }
        public int CapacityCriticalRate { get; set; }
        public int Result { get; set; }
        //エラー
        public ErrorResponse Error { get; set; }
    }
}