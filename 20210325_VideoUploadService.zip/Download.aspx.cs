using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VideoUploadService.Models;
using VideoUploadService.Models.Common;

namespace VideoUploadService
{
    public partial class Download : System.Web.UI.Page
    {
        readonly String basePath = System.Configuration.ConfigurationManager.AppSettings["DownloadFolder"].ToString();
        private static string winPackageRecognizer = ".msi";
        private static string macPackageRecognizer = ".dmg";
        private static string macManualRecognizer = "mac";
        private static string winManualRecognizer = "win";
        private static string packagePath = "Package";
        private static string manualPath = "Manual";

        //�p�b�P�[�W�t�@�C��
        string packageFilePath;
        //�}�j���A���t�@�C��
        string manualFilePath;

        protected void Page_Load(object sender, EventArgs e)
        {
            String osInfo = Request.UserAgent.ToLower();

            if (osInfo.IndexOf("windows nt") != -1)
            {
                VersionInfo winPackageInfo = Tools.FileInfoGet(basePath + @packagePath, winPackageRecognizer);
                packageFilePath = winPackageInfo.FilePath;
                DrawDownloadTable(packageTable, winPackageInfo, Package_Click);

                VersionInfo winManualInfo = Tools.FileInfoGet(basePath + @manualPath, winManualRecognizer);
                manualFilePath = winManualInfo.FilePath;
                DrawDownloadTable(manualTable, winManualInfo, Manual_Click);
            }
            else if (osInfo.IndexOf("mac os") != -1)
            {
                VersionInfo macPackageInfo = Tools.FileInfoGet(basePath + @packagePath, macPackageRecognizer);
                packageFilePath = macPackageInfo.FilePath;
                DrawDownloadTable(packageTable, macPackageInfo, Package_Click);

                VersionInfo macManualInfo = Tools.FileInfoGet(basePath + @manualPath, macManualRecognizer);
                manualFilePath = macManualInfo.FilePath;
                DrawDownloadTable(manualTable, macManualInfo, Manual_Click);
            }
            else
            {
                Label1.Text = "�K�p�ȃp�b�P�[�W������܂���B";
            }
        }


        /// <summary>
        /// �\���쐬����
        /// </summary>
        /// <param name="table"></param>
        /// <param name="htData"></param>
        /// <param name="handler"></param>
        private void DrawDownloadTable(Table table, VersionInfo fileInfo, EventHandler handler)
        {
            TableHeaderRow headerRow = new TableHeaderRow();
            TableHeaderCell headerCell;
            headerCell = new TableHeaderCell();
            if (fileInfo.FilePath.Contains(packagePath))
            {
                headerCell.Text = "�p�b�P�[�W��";
            }
            else if (fileInfo.FilePath.Contains(manualPath))
            {
                headerCell.Text = "�}�j���A����";
            }
            else
            {
                headerCell.Text = "���O";
            }
            headerCell.Width = Unit.Pixel(450);
            headerRow.Cells.Add(headerCell);

            headerCell = new TableHeaderCell();
            headerCell.Text = "�o�b�W����";
            headerCell.Width = Unit.Pixel(150);
            headerRow.Cells.Add(headerCell);

            headerCell = new TableHeaderCell();
            headerCell.Text = "�X�V���t";
            headerCell.Width = Unit.Pixel(150);
            headerRow.Cells.Add(headerCell);

            table.Rows.Add(headerRow);
            TableRow row = new TableRow();
            TableCell cell;

            //�t�@�C����
            cell = new TableCell();
            LinkButton winLinkButton = new LinkButton();
            winLinkButton.Text = Path.GetFileName(fileInfo.FilePath);
            winLinkButton.Click += handler;
            cell.Controls.Add(winLinkButton);
            row.Cells.Add(cell);

            //�t�@�C���o�[�W����
            cell = new TableCell();
            cell.Text = fileInfo.VerNo;
            row.Cells.Add(cell);

            //���t
            cell = new TableCell();
            cell.Text = Tools.FomatDate(fileInfo.LastUpdateDate);
            row.Cells.Add(cell);
            table.Rows.Add(row);

        }

        /// <summary>
        /// �p�b�P�[�W�_�E�����[�h
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Package_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"" + Path.GetFileName(packageFilePath) + "\"");
            Response.WriteFile(packageFilePath);
            Response.End();
        }

        /// <summary>
        /// �}�j���A���t�@�C���_�E�����[�h
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Manual_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"" + Path.GetFileName(manualFilePath) + "\"");
            Response.WriteFile(manualFilePath);
            Response.End();
        }

    }
}