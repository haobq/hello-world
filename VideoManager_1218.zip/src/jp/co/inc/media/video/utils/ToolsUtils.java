package jp.co.inc.media.video.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.DateFormat;

import javax.imageio.ImageIO;

import javafx.geometry.Bounds;
import javafx.geometry.Point2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Window;

public class ToolsUtils {

	/**
	 * 動画から画像を撮る
	 * @param pane
	 * @return
	 */
	public static Image screenCapture(Pane pane) {
		Image image = null;
		try {

			if (pane.getParent() != null && pane.getParent().getScene() != null) {
				Window w = pane.getParent().getScene().getWindow();
				System.out.println("w.getX()=" + w.getX());
				System.out.println("w.getY()=" + w.getY());

				System.out.println("pane.getParent().getScene().getX()=" + pane.getParent().getScene().getX());
				System.out.println("pane.getParent().getScene().getY()=" + pane.getParent().getScene().getY());

				System.out.println("pane.getParent().getX()=" + pane.getParent().getScaleX());
				System.out.println("pane.getParent().getY()=" + pane.getParent().getScaleY());

				Bounds bounds = pane.getChildren().get(0).getLayoutBounds();
				Point2D coordinates = pane.localToScene(bounds.getMinX(), bounds.getMinY());
				int X = (int) coordinates.getX() + (int) w.getX();
				int Y = (int) coordinates.getY() + (int) w.getY();
				int width = (int) pane.getWidth();
				int height = (int) pane.getHeight();
				System.out.println("X=" + X);
				System.out.println("Y=" + Y);
				System.out.println("width=" + width);
				System.out.println("height=" + height);
				java.awt.Rectangle screenRect = new java.awt.Rectangle(X, Y + 20, width, height);
				java.awt.Robot robot = new java.awt.Robot();
				java.awt.image.BufferedImage bi = robot.createScreenCapture(screenRect);
				java.io.ByteArrayOutputStream stream = new java.io.ByteArrayOutputStream();
				ImageIO.write(bi, "png", stream);
				image = new Image(new java.io.ByteArrayInputStream(stream.toByteArray()), width, height, true, true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return image;
	}

	/**
	 * 画像を設定する。
	 * @param pane
	 * @param subPane
	 */
	public static void setImageView(Pane pane, Pane subPane) {
		Image image = screenCapture(pane);
		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(subPane.getWidth());
		imageView.setFitHeight(pane.getHeight()/3.33);
		subPane.getChildren().clear();
		subPane.getChildren().add(imageView);
	}
	
	/**
	 * ＭＳ 明朝 と ＭＳ Ｐ明朝のフォント
	 * @param fontPath フォントパス
	 * @param fontSize フォントサイズ
	 * @return 文字数
	 */
	public static Font getCustomFont(String fontPath, int fontSize) {
		try {
			return Font.loadFont(new FileInputStream(new File(fontPath)), fontSize);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 全角文字は２桁、半角文字は１桁として文字数をカウントする
	 * @param str 対象文字列
	 * @return 文字数
	 */
	public static int getHan1Zen2(String str) {
	  
	  //戻り値
	  int ret = 0;
	  
	  //全角半角判定
	  char[] c = str.toCharArray();
	  for(int i=0;i<c.length;i++) {
	    if(String.valueOf(c[i]).getBytes().length <= 1){
	      ret += 1; //半角文字なら＋１
	    }else{
	      ret += 2; //全角文字なら＋２
	    }
	  }
	  
	  return ret;
	}
	/**
	 * 日付の妥当性チェックを行います。
	 * 指定した日付文字列（yyyy/MM/dd or yyyy-MM-dd）が
	 * カレンダーに存在するかどうかを返します。
	 * @param strDate チェック対象の文字列
	 * @return 存在する日付の場合true
	 */
	public static boolean checkDate(String strDate) {
		if (strDate.equals("")) {
			return true;
		}
		strDate = strDate.replace('-', '/');
		DateFormat format = DateFormat.getDateInstance();
		// 日付/時刻解析を厳密に行うかどうかを設定する。
		format.setLenient(false);
		try {
			format.parse(strDate);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}	
}
