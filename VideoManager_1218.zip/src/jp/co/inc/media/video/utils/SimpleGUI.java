package jp.co.inc.media.video.utils;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class SimpleGUI extends Application {
	public void start(Stage primaryStage) throws Exception {
		GridPane root = new GridPane();
		Scene scene = new Scene(root);

//Buttons
		Button b1 = new Button("KNAPP 1");
		Button b2 = new Button("KNAPP 2");
		Button b3 = new Button("KNAPP 3");
		Button b6 = new Button("KNAPP 6");

		root.add(b1, 0, 0);
		root.add(b2, 1, 0);
		root.add(b3, 2, 0);



// node, columnIndex, rowIndex, columnSpan, rowSpan:
		root.add(b6, 0, 1, 3, 4);

		root.setAlignment(Pos.CENTER);
// allow button to grow:
		b6.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}