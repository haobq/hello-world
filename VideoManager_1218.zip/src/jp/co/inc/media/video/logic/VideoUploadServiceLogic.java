package jp.co.inc.media.video.logic;

import java.net.ConnectException;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.namespace.QName;
import javax.xml.ws.WebServiceException;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasFrame;
import jp.co.inc.media.video.common.MessageConst;
import jp.co.inc.media.video.components.HospitalSelect;
import jp.co.inc.media.video.components.LoginDialog;
import jp.co.inc.media.video.frame.CallMainFrame;
import jp.co.inc.media.video.service.Clinic;
import jp.co.inc.media.video.service.LoginRespone;
import jp.co.inc.media.video.service.VideoUploadService;
import jp.co.inc.media.video.service.VideoUploadServiceSoap;
import jp.co.inc.media.video.utils.Messagebox;

public class VideoUploadServiceLogic extends VideoUploadService implements BasConst, MessageConst {
	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(VideoUploadServiceLogic.class.getName());
	// サービス
	public static QName SERVICE_NAME = new QName("http://video.media.inc.co.jp/service", "VideoUploadService");
	// レスポンス
	private static LoginRespone loginReponse = null;
	// 医院ID
	private static String hosp_id = null;

	// 医院選択画面Stage
	public static Stage hospitalSelect = new Stage();

	/**
	 * @return hosp_id
	 */
	public static String getHosp_id() {
		return hosp_id;
	}

	/**
	 * @param hosp_id セットする hosp_id
	 */
	public static void setHosp_id(String hosp_id) {
		VideoUploadServiceLogic.hosp_id = hosp_id;
	}

	/**
	 * サービス接続し、ポートを返す。
	 * @return port
	 */
	public static VideoUploadServiceSoap getPort() throws ConnectException {
		final URL wsdlURL = VideoUploadService.WSDL_LOCATION;
		VideoUploadServiceSoap port = null;

		final VideoUploadService service = new VideoUploadService(wsdlURL, SERVICE_NAME);
		port = service.getVideoUploadServiceSoap12();
		return port;
	}

	/**
	 * @return loginReponse
	 */
	public static LoginRespone getLoginReponse() {
		return loginReponse;
	}

	/**
	 * @param loginReponse セットする loginReponse
	 */
	public static void setLoginReponse(LoginRespone loginReponse) {
		VideoUploadServiceLogic.loginReponse = loginReponse;
	}

	public static LoginRespone LoginManager(BasFrame callBaseFrm, Stage owner, String groupId, String userId,
			String paasword) {
		// 初期化
		setHosp_id(null);
		
		try {
			
			// ログレスポンス設定
			setLoginReponse(getPort().login(groupId, userId, paasword, "",SESSION_FLG));
			
			if (SUCCESS.equals(getLoginReponse().getError().getErrorCode())) {
				// iniファイルに書き込む
				LoginDialog.writeIniFile();

				// 訪問先取得
				List<Clinic> clinicReponse = getLoginReponse().getClinicList().getClinic();
				if (clinicReponse != null) {
					// ログイン画面非表示
					CallMainFrame.loginDialog.hide();

					if (getLoginReponse().getClinicList().getClinic().size() > 1) {
						// 医院選択画面表示
						hospitalSelect = new HospitalSelect(callBaseFrm, owner, HOSPITAL_SELECT_TITLE,
								getLoginReponse().getClinicList(), groupId, userId, paasword, 300, 150);
						hospitalSelect.sizeToScene();
						hospitalSelect.show();
						hospitalSelect.setOnCloseRequest(new EventHandler<WindowEvent>() {
							@Override
							public void handle(WindowEvent event) {
								System.out.println("hospitalSelect close");
								// ログアウト
								CallMainFrame.logout();
							}
						});
					} else {
						// 医院ID設定
						setHosp_id(clinicReponse.get(0).getHospId());
					}
				}
			} else {
				Platform.runLater(
						() -> {
							Messagebox.Error(hospitalSelect, getLoginReponse().getError().getErrorMessage());
						});
				return null;
			}
			
		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, E0021);
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, E0021);
		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, E0001);
		}
		
		return getLoginReponse();
	}

}
