package ei.jp.gecapital.util;

import java.util.Locale;
import java.util.ResourceBundle;

public class PropertyUtil {

	public static String getPropertyElement(String property, String element) {
		String st = "";
		ResourceBundle prpt = null;
		prpt = ResourceBundle.getBundle(property, Locale.US);
		st = prpt.getString(element);
		return st;
	}


	public static String doPropertiesParam(String property, String[] params) {

		if (params != null && params.length > 0) {
			for (int i = 0; i < params.length; i++) {
				property = property.replace("{" + i + "}", params[i]);
			}
		}
		return property;
	}

}
