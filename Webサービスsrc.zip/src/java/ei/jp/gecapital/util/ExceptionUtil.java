/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ei.jp.gecapital.util;

import java.util.Map;
import jp.gecapital.schema.ei.eiwsexception.EIWSExceptionType;
import jp.gecapital.schema.ei.eiwsexception.EIWSExceptionsType;

/**
 *
 * @author chenshuang
 */
public class ExceptionUtil {

    static final String MSG_RES = "MessageResources";
    static final String ID_KEY = "exception.id.";
    static final String MESSAGE_KEY = "exception.message.";
    static final String OPERATION_KEY = "exception.operation.";
    static final String CAUSE_KEY = "exception.cause.";
    static final String ACTION_KEY = "exception.action.";

    public static EIWSExceptionType getException(String msgId,String[] params) {
        EIWSExceptionType eiwsexception = new EIWSExceptionType();
        eiwsexception.setMessage(PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement(MSG_RES, MESSAGE_KEY+msgId), params));
        eiwsexception.setOperation(PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement(MSG_RES, OPERATION_KEY+msgId), params));
        eiwsexception.setCause(PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement(MSG_RES, CAUSE_KEY+msgId), params));
        eiwsexception.setAction(PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement(MSG_RES, ACTION_KEY+msgId), params));
        return eiwsexception;
    }

    public static EIWSExceptionType getException(String msgId) {
        EIWSExceptionType eiwsexception = new EIWSExceptionType();
        eiwsexception.setID(PropertyUtil.getPropertyElement(MSG_RES, ID_KEY+msgId));
        eiwsexception.setMessage(PropertyUtil.getPropertyElement(MSG_RES, MESSAGE_KEY+msgId));
        eiwsexception.setOperation(PropertyUtil.getPropertyElement(MSG_RES, OPERATION_KEY+msgId));
        eiwsexception.setCause(PropertyUtil.getPropertyElement(MSG_RES, CAUSE_KEY+msgId));
        eiwsexception.setAction(PropertyUtil.getPropertyElement(MSG_RES, ACTION_KEY+msgId));
        return eiwsexception;
    }

    public static EIWSExceptionType getException(String msgId, String callStack ) {
        EIWSExceptionType eiwsexception = new EIWSExceptionType();
        eiwsexception.setID(PropertyUtil.getPropertyElement(MSG_RES, ID_KEY+msgId));
        eiwsexception.setMessage(PropertyUtil.getPropertyElement(MSG_RES, MESSAGE_KEY+msgId));
        eiwsexception.setOperation(PropertyUtil.getPropertyElement(MSG_RES, OPERATION_KEY+msgId));
        eiwsexception.setCause(PropertyUtil.getPropertyElement(MSG_RES, CAUSE_KEY+msgId));
        eiwsexception.setAction(PropertyUtil.getPropertyElement(MSG_RES, ACTION_KEY+msgId));
        eiwsexception.setCallStackTrace(callStack);
        return eiwsexception;
    }

    public static EIWSExceptionsType doException(String typeId, String callStack, Map<String, String[]> parameters) {
        String idKey = "pdf.exception.id." + typeId;
        String messageKey = "pdf.exception.message." + typeId;
        String operationKey = "pdf.exception.operation." + typeId;
        String causeKey = "pdf.exception.cause." + typeId;
        String actionKey = "pdf.exception.action." + typeId;

        String[] idParam = parameters.get("id");
        String[] messageParam = parameters.get("message");
        String[] operationParam = parameters.get("operation");
        String[] causeParam = parameters.get("cause");
        String[] actionParam = parameters.get("action");

        String id = PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement("MessageResources", idKey), idParam);
        String message = PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement("MessageResources", messageKey), messageParam);
        String operation = PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement("MessageResources", operationKey), operationParam);
        String cause = PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement("MessageResources", causeKey), causeParam);
        String action = PropertyUtil.doPropertiesParam(PropertyUtil.getPropertyElement("MessageResources", actionKey), actionParam);

        EIWSExceptionsType faultInfos = new EIWSExceptionsType();
        EIWSExceptionType faultInfo = new EIWSExceptionType();
        faultInfo.setID(id);
        faultInfo.setMessage(message);
        faultInfo.setOperation(operation);
        faultInfo.setCause(cause);
        faultInfo.setAction(action);
        if (callStack != null) {
            faultInfo.setCallStackTrace(callStack);
        }

        faultInfos.getEIWSException().add(faultInfo);

        return faultInfos;
    }
}
