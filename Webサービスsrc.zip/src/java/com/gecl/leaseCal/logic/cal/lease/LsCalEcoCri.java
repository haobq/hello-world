/*
 * @(#)LsCalLdnscal.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.Stairs;

/**
 * 低炭リース信用保険料算出Bean。
 * @author  HAOBQ
 * @version 01-01、 2012/02/06
 * @since   01-01
 */
public class LsCalEcoCri {
	private Gcal _gcal; //Gcalbean
	private Stairs _stairs; //回収情報bean
	private CashFl _cashFl; //CashFlbean

	/**
	 * コンストラクタ．     <BR>     *
	 */
	public LsCalEcoCri() {

	}
	/**
	 * オブジェクトをセットする．     <BR>
	 * Gcal・回収情報・CashFlowを渡す。
	 * @param gcal		Gcalオブジェクト
	 * @param stairs	回収情報
	 * @param cashFl	CashFlオブジェクト
	 */
	public void setPara(Gcal gcal, Stairs stairs, CashFl cashFl) {
		_gcal = gcal;
		_stairs = stairs;
		_cashFl = cashFl;
	}
	/**
	 * 低炭リース信用保険料を行う． <BR>
	 *  1.画面で入力のエコリースのフラグ =１　場合のみ計算する
	 *  2.付保期間=検収予定日の翌日から最終支払日の月数
	 *  3.第一回回収金額=検収予定日となる第一月分の回収金額
	 *  4.(契約額－検収予定日となる第一月分の回収金額)/2*低炭信保料率
	 *  5.実行費用に加算する
	 */
	public void doCalculate() {

		double dWSVI; /*第一回回収金額*/
		long lWFST_YY; /*第一回回収予定日の年*/
		long lWFST_MM; /*第一回回収予定日の月*/
		long lWFST_DD; /*第一回回収予定日の日*/
		int nStairsPos;

		//System.out.println("低炭リース 開始");

		/*付保期間算出 */
		if (_gcal.getCriRt()>0){
			//低炭信保料率>0時計算する。
			_gcal.setCriTm(
				(int) ((LfcLogicComm.db3Year(_gcal.getFidtIn())
					- LfcLogicComm.db3Year(_gcal.getDKensh()))
					* 12
					+ LfcLogicComm.db3Month(_gcal.getFidtIn())
					- LfcLogicComm.db3Month(_gcal.getDKensh())
					+1));
			//ADD BY HBQ 20120316 B
//        System.out.println("最終回収日===" + _gcal.getFidtIn());
//        System.out.println("検収日===" + _gcal.getDKensh());
//        System.out.println("調整前付保期間===" + _gcal.getCriTm());
			//検収日の日付>=最終回収日の日付時付時　保期間=付保期間-1
			if (LfcLogicComm.db3Day(_gcal.getDKensh())>=LfcLogicComm.db3Day(_gcal.getFidtIn())){
				//検収日の日付<最終回収日の日付あるいは最終回収日の末日時　付保期間=付保期間
				if (LfcLogicComm.dtLast(LfcLogicComm.db3Year(_gcal.getFidtIn()),LfcLogicComm.db3Month(_gcal.getFidtIn()))!=LfcLogicComm.db3Day(_gcal.getFidtIn())) {
					_gcal.setCriTm(_gcal.getCriTm()-1);
				}
			}
			//ADD BY HBQ 20120316 E
		}else{
			//低炭信保料率=0時計算しない。
			_gcal.setCriTm(0);
		}

		/* 低炭信保料率  小数点３桁(%) 画面から取得する*/
		//_gcal.setCriRt(
		//	LfcLogicComm.dround(0.19 / 12 * _gcal.getCriTm(), 3));

		/*第一回回収金額、回収予定日*/
		dWSVI = 0;
		lWFST_YY = 0;
		lWFST_MM = 0;
		lWFST_DD = 0;
		nStairsPos = _stairs.getTopRow();
		while (nStairsPos < _stairs.getRowCount()) {
			if (_stairs.getAct(nStairsPos) == LfcLogicPgConst.KUBUN_YES) {
				dWSVI = _stairs.getIncome(nStairsPos);
				lWFST_YY = _stairs.getDateYY(nStairsPos);
				lWFST_MM = _stairs.getDateMM(nStairsPos);
				lWFST_DD = _stairs.getDateDD(nStairsPos);
				break;
			}
			nStairsPos = nStairsPos + 1;
		}


		/*低炭信用保険料算出(小数点を切り捨て)*/
		if (LfcLogicComm.db3Year(_gcal.getDKensh()) == lWFST_YY
			&& LfcLogicComm.db3Month(_gcal.getDKensh()) == lWFST_MM
			&& LfcLogicComm.db3Day(_gcal.getDKensh()) == lWFST_DD) {
			//ADD BY HBQ 20120301 B
			//_gcal.setCriTm(_gcal.getCriTm()-1);
			//ADD BY HBQ 20120301 E
		_gcal.setCriF(
				Math.floor(
					(_gcal.getIncGt() - dWSVI) / 2.0 * _gcal.getCriRt() / 12 * _gcal.getCriTm()/100
						+ 0.00001));
		} else {
			_gcal.setCriF(
				Math.floor(_gcal.getIncGt() / 2.0 * _gcal.getCriRt() / 12 * _gcal.getCriTm()/100 + 0.00001));
		}

//		System.out.println("契約額　　    =	" + _gcal.getIncGt());
//		System.out.println("第一回回収金額=	" + dWSVI);
//		System.out.println("低炭信保料率  =	" + _gcal.getCriRt());
//		System.out.println("低炭信用保険料=	" + _gcal.getCriF());
//		System.out.println("付保期間      =	" + _gcal.getCriTm());

		//System.out.println("低炭リース 終了");

	}
}
