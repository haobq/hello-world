/*
 * @(#)LsCalLzancal.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *　　　　
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.Fixrem;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;

public class LsCalLzancal {
    private Gcal _gcal;	//Gcal bean
    private Fixrem _fixrem;	//Fixrem bean

    public LsCalLzancal() {

    }

    public void setPara(Gcal gcal, Fixrem fixrem) {
        _gcal = gcal;
        _fixrem = fixrem;
    }

    public void doCalculate() {
        if(_gcal.getFremIX() == 0 || _gcal.getLeaseM() == 0) {
            _gcal.setRemVRT(0);
            _gcal.setRemVRtFlg(true);
            _gcal.setRemVAL(0);
            _gcal.setRemValFlg(true);
        } else {
             rRateSet();
             _gcal.setRemVRtFlg(false);
             if(_gcal.getPurchas() == 0) {
                _gcal.setRemVAL(0);
                _gcal.setRemValFlg(true);
             } else {
                rValCal();
                _gcal.setRemVRtFlg(false);
                _gcal.setRemValFlg(false);
             }
        }
    }

    private void rRateSet() {
        _gcal.setRemVRT(0);
        if (_gcal.getLeaseM() <= 36) {
            _gcal.setRemVRT(_fixrem.getFremRt(_gcal.getFremIX()));
            return;
        }
        if (_gcal.getLeaseM() <= 48) {
            _gcal.setRemVRT(_fixrem.getFremRt2(_gcal.getFremIX()));
            return;
        }
        if (_gcal.getLeaseM() <= 60) {
            _gcal.setRemVRT(_fixrem.getFremRt3(_gcal.getFremIX()));
            return;
        }
        if (_gcal.getLeaseM() <= 72) {
            _gcal.setRemVRT(_fixrem.getFremRt4(_gcal.getFremIX()));
            return;
        }
        if (_gcal.getLeaseM() <= 84) {
            _gcal.setRemVRT(_fixrem.getFremRt5(_gcal.getFremIX()));
            return;
        }
        if (_gcal.getLeaseM() <= 96) {
            _gcal.setRemVRT(_fixrem.getFremRt6(_gcal.getFremIX()));
            return;
        }
        if (_gcal.getLeaseM() <= 108) {
            _gcal.setRemVRT(_fixrem.getFremRt7(_gcal.getFremIX()));
            return;
        }
    }

    private void rValCal() {
    	//ydy modify 20071229 s
//        _gcal.setRemVAL(Math.floor(Math.floor(_gcal.getPurchas() * _gcal.getRemVRT() / 100 + 0.00001) * 100 + 0.01));
    	_gcal.setRemVAL(Math.floor(Math.floor(LfcFrmComm.dround(_gcal.getPurchas() * _gcal.getRemVRT(),0) / 100 + 0.00001) * 100 + 0.01));
    	//ydy modify 20071229 e
        _gcal.setRemVRT(Math.floor(_gcal.getRemVAL() / _gcal.getPurchas() * 100 + 0.5) / 100);
    }
}

