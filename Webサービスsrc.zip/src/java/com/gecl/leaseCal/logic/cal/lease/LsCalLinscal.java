/*
 * @(#)LsCalLinscal.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *修正者：　　?補千
 *修正日：　　20050425
 *修正内容：　賠償責任保険の物件数量計算方法更新
 *
 */
package com.gecl.leaseCal.logic.cal.lease;



import com.gecl.leaseCal.db.comm.DosoinstBean;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import java.util.ArrayList;
import java.util.Vector;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;

public class LsCalLinscal {

    private Gcal _gcal;
    private Vector _vResult;
    DosoinstBean dosoinstBean = new DosoinstBean();

    public LsCalLinscal() {
    }

    public void setPara(Gcal gcal) {
        _gcal = gcal;
        dosoinstBean.parseXml();
    }

    public ArrayList<ErrorInforOutputComplexType> doCalculate() {
        int nLeaYY;
        int nLeaMM;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        if (_gcal.getDosoRt() == 0) {
            _gcal.setDosoIx(0);
            _gcal.setDosoF(0);
        } else {
            nLeaYY = _gcal.getLeaseM() / 12;
            nLeaMM = _gcal.getLeaseM() % 12;
            if (nLeaMM == 0) {
                double dDosoIxT;
                dDosoIxT = dosoGet(nLeaYY);
                if (dDosoIxT < 0) {
                    //DOSOINSTの年数が取得できません。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR087, "ERR087", errMsglist);
                    return errMsglist;
                }
                _gcal.setDosoIx(dDosoIxT);

                _gcal.setDosoF(LfcLogicComm.dround(((_gcal.getPurchas() - _gcal.getRemVAL()) * _gcal.getDosoIx() + _gcal.getRemVAL() * nLeaYY) * _gcal.getDosoRt() / 1000.0, 0));

            } else {
                double dDosoIxT;
                double dDosoix;
                dDosoIxT = dosoGet(nLeaYY + 1);
                if (dDosoIxT < 0) {
                    //DOSOINSTの年数が取得できません。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR087, "ERR087", errMsglist);
                    return errMsglist;
                }
                dDosoix = dosoIx(nLeaYY + 1);
                _gcal.setDosoIx(dDosoIxT - dDosoix + dDosoix * LfcLogicPgConst.DS_STR[nLeaMM]);
//20040823 ljq add s
                _gcal.setDosoIx(LfcFrmComm.dround(_gcal.getDosoIx(), 7));

//20040823 ljq add e
                _gcal.setDosoF(LfcLogicComm.dround(((_gcal.getPurchas() - _gcal.getRemVAL()) * _gcal.getDosoIx() + _gcal.getRemVAL() * (nLeaYY + LfcLogicPgConst.DS_STR[nLeaMM])) * _gcal.getDosoRt() / 1000.0, 0));
            }
        }

        //賠償責任保険
        if ("1".equals(_gcal.getSwBais())) {
            //hbq 20050425 賠償責任保険の物件数量計算方法更新　begin
            _gcal.setBaisF(2000.0 * ((_gcal.getLeaseM() + 11) / 12) * _gcal.getQuant());
            //hbq 20050425 賠償責任保険の物件数量計算方法更新　end
        } else {
            _gcal.setBaisF(0);
        }
        //保険料合算
        _gcal.setInsur(_gcal.getDosoF() + _gcal.getBaisF() + _gcal.getMachiF() + _gcal.getFireF() + _gcal.getEtcF());
        return null;
    }

    public double dosoGet(int nLeaYY) {
        Vector vResults;

        if (dosoinstBean.getQueryResults() == true) {
            vResults = dosoinstBean.getResults();
        } else {
            return -1;
        }
        if (nLeaYY > 99 || nLeaYY < 0) {
            return -1;
        }

        for (int i = 0; i < vResults.size(); i++) {
            _vResult = (Vector) vResults.elementAt(i);
            if (nLeaYY == Integer.parseInt((String) _vResult.elementAt(0))) {
                Double tmpDouble = new Double((String) _vResult.elementAt(_vResult.size() - 1));
                return tmpDouble.doubleValue();
            }
        }
        return -1;
    }

    public double dosoIx(int nTerm) {
        if (nTerm > 36 || nTerm < 1) {
            return -1;
        }
        Double tmpDouble = new Double((String) _vResult.elementAt(nTerm));
        return tmpDouble.doubleValue();
    }
}
