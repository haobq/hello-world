/*
 * @(#)LsCalLfr1cal.java      01-01  2003/06/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 * 修正日：20070326
 * 修正人：zhangyibo
 * 修正内容：ROIの税率を改定
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import java.util.Date;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Stairs;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.Fixrem;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


/**
 * 回収回数（一段）算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/06/20
 * @since   01-01
 */
public class LsCalLfr1cal {

    /** GcalBean */
    private Gcal _gcal;
    /** 回収情報Bean */
    private Stairs _stairs;
    /** 支払情報Bean */
    private Paydiv _paydiv;
    /** CashFlBean */
    private CashFl _cashFl;
    /**  */
    private Fixrem _fixrem;
    /** PG実行成功かどうかのフラグ */
    private int _nRet;

    /**
     * コンストラクタ．     <BR>
     * Gcal・回収情報・支払情報・CashFlow・Fixremを渡す。
     * @param gcal
     * @param stairs
     * @param paydiv
     * @param cashFl
     * @param fixrem
     */
    public LsCalLfr1cal(Gcal gcal, Stairs stairs, Paydiv paydiv, CashFl cashFl, Fixrem fixrem) {
        _gcal = gcal;
        _stairs = stairs;
        _paydiv = paydiv;
        _cashFl = cashFl;
        _fixrem = fixrem;
    }

    /**
     * 回収回数算出実行成功かどうかのフラグを戻す． <BR>
     * @return  int 0:成功
     *              1:ＴＲが算出不能です。
     *             -1:信保付保区分が正しくない。
     */
    public int getRet() {
        return _nRet;
    }


    /**
     * 回収回数（一段）算出のメソッド．     <BR>
     * @return
     */
    public ArrayList<ErrorInforOutputComplexType> doCalculate() {
        String strWsvCsw;                   //前の信保付保区分
        Date dtStartTime = new Date();        //計算時間
        long lStartTime;                    //開始の時間
        long lEndTime;                      //結束の時間
        long lWreqm;                        //元本調整月数
        int dWo1Num;                     //前回金額
        double dWd1Rt;                      //前回誤差
        int dWo2Num;                     //前々回金額
        double dWd2Rt;                      //前々回誤差
        double dWsvRate;                    //計算前の基準利率
        double dWrCajpy;				    //原価調整額による年荒利率を取得する
        double dWcomp;
        double dWinc;                       //回収回数
        double dWtrM;                       //表面金利
        double dWrndRt;				        //計算後の基準利率
        double dWdif;                       //料率誤差
        int nCalFlag;                       //計算方式
        int nWcycle;                        //回收サイクル
        int nLpCnt;
        int nStairsPos;
        int nEndFlag;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        _nRet = 0;
        //保存前の信保付保区分
        strWsvCsw = _gcal.getSwCri();
        lStartTime = dtStartTime.getTime();

        dWo2Num = 0;
        dWd2Rt = 0;

        //取得回收金額と回收サイクル
        dWinc = _stairs.getIncome(_stairs.getTopRow());
        nWcycle = _stairs.getCycle(_stairs.getTopRow());

        //原価調整額を計算
        LsCalCajcalc Cajcalc = new LsCalCajcalc();
        Cajcalc.setPara(_paydiv, _gcal);
        Cajcalc.doCalculate();

        //初期費用 = その他一時費用(ｲ)+その他一時費用(ﾛ)+その他一時費用(ﾊ)+斡旋手数料
        _gcal.setInitC(_gcal.getIchiji1() + _gcal.getIchiji2() + _gcal.getIchiji3() + _gcal.getAssen());

        nCalFlag = 0;
        dWsvRate = 0.0;
        if (_gcal.getRateUnFlg() == LfcLogicPgConst.KUBUN_NO) {
            //運用利回り指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_RATEUN;
            dWsvRate = _gcal.getRateUN();
        } else if (_gcal.getRateROIFlg() == LfcLogicPgConst.KUBUN_NO) {
            //ＲＯＩ指定の場合
//OJ040057 20040512 ljq change start
//            nCalFlag = LfcLogicPgConst.CAL_BASE_ROI;
//            dWsvRate = _gcal.getRateROI();
            //20070326 modi zyb s
//            _gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateROI() / 0.65, 5));
            _gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateROI() / LfcLogicPgConst.USA_PERSON_TAX, 5));
            //20070326 modi zyb e
            _gcal.setRateUN(_gcal.getRateYr() + _gcal.getRateJL());
            nCalFlag = LfcLogicPgConst.CAL_BASE_RATEUN;
            dWsvRate = _gcal.getRateUN();
//OJ040057 20040512 ljq change end

        } else if (_gcal.getTrueRtFlg() == LfcLogicPgConst.KUBUN_NO) {
            //ＴＲ指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_TRUERT;
            dWsvRate = _gcal.getTrueRT();
        }

        //調整計算前の基準利率
        if (dWsvRate > 0) {
//OJ040057 20040512 ljq change start
//            dWsvRate = Math.floor(dWsvRate * 10000 + 0.5) / 10000;
            dWsvRate = Math.floor(dWsvRate * 10000 + 0.5000001) / 10000;
//OJ040057 20040512 ljq change end
        } else {
            dWsvRate = Math.floor(dWsvRate * 10000 - 0.5) / 10000;
        }
        //原価調整額による年荒利率を取得する
//OJ040057 20040512 ljq change start
//        dWrCajpy = (Math.pow(1 + _gcal.getRateCADJ() * 100 / 12, (double)Math.abs(_gcal.getAdjM()))
//                        * (1 + _gcal.getRateCADJ() * 100 / 365 * Math.abs(_gcal.getAdjD())) - 1)
//                        / (_gcal.getPurchas() / dWinc) * 12;
        dWrCajpy = (Math.pow(1 + _gcal.getRateJL() * 100 / 12, (double) Math.abs(_gcal.getAdjM())) * (1 + _gcal.getRateJL() * 100 / 365 * Math.abs(_gcal.getAdjD())) - 1) / (_gcal.getPurchas() / dWinc) * 12 / 100;
//OJ040057 20040512 ljq change end
        if (_gcal.getAdjM() < 0 || _gcal.getAdjD() < 0) {
            //原価調整月数 < 0又は原価調整日数 < 0 の場合
            dWrCajpy = -1 * dWrCajpy;
        }

        if (nCalFlag == LfcLogicPgConst.CAL_BASE_RATEUN) {
            //運用利回り指定の場合
            //ＴＲ = 運用利回り-調整利率/TRの平元率
            _gcal.setTrueRT(_gcal.getRateUN() - dWrCajpy / LfcLogicPgConst.TR_RATE_HN * 1.0000000000);
        }
        if (nCalFlag == LfcLogicPgConst.CAL_BASE_ROI) {
            //ＲＯＩ指定の場合
            //ＴＲ = ROI/0.59 +  社内金利 - 原価調整額による年荒利率 / TRの平元率
            _gcal.setTrueRT(_gcal.getRateROI() / LfcLogicPgConst.USA_PERSON_TAX + _gcal.getRateJL() - dWrCajpy / LfcLogicPgConst.TR_RATE_HN * 1.0000000000);
        }

        //表面金利を計算する。
        if (nWcycle == 1) {
            //回收サイクルが１の場合
            //表面金利 = ＴＲ/12/100
//            dWtrM = _gcal.getTrueRT() / 12 / 100;
            dWtrM = _gcal.getTrueRT() / 12;
        } else {
            //表面金利 = (TR/100*24)/(24-TR/100*(回收サイクル-1))/12*回收サイクル
//            dWtrM = (_gcal.getTrueRT() / 100 * 24) / (24 - _gcal.getTrueRT() / 100 * (nWcycle - 1)) / 12 * nWcycle;
            dWtrM = (_gcal.getTrueRT() * 24) / (24 - _gcal.getTrueRT() * (nWcycle - 1)) / 12 * nWcycle;
        }

        if (_gcal.getTrueRT() == 0) {
            _gcal.setDivfreq((int) ((_gcal.getPurchas() + _gcal.getInitC() - _gcal.getInc0() - _gcal.getRemVAL()) / dWinc));
        } else {
            dWcomp = Math.abs((_gcal.getRemVAL() * dWtrM - dWinc) / ((_gcal.getPurchas() + _gcal.getInitC() - _gcal.getInc0()) * dWtrM - dWinc));
            if (dWcomp <= 0) {
                dWcomp = 1;
            }
            _gcal.setDivfreq((int) LfcLogicComm.dround(Math.log(Math.abs(dWcomp)) / Math.log(Math.abs(1 + dWtrM)) + 0.001, 0));
        }

        //調整精度
        nLpCnt = 0;
        nEndFlag = 0;
        while (true) {
            Date dtEndTime = new Date();
            lEndTime = dtEndTime.getTime();
            if (lEndTime - lStartTime >= LfcLogicPgConst.MAX_TIME) {
                //"値が収束せず、計算不能です。"
                 errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR068,"ERR068",errMsglist);
                //LfcMessageBox.show(null, LfcLogicMsgConst.ERR068, "メッセージ", JOptionPane.ERROR_MESSAGE);
                _stairs.setFreque(LfcLogicPgConst.INVALID_INCOME, _stairs.getTopRow());
                _gcal.setSwCri(strWsvCsw);
                if (_gcal.getFremIX() != 0) {
                    _gcal.setRemVAL(0);
                    _gcal.setRemValFlg(LfcLogicPgConst.KUBUN_YES);
                    _gcal.setRemVRT(0);
                    _gcal.setRemVRtFlg(LfcLogicPgConst.KUBUN_YES);
                }
                _nRet = 1;
                return errMsglist;
            }
            //調整回収回数
            if (_gcal.getDivfreq() <= 0) {
                _gcal.setDivfreq(1);
            }
            lWreqm = (_stairs.getDateYY(_stairs.getTopRow()) * 12L + _stairs.getDateMM(_stairs.getTopRow())) - (LfcLogicComm.db3Year(_gcal.getDKensh()) * 12L + LfcLogicComm.db3Month(_gcal.getDKensh())) - 1;
            if (lWreqm + 1 + nWcycle * (_gcal.getDivfreq() - 1) > 360) {
                _gcal.setDivfreq((int) ((360 - lWreqm - 1) / nWcycle + 1));
            }
            _stairs.setFreque(_gcal.getDivfreq(), _stairs.getTopRow());

            nStairsPos = _stairs.getTopRow();
            _gcal.setLeaseM((int) Math.floor(_gcal.getInc0M() + 0.999));
            while (nStairsPos < _stairs.getRowCount()) {
                if (_stairs.getAct(nStairsPos) == LfcLogicPgConst.KUBUN_YES) {
                    _gcal.setLeaseM(_gcal.getLeaseM() + _stairs.getCycle(nStairsPos) * _stairs.getFreque(nStairsPos));
                }
                nStairsPos = nStairsPos + 1;
            }

            //定率残価算出
            if (_gcal.getFremIX() != 0) {
                LsCalLzancal Lzancal = new LsCalLzancal();
                Lzancal.setPara(_gcal, _fixrem);
                Lzancal.doCalculate();
            }

            //CASHFLOW設定
            LsCalLmkCash lmkCash = new LsCalLmkCash();
            lmkCash.setPara(_gcal, _stairs, _cashFl);
            lmkCash.doCalculate();
            //LsCalComm.LmkCash.setPara(_gcal, _stairs, _cashFl);
            //LsCalComm.LmkCash.doCalculate();

            //採算項目再計算
            LsCalLproCal lprocal = new LsCalLproCal();
            lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
            lprocal.doCal();
            //LsCalComm.Lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
            //LsCalComm.Lprocal.doCal();
            if (lprocal.getRet() == 1) {
                _stairs.setFreque(LfcLogicPgConst.INVALID_FREQUE, _stairs.getTopRow());
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return null;
            }

            if (nEndFlag == 1) {
                break;
            }

            //今回採算した率算出
            dWrndRt = 0;
            if (nCalFlag == LfcLogicPgConst.CAL_BASE_RATEUN) {
                dWrndRt = _gcal.getRateUN();
            } else if (nCalFlag == LfcLogicPgConst.CAL_BASE_ROI) {
                dWrndRt = _gcal.getRateROI();
            } else if (nCalFlag == LfcLogicPgConst.CAL_BASE_TRUERT) {
                dWrndRt = _gcal.getTrueRT();
            }
            if (dWrndRt > 0) {
                dWrndRt = Math.floor(dWrndRt * 10000 + 0.5) / 10000;
            } else {
                dWrndRt = Math.floor(dWrndRt * 10000 - 0.5) / 10000;
            }

            //今回採算した率と前回率の差算出
            dWdif = dWrndRt - dWsvRate;
            if (Math.floor(Math.abs(dWdif) * 100000000 + 0.0001) == 0) {
                break;
            }

            if (_gcal.getLeaseM() >= 360 && dWdif < 0) {
                //"リース月数が３６０か月を越える為、計算不能です。"
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR073,"ERR073",errMsglist);
                _stairs.setFreque(LfcLogicPgConst.INVALID_FREQUE, _stairs.getTopRow());
                _gcal.setSwCri(strWsvCsw);
                if (_gcal.getFremIX() != 0) {
                    _gcal.setRemVAL(0);
                    _gcal.setRemValFlg(LfcLogicPgConst.KUBUN_YES);
                    _gcal.setRemVRT(0);
                    _gcal.setRemVRtFlg(LfcLogicPgConst.KUBUN_YES);
                }
                _nRet = 1;
                break;
            }

            //数値収束
            dWo1Num = _gcal.getDivfreq();
            dWd1Rt = dWdif;
//OJ040057 20040512 ljq change start
            dWd1Rt = LfcLogicComm.dround(dWd1Rt, 4);
//OJ040057 20040512 ljq change end
            nLpCnt = nLpCnt + 1;
            LsCalLfrqAppr Lfrqappr = new LsCalLfrqAppr();
            Lfrqappr.setPara(nLpCnt, dWo1Num, dWd1Rt, dWo2Num, dWd2Rt, _gcal.getDivfreq());
            Lfrqappr.doCalculate();

            dWo1Num = Lfrqappr.getOld1Num();
            dWd1Rt = Lfrqappr.getDif1Rt();
            dWo2Num = Lfrqappr.getOld2Num();
            dWd2Rt = Lfrqappr.getDif2Rt();
            _gcal.setDivfreq(Lfrqappr.getNewNum());

            if (Lfrqappr.getFqrRcd() == -1) {
                _nRet = -3;
                break;
            } else if (Lfrqappr.getFqrRcd() == -2) {
                _nRet = -3;
                nEndFlag = 1;
            }
        }
//        if ("1".equals(strWsvCsw)) {
//            //前の信保付保区分が"1"の場合、信保付保区分に"1"をセットする
//            _gcal.setSwCri("1");
//            _nRet = _nRet - 1;
//        }
        return errMsglist;
    }
}
