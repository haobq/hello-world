/*
 * @(#)LsCalLrv2cal.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 * 修正日：20070326
 * 修正人：zhangyibo
 * 修正内容：ROIの税率を改定
 */
package com.gecl.leaseCal.logic.cal.lease;

import java.util.Date;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Stairs;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.Fixrem;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


/**
 * 残価算出（複数段）算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/06/20
 * @since   01-01
 */
public class LsCalLrv2cal {
    /** GcalBean */
    private Gcal     _gcal;
    /** 回収情報Bean */
    private Stairs   _stairs;
    /** 支払情報Bean */
    private Paydiv   _paydiv;
    /** CashFlBean */
    private CashFl   _cashFl;
    /** */
    private Fixrem   _fixrem;
    /** PG実行成功かどうかのフラグ */
    private int      _nRet;

    /**
     * コンストラクタ．     <BR>
     * Gcal・回収情報・支払情報・CashFlow・Fixremを渡す。
     * @param gcal
     * @param stairs
     * @param paydiv
     * @param cashFl
     * @param fixrem
     */
    public LsCalLrv2cal(Gcal gcal, Stairs stairs, Paydiv paydiv, CashFl cashFl, Fixrem fixrem) {
        _gcal       = gcal;
        _stairs     = stairs;
        _paydiv     = paydiv;
        _cashFl     = cashFl;
        _fixrem     = fixrem;
    }

    /**
     * 残価算出実行成功かどうかのフラグを戻す． <BR>
     * @return  int 0:成功
     *              1:ＴＲが算出不能です。
     *             -1:信保付保区分が正しくない。
     */
    public int getRet() {
        return _nRet;
    }

    /**
     * 残価算出（複数段）算出のメソッド．     <BR>
     * @return
     */
    public ArrayList<ErrorInforOutputComplexType> doCalculate() {
        String strWsvCsw;                   //前の信保付保区分
        Date dtStartTime = new Date();        //計算時間
        long lStartTime;                    //開始の時間
        long lEndTime;                      //結束の時間
        long lWreqm;                        //元本調整月数
        double dWo1Num;                     //前回金額
        double dWd1Rt;                      //前回誤差
        double dWo2Num;                     //前々回金額
        double dWd2Rt;                      //前々回誤差
        double dWo3Num;                     //今回金額
        double dWd3Rt;                      //今回誤差
        double dWsvRate;                    //計算前の基準利率
        double dWrCajpy;				    //原価調整額による年荒利率
        double dWs;                         //調整回收金総額
        double dWs2;                        //調整元本
        double dWtrM;                       //表面金利
        double dWrndRt;				        //計算後の基準利率
        double dWdif;                       //料率誤差
        int nWrndK;                         //整數部分の長さ
        int nCalFlag;                       //計算方式
        int nWfrequence;                    //回收回数
        int nWcycle;                        //回收サイクル
        int nLpCnt;
        int nWreqmPos;
        int nCashFlPos;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        _nRet = 0;
        //保存前の信保付保区分
        strWsvCsw = _gcal.getSwCri();
        lStartTime = dtStartTime.getTime();

        dWo2Num = 0;
        dWd2Rt = 0;
        dWo3Num = 0;
        dWd3Rt = 0;

        //契約額を計算する。
        _gcal.setIncGt(_gcal.getInc0() + _gcal.getIncT());

        //保険料を計算する。
        LsCalLinscal Linscal = new LsCalLinscal();
        Linscal.setPara(_gcal);
        Linscal.doCalculate();

        //団信生保を計算する。
        LsCalLdnscal Ldnscal = new LsCalLdnscal();
        Ldnscal.setPara(_gcal, _stairs, _cashFl);
        Ldnscal.doCalculate();

        //少額資産区分 = "1"
        if(_gcal.getSwSPro().equals("1")) {
            _gcal.setFatax(0);
        } else {
            LsCalFatcal FatCal = new LsCalFatcal();
            FatCal.setPara(_gcal);
            FatCal.doCalculate();
        }

        		//低炭素リース保険料率==0
		if (_gcal.getCriRt()==0.0){
			//低炭素リース保険料
			 _gcal.setCriF(0.0);
			//低炭素リース付保期間を0に設定
			_gcal.setCriTm(0);
		}else{
			//低炭リース信用保険料を行う
            LsCalEcoCri EcoCri = new LsCalEcoCri();
			EcoCri.setPara(_gcal, _stairs, _cashFl);
			EcoCri.doCalculate();
		}

        //初期費用 = その他一時費用(ｲ)+その他一時費用(ﾛ)+その他一時費用(ﾊ)+斡旋手数料
        _gcal.setInitC(_gcal.getIchiji1() + _gcal.getIchiji2() + _gcal.getIchiji3() + _gcal.getAssen());

        //実行費用総額
        _gcal.setExecC(_gcal.getFatax() + _gcal.getInsur() + _gcal.getKurino1()
                            + _gcal.getKurino2() + _gcal.getHoshury());

        //ＮＥＴ率
        _gcal.setNetRt(1 - _gcal.getExecC() / _gcal.getIncGt() * 1.0000000);

        //原価調整額を計算
        LsCalCajcalc Cajcalc = new LsCalCajcalc();
        Cajcalc.setPara(_paydiv,_gcal);
        Cajcalc.doCalculate();

        nCalFlag = 0;
        dWsvRate = 0.0;
        if(_gcal.getRateUnFlg() == LfcLogicPgConst.KUBUN_NO) {
            //運用利回り指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_RATEUN;
            dWsvRate = _gcal.getRateUN();
        } else if(_gcal.getRateROIFlg() == LfcLogicPgConst.KUBUN_NO) {
            //ROI指定の場合
//OJ040057 20040512 ljq change start
//            nCalFlag = LfcLogicPgConst.CAL_BASE_ROI;
//            dWsvRate = _gcal.getRateROI();
        	//20070326 modi zyb s
//            _gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateROI() / 0.65, 5));
        	_gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateROI() / LfcLogicPgConst.USA_PERSON_TAX, 5));
        	//20070326 modi zyb e
            _gcal.setRateUN(_gcal.getRateYr() + _gcal.getRateJL());
            nCalFlag = LfcLogicPgConst.CAL_BASE_RATEUN;
            dWsvRate = _gcal.getRateUN();
//OJ040057 20040512 ljq change end
        } else if(_gcal.getTrueRtFlg() == LfcLogicPgConst.KUBUN_NO) {
            //ＴＲ指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_TRUERT;
            dWsvRate = _gcal.getTrueRT();
        }

        //調整計算前の基準利率
        if(dWsvRate > 0) {
//OJ040057 20040512 ljq change start
//            dWsvRate = Math.floor(dWsvRate * 10000 + 0.5) / 10000;
            dWsvRate = Math.floor(dWsvRate * 10000 + 0.5000001) / 10000;
//OJ040057 20040512 ljq change end
        } else {
            dWsvRate = Math.floor(dWsvRate * 10000 - 0.5) / 10000;
        }
        //原価調整額による年荒利率を取得する
//OJ040057 20040512 ljq change start
//        dWrCajpy = (Math.pow(1 + _gcal.getRateCADJ() * 100 / 12, (double)Math.abs(_gcal.getAdjM()))
//                        * (1 + _gcal.getRateCADJ() * 100 / 365 * Math.abs(_gcal.getAdjD())) - 1)
//                        / _gcal.getLeaseM() * 12;
        dWrCajpy = (Math.pow(1 + _gcal.getRateJL() * 100 / 12, (double)Math.abs(_gcal.getAdjM()))
                        * (1 + _gcal.getRateJL() * 100 / 365 * Math.abs(_gcal.getAdjD())) - 1)
                        / _gcal.getLeaseM() * 12 / 100;
//OJ040057 20040512 ljq change start
        if(_gcal.getAdjM() < 0 || _gcal.getAdjD() < 0) {
            //原価調整月数 < 0又は原価調整日数 < 0 の場合
            dWrCajpy = -1 * dWrCajpy;
        }

        if(nCalFlag == LfcLogicPgConst.CAL_BASE_RATEUN) {
            //運用利回り又は年利回り指定の場合
            //ＴＲ = 運用利回り-原価調整額による年荒利率/TRの平元率
            _gcal.setTrueRT(_gcal.getRateUN() - dWrCajpy / LfcLogicPgConst.TR_RATE_HN * 1.0000000000);
        }
        if(nCalFlag == LfcLogicPgConst.CAL_BASE_ROI) {
            //ＲＯＩ指定の場合
            //ＴＲ = ROI/0.59 +  社内金利 - 原価調整額による年荒利率 / TRの平元率
            _gcal.setTrueRT(_gcal.getRateROI() / LfcLogicPgConst.USA_PERSON_TAX
                    + _gcal.getRateJL() - dWrCajpy / LfcLogicPgConst.TR_RATE_HN * 1.0000000000);
        }

        //表面金利を計算する。
//        dWtrM = _gcal.getTrueRT() / 12 / 100;
        dWtrM = _gcal.getTrueRT() / 12;

        //元本調整月數を計算する。
        lWreqm = _gcal.getLeaseM() + 1;

        //調整元本を計算する。
        nCashFlPos = 0;
        dWs2 = (_gcal.getPurchas() + _gcal.getInitC() - _cashFl.getIncome(nCashFlPos))
                    * Math.pow(1 + dWtrM, (double)lWreqm);
        dWs = 0;
        nWreqmPos = 0;
        nCashFlPos = 1;
        while(nCashFlPos < _cashFl.getCashCnt()) {
            nWreqmPos = nWreqmPos + 1;
            dWs = dWs + _cashFl.getIncome(nCashFlPos) * _gcal.getNetRt()
                    * Math.pow(1 + dWtrM, (double)(lWreqm - nWreqmPos));
            nCashFlPos = nCashFlPos + 1;
        }
        _gcal.setRemVAL(dWs2 - dWs);
        //残価の整數部分の長さを取得する
        nWrndK = (int)Math.floor(Math.log(Math.abs(_gcal.getRemVAL()) + 0.1) / Math.log(10.0) + 0.001) + 1;
        if(nWrndK > 5) {
            nWrndK = 3 - nWrndK;
        } else {
            nWrndK = 1 - nWrndK;
        }
        //調整残価
        _gcal.setRemVAL(LfcLogicComm.dround(_gcal.getRemVAL(),nWrndK));

        //調整精度
        nLpCnt = 0;
        while(true) {
            Date dtEndTime = new Date();
            lEndTime = dtEndTime.getTime();
            if(lEndTime - lStartTime >= LfcLogicPgConst.MAX_TIME) {
                //"値が収束せず、計算不能です。"
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR068,"ERR068",errMsglist);
                _gcal.setRemVAL(0);
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return errMsglist;
            }
            //調整残価
            if(_gcal.getRemVAL() < 0) {
                _gcal.setRemVAL(0);
            }
            if(_gcal.getRemVAL() >= 1e11) {
                _gcal.setRemVAL(1e11 - 1);
            }

            //採算項目再計算
            LsCalLproCal lprocal = new LsCalLproCal();
            lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
            lprocal.doCal();
            //LsCalComm.Lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
            //LsCalComm.Lprocal.doCal();
            if(lprocal.getRet() == 1) {
                _gcal.setRemVAL(0);
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return null;
            }

            //今回採算した率算出
            dWrndRt = 0;
            if(nCalFlag == LfcLogicPgConst.CAL_BASE_RATEUN) {
                dWrndRt = _gcal.getRateUN();
            } else if(nCalFlag == LfcLogicPgConst.CAL_BASE_ROI) {
                dWrndRt = _gcal.getRateROI();
            } else if(nCalFlag == LfcLogicPgConst.CAL_BASE_TRUERT) {
                dWrndRt = _gcal.getTrueRT();
            }
            if(dWrndRt > 0) {
                dWrndRt = Math.floor(dWrndRt * 10000 + 0.5) / 10000;
            } else {
                dWrndRt = Math.floor(dWrndRt * 10000 - 0.5) / 10000;
            }

            //今回採算した率と前回率の差算出
            dWdif = dWrndRt - dWsvRate;
            if(Math.floor(Math.abs(dWdif) * 100000000 + 0.0001) == 0) {
                break;
            }
            if(_gcal.getRemVAL() <= 0 && dWdif > 0) {
                //"残価がマイナス値になる為、計算不能です。"
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR074,"ERR074",errMsglist);

                _gcal.setRemVAL(0);
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return errMsglist;
            }
            if(_gcal.getRemVAL() >= 1e11 - 1 && dWdif < 0) {
                //"残価が大きくなりすぎる為、計算不能です。"
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR075,"ERR075",errMsglist);
                _gcal.setRemVAL(0);
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return errMsglist;
            }

            //数値収束
            dWo1Num = _gcal.getRemVAL();
            dWd1Rt = dWdif;
//OJ040057 20040512 ljq change start
            dWd1Rt = LfcLogicComm.dround(dWd1Rt, 4);
//OJ040057 20040512 ljq change end
            nLpCnt = nLpCnt + 1;
            LsCalLnumAppr numAppr = new LsCalLnumAppr();
            numAppr.setPara(nLpCnt, dWo1Num, dWd1Rt, dWo2Num, dWd2Rt, dWo3Num, dWd3Rt, _gcal.getRemVAL());
            numAppr.doCalculate();
            dWo1Num = numAppr.getOld1Num();
            dWd1Rt = numAppr.getDif1Rt();
            dWo2Num = numAppr.getOld2Num();
            dWd2Rt = numAppr.getDif2Rt();
            dWo3Num = numAppr.getOld3Num();
            dWd3Rt = numAppr.getDif3Rt();
            _gcal.setRemVAL(numAppr.getNewNum());
            if(numAppr.getNAPRCD() == -1) {
                _nRet = -3;
                break;
            }
        }
//zq add 20120306 s
//      if("1".equals(strWsvCsw)) {
//          //前の信保付保区分が"1"の場合、信保付保区分に"1"をセットする
//          _gcal.setSwCri("1");
//          _nRet = _nRet - 1;
//      }
//zq add 20120306 e  
        return null;
    }
}
