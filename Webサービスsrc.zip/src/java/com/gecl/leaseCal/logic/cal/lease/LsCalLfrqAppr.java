/*
 * @(#)LsCalLfrqAppr.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.LfcLogicComm;

public class LsCalLfrqAppr {

    /** 収束計算回数 */
    private int    _nLpCnt;
    /** 前回回数 */
    private int    _nOld1Num;
    /** 前回誤差 */
    private double _dDif1Rt;
    /** 今回回数 */
    private int    _nOld2Num;
    /** 今回誤差 */
    private double _dDif2Rt;
    /** 収束後回数 */
    private int    _nNewNum;
    /** PG実行成功かどうかのフラグ */
    private int    _nFqrRcd;

    public int getOld1Num(){
        return _nOld1Num;
    }

    public double getDif1Rt(){
        return _dDif1Rt;
    }

    public int getOld2Num(){
        return _nOld2Num;
    }

    public double getDif2Rt(){
        return _dDif2Rt;
    }

    public int getNewNum(){
        return _nNewNum;
    }

    public double getFqrRcd(){
        return _nFqrRcd;
    }

    public LsCalLfrqAppr() {
    }

    public void setPara(int nLpCnt,int nOld1Num,double dDif1Rt,
           int nOld2Num,double dDif2Rt, int nNewNum) {

        _nLpCnt   = nLpCnt;
        _nOld1Num = nOld1Num;
        _dDif1Rt  = dDif1Rt;
        _nOld2Num = nOld2Num;
        _dDif2Rt  = dDif2Rt;
        _nNewNum  = nNewNum;
    }

    public void doCalculate() {
	    int    nWdifNum;
	    double dWdifRt;

        _nFqrRcd=0;

        //前回の回収回数が１回で、指定された採算項目との誤差が０より大きい場合
        if (_nOld1Num == 1){
            if (_dDif1Rt > 0){
                //求める回収回数を１回として、指定された採算項目を調整する。
                _nFqrRcd = -1;
                return;
            }
        }

        //前回の回収回数と前々回の回収回数との差が１回で、
        //片方の誤差が０より小さく、もう一方の誤差が０より大きい場合
        if (Math.abs(_nOld1Num-_nOld2Num) == 1){
            if (_dDif1Rt > 0 && _dDif2Rt < 0 ){
                //２つの回収回数のうち、大きい方を求める回収回数として、
                //指定された採算項目を調整する
                _nNewNum = _nOld1Num;
                _nFqrRcd = -1;
                return;
            }

            if (_dDif1Rt < 0 && _dDif2Rt > 0 ){
                _nNewNum = _nOld2Num;
                _nFqrRcd = -2;
                return;
            }
        }

        //前記１、２以外の場合、回収回数の近似値を求める
        //ア．１回目の近似値の場合
        if (_nLpCnt == 1){
            //今回の近似値＝前回の近似値[暫定値]×（１－前回の誤差÷１００）（小数第１位を四捨五入）
            _nNewNum = (int)LfcLogicComm.dround(_nOld1Num*(1 - _dDif1Rt / 100), 0);

        //イ．２回目以降の近似値の場合
        }else{
            //前々回の近似値－前回の近似値
            nWdifNum =_nOld2Num- _nOld1Num;
            //前々回の誤差－前回の誤差
            dWdifRt = _dDif2Rt - _dDif1Rt;
            if (dWdifRt == 0){
                dWdifRt = 0.001;
            }
            //今回の近似値（小数第１位を四捨五入）
            _nNewNum = (int)LfcLogicComm.dround(_nOld1Num - Math.abs(nWdifNum / dWdifRt) * _dDif1Rt,0);
        }

        //ウ．前記ア、イで求めた今回の近似値が、前回の近似値と等しい場合
        if (_nNewNum == _nOld1Num){
            //前回の誤差が０より小さいとき
            if (_dDif1Rt < 0){
                //今回の近似値＝前回の近似値＋１
                _nNewNum = _nNewNum + 1;
            //前回の誤差が０より大きいとき
            }else{
                //今回の近似値＝前回の近似値－１
                _nNewNum = _nNewNum - 1;
            }
        }

        //前回迄の近似値・誤差の保存
        //過去２回までの近似値・誤差を順次シフトして保存する
        _nOld2Num = _nOld1Num;
        _dDif2Rt = _dDif1Rt;
        _nOld1Num = _nNewNum;
        return;
    }
}
