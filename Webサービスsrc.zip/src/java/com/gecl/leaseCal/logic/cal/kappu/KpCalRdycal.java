/*
 * @(#)KpCalRdycal.java      01-01  2003/06/13
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 *修正日：20050513
 *修正人：潘正寛
 *修正内容：ROEで逆算をする
 */
package com.gecl.leaseCal.logic.cal.kappu;


import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.Fixrem;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.Stairs;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


/**
 * リース料（一段）算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/06/13
 * @since   01-01
 */
public class KpCalRdycal {

    /** GcalBean */
    private Gcal _gcal;
    /** 回収情報Bean */
    private Stairs _stairs;
    /** 支払情報Bean */
    private Paydiv _paydiv;
    /** CashFlBean */
    private CashFl _cashFl;
    /** PG実行成功かどうかのフラグ */
    private Fixrem _fixrem;
    /** PG実行成功かどうかのフラグ */
    private int _nRet;
    private int _nWrng;

    /**
     * コンストラクタ．     <BR>
     * Gcal・回収情報・支払情報・CashFlowを渡す。
     * @param gcal
     * @param stairs
     * @param paydiv
     * @param cashFl
     * @param fixrem
     */
    public KpCalRdycal(Gcal gcal, Stairs stairs, Paydiv paydiv, CashFl cashFl, Fixrem fixrem) {
        _gcal = gcal;
        _stairs = stairs;
        _paydiv = paydiv;
        _cashFl = cashFl;
        _fixrem = fixrem;
    }

    /**
     * 採算実行成功かどうかのフラグを戻す． <BR>
     * @return  int 0:成功
     *              1:ＴＲが算出不能です。
     *             -1:信保付保区分が正しくない。
     */
    public int getRet() {
        return _nRet;
    }

    public int getWrng() {
        return _nWrng;
    }

    /**
     * リース料（一段）算出のメソッド．     <BR>
     */
    public ArrayList<ErrorInforOutputComplexType> doCalculate(int nCalItem,int nBaseProf) {
        int nIncomeCount;
        int nFrequeCount;
        int nWcnt;
        int nWsvFrq;
        int nWlTerm;
        int nLastValidStairs;
        double dSRyortT;
        double dSRyortM;
        double dSRateUn;
        double dSRateROI;
        double dSTrueRt;
        double dWsvinc;
        double dRemVal;
        double dRemVRt;
        double dInterP;
        double dInterI;
        double dChanrge;
        double dExecC;
        double dKurino1;
        double dInsur;
        double dDosoF;
        double dCostT;
        double dProfT;
        double dProfY;
        double dCharge;
        double dCapitT;
        double dNetRt;
        double dTrueRt;
        double dRateROI;
        double dRateUn;
        double dRateYr;
        double dRyortT;
        double dRyortM;
        double dFinanceMargin;
        double dPvFinanceMargin;
        double dRaMargin;
        double dRaPvMargin;
        double dDamFa;
        double dDamLa;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        KpCalProcalc Procalc = new KpCalProcalc();
//      pzk add 20050512 start
        //算出項目指定の選択項目
        int intCalItem;
        //逆算時基準項目の選択項目
        int intBaseProf;
        intCalItem = nCalItem;
        intBaseProf = nBaseProf;
        //intCalItem = KpCalComm.getReqItem();
        //intBaseProf = KpCalComm.getBaseItem();
//      pzk add 20050512 end

        if (_gcal.getSwPay() == LfcLogicPgConst.KUBUN_YES) {
            for (int i = 0; i < LfcLogicPgConst.PAYDIV_MAX_COUNT; i++) {
                if (_paydiv.getPurchas(i) <= 0 && _paydiv.getDateYY(i) <= 0 && _paydiv.getDateMM(i) <= 0 && _paydiv.getDateDD(i) <= 0) {
                    _paydiv.setAct(LfcLogicPgConst.KUBUN_NO, i);
                } else {
                    _paydiv.setAct(LfcLogicPgConst.KUBUN_YES, i);
                }
            }
        }

        for (int i = 0; i < LfcLogicPgConst.STAIRS_MAX_COUNT; i++) {
            if (_stairs.getIncome(i) <= 0 && _stairs.getFreque(i) <= 0 && _stairs.getDateYY(i) <= 0 && _stairs.getDateMM(i) <= 0 && _stairs.getDateDD(i) <= 0 && _stairs.getCycle(i) <= 0) {
                _stairs.setAct(LfcLogicPgConst.KUBUN_NO, i);
            } else {
                _stairs.setAct(LfcLogicPgConst.KUBUN_YES, i);
            }
        }

        nIncomeCount = 0;
        nFrequeCount = 0;
        KpCalErrorCheck ErrCheck = new KpCalErrorCheck();
        ErrCheck.setPara(_gcal, _stairs, _paydiv);
        ArrayList<ErrorInforOutputComplexType> errMsglistTmp=ErrCheck.doErrorCheck(nCalItem,nBaseProf);
        if (!errMsglistTmp.isEmpty()) {
            errMsglist=errMsglistTmp;
            //KpCalComm.setResultDisplayFlag(false);
            return errMsglist;
        }
        nIncomeCount = ErrCheck.getIncomeCount();
        nFrequeCount = ErrCheck.getFrequeCount();

        if (intCalItem == LfcLogicPgConst.KAP_ITEM_KINGAKU && nIncomeCount == 0) {
            _stairs.setIncome(0.0, _stairs.getLastRow());
            nIncomeCount = 1;
        }
        if (intCalItem == LfcLogicPgConst.KAP_ITEM_KAISU && nFrequeCount == 0) {
            _stairs.setFreque(0, _stairs.getLastRow());
            nFrequeCount = 1;
        }
        if (intCalItem == LfcLogicPgConst.KAP_ITEM_KINGAKU_INC0 && nIncomeCount == 0) {
            _stairs.setIncome(0.0, _stairs.getTopRow());
            nIncomeCount = 1;
        }

        dSRyortT = _gcal.getRyortT();
        dSRyortM = _gcal.getRyortM();
        dSRateUn = _gcal.getRateUN();
//      pzk modi 20050513 start
//        dSRateROI = _gcal.getRateROI();
        if ((intCalItem != LfcLogicPgConst.KAP_ITEM_LPRO) && (intBaseProf == LfcLogicPgConst.CAL_BASE_ROE)) {
            //ROEからROI算出　ROI＝ROE/（LeverageRatio+１）　少数点３桁で四捨五入　少数点２桁で計算する
            dSRateROI = LfcLogicComm.dround(_gcal.getROE() / (_gcal.getLeverage() + 1), 4);
            _gcal.setRateROI(dSRateROI);
        } else {
            dSRateROI = _gcal.getRateROI();
        }
        //      pzk modi 20050513 end
        dSTrueRt = _gcal.getTrueRT();
        KpCalMkcash KpMkcash = new KpCalMkcash();
        KpMkcash.setPara(_gcal, _stairs, _cashFl);
        KpMkcash.doCalculate();
        if (_gcal.getLeaseD() == 1) {
            int i;
            for (i = 0; i < LfcLogicPgConst.STAIRS_MAX_COUNT; i++) {
                if (_stairs.getAct(i)) {
                    break;
                }
            }
            if (_stairs.getIncome(i) <= 0) {
                if (_gcal.getKappuM() == 1) {
                    //PUTERR("割賦月数が１ｶ月の時は、採算の計算のみ可能です。");
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR109, "ERR109", errMsglist);
                    return errMsglist;
                }
                KpCalIn1Calc In1cal = new KpCalIn1Calc(_gcal, _stairs, _paydiv, _cashFl);
                In1cal.doCalculate();
                _nRet = In1cal.getRet();
            } else if (_gcal.getInc0Flg()) {
                if (_gcal.getKappuM() == 1) {
                    //PUTERR("割賦月数が１ｶ月の時は、採算の計算のみ可能です。");
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR109, "ERR109", errMsglist);
                    return errMsglist;
                }
                KpCalI01Calc I01calc = new KpCalI01Calc(_gcal, _stairs, _paydiv, _cashFl);
                I01calc.doCalculate();
                _nRet = I01calc.getRet();
            } else if (_stairs.getFreque(i) <= 0) {
                KpCalFr1Calc Fr1calc = new KpCalFr1Calc(_gcal, _stairs, _paydiv, _cashFl);
                Fr1calc.doCalculate();
                _nRet = Fr1calc.getRet();
            } else if (_gcal.getPurchasFlg() == LfcLogicPgConst.KUBUN_YES) {
                if (_gcal.getKappuM() == 1) {
                    //PUTERR("割賦月数が１ｶ月の時は、採算の計算のみ可能です。");
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR109, "ERR109", errMsglist);
                    return errMsglist;
                }
                KpCalPu1Calc Pu1calc = new KpCalPu1Calc(_gcal, _stairs, _paydiv, _cashFl);
                Pu1calc.doCalculate();
                _nRet = Pu1calc.getRet();
            } else {
                Procalc.setPara(_gcal, _stairs, _cashFl, _paydiv);
                Procalc.doCal();
                _nRet = Procalc.getRet();
            }
        } else {
            if (nIncomeCount != 0) {
                KpCalIn2Calc In2calc = new KpCalIn2Calc(_gcal, _stairs, _paydiv, _cashFl);
                In2calc.doCalculate();
                _nRet = In2calc.getRet();
            } else if (_gcal.getInc0Flg()) {
                KpCalI02Calc I02Calc = new KpCalI02Calc(_gcal, _stairs, _paydiv, _cashFl);
                I02Calc.doCalculate();
                _nRet = I02Calc.getRet();
            } else if (nFrequeCount != 0) {
                KpCalFr2Calc Fr2calc = new KpCalFr2Calc(_gcal, _stairs, _paydiv, _cashFl);
                Fr2calc.doCalculate();
                _nRet = Fr2calc.getRet();
            } else if (_gcal.getPurchasFlg() == LfcLogicPgConst.KUBUN_YES) {
                KpCalPu2Calc Pu2calc = new KpCalPu2Calc(_gcal, _stairs, _paydiv, _cashFl);
                Pu2calc.doCalculate();
                _nRet = Pu2calc.getRet();
            } else {
                Procalc.setPara(_gcal, _stairs, _cashFl, _paydiv);
                Procalc.doCal();
                _nRet = Procalc.getRet();
            }
        }
//20040530 ljq delete start
//        _gcal.setIncT(_gcal.getIncGt() - _gcal.getHoshury());
//20040530 ljq delete end

        if (_gcal.getIncGt() / _gcal.getPurchas() < 0.001) {
            //購入価額に対して回収金額が少な過ぎます。
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR078, "ERR078", errMsglist);
            _nRet = 1;
        }
        if (_nRet > 0) {
            _gcal.setRyortT(dSRyortT);
            _gcal.setRyortM(dSRyortM);
            _gcal.setRateUN(dSRateUn);
            _gcal.setRateROI(dSRateROI);
            _gcal.setTrueRT(dSTrueRt);
            //KpCalComm.setResultDisplayFlag(false);
            return errMsglist;
        } else if (_nRet < 0) {
            _nWrng = Math.abs(_nRet);
        }

        _gcal.setPurchasFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setInc0Flg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setRyortTFlg(LfcLogicPgConst.KUBUN_NO);
        if (_gcal.getEvenFlg() == 1) {
            _gcal.setRyortMFlg(LfcLogicPgConst.KUBUN_NO);
        } else {
            _gcal.setRyortMFlg(LfcLogicPgConst.KUBUN_YES);
        }
        _gcal.setRateUnFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setRateROIFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setTrueRtFlg(LfcLogicPgConst.KUBUN_NO);

        AdjProfRate();

        _nRet = 0;
        if (_nWrng == 1) {
            //割賦信用保険の適用を取りやめました。
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN009, "WRN009", errMsglist);
        } else if (_nWrng == 2) {
            //割賦信用保険を適用しました。
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN010, "WRN010", errMsglist);
        } else if (_nWrng == 3) {
            //指定された採算項目を調整しました。
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN003, "WRN003", errMsglist);
        } else if (_nWrng == 4) {
            //割賦信用保険の適用を取りやめ、指定された採算項目を調整しました。
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN011, "WRN011", errMsglist);
        } else if (_nWrng == 5) {
            //割賦信用保険を適用し、指定された採算項目を調整しました。
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN012, "WRN012", errMsglist);
        }
        return errMsglist;
    }

    /*================================= */
    /*        採算項目（率）調整        */
    /*================================= */
    private ArrayList<ErrorInforOutputComplexType> AdjProfRate() {
        //display message or not
        boolean bDisplayMsg = false;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        _gcal.setRyortT(LfcLogicComm.dround(_gcal.getRyortT(), 5));
        if (_gcal.getRyortT() > 9.99999) {
            _gcal.setRyortT(9.99999);
        }
        if (_gcal.getRyortT() < -9.99999) {
            _gcal.setRyortT(-9.99999);
        }
        _gcal.setRyortM(LfcLogicComm.dround(_gcal.getRyortM(), 5));
        if (_gcal.getRyortM() > 9.99999) {
            _gcal.setRyortM(9.99999);
        }
        if (_gcal.getRyortM() < -9.99999) {
            _gcal.setRyortM(-9.99999);
        }
        _gcal.setRateUN(LfcLogicComm.dround(_gcal.getRateUN(), 4));
        if (_gcal.getRateUN() > 0.9999) {
            _gcal.setRateUN(0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRateUN() < -0.9999) {
            _gcal.setRateUN(-0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRateYr() == 0.9999 || _gcal.getRateYr() <= 0) {
            _gcal.setRateROI(_gcal.getRateYr());
        } else {
//			20040810 ljq change s
//			_gcal.setRateROI(LfcLogicComm.dround(_gcal.getRateYr() * LfcLogicPgConst.USA_PERSON_TAX, 4));
            _gcal.setRateROI(LfcLogicComm.dround(LfcLogicComm.dround(_gcal.getProfT() / _gcal.getCapitT(), 5) * LfcLogicPgConst.USA_PERSON_TAX, 4));
//			20040810 ljq change e
        }
        if (_gcal.getRateROI() > 0.9999) {
            _gcal.setRateROI(0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRateROI() < -0.9999) {
            _gcal.setRateROI(-0.9999);
            bDisplayMsg = true;
        }
//		20040830 ljq add s
        if (_gcal.getRateROI() == 0) {
            _gcal.setROE(0.0);
        } else if (_gcal.getRateROI() >= 0.9999) {
            _gcal.setROE(0.9999);
        } else if (_gcal.getRateROI() <= -0.9999) {
            _gcal.setROE(-0.9999);
        } else {
            _gcal.setROE(LfcLogicComm.dround((_gcal.getLeverage() + 1) * _gcal.getRateROI(), 4));
        }
//      pzk   modi 20050513 start
        if (_gcal.getROE() >= 10) {
            _gcal.setROE(9.9999);
        }
        if (_gcal.getROE() <= -10) {
            _gcal.setROE(-9.9999);
        }
//		if(_gcal.getROE() <= -99.9999) {
//			_gcal.setROE(-99.9999);
//		}
//		if(_gcal.getROE() >= 99.9999) {
//			_gcal.setROE(99.9999);
//		}
//      pzk   modi 20050513 end

//		20040830 ljq add e
        _gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateYr(), 4));
        if (_gcal.getRateYr() > 0.9999) {
            _gcal.setRateYr(0.9999);
        }
        if (_gcal.getRateYr() < -0.9999) {
            _gcal.setRateYr(-0.9999);
        }
        _gcal.setRtPrT(LfcLogicComm.dround(_gcal.getRtPrT(), 4));
        if (_gcal.getRtPrT() > 0.9999) {
            _gcal.setRtPrT(0.9999);
        }
        if (_gcal.getRtPrT() < -0.9999) {
            _gcal.setRtPrT(-0.9999);
        }
        _gcal.setRtPrY(LfcLogicComm.dround(_gcal.getRtPrY(), 4));
        if (_gcal.getRtPrY() > 0.9999) {
            _gcal.setRtPrY(0.9999);
        }
        if (_gcal.getRtPrY() < -0.9999) {
            _gcal.setRtPrY(-0.9999);
        }
        _gcal.setTrueRT(LfcLogicComm.dround(_gcal.getTrueRT(), 4));
        if (_gcal.getTrueRT() > 0.9999) {
            _gcal.setTrueRT(0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getTrueRT() < -0.9999) {
            _gcal.setTrueRT(-0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRaMargin() > 0.9999) {
            _gcal.setRaMargin(0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRaMargin() < -0.9999) {
            _gcal.setRaMargin(-0.9999);
            bDisplayMsg = true;
        }

        if (_gcal.getFinanceMargin() > 0.9999) {
            _gcal.setFinanceMargin(0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getFinanceMargin() < -0.9999) {
            _gcal.setFinanceMargin(-0.9999);
            bDisplayMsg = true;
        }
        if (bDisplayMsg == true) {
            //"前受リース料／頭金が大きいため採算項目は99.99で表示します。\nその他の計算は正しく行われました。問題がなければ登録して下さい。";
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR120, "ERR120", errMsglist);
        }

        return errMsglist;
    }
}
