/*
 * @(#)KpCalIn1Calc.java      01-01  2003/06/13
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 * 修正日：20070326
 * 修正人：zhangyibo
 * 修正内容：ROIの税率を改定
 */
package com.gecl.leaseCal.logic.cal.kappu;

import java.util.Date;
import com.gecl.leaseCal.log.LfcMessageBox;
import com.gecl.leaseCal.logic.cal.lease.LsCalCajcalc;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Stairs;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.cal.lease.LsCalLnumAppr;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;

/**
 * 割賦金額（一段）算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/06/13
 * @since   01-01
 */
public class KpCalIn1Calc {

    /** GcalBean */
    private Gcal _gcal;
    /** 回収情報Bean */
    private Stairs _stairs;
    /** 支払情報Bean */
    private Paydiv _paydiv;
    /** CashFlBean */
    private CashFl _cashFl;
    /** PG実行成功かどうかのフラグ */
    private int _nRet;

    /**
     * コンストラクタ．     <BR>
     * Gcal・回収情報・支払情報・CashFlowを渡す。
     * @param gcal
     * @param stairs
     * @param paydiv
     * @param cashFl
     */
    public KpCalIn1Calc(
            Gcal gcal,
            Stairs stairs,
            Paydiv paydiv,
            CashFl cashFl) {
        _gcal = gcal;
        _stairs = stairs;
        _paydiv = paydiv;
        _cashFl = cashFl;
    }

    /**
     * 割賦金額（一段）成功かどうかのフラグを戻す． <BR>
     * @return  int 0:成功
     *              1:ＴＲが算出不能です。
     *             -1:信保付保区分が正しくない。
     */
    public int getRet() {
        return _nRet;
    }

    /**
     * 割賦金額（一段）算出のメソッド．     <BR>
     * @return
     */
    public ArrayList<ErrorInforOutputComplexType> doCalculate() {
        String strWsvCsw; //前の信保付保区分
        Date dtStartTime = new Date(); //開始の時間

        long lStartTime; //開始時間の値
        long lEndTime; //結束時間の値
        double dWo1Num; //前回金額
        double dWd1Rt; //前回誤差
        double dWo2Num; //前々回金額
        double dWd2Rt; //前々回誤差
        double dWo3Num; //今回金額
        double dWd3Rt; //今回誤差
        double dWsvRate; //計算前の基準利率
        double dWinc; //割賦金額
        double dWtrM; //表面金利
        double dWrndRt; //計算後の基準利率
        double dWdif; //料率誤差
        double dWcalc;
        int nWrndK; //割賦金額の整數部分の長さ
        int nCalFlag; //計算方式
        int nWfrequence; //回收回数
        int nWcycle; //回收サイクル
        int nLpCnt;
        int dWi0_Flg;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        _nRet = 0;
        //保存前の信保付保区分
        strWsvCsw = _gcal.getSwCri();
        lStartTime = dtStartTime.getTime();

        dWo2Num = 0;
        dWd2Rt = 0;
        dWo3Num = 0;
        dWd3Rt = 0;

        //原価調整額を計算
        LsCalCajcalc Cajcalc = new LsCalCajcalc();
        Cajcalc.setPara(_paydiv, _gcal);
        Cajcalc.doCalculate();
        //保険料
        KpCalInscalc KpInscalc = new KpCalInscalc();
        KpInscalc.setPara(_gcal);
        KpInscalc.doCalculate();

        //初期費用 = その他一時費用(ｲ)+その他一時費用(ﾛ)+その他一時費用(ﾊ)+斡旋手数料
        _gcal.setInitC(
                _gcal.getIchiji1() + _gcal.getIchiji2() + _gcal.getIchiji3() + _gcal.getAssen());
        //  実行費用総額
        _gcal.setExecC(
                _gcal.getInsur() + _gcal.getKappuI() + _gcal.getKurino1() + _gcal.getKurino2() + _gcal.getHoshury());

        nCalFlag = 0;
        dWsvRate = 0.0;
        if (_gcal.getRyortTFlg() == LfcLogicPgConst.KUBUN_NO) {
            //合計料率指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_RYORTT;
            dWsvRate = _gcal.getRyortT();
        } else if (_gcal.getRyortMFlg() == LfcLogicPgConst.KUBUN_NO) {
            //月料率指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_RYORTM;
            dWsvRate = _gcal.getRyortM();
        } else if (_gcal.getRateUnFlg() == LfcLogicPgConst.KUBUN_NO) {
            //運用利回り指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_RATEUN;
            dWsvRate = _gcal.getRateUN();
        } else if (_gcal.getRateROIFlg() == LfcLogicPgConst.KUBUN_NO) {
            //ROI指定の場合
//OJ040057 20040513 ljq change start
//			nCalFlag = LfcLogicPgConst.CAL_BASE_ROI;
//			dWsvRate = _gcal.getRateROI();
            //20070326 modi zyb s
//            _gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateROI() / 0.65, 4));
            _gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateROI() / LfcLogicPgConst.USA_PERSON_TAX, 4));
            //20070326 modi zyb e
            _gcal.setRateUN(_gcal.getRateYr() + _gcal.getRateJL());
            nCalFlag = LfcLogicPgConst.CAL_BASE_RATEUN;
            dWsvRate = _gcal.getRateUN();
//OJ040057 20040513 ljq change end
        } else if (_gcal.getTrueRtFlg() == LfcLogicPgConst.KUBUN_NO) {
            //ＴＲ指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_TRUERT;
            dWsvRate = _gcal.getTrueRT();
        }

        //調整計算前の基準利率
        if (nCalFlag == LfcLogicPgConst.CAL_BASE_RYORTT || nCalFlag == LfcLogicPgConst.CAL_BASE_RYORTM) {
            if (dWsvRate > 0) {
//OJ040057 20040513 ljq change start
//				dWsvRate = Math.floor(dWsvRate * 100000 + 0.5) / 100000;
                dWsvRate = Math.floor(dWsvRate * 100000 + 0.5000001) / 100000;
//OJ040057 20040513 ljq change end
            } else {
                dWsvRate = Math.floor(dWsvRate * 100000 - 0.5) / 100000;
            }
        } else {
            if (dWsvRate > 0) {
//OJ040057 20040513 ljq change start
//				dWsvRate = Math.floor(dWsvRate * 10000 + 0.5) / 10000;
                dWsvRate = Math.floor(dWsvRate * 10000 + 0.5000001) / 10000;
//OJ040057 20040513 ljq change end
            } else {
                dWsvRate = Math.floor(dWsvRate * 10000 - 0.5) / 10000;
            }
        }

        //取得回收回數、回收サイクル
        nWfrequence = _stairs.getFreque(_stairs.getTopRow());
        nWcycle = _stairs.getCycle(_stairs.getTopRow());

        //合計料率指定の場合
        if (nCalFlag == LfcLogicPgConst.CAL_BASE_RYORTT) {
            if (_gcal.getInc0Flg() == LfcLogicPgConst.KUBUN_YES) {
                //前受リース月数指定の時
                //割賦金額＝（購入額×合計料率÷100）÷(回収回数＋前受リース月数)
                dWi0_Flg = 0;
                dWinc =
                        LfcLogicComm.dround(
                        (_gcal.getPurchas() * _gcal.getRyortT()) / (nWfrequence + 1) + 0.01,
                        0);
            } else {
                //前受割賦金額が金額指定の時（0も含む）
                //割賦金額＝（購入額×合計料率÷100―前受割賦金額）÷回収回数
                dWi0_Flg = 1;
                dWinc =
                        LfcLogicComm.dround(
                        (_gcal.getPurchas() * _gcal.getRyortT() - _gcal.getInc0()) / nWfrequence + 0.01,
                        0);
            }
        } else if (nCalFlag == LfcLogicPgConst.CAL_BASE_RYORTM) {
            //月料率指定の場合
            //割賦金額＝購入額×月料率÷100
            if (_gcal.getInc0Flg() == LfcLogicPgConst.KUBUN_YES) {
                dWi0_Flg = 0;
            } else {
                dWi0_Flg = 1;
            }
            dWinc =
                    LfcLogicComm.dround(
                    _gcal.getPurchas() * _gcal.getRyortM() + 0.01,
                    0);

        } else {
            //採算項目指定の場合（運用利回り、ROI、TR）

            //ＴＲの算出
            if (nCalFlag == LfcLogicPgConst.CAL_BASE_RATEUN) {
                //運用利回り指定の場合
                //ＴＲ = 運用利回り-(原価調整額/購入価額/ﾘｰｽ月数*12*100)/TRの平元率
                _gcal.setTrueRT(
                        _gcal.getRateUN() - (_gcal.getCAdj() / _gcal.getPurchas() / _gcal.getKappuM() * 12) / LfcLogicPgConst.TR_RATE_HN * 1.0000000000);
            }
            if (nCalFlag == LfcLogicPgConst.CAL_BASE_ROI) {
                //ＲＯＩ指定の場合
                //ＴＲ = ROI/0.59 +  社内金利 - (原価調整額/購入価額/ﾘｰｽ月数*12*100)/TRの平元率
                _gcal.setTrueRT(
                        _gcal.getRateROI() / LfcLogicPgConst.USA_PERSON_TAX + _gcal.getRateJL() - (_gcal.getCAdj() / _gcal.getPurchas() / _gcal.getKappuM() * 12) / LfcLogicPgConst.TR_RATE_HN * 1.0000000000);
            }

            //計算表面金利
            if (nWcycle == 1) {
                //回收サイクルが１の場合
                //表面金利 = ＴＲ/12/100
                dWtrM = _gcal.getTrueRT() / 12;
            } else {
                //表面金利 = (ＴＲ/100*24)/(24-TR/100*(回收サイクル-1))/12*回收サイクル
                dWtrM =
                        (_gcal.getTrueRT() * 24) / (24 - _gcal.getTrueRT() * (nWcycle - 1)) / 12 * nWcycle;
            }

            if (_gcal.getInc0Flg() == LfcLogicPgConst.KUBUN_YES) {
                dWi0_Flg = 0;
                //前受リース月数指定の時
                if (_gcal.getTrueRT() == 0) {
                    //ＴＲが０の場合
                    //割賦金額＝(購入価額+初期費用-残価)/(回收回數+前受ﾘｰｽ月数/回收サイクル）
                    dWinc =
                            (_gcal.getPurchas() + _gcal.getInitC()) / (nWfrequence + 1);
                } else {
                    //ＴＲが０以外の場合
                    //割賦金額
                    dWinc =
                            (_gcal.getPurchas() + _gcal.getInitC()) * (1 - 1 / (1 + (dWtrM * Math.pow(
                            1 + dWtrM,
                            (double) nWfrequence)) / (Math.pow(
                            1 + dWtrM,
                            (double) nWfrequence) - 1)));
                }
            } else {
                dWi0_Flg = 1;
                //前受リース料が金額指定の時（0も含む）
                if (_gcal.getTrueRT() == 0) {
                    //ＴＲが０の場合
                    //割賦金額＝(購入価額+初期費用-前受ﾘｰｽ料-残価)/回收回數
                    dWinc =
                            (_gcal.getPurchas() + _gcal.getInitC() - _gcal.getInc0()) / nWfrequence;
                } else {
                    //ＴＲが０以外の場合
                    dWcalc = Math.pow(1 + dWtrM, (double) nWfrequence);
                    //割賦金額＝((購入価額+初期費用-前受ﾘｰｽ料/頭金)*pow（１＋表面金利，回收回數）-残価)
                    //              *表面金利/(pow（１＋表面金利，回收回數）-1)
                    dWinc =
                            (_gcal.getPurchas() + _gcal.getInitC() - _gcal.getInc0()) * (dWcalc * dWtrM) / (dWcalc - 1);
                }
            }

            //割賦金額の整數部分の長さを取得する
            nWrndK =
                    (int) Math.floor(
                    Math.log(Math.abs(dWinc) + 0.1) / Math.log(10.0) + 0.001) + 1;
            if (nWrndK > 5) {
                nWrndK = 3 - nWrndK;
            } else {
                nWrndK = 1 - nWrndK;
            }
            //調整割賦金額
            dWinc = LfcLogicComm.dround(dWinc, nWrndK);
        }
        if (nCalFlag == LfcLogicPgConst.CAL_BASE_RYORTT || nCalFlag == LfcLogicPgConst.CAL_BASE_RYORTM) {
            //合計料率又は月料率指定の場合
            if (dWinc <= 0) {
                if (dWi0_Flg == 0) {
                    _gcal.setInc0(0);
                    //"頭金及び割賦金が０以下になる為、計算不能です。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR116, "ERR116", errMsglist);
                } else {
                    //"割賦金が０以下になる為、計算不能です。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR117, "ERR117", errMsglist);
                }
                _nRet = 1;
                return errMsglist;
            }
            if (dWinc >= 1e11) {
                if (dWi0_Flg == 0) {
                    _gcal.setInc0(0);
                    //"頭金及び割賦金が大きくなりすぎる為、計算不能です。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR118, "ERR118", errMsglist);

                } else {
                    //"割賦金が大きくなりすぎる為、計算不能です。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR119, "ERR119", errMsglist);
                }
                _nRet = 1;
                return errMsglist;
            }
        }

        //調整精度
        nLpCnt = 0;

        while (true) {
            nLpCnt = nLpCnt + 1;
            Date dtEndTime = new Date();
            lEndTime = dtEndTime.getTime();
            if (lEndTime - lStartTime >= LfcLogicPgConst.MAX_TIME / 10) {
                //"値が収束せず、計算不能です。"
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR068, "ERR068", errMsglist);

                _stairs.setIncome(
                        LfcLogicPgConst.INVALID_INCOME,
                        _stairs.getTopRow());
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return errMsglist;
            }
            //調整割賦金額
            if (dWinc <= 0) {
                dWinc = 1;
            }
            if (dWinc >= 1e11) {
                dWinc = 1e11 - 1;
            }
            if (dWi0_Flg == 0) {
                //前受リース月数指定の時,前受リース料を算出する
                _gcal.setInc0(dWinc);
            }
            _stairs.setIncome(dWinc, _stairs.getTopRow());

            //CashFlowを計算
            KpCalMkcash KpMkcash = new KpCalMkcash();
            KpMkcash.setPara(_gcal, _stairs, _cashFl);
            KpMkcash.doCalculate();

            //採算項目再計算
            KpCalProcalc KpProcalc = new KpCalProcalc();
            KpProcalc.setPara(_gcal, _stairs, _cashFl, _paydiv);
            KpProcalc.doCal();
            if (KpProcalc.getRet() == 1) {
                _stairs.setIncome(
                        LfcLogicPgConst.INVALID_INCOME,
                        _stairs.getTopRow());
                if (dWi0_Flg == 0) {
                    //前受リース月数指定の時,前受リース料を算出する
                    _gcal.setInc0(dWinc);
                }
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return errMsglist;
            }

            //今回採算した率算出
            dWrndRt = 0;
            if (nCalFlag == LfcLogicPgConst.CAL_BASE_RYORTT || nCalFlag == LfcLogicPgConst.CAL_BASE_RYORTM) {
                //合計料率又は月料率指定する場合
                //Loop終了計算結果保存画面に表示
                break;
            } else if (nCalFlag == LfcLogicPgConst.CAL_BASE_RATEUN) {
                dWrndRt = _gcal.getRateUN();
            } else if (nCalFlag == LfcLogicPgConst.CAL_BASE_ROI) {
                dWrndRt = _gcal.getRateROI();
            } else if (nCalFlag == LfcLogicPgConst.CAL_BASE_TRUERT) {
                dWrndRt = _gcal.getTrueRT();
            }
            if (dWrndRt > 0) {
                dWrndRt = Math.floor(dWrndRt * 10000 + 0.5) / 10000;
            } else {
                dWrndRt = Math.floor(dWrndRt * 10000 - 0.5) / 10000;
            }

            //今回採算した率と前回率の差算出
            dWdif = dWrndRt - dWsvRate;
            if (Math.floor(Math.abs(dWdif) * 100000000 + 0.0001) == 0) {
                break;
            }
            if (dWinc <= 1 && dWdif > 0) {
                LfcMessageBox box = new LfcMessageBox();
                if (dWi0_Flg == 0) {
                    _gcal.setInc0(0);
                    //"頭金及び割賦金が０以下になる為、計算不能です。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR116, "ERR116", errMsglist);

                } else {
                    //"割賦金が０以下になる為、計算不能です。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR117, "ERR117", errMsglist);
                }
                _stairs.setIncome(
                        LfcLogicPgConst.INVALID_INCOME,
                        _stairs.getTopRow());
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return errMsglist;
            }
            if (dWinc >= 1e11 - 1 && dWdif < 0) {
                if (dWi0_Flg == 0) {
                    _gcal.setInc0(0);
                    //"頭金及び割賦金が大きくなりすぎる為、計算不能です。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR118, "ERR118", errMsglist);
                } else {
                    //"割賦金が大きくなりすぎる為、計算不能です。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR119, "ERR119", errMsglist);
                    _stairs.setIncome(
                            LfcLogicPgConst.INVALID_INCOME,
                            _stairs.getTopRow());
                    _gcal.setSwCri(strWsvCsw);
                    _nRet = 1;
                    break;
                }
            }
            //数値収束
            dWo1Num = dWinc;
            dWd1Rt = dWdif;
//OJ040057 20040513 ljq change start
            dWd1Rt = LfcLogicComm.dround(dWd1Rt, 4);
//OJ040057 20040513 ljq change end
            LsCalLnumAppr numAppr = new LsCalLnumAppr();
            numAppr.setPara(
                    nLpCnt,
                    dWo1Num,
                    dWd1Rt,
                    dWo2Num,
                    dWd2Rt,
                    dWo3Num,
                    dWd3Rt,
                    dWinc);
            numAppr.doCalculate();
            dWo1Num = numAppr.getOld1Num();
            dWd1Rt = numAppr.getDif1Rt();
            dWo2Num = numAppr.getOld2Num();
            dWd2Rt = numAppr.getDif2Rt();
            dWo3Num = numAppr.getOld3Num();
            dWd3Rt = numAppr.getDif3Rt();
            dWinc = numAppr.getNewNum();
            if (numAppr.getNAPRCD() == -1) {
                _nRet = -3;
                break;
            }
            if ("1".equals(strWsvCsw) && "2".equals(_gcal.getSwCri())) {

                _nRet = _nRet - 1;
            }
            if ("2".equals(strWsvCsw) && "1".equals(_gcal.getSwCri())) {

                _nRet = _nRet - 2;
            }
        }
        return errMsglist;
    }
}
