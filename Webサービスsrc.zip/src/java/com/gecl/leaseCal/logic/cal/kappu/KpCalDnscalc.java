/*
 * @(#)KpDnscalc.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.kappu;

import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Stairs;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
/**
 * 団信保険料算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/07/26
 * @since   01-01
 */
public class KpCalDnscalc {
    private Gcal _gcal;             //Gcalbean
    private Stairs _stairs;         //回収情報bean
    private CashFl _cashFl;         //CashFlbean

    /**
     * コンストラクタ．     <BR>     *
     */
    public KpCalDnscalc() {

    }
    /**
     * オブジェクトをセットする．     <BR>
     * Gcal・回収情報・CashFlowを渡す。
     * @param gcal	Gcalオブジェクト
     * @param stairs	回収情報
     * @param cashFl	CashFlオブジェクト
     */
    public void setPara(Gcal gcal,Stairs stairs,CashFl cashFl) {
        _gcal = gcal;
        _stairs = stairs;
        _cashFl = cashFl;
    }
    /**
     * 団信保険料算出を行う． <BR>
     *
     */
    public void doCalculate() {
    	double KappuZan;

	    //団信保険料率あり
    	if (_gcal.getDansRt() != 0){
            //均等回収の場合
    		if (_gcal.getEvenFlg() == 1){
    			//割賦月数が偶数の場合
    			if(_gcal.getKappuM() % 2 == 0){
                    //その他繰延費用(ﾍ)=(購入価額-頭金)*0.6125*割賦月数
                    //*団信保険料率/10000+(購入価額-前受頭金)*0.525*団信保険料率/10000
    				_gcal.setKurino1(LfcLogicComm.dround((_gcal.getPurchas() -_gcal.getInc0())
                                        * 0.6125 * _gcal.getKappuM() * _gcal.getDansRt() / 10000
                                        + (_gcal.getPurchas() - _gcal.getInc0()) * 0.525
                                        * _gcal.getDansRt() / 10000 + 0.001, 0));
    			} else {
                    //その他繰延費用(ﾍ)=(購入価額-頭金)*0.6125*割賦月数
                    //*団信保険料率/10000+(購入価額-前受頭金)*7875*団信保険料率/10000
    				_gcal.setKurino1(LfcLogicComm.dround((_gcal.getPurchas() - _gcal.getInc0())
                                        * 0.6125 * _gcal.getKappuM() * _gcal.getDansRt() / 10000
                                        + (_gcal.getPurchas() - _gcal.getInc0()) * 0.7875
                                        * _gcal.getDansRt() / 10000 + 0.001, 0));
    			}
			//均等回収以外の場合
    		} else {
                _gcal.setKurino1(0.0);
                //割賦金総額を取得する
                KappuZan = _gcal.getIncT();
                for(int i = 0; i < _cashFl.getCashCnt(); ++i){
                    _gcal.setKurino1(_gcal.getKurino1() +
                                        LfcLogicComm.dround(KappuZan
                                            * _gcal.getDansRt() / 10000.0
                                            + 0.001, 0));
                    KappuZan = KappuZan-_cashFl.getIncome(i);
                }
    		}
        }
    }
}

