/*
 * @(#)LsCalLin2cal.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 * 修正日：20070326
 * 修正人：zhangyibo
 * 修正内容：ROIの税率を改定
 */
package com.gecl.leaseCal.logic.cal.lease;

import java.util.Date;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Stairs;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


/**
 * リース料（複数段）算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/06/16
 * @since   01-01
 */
public class LsCalLin2cal {
    /** GcalBean */
    private Gcal     _gcal;
    /** 回収情報Bean */
    private Stairs   _stairs;
    /** 支払情報Bean */
    private Paydiv   _paydiv;
    /** CashFlBean */
    private CashFl   _cashFl;
    /** PG実行成功かどうかのフラグ */
    private int      _nRet;

    /**
     * コンストラクタ．     <BR>
     * Gcal・回収情報・支払情報・CashFlowを渡す。
     * @param gcal
     * @param stairs
     * @param paydiv
     * @param cashFl
     */
    public LsCalLin2cal(Gcal gcal, Stairs stairs, Paydiv paydiv, CashFl cashFl) {
        _gcal       = gcal;
        _stairs     = stairs;
        _paydiv     = paydiv;
        _cashFl     = cashFl;
    }

    /**
     * 採算実行成功かどうかのフラグを戻す． <BR>
     * @return  int 0:成功
     *              1:ＴＲが算出不能です。
     *             -1:信保付保区分が正しくない。
     */
    public int getRet() {
        return _nRet;
    }

    /**
     * リース料（複数段）算出のメソッド．     <BR>
     * @return
     */
    public ArrayList<ErrorInforOutputComplexType> doCalculate() {
        String strWsvCsw;                   //前の信保付保区分
        Date dtStartTime = new Date();        //計算時間
        long lStartTime;                    //開始の時間
        long lEndTime;                      //結束の時間
        long lWreqm;                        //元本調整月数
        double dWo1Num;                     //前回金額
        double dWd1Rt;                      //前回誤差
        double dWo2Num;                     //前々回金額
        double dWd2Rt;                      //前々回誤差
        double dWo3Num;                     //今回金額
        double dWd3Rt;                      //今回誤差
        double dWsvRate;                    //計算前の基準利率
        double dWrCajpy;                    //原価調整額による年荒利率
        double dWinc;                       //リース料
        double dWtrM;                       //表面金利
        double dWrndRt;                     //計算後の基準利率
        double dWdif;                       //料率誤差
        double dWs;                         //調整回收金総額
        double dWs2;                        //調整元本
        int nWrndK;                         //リース料の整數部分の長さ
        int nCalFlag;                       //計算方式
        int nWfrequence;                    //回收回数
        int nWcycle;                        //回收サイクル
        int nLpCnt;                         //計算カウント
        int nStairsPos;                     //stairsの計算カウント
        int nCashFlPos;
        int nWreqmPos;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        _nRet = 0;

        //保存前の信保付保区分
        strWsvCsw = _gcal.getSwCri();
        lStartTime = dtStartTime.getTime();

        dWo2Num = 0;
        dWd2Rt = 0;
        dWo3Num = 0;
        dWd3Rt = 0;

        //原価調整額を計算
        LsCalCajcalc Cajcalc = new LsCalCajcalc();
        Cajcalc.setPara(_paydiv,_gcal);
        Cajcalc.doCalculate();

        //初期費用 = その他一時費用(ｲ)+その他一時費用(ﾛ)+その他一時費用(ﾊ)+斡旋手数料
        _gcal.setInitC(_gcal.getIchiji1() + _gcal.getIchiji2() + _gcal.getIchiji3() + _gcal.getAssen());

        nCalFlag = 0;
        dWsvRate = 0.0;
        if(_gcal.getRateUnFlg() == LfcLogicPgConst.KUBUN_NO) {
            //運用利回り指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_RATEUN;
            dWsvRate = _gcal.getRateUN();
        } else if(_gcal.getRateROIFlg() == LfcLogicPgConst.KUBUN_NO) {
            //年利回り指定の場合
//OJ040057 20040512 ljq change start
//            nCalFlag = LfcLogicPgConst.CAL_BASE_ROI;
//            dWsvRate = _gcal.getRateROI();
        	//20070326 modi zyb s
//            _gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateROI() / 0.65, 5));
        	_gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateROI() / LfcLogicPgConst.USA_PERSON_TAX, 5));
        	//20070326 modi zyb e
            _gcal.setRateUN(_gcal.getRateYr() + _gcal.getRateJL());
            nCalFlag = LfcLogicPgConst.CAL_BASE_RATEUN;
            dWsvRate = _gcal.getRateUN();
//OJ040057 20040512 ljq change end
        } else if(_gcal.getTrueRtFlg() == LfcLogicPgConst.KUBUN_NO) {
            //ＴＲ指定の場合
            nCalFlag = LfcLogicPgConst.CAL_BASE_TRUERT;
            dWsvRate = _gcal.getTrueRT();
        }

        //調整計算前の基準利率
        if(dWsvRate > 0) {
            dWsvRate = Math.floor(dWsvRate * 10000 + 0.5) / 10000;
        } else {
            dWsvRate = Math.floor(dWsvRate * 10000 - 0.5) / 10000;
        }
        //原価調整額による年荒利率を取得する
//OJ040057 20040512 ljq change start
//        dWrCajpy = (Math.pow(1 + _gcal.getRateCADJ() * 100 / 12, (double)Math.abs(_gcal.getAdjM()))
//                        * (1 + _gcal.getRateCADJ() * 100 / 365 * Math.abs(_gcal.getAdjD())) - 1)
//                        / _gcal.getLeaseM() * 12;
        dWrCajpy = (Math.pow(1 + _gcal.getRateJL() * 100 / 12, (double)Math.abs(_gcal.getAdjM()))
                        * (1 + _gcal.getRateJL() * 100 / 365 * Math.abs(_gcal.getAdjD())) - 1)
                        / _gcal.getLeaseM() * 12 / 100;
//OJ040057 20040512 ljq change start
        if(_gcal.getAdjM() < 0 || _gcal.getAdjD() < 0) {
            //原価調整月数 < 0又は原価調整日数 < 0 の場合
            dWrCajpy = -1 * dWrCajpy;
        }

        if(nCalFlag == LfcLogicPgConst.CAL_BASE_RATEUN) {
            //運用利回り指定の場合
            //ＴＲ = 運用利回り-原価調整額による年荒利率/TRの平元率
            _gcal.setTrueRT(_gcal.getRateUN() - dWrCajpy / LfcLogicPgConst.TR_RATE_HN * 1.0000000000);
        }
        if(nCalFlag == LfcLogicPgConst.CAL_BASE_ROI) {
            //ＲＯＩ指定の場合
            //ＴＲ = ROI/0.59 +  社内金利 - 原価調整額による年荒利率 / TRの平元率
            _gcal.setTrueRT(_gcal.getRateROI() / LfcLogicPgConst.USA_PERSON_TAX
                    + _gcal.getRateJL() - dWrCajpy / LfcLogicPgConst.TR_RATE_HN * 1.0000000000);
        }
        //計算表面金利
//        dWtrM = _gcal.getTrueRT() / 12 /100;
        dWtrM = _gcal.getTrueRT() / 12;

        //求める段を算出する
        //求める段:有効段と回収金額<=0の場合
        for(nStairsPos = _stairs.getTopRow(); nStairsPos < _stairs.getRowCount(); nStairsPos++) {
            if(_stairs.getAct(nStairsPos) == LfcLogicPgConst.KUBUN_YES
                    && _stairs.getIncome(nStairsPos) <= 0) {
                        break;
            }
        }

        //LsCalComm.setCalStairsPos(nStairsPos);
        //元本調整月數 = 求める段の月數－検収月数－１
        lWreqm = (_stairs.getDateYY(nStairsPos) * 12L + _stairs.getDateMM(nStairsPos))
                        - (LfcLogicComm.db3Year(_gcal.getDKensh()) * 12L + LfcLogicComm.db3Month(_gcal.getDKensh())) - 1;
        //回收回數と回收サイクルを取得する
        nWfrequence = _stairs.getFreque(nStairsPos);
        nWcycle = _stairs.getCycle(nStairsPos);

        //調整元本 = (購入価額+初期費用- cashflow[0]の回收金額)*pow(1+表面金利,元本調整月數)
        nCashFlPos = 0;
        dWs2 = (_gcal.getPurchas() + _gcal.getInitC() - _cashFl.getIncome(nCashFlPos))
                        * Math.pow(1 + dWtrM, (double)lWreqm);
        dWs = 0;
        nWreqmPos = 0;
        nCashFlPos = 1;
        //1から元本調整月數までループして「回收金額*pow(1+表面金利,(元本調整月數-i))」に累計を行う。
        while(nWreqmPos < lWreqm) {
            nWreqmPos = nWreqmPos + 1;
            dWs = dWs + _cashFl.getIncome(nCashFlPos) * Math.pow(1 + dWtrM, (double)(lWreqm - nWreqmPos));
            nCashFlPos = nCashFlPos + 1;
        }

        nCashFlPos = _cashFl.getCashCnt() - 1;
        nWreqmPos = nCashFlPos;
        //元本調整月數からMAX(CashFlowの長さ)までループして「回收金額*pow(1+表面金利,(i - 元本調整月數))」に累計を行う。
        while(nWreqmPos > lWreqm) {
            dWs = dWs + _cashFl.getIncome(nCashFlPos) / Math.pow(1 + dWtrM, (double)(nWreqmPos - lWreqm));
            nWreqmPos = nWreqmPos - 1;
            nCashFlPos = nCashFlPos - 1;
        }
        //期首元本を計算する。
        dWs = dWs / Math.pow(1 + dWtrM, (double)(nWcycle - 1));

        //表面金利を計算する。
        if(nWcycle == 1) {
            //回收サイクルが１の場合
            //表面金利 = ＴＲ/12/100
//            dWtrM = _gcal.getTrueRT() / 12 / 100;
            dWtrM = _gcal.getTrueRT() / 12;
        } else {
            //表面金利 = (TR/100*24)/(24-TR/100*(回收サイクル-1))/12*回收サイクル
//            dWtrM = (_gcal.getTrueRT() / 100 * 24) / (24 - _gcal.getTrueRT() / 100 * (nWcycle - 1)) / 12 * nWcycle;
            dWtrM = (_gcal.getTrueRT() * 24) / (24 - _gcal.getTrueRT() * (nWcycle - 1)) / 12 * nWcycle;
        }

        if(_gcal.getTrueRT() == 0) {
            //ＴＲが０の場合
            //リース料＝(調整元本-期首元本)/回收回數
            dWinc = (dWs2 - dWs) / nWfrequence;
        } else {
            //ＴＲが０以外の場合
            //リース料＝(調整元本-期首元本)*(表面金利*pow(1+表面金利,回收回數))
            //              /(pow(1+表面金利,回收回數)-1)
            dWinc = (dWs2 - dWs) * (dWtrM * Math.pow(1 + dWtrM, (double)nWfrequence))
                        / (Math.pow(1 + dWtrM, (double)nWfrequence) - 1);
        }

        //リース料の整數部分の長さを取得する
        nWrndK = (int)Math.floor(Math.log(Math.abs(dWinc) + 0.1) / Math.log(10.0) + 0.001) + 1;
        if(nWrndK > 5) {
            nWrndK = 3 - nWrndK;
        } else {
            nWrndK = 1 - nWrndK;
        }
        //調整リース料
        dWinc = LfcLogicComm.dround(dWinc,nWrndK);

        //調整精度
        nLpCnt = 0;
        while(true) {
            Date dtEndTime = new Date();
            lEndTime = dtEndTime.getTime();
            if(lEndTime - lStartTime >= LfcLogicPgConst.MAX_TIME) {
                //"値が収束せず、計算不能です。"
		errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR068,"ERR068",errMsglist);
                _stairs.setIncome(LfcLogicPgConst.INVALID_INCOME, nStairsPos);
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return errMsglist;
            }
            //調整リース料
            if(dWinc <= 0) {
                dWinc = 1;
            }
            if(dWinc >= 1e11) {
                dWinc = 1e11 - 1;
            }

            _stairs.setIncome(dWinc, nStairsPos);

            //CASHFLOW設定
            LsCalLmkCash lmkCash = new LsCalLmkCash();
            lmkCash.setPara(_gcal, _stairs, _cashFl);
            lmkCash.doCalculate();
            //LsCalComm.LmkCash.setPara(_gcal, _stairs, _cashFl);
            //LsCalComm.LmkCash.doCalculate();

            //採算項目再計算
            LsCalLproCal lprocal = new LsCalLproCal();
            lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
            lprocal.doCal();
            //LsCalComm.Lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
            //LsCalComm.Lprocal.doCal();
            if(lprocal.getRet() == 1) {
                _stairs.setIncome(LfcLogicPgConst.INVALID_INCOME, nStairsPos);
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return null;
            }

            //今回採算した率算出
            dWrndRt = 0;
            if(nCalFlag == LfcLogicPgConst.CAL_BASE_RATEUN) {
                dWrndRt = _gcal.getRateUN();
            } else if(nCalFlag == LfcLogicPgConst.CAL_BASE_ROI) {
                dWrndRt = _gcal.getRateROI();
            } else if(nCalFlag == LfcLogicPgConst.CAL_BASE_TRUERT) {
                dWrndRt = _gcal.getTrueRT();
            }
            if(dWrndRt > 0) {
                dWrndRt = Math.floor(dWrndRt * 10000 + 0.5) / 10000;
            } else {
                dWrndRt = Math.floor(dWrndRt * 10000 - 0.5) / 10000;
            }

            //今回採算した率と前回率の差算出
            dWdif = dWrndRt - dWsvRate;
            if(Math.floor(Math.abs(dWdif) * 100000000 + 0.0001) == 0) {
                break;
            }
            if(dWinc <= 1 && dWdif > 0) {
                //"回収金が０以下になる為、計算不能です。"
		errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR066,"ERR066",errMsglist);
                _stairs.setIncome(LfcLogicPgConst.INVALID_INCOME, nStairsPos);
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return null;
            }
            if(dWinc >= 1e11 - 1 && dWdif < 0) {
                //"回収金が大きくなりすぎる為、計算不能です。"
		errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR067,"ERR067",errMsglist);

                _stairs.setIncome(LfcLogicPgConst.INVALID_INCOME, nStairsPos);
                _gcal.setSwCri(strWsvCsw);
                _nRet = 1;
                return errMsglist;
            }

            //数値収束
            dWo1Num = dWinc;
            dWd1Rt = dWdif;
            nLpCnt = nLpCnt + 1;
            LsCalLnumAppr numAppr = new LsCalLnumAppr();
            numAppr.setPara(nLpCnt, dWo1Num, dWd1Rt, dWo2Num, dWd2Rt, dWo3Num, dWd3Rt, dWinc);
            numAppr.doCalculate();
            dWo1Num = numAppr.getOld1Num();
            dWd1Rt = numAppr.getDif1Rt();
            dWo2Num = numAppr.getOld2Num();
            dWd2Rt = numAppr.getDif2Rt();
            dWo3Num = numAppr.getOld3Num();
            dWd3Rt = numAppr.getDif3Rt();
            dWinc = numAppr.getNewNum();

            if(numAppr.getNAPRCD() == -1) {
                _nRet = -3;
                break;
            }
        }
//        if("1".equals(strWsvCsw)) {
//            //前の信保付保区分が"1"の場合、信保付保区分に"1"をセットする
//            _gcal.setSwCri("1");
//            _nRet = _nRet - 1;
//        }
        return null;
    }
}
