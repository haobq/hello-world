/*
 * @(#)LsCalLtrcal.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.*;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;

public class LsCalLtrcal {
    private Gcal _gcal;
    private CashFl _cashFl;
    private int _nCashCnt;
    private int _nRet = 0;

    public LsCalLtrcal() {

    }

    public void setPara(Gcal gcal, CashFl cashFl) {
        _gcal = gcal;
        _cashFl = cashFl;
//20040527 ljq add start
        _nRet = 0;
//20040527 ljq add end
    }

    public int getRet() {
        return _nRet;
    }

    public ArrayList<ErrorInforOutputComplexType> doCalculate() {

        int    nLMax = 100;
        int    nRMax = 20;
        int    nLCnt = 0;
        int    nRCnt = 0;
        int    nCashPos;
        double dCashf;
        double E = 1;
        double X0 = 1.0;
        double X1 = 1.0;
        double S;
        double T;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        X0 = 1.0 / (1.0 + 0.05 / 12.0);
        dCashf = _cashFl.getIncome(0) * _gcal.getNetRt() - _gcal.getPurchas()
                            - _gcal.getInitC();
        _cashFl.setCashFlow(dCashf, 0);

        for(int i = 1; i < _cashFl.getCashCnt() ; i++) {
            dCashf = _cashFl.getIncome(i) * _gcal.getNetRt();
            _cashFl.setCashFlow(dCashf, i);
        }

        nCashPos = _gcal.getLeaseM() + 2 - 1;
        _cashFl.setCashFlow(_cashFl.getCashFlow(nCashPos) + _gcal.getRemVAL(), nCashPos);
        while(nLCnt < nLMax) {
            nLCnt = nLCnt + 1;
            S = 0;
            T = 0;

            int i = _cashFl.getCashCnt() - 1;
            while(i > 0) {
                S = _cashFl.getCashFlow(i) + S * X0;
                T = S + T * X0;
                i = i - 1;
            }

            if(Math.abs(S) > 1E+65 || Math.abs(T) >= 1E+65) {
                nRCnt = nRCnt + 1;
                if(nRCnt <= nRMax) {
                    X0 = (X0 + 1) / 2.0;
                    continue;
                } else {
                    break;
                }
            }

            S = _cashFl.getCashFlow(0) + S * X0;
            X1 = X0 - S / T;
            E = (X1 - X0) / X0;
//            _gcal.setTrueRT((1 / X1 - 1) * 100);
            _gcal.setTrueRT((1 / X1 - 1));
            if(Math.abs(E) < 1E-15) {
                break;
            }
            X0 = X1;
        }

        if(nRCnt > nRMax || nLCnt > nLMax) {
            //ＴＲが算出不能です。計算条件を確認して下さい。
             errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR085,"ERR085",errMsglist);
            _nRet = -1;
        } else {
//            _gcal.setTrueRT((1 / X1 - 1) * 12 * 100);
            _gcal.setTrueRT((1 / X1 - 1) * 12);
        }
        return errMsglist;
    }
}
