/*
 * @(#)LsCalLnumAppr.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

public class LsCalLnumAppr {
    /**収束計算回数*/
     private int    _nLpCnt;
    /**前回金額*/
     private double _dOld1Num;
    /**前回誤差*/
     private double _dDif1Rt;
    /**前々回金額*/
     private double _dOld2Num;
    /**前々回誤差*/
     private double _dDif2Rt;
    /**今回金額*/
     private double _dOld3Num;
    /**今回誤差*/
     private double _dDif3Rt;
    /**収束後金額*/
     private double _dNewNum;

     private int    _nNapRcd;
    /**今回の近似値*/
     double dWnewN;
    /***前々回の近似値と前回の近似値の誤差*/
     double dWdifNum;
    /**前々回の誤差と前回の誤差*/
     double dWdifRt;
    /**四捨五入する位置を求める*/
     double dWrndL;

    public double getNAPRCD(){
        return _nNapRcd;
    }

    public double getOld1Num() {
        return _dOld1Num;
    }
    public double getDif1Rt() {
        return _dDif1Rt;
    }
    public double getOld2Num() {
        return _dOld2Num;
    }
    public double getDif2Rt() {
        return _dDif2Rt;
    }

    public double getOld3Num() {
        return _dOld3Num;
    }
    public double getDif3Rt() {
        return _dDif3Rt;
    }

    public double getNewNum() {
        return _dNewNum;
    }

    public LsCalLnumAppr() {

    }

    public void setPara(int nLpCnt,double dOld1Num,double dDif1Rt,
           double dOld2Num,double dDif2Rt, double dOld3Num,
           double dDif3Rt,double dNewNum) {

        _nLpCnt   = nLpCnt;
        _dOld1Num = dOld1Num;
        _dDif1Rt  = dDif1Rt;
        _dOld2Num = dOld2Num;
        _dDif2Rt  = dDif2Rt;
        _dOld3Num = dOld3Num;
        _dDif3Rt  = dDif3Rt;
        _dNewNum  = dNewNum;
    }

    public void doCalculate() {

        _nNapRcd=0;

        //1回目の近似値の場合
        if(_nLpCnt==1){

            //今回の近似値を計算
            dWnewN = Math.floor(_dOld1Num*(1-_dDif1Rt / 10) + 0.01);

        //2回目以降の近似値の場合
        }else{

            //前々回の近似値と前回の近似値の誤差を計算する
            dWdifNum = Math.floor(_dOld2Num-_dOld1Num+0.01);

            //前々回の誤差と前回の誤差を計算する
            dWdifRt = _dDif2Rt - _dDif1Rt;

            //前々回の誤差と前回の誤差が等しい場合
            if (Math.floor(Math.abs(dWdifRt) * 10000 + 0.01)==0){

                dWnewN = _dOld1Num - dWdifNum;

                //前々回の近似値と前回の近似値が等しい場合
                if (dWnewN == _dOld1Num){

                    if (_dDif1Rt>0){

                        //今回の近似値[四捨五入前]＝前回の近似値-100
                        dWnewN =_dOld1Num - 100;

                    }else{

                        //今回の近似値[四捨五入前]＝前回の近似値＋100
                        dWnewN =_dOld1Num + 100;
                    }
                }
            //前々回の誤差と前回の誤差が異なる場合
            }else{
                dWnewN=_dOld1Num - Math.abs(dWdifNum/dWdifRt)*_dDif1Rt;
            }
        }

        //四捨五入する位置を求める
        dWrndL = (int)Math.abs(Math.floor(Math.log(Math.abs(dWnewN)+0.1)/Math.log(10.0)))+1;

        //近似値が、６桁以上のとき
        if(dWrndL>5){
            //上位の桁から４桁目とする
            dWrndL= 3 - dWrndL;
        //近似値が、５桁以下のとき
        }else{
           //上位の桁から２桁目とする
            dWrndL= 1 - dWrndL;
        }

        //今回近似値を四捨五入処理開始
        while(true){

            _dNewNum= Math.floor(Math.floor(dWnewN*Math.pow(10.0,dWrndL)+0.5)/Math.pow(10.0,dWrndL)+0.5);

            if ((_dDif1Rt<0 && _dNewNum<=_dOld1Num)||
                (_dDif1Rt>0 && _dNewNum>=_dOld1Num)||
                (_dDif2Rt<0 && _dNewNum<=_dOld2Num)||
                (_dDif2Rt>0 && _dNewNum>=_dOld2Num)||
                (_dDif3Rt<0 && _dNewNum<=_dOld3Num)||
                (_dDif3Rt>0 && _dNewNum>=_dOld3Num)){

                if (dWrndL==0){

                    //1回目の近似値の場合
                    if (_nLpCnt==1){

                        //前回の誤差が０より大きいとき
                        if (_dDif1Rt>0){

                           //今回の近似値＝前回の近似値×０.９  （小数第１位を四捨五入）
                            _dNewNum = Math.floor(_dOld1Num*0.9+0.01);

                        //前回の誤差が０より小さいとき
                        }else{

                           //今回の近似値＝前回の近似値×１.１  （小数第１位を四捨五入
                            _dNewNum = Math.floor(_dOld1Num*1.1+0.01);
                        }

                    //2回目以降の近似値の場合
                    }else{
                        //前々回の近似値と前回の近似値との誤差の絶対値が１のとき
                        if (Math.abs(_dOld2Num-_dOld1Num)==1){

                            //前回の誤差が０より大きく、前々回の誤差が０より小さい場合
                            if (_dDif1Rt>0 && _dDif2Rt<0){

                                //指定された採算に合致する値が求められない為、前回の近似値を強制的な集束値とする
                                _nNapRcd = -1;

                            //前回の誤差が０より小さく、前々回の誤差が０より大きい場合
                            }else if (_dDif1Rt<0 && _dDif2Rt>0){

                                //指定された採算に合致する値が求められない為、前々回の近似値を強制的な集束値とする
                                _dNewNum = _dOld2Num;

                            //前回の誤差が０より大きく、前々回の誤差が０より大きい場合
                            }else if(_dDif1Rt>0 && _dDif2Rt>0){

                                //今回の近似値＝前回の近似値－１
                                _dNewNum = _dOld1Num -1;

                            //前回の誤差が０より小さく、前々回の誤差が０より小さい場合
                            }else if(_dDif1Rt<0 && _dDif2Rt<0){

                                //今回の近似値＝前回の近似値＋１
                                _dNewNum = _dOld1Num +1;
                            }
                        //前々回の近似値と前回の近似値との誤差の絶対値が１以外
                        //（１より大きい）時今回の近似値＝（前々回の近似値＋前回の近似値）÷２  （小数第１位を四捨五入）
                        }else {
                            _dNewNum= Math.floor((_dOld2Num+_dOld1Num)/2+0.5+0.00001);
                        }
                    }
                    break;
                }
            }else{
                break;
            }
            dWrndL=dWrndL+1;
        }

        //過去３回までの近似値・誤差を順次シフトして保存する
        if (!((_dDif1Rt<0 && _dDif2Rt<0 && _dDif3Rt>0)||(_dDif1Rt>0 && _dDif2Rt>0 && _dDif3Rt<0))){
            //今回の近似値=前回の近似値
            _dOld3Num =_dOld2Num;
            //今回の誤差=前回の誤差
            _dDif3Rt  =_dDif2Rt;
        }
        //前回の近似値=前々回の近似値
        _dOld2Num =_dOld1Num;
        //前回の誤差=前々回の誤差
        _dDif2Rt  =_dDif1Rt;
        //
        _dOld1Num =_dNewNum;

    }

}
