/*
 * @(#)LsCalLrdycal.java      01-01  2003/06/13
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 *修正日：20050512
 *修正人：潘正寛
 *修正内容：ROEで逆算をする
 *
 * 修正日：20050525
 * 修正人：潘正寛
 * 修正内容：残価額100円以下を切り捨て）
 *
 * 修正日：200507028
 * 修正人：HBQ
 * 修正内容：残価計算値を百円で切り捨て *
 *
 * 修正日：20051018
 * 修正人：潘正寛
 * 修正内容：Add a warning flag.
 */
package com.gecl.leaseCal.logic.cal.lease;


import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.Fixrem;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.Stairs;
import java.util.ArrayList;

import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


/**
 * 計算処理制御
 * @author  廖家慶
 * @version 01-01、 2003/06/04
 * @since   01-01
 */
public class LsCalLrdycal {

    /** GcalBean */
    private Gcal _gcal;
    /** 回収情報Bean */
    private Stairs _stairs;
    /** 支払情報Bean */
    private Paydiv _paydiv;
    /** CashFlBean */
    private CashFl _cashFl;
    /** PG実行成功かどうかのフラグ */
    private Fixrem _fixrem;
    /** PG実行成功かどうかのフラグ */
    private int _nRet;
    private int _nWrng;

    /**
     * コンストラクタ．     <BR>
     * Gcal・回収情報・支払情報・CashFlowを渡す。
     * @param gcal
     * @param stairs
     * @param paydiv
     * @param cashFl
     * @param fixrem
     */
    public LsCalLrdycal(Gcal gcal, Stairs stairs, Paydiv paydiv, CashFl cashFl, Fixrem fixrem) {
        _gcal = gcal;
        _stairs = stairs;
        _paydiv = paydiv;
        _cashFl = cashFl;
        _fixrem = fixrem;
    }

    /**
     * 採算実行成功かどうかのフラグを戻す． <BR>
     * @return  int 0:成功
     *              1:ＴＲが算出不能です。
     *             -1:信保付保区分が正しくない。
     */
    public int getRet() {
        return _nRet;
    }

    public int getWrng() {
        return _nWrng;
    }

    /**
     * リース料（一段）算出のメソッド．     <BR>
     * @return
     */
    public ArrayList<ErrorInforOutputComplexType> doCalculate(int nCalItem,int nBaseProf) {
        int nIncomeCount;
        int nFrequeCount;
        int nWcnt;
        int nWsvFrq;
        int nWlTerm;
        int nLastValidStairs;
        double dSRyortT;
        double dSRyortM;
        double dSRateUn;
        double dSRateROI;
        double dSTrueRt;
        double dWsvinc;
        double dRemVal;
        double dRemVRt;
        double dInterP;
        double dInterI;
        double dChanrge;
        double dExecC;
        double dKurino1;
        double dInsur;
        double dDosoF;
        double dCostT;
        double dProfT;
        double dProfY;
        double dCharge;
        double dCapitT;
        double dNetRt;
        double dTrueRt;
        double dRateROI;
        double dRateUn;
        double dRateYr;
        double dRyortT;
        double dRyortM;
        double dRtPrT;
        double dRtPrY;
        double dFinanceMargin;
        double dPvFinanceMargin;
        double dRaMargin;
        double dRaPvMargin;
        double dDamFa;
        double dDamLa;
        double dROE;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

//pzk add 20050512 start
        //算出項目指定の選択項目
        int intCalItem;
        //逆算時基準項目の選択項目
        int intBaseProf;

        intCalItem = nCalItem;
        intBaseProf = nBaseProf;
        //intCalItem = LsCalComm.getReqItem();
        //intBaseProf = LsCalComm.getBaseItem();
//pzk add 20050512 end

        //分割支払有無区分
        if (_gcal.getSwPay() == LfcLogicPgConst.KUBUN_YES) {

            //設置分割支払有効区分
            for (int i = 0; i < LfcLogicPgConst.PAYDIV_MAX_COUNT; i++) {
                if (_paydiv.getPurchas(i) <= 0 && _paydiv.getDateYY(i) <= 0 && _paydiv.getDateMM(i) <= 0 && _paydiv.getDateDD(i) <= 0) {
                    _paydiv.setAct(LfcLogicPgConst.KUBUN_NO, i);
                } else {
                    _paydiv.setAct(LfcLogicPgConst.KUBUN_YES, i);
                }
            }
        }

        //設置リース階段有効区分
        for (int i = 0; i < LfcLogicPgConst.STAIRS_MAX_COUNT; i++) {
            if (_stairs.getIncome(i) <= 0 && _stairs.getFreque(i) <= 0 && _stairs.getDateYY(i) <= 0 && _stairs.getDateMM(i) <= 0 && _stairs.getDateDD(i) <= 0 && _stairs.getCycle(i) <= 0) {
                _stairs.setAct(LfcLogicPgConst.KUBUN_NO, i);
            } else {
                _stairs.setAct(LfcLogicPgConst.KUBUN_YES, i);
            }
        }

        //入力データチェック
        nIncomeCount = 0;
        nFrequeCount = 0;
        LsCalErrorCheck ErrCheck = new LsCalErrorCheck();
        ErrCheck.setPara(_gcal, _stairs, _paydiv);
        ArrayList<ErrorInforOutputComplexType>  errMsglisttmp=ErrCheck.doErrorCheck(nCalItem,nBaseProf);
        if (!errMsglisttmp.isEmpty()) {
            errMsglist=errMsglisttmp;
            //LsCalComm.setResultDisplayFlag(false);
            return errMsglist;
        }
        nIncomeCount = ErrCheck.getIncomeCount();
        nFrequeCount = ErrCheck.getFrequeCount();

        //取得リース有効階段中回　　　收金額為空（０）和回数為　　空（０）數量
        if (intCalItem == 1 && nIncomeCount == 0) {
            _stairs.setIncome(0.0, _stairs.getLastRow());
            nIncomeCount = 1;
        }
        if (intCalItem == 3 && nFrequeCount == 0) {
            _stairs.setFreque(0, _stairs.getLastRow());
            nFrequeCount = 1;
        }

        //取得合計料率
        dSRyortT = _gcal.getRyortT();

        //取得月料率
        dSRyortM = _gcal.getRyortM();

        //取得運用利回り
        dSRateUn = _gcal.getRateUN();
//      pzk modi 20050512 start

        //取得ＴＲ
//        dSRateROI = _gcal.getRateROI();
        if ((intCalItem != LfcLogicPgConst.CAL_ITEM_LPRO) && (intBaseProf == LfcLogicPgConst.CAL_BASE_ROE)) {
            //ROEからROI算出　ROI＝ROE/（LeverageRatio+１）　少数点３桁で四捨五入　少数点２桁で計算する
            dSRateROI = LfcLogicComm.dround(_gcal.getROE() / (_gcal.getLeverage() + 1), 4);
            _gcal.setRateROI(dSRateROI);
        } else {
            dSRateROI = _gcal.getRateROI();
        }
//      pzk modi 20050512 end
        dSTrueRt = _gcal.getTrueRT();


        //残価入力有無区分＝１&& 残価率入力有無区分＝０
        if (_gcal.getRemValFlg() == LfcLogicPgConst.KUBUN_YES && _gcal.getRemVRtFlg() == LfcLogicPgConst.KUBUN_NO) {
//                  pzk modi 20050525 start
            //_gcal.setRemVAL(LfcLogicComm.dround(_gcal.getPurchas() * _gcal.getRemVRT() + 0.001, 0));
            //残価計算値を百円で切り捨て　HBQ　200507028　begin
            //_gcal.setRemVAL((long)(LfcLogicComm.dround(_gcal.getPurchas() * _gcal.getRemVRT() + 0.001, 0)/100)*100);
            //ydy modify 20071229 s
//            _gcal.setRemVAL((long)(_gcal.getPurchas() * _gcal.getRemVRT()/100)*100);
            _gcal.setRemVAL((long) (LfcLogicComm.dround(_gcal.getPurchas() * _gcal.getRemVRT(), 0) / 100) * 100);
            //ydy modify 20071229 e
            //残価計算値を百円で切り捨て　HBQ　200507028　end

//          pzk modi 20050525 end
        }

        //前受/頭金入力有無区分＝１ ||
        //（前受ﾘｰｽ月数入力有無区分＝０ &&ﾘｰｽ月数入力有無区分=1) &&
        //回收金額為空個數＝０
        if ((_gcal.getInc0Flg() == LfcLogicPgConst.KUBUN_YES || (_gcal.getInc0MFlg() == LfcLogicPgConst.KUBUN_NO && _gcal.getLeaseMFlg() == LfcLogicPgConst.KUBUN_YES)) && nIncomeCount == 0) {
            for (nLastValidStairs = LfcLogicPgConst.STAIRS_MAX_COUNT - 1; nLastValidStairs >= 0; --nLastValidStairs) {
                if (!_stairs.getAct(nLastValidStairs) == LfcLogicPgConst.KUBUN_YES) {
                    continue;
                }
                if (_stairs.getIncome(nLastValidStairs) != 0.0) {
                    break;
                }
            }
            _gcal.setInc0(Math.floor(_stairs.getIncome(nLastValidStairs) * _gcal.getInc0M() / _stairs.getCycle(nLastValidStairs) + 0.5001));
        }

        //ﾘｰｽ月数入力有無区分＝１ &&回數為空個數＝０
        if (_gcal.getLeaseMFlg() == LfcLogicPgConst.KUBUN_YES && nFrequeCount == 0) {
            for (nLastValidStairs = LfcLogicPgConst.STAIRS_MAX_COUNT - 1; nLastValidStairs >= 0; --nLastValidStairs) {
                if (!_stairs.getAct(nLastValidStairs) == LfcLogicPgConst.KUBUN_YES) {
                    continue;
                }
                if (_stairs.getIncome(nLastValidStairs) != 0.0) {
                    break;
                }
            }

            //最後有效階段的回收=0
            _stairs.setFreque(0, nLastValidStairs);
        }
        LsCalLmkCash lmkCash = new LsCalLmkCash();
        lmkCash.setPara(_gcal, _stairs, _cashFl);
        lmkCash.doCalculate();
        //LsCalComm.LmkCash.setPara(_gcal, _stairs, _cashFl);
        //LsCalComm.LmkCash.doCalculate();
        _gcal.setEvenFlg(0);

        //ﾘｰｽ段数＝１
        if (_gcal.getLeaseD() == 1) {


            //回收金額為空個數≠０
            if (nIncomeCount != 0) {

                //リース料算出
                LsCalLin1cal Lin1cal = new LsCalLin1cal(_gcal, _stairs, _paydiv, _cashFl);
                Lin1cal.doCalculate();
                _nRet = Lin1cal.getRet();

                //定率残価ｲﾝﾃﾞｯｸｽ＝０ && 残価入力有無区分= 1 && 残価率入力有無区分=1
            } else if (_gcal.getFremIX() == 0 && _gcal.getRemValFlg() == LfcLogicPgConst.KUBUN_YES && _gcal.getRemVRtFlg() == LfcLogicPgConst.KUBUN_YES) {

                //残価算出
                LsCalLrv1cal Lrv1cal = new LsCalLrv1cal(_gcal, _stairs, _paydiv, _cashFl, _fixrem);
                Lrv1cal.doCalculate();
                _nRet = Lrv1cal.getRet();

                //ﾘｰｽ月数入力有無区分=1
            } else if (_gcal.getLeaseMFlg() == LfcLogicPgConst.KUBUN_YES) {

                //回数算出
                LsCalLfr1cal Lfr1cal = new LsCalLfr1cal(_gcal, _stairs, _paydiv, _cashFl, _fixrem);
                Lfr1cal.doCalculate();
                _nRet = Lfr1cal.getRet();

                //購入価額入力有無区分=1
            } else if (_gcal.getPurchasFlg() == LfcLogicPgConst.KUBUN_YES) {

                //購入価額算出
                LsCalLpu1cal Lpu1cal = new LsCalLpu1cal(_gcal, _stairs, _paydiv, _cashFl, _fixrem);
                Lpu1cal.doCalculate();
                _nRet = Lpu1cal.getRet();
            } else {

                //採算項目算出
                LsCalLproCal lprocal = new LsCalLproCal();
                lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
                lprocal.doCal();
                //LsCalComm.Lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
                //LsCalComm.Lprocal.doCal();
                //_nRet = LsCalComm.Lprocal.getRet();
                _nRet = lprocal.getRet();
            }

            //各頂目の複数段算出
        } else {
            if (nIncomeCount != 0) {
                LsCalLin2cal Lin2cal = new LsCalLin2cal(_gcal, _stairs, _paydiv, _cashFl);
                Lin2cal.doCalculate();
                _nRet = Lin2cal.getRet();
            } else if (_gcal.getFremIX() == 0 && _gcal.getRemValFlg() == LfcLogicPgConst.KUBUN_YES && _gcal.getRemVRtFlg() == LfcLogicPgConst.KUBUN_YES) {
                LsCalLrv2cal Lrv2cal = new LsCalLrv2cal(_gcal, _stairs, _paydiv, _cashFl, _fixrem);
                Lrv2cal.doCalculate();
                _nRet = Lrv2cal.getRet();
            } else if (_gcal.getLeaseMFlg() == LfcLogicPgConst.KUBUN_YES) {
                LsCalLfr2cal Lfr2cal = new LsCalLfr2cal(_gcal, _stairs, _paydiv, _cashFl, _fixrem);
                Lfr2cal.doCalculate();
                _nRet = Lfr2cal.getRet();
            } else if (_gcal.getPurchasFlg() == LfcLogicPgConst.KUBUN_YES) {
                LsCalLpu2cal Lpu2cal = new LsCalLpu2cal(_gcal, _stairs, _paydiv, _cashFl, _fixrem);
                Lpu2cal.doCalculate();
                _nRet = Lpu2cal.getRet();
            } else {
                LsCalLproCal lprocal = new LsCalLproCal();
                lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
                lprocal.doCal();
                //LsCalComm.Lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
                //LsCalComm.Lprocal.doCal();
                //_nRet = LsCalComm.Lprocal.getRet();
                _nRet = lprocal.getRet();
            }
        }

        //計算ﾘｰｽ料 = 契約額!)保守料
        _gcal.setIncT(_gcal.getIncGt() - _gcal.getHoshury());

        if (_gcal.getIncGt() / _gcal.getPurchas() < 0.001) {
            //購入価額に対して回収金額が少な過ぎます。
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR078, "ERR078", errMsglist);
            _nRet = 1;
        }

        //返回値判斷
        //＞０：エラー
        if (_nRet > 0) {
            _gcal.setRyortT(dSRyortT);
            _gcal.setRyortM(dSRyortM);
            _gcal.setRateUN(dSRateUn);
            _gcal.setRateROI(dSRateROI);
            _gcal.setTrueRT(dSTrueRt);
            if (_gcal.getInc0Flg() == LfcLogicPgConst.KUBUN_YES) {
                _gcal.setInc0(0);
            }
            if (_gcal.getInc0MFlg() == LfcLogicPgConst.KUBUN_YES) {
                _gcal.setInc0M(0);
            }
            if (_gcal.getRemValFlg() == LfcLogicPgConst.KUBUN_YES) {
                _gcal.setRemVAL(0);
            }
            if (_gcal.getRemVRtFlg() == LfcLogicPgConst.KUBUN_YES) {
                _gcal.setRemVRT(0);
            }
            if (_gcal.getLeaseMFlg() == LfcLogicPgConst.KUBUN_YES) {
                _gcal.setLeaseM(0);
            }
            //LsCalComm.setResultDisplayFlag(false);

            return errMsglist;

            //＜０：警告
        } else if (_nRet < 0) {
            _nWrng = Math.abs(_nRet);
        }

        nWcnt = 0;
        dWsvinc = 0;
        nWsvFrq = 0;
        nWlTerm = (int) Math.floor(_gcal.getInc0M() + 0.999);
        for (int i = 0; i < LfcLogicPgConst.STAIRS_MAX_COUNT; i++) {
            if (!_stairs.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                continue;
            }
            nWcnt = nWcnt + 1;
            if (nWcnt == 2 && nWsvFrq == 1 && dWsvinc == _stairs.getIncome(i) * 2) {
                nWlTerm = nWlTerm + 1;
            }
            nWlTerm = nWlTerm + _stairs.getCycle(i) * _stairs.getFreque(i);
            dWsvinc = _stairs.getIncome(i);
            nWsvFrq = _stairs.getFreque(i);
        }
//PZK ADD 2004/11/08 START
//        if(_gcal.getLeaseM() != nWlTerm) {
//リース月数≦回収完了月-検収予定月
        if (_gcal.getLeaseM() < nWlTerm) {
            _nWrng = 6;
        }
//PZK ADD 2004/11/08 END

        //採算項目（率）調整
        AdjProfRate(false);

        dRemVal = _gcal.getRemVAL();
        dRemVRt = _gcal.getRemVRT();
        dInterP = _gcal.getInterP();
        dInterI = _gcal.getInterI();
        dCharge = _gcal.getCharge();
        dExecC = _gcal.getExecC();
        dKurino1 = _gcal.getKurino1();
        dInsur = _gcal.getInsur();
        dDosoF = _gcal.getDosoF();
        dCostT = _gcal.getCostT();
        dProfT = _gcal.getProfT();
        dProfY = _gcal.getProfY();
        dCapitT = _gcal.getCapitT();
        dNetRt = _gcal.getNetRt();
        dTrueRt = _gcal.getTrueRT();
        dRateROI = _gcal.getRateROI();
        dRateUn = _gcal.getRateUN();
        dRateYr = _gcal.getRateYr();
        dRyortT = _gcal.getRyortT();
        dRyortM = _gcal.getRyortM();
        dRtPrT = _gcal.getRtPrT();
        dRtPrY = _gcal.getRtPrY();
        dDamFa = _gcal.getDamFa();
        dDamLa = _gcal.getDamLa();
        dFinanceMargin = _gcal.getFinanceMargin();
        dPvFinanceMargin = _gcal.getPvFinanceMargin();
        dRaMargin = _gcal.getRaMargin();
        dRaPvMargin = _gcal.getRaPvMargin();
        dROE = _gcal.getROE();

        if (_gcal.getRemVAL() != 0) {
            _gcal.setRemVAL(0);
            _gcal.setRemVRT(0);
            _gcal.setInc0Flg(LfcLogicPgConst.KUBUN_NO);
            _gcal.setInc0MFlg(LfcLogicPgConst.KUBUN_NO);
            _gcal.setRemValFlg(LfcLogicPgConst.KUBUN_NO);
            _gcal.setRemVRtFlg(LfcLogicPgConst.KUBUN_NO);
            lmkCash.setPara(_gcal, _stairs, _cashFl);
            lmkCash.doCalculate();
            //LsCalComm.LmkCash.setPara(_gcal, _stairs, _cashFl);
            //LsCalComm.LmkCash.doCalculate();

            LsCalLproCal lprocal = new LsCalLproCal();
            lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
            lprocal.doCal();
            //LsCalComm.Lprocal.setPara(_gcal, _stairs, _cashFl, _paydiv);
            //LsCalComm.Lprocal.doCal();
            AdjProfRate(true);
        }
        _gcal.setFIntP(_gcal.getInterP());
        _gcal.setFIntI(_gcal.getInterI());
        _gcal.setFCharge(_gcal.getCharge());
        _gcal.setFExecC(_gcal.getExecC());
        _gcal.setFKuri1(_gcal.getKurino1());
        _gcal.setFInsur(_gcal.getInsur());
        _gcal.setFCostT(_gcal.getCostT());
        _gcal.setFProT(_gcal.getProfT());
        _gcal.setFProY(_gcal.getProfY());
        _gcal.setFCapT(_gcal.getCapitT());
        _gcal.setFTrueRT(_gcal.getTrueRT());
        _gcal.setFRtYr(_gcal.getRateYr());
        _gcal.setFRtRoi(_gcal.getRateROI());
        _gcal.setFRtUn(_gcal.getRateUN());
        _gcal.setFRtPrt(_gcal.getRtPrT());
        _gcal.setFRtPry(_gcal.getRtPrY());
        _gcal.setFFinanceMargin(_gcal.getFinanceMargin());
        _gcal.setFPvFinanceMargin(_gcal.getPvFinanceMargin());
        _gcal.setFRaMargin(_gcal.getRaMargin());
        _gcal.setFRaPvMargin(_gcal.getRaPvMargin());
        _gcal.setFROE(_gcal.getROE());

        _gcal.setRemVAL(dRemVal);
        _gcal.setRemVRT(dRemVRt);
        _gcal.setInterP(dInterP);
        _gcal.setInterI(dInterI);
        _gcal.setCharge(dCharge);
        _gcal.setExecC(dExecC);
        _gcal.setKurino1(dKurino1);
        _gcal.setInsur(dInsur);
        _gcal.setDosoF(dDosoF);
        _gcal.setCostT(dCostT);
        _gcal.setProfT(dProfT);
        _gcal.setProfY(dProfY);
        _gcal.setCapitT(dCapitT);
        _gcal.setNetRt(dNetRt);
        _gcal.setRateUN(dRateUn);
        _gcal.setTrueRT(dTrueRt);
        _gcal.setRateYr(dRateYr);
        _gcal.setRateROI(dRateROI);
        _gcal.setRyortT(dRyortT);
        _gcal.setRyortM(dRyortM);
        _gcal.setRtPrT(dRtPrT);
        _gcal.setRtPrY(dRtPrY);
        _gcal.setFinanceMargin(dFinanceMargin);
        _gcal.setPvFinanceMargin(dPvFinanceMargin);
        _gcal.setRaMargin(dRaMargin);
        _gcal.setRaPvMargin(dRaPvMargin);
        _gcal.setDamFa(dDamFa);
        _gcal.setDamLa(dDamLa);
        _gcal.setPurchasFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setInc0Flg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setInc0MFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setRemValFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setRemVRtFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setLeaseMFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setRyortTFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setROE(dROE);

        if (_gcal.getEvenFlg() == 1) {
            _gcal.setRyortMFlg(LfcLogicPgConst.KUBUN_NO);
        } else {
            _gcal.setRyortMFlg(LfcLogicPgConst.KUBUN_YES);
        }
        _gcal.setRateUnFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setRateROIFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setTrueRtFlg(LfcLogicPgConst.KUBUN_NO);
		if(_gcal.getCriRt() > 0){
			if ( _gcal.getLeaseM() < 36 || _gcal.getLeaseM() > 120){
			errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR127, "ERR127", errMsglist);
			}
			//回収情報テーブル(
			if(_gcal.getIncGt() < 3000000 || _gcal.getIncGt() > 50000000){
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR129, "ERR129", errMsglist);
			}
		}
        _nRet = 0;
        if (_nWrng == 1) {
            //リース信用保険の適用を取りやめました。
            //errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN001, "WRN001", errMsglist);
        } else if (_nWrng == 2) {
            //リース信用保険を適用しました。
            //errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN002, "WRN002", errMsglist);

        } else if (_nWrng == 3) {
            //指定された採算項目を調整しました。
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN003, "WRN003", errMsglist);

        } else if (_nWrng == 4) {
            //リース信用保険の適用を取りやめ、指定された採算項目を調整しました。
            //errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN004, "WRN004", errMsglist);
        } else if (_nWrng == 5) {
            //リース信用保険を適用し、指定された採算項目を調整しました。
            //errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN005, "WRN005", errMsglist);

        } else if (_nWrng == 6) {
//PZK 2004.08.12 START
            //リース月数と回収月数が合いません。再確認してください。
            //リース月数と総回収月数が合っていませんが要求された計算が行われました。問題なければ登録して下さい。
//			PZK 2004.11.08 START
            //回収期日がリース期間を超えています。問題がなければ登録して下さい。
//			PZK 2004.11.08 END
//PZK 2004.08.12 END


//			LfcMessageBox.show(null,LfcLogicMsgConst.ERR084,"メッセージ",JOptionPane.ERROR_MESSAGE);

            //SubOut 計算のパスために、0をセットする
            //pzk 20051018 s
            _nWrng = 0;
            //pzk 20051018 e
        }

        return errMsglist;
    }

    /*================================= */
    /*        採算項目（率）調整        */
    /*================================= */
    private ArrayList<ErrorInforOutputComplexType> AdjProfRate(boolean bFullPay) {
        //display message or not
        boolean bDisplayMsg = false;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        _gcal.setRyortT(LfcLogicComm.dround(_gcal.getRyortT(), 5));
        if (_gcal.getRyortT() > 9.99999) {
            _gcal.setRyortT(9.99999);
//			bDisplayMsg = true;
        }
        if (_gcal.getRyortT() < -9.99999) {
            _gcal.setRyortT(-9.99999);
//			bDisplayMsg = true;
        }
        _gcal.setRyortM(LfcLogicComm.dround(_gcal.getRyortM(), 5));
        if (_gcal.getRyortM() > 9.99999) {
            _gcal.setRyortM(9.99999);
//			bDisplayMsg = true;
        }
        if (_gcal.getRyortM() < -9.99999) {
            _gcal.setRyortM(-9.99999);
//			bDisplayMsg = true;
        }
        _gcal.setRateUN(LfcLogicComm.dround(_gcal.getRateUN(), 4));
        if (_gcal.getRateUN() > 0.9999) {
            _gcal.setRateUN(0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRateUN() < -0.9999) {
            _gcal.setRateUN(-0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRateYr() == 0.9999 || _gcal.getRateYr() <= 0) {
            _gcal.setRateROI(_gcal.getRateYr());
        } else {
//			20040810 ljq change s
//					 _gcal.setRateROI(LfcLogicComm.dround(_gcal.getRateYr() * LfcLogicPgConst.USA_PERSON_TAX, 4));
            _gcal.setRateROI(LfcLogicComm.dround(LfcLogicComm.dround(_gcal.getProfT() / _gcal.getCapitT(), 5) * LfcLogicPgConst.USA_PERSON_TAX, 4));
//			20040810 ljq change e
        }
        if (_gcal.getRateROI() < -0.9999) {
            _gcal.setRateROI(-0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRateROI() > 0.9999) {
            _gcal.setRateROI(0.9999);
            bDisplayMsg = true;
        }
//20040830 ljq add s
        if (_gcal.getRateROI() == 0) {
            _gcal.setROE(0.0);
        } else if (_gcal.getRateROI() >= 0.9999) {
            _gcal.setROE(0.9999);
        } else if (_gcal.getRateROI() <= -0.9999) {
            _gcal.setROE(-0.9999);
        } else {
            _gcal.setROE(LfcLogicComm.dround((_gcal.getLeverage() + 1) * _gcal.getRateROI(), 4));
        }
//      pzk   modi 20050513 start
        if (_gcal.getROE() >= 10) {
            _gcal.setROE(9.9999);
        }
        if (_gcal.getROE() <= -10) {
            _gcal.setROE(-9.9999);
        }
//		if(_gcal.getROE() <= -99.9999) {
//			_gcal.setROE(-99.9999);
//		}
//		if(_gcal.getROE() >= 99.9999) {
//			_gcal.setROE(99.9999);
//		}
//      pzk   modi 20050513 start
//20040830 ljq add e
        _gcal.setRateYr(LfcLogicComm.dround(_gcal.getRateYr(), 4));
        if (_gcal.getRateYr() > 0.9999) {
            _gcal.setRateYr(0.9999);
        }
        if (_gcal.getRateYr() < -0.9999) {
            _gcal.setRateYr(-0.9999);
        }
        _gcal.setRtPrT(LfcLogicComm.dround(_gcal.getRtPrT(), 4));
        if (_gcal.getRtPrT() > 0.9999) {
            _gcal.setRtPrT(0.9999);
        }
        if (_gcal.getRtPrT() < -0.9999) {
            _gcal.setRtPrT(-0.9999);
        }
        _gcal.setRtPrY(LfcLogicComm.dround(_gcal.getRtPrY(), 4));
        if (_gcal.getRtPrY() > 0.9999) {
            _gcal.setRtPrY(0.9999);
        }
        if (_gcal.getRtPrY() < -0.9999) {
            _gcal.setRtPrY(-0.9999);
        }
        _gcal.setTrueRT(LfcLogicComm.dround(_gcal.getTrueRT(), 4));
        if (_gcal.getTrueRT() > 0.9999) {
            _gcal.setTrueRT(0.9999);
        }
        if (_gcal.getTrueRT() < -0.9999) {
            _gcal.setTrueRT(-0.9999);
            bDisplayMsg = true;
        }
        //ljq add
        if (_gcal.getRaMargin() > 0.9999) {
            _gcal.setRaMargin(0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getRaMargin() < -0.9999) {
            _gcal.setRaMargin(-0.9999);
            bDisplayMsg = true;
        }

        if (_gcal.getFinanceMargin() > 0.9999) {
            _gcal.setFinanceMargin(0.9999);
            bDisplayMsg = true;
        }
        if (_gcal.getFinanceMargin() < -0.9999) {
            _gcal.setFinanceMargin(-0.9999);
            bDisplayMsg = true;
        }
        if (bDisplayMsg == true && bFullPay == false) {
            //"前受リース料／頭金が大きいため採算項目は99.99で表示します。\nその他の計算は正しく行われました。問題がなければ登録して下さい。";
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR120,"ERR120",errMsglist);
        }
        return errMsglist;
    }
}
