/*
 * @(#)LsCalCashFlow.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.Stairs;

public class LsCalLmkCash {
    private Gcal _gcal;
    private Stairs _stairs;
    private CashFl _cashFl;

    public LsCalLmkCash() {

    }

    public void setPara(Gcal gcal, Stairs stairs, CashFl cashFl) {
        _gcal = gcal;
        _stairs = stairs;
        _cashFl = cashFl;
    }

    public void doCalculate() {
        int nLastCol;               //
        int nCycle;
        int nFreque;
        int nCycleI;
        int nFrequeJ;
        int MM;
        int DD;
        double dIncome;
        long lCheckDate;
        long lIoM;
        int nCashCnt;
        int nRowTop;
        int nRowCnt;

        _gcal.setDivfreq(0);
        _gcal.setIncT(0);

        nCashCnt = 0;
        nRowTop = 0;
        nRowCnt = 0;
        nLastCol = 0;

        for(int i = 0; i < LfcLogicPgConst.STAIRS_MAX_COUNT; i++) {
            if(_stairs.getAct(i)  == LfcLogicPgConst.KUBUN_YES) {
                nRowTop = i;
                break;
            }
        }
        _stairs.setTopRow(nRowTop);

        lCheckDate = LfcLogicComm.db3Year(_gcal.getDKensh()) * 12L + LfcLogicComm.db3Month(_gcal.getDKensh()) - 1;
        for(int i = _stairs.getTopRow(); i < LfcLogicPgConst.STAIRS_MAX_COUNT; i++) {
            if(_stairs.getAct(i) == LfcLogicPgConst.KUBUN_NO) {
                continue;
            }
            nLastCol = i;
            if(_stairs.getIncome(i) == LfcLogicPgConst.STAIRS_NO_INCOME) {
                dIncome = 0;
            } else {
                dIncome = _stairs.getIncome(i);
            }
            nCycle = _stairs.getCycle(i);
            nFreque = _stairs.getFreque(i);

            //分割回数の算出
            _gcal.setDivfreq(_gcal.getDivfreq() + nFreque);

            //ﾘｰｽ料総額の算出
            _gcal.setIncT(_gcal.getIncT() + dIncome * nFreque);

            nCycleI = (int)((_stairs.getDateYY(i) * 12L + _stairs.getDateMM(i)) - lCheckDate - 1);
            while(nCycleI > 0) {
                clrCashf(nCashCnt);
                nCashCnt = nCashCnt + 1;
                nCycleI = nCycleI - 1;
            }

            nCycleI = nFreque;
            while(nCycleI > 0) {
                clrCashf(nCashCnt);
                _cashFl.setIncome(dIncome, nCashCnt);
                nCashCnt = nCashCnt + 1;
                nFrequeJ = nCycle - 1;
                while(nFrequeJ > 0 && nCycleI != 1) {
                    clrCashf(nCashCnt);
                    nCashCnt = nCashCnt + 1;
                    nFrequeJ = nFrequeJ - 1;
                }
                nCycleI = nCycleI - 1;
            }
            lCheckDate = _stairs.getDateYY(i) * 12L + _stairs.getDateMM(i)
                                + (_stairs.getFreque(i) - 1) * _stairs.getCycle(i);
        }
        nRowCnt = nLastCol + 1;
        _stairs.setRowCount(nRowCnt);

        MM = _stairs.getDateMM(nLastCol) + (_stairs.getFreque(nLastCol) - 1)
                    * _stairs.getCycle(nLastCol);
        _gcal.setFidtIn(LfcLogicComm.db3Itod(_stairs.getDateYY(nLastCol), MM, 1));

        MM = LfcLogicComm.db3Month(_gcal.getFidtIn());
        DD = _stairs.getDateDD(nLastCol);
        if(DD != LfcLogicComm.db3Day(LfcLogicComm.db3Itod(LfcLogicComm.db3Year(_gcal.getFidtIn()), MM, DD))) {
            MM = MM + 1;
            DD = 0;
        }
        _gcal.setFidtIn(LfcLogicComm.db3Itod(LfcLogicComm.db3Year(_gcal.getFidtIn()), MM, DD));

        if(_gcal.getInc0() != 0) {
            lIoM = LfcLogicComm.db3Year(_gcal.getDInc0()) * 12L + LfcLogicComm.db3Month(_gcal.getDInc0())
                        - (LfcLogicComm.db3Year(_gcal.getDKensh()) * 12L + LfcLogicComm.db3Month(_gcal.getDKensh())) + 1;

            while(nCashCnt < lIoM) {
                clrCashf(nCashCnt);
                nCashCnt = nCashCnt + 1;
            }
            _cashFl.setIncome(_cashFl.getIncome((int)(lIoM - 1)) + _gcal.getInc0(), (int)(lIoM - 1));
        }

        while(nCashCnt < _gcal.getLeaseM() + 2) {
            clrCashf(nCashCnt);
            nCashCnt = nCashCnt + 1;
        }
        _cashFl.setCashCnt(nCashCnt);
    }

    private void clrCashf(int nCashFlowPos) {
        _cashFl.setCashFlow(0, nCashFlowPos);
        _cashFl.setIncome(0, nCashFlowPos);
    }
}
