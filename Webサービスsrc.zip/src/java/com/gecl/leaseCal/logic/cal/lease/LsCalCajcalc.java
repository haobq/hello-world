/*
 * @(#)LsCalCajcalc.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;

/**
 * 原価調整額算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/05/20
 * @since   01-01
 */
public class LsCalCajcalc {
    /** Gcalbean */
    Gcal _gcal = null;
    /** 支払情報bean */
    Paydiv _paydiv = null;

    /**
     * コンストラクタ．     <BR>
     */
    public LsCalCajcalc() {
    }

    /**
     * オブジェクトをセットする．     <BR>
     * Gcal・支払情報を渡す。
     * @param gcal	Gcalオブジェクト
     * @param paydiv	支払情報オブジェクト
     */
    public void setPara(Paydiv paydiv, Gcal gcal) {
        _gcal = gcal;
        _paydiv = paydiv;
    }

    /**
     *原価調整額算出を行う． <BR>
     *
     */
    public void doCalculate() {
        int    nPaydivPos;                  //
        double dWsD;
        double dWAdj;                       //原価調整額
        long   lWdpay;

    	// 分割支払有無区分の判定
        if (_gcal.getSwPay() == LfcLogicPgConst.KUBUN_YES) {
            //原価調整額を設定
            _gcal.setCAdj(0);
            dWsD = 0;
            //支払情報行數最大値として循環算出
            for (nPaydivPos = 0;nPaydivPos < LfcLogicPgConst.PAYDIV_MAX_COUNT; ++nPaydivPos) {
                //有効区分判定
                if (!_paydiv.getAct(nPaydivPos)) {
                    continue;
                }
                //支払日（年月）＞検収予定日（年月）
                if (_paydiv.getDateYY(nPaydivPos) * 100L + _paydiv.getDateMM(nPaydivPos)
                    > LfcLogicComm.db3Year(_gcal.getDKensh()) * 100L
                    + LfcLogicComm.db3Month(_gcal.getDKensh())) {
                    //支払日（年月日）を取得
                    lWdpay = LfcLogicComm.db3Itod(_paydiv.getDateYY(nPaydivPos),
                                          _paydiv.getDateMM(nPaydivPos),
                                          _paydiv.getDateDD(nPaydivPos) + 1);

                    //原価調整月数を設定
                    _gcal.setAdjM((LfcLogicComm.db3Year(lWdpay)
                               - LfcLogicComm.db3Year(_gcal.getDKensh())) * 12
                               + LfcLogicComm.db3Month(lWdpay)
                               - LfcLogicComm.db3Month(_gcal.getDKensh()) -1 );

                    //原価調整日数を設定
                    _gcal.setAdjD(LfcLogicComm.db3Day(lWdpay) - 1);
                } else {

                    //支払日（年月日）を取得
                    lWdpay = LfcLogicComm.db3Itod(_paydiv.getDateYY(nPaydivPos),
                                          _paydiv.getDateMM(nPaydivPos),
                                          _paydiv.getDateDD(nPaydivPos));

                    //原価調整月数を設定
                    _gcal.setAdjM((LfcLogicComm.db3Year(lWdpay)
                               - LfcLogicComm.db3Year(_gcal.getDKensh())) * 12
                               + LfcLogicComm.db3Month(lWdpay)
                               - LfcLogicComm.db3Month(_gcal.getDKensh()));
                    //原価調整日数を設定
                    _gcal.setAdjD(LfcLogicComm.db3Day(lWdpay)
                               - LfcLogicComm.dtLast(LfcLogicComm.db3Year(lWdpay), LfcLogicComm.db3Month(lWdpay)));
                }
                //原価調整額を算出
                dWAdj = _paydiv.getPurchas(nPaydivPos)
                        * Math.pow((1 + _gcal.getRateCADJ() / 12), (double)Math.abs(_gcal.getAdjM()))
                        * (1 + _gcal.getRateCADJ() / 365 * Math.abs(_gcal.getAdjD()))
                        - _paydiv.getPurchas(nPaydivPos);

                //小数点以下四捨五入
                dWAdj = LfcLogicComm.dround(dWAdj, 0);
                //マイナス調整
                if (_gcal.getAdjM() < 0 || _gcal.getAdjD() < 0) {
                    dWAdj = dWAdj * -1;
                }
                //原価調整額を設定
                _gcal.setCAdj(_gcal.getCAdj() + dWAdj);

                dWsD = dWsD + (_gcal.getAdjM() * 30 + _gcal.getAdjD()) * _paydiv.getPurchas(nPaydivPos);
            }
            dWsD = LfcLogicComm.dround(dWsD / _gcal.getPurchas(), 0);
            _gcal.setAdjM((int)(Math.floor(Math.abs(dWsD) / 30 + 0.01)));
            _gcal.setAdjD((int)(Math.abs(dWsD) % 30.0));
            if (dWsD < 0) {
                _gcal.setAdjM(_gcal.getAdjM() * -1);
                _gcal.setAdjD(_gcal.getAdjD() * -1);
            }
        } else {
            //支払予定日（年月）＞検収予定日（年月）
            if (LfcLogicComm.db3Year(_gcal.getDPaymt()) * 100L
                    + LfcLogicComm.db3Month(_gcal.getDPaymt())
                    > LfcLogicComm.db3Year(_gcal.getDKensh()) * 100L
                    + LfcLogicComm.db3Month(_gcal.getDKensh())) {
                //支払予定日（年月日）を取得
                lWdpay = LfcLogicComm.db3Itod(LfcLogicComm.db3Year(_gcal.getDPaymt()),
                                      LfcLogicComm.db3Month(_gcal.getDPaymt()),
                                      LfcLogicComm.db3Day(_gcal.getDPaymt()) + 1);
                //原価調整月数を設定
                _gcal.setAdjM((LfcLogicComm.db3Year(lWdpay)
                            - LfcLogicComm.db3Year(_gcal.getDKensh())) * 12
                            + LfcLogicComm.db3Month(lWdpay)
                            - LfcLogicComm.db3Month(_gcal.getDKensh()) - 1);
               //原価調整日数を設定
                _gcal.setAdjD(LfcLogicComm.db3Day(lWdpay) - 1);
            } else {
                //原価調整月数を設定
                _gcal.setAdjM((LfcLogicComm.db3Year(_gcal.getDPaymt())
                            - LfcLogicComm.db3Year(_gcal.getDKensh())) * 12
                            + LfcLogicComm.db3Month(_gcal.getDPaymt())
                            - LfcLogicComm.db3Month(_gcal.getDKensh()));
                //原価調整日数を設定
                _gcal.setAdjD(LfcLogicComm.db3Day(_gcal.getDPaymt())
                           - LfcLogicComm.dtLast(LfcLogicComm.db3Year(_gcal.getDPaymt()), LfcLogicComm.db3Month(_gcal.getDPaymt())));

            }

            //原価調整額を算出
            _gcal.setCAdj(_gcal.getPurchas()
                       * Math.pow((1 + _gcal.getRateCADJ()/ 12), (double)Math.abs(_gcal.getAdjM()))
                       * (1 + _gcal.getRateCADJ()/ 365 * Math.abs(_gcal.getAdjD()))
                       - _gcal.getPurchas());

            //小数点以下四捨五入
            _gcal.setCAdj(LfcLogicComm.dround(_gcal.getCAdj() + 0.0001, 0));
            if (_gcal.getAdjM() < 0 || _gcal.getAdjD() < 0) {
                _gcal.setCAdj(_gcal.getCAdj() * -1);
            }
        }
    }
}