/*
 * @(#)KpCalProcalc.java      01-01  2003/06/12
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.kappu;


import com.gecl.leaseCal.logic.cal.lease.LsCalCajcalc;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.Stairs;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


/**
 * 採算項目算出Bean。
 * @author  王嵩
 * @version 01-01、 2003/06/13
 * @since   01-01
 * hbq 20050422 TRが計算不能　あとで　採算できない問題を修正
 */
public class KpCalProcalc {

    //GcalBean
    private Gcal _gcal;
    //CashFlBean
    private CashFl _cashFl;
    //回収情報Bean
    private Stairs _stairs;
    //支払情報Bean
    private Paydiv _paydiv;
    //通常・ﾌﾙﾍﾟｲｱｳﾄ区分
    private int _nFpay;
    //最終段を格納する変数
    private int _nEndActRow;
    //採算実行成功かどうかのフラグ
    private int _nRet = 0;

    /**
     * コンストラクタ．     <BR>
     */
    public KpCalProcalc() {
    }

    /**
     * パラメータのセット
     * Gcal・CashFlow・回収情報・支払情報を渡す。
     */
    public void setPara(Gcal gcal, Stairs stairs, CashFl cashFl, Paydiv paydiv) {
        _gcal = gcal;
        _cashFl = cashFl;
        _stairs = stairs;
        _paydiv = paydiv;
        //hbq 20050422 TRが計算不能　あとで　採算できない問題を修正　begin
        _nRet = 0;
        //hbq 20050422 TRが計算不能　あとで　採算できない問題を修正　end

    }

    /**
     * 採算実行成功かどうかのフラグを戻す． <BR>
     * @return  int 0:成功
     *              1:ＴＲが算出不能です。
     *             -1:信保付保区分が正しくない（古い信保付保区分＝１　&& 信保付保区分＝2）。
     *             -２:信保付保区分が正しくない（古い信保付保区分＝２　&& 信保付保区分＝１）。
     */
    public int getRet() {
        return _nRet;
    }

    public void setFpay(int nFpay) {
        _nFpay = nFpay;
    }

    /**
     * 採算項目算出のメソッド．     <BR>
     */
    public void doCal() {
        doLproCal();
        //doRoiCal();
        setFpay(0);
        doFinanceMarginCal();
        doPvFinanceMarginCal();
        doRaMarginCal();
        doRaPvMarginCal();
    }

    /**
     * 採算項目算出のメソッド．     <BR>
     */
    public ArrayList<ErrorInforOutputComplexType> doLproCal() {
        //信保付保区分を格納する変数
        String strWsaCsw;

        //第n段のCashFlowの計算値を格納
        double dWmzan = 0;
        //CashFlowから計算値を格納
        double dWzant = 0;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        //信保付保区分を格納する
        strWsaCsw = _gcal.getSwCri();
        //契約額
        _gcal.setIncGt(_gcal.getInc0() + _gcal.getIncT());
        //保険料（計）算出
        KpCalInscalc KpInscalc = new KpCalInscalc();
        KpInscalc.setPara(_gcal);
        KpInscalc.doCalculate();

        //団信保険料算出
        KpCalDnscalc KpDnscalc = new KpCalDnscalc();
        KpDnscalc.setPara(_gcal, _stairs, _cashFl);
        KpDnscalc.doCalculate();
        //少額資産区分=‘1’

        //割賦信用保険算出
        //KpCalComm.KpCricalc.setPara(_gcal, _stairs, _cashFl);
        //KpCalComm.KpCricalc.doCalculate();

        //初期費用を計算
        _gcal.setInitC(_gcal.getIchiji1() + _gcal.getIchiji2() + _gcal.getIchiji3() + _gcal.getAssen());
        //実行費用総額を計算
        _gcal.setExecC(_gcal.getInsur() + _gcal.getKappuI() + _gcal.getKurino1() +
                _gcal.getKurino2() + _gcal.getHoshury());
        //ＮＥＴ率を計算
        _gcal.setNetRt(1 - _gcal.getExecC() / _gcal.getIncGt() * 1.0000000);
        //回収利息を計算
        _gcal.setInterI(LfcLogicComm.dround(_gcal.getIncT() * _gcal.getNetRt() -
                (_gcal.getPurchas() + _gcal.getInitC() - _gcal.getInc0() * _gcal.getNetRt()), 0));

        //割賦月数 ＝１
        if (_gcal.getKappuM() == 1) {
            _gcal.setTrueRT(-0.9999);
        } else {
            KpCalTrcalc KpTrcalc = new KpCalTrcalc();
            KpTrcalc.setPara(_gcal, _cashFl);
            //ＴＲＵＥ＿ＲＡＴＥ算出
            KpTrcalc.doCalculate();
            if (KpTrcalc.getRet() != 0) {
                _nRet = 1;
                //throw new Exception("ＴＲが算出不能です。計算条件を確認して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR085, "ERR085", errMsglist);
                //信保付保区分＝古い信保付保区分
                _gcal.setSwCri(strWsaCsw);
                return errMsglist;   //TRが算出不能フラグ
            }
        }

        //割賦月数 ＝１
        if (_gcal.getKappuM() == 1) {
            _gcal.setInterP(0);
        } else {
            if (Math.abs(_gcal.getTrueRT()) < 1e-10) {
                dWmzan = 0;
                dWzant = 0;
                for (int i = 0; i < _cashFl.getCashCnt(); i++) {
                    //第n段のCashFlowの計算値を格納
                    dWmzan = dWmzan - _cashFl.getCashFlow(i);
                    //CashFlowから計算値を格納
                    dWzant = dWzant + dWmzan;
                }
                //支払利息を計算
                _gcal.setInterP(LfcLogicComm.dround(dWzant * _gcal.getRateJL() / 12, 0));
            } else {
                //支払利息を計算
                _gcal.setInterP(LfcLogicComm.dround(_gcal.getInterI() * _gcal.getRateJL() / _gcal.getTrueRT(), 0));
            }
        }
        //割賦原価計を計算
        _gcal.setCostT(_gcal.getPurchas() + _gcal.getInterP() +
                _gcal.getInitC() + _gcal.getExecC());
        //当社手数料を計算
        _gcal.setCharge(_gcal.getIncGt() - _gcal.getCostT());
        //原価調整額
        LsCalCajcalc Cajcalc = new LsCalCajcalc();
        Cajcalc.setPara(_paydiv, _gcal);
        Cajcalc.doCalculate();
        //荒利益額を計算
        _gcal.setProfT(_gcal.getCharge() + _gcal.getCAdj());
        //割賦月数>12
        if (_gcal.getKappuM() > 12) {
            //年荒利益額を計算
            _gcal.setProfY(LfcLogicComm.dround(_gcal.getProfT() / _gcal.getKappuM() * 12, 0));
        } else {
            _gcal.setProfY(_gcal.getProfT());
        }
        //使用総資金を計算
        _gcal.setCapitT(LfcLogicComm.dround(_gcal.getInterP() / _gcal.getRateJL(), 0));
        //総荒利率を計算
//20040530 ljq change start
/*
        _gcal.setRtPrT(LfcLogicComm.dround(_gcal.getProfT() / _gcal.getPurchas(), 2));
        if (_gcal.getKappuM() > 12) {
        //年荒利率を計算
        _gcal.setRtPrY(LfcLogicComm.dround(_gcal.getProfT() / _gcal.getPurchas() / _gcal.getKappuM() *12, 2));
        }else {
        _gcal.setRtPrY(_gcal.getRtPrT());
        }
         */
        _gcal.setRtPrT(LfcLogicComm.dround(_gcal.getProfT() / _gcal.getPurchas(), 4));
        if (_gcal.getKappuM() > 12) {
            //年荒利率を計算
            _gcal.setRtPrY(LfcLogicComm.dround(_gcal.getProfT() / _gcal.getPurchas() / _gcal.getKappuM() * 12, 4));
        } else {
            _gcal.setRtPrY(_gcal.getRtPrT());
        }
//20040530 ljq change end
        if (_gcal.getKappuM() == 1) {
            //年利回りを-99.99にする
            _gcal.setRateYr(-0.9999);
        } else {
            //年利回りを計算
//20040816 ljq chagne s
            _gcal.setRateYr(_gcal.getInterP() == 0 ? 0.9999 : LfcLogicComm.dround(_gcal.getProfT() / _gcal.getInterP() * _gcal.getRateJL(), 4));
//			_gcal.setRateYr(_gcal.getInterP() == 0 ? 0.9999 : LfcLogicComm.dround(_gcal.getProfT() / _gcal.getInterP() * _gcal.getRateJL(), 5));
//20040816 ljq change e
        }

        //残価=0、CashFlowの各段の金額=0 && 割賦月数 ＝１
        if (_gcal.getKappuM() == 1) {
            //運用利回りを-99.99にする
            _gcal.setRateUN(-0.9999);
        } else {
            //運用利回りを計算
            _gcal.setRateUN(_gcal.getInterP() == 0 ? 0.9999 : _gcal.getRateJL() + _gcal.getRateYr());
        }
        //合計料率
        _gcal.setRyortT(_gcal.getIncGt() / _gcal.getPurchas());
        //均等回収の場合
        if (_gcal.getEvenFlg() == 1) {
            //月料率を計算
            _gcal.setRyortM(_gcal.getIncT() / _gcal.getDivfreq() / _gcal.getPurchas());
        } else {
            //月料率を0にする
            _gcal.setRyortM(0);
        }

        doRoiCal();
        //古い信保付保区分＝１　&& 信保付保区分＝2
        if ("1".equals(strWsaCsw) && "2".equals(_gcal.getSwCri())) {
            //_gcal.setSwCri("1");
            _nRet = -1;
        }
        //古い信保付保区分＝２　&& 信保付保区分＝１
        if ("2".equals(strWsaCsw) && "1".equals(_gcal.getSwCri())) {
            //_gcal.setSwCri("1");
            _nRet = -2;
        }
        return errMsglist;
    }

    /**
     * Roi算出メソッド． <BR>
     */
    private void doRoiCal() {
        //ROI計
//20040810 ljq delete s
//        _gcal.setRateROI(_gcal.getRateYr() * LfcLogicPgConst.USA_PERSON_TAX);
//		20040810 ljq delete s
    }

    /**
     * FinanceMarginCal算出メソッド． <BR>
     */
    private void doFinanceMarginCal() {
        //FinanceMargin率計算
//        _gcal.setFinanceMargin(_gcal.getRateUN() -
//                              (_gcal.getRateCADJ() + _gcal.getRtLossR() + _gcal.getRtEAniO() - _gcal.getRtFeeN()));//運用利回


        //FinanceMargin率=Yield(運用利回)-COF(原調計算金利)
        _gcal.setFinanceMargin(_gcal.getRateUN() - _gcal.getRateCADJ());
    }

    /**
     * リース案件のPV Finance Margin額の算出メソッド． <BR>
     */
    private void doPvFinanceMarginCal() {
        //Yield額=Yield*使用総資金,  　COF額=COF*使用総資金
        //FinanceMargin額=Yield額-COF額
        double dFinanceMargin;
//        dFinanceMargin = (_gcal.getRateUN() - _gcal.getRateCADJ()) * _gcal.getCapitT();
        dFinanceMargin = LfcFrmComm.dround((LfcFrmComm.dround((_gcal.getRateUN() - _gcal.getRateCADJ()), 4) * LfcFrmComm.dround(_gcal.getCapitT(), 0)), 0);
        _gcal.setPvFinanceMargin(dFinanceMargin);


//        int nCashCnt;                //CASHFLOW発生月数
//        double dNetPercent;          //NET率
//        double dPv;                  //回収額（リース料－実行費用）のＰＶ
//        double dLeasePriod;          //実際のcash flowが発生する期間数（前受けリース料を考慮）
//        double dIncome;              //月々のリース料
//        double dCalcRate;
//        double wk_double;
//        double dTrueRT;              //TR
//        double dExecC;               //実行費用
//        double dRemVAL;              //残価
//        double dProfT;               //総荒利益
//        double dWork_b;
//        double dWork_c;
//        double dWork_1;
//        double dWork_2;
//        /* 1.異常TR（０より小さい）場合
//         * 2.異常TR（１以上）の場合
//         * 3.社内金利＝０の場合
//         * １～３の場合は、荒利額をＰＶ荒利額にセットする。
//         *              （契約額－実行費用）
//         * NET率算出　＝ ------------------  ･･････(A)
//         *                    契約額
//         *
//         * 小数点以下１１桁目を切り捨てる。
//         */
//        dNetPercent = _gcal.getIncGt();
//        dNetPercent = dNetPercent - _gcal.getExecC();
//        dNetPercent = dNetPercent / _gcal.getIncGt();
//        //小数点以下１５桁目を四捨五入
////		dNetPercent = LfcLogicComm.dround(dNetPercent, 14);//14桁を保留
//        /* 回収額（リース料－実行費用）のcash flowを作成し、
//         * 社内金利（÷１２[月利]）によるＰＶを求める。
//         * r＝社内金利÷１２
//         * |---------------------------------------------------------|
//         * |月|その月の回収額(B)|計算率(C)|割引後の回収額(D)=A×B÷C |
//         * |---------------------------------------------------------|
//         * |  |                 |      0  |                          |
//         * |0 |                 |(1÷r)   |                          |
//         * |---------------------------------------------------------|
//         * |  |                 |      1  |                          |
//         * |1 |                 |(1÷r)   |                          |
//         * |---------------------------------------------------------|
//         * |･ |                 |   ･     |                          |
//         * |･ |                 |   ･     |                          |
//         * |･ |                 |   ･     |                          |
//         * |･ |                 |   ･     |                          |
//         * |･ |                 |   ･     |                          |
//         * |---------------------------------------------------------|
//         * |  |                 |      n  |                          |
//         * |n |                 |(1÷r)   |                          |
//         * |---------------------------------------------------------|
//         * 注意：検収月＝０月、契約期間＋１３ヶ月＝ｎ月とする。
//         *    　 前受リース料及び頭金は全て検収月（０月）に回収するとみなす。よって
//         *　 　  前受け充当のある月は、充当額を引いた額をBとしている。
//         */
//        dPv = 0;
//        //算出利率(ＣＯＦ＋貸倒引当率(Origination)－手数料率(NPP))
//        dCalcRate = _gcal.getRateCADJ() + _gcal.getRtLossR() + _gcal.getRtEAniO() - _gcal.getRtFeeN();
//        dCalcRate = dCalcRate / 12;
//        //11桁目を切り捨てる。
//		dCalcRate = LfcLogicComm.doDecCut(dCalcRate, 10);
//        dLeasePriod = _gcal.getKappuM() - 1;
//        KpCalComm.KpMkcash.setPara(_gcal, _stairs, _cashFl);
//        //CASHFLOWの作成（前受リース料含む）
//        KpCalComm.KpMkcash.doCalculate();
//        nCashCnt = _cashFl.getCashCnt();
//        _cashFl.setIncome(_cashFl.getIncome(0) + _gcal.getInc0(), 0);
//
//        for (int loop1 = 0; loop1 <= nCashCnt - 1; loop1++) {
//            dIncome = _cashFl.getIncome(loop1);
//            wk_double = 0;
//            wk_double = dNetPercent * dIncome;
//            if (wk_double != 0) {
//                wk_double = wk_double / (Math.pow(1 + dCalcRate, loop1));
//            }
//
//            //小数点以下７桁目四捨五入
//            wk_double = LfcLogicComm.dround(wk_double, 6);
//            dPv = dPv + wk_double;
//        }
//        //Ｄの総額　＋　原価調整額　・・・・（１）とする
//        dWork_1 = dPv + _gcal.getCAdj();
//        //契約期間　＋　１を･････ａ'とする。
//        dLeasePriod = _gcal.getKappuM() + 1;
//        //購入額＋初期費用・・・・・(2)とする
//        dWork_2 = _gcal.getPurchas() + _gcal.getInitC();
//        //小数点以下７桁目を切り捨て
//        dWork_2 = LfcLogicComm.dround(dWork_2, 6);
//        //円未満を四捨五入
//        dWork_1 = LfcLogicComm.dround(dWork_1 - dWork_2, 0);
//        _gcal.setPvFinanceMargin(dWork_1);
//        _cashFl.setIncome(_cashFl.getIncome(0) - _gcal.getInc0(), 0);
    }

    /**
     * リース案件のRaMargin額の算出メソッド． <BR>
     */
    private void doRaMarginCal() {
        //RaMargin計算
        _gcal.setRaMargin(_gcal.getRateUN() - _gcal.getRateCADJ() - _gcal.getRtLossR());
    }

    /**
     * リース案件のRaPvMargin額の算出メソッド． <BR>
     */
    private void doRaPvMarginCal() {
        int nCashCnt;                //CASHFLOW発生月数
        double dNetPercent;          //NET率
        double dPv;                  //回収額（リース料－実行費用）のＰＶ
        double dLeasePriod;          //実際のcash flowが発生する期間数（前受けリース料を考慮）
        double dIncome;              //月々のリース料
        double dCalcRate;
        double wk_double;
        double dTrueRT;              //TR
        double dExecC;               //実行費用
        double dRemVAL;              //残価
        double dProfT;               //総荒利益
        double dWork_b;
        double dWork_c;
        double dWork_1;
        double dWork_2;
        /* 1.異常TR（０より小さい）場合
         * 2.異常TR（１以上）の場合
         * 3.社内金利＝０の場合
         * １～３の場合は、荒利額をＰＶ荒利額にセットする。
         *              （契約額－実行費用）
         * NET率算出　＝ ------------------  ･･････(A)
         *                    契約額
         *
         * 小数点以下１１桁目を切り捨てる。
         */
        dNetPercent = _gcal.getIncGt();
        dNetPercent = dNetPercent - _gcal.getExecC();
        dNetPercent = dNetPercent / _gcal.getIncGt();
        //小数点以下１５桁目を四捨五入
        dNetPercent = LfcLogicComm.dround(dNetPercent, 14);//14桁を保留
        /* 回収額（リース料－実行費用）のcash flowを作成し、
         * 社内金利（÷１２[月利]）によるＰＶを求める。
         * r＝社内金利÷１２
         * |---------------------------------------------------------|
         * |月|その月の回収額(B)|計算率(C)|割引後の回収額(D)=A×B÷C |
         * |---------------------------------------------------------|
         * |  |                 |      0  |                          |
         * |0 |                 |(1÷r)   |                          |
         * |---------------------------------------------------------|
         * |  |                 |      1  |                          |
         * |1 |                 |(1÷r)   |                          |
         * |---------------------------------------------------------|
         * |･ |                 |   ･     |                          |
         * |･ |                 |   ･     |                          |
         * |･ |                 |   ･     |                          |
         * |･ |                 |   ･     |                          |
         * |･ |                 |   ･     |                          |
         * |---------------------------------------------------------|
         * |  |                 |      n  |                          |
         * |n |                 |(1÷r)   |                          |
         * |---------------------------------------------------------|
         * 注意：検収月＝０月、契約期間＋１３ヶ月＝ｎ月とする。
         *    　 前受リース料及び頭金は全て検収月（０月）に回収するとみなす。よって
         *　 　  前受け充当のある月は、充当額を引いた額をBとしている。
         */
        dPv = 0;
        //算出利率(ＣＯＦ＋貸倒引当率(Origination)－手数料率(NPP))
        dCalcRate = _gcal.getRateCADJ() + _gcal.getRtLossR();
        dCalcRate = dCalcRate / 12;
        //11桁目を切り捨てる。
        dCalcRate = LfcLogicComm.doDecCut(dCalcRate, 10);
        dLeasePriod = _gcal.getKappuM() - 1;
        KpCalMkcash KpMkcash = new KpCalMkcash();
        KpMkcash.setPara(_gcal, _stairs, _cashFl);
        //CASHFLOWの作成（前受リース料含む）
        KpMkcash.doCalculate();
        nCashCnt = _cashFl.getCashCnt();
        _cashFl.setIncome(_cashFl.getIncome(0) + _gcal.getInc0(), 0);

        for (int loop1 = 0; loop1 <= nCashCnt - 1; loop1++) {
            dIncome = _cashFl.getIncome(loop1);
            wk_double = 0;
            wk_double = dNetPercent * dIncome;
            if (wk_double != 0) {
                wk_double = wk_double / (Math.pow(1 + dCalcRate, loop1));
            }

            //小数点以下７桁目四捨五入
            wk_double = LfcLogicComm.dround(wk_double, 6);
            dPv = dPv + wk_double;
        }
        //Ｄの総額　＋　原価調整額　・・・・（１）とする
        dWork_1 = dPv + _gcal.getCAdj();
        //契約期間　＋　１を･････ａ'とする。
        dLeasePriod = _gcal.getKappuM() + 1;

        //ＴＲ･･････ r'とする。
//        wk_tr = (gCALCOM.wTRUE_RT / 100) / 12

        //購入額＋初期費用・・・・・(2)とする
        dWork_2 = _gcal.getPurchas() + _gcal.getInitC();
        //小数点以下７桁目を切り捨て
        dWork_2 = LfcLogicComm.dround(dWork_2, 6);
        //円未満を四捨五入
        dWork_1 = LfcLogicComm.dround(dWork_1 - dWork_2, 0);
        //
        _gcal.setRaPvMargin(dWork_1);
        _cashFl.setIncome(_cashFl.getIncome(0) - _gcal.getInc0(), 0);
    }
}

