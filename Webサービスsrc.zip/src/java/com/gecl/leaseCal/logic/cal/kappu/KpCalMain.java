/*
 * @(#)KpCalMain.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *修正日：20050513
 *修正人：潘正寛
 *修正内容：ROE区分を追加する
 *
 * 修正日時：20051228
 * 修正人　：HBQ
 * 修正内容：指定された採算項目を調整しました時　サブアウトも計算OKに調整
 */
package com.gecl.leaseCal.logic.cal.kappu;

import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Stairs;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.Fixrem;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


public class KpCalMain {

    private Gcal _gcal;
    private CashFl _cashFl;
    private Paydiv _paydiv;
    private Stairs _stairs;
    private Fixrem _fixrem;
    private int _nCalItem;
    private int _nBaseProf;
    private int _nRet;
    private int _nWring;  // hbq 20051228 ADD
    private boolean _bResultDisplayFlag;

    public KpCalMain(Gcal gcal, Paydiv paydiv, Stairs stairs,int nReqItem,int nBaseItem) {
        _gcal = gcal;
        _paydiv = paydiv;
        _stairs = stairs;
        _nCalItem = nReqItem;
        _nBaseProf= nBaseItem;
        //_nCalItem = KpCalComm.getReqItem();
        //_nBaseProf = KpCalComm.getBaseItem();
        _cashFl = new CashFl();
        _fixrem = new Fixrem();
    }

    public int getRet() {
        return _nRet;
    }

    public boolean getResultDisplayFlag() {
        return _bResultDisplayFlag;
    }

    public Gcal getGcal() {
        return _gcal;
    }
    //hbq 20051228 ADD begin

    public int getWring() {
        return _nWring;
    }
    //hbq 20051228 ADD end

    public ArrayList<ErrorInforOutputComplexType> doCalculate(int nReqItem,int nBaseItem) {
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        _gcal.setPurchasFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setInc0Flg(LfcLogicPgConst.KUBUN_NO);
        _bResultDisplayFlag = true;
        switch (_nCalItem) {
            case LfcLogicPgConst.KAP_ITEM_LPRO:
                // 採算項目算出
                break;
            case LfcLogicPgConst.KAP_ITEM_KINGAKU:
                // 回収金額算出
                break;
            case LfcLogicPgConst.KAP_ITEM_KINGAKU_INC0:
                // 回収金額・頭金算出
                _gcal.setInc0Flg(LfcLogicPgConst.KUBUN_YES);
                break;
            case LfcLogicPgConst.KAP_ITEM_INC0:
                // 頭金逆算
                _gcal.setInc0Flg(LfcLogicPgConst.KUBUN_YES);
                break;
            case LfcLogicPgConst.KAP_ITEM_KAISU:
                // 回収回数逆算
                break;
            case LfcLogicPgConst.KAP_ITEM_PUCHARS:
                // 購入価額逆算
                _gcal.setPurchasFlg(LfcLogicPgConst.KUBUN_YES);
                break;
            default:
                //パラメータエラー：　算出項目指定区分エラー
                 errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR076,"ERR076",errMsglist);
                return errMsglist;
        }
        _gcal.setRyortTFlg(LfcLogicPgConst.KUBUN_YES);
        _gcal.setRyortMFlg(LfcLogicPgConst.KUBUN_YES);
        _gcal.setRateUnFlg(LfcLogicPgConst.KUBUN_YES);
        _gcal.setRateROIFlg(LfcLogicPgConst.KUBUN_YES);
        _gcal.setTrueRtFlg(LfcLogicPgConst.KUBUN_YES);
        if (_nCalItem != LfcLogicPgConst.KAP_ITEM_LPRO) {
            switch (_nBaseProf) {
                case LfcLogicPgConst.CAL_BASE_RYORTT:
                    _gcal.setRyortTFlg(LfcLogicPgConst.KUBUN_NO);
                    break;
                case LfcLogicPgConst.CAL_BASE_RYORTM:
                    _gcal.setRyortMFlg(LfcLogicPgConst.KUBUN_NO);
                    break;
                case LfcLogicPgConst.CAL_BASE_RATEUN:
                    _gcal.setRateUnFlg(LfcLogicPgConst.KUBUN_NO);
                    break;
                case LfcLogicPgConst.CAL_BASE_ROI:
                    _gcal.setRateROIFlg(LfcLogicPgConst.KUBUN_NO);
                    break;
//              pzk add 20050513 start
                case LfcLogicPgConst.CAL_BASE_ROE:
                    _gcal.setRateROIFlg(LfcLogicPgConst.KUBUN_NO);
                    break;
//              pzk add 20050513 end
                case LfcLogicPgConst.CAL_BASE_TRUERT:
                    _gcal.setTrueRtFlg(LfcLogicPgConst.KUBUN_NO);
                    break;
                default:
                    //パラメータエラー：　逆算時基準項目エラー
                 errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR077,"ERR077",errMsglist);
                return errMsglist;
            }
        }
        _gcal.setDate1YY(LfcLogicComm.db3Year(_gcal.getDKensh()));
        _gcal.setDate1MM(LfcLogicComm.db3Month(_gcal.getDKensh()));
        _gcal.setDate1DD(LfcLogicComm.db3Day(_gcal.getDKensh()));
        _gcal.setDate2YY(LfcLogicComm.db3Year(_gcal.getDPaymt()));
        _gcal.setDate2MM(LfcLogicComm.db3Month(_gcal.getDPaymt()));
        _gcal.setDate2DD(LfcLogicComm.db3Day(_gcal.getDPaymt()));
        _gcal.setDate3YY(LfcLogicComm.db3Year(_gcal.getDInc0()));
        _gcal.setDate3MM(LfcLogicComm.db3Month(_gcal.getDInc0()));
        _gcal.setDate3DD(LfcLogicComm.db3Day(_gcal.getDInc0()));

        KpCalRdycal Rdycal = new KpCalRdycal(_gcal, _stairs, _paydiv, _cashFl, _fixrem);
        ArrayList<ErrorInforOutputComplexType> errMsgTmp=Rdycal.doCalculate(nReqItem,nBaseItem);
        errMsglist.addAll(errMsgTmp);

        _nRet = Rdycal.getRet();
        _nWring = Rdycal.getWrng();   //hbq 20051228 ADD
        if (!errMsglist.isEmpty()){
            _bResultDisplayFlag = false;
        }else{
            _bResultDisplayFlag = true;
        }
        if (Rdycal.getRet() == 0 && Rdycal.getWrng() != 0) {
            _nRet = -1;
        }
        return errMsglist;
    }
}
