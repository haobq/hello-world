/*
 * @(#)KpCalMkcash.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.kappu;

import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Stairs;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


public class KpCalMkcash {

    private Gcal _gcal; //Gcalbean
    private Stairs _stairs; //回収情報bean
    private CashFl _cashFl; //CashFlbean
    private int _nRet = 0;

    /**
     * コンストラクタ．     <BR>     *
     */
    public KpCalMkcash() {
    }

    /**
     * オブジェクトをセットする．     <BR>
     * Gcal・回収情報・CashFlowを渡す。
     * @param gcal	Gcalオブジェクト
     * @param stairs	回収情報
     * @param cashFl	CashFlオブジェクト
     */
    public void setPara(Gcal gcal, Stairs stairs, CashFl cashFl) {
        _gcal = gcal;
        _stairs = stairs;
        _cashFl = cashFl;
    }

    public int getRet() {
        return _nRet;
    }

    /**
     * CashFlowの算出を行う． <BR>
     *
     * @return
     */
    public ArrayList<ErrorInforOutputComplexType> doCalculate() {
        int nLastCol; //
        int nCycle;
        int nFreque;
        int nCycleI;
        int nFrequeJ;
        int MM;
        int DD;
        double dIncome;
        long lCheckDate;
        long lIoM;
        int nCashCnt;
        int nRowTop;
        int nRowCnt;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        //分割回数（回収）を設定
        _gcal.setDivfreq(0);
        //割賦金総額を設定
        _gcal.setIncT(0);

        nCashCnt = 0;
        nRowTop = 0;
        nRowCnt = 0;
        nLastCol = 0;

        //回收情報行數最大値を取得し、設定する
        for (int i = 0; i < LfcLogicPgConst.STAIRS_MAX_COUNT; i++) {
            if (_stairs.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                nRowTop = i;
                break;
            }
        }
        if (nRowTop == LfcLogicPgConst.STAIRS_MAX_COUNT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR025, "ERR025", errMsglist);
            _nRet = -1;
        }
        _stairs.setTopRow(nRowTop);

        //ＣＡＳＨＦＬＯＷテーブルの設定
        //検収予定日（年、月）
        lCheckDate =
                LfcLogicComm.db3Year(_gcal.getDKensh()) * 12L + LfcLogicComm.db3Month(_gcal.getDKensh()) - 1;
        for (int i = _stairs.getTopRow();
                i < LfcLogicPgConst.STAIRS_MAX_COUNT;
                i++) {
            if (_stairs.getAct(i) == LfcLogicPgConst.KUBUN_NO) {
                continue;
            }
            nLastCol = i;
            // 回収金額の設定
            if (_stairs.getIncome(i) == LfcLogicPgConst.STAIRS_NO_INCOME) {
                dIncome = 0;
            } else {
                dIncome = _stairs.getIncome(i);
            }
            //回収サイクルの設定
            nCycle = _stairs.getCycle(i);
            //回数の設定
            nFreque = _stairs.getFreque(i);

            //分割回数の算出
            _gcal.setDivfreq(_gcal.getDivfreq() + nFreque);

            //ﾘｰｽ料総額の算出
            _gcal.setIncT(_gcal.getIncT() + dIncome * nFreque);
            nCycleI =
                    (int) ((_stairs.getDateYY(i) * 12L + _stairs.getDateMM(i)) - lCheckDate - 1);
            while (nCycleI > 0) {
                clrCashf(nCashCnt);
                nCashCnt = nCashCnt + 1;
                nCycleI = nCycleI - 1;
            }
            nCycleI = nFreque;
            while (nCycleI > 0) {
                clrCashf(nCashCnt);
                _cashFl.setIncome(dIncome, nCashCnt);
                nCashCnt = nCashCnt + 1;
                nFrequeJ = nCycle - 1;
                while (nFrequeJ > 0 && nCycleI != 1) {
                    clrCashf(nCashCnt);
                    nCashCnt = nCashCnt + 1;
                    nFrequeJ = nFrequeJ - 1;
                }
                nCycleI = nCycleI - 1;
            }
            lCheckDate =
                    _stairs.getDateYY(i) * 12L + _stairs.getDateMM(i) + (_stairs.getFreque(i) - 1) * _stairs.getCycle(i);
        }
        nRowCnt = nLastCol + 1;
        _stairs.setRowCount(nRowCnt);
        MM =
                _stairs.getDateMM(nLastCol) + (_stairs.getFreque(nLastCol) - 1) * _stairs.getCycle(nLastCol);
        _gcal.setFidtIn(
                LfcLogicComm.db3Itod(_stairs.getDateYY(nLastCol), MM, 1));
        MM = LfcLogicComm.db3Month(_gcal.getFidtIn());
        //回収日（日）の設定
        DD = _stairs.getDateDD(nLastCol);
        if (DD != LfcLogicComm.db3Day(
                LfcLogicComm.db3Itod(
                LfcLogicComm.db3Year(_gcal.getFidtIn()),
                MM,
                DD))) {
            MM = MM + 1;
            DD = 0;
        }
        //最終回収予定日の設定
        _gcal.setFidtIn(
                LfcLogicComm.db3Itod(
                LfcLogicComm.db3Year(_gcal.getFidtIn()),
                MM,
                DD));
        _gcal.setKappuM(nCashCnt);
        _cashFl.setCashCnt(nCashCnt);
        return errMsglist;
    }

    private void clrCashf(int nCashFlowPos) {
        _cashFl.setCashFlow(0, nCashFlowPos);
        _cashFl.setIncome(0, nCashFlowPos);
    }
}
