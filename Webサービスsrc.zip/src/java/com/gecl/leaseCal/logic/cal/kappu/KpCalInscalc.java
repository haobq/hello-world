/*
 * @(#)KpCalInscalc.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *修正者：　　?補千
 *修正日：　　20050425
 *修正内容：　賠償責任保険の物件数量計算方法更新

 */
package com.gecl.leaseCal.logic.cal.kappu;

import com.gecl.leaseCal.db.comm.DosoinstBean;
import java.util.Vector;


import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;

public class KpCalInscalc {

    private Gcal _gcal;                                   //Gcalbean
    private Vector _vResult;
    DosoinstBean dosoinstBean = new DosoinstBean();
    /**
     * コンストラクタ．     <BR>
     */
    public KpCalInscalc() {
    }

    /**
     * オブジェクトをセットする．     <BR>
     * Gcalオブジェクトを渡す。
     * @param gcal	Gcalオブジェクト
     */
    public void setPara(Gcal gcal) {
        _gcal = gcal;
        dosoinstBean.parseXml();
    }

    /**
     *保険料算出を行う． <BR>
     *
     * @return
     */
    public ArrayList<ErrorInforOutputComplexType> doCalculate() {
        int nKapYY;
        int nKapMM;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        //動総保険料率の判定
        if (_gcal.getDosoRt() == 0) {
            //動総保険金額指数
            _gcal.setDosoIx(0);
            //動総保険料
            _gcal.setDosoF(0);
        } else {
            nKapYY = _gcal.getKappuM() / 12;
            nKapMM = _gcal.getKappuM() % 12;

            //割賦月数が年単位で割切れるか判定
            if (nKapMM == 0) {
                double dDosoIxT;
                //割賦年数に対して、期間合計指数と 動総保険金額指数取得

                dDosoIxT = dosoGet(nKapYY);

                if (dDosoIxT < 0) {
                    //DOSOINSTの年数が取得できません。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR087 + "(" + nKapYY + ")","ERR087",errMsglist);
                    return errMsglist;
                }
                _gcal.setDosoIx(dDosoIxT);
                //動総保険料の算出
                _gcal.setDosoF(LfcLogicComm.dround(_gcal.getPurchas() * _gcal.getDosoIx() * _gcal.getDosoRt() / 1000.0, 0));
            } else {
                double dDosoIxT;
                double dDosoix;
                //（割賦年数＋１）に対して、 期間合計指数と動総保険金額指数取得
                dDosoIxT = dosoGet(nKapYY + 1);
                if (dDosoIxT < 0) {
                    //DOSOINSTの年数が取得できません。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR087 + "(" + nKapYY + ")","ERR087",errMsglist);
                    return errMsglist;
                }
                dDosoix = dosoIx(nKapYY + 1);

                _gcal.setDosoIx(dDosoIxT - dDosoix + dDosoix * LfcLogicPgConst.DS_STR[nKapMM]);
//20040823 ljq add s
                _gcal.setDosoIx(LfcFrmComm.dround(_gcal.getDosoIx(), 7));
//20040823 ljq add e
                //動総保険料の算出
                _gcal.setDosoF(LfcLogicComm.dround(_gcal.getPurchas() * _gcal.getDosoIx() * _gcal.getDosoRt() / 1000.0, 0));
            }
        }

        //賠償責任保険
        if ("1".equals(_gcal.getSwBais())) {
            //hbq 20050425 賠償責任保険の物件数量計算方法更新　begin
            _gcal.setBaisF(2000.0 *  ((_gcal.getKappuM() + 11) / 12));
            //hbq 20050425 賠償責任保険の物件数量計算方法更新　end
        } else {
            _gcal.setBaisF(0);
        }
        //保険料合算
        _gcal.setInsur(_gcal.getDosoF() + _gcal.getBaisF() + _gcal.getMachiF() + _gcal.getFireF() + _gcal.getEtcF());
        return null;
    }

    /**
     *XMLにより期間合計指数を取得する． <BR>
     *
     * @param nKapYY
     * @return
     */
    public double dosoGet(int nKapYY) {
        Vector vResults;
        if (dosoinstBean.getQueryResults() == true) {
            vResults = dosoinstBean.getResults();

        } else {
            return -1;
        }
        if (nKapYY > 99 || nKapYY < 0) {
            return -1;
        }
        for (int i = 0; i < vResults.size(); i++) {
            _vResult = (Vector) vResults.elementAt(i);

            if (nKapYY == Integer.parseInt((String) _vResult.elementAt(0))) {
                Double tmpDouble = new Double((String) _vResult.elementAt(_vResult.size() - 1));
                return tmpDouble.doubleValue();
            }
        }
        return -1;
    }

    /**
     *XMLにより動総保険金額指数を取得する． <BR>
     *
     * @param nTerm
     * @return
     */
    public double dosoIx(int nTerm) {
        if (nTerm > 36 || nTerm < 1) {
            return -1;
        }
        Double tmpDouble = new Double((String) _vResult.elementAt(nTerm));
        return tmpDouble.doubleValue();
    }
}
