/*
 * @(#)LsCalLdnscal.java      01-01  2003/05/22
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.Stairs;
import com.gecl.leaseCal.logic.comm.CashFl;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;

/**
 * 団信保険料算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/05/22
 * @since   01-01
 */
public class LsCalLdnscal {
    private Gcal _gcal;             //Gcalbean
    private Stairs _stairs;         //回収情報bean
    private CashFl _cashFl;         //CashFlbean

    /**
     * コンストラクタ．     <BR>     *
     */
    public LsCalLdnscal() {

    }
    /**
     * オブジェクトをセットする．     <BR>
     * Gcal・回収情報・CashFlowを渡す。
     * @param gcal	Gcalオブジェクト
     * @param stairs	回収情報
     * @param cashFl	CashFlオブジェクト
     */
    public void setPara(Gcal gcal,Stairs stairs,CashFl cashFl) {
        _gcal = gcal;
        _stairs = stairs;
        _cashFl = cashFl;
    }
    /**
     * 団信保険料算出を行う． <BR>
     *
     */
    public void doCalculate() {
    	double LeaseZan;

	    //団信保険料率あり
    	if (_gcal.getDansRt() != 0){
            //（前受リースある場合）前受リース料回収月＝検収月　AND
            //回収月＝検収月　AND　回収額が均
            //又は（前受ﾘｰｽ料/頭金がない場合）回収額が均
    		if (_gcal.getEvenFlg() ==  1 && (_gcal.getInc0() == 0
                        || (LfcLogicComm.db3Year(_gcal.getDKensh()) == LfcLogicComm.db3Year(_gcal.getDInc0())
                        && LfcLogicComm.db3Month(_gcal.getDKensh()) == LfcLogicComm.db3Month(_gcal.getDInc0())))
                        &&  LfcLogicComm.db3Year(_gcal.getDKensh()) == _stairs.getDateYY(_cashFl.getRowTop())
                        && LfcLogicComm.db3Month(_gcal.getDKensh()) == _stairs.getDateMM(_cashFl.getRowTop())){
                //リース月数が偶数の場合
                if (_gcal.getLeaseM() % 2 == 0) {

                 //その他繰延費用(ﾍ)を設定（団信保険料）
                    _gcal.setKurino1(LfcLogicComm.dround(_gcal.getPurchas() * 1.1 * _gcal.getLeaseM() * _gcal.getDansRt() / 10000.0
                    -(0.4875 * _gcal.getLeaseM() - 0.525) * (_gcal.getPurchas() - _gcal.getRemVAL()) * _gcal.getDansRt() / 10000.0 + 0.001, 0));
                } else {

                    _gcal.setKurino1(LfcLogicComm.dround(_gcal.getPurchas() * 1.1 * _gcal.getLeaseM() * _gcal.getDansRt() / 10000.0
                    -(0.4875 * _gcal.getLeaseM() - 0.7875) * (_gcal.getPurchas() - _gcal.getRemVAL()) * _gcal.getDansRt() / 10000.0 + 0.001, 0));
                }
            } else {
                //検収当月を保険付保開始月
                _gcal.setKurino1(0.0);
                //契約額を最初（保険付保開始月）の保険金額としてセット
                LeaseZan = _gcal.getIncGt();

                //毎月、月初のリース料残高を保険金額として保険を付保する
                for ( int i = 0; i <_cashFl.getCashCnt(); ++i){
               	    _gcal.setKurino1( _gcal.getKurino1() + LfcLogicComm.dround(LeaseZan * _gcal.getDansRt() / 10000.0 + 0.001, 0));
               	    LeaseZan = LeaseZan - _cashFl.getIncome(i);
               	}
            }
        }
    }
}

