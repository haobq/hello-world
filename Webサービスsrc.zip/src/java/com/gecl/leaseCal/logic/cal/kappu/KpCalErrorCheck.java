/*
 * @(#)KpCalErrorCheck.java      01-01  2003/06/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.kappu;

import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.Stairs;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


public class KpCalErrorCheck {

    private Gcal _gcal;
    private Paydiv _paydiv;
    private Stairs _stairs;
    private int _nIncomeCount;
    private int _nFrequeCount;
    private int _nCntrctType;

    public KpCalErrorCheck() {
    }

    public void setPara(Gcal gcal, Stairs stairs, Paydiv paydiv) {
        _gcal = gcal;
        _stairs = stairs;
        _paydiv = paydiv;
    }

    public int getIncomeCount() {
        return _nIncomeCount;
    }

    public int getFrequeCount() {
        return _nFrequeCount;
    }

    public ArrayList<ErrorInforOutputComplexType> doErrorCheck(int nCalItem,int nBaseProf) {

        //ZJ 20040805
//        JInternalFrame jf = LfcFrmComm.lsCalDesktop.getCurrJInternalFrame();
        boolean bflgErrorCheck = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        if (!_gcal.getRyortTFlg()) {
            //「合計料率」範囲チェック(合計料率<100、合計料率>999の場合、エラー)
            if (_gcal.getRyortT() * 100 <= 100 || _gcal.getRyortT() * 100 >= 999) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR040, "ERR040", errMsglist);
                //ZJ 20040805 start
//               if (jf instanceof KpCalBaseInfoFrm) {
//                   ((KpCalBaseInfoFrm)jf).txtRyoristsuT.requestFocus();
//               }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }

        }
        if (!_gcal.getRyortMFlg()) {
            //「月料率」範囲チェック(月料率<0、月料率>999の場合、エラー)
            if (_gcal.getRyortM() * 100 < 0 || _gcal.getRyortM() * 100 > 999) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR041, "ERR041", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof KpCalBaseInfoFrm) {
//                    ((KpCalBaseInfoFrm)jf).txtRyoritsuM.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }
        if (!_gcal.getRateUnFlg()) {
            //「運用利回」範囲チェック(運用回り<-99.99、運用利回り>99.99の場合、エラー)
            if (_gcal.getRateUN() * 100 < -99.99 || _gcal.getRateUN() * 100 > 99.99) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR042, "ERR042", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof KpCalBaseInfoFrm) {
//                    ((KpCalBaseInfoFrm)jf).txtRateUnyo.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }
        if (!_gcal.getRateROIFlg()) {
            //「ＲＯＩ」範囲チェック(ROI<-99.99、ROI>99.99の場合、エラー)
            if (_gcal.getRateROI() * 100 < -99.99 || _gcal.getRateROI() * 100 > 99.99) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR043, "ERR043", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof KpCalBaseInfoFrm) {
//                    ((KpCalBaseInfoFrm)jf).txtRoi.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }
        if (!_gcal.getTrueRtFlg()) {
            //「ＴＲ」範囲チェック(TR<-99.99、TR>99.99の場合、エラー)
            if (_gcal.getTrueRT() * 100 < -99.99 || _gcal.getTrueRT() * 100 > 99.99) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR044, "ERR044", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof KpCalBaseInfoFrm) {
//                    ((KpCalBaseInfoFrm)jf).txtTrueRate.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }

        _gcal.setDKensh(LfcLogicComm.db3Itod(_gcal.getDate1YY(),
                _gcal.getDate1MM(),
                _gcal.getDate1DD() == 0 ? 1 : _gcal.getDate1DD()));

        //一括支払の場合
        if (!_gcal.getSwPay()) {
            //検収予定日と支払予定日の関係が正しいかどうかのチェック
            if ((_gcal.getDate1YY() - 5) * 12 + _gcal.getDate1MM() > _gcal.getDate2YY() * 12 + _gcal.getDate2MM() ||
                    _gcal.getDate2YY() * 12 + _gcal.getDate2MM() > (_gcal.getDate1YY() + 10) * 12 + _gcal.getDate1MM()) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR003, "ERR003", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof KpCalBaseInfoFrm) {
//                    ((KpCalBaseInfoFrm)jf).txtDateKensh.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
            _gcal.setDPaymt(LfcLogicComm.db3Itod(_gcal.getDate2YY(), _gcal.getDate2MM(), _gcal.getDate2DD()));
        } else {
            int i = 0;
            for (i = 0; i < 120; i++) {
                if (_paydiv.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                    break;
                }
            }
            //分割支払120段にはデータ入力しないチェック
            if (i == 120) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR004, "ERR004", errMsglist);
                bflgErrorCheck = false;
            } else {
                for (; i < 120; i++) {
                    if (_paydiv.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                        //入力した段の支払予定年月は検収予定年月より、60月前の場合、120月後のチェック
                        if ((_gcal.getDate1YY() - 5) * 12 + _gcal.getDate1MM() >
                                _paydiv.getDateYY(i) * 12 + _paydiv.getDateMM(i) || _paydiv.getDateYY(i) * 12 + _paydiv.getDateMM(i) >
                                (_gcal.getDate1YY() + 10) * 12 + _gcal.getDate1MM()) {
                            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR003, "ERR003", errMsglist);
                            bflgErrorCheck = false;
                        }
                    }
                }
            }
            _gcal.setDPaymt(LfcLogicComm.db3Itod(0, 0, 0));
        }
        //分割支払時は 購入価額を求めることはできません
        if (_gcal.getPurchasFlg() && _gcal.getSwPay()) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR007, "ERR007", errMsglist);
            bflgErrorCheck = false;
        }

        //購入価額は1,000円以上､500億円以下で指定して下さい。500億円を超える場合は､桁あふれの為入力できません。
        if (!_gcal.getPurchasFlg() &&
                (_gcal.getPurchas() < 1000 || _gcal.getPurchas() > 50000000000.0)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR008, "ERR008", errMsglist);

            //ZJ 20040805 start
//            if (jf instanceof KpCalBaseInfoFrm) {
//                ((KpCalBaseInfoFrm)jf).txtPurchase.requestFocus();
//            }
            //ZJ 20040805 end

            bflgErrorCheck = false;
        }
//20040624 ljq delete start
/*
        //頭金が購入価額を超えています。
        if(_gcal.getPurchasFlg() == LfcLogicPgConst.KUBUN_NO && _gcal.getInc0Flg() == LfcLogicPgConst.KUBUN_NO && _gcal.getPurchas() <= _gcal.getInc0()) {
        errMsglist = LfcLogicComm..addErrMsgList(LfcLogicMsgConst.ERR098,"メッセージ",errMsglist);
        bflgErrorCheck= false;
        }
         */
//20040624 ljq delete end
        //割賦段数を取得
        _gcal.setLeaseD(0);
        for (int i = 0; i < LfcLogicPgConst.STAIRS_MAX_COUNT; ++i) {
            if (_stairs.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                _gcal.setLeaseD(_gcal.getLeaseD() + 1);
            }
        }
        //回収データが入力していないチェック
        if (_gcal.getLeaseD() < 1) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR025, "ERR025", errMsglist);
            bflgErrorCheck = false;
        }
        ArrayList<ErrorInforOutputComplexType> errMsglistSubErrChk = doSubErrChk(nCalItem,nBaseProf);
        if (!errMsglistSubErrChk.isEmpty()) {
            errMsglist.addAll(errMsglistSubErrChk);
            bflgErrorCheck = false;
        }

        if (_stairs.getDateYY(_stairs.getTopRow()) == LfcLogicComm.db3Year(_gcal.getDKensh()) && _stairs.getDateMM(_stairs.getTopRow()) == LfcLogicComm.db3Month(_gcal.getDKensh()) && _stairs.getDateDD(_stairs.getTopRow()) == LfcLogicComm.db3Day(_gcal.getDKensh())) {
            //PUTERR("頭金の回収予定日＝第一回目の回収予定日はエラー");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR099, "ERR099", errMsglist);
            bflgErrorCheck = false;
        }
        if (_gcal.getLeaseD() == 1) {
            int i;
            for (i = 0; i < LfcLogicPgConst.STAIRS_MAX_COUNT; i++) {
                if (_stairs.getAct(i)) {
                    break;
                }
            }
            _gcal.setEvenFlg(0);
            long lMonth1;
            long lMonth2;
            lMonth1 = _stairs.getDateYY(i) * 12L + _stairs.getDateMM(i);
            lMonth2 = LfcLogicComm.db3Year(_gcal.getDKensh()) * 12L + LfcLogicComm.db3Month(_gcal.getDKensh());
            if (_stairs.getCycle(i) == 1 && (lMonth1 - lMonth2) == 1) {
                _gcal.setEvenFlg(1);
            }
            if (_stairs.getIncome(i) <= 0 && _gcal.getPurchasFlg()) {
                //PUTERR("割賦金か購入価額のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR100, "ERR100", errMsglist);
                bflgErrorCheck = false;
            }
            if (_stairs.getIncome(i) <= 0 && _stairs.getFreque(i) <= 0) {
                //PUTERR("割賦金か回数のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR101, "ERR101", errMsglist);
                bflgErrorCheck = false;
            }
            if (_stairs.getIncome(i) <= 0 && _gcal.getRyortTFlg() && _gcal.getRyortMFlg() && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
                //PUTERR("割賦金か採算項目のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR102, "ERR102", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getInc0Flg() && _gcal.getPurchasFlg()) {
                //PUTERR("頭金か購入価額のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR103, "ERR103", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getInc0Flg() && _stairs.getFreque(i) <= 0) {
                //PUTERR("頭金か回数のどちらかに値を設定して下さい．");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR104, "ERR104", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getInc0Flg() && _gcal.getRyortTFlg() && _gcal.getRyortMFlg() && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
                //PUTERR("頭金か採算項目のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR105, "ERR105", errMsglist);
                bflgErrorCheck = false;
            }
            if (_stairs.getFreque(i) <= 0 && _gcal.getPurchasFlg()) {
                //PUTERR("回数か購入価額のどちらかに値を設定して下さい．");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR106, "ERR106", errMsglist);
                bflgErrorCheck = false;
            }
            if (_stairs.getFreque(i) <= 0 && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
                //PUTERR("回数か採算項目のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR107, "ERR107", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getPurchasFlg() && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
                //PUTERR("購入価額か採算項目のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR108, "ERR108", errMsglist);
                bflgErrorCheck = false;
            }
        } else {
            _gcal.setEvenFlg(0);
            if (_nIncomeCount != 0 && _nFrequeCount != 0) {
                //PUTERR("割賦金か回数のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR101, "ERR101", errMsglist);
                bflgErrorCheck = false;
            }
            if (_nIncomeCount != 0 && _gcal.getPurchasFlg()) {
                // PUTERR("割賦金か購入価額のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR100, "ERR100", errMsglist);
                bflgErrorCheck = false;
            }
            if (_nIncomeCount != 0 && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
                //PUTERR("割賦金か採算項目のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR102, "ERR102", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getInc0Flg() && _gcal.getPurchasFlg()) {
                //PUTERR("頭金か購入価額のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR103, "ERR103", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getInc0Flg() && _nIncomeCount > 1) {
                //PUTERR("頭金と途中段の割賦金は、同時に求めることはできません。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR110, "ERR110", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getInc0Flg() && _nFrequeCount != 0) {
                //PUTERR("頭金か回数のどちらかに値を設定して下さい．");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR104, "ERR104", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getInc0Flg() && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
                //PUTERR("頭金か採算項目のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR105, "ERR105", errMsglist);
                bflgErrorCheck = false;
            }
            if (_nFrequeCount != 0 && _gcal.getPurchasFlg()) {
                //PUTERR("回数か購入価額のどちらかに値を設定して下さい．");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR106, "ERR106", errMsglist);
                bflgErrorCheck = false;
            }
            if (_nFrequeCount != 0 && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
                //PUTERR("回数か採算項目のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR107, "ERR107", errMsglist);
                bflgErrorCheck = false;
            }
            if (_gcal.getPurchasFlg() && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
                //PUTERR("購入価額か採算項目のどちらかに値を設定して下さい。");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR108, "ERR108", errMsglist);
                bflgErrorCheck = false;
            }
        }
        return errMsglist;
    }

    boolean doDayCheck(int nYy, int nMm, int nDd) {
        long tmp;
        if (nYy == 0) {
            return false;
        }
        if (nYy < 100) {
            nYy += 1900;
        }
        tmp = LfcLogicComm.db3Itod(nYy, nMm, nDd);
        if (LfcLogicComm.db3Year(tmp) == nYy && LfcLogicComm.db3Month(tmp) == nMm && LfcLogicComm.db3Day(tmp) == nDd) {
            return true;
        } else {
            return false;
        }
    }

    public ArrayList<ErrorInforOutputComplexType> doSubErrChk(int nCalItem,int nBaseProf) {
        int i;
        long lChkDt;
        int nPos;
        //回収金額の複数段が未入力カウンタ変数
        int nIncome = 0;
        //回収回数の複数段が未入力カウンタ変数
        int nFreque = 0;
        int nLastCol = 0;
        _nIncomeCount = 0;
        _nFrequeCount = 0;
        boolean bflgErrorCheck = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        _gcal.setInddFlg(0);
        lChkDt = LfcLogicComm.db3Year(_gcal.getDKensh() * 12 + LfcLogicComm.db3Month(_gcal.getDKensh()) - 1);
        for (i = 0; i < 360; i++) {
            if (_stairs.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                break;
            }
        }
        _stairs.setTopRow(i);
        nPos = 0;
        for (; i < 360; i++) {
            if (_stairs.getAct(i) == LfcLogicPgConst.KUBUN_NO) {
                continue;
            }
            nLastCol = i;
            nPos = nPos + 1;
            if (_stairs.getIncome(i) <= 0) {
                if (nCalItem != LfcLogicPgConst.KAP_ITEM_KINGAKU && nCalItem != LfcLogicPgConst.KAP_ITEM_KINGAKU_INC0) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                            (i + 1) +
                            LfcLogicMsgConst.ERR026, "ERR026", errMsglist);
                    bflgErrorCheck = false;
                }
                _nIncomeCount = nPos;
                nIncome = nIncome + 1;
            }
            //回収回数逆算以外、回収回数未入力チェック
            if (_stairs.getFreque(i) <= 0) {
                //回収回数逆算以外の場合、
                if (nCalItem != LfcLogicPgConst.KAP_ITEM_KAISU) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                            (i + 1) +
                            LfcLogicMsgConst.ERR035, "ERR035", errMsglist);
                    bflgErrorCheck = false;
                }
                _nFrequeCount = nPos;
                nFreque = nFreque + 1;
            }
            //回収回数逆算以外、回収回数>360のチェック
            if (_stairs.getFreque(i) > 360) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +
                        LfcLogicMsgConst.ERR036, "ERR036", errMsglist);
                bflgErrorCheck = false;
            }
            if (_stairs.getCycle(i) <= 0) {
                if (_stairs.getFreque(i) == 1) {
                    _stairs.setCycle(1, i);
                } else {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                            (i + 1) +
                            LfcLogicMsgConst.ERR033, "ERR033", errMsglist);
                    bflgErrorCheck = false;
                }
            }
            if (_stairs.getCycle(i) > 360) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +
                        LfcLogicMsgConst.ERR034, "ERR034", errMsglist);
                bflgErrorCheck = false;
            }
            if (_stairs.getDateDD(i) == 0) {
                _gcal.setInddFlg(1);
            }
            if (_stairs.getDateYY(i) == 0 && _stairs.getDateMM(i) == 0 && _stairs.getDateDD(i) == 0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +
                        LfcLogicMsgConst.ERR029, "ERR029", errMsglist);
                bflgErrorCheck = false;
            }
            if (!doDayCheck(_stairs.getDateYY(i),
                    _stairs.getDateMM(i),
                    _stairs.getDateDD(i) == 0 || _stairs.getDateDD(i) == 99 ? 1 : _stairs.getDateDD(i))) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +
                        LfcLogicMsgConst.ERR030, "ERR030", errMsglist);
                bflgErrorCheck = false;
            }
            //第１段の場合、
            if (i + 1 == 1) {
                //第１回目の回収予定日と検収予定日の関係のチェック（第1段の回収予定日<検収予定日の場合、エラー）
                if (_gcal.getDate1DD() == 0 || _stairs.getDateDD(i) == 0 || _stairs.getDateDD(i) == 99) {
                    if ((_gcal.getDate1YY()) * 100 + _gcal.getDate1MM() > _stairs.getDateYY(i) * 100 + _stairs.getDateMM(i)) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR031, "ERR031", errMsglist);
                        bflgErrorCheck = false;
                    }
                } else {
                    if ((_gcal.getDate1YY()) * 10000 + _gcal.getDate1MM() * 100 + _gcal.getDate1DD() > _stairs.getDateYY(i) * 10000 + _stairs.getDateMM(i) * 100 + _stairs.getDateDD(i)) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR031, "ERR031", errMsglist);
                        bflgErrorCheck = false;
                    }
                }
            }
            //
            if ((_stairs.getDateYY(i) * 12 + _stairs.getDateMM(i)) - lChkDt - 1 < 0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +
                        LfcLogicMsgConst.ERR032, "ERR032", errMsglist);
                bflgErrorCheck = false;
            }
            lChkDt = _stairs.getDateYY(i) * 12 + _stairs.getDateMM(i) + (_stairs.getFreque(i) - 1) * _stairs.getCycle(i);
        }
        //回収金額を複数求める事が出来ないチェック(複数段の回収金額が０でした。)
        if (nIncome > 1) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR027, "ERR027", errMsglist);
            bflgErrorCheck = false;
        }
        //回数を複数求める事が出来ないチェック(複数段の回収回数=0の場合)
        if (nFreque > 1) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR038, "ERR038", errMsglist);
            bflgErrorCheck = false;
        }
        //最終段以外の回数を求めることはできないチェック(最終段回収回数<>0、前の段の回収回数=0)
        if (nFreque == 1 && _stairs.getFreque(nLastCol) > 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR037, "ERR037", errMsglist);
            bflgErrorCheck = false;
        }
        //回収金額逆算、全て段の回収金額が０ではないチェック(求めたい回収金を0にしてください)
        if (nCalItem == LfcLogicPgConst.KAP_ITEM_KINGAKU && nPos > 1 && nIncome == 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR028, "ERR028", errMsglist);
            bflgErrorCheck = false;
        }
        /*
        //回収回数逆算、全て段の回収回数０ではないチェック(求めたい回収回数を0にしてください)
        if (KpCalComm.getReqItem() == 3 && nPos > 1 && nFreque == 0) {
        LfcMessageBox.show(LfcLogicMsgConst.ERR039);
        bflgErrorCheck= false;
        }
         */
        if (nCalItem != LfcLogicPgConst.KAP_ITEM_KAISU) {
            if (lChkDt - LfcLogicComm.db3Year(_gcal.getDKensh()) * 12 + LfcLogicComm.db3Month(_gcal.getDKensh()) + 1 > 400) {
//                PUTERR("回収期間が長すぎます。（４００か月を越えています。）");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR086, "ERR086", errMsglist);
                bflgErrorCheck = false;
            }
        }

        _stairs.setLastRow(nLastCol);
        return errMsglist;
    }
}


