/*
 * @(#)LsCalErrorCheck.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.LfcLogicPgConst;
import com.gecl.leaseCal.logic.comm.Paydiv;
import com.gecl.leaseCal.logic.comm.Stairs;
import java.util.ArrayList;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;


public class LsCalErrorCheck {

    private Gcal _gcal;
    private Paydiv _paydiv;
    private Stairs _stairs;
    private int _nIncomeCount;
    private int _nFrequeCount;
    private int _nCntrctType;


    public LsCalErrorCheck() {
    }

    public void setPara(Gcal gcal, Stairs stairs, Paydiv paydiv) {
        _gcal = gcal;
        _stairs = stairs;
        _paydiv = paydiv;
    }

    public int getIncomeCount() {
        return _nIncomeCount;
    }

    public int getFrequeCount() {
        return _nFrequeCount;
    }

    public ArrayList<ErrorInforOutputComplexType> setCntrctType(String str) {
        //割賦
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        String strCntrctNo = _gcal.getKeiyaku();
        _nCntrctType = LfcLogicPgConst.KAPPU;
        if (strCntrctNo != null && !"".equals(strCntrctNo)) {
            if (strCntrctNo.length() == 8) {
                if (strCntrctNo.charAt(2) != 'S' && strCntrctNo.charAt(2) != 'C') {
                    _nCntrctType = LfcLogicPgConst.LEASE;//リース
                }
            } else {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR070, "ERR070", errMsglist);
            }
        } else {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR070, "ERR070", errMsglist);
        }
        return errMsglist;
    }

    public ArrayList<ErrorInforOutputComplexType> doErrorCheck(int nCalItem,int nBaseProf) {
        //ZJ 20040805
//        JInternalFrame jf = LfcFrmComm.lsCalDesktop.getCurrJInternalFrame();
        boolean bflgErrorCheck = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        if (!_gcal.getRyortTFlg()) {
            //「合計料率」範囲チェック(合計料率<100、合計料率>999の場合、エラー)
//            if (_gcal.getRyortT() < 100 ||_gcal.getRyortT() > 999) {
            if (_gcal.getRyortT() * 100 <= 100 || _gcal.getRyortT() * 100 >= 999) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR040, "ERR040", errMsglist);
                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).txtRyoristsuT.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }

        }
        if (!_gcal.getRyortMFlg()) {
            //「月料率」範囲チェック(月料率<0、月料率>999の場合、エラー)
//            if (_gcal.getRyortM() < 0 || _gcal.getRyortM() > 999) {
            if (_gcal.getRyortM() * 100 < 0 || _gcal.getRyortM() * 100 > 999) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR041, "ERR041", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).txtRyoritsuM.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }
        if (!_gcal.getRateUnFlg()) {
            //「運用利回」範囲チェック(運用回り<-99.99、運用利回り>99.99の場合、エラー)
//            if (_gcal.getRateUN() < -99.99 || _gcal.getRateUN() > 99.99) {
            if (_gcal.getRateUN() * 100 < -99.99 || _gcal.getRateUN() * 100 > 99.99) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR042, "ERR042", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).txtRateUnyo.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }
        if (!_gcal.getRateROIFlg()) {
            //「ＲＯＩ」範囲チェック(ROI<-99.99、ROI>99.99の場合、エラー)
//            if (_gcal.getRateROI() < -99.99 || _gcal.getRateROI() > 99.99) {
            if (_gcal.getRateROI() * 100 < -99.99 || _gcal.getRateROI() * 100 > 99.99) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR043, "ERR043", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).txtRoi.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }
        if (!_gcal.getTrueRtFlg()) {
            //「ＴＲ」範囲チェック(TR<-99.99、TR>99.99の場合、エラー)
//            if (_gcal.getTrueRT() < -99.99 || _gcal.getTrueRT() > 99.99) {
            if (_gcal.getTrueRT() * 100 < -99.99 || _gcal.getTrueRT() * 100 > 99.99) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR044, "ERR044", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
                //((LsCalBaseInfoFrm)jf).txtTrueRate.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }
        /*
        //検収予定日未入力のチェック
        if (_gcal.getDKensh() == 0) {
        LfcMessageBox.show(LfcLogicMsgConst.ERR001);
        bflgErrorCheck= false;
        }

        //検収予定日が 暦の上で存在するかどうかのチェック
        if (!doDayCheck(_gcal.getDate1YY(), _gcal.getDate1MM(), _gcal.getDate1DD() == 0 ? 1:_gcal.getDate1DD())) {
        LfcMessageBox.show(LfcLogicMsgConst.ERR001);
        bflgErrorCheck= false;
        }
         */
        _gcal.setDKensh(LfcLogicComm.db3Itod(_gcal.getDate1YY(),
                _gcal.getDate1MM(),
                _gcal.getDate1DD() == 0 ? 1 : _gcal.getDate1DD()));

//        if (_nCntrctType == LfcLogicPgConst.LEASE) {
        if (true) {
            //一括支払の場合
            if (!_gcal.getSwPay()) {
                //支払予定日未入力のチェック
                if (_gcal.getDPaymt() == 0) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR002, "ERR002", errMsglist);

                    //ZJ 20040805 start
//                    if (jf instanceof LsCalBaseInfoFrm) {
//                        ((LsCalBaseInfoFrm)jf).txtDatePaymt.requestFocus();
//                    }
                    //ZJ 20040805 end

                    bflgErrorCheck = false;
                }
                //支払予定日が 暦の上で存在するかどうかのチェック
                if (!doDayCheck(_gcal.getDate2YY(), _gcal.getDate2MM(), _gcal.getDate2DD())) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR002, "ERR002", errMsglist);

                    //ZJ 20040805 start
//                    if (jf instanceof LsCalBaseInfoFrm) {
//                        ((LsCalBaseInfoFrm)jf).txtDatePaymt.requestFocus();
//                    }
                    //ZJ 20040805 end

                    bflgErrorCheck = false;
                }

                //検収予定日と支払予定日の関係が正しいかどうかのチェック
                if ((_gcal.getDate1YY() - 5) * 12 + _gcal.getDate1MM() > _gcal.getDate2YY() * 12 + _gcal.getDate2MM() ||
                        _gcal.getDate2YY() * 12 + _gcal.getDate2MM() > (_gcal.getDate1YY() + 10) * 12 + _gcal.getDate1MM()) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR003, "ERR003", errMsglist);

                    //ZJ 20040805 start
//                    if (jf instanceof LsCalBaseInfoFrm) {
//                        ((LsCalBaseInfoFrm)jf).txtDateKensh.requestFocus();
//                    }
                    //ZJ 20040805 end

                    bflgErrorCheck = false;
                }
                _gcal.setDPaymt(LfcLogicComm.db3Itod(_gcal.getDate2YY(), _gcal.getDate2MM(), _gcal.getDate2DD()));
            } else {
                int i = 0;
                for (i = 0; i < 120; i++) {
                    if (_paydiv.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                        break;
                    }
                }
                //分割支払120段にはデータ入力しないチェック
                if (i == 120) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR004, "ERR004", errMsglist);
                    bflgErrorCheck = false;
                } else {
                    for (; i < 120; i++) {
                        if (_paydiv.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                            //支払予定日が 暦の上で存在するかどうかのチェック
                            if (!doDayCheck(_paydiv.getDateYY(i), _paydiv.getDateMM(i), _paydiv.getDateDD(i))) {
                                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR002, "ERR002", errMsglist);

                                //ZJ 20040805 start
//                                if (jf instanceof LsCalBaseInfoFrm) {
//                                    ((LsCalBaseInfoFrm)jf).txtDatePaymt.requestFocus();
//                                }
                                //ZJ 20040805 end

                                bflgErrorCheck = false;
                            }
                            //入力した段の支払予定年月は検収予定年月より、60月前の場合、120月後のチェック
                            if ((_gcal.getDate1YY() - 5) * 12 + _gcal.getDate1MM() > _paydiv.getDateYY(i) * 12 + _paydiv.getDateMM(i) || _paydiv.getDateYY(i) * 12 + _paydiv.getDateMM(i) > (_gcal.getDate1YY() + 10) * 12 + _gcal.getDate1MM()) {
                                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR003, "ERR003", errMsglist);

                                //ZJ 20040805 start
//                                if (jf instanceof LsCalBaseInfoFrm) {
//                                    ((LsCalBaseInfoFrm)jf).txtDateKensh.requestFocus();
//                                }
                                //ZJ 20040805 end

                                bflgErrorCheck = false;
                            }
                        }
                    }
                }
                _gcal.setDPaymt(LfcLogicComm.db3Itod(0, 0, 0));
            }
        }

        //「社内コスト率」０は計算できません。
        if (_gcal.getRateJL() == 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR005, "ERR005", errMsglist);

            //ZJ 20040805 start
//            if (jf instanceof LsCalBaseInfoFrm) {
//                ((LsCalBaseInfoFrm)jf).btnSelectCostRate.requestFocus();
//            }
            //ZJ 20040805 end

            bflgErrorCheck = false;
        }

        //COFが入力されていません。ＣＯＦ（原調計算金利）
        if (_gcal.getRateCADJ() == 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR006, "ERR006", errMsglist);

            //ZJ 20040805 start
//            if (jf instanceof LsCalBaseInfoFrm) {
//                ((LsCalBaseInfoFrm)jf).cbxCof.getEditor().getEditorComponent().requestFocus();
//            }
            //ZJ 20040805 end

            bflgErrorCheck = false;
        }

        //分割支払時は 購入価額を求めることはできません
        if (_gcal.getPurchasFlg() && _gcal.getSwPay()) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR007, "ERR007", errMsglist);

            //ZJ 20040805 start
//            if (jf instanceof LsCalBaseInfoFrm) {
//                ((LsCalBaseInfoFrm)jf).txtPurchase.requestFocus();
//            }
            //ZJ 20040805 end

            bflgErrorCheck = false;
        }

        //購入価額は1,000円以上､500億円以下で指定して下さい。500億円を超える場合は､桁あふれの為入力できません。
        if (!_gcal.getPurchasFlg() &&
                (_gcal.getPurchas() < 1000 || _gcal.getPurchas() > 50000000000.0)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR008, "ERR008", errMsglist);

            //ZJ 20040805 start
//            if (jf instanceof LsCalBaseInfoFrm) {
//                ((LsCalBaseInfoFrm)jf).txtPurchase.requestFocus();
//            }
            //ZJ 20040805 end

            bflgErrorCheck = false;
        }

//        if (_nCntrctType == LfcLogicPgConst.LEASE) {
        if (true) {
            /*
            //残価率範囲エラーチェック
            if (_gcal.getRemVRT() < 0 || _gcal.getRemVRT() > 100) {
            LfcMessageBox.show(LfcLogicMsgConst.ERR009);
            bflgErrorCheck= false;
            }
             */
            //残価逆算以外の場合、残価範囲エラーチェック
            if (!_gcal.getRemValFlg() && _gcal.getRemVAL() < 0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR010, "ERR010", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).txtRemainVal.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }

            //残価逆算以外の場合、残価が 購入価額を越えているチェック
            if (!_gcal.getRemValFlg() && !_gcal.getPurchasFlg() && _gcal.getRemVAL() > _gcal.getPurchas()) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR011, "ERR011", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).txtRemainVal.requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }

            //回収回逆算以外、リース月数未入力チェック
            if (!_gcal.getLeaseMFlg() && _gcal.getLeaseM() == 0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR012, "ERR012", errMsglist);
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).cbxLeaseM.getEditor().getEditorComponent().requestFocus();

                //ZJ 20040805 start
//                    if (jf instanceof LsCalBaseInfoFrm) {
//                        ((LsCalBaseInfoFrm)jf).cbxLeaseM.getEditor().getEditorComponent().requestFocus();
//                    }
                //ZJ 20040805 end

//                }
                bflgErrorCheck = false;
            }

            //回収回逆算以外、リース月数>360チェック
            if (!_gcal.getLeaseMFlg() && _gcal.getLeaseM() > 360) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR014, "ERR014", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).cbxLeaseM.getEditor().getEditorComponent().requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
            /*
            //法定耐用年数範囲エラー「1-99」チェック
            if (_gcal.getDuraY() < 1 || _gcal.getDuraY() > 99) {
            LfcMessageBox.show(LfcLogicMsgConst.ERR015);
            bflgErrorCheck= false;
            }
             */
            if (!_gcal.getLeaseMFlg()) {
                if (_gcal.getInc0Flg() && _gcal.getInc0MFlg()) {
//                  PUTERR("前受リース料の月数か回収金のどちらかに値を設定して下さい。");
                    bflgErrorCheck = false;
                }
                /*
                if (!_gcal.getPurchasFlg() && !_gcal.getInc0Flg() && _gcal.getPurchas() <= _gcal.getInc0()) {
                //                  PUTERR("前受リース料が購入価額を超えています。");
                LfcMessageBox.show(LfcLogicMsgConst.ERR023);
                bflgErrorCheck= false;
                }
                 */
            } else {
                if (_gcal.getInc0MFlg()) {
//                  PUTERR("リース月数を求める場合は、前受リース料の月数を入力して下さい。");
                    bflgErrorCheck = false;
                }
            }
            /*
            20040922 ljq delete
            if (!_gcal.getPurchasFlg() && !_gcal.getInc0Flg() && _gcal.getPurchas() <= _gcal.getInc0()) {
            //                  PUTERR("前受リース料が購入価額を超えています。");
            errMsglist = LfcLogicComm..addErrMsgList(LfcLogicMsgConst.ERR023,"メッセージ"errMsglist);

            //ZJ 20040805 start
            if (jf instanceof LsCalBaseInfoFrm) {
            ((LsCalBaseInfoFrm)jf).txtPurchase.requestFocus();
            }
            //ZJ 20040805 end

            bflgErrorCheck= false;
            }
             */
            /*--- 前受リース料回収日 */
            if ((!_gcal.getInc0Flg() && _gcal.getInc0() == 0 && (!_gcal.getLeaseMFlg() || _gcal.getInc0M() == 0)) ||
                    (_gcal.getInc0Flg() && !_gcal.getInc0MFlg() && _gcal.getInc0M() == 0)) {
                if (_gcal.getDate3YY() != 0 || _gcal.getDate3MM() != 0 || _gcal.getDate3DD() != 0) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR018, "ERR018", errMsglist);
                    bflgErrorCheck = false;
                }
                _gcal.setDInc0(LfcLogicComm.db3Itod(0, 0, 0));

            } else {
                /*
                if (_gcal.getInc0M() < 0) {
                LfcMessageBox.show(LfcLogicMsgConst.ERR017);
                }
                 */
                if (_gcal.getDate3YY() == 0 && _gcal.getDate3MM() == 0 && _gcal.getDate3DD() == 0) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR019, "ERR019", errMsglist);
                    bflgErrorCheck = false;
                }

//                if (!doDayCheck(_gcal.getDate3YY(), _gcal.getDate3MM(), _gcal.getDate3DD() == 0 ? 1 : _gcal.getDate3DD())) {
//                    errMsglist = LfcLogicComm..addErrMsgList(LfcLogicMsgConst.ERR020,"メッセージ"errMsglist);
//                    bflgErrorCheck= false;
//                }
//
                if (_gcal.getDate1DD() == 0 || _gcal.getDate3DD() == 0) {
                    if (_gcal.getDate1YY() * 100 + _gcal.getDate1MM() > _gcal.getDate3YY() * 100 + _gcal.getDate3MM()) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR021, "ERR021", errMsglist);
                        bflgErrorCheck = false;
                    }
                } else {
                    if (_gcal.getDate1YY() * 10000 + _gcal.getDate1MM() * 100 + _gcal.getDate1DD() > _gcal.getDate3YY() * 10000 + _gcal.getDate3MM() * 100 + _gcal.getDate3DD()) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR021, "ERR021", errMsglist);
                        bflgErrorCheck = false;
                    }
                }
                /*
                if (_stairs.getDateDD(_stairs.getTopRow()) == 0 || _gcal.getDate3DD() == 0) {
                if (_gcal.getDate3YY() * 100 + _gcal.getDate3MM() > _stairs.getDateYY(_stairs.getTopRow()) * 100 + _stairs.getDateMM(_stairs.getTopRow())) {
                errMsglist = LfcLogicComm..addErrMsgList(LfcLogicMsgConst.ERR022,"メッセージ"errMsglist);
                bflgErrorCheck= false;
                }
                }else {
                if (_gcal.getDate3YY() * 10000 + _gcal.getDate3MM() * 100 + _gcal.getDate3DD() > _stairs.getDateYY(_stairs.getTopRow()) * 10000 + _stairs.getDateMM(_stairs.getTopRow()) * 100 + _stairs.getDateDD(_stairs.getTopRow())) {
                errMsglist = LfcLogicComm..addErrMsgList(LfcLogicMsgConst.ERR022,"メッセージ"errMsglist);
                bflgErrorCheck= false;
                }
                }
                 */
                //前受リース料回収日と検収予定日の関係のチェック、(検収予定年月より、360月)
                if (_gcal.getDate3YY() * 12 + _gcal.getDate3MM() > (_gcal.getDate1YY() + 30) * 12 + _gcal.getDate1MM()) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR021, "ERR021", errMsglist);
                    bflgErrorCheck = false;
                }
                _gcal.setDInc0(LfcLogicComm.db3Itod(_gcal.getDate3YY(), _gcal.getDate3MM(), _gcal.getDate3DD() == 0 ? 1 : _gcal.getDate3DD()));
            }
        }

        //ﾘｰｽ段数を取得
        _gcal.setLeaseD(0);
        for (int i = 0; i < 360; ++i) {
            if (_stairs.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                _gcal.setLeaseD(_gcal.getLeaseD() + 1);
            }
        }
        //回収データが入力していないチェック
        if (_gcal.getLeaseD() < 1) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR025, "ERR025", errMsglist);
            bflgErrorCheck = false;
        }
        ArrayList<ErrorInforOutputComplexType>  errMsglistSubErrChk=doSubErrChk(nCalItem,nBaseProf);
        if (!errMsglistSubErrChk.isEmpty()) {
            errMsglist.addAll(errMsglistSubErrChk);
            bflgErrorCheck = false;
        }
        if (_nIncomeCount != 0 && _gcal.getPurchasFlg()) {
//            PUTERR("購入価額か回収金のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR088, "ERR088", errMsglist);
            bflgErrorCheck = false;
        } else if (_nFrequeCount != 0 && _gcal.getPurchasFlg()) {
//            PUTERR("購入価額か回数のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR089, "ERR089", errMsglist);
            bflgErrorCheck = false;
        } else if (_nIncomeCount != 0 && (_gcal.getFremIX() == 0 && _gcal.getRemValFlg() && _gcal.getRemVRtFlg())) {
//            PUTERR("残価か回収金のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR090, "ERR090", errMsglist);
            bflgErrorCheck = false;
        } else if ((_gcal.getFremIX() == 0 && _gcal.getRemValFlg() && _gcal.getRemVRtFlg()) && _nFrequeCount != 0) {
//            PUTERR("残価か回数のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR091, "ERR091", errMsglist);
            bflgErrorCheck = false;
        } else if (_nIncomeCount != 0 && _gcal.getLeaseMFlg()) {
//            PUTERR("リ－ス月数か回収金のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR092, "ERR092", errMsglist);
            bflgErrorCheck = false;
        } else if (_nIncomeCount != 0 && _nFrequeCount != 0) {
//            PUTERR("回収金か回数のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR093, "ERR093", errMsglist);
            bflgErrorCheck = false;
        } else if (_nIncomeCount != 0 && _gcal.getLeaseD() == 1 && _gcal.getRyortTFlg() && _gcal.getRyortMFlg() && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
//            PUTERR("回収金か料率／採算項目のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR094, "ERR094", errMsglist);
            bflgErrorCheck = false;
        } else if (_nIncomeCount != 0 && _gcal.getLeaseD() > 1 && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
//            PUTERR("回収金か採算項目のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR095, "ERR095", errMsglist);
            bflgErrorCheck = false;
        } else if (_nFrequeCount != 0 && _gcal.getRateUnFlg() && _gcal.getRateROIFlg() && _gcal.getTrueRtFlg()) {
//            PUTERR("回数か採算項目のどちらかに値を設定して下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR096, "ERR096", errMsglist);
            bflgErrorCheck = false;
        } else if (_nFrequeCount != 0 && !_gcal.getLeaseMFlg()) {
//            PUTERR("最終段の回数を求める場合は、リース月数を空白にして下さい。");
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR097, "ERR097", errMsglist);
            bflgErrorCheck = false;
        }
        if (_gcal.getPurchasFlg() || (_gcal.getRemValFlg() && _gcal.getRemVRtFlg()) || _nIncomeCount != 0) {
            if (_gcal.getLeaseM() == 1) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR013, "ERR013", errMsglist);

                //ZJ 20040805 start
//                if (jf instanceof LsCalBaseInfoFrm) {
//                    ((LsCalBaseInfoFrm)jf).cbxLeaseM.getEditor().getEditorComponent().requestFocus();
//                }
                //ZJ 20040805 end

                bflgErrorCheck = false;
            }
        }
//        if (_nCntrctType == LfcLogicPgConst.LEASE) {
        if (true) {
            if (_gcal.getLeaseD() > 1) {
                if ((_gcal.getRemValFlg() && _gcal.getRemVRtFlg()) || _gcal.getPurchasFlg() || _nIncomeCount != 0) {
                    if (_gcal.getInc0Flg() && (_gcal.getInc0MFlg() || _gcal.getInc0M() != 0)) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR016, "ERR016",errMsglist);
                        bflgErrorCheck= false;
                    }
                }
            }
        }
        return errMsglist;

    }

    boolean doDayCheck(int nYy, int nMm, int nDd) {
        long tmp;
        if (nYy == 0) {
            return false;
        }
        if (nYy < 100) {
            nYy += 1900;
        }
        tmp = LfcLogicComm.db3Itod(nYy, nMm, nDd);
        if (LfcLogicComm.db3Year(tmp) == nYy && LfcLogicComm.db3Month(tmp) == nMm && LfcLogicComm.db3Day(tmp) == nDd) {
            return true;
        } else {
            return false;
        }
    }

    ArrayList<ErrorInforOutputComplexType> doSubErrChk(int nCalItem,int nBaseProf) {
        int i;
        long lChkDt;
        int nPos;
        //回収金額の複数段が未入力カウンタ変数
        int nIncome = 0;
        //回収回数の複数段が未入力カウンタ変数
        int nFreque = 0;
        int nLastCol = 0;
        _nIncomeCount = 0;
        _nFrequeCount = 0;
        _gcal.setInddFlg(0);
        boolean bflgErrorCheck = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();

        lChkDt = LfcLogicComm.db3Year(_gcal.getDKensh() * 12 + LfcLogicComm.db3Month(_gcal.getDKensh()) - 1);
        for (i = 0; i < 360; i++) {
            if (_stairs.getAct(i) == LfcLogicPgConst.KUBUN_YES) {
                break;
            }
        }
        _stairs.setTopRow(i);
        nPos = 0;
        for (; i < 360; i++) {
            if (_stairs.getAct(i) == LfcLogicPgConst.KUBUN_NO) {
                continue;
            }
            nLastCol = i;
            nPos = nPos + 1;
            if (_stairs.getIncome(i) <= 0) {
                if (nCalItem != 1) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                            (i + 1) +LfcLogicMsgConst.ERR026, "ERR026",errMsglist);
                    bflgErrorCheck= false;
                }
                _nIncomeCount = nPos;
                nIncome = nIncome + 1;
            }
            //回収回数逆算以外、回収回数未入力チェック
            if (_stairs.getFreque(i) <= 0) {
                //回収回数逆算以外の場合、
                if (nCalItem != LfcLogicPgConst.CAL_ITEM_KAISU) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                            (i + 1) +LfcLogicMsgConst.ERR035, "ERR035",errMsglist);
                    bflgErrorCheck= false;
                }
                _nFrequeCount = nPos;
                nFreque = nFreque + 1;
            }
            //回収回数逆算以外、回収回数>360のチェック
            if (_stairs.getFreque(i) > 360) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +LfcLogicMsgConst.ERR036, "ERR036",errMsglist);
                bflgErrorCheck= false;
            }
            if (_stairs.getCycle(i) <= 0) {
                if (_stairs.getFreque(i) == 1) {
                    _stairs.setCycle(1, i);
                } else {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                            (i + 1) +LfcLogicMsgConst.ERR033, "ERR033",errMsglist);
                    bflgErrorCheck= false;
                }
            }
            if (_stairs.getCycle(i) > 360) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +LfcLogicMsgConst.ERR034, "ERR034",errMsglist);
                bflgErrorCheck= false;
            }
            if (_stairs.getDateDD(i) == 0) {
                _gcal.setInddFlg(1);
            }
            if (_stairs.getDateYY(i) == 0 && _stairs.getDateMM(i) == 0 && _stairs.getDateDD(i) == 0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +LfcLogicMsgConst.ERR029, "ERR029",errMsglist);
                bflgErrorCheck= false;
            }
            if (!doDayCheck(_stairs.getDateYY(i),
                    _stairs.getDateMM(i),
                    _stairs.getDateDD(i) == 0 || _stairs.getDateDD(i) == 99 ? 1 : _stairs.getDateDD(i))) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +LfcLogicMsgConst.ERR030, "ERR030",errMsglist);
                bflgErrorCheck= false;
            }
            //第１段の場合、
            if (i + 1 == 1) {
                //第１回目の回収予定日と検収予定日の関係のチェック（第1段の回収予定日<検収予定日の場合、エラー）
                if (_gcal.getDate1DD() == 0 || _stairs.getDateDD(i) == 0 || _stairs.getDateDD(i) == 99) {
                    if ((_gcal.getDate1YY()) * 100 + _gcal.getDate1MM() > _stairs.getDateYY(i) * 100 + _stairs.getDateMM(i)) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR031, "ERR031",errMsglist);
                        bflgErrorCheck= false;
                    }
                } else {
                    if ((_gcal.getDate1YY()) * 10000 + _gcal.getDate1MM() * 100 + _gcal.getDate1DD() > _stairs.getDateYY(i) * 10000 + _stairs.getDateMM(i) * 100 + _stairs.getDateDD(i)) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR031, "ERR031",errMsglist);
                        bflgErrorCheck= false;
                    }
                }
            }
            //
            if ((_stairs.getDateYY(i) * 12 + _stairs.getDateMM(i)) - lChkDt - 1 < 0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR069 +
                        (i + 1) +LfcLogicMsgConst.ERR032, "ERR032",errMsglist);
                bflgErrorCheck= false;
            }
            lChkDt = _stairs.getDateYY(i) * 12 + _stairs.getDateMM(i) + (_stairs.getFreque(i) - 1) * _stairs.getCycle(i);
        }
        //回収金額を複数求める事が出来ないチェック(複数段の回収金額が０でした。)
        if (nIncome > 1) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR027, "ERR027",errMsglist);
            bflgErrorCheck= false;
        }
        //回数を複数求める事が出来ないチェック(複数段の回収回数=0の場合)
        if (nFreque > 1) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR038, "ERR038",errMsglist);
            bflgErrorCheck= false;
        }
        //最終段以外の回数を求めることはできないチェック(最終段回収回数<>0、前の段の回収回数=0)
        if (nFreque == 1 && _stairs.getFreque(nLastCol) > 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR037, "ERR037",errMsglist);
            bflgErrorCheck= false;
        }
        //回収金額逆算、全て段の回収金額が０ではないチェック(求めたい回収金を0にしてください)
        if (nCalItem == LfcLogicPgConst.CAL_ITEM_KINGAKU && nPos > 1 && nIncome == 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR028, "ERR028",errMsglist);
            bflgErrorCheck= false;
        }
        /*
        //回収回数逆算、全て段の回収回数０ではないチェック(求めたい回収回数を0にしてください)
        if (LsCalComm.getReqItem() == 3 && nPos > 1 && nFreque == 0) {
        LfcMessageBox.show(LfcLogicMsgConst.ERR039);
        bflgErrorCheck= false;
        }
         */
        if (nCalItem!= LfcLogicPgConst.CAL_ITEM_KAISU) {
            if (lChkDt - LfcLogicComm.db3Year(_gcal.getDKensh()) * 12 + LfcLogicComm.db3Month(_gcal.getDKensh()) + 1 > 400) {
//                PUTERR("回収期間が長すぎます。（４００か月を越えています。）");
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR086, "ERR086",errMsglist);
                bflgErrorCheck= false;
            }
        }

        _stairs.setLastRow(nLastCol);
        return errMsglist;
    }

    private ArrayList<ErrorInforOutputComplexType> addErrMsgList(
            String strMessage,
            String strTitle,
            ArrayList<ErrorInforOutputComplexType> errMsglist) {
        ArrayList<ErrorInforOutputComplexType> errMsglistOout = null;
        errMsglistOout = LfcLogicComm.addErrMsgList(strMessage, strTitle, errMsglist);
        return errMsglistOout;
    }
}


