/*
 * @(#)Lfatcal.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.cal.lease;

import com.gecl.leaseCal.logic.comm.Gcal;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;

/**
 * 固定資産税算出Bean。
 * @author  廖家慶
 * @version 01-01、 2003/05/20
 * @since   01-01
 */
public class LsCalFatcal {

    Gcal _gcal= null;

    public LsCalFatcal() {
    }

    public void setPara(Gcal gcal) {
        _gcal = gcal;
    }

   public void  doCalculate() {

        double StandRt = 0.014;         //固定資産税率
        double BookRt;                  //薄価率
        double DepreRt;                 //償却率
        int leaseYr;                    //歴史年数
        int NN;                         //最終年数

        //償却率算出
        DepreRt = LfcLogicComm.dround(1 - Math.pow(0.1, (1.0 / _gcal.getDuraY())) + 0.0000001, 3);
        if (_gcal.getDuraY() == 24 || _gcal.getDuraY() == 34 || _gcal.getDuraY() == 72 || _gcal.getDuraY() == 77){
            DepreRt = DepreRt + 0.001;
        }
        //薄価率判定
        leaseYr = (_gcal.getLeaseM() + 11) / 12;
        NN = leaseYr + 1;
        BookRt = 0;
        while (BookRt < 0.05 && NN > 0) {
            NN = NN - 1;
            //BookRt = (1.0 - DepreRt / 4) * Math.pow((1.0 - DepreRt), (NN - 1.0));
			BookRt = (1.0 - DepreRt*5/12) * Math.pow((1.0 - DepreRt), (NN - 1.0));
        }
        //固定資産税算出
        //ydy modify 20071204 s
//        _gcal.setFatax(LfcLogicComm.dround(_gcal.getPurchas() * (1.0 - DepreRt / 4)*(1.0 - Math.pow((1.0 - DepreRt), (double)NN))
        _gcal.setFatax(LfcLogicComm.dround(_gcal.getPurchas() * (1.0 - DepreRt * 5 / 12)*(1.0 - Math.pow((1.0 - DepreRt), (double)NN))
        //ydy modify 20071204 e
                / DepreRt * StandRt + 0.0001, 0) + LfcLogicComm.dround(_gcal.getPurchas() * (leaseYr - NN) * 0.05 * StandRt + 0.0001, 0));
   }
}
