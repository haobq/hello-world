/*
 * ﾌｧｲﾙ名：LfcFrmComm.java
 *
 * 修正履歴：
 *           ver1.00      2003.03.18      HaoBuQian
 *                        作成
 *　修正者：王嵩
 *	修正日：2005/01/17
 *　修正内容：YYYY/MM/DD HH:MM:SSからYYYYMMDD HH:MM:SSに変更するメソッドを追加する。
 *			 メソッド：formatDate10To8DT(String strDate)
 *　修正者：HBQ
 *	修正日：2005/02/08
 *　修正内容：文字<→＜；>→＞；&→＆；'→’；"→”
 *
 *           Copyright (c) 2004
 *
 * 修正者：曾健
 * 修正日：20051118
 * 修正内容：Create OldData Folder
 */
package com.gecl.leaseCal.logic.comm;

import java.awt.Rectangle;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import java.util.TimeZone;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import com.gecl.leaseCal.db.comm.LfcFrmBeanConst;

/**
 * ｸﾗｽ名：ｸﾗｲｱﾝﾄ共通機能
 *
 * 概要：  1.数字であるかﾁｪｯｸ
 *           2.数値ﾁｪｯｸ(小数点以下の数値もﾁｪｯｸ）
 *           3.ｶﾝﾏ（通貨用','）を追加
 *           4.ｶﾝﾏ（通貨用','）を削除
 *           5.有効の日付ﾁｪｯｸ
 *           6.日付編集
 *           7.日付を指定した型で変換
 *           8.日付大きさ比較
 *           9.ｼｽﾃﾑ日付取得
 *          10.文字列の長さ取得
 *          11.半角ｶﾀｶﾅがあるかのﾁｪｯｸ
 *          12.文字列中の小さい半角ｶﾅを大きい半角ｶﾅに変換
 *          13.有効な時刻であるかのﾁｪｯｸ
 *          14.時刻に日付を追加
 *          15.有効な日付時刻ﾁｪｯｸ
 *          16.指定した型の小数かをﾁｪｯｸ
 */
public class LfcFrmComm implements LfcFrmPgConst {

//	public static LfcFrame lfcFrame;
//	public static LfcDesktop lsCalDesktop;
//	public static LfcDesktopEst lsCalDesktopEst;
    //	public static final LfcDateChooser DATE_CHOOSER =
    //		new LfcDateChooser((JFrame) null, "Select Date");
    /**
     * 数値であるかﾁｪｯｸ
     * @param  strPara  判断しようとする文字列
     *
     * @return boolean
     * exception   判断しようとする文字列は数値でない
     */
    public static boolean isNumeric(String strPara) {
        // 臨時変数
        char tempchar[] = strPara.toCharArray();
        // 文字列の長さ
        int nLen = strPara.length();

        try {
            /* 全角ﾁｪｯｸ */
            boolean ret = checkZenkaku(strPara);
            if (ret == false) {
                return false;
            }

            /* 文字列の長さﾁｪｯｸ */
            if (nLen < 1) {
                return false;
            }

            for (int i = 0; i < nLen; i++) {
                if (tempchar[0] == '-' && i == 0) {
                    continue;
                }
                if (!Character.isDigit(tempchar[i])) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 数値ﾁｪｯｸ(小数点以下の数値もﾁｪｯｸ）
     * @param  strPara  判断しようとする文字列
     *
     * @return boolean
     * @exception  判断しようとする文字列は小数でない
     * @see  isFloat(String,float)
     */
    public static boolean isFloat(String strPara) {
        // 臨時変数
        char tempchar[] = strPara.toCharArray();
        // 文字列の長さ
        int nLen = strPara.length();

        try {
            /* 全角ﾁｪｯｸ */
            boolean ret = checkZenkaku(strPara);
            if (ret == false) {
                return false;
            }

            /* 先頭と最後が小数点の場合はNGとする */
            if ((tempchar[0] == '.') || (tempchar[nLen - 1] == '.')) {
                return false;
            }

            /* テップFloatへ変換 */
            Float.valueOf(strPara);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 指定した型の小数かﾁｪｯｸする
     * @param  strPara  判断しようとする文字列
     * @param  fltPara  小数の型
     *
     * @return boolean
     * @exception  判断しようとする文字列は小数でない
     * @see  isFloat(String)
     */
    public static boolean isFloat(String strPara, float fltPara) {
        // 文字列に小数点の位置
        int nIndexOfString = 0;
        // 小数の型に小数点の位置
        int nIndexOfFloat = 0;
        // 文字列の整数部分の長さ
        int nIntLenOfString = 0;
        // 文字列の小数部分の長さ
        int nDecLenOfString = 0;
        // 小数の型の整数部分
        int nIntOfFloat = 0;
        // 小数の型の小数部分
        int nDecOfFloat = 0;
        // 臨時文字列
        String strTemp = String.valueOf(fltPara);

        try {
            /* 通常小数であるのﾁｪｯｸ */
            if (!isFloat(strPara)) {
                return false;
            }

            // ﾊﾟﾗﾒｰﾀstrParaに小数点の位置を取得
            nIndexOfString = strPara.indexOf(".");
            if (nIndexOfString != -1) /* 数値に小数点はある */ {
                nIntLenOfString = strPara.substring(0, nIndexOfString).length();
                nDecLenOfString =
                        strPara.substring(nIndexOfString + 1).length();
            } else /* 数値に小数点はなし */ {
                nIntLenOfString = strPara.length();
                nDecLenOfString = 0;
            }

            // ﾊﾟﾗﾒｰﾀfltParaに小数点の位置を取得
            nIndexOfFloat = strTemp.indexOf(".");
            nIntOfFloat = Integer.parseInt(strTemp.substring(0, nIndexOfFloat));
            nDecOfFloat =
                    Integer.parseInt(strTemp.substring(nIndexOfFloat + 1));

            /* 指定した型のﾁｪｯｸ */
            if (nDecOfFloat == 0) /* 指定した型の小数部分はなし */ {
                if ((nIntLenOfString > nIntOfFloat) || (nDecLenOfString > nDecOfFloat)) {
                    return false;
                }
            } else /* 指定した型の小数部分はある */ {
                if ((nIntLenOfString > (nIntOfFloat - nDecOfFloat - 1)) || (nDecLenOfString > nDecOfFloat)) {
                    return false;
                }
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * ｶﾝﾏ（通貨用','）を追加
     * @param  lngPara  通貨数値
     *
     * @return string
     * @see  modUnComma(String)
     */
    public static String modCurrency(Long lngPara) {
        // 臨時文字列
        String strTemp = lngPara.toString();
        String strTempStore = "";
        int site = strTemp.indexOf("-");
        if (site != -1) {
            strTempStore = "-";
            strTemp = strTemp.substring(1);
        }
        // ｴﾗ-戻る値
        String strErr = "";
        // 可変文字列
        StringBuffer strBuf1 = new StringBuffer();
        // 可変文字列
        StringBuffer strBuf2 = new StringBuffer();
        // 臨時変数
        char tempchar[] = strTemp.toCharArray();
        // 文字列の長さ
        int nLen = strTemp.length();

        /* パラメータがnullの場合 ""戻る */
        if (nLen < 1) {
            return strErr;
        }

        /* 三桁毎にｶﾝﾏ追加 */
        for (int i = nLen - 1, k = 0; i >= 0; i--) {
            if (i == (nLen - (3 * k) - 4)) {
                k++;
                strBuf1.append(',');
            }
            strBuf1.append(tempchar[i]);
        }

        /* 文字列再設置 */
        for (int j = strBuf1.length() - 1; j >= 0; j--) {
            strBuf2.append(strBuf1.charAt(j));
        }
        strTemp = strBuf2.toString();
        return strTempStore + strTemp;
    }

    public static String modCurrencyPre(Long lngPara) {
        String strRet = modCurrency(lngPara);
        return "\\" + strRet;
    }

    public static String modCurrency(long lngPara) {
        // 臨時文字列
        String strTemp = String.valueOf(lngPara);
        String strTempStore = "";
        int site = strTemp.indexOf("-");
        if (site != -1) {
            strTempStore = "-";
            strTemp = strTemp.substring(1);
        }
        // ｴﾗ-戻る値
        String strErr = "";
        // 可変文字列
        StringBuffer strBuf1 = new StringBuffer();
        // 可変文字列
        StringBuffer strBuf2 = new StringBuffer();
        // 臨時変数
        char tempchar[] = strTemp.toCharArray();
        // 文字列の長さ
        int nLen = strTemp.length();

        /* パラメータがnullの場合 ""戻る */
        if (nLen < 1) {
            return strErr;
        }

        /* 三桁毎にｶﾝﾏ追加 */
        for (int i = nLen - 1, k = 0; i >= 0; i--) {
            if (i == (nLen - (3 * k) - 4)) {
                k++;
                strBuf1.append(',');
            }
            strBuf1.append(tempchar[i]);
        }

        /* 文字列再設置 */
        for (int j = strBuf1.length() - 1; j >= 0; j--) {
            strBuf2.append(strBuf1.charAt(j));
        }
        strTemp = strBuf2.toString();
        return strTempStore + strTemp;
    }

    public static String modCurrencyPre(long lngPara) {
        String strRet = modCurrency(lngPara);
        return "\\" + strRet;
    }

    /**
     * ｶﾝﾏ（通貨用','）を追加
     * @param  lngPara  通貨数値
     *
     * @return string
     * @see  modUnComma(String)
     */
    public static String modCurrency(String strPara) {
        if (strPara == null || strPara.equals("")) {
            return "";
        }

        String strTempStore = "";
        int site = strPara.indexOf("-");
        if (site != -1) {
            strTempStore = "-";
            strPara = strPara.substring(1);
        }
        strPara = modUnComma(strPara);
        Long lngPara = Long.valueOf(strPara);
        // 臨時文字列
        String strTemp = lngPara.toString();
        // ｴﾗ-戻る値
        String strErr = "";
        // 可変文字列
        StringBuffer strBuf1 = new StringBuffer();
        // 可変文字列
        StringBuffer strBuf2 = new StringBuffer();
        // 臨時変数
        char tempchar[] = strTemp.toCharArray();
        // 文字列の長さ
        int nLen = strTemp.length();

        /* パラメータがnullの場合 ""戻る */
        if (nLen < 1) {
            return strErr;
        }

        /* 三桁毎にｶﾝﾏ追加 */
        for (int i = nLen - 1, k = 0; i >= 0; i--) {
            if (i == (nLen - (3 * k) - 4)) {
                k++;
                strBuf1.append(',');
            }
            strBuf1.append(tempchar[i]);
        }

        /* 文字列再設置 */
        for (int j = strBuf1.length() - 1; j >= 0; j--) {
            strBuf2.append(strBuf1.charAt(j));
        }
        strTemp = strBuf2.toString();
        return strTempStore + strTemp;
    }

    public static String modCurrencyPre(String strPara) {
        String strRet = modCurrency(strPara);
        return "\\" + strRet;
    }

    /**
     * ｶﾝﾏ（通貨用','）を削除
     * @param  strPara  ｶﾝﾏを外そうとする文字列
     *
     * @return string
     * @see modCurrency(Long)
     */
    public static String modUnComma(String strPara) {
        // 臨時文字列
        String strTemp = "";

        /* パラメータが""の場合""を戻る */
        if (strPara.equals("")) {
            return strPara;
        } else if (strPara.indexOf("\\") != -1) {
            strPara = strPara.replace('\\', ' ').trim();
        }

        /* 全部ｶﾝﾏを削除 */
        for (int i = 0; i < strPara.length(); i++) {
            if (!strPara.substring(i, i + 1).equals(",")) {
                strTemp = strTemp + strPara.substring(i, i + 1);
            }
        }
        return strTemp;
    }

    public static String modUnCommaPre(String strPara) {
        String strRet = modUnComma(strPara);
        if (strRet.indexOf("\\") > 0) {
            return strRet.substring(1, strRet.length());
        }
        return strRet;
    }

    /**
     * 指定したキャラクターがが文字列内に存在する数量。
     * @param  strString
     * @param  cValue
     *
     * @return int
     */
    public static int getCharNumInStr(String strString, char cValue) {
        int nCount = 0;
        char cTemp[] = strString.toCharArray();
        for (int i = 0; i < cTemp.length; i++) {
            if (cTemp[i] == cValue) {
                nCount = nCount + 1;
            }
        }
        return nCount;
    }

    /**
     * 有効の日付ﾁｪｯｸ
     * @param  strPara  判断しようとする文字列
     *
     * @return boolean
     * @exception  判断しようとする文字列の部分は数値へ変換できない
     * @see  isDateTime(String)
     */
    public static boolean isDate(String strPara) {
        /*
        int n = 1;
        if (n == 1) {
        return true;
        }
         */
        // 文字列の長さ
        int nLen = strPara.length();
        // 年、月、日を数値保存
        int nYear = 0, nMonth = 0, nDay = 0;
        // 年、月、日を文字列保存
        String strYear = "", strMonth = "", strDay = "";
        // 臨時変数
        char tempchar[] = strPara.toCharArray();
        // ｴﾗｰﾌﾗｸﾞ
        boolean errorFlag = false;

        try {
            /* 全角ﾁｪｯｸ */
            boolean ret = checkZenkaku(strPara);
            if (ret == false) {
                return false;
            }

            /* 文字列を年、月、日に分割 */
            switch (nLen) {
                case 8: // YYYYMMDD
                    strYear = strPara.substring(0, 4);
                    strMonth = strPara.substring(4, 6);
                    strDay = strPara.substring(6, 8);
                    break;
                case 10: // YYYY/MM/DD
                    if ((tempchar[4] == '/') && (tempchar[7] == '/')) {
                        strYear = strPara.substring(0, 4);
                        strMonth = strPara.substring(5, 7);
                        strDay = strPara.substring(8);
                    }
                    break;
                default:
                    errorFlag = true;
                    break;
            }

            /* 有効日付形式以外ｴﾗｰ */
            if (errorFlag == true) {
                return false;
            }

            /* 文字列から数値へ変換 */
            nYear = Integer.parseInt(strYear);
            nMonth = Integer.parseInt(strMonth);
            nDay = Integer.parseInt(strDay);

            /* 月毎の基本日数を保存 */
            int[] nDayOfMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

            //added start by BQG 2004/07/23
			/* 00 と99 の転換*/
            if (nDay == 0) {
                nDay = 1;
            } else if (nDay == 99) {
                nDay = nDayOfMonth[nMonth - 1];
            }
            //			added end by BQG 2004/07/23

            /* 日付の月と日をﾁｪｯｸ */
            if ((nMonth < 1) || (nMonth > 12) || (nDay < 1) || (nDay > 32)) {
                return false;
            }

            GregorianCalendar calendar =
                    (GregorianCalendar) GregorianCalendar.getInstance();
            // 閏年の判断
            if (calendar.isLeapYear(nYear)) {
                nDayOfMonth[1] = 29;
            }
            // 月毎の日数判断
            if (nDay > nDayOfMonth[nMonth - 1]) {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static boolean isEstDate(String strPara) {

        // 文字列の長さ
        int nLen = strPara.length();
        // 年、月、日を数値保存
        int nYear = 0, nMonth = 0, nDay = 0;
        // 年、月、日を文字列保存
        String strYear = "", strMonth = "", strDay = "";
        // 臨時変数
        char tempchar[] = strPara.toCharArray();
        // ｴﾗｰﾌﾗｸﾞ
        boolean errorFlag = false;

        try {
            /* 全角ﾁｪｯｸ */
            boolean ret = checkZenkaku(strPara);
            if (ret == false) {
                return false;
            }

            /* 文字列を年、月、日に分割 */
            switch (nLen) {
                case 8: // YYYYMMDD
                    strYear = strPara.substring(0, 4);
                    strMonth = strPara.substring(4, 6);
                    strDay = strPara.substring(6, 8);
                    break;
                case 10: // YYYY/MM/DD
                    if ((tempchar[4] == '/') && (tempchar[7] == '/')) {
                        strYear = strPara.substring(0, 4);
                        strMonth = strPara.substring(5, 7);
                        strDay = strPara.substring(8);
                    }
                    break;
                default:
                    errorFlag = true;
                    break;
            }

            /* 有効日付形式以外ｴﾗｰ */
            if (errorFlag == true) {
                return false;
            }

            /* 文字列から数値へ変換 */
            nYear = Integer.parseInt(strYear);
            nMonth = Integer.parseInt(strMonth);
            nDay = Integer.parseInt(strDay);

            /* 日付の月と日をﾁｪｯｸ */
            if ((nMonth < 1) || (nMonth > 12)) {
                return false;
            }
            if (nDay < 1) {
                if (nDay != 0) {
                    return false;
                }
            }
            if (nDay > 31) {
                if (nDay != 99) {
                    return false;
                }
            }

            /* 月毎の基本日数を保存 */
            int[] nDayOfMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

            GregorianCalendar calendar =
                    (GregorianCalendar) GregorianCalendar.getInstance();
            // 閏年の判断
            if (calendar.isLeapYear(nYear)) {
                nDayOfMonth[1] = 29;
            }
            // 月毎の日数判断
            if (nDay != 0 && nDay != 99) {
                if (nDay > nDayOfMonth[nMonth - 1]) {
                    return false;
                }
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * ｺﾝｽﾄﾗｸﾀ1:末日を取得
     * @param   sData	   Stringの日期
     * @param   戻り値	  String
     */
    public static String Matsubi(String sDate) {
        int intyear = Integer.parseInt(sDate.substring(0, 4)); //年取得
        int intmonth = Integer.parseInt(sDate.substring(4, 6)); //月取得
        int matsubi = 31; //末日初期化
        if ((intmonth == 4) || (intmonth == 6) || (intmonth == 9) || (intmonth == 11)) {
            matsubi = 30;
        }
        if (intmonth == 2) {
            if (intyear % 4 == 0) {
                matsubi = 29;
            } else {
                matsubi = 28;
            }
        }
        return (Integer.toString(matsubi));
    }

    /**
     * 有効の日付時刻ﾁｪｯｸ
     * @param  strPara  判断しようとする文字列
     *
     * @return boolean
     * @exception  判断しようとする文字列は日付時刻でない
     * @see  isDate(String)
     */
    public static boolean isDateTime(String strPara) {
        // 文字列の長さ
        int nLen = strPara.length();
        // 日付を保存用文字列
        String strDate = "";
        // ｽﾍﾟｰｽを保存用文字列
        String strSpace = "";
        // 時刻を保存用文字列
        String strTime = "";
        // ｴﾗｰﾌﾗｸﾞ
        boolean errorFlag = false;

        try {
            /* 長さをﾁｪｯｸ */
            switch (nLen) {
                case 10: // YYYY/MM/DD
                    if (!isDate(strPara)) {
                        errorFlag = true;
                    }
                    break;
                case 16: // YYYY/MM/DD HH:MM
					/* 文字列の分割と判断 */
                    strDate = strPara.substring(0, 10);
                    strSpace = strPara.substring(10, 11);
                    strTime = strPara.substring(11);
                    // 日付のﾁｪｯｸ
                    if (!isDate(strDate)) {
                        errorFlag = true;
                    }
                    // 文字列中にｽﾍﾟｰｽのﾁｪｯｸ
                    if (!strSpace.equals(ONE_SPACE)) {
                        errorFlag = true;
                    }
                    // 時刻のﾁｪｯｸ
                    if (!isTime(strTime)) {
                        errorFlag = true;
                    }
                    break;
                default:
                    errorFlag = true;
                    break;
            }
            /* 返却値を設定 */
            if (errorFlag == true) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 日付編集
     * @param  strPara  変換元ﾃﾞｰﾀ
     * @param  intkind  年/月型かほかの型かの区分
     *
     * @return string
     * @exception  文字列から数値へ変換時のｴﾗｰ
     * @see  modDate(GregorianCalendar,Strinf)
     */
    public static String modDate(String strPara, int intKind) {
        // 文字列の長さ
        int nLen = strPara.length();
        // 臨時変数
        int nTemp;
        // 臨時変数
        Integer itgTemp;
        // 年、月、日を文字列保存
        String strYear = "", strMonth = "", strDay = "";
        // ｴﾗｰ戻る値
        String strErr = "";
        // 正常戻る値
        String strRet = "";
        // 日付に年を追加ﾌﾗｸﾞ
        boolean addYearFlag = false;
        // ｴﾗｰﾌﾗｸﾞ
        boolean errorFlag = false;
        // 臨時変数
        char tempchar[] = strPara.toCharArray();

        /* 月毎の基本日数を保存 */
        int[] nDayOfMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        GregorianCalendar calendar =
                (GregorianCalendar) GregorianCalendar.getInstance();

        try {
            /* 全角ﾁｪｯｸ */
            if (!checkZenkaku(strPara)) {
                return strErr;
            }
            // 日付種類の区分
            switch (intKind) {
                case 1:
                    switch (nLen) {
                        case 4: // YYMM
                            strYear = strPara.substring(0, 2);
                            strMonth = strPara.substring(2);
                            addYearFlag = true;
                            break;
                        case 5: // YY/MM
                            if (tempchar[2] == '/') {
                                strYear = strPara.substring(0, 2);
                                strMonth = strPara.substring(3);
                                addYearFlag = true;
                            }
                            break;
                        case 6: // YYYYMM
                            strYear = strPara.substring(0, 4);
                            strMonth = strPara.substring(4);
                            break;
                        case 7: // YYYY/MM
                            if (tempchar[4] == '/') {
                                strRet = strPara;
                            }
                            break;
                        default:
                            errorFlag = true;
                            break;
                    }
                    break;
                case 2:
                    switch (nLen) {
                        case 4: // MMDD
                            strRet =
                                    strPara.substring(0, 2) + "/" + strPara.substring(2);
                            break;
                        case 5: // MM/DD
                            if (tempchar[2] == '/') {
                                strRet = strPara;
                            }
                            break;
                        case 6: // YYMMDD
                            strYear = strPara.substring(0, 2);
                            strMonth = strPara.substring(2, 4);
                            strDay = strPara.substring(4);
                            addYearFlag = true;
                            break;
                        case 8: // YY/MM/DDまたはYYYYMMDD
                            if ((tempchar[2] == '/') && (tempchar[5] == '/')) // YY/MM/DD
                            {
                                strYear = strPara.substring(0, 2);
                                strMonth = strPara.substring(3, 5);
                                strDay = strPara.substring(6);
                                addYearFlag = true;
                            } else // YYYYMMDD
                            {
                                strYear = strPara.substring(0, 4);
                                strMonth = strPara.substring(4, 6);
                                strDay = strPara.substring(6);
                            }
                            break;
                        case 10: // YYYY/MM/DD
                            if ((tempchar[4] == '/') && (tempchar[7] == '/')) {
                                strYear = strPara.substring(0, 4);
                                strMonth = strPara.substring(5, 7);
                                strDay = strPara.substring(8);
                                //								strRet = strPara;
                            }
                            break;
                        default:
                            errorFlag = true;
                            break;
                    }
                    break;
                case 3:
                    switch (nLen) {
                        case 4: // HHMM
                            strRet =
                                    strPara.substring(0, 2) + ":" + strPara.substring(2);
                            break;
                        case 5: // HH:MM
                            if (tempchar[2] == ':') {
                                strRet = strPara;
                            }
                            break;
                        default:
                            errorFlag = true;
                            break;
                    }
                    break;
                default:
                    errorFlag = true;
                    break;
            }

            /* ｴﾗｰ時返却値を設定 */
            if (errorFlag == true) {
                return strErr;
            }

            if (!strYear.equals("")) {
                // 閏年の判断
                if (calendar.isLeapYear(Integer.parseInt(strYear))) {
                    nDayOfMonth[1] = 29;
                }
                if (addYearFlag == true) /* 年の先頭二桁を追加 */ {
                    itgTemp = Integer.valueOf(strYear);
                    nTemp = itgTemp.intValue();
                    if ((nTemp >= 0) && (nTemp <= 79)) {
                        strRet = "20" + strYear + "/" + strMonth;
                    } else {
                        strRet = "19" + strYear + "/" + strMonth;
                    }
                } else {
                    strRet = strYear + "/" + strMonth;
                }

                if (!strDay.equals("")) {
                    if (Integer.parseInt(strMonth) != 0) {
                        if (Integer.parseInt(strDay) == 0) {
                            strDay = "01";
                        } else if (Integer.parseInt(strDay) == 99) {
                            strDay =
                                    String.valueOf(
                                    nDayOfMonth[Integer.parseInt(strMonth) - 1]);
                        }
                    }
                    // 日の追加
                    strRet = strRet + "/" + strDay;
                }
            }
            // 返却値を設定
            return strRet;
        } catch (Exception e) {
            return strErr;
        }
    }

    /**
     * 日付を指定した型で変換
     * @param  GregorianCalendar  変換元ﾃﾞｰﾀ
     * @param  strPara  出力しようとするﾃﾞｰﾀFormat
     *
     * @return string
     * @exception  パラメータstrParaは正確の日付形式でない
     * @see  modDate(String,int)
     */
    public static String modDate(GregorianCalendar datDate, String strPara) {
        // ｴﾗｰ戻る値
        String strErr = "";

        try {
            // 日付形式のｲﾝｽﾀﾝｽ生成
            SimpleDateFormat sFormat = new SimpleDateFormat(strPara);
            // 返却値を設定
            return (sFormat.format(datDate.getTime()));
        } catch (Exception e) {
            return strErr;
        }
    }

    /**
     * 日付大きさ比較
     * @param  GregorianCalendar  比較元ﾃﾞｰﾀ
     * @param  GregorianCalendar  比較先ﾃﾞｰﾀ
     *
     * @return int
     */
    public static int compareDate(
            GregorianCalendar dteSource,
            GregorianCalendar dteDestnation) {
        if (dteSource.getTime().equals(dteDestnation.getTime())) // "="
        {
            return 0;
        } else {
            if (dteSource.getTime().after(dteDestnation.getTime())) // ">"
            {
                return 1;
            } else // "<"
            {
                return -1;
            }
        }
    }

    /**
     * Compare two string date
     * @param  date1
     * @param  date2
     *
     * @return int
     */
    public static int compareDateStr(String date1, String date2) {
        if (isDate(date1) && isDate(date2)) {
            int date1Y =
                    Integer.parseInt(date1.substring(0, date1.indexOf("/")));
            if (date1.substring(0, date1.indexOf("/")).length() == 2) {
                if (date1Y >= 0 && date1Y <= 79) {
                    date1Y = date1Y + 2000;
                } else {
                    date1Y = date1Y + 1900;
                }
            }
            int date1M =
                    Integer.parseInt(
                    date1.substring(
                    date1.indexOf("/") + 1,
                    date1.lastIndexOf("/")));
            date1M = date1M - 1;
            int date1D =
                    Integer.parseInt(date1.substring(date1.lastIndexOf("/") + 1));

            int date2Y =
                    Integer.parseInt(date2.substring(0, date2.indexOf("/")));
            if (date2.substring(0, date2.indexOf("/")).length() == 2) {
                if (date2Y >= 0 && date2Y <= 79) {
                    date2Y = date2Y + 2000;
                } else {
                    date2Y = date2Y + 1900;
                }
            }
            int date2M =
                    Integer.parseInt(
                    date2.substring(
                    date2.indexOf("/") + 1,
                    date2.lastIndexOf("/")));
            date2M = date2M - 1;
            int date2D =
                    Integer.parseInt(date2.substring(date2.lastIndexOf("/") + 1));
            GregorianCalendar gc =
                    new GregorianCalendar(date1Y, date1M, date1D);
            GregorianCalendar gc1 =
                    new GregorianCalendar(date2Y, date2M, date2D);
            return compareDate(gc, gc1);
        } else {
            return -2;
        }
    }

    /**
     * Fromat data
     * @param  str
     * @param  length
     * @param  value
     *
     * @return String
     */
    public static String format(String str, int length, char value) {
        if (str.length() >= length) {
            return str;
        } else {
            String temp = "";
            for (int i = 0; i < (length - str.length()); i++) {
                temp = temp + String.valueOf(value);
            }
            return temp + str;
        }
    }

    /**
     * Fromat data
     * @param  lngValue
     * @param  length
     * @param  value
     *
     * @return String
     */
    public static String format(Long lngValue, int length, char value) {
        String str = String.valueOf(lngValue);
        if (str.length() >= length) {
            return str;
        } else {
            String temp = "";
            for (int i = 0; i < (length - str.length()); i++) {
                temp = temp + String.valueOf(value);
            }
            return temp + str;
        }
    }

    /**
     * Fromat data
     * @param  nValue
     * @param  length
     * @param  value
     *
     * @return String
     */
    public static String format(int nValue, int length, char value) {
        String str = String.valueOf(nValue);
        if (str.length() >= length) {
            return str;
        } else {
            String temp = "";
            for (int i = 0; i < (length - str.length()); i++) {
                temp = temp + String.valueOf(value);
            }
            return temp + str;
        }
    }

    /**
     * ｼｽﾃﾑ日付取得
     * @param  strPara  出力しようとするFormat
     *
     * @return string
     * @exception パラメータは正確の日付形式でない
     */
    public static String getSysdate(String strPara) {
        // ｴﾗｰ戻る値
        String strErr = "";

        try {
            // ｼｽﾃﾑ日付取得
            Date sysdate = new Date();
            // 日付形式のｲﾝｽﾀﾝｽ生成
            SimpleDateFormat sFormat = new SimpleDateFormat(strPara);
            // 日本の標準時区を取得する
            TimeZone tz = TimeZone.getTimeZone("JST");
            // 日本の標準時区を設定する
            sFormat.setTimeZone(tz);
            // 返却値を設定
            return (sFormat.format(sysdate));
        } catch (Exception e) {
            return strErr;
        }
    }

    /**
     * 秒を含むｼｽﾃﾑ日付取得
     * @param  strPara  出力しようとするFormat
     * @see    #getSysdate(String)
     * @return string
     * @exception パラメータは正確の日付形式でない
     */
    public static String getSysDate_SS(String strPara) {
        /*入力のString内で、秒("SS" or "ss")が最初に出現する位置を取得する。*/
        int nSS_Index = strPara.toUpperCase().indexOf("SS");
        String strSysDate_SS;
        if (nSS_Index == -1) {
            /*入力のString内で秒("SS" or "ss")がないの時、戻る*/
            return getSysdate(strPara);
        }
        /*正確ｼｽﾃﾑ日付(秒を含む)を取得する*/
        strSysDate_SS = getSysdate(strPara);
        while (Integer.valueOf(strSysDate_SS.substring(nSS_Index, nSS_Index + 2)).intValue() > 59) {
            strSysDate_SS = getSysdate(strPara);
        }
        return strSysDate_SS;
    }

    /**
     * 文字列の長さ取得
     * @param  strPara  判断しようとする文字列
     *
     * @return int
     * @exception  文字列からバイトへ変換時ｴﾗｰ
     */
    public static int getEUCLength(String strPara) {
        // 臨時変数
        byte tempbyte[];

        try {
            // 文字列からバイトへ変換
            tempbyte = strPara.getBytes("SJIS");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return 0;
        }
        // 文字列のSJIS長さ
        int nLensjis = tempbyte.length;
        // 文字列のEUC長さ初期化
        int nLeneuc = 0;

        /* 文字列のEUC長さを取得 */
        for (int i = 0; i < nLensjis;) {
            byte b = tempbyte[i];

            if (((b >= -127) && (b <= -97)) || ((b >= -32) && (b <= -17))) /* 全角１バイト目(0x81-0x9F, 0xE0-0xEF) */ {
                i += 2;
                nLeneuc += 2;
            } else {
                if ((b >= -95) && (b <= -33)) /* 半角ｶﾀｶﾅ(0xA1-0xDF) */ {
                    i++;
                    nLeneuc += 2;
                } else /* その他 */ {
                    i++;
                    nLeneuc++;
                }
            }
        }
        return nLeneuc;
    }

    /**
     * 半角ｶﾀｶﾅがあるかのﾁｪｯｸする
     * @param  strPara  判断しようとする文字列
     *
     * @return int
     * @exception  字符比較時ｴﾗｰ
     */
    public static int hasHalfKana(String strPara) {
        // 臨時変数
        char tempchar[] = strPara.toCharArray();
        // 可変文字列
        StringBuffer strBuf = new StringBuffer();
        // 文字列の長さ
        int nLen = strPara.length();

        try {
            /* 半角ｶﾀｶﾅがあるかのﾁｪｯｸ */
            for (int i = 0; i < nLen; i++) {
                if ((tempchar[i] >= '\uFF66') && (tempchar[i] <= '\uFF9F')) // 半角ｶﾀｶﾅがある
                {
                    return 1;
                }
            }
            // 半角ｶﾀｶﾅがなし
            return -1;
        } catch (Exception e) {
            return 0;
        }
    }
    //hbq 20050208 add start

    /**
     * ｺﾝｽﾄﾗｸﾀ: 文字<→＜；>→＞；&→＆；'→’；"→”
     * @param   文字列	   Stringの文字
     * @param   戻り値	  String
     */
    public static String CnvStr(String p_src_str) {
        if (p_src_str == null) {
            return ("");
        } else {
            return (p_src_str.replaceAll("&", "＆").
                    replaceAll("<", "＜").
                    replaceAll(">", "＞").
                    replaceAll("\"", "”").
                    replaceAll("'", "’"));
        }

    }
    //hbq 20050208 add end

    /**
     * 文字列中の小さい半角ｶﾅを大きい半角ｶﾅに変換
     * @param  strPara  変換しようとする文字列
     *
     * @return string
     */
    public static String modHalfKana(String strPara) {

        strPara = CnvStr(strPara);
        // 文字列の長さ
        int nLen = strPara.length();
        // 臨時変数
        char tempchar[] = strPara.toCharArray();

        for (int i = 0; i < nLen; i++) {
            switch (tempchar[i]) {
                case '\uFF67': //  ｱ
                    tempchar[i] = '\uFF71';
                    break;
                case '\uFF68': //  ｲ
                    tempchar[i] = '\uFF72';
                    break;
                case '\uFF69': //  ｳ
                    tempchar[i] = '\uFF73';
                    break;
                case '\uFF6A': //  ｴ
                    tempchar[i] = '\uFF74';
                    break;
                case '\uFF6B': //  ｵ
                    tempchar[i] = '\uFF75';
                    break;
                case '\uFF6C': //  ﾔ
                    tempchar[i] = '\uFF94';
                    break;
                case '\uFF6D': //  ﾕ
                    tempchar[i] = '\uFF95';
                    break;
                case '\uFF6E': //  ﾖ
                    tempchar[i] = '\uFF96';
                    break;
                case '\uFF6F': //  ﾂ
                    tempchar[i] = '\uFF82';
                    break;
                case '\uFF70': //  ｰ
                    tempchar[i] = '-';
                    break;
                default:
                    break;
            }
        }
        return new String(tempchar);
    }

    /**
     * 有効な時刻であるかのﾁｪｯｸ
     * @param  strPara  判断しようとする文字列
     *
     * @return boolean
     * @exception  文字列から数値へ変換時ｴﾗｰ
     */
    public static boolean isTime(String strPara) {
        // 文字列の長さ
        int nLen = strPara.length();
        // 時、分、秒を数値で保存
        int nHour = 0, nMinute = 0, nSecond = 0;
        // 時、分、秒を文字列で保存
        String strHour = "", strMinute = "", strSecond = "";
        // 臨時変数
        char tempchar[] = strPara.toCharArray();
        // ｴﾗｰﾌﾗｸﾞ
        boolean errorFlag = false;

        try {
            /* 全角ﾁｪｯｸ */
            boolean ret = checkZenkaku(strPara);
            if (ret == false) {
                return false;
            }

            /* 長さをﾁｪｯｸ */
            switch (nLen) {
                case 5: // HH:MM
                    for (int i = 0; i < 5; i++) {
                        if (!Character.isDigit(tempchar[i])) // 数字以外の場合
                        {
                            if (tempchar[i] != ':') {
                                errorFlag = true;
                            }
                            if (i != 2) {
                                errorFlag = true;
                            }
                        }
                    }
                    strHour = strPara.substring(0, 2);
                    strMinute = strPara.substring(3);
                    // HH:MM形式時有効の秒追加
                    strSecond = "01";
                    break;
                case 6: // HHMMSS
                    if (!isNumeric(strPara)) {
                        errorFlag = true;
                    }
                    strHour = strPara.substring(0, 2);
                    strMinute = strPara.substring(2, 4);
                    strSecond = strPara.substring(4);
                    break;
                case 8: // HH:MM:SS
                    for (int i = 0; i < 8; i++) {
                        if (!Character.isDigit(tempchar[i])) // 数字以外の場合
                        {
                            if (tempchar[i] != ':') {
                                errorFlag = true;
                            }
                            if ((i != 2) && (i != 5)) {
                                errorFlag = true;
                            }
                        }
                    }
                    strHour = strPara.substring(0, 2);
                    strMinute = strPara.substring(3, 5);
                    strSecond = strPara.substring(6);
                    break;
                default:
                    errorFlag = true;
                    break;
            }
            /* ｴﾗｰ時返却値を設定 */
            if (errorFlag == true) {
                return false;
            }

            /* String->Integer */
            Integer intghh = Integer.valueOf(strHour);
            Integer intgmm = Integer.valueOf(strMinute);
            Integer intgss = Integer.valueOf(strSecond);

            /* integer->int */
            nHour = intghh.intValue();
            nMinute = intgmm.intValue();
            nSecond = intgss.intValue();

            // 時のﾁｪｯｸ
            if ((nHour < 0) || (nHour > 23)) {
                return false;
            }
            // 分のﾁｪｯｸ
            if ((nMinute < 0) || (nMinute > 59)) {
                return false;
            }
            // 秒のﾁｪｯｸ
            if ((nSecond < 0) || (nSecond > 59)) {
                return false;
            }
            return true;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 指定された時間の前にシステム日付を追加して返却
     * @param  strPara  DBに保存しようとする時刻
     *
     * @return string
     */
    public static String modSQLDate(String strPara) {
        // ｴﾗｰ戻る値
        String strErr = "";
        // 臨時文字列
        String strTemp = "";
        // 正常戻る値
        String strRet = "";

        /* 時刻のﾁｪｯｸ */
        if (!isTime(strPara)) {
            return strErr;
        }
        // ｼｽﾃﾑ日付を取得
        strTemp = getSysdate(DATE_TYPE_YYYY_MM_DD);
        // 日付の追加
        strRet = strTemp + " " + strPara;
        return strRet;
    }

    /**
     * 全角ある無しﾁｪｯｸ
     * @param  strPara  判断しようとする文字列
     *
     * @return boolean
     */
    public static boolean checkZenkaku(String strPara) {
        // 文字列の長さ
        int nLenOfStr = strPara.length();
        // 臨時変数
        byte tempbyte[] = strPara.getBytes();
        // バイトの長さ
        int nLenOfByte = tempbyte.length;

        if (nLenOfStr < nLenOfByte) {
            return false;
        }
        return true;
    }

    /**
     * 日付増える関数．    <BR>
     *
     *<PRE>
     * 日付増える(年、月、日それぞれ増えるできる)
     *</PRE>
     *
     * @param   nFlag       0: 年増える １：月増える ２：日増える
     * @param   strYYYYMMDD 増えるしたいの日付
     * @param   nLen        増えるの値
     * @return  String 増えるされた日付
     *
     */
    public static String addDate(int nFlag, String strYYYYMMDD, int nLen) {
        // 年取得
        int nY = Integer.parseInt(strYYYYMMDD.substring(0, 4));
        // 月取得
        int nM = Integer.parseInt(strYYYYMMDD.substring(5, 7));
        // 日取得
        int nD = Integer.parseInt(strYYYYMMDD.substring(8, 10));
        // 古いの最大天数
        int nOldDay = getDayOfMonth(strYYYYMMDD.substring(0, 7));
        GregorianCalendar gmt;

        if (nFlag == DATE_ADD_YEAR) {
            gmt = new GregorianCalendar(nY, nM - 1, 1);
            gmt.add(Calendar.YEAR, nLen);
        } else {
            if (nFlag == DATE_ADD_MONTH) {
                gmt = new GregorianCalendar(nY, nM - 1, 1);
                gmt.add(Calendar.MONTH, nLen);
            } else {
                gmt = new GregorianCalendar(nY, nM - 1, nD);
                gmt.add(Calendar.DAY_OF_YEAR, nLen);
            }
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        String strDate = format.format(gmt.getTime());

        /* 日は月の最後日時、特別の処理 */
        if (nFlag == DATE_ADD_MONTH || nFlag == DATE_ADD_YEAR) {
            int nNewDay = getDayOfMonth(strDate.substring(0, 7));
            if (nOldDay == nD || nD > nNewDay) {
                strDate =
                        strDate.substring(0, 7) + "/" + String.valueOf(nNewDay);
            } else {
                strDate = strDate.substring(0, 7) + "/" + format(nD, 2, '0');
            }
        }
        return strDate;
    }

    /**
     * 日付増える関数（契約用）．    <BR>
     *
     *<PRE>
     * 日付増える(年、月、日それぞれ増えるできる)
     *</PRE>
     *
     * @param   nFlag       0: 年増える １：月増える ２：日増える
     * @param   strYYYYMMDD 増えるしたいの日付
     * @param   nLen        増えるの値
     * @return  String 増えるされた日付
     *
     */
    public static String addDateInCnt(
            int nFlag,
            String strYYYYMMDD,
            int nLen) {
        // 年取得
        int nY = Integer.parseInt(strYYYYMMDD.substring(0, 4));
        // 月取得
        int nM = Integer.parseInt(strYYYYMMDD.substring(5, 7));
        // 日取得
        int nD = Integer.parseInt(strYYYYMMDD.substring(8, 10));
        // 古いの最大天数
        int nOldDay = getDayOfMonth(strYYYYMMDD.substring(0, 7));
        GregorianCalendar gmt;

        if (nFlag == DATE_ADD_YEAR) {
            gmt = new GregorianCalendar(nY, nM - 1, 1);
            gmt.add(Calendar.YEAR, nLen);
        } else {
            if (nFlag == DATE_ADD_MONTH) {
                gmt = new GregorianCalendar(nY, nM - 1, 1);
                gmt.add(Calendar.MONTH, nLen);
            } else {
                gmt = new GregorianCalendar(nY, nM - 1, nD);
                gmt.add(Calendar.DAY_OF_YEAR, nLen);
            }
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        String strDate = format.format(gmt.getTime());

        /* 日は月の最後日時、特別の処理 */
        if (nFlag == DATE_ADD_MONTH || nFlag == DATE_ADD_YEAR) {
            int nNewDay = getDayOfMonth(strDate.substring(0, 7));
            if (nD > nNewDay) {
                strDate =
                        strDate.substring(0, 7) + "/" + String.valueOf(nNewDay);
            } else {
                strDate = strDate.substring(0, 7) + "/" + format(nD, 2, '0');
            }
        }
        return strDate;
    }

    /**
     * 画面検索ｷｰ入力値は変更かどうかの判断を行う．
     *
     *<PRE>
     * いまの検索ｷｰ配列と古い検索ｷｰ配列と比較する。
     *</PRE>
     *
     * @param  keyQuery_Old  古い検索ｷｰ配列
     * @param  keyQuery_New  いまの検索ｷｰ配列
     *
     * @return boolean (ﾁｪｯｸ結果 True：同じ、False：同じではない)
     *
     */
    public static boolean checkKeyStatus(
            String[] keyQuery_Old,
            String[] keyQuery_New) {
        //以前の検索ｷｰを出力する
        for (int i = 0; i < keyQuery_Old.length; i++) {
        }
        //現在の検索ｷｰを出力する
        for (int j = 0; j < keyQuery_New.length; j++) {
        }
        if (keyQuery_Old.length != keyQuery_New.length) {
            return false;
        }
        //以前の検索ｷｰと現在の検索ｷｰと比較する
        for (int k = 0; k < keyQuery_Old.length; k++) {
            if (keyQuery_Old[k] == null && keyQuery_New[k] == null) {
                continue;
            } else if (keyQuery_Old[k] == null || keyQuery_New[k] == null) {
                return false;
            } else if (!keyQuery_Old[k].equals(keyQuery_New[k])) {
                return false;
            }
        }
        return true;
    }

    /**
     * 指定年月で含む日数を取得する．<BR>
     *
     *<PRE>
     * １．年月のﾀｲﾌﾟはYYYY/MMである
     * ２．戻し日数はintである
     *</PRE>
     *
     * @param   strYM  指定した年月
     * @return  int 	 指定した年月の日数
     */
    public static int getDayOfMonth(String strYM) {
        int[] nDayOfMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        GregorianCalendar calendar =
                (GregorianCalendar) GregorianCalendar.getInstance();

        // 閏年の判断
        if (calendar.isLeapYear(Integer.parseInt(strYM.substring(0, 4)))) {
            nDayOfMonth[1] = 29;
        }

        String strDay = strYM.substring(5, 7);

        int nDayMonth = Integer.parseInt(strDay);
        // 結果を戻す
        return nDayOfMonth[nDayMonth - 1];

    }

    /**
     * 指定年月の範囲を判定する．<BR>
     *
     *<PRE>
     * 指定年月の範囲を判定する
     * 指定年月の範囲は(判定の基準年月-月の最低限度数)
     * ～(判定の基準年月+月の最高限度数)です
     *</PRE>
     *
     * @param    nLowerLimit      月の最低限度数
     * @param    nUpperLimit      月の最高限度数
     * @param    strDateYM        判定されたの年月
     * @param    strBaseDateYM    判定の基準年月
     * @return   boolean
     */
    public static boolean isDateInBound(
            int nLowerLimit,
            int nUpperLimit,
            String strDateYM,
            String strBaseDateYM) {
        /*入力年月の書式が不正しい場合、falseを戻る*/
        if ((strBaseDateYM.length() != 7 && strBaseDateYM.length() != 0) || (strDateYM.length() != 7 && strDateYM.length() != 0) || (nLowerLimit == 0 && nUpperLimit == 0)) {
            return false;
        }

        if (strBaseDateYM.length() == 0) {
            //入力の判定基準年月は空きStringです時、判定基準年月はｼｽﾃﾑ年月です
            strBaseDateYM = getSysdate("yyyy/MM");
        }

        /*判定された年月を設定する*/
        int nDateY = Integer.valueOf(strDateYM.substring(0, 4)).intValue();
        int nDateM = Integer.valueOf(strDateYM.substring(5, 7)).intValue();
        int nDateMonths = nDateY * 12 + nDateM;
        /*基準年月を設定する*/
        int nDateBaseY =
                Integer.valueOf(strBaseDateYM.substring(0, 4)).intValue();
        int nDateBaseM =
                Integer.valueOf(strBaseDateYM.substring(5, 7)).intValue();
        int nDateBaseMonths = nDateBaseY * 12 + nDateBaseM;

        /*年月範囲を判定する*/
        if (nDateMonths >= nDateBaseMonths - nLowerLimit && nDateMonths <= nDateBaseMonths + nUpperLimit) {
            return true;
        }
        return false;
    }

    /**
     * 重複したﾃﾞｰﾀを削除
     * @param  strData  抽出元ﾃﾞｰﾀ
     * @return String[][]
     * @exception   配列を使用中にｴﾗｰ
     */
    public static String[][] distinctData(String[][] strData)
            throws Exception {
        int nCnt;
        int nLen = strData.length;
        // 臨時変数1
        String[][] strTemp1 = new String[nLen][2];
        // 臨時変数2
        String[][] strTemp2 = null;
        boolean isSingle;
        nCnt = 0;
        try {
            /* 配列にﾃﾞｰﾀをｾｯﾄする */
            for (int i = 0; i < nLen; i++) {
                isSingle = true;
                for (int j = i + 1; j < nLen; j++) {
                    if (strData[i][0].equals(strData[j][0])) {
                        isSingle = false;
                        break;
                    }
                }
                if (isSingle) {
                    strTemp1[nCnt][0] = strData[i][0];
                    strTemp1[nCnt][1] = strData[i][1];
                    nCnt = nCnt + 1;
                }
            }
            strTemp2 = new String[nCnt][2];
            for (int i = 0; i < nCnt; i++) {
                strTemp2[i] = strTemp1[i];
            }
            return strTemp2;
        } catch (Exception e) {
            return strTemp2;
        }
    }

    /**
     * 当前のthreadをsleepする
     * @param  lngMSecond  sleepの秒
     * @return なし
     *
     */
    public static void setSleep(long lngMSecond) {
        try {
            Thread.sleep(lngMSecond);
        } catch (Exception e) {
        }
    }

    /**
     *  String → doubleに変換
     * @param sData
     * @return
     */
    public static double ToDouble(String sData) {
        String result = "";
        if ((sData != null) && (!sData.equals(""))) {
            for (int i = 0; i < sData.length(); ++i) {
                if (sData.charAt(i) != ',') {
                    result = result + sData.charAt(i);
                }
            }
        } else {
            result = "0";
        }
        Double dresult = new Double(result);
        return (dresult.doubleValue());
    }

    /**
     *  String → intに変換
     * @param sData
     * @return
     */
    public static int toInt(String sData) {
        String result = "";
        if (sData != null) {
            sData = sData.trim();
        }
        if ((sData != null) && (!sData.equals(""))) {
            for (int i = 0; i < sData.length(); ++i) {
                if (sData.charAt(i) != ',') {
                    result = result + sData.charAt(i);
                }
            }
        } else {
            result = "0";
        }
        //		Integer iresult = new Integer(result);
        //		return (iresult.intValue());
        //ltq
        if ((result != null) && (!result.equals("")) && (!result.equals("null"))) {
            return (Integer.parseInt(result));
        } else {
            return 0;
        }
    }

    /**
     *  String → longに変換
     * @param sData
     * @return
     */
    public static long ToLong(String sData) {
        String result = "";
        sData = "" + (long) ToDouble(sData);
        if ((sData != null) && (!sData.equals(""))) {
            for (int i = 0; i < sData.length(); ++i) {
                if (sData.charAt(i) != ',') {
                    result = result + sData.charAt(i);
                }
            }
        } else {
            result = "0";
        }
        Long lresult = new Long(result);
        return (lresult.longValue());
    }

    public static int isCntrctType(String strCntrctNo) {
        if (strCntrctNo == null || "".equals(strCntrctNo)) {
            return LEASE;
        }
        if (strCntrctNo.length() == 3) {
            if ("L".equals(strCntrctNo.substring(2, 3).toUpperCase())) {
                return LEASE;
            } else if ("S".equals(strCntrctNo.substring(2, 3).toUpperCase())) {
                return KAPPU;
            } else {
                return CNTRCT_TYPE_BUG;
            }
        }
        try {
            if ("L".equals(strCntrctNo.substring(2, 3).toUpperCase()) || "KL".equals(strCntrctNo.substring(2, 4).toUpperCase()) || "AL".equals(strCntrctNo.substring(2, 4).toUpperCase())) {
                return LEASE;
            } else if ("S".equals(strCntrctNo.substring(2, 3).toUpperCase()) || "KS".equals(strCntrctNo.substring(2, 4).toUpperCase()) || "AS".equals(strCntrctNo.substring(2, 4).toUpperCase())) {
                return KAPPU;
            } else {
                return CNTRCT_TYPE_BUG;
            }
        } catch (StringIndexOutOfBoundsException e) {
            return CNTRCT_TYPE_BUG;
        }
    }

    public static String changeDate(String sDate) {
        StringTokenizer st = new StringTokenizer(sDate, "/");
        String sReturnDate = "";
        while (st.hasMoreTokens()) {
            sReturnDate = sReturnDate + st.nextToken();
        }
        return sReturnDate;
    }

    public static String bigDround(double x, int y) {

        double x1 = x;
        int y1 = y;
        double re = dround(x1, y1);
        String str2 = Double.toString(re);
        BigDecimal big = new BigDecimal(str2);
        String str = big.toString();

        int index = str.indexOf(".");

        if (index < 0) {
            str = str + ".000";
        } else {
            String subStr = str.substring(index);
            if (subStr.length() < 3) {
                str = str + "00";
            }
            if (subStr.length() == 3) {
                str = str + "0";
            }
        }
        return str;

    }

    public static String bigDround(double x) {

        double x1 = x;
        double re = dround(x1, 0);
        String str = modCurrency((long) re);
        return str;

    }

    public static double dround(double x, int y) {
        if (x < 0) {
            return (Math.ceil((x) * Math.pow(10.0, (double) (y)) - 0.5) / Math.pow(10.0, (double) (y)));
        } else {
            return (Math.floor((x) * Math.pow(10.0, (double) (y)) + 0.5) / Math.pow(10.0, (double) (y)));
        }
    }

    public static double truncate(double x, int y) {
        if (x < 0) {
            return (Math.ceil((x) * Math.pow(10.0, (double) (y))) / Math.pow(10.0, (double) (y)));
        } else {
            return (Math.floor((x) * Math.pow(10.0, (double) (y))) / Math.pow(10.0, (double) (y)));
        }
    }

    public static double dround(String z, int y) {
        if (z == null || z.length() == 0) {
            return 0;
        }
        double x = Double.parseDouble(z);
        if (x < 0) {
            return (Math.ceil((x) * Math.pow(10.0, (double) (y)) - 0.5) / Math.pow(10.0, (double) (y)));
        } else {
            return (Math.floor((x) * Math.pow(10.0, (double) (y)) + 0.5) / Math.pow(10.0, (double) (y)));
        }
    }

    public static String lostNull(String _strValue) {
        String _strReturn = "";
        if (_strValue != null) {
            _strReturn = _strValue.trim();
        }
        return _strReturn;
    }

    public static String lostNull(Object obj) {
        String _strReturn = "";
        if (obj != null) {
            _strReturn = obj.toString();
        }
        return _strReturn;
    }

    public static String maxAdjust(double dValue, int maxLen) {
        String _strReturn = "";
        /*		if (dValue > 0) {
        if (Math.pow(10, maxLen) > dValue) {
        _strReturn = "" + (long) dValue;
        }
        } else {
        if ((long) (Math.pow(10, maxLen - 1)) > (long) (dValue * (-1))) {
        _strReturn = "" + (long) dValue;
        }
        }
         */
        _strReturn = "" + (long) dValue;
        return _strReturn;
    }

    public static String unformatDate(String strDate) {
        String _strReturn = "";
        for (int i = 0; i < strDate.length(); i++) {
            if (strDate.charAt(i) == '/') {
            } else {
                _strReturn = _strReturn + strDate.charAt(i);
            }
        }
        return _strReturn;
    }

    public static String formatAdder(String strNo, int nTotal, String strCon) {
        String strReturnNo = "";
        int nNo = strNo.length();
        StringBuffer tmpStrZero = new StringBuffer();
        for (int l = 0; l < (nTotal - nNo); l++) {
            tmpStrZero = tmpStrZero.append(strCon);
        }
        strReturnNo = tmpStrZero.toString() + strNo;
        return strReturnNo;
    }

    public static String formatAddSpace(String strNm, int nHan) {
        String strReturnBukNm = "";
        int nNm = strNm.length();
        if (nNm >= nHan) {
            strReturnBukNm = strNm.substring(0, nHan);
        } else {
            StringBuffer tmpStrSpace = new StringBuffer();
            for (int k = 0; k < (nHan - nNm); k++) {
                tmpStrSpace = tmpStrSpace.append("　");
            }
            strReturnBukNm = strNm + tmpStrSpace.toString();
        }
        return strReturnBukNm;
    }

    static public String formatDate8To10(String strDate) {
        //hbq 20051207 bug 修正 begin
        if (strDate == null) {
            return "";
        }
        //hbq 20051207 bug 修正　end
        if (strDate.length() != 8) {
            //20040607 ltq estのlease\LsEstConditionPnlの前受回収日を修正たので、あの修正しました。
            return "";
            //			return strDate;
        } else {
            return strDate.substring(0, 4) + "/" + strDate.substring(4, 6) + "/" + strDate.substring(6, 8);
        }
    }

    static public String formatDate10To8(String strDate) {
        if (strDate.length() != 10) {
            //			return strDate;
            //			20040607 ltq estのlease\LsEstConditionPnlの前受回収日を修正たので、あの修正しました。
            return "";

        } else {
            return strDate.substring(0, 4) + strDate.substring(5, 7) + strDate.substring(8, 10);
        }
    }

//ws 20050117 add start
    static public String formatDate10To8DT(String strDate) {
        if (strDate.length() > 17) {
            return LfcFrmComm.formatDate10To8(strDate.substring(0, 10)) + strDate.substring(10);
        } else {
            return strDate;
        }
    }
//ws 20050117 add end

    static public int flagDisplay(String strFlag, int nSelectIndex) {
        if ("".equals(strFlag)) {
            if (nSelectIndex == 0) {
                return 0;
            } else {
                return 1;
            }
        }
        return toInt(strFlag) - 1;
    }

    static public String flagSave(int nSelectIndex) {
        switch (nSelectIndex) {
            case -1:
                return "";
            default:
                return "" + (nSelectIndex + 1);
        }
    }

    static public int methodDisplay(String strDbMethod) {
        int nDbMethod = toInt(strDbMethod);
        switch (nDbMethod) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                //			修正 Start by Bian Qinggang 2004/05/21
                //			case 6 :
                //				return nDbMethod - 1;
                return nDbMethod;
            //			修正 End by Bian Qinggang 2004/05/21

            case 9:
                return 6;
            default:
                //			修正 Start by Bian Qinggang 2004/05/21
                //				return -1;
                return 0;
            //			修正 End by Bian Qinggang 2004/05/21

        }
    }
    /*
    static public String methodSave(String strMethodIndex) {
    int nMethodIndex = toInt(strMethodIndex);
    switch(nMethodIndex) {
    case  1:
    case  2:
    case  3:
    case  4:
    case  5:
    return "" + (nMethodIndex + 1);
    case  6:
    return "9";
    default:
    return "";
    }
    }
     */

    /**
     * <p>methodSave</p>
     * @param nMethodIndex a number
     * @return a String
     */
    static public String methodSave(int nMethodIndex) {
        //        int nMethodIndex = toInt(strMethodIndex);
        switch (nMethodIndex) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                //修正 Start by Bian Qinggang 2004/05/21
                //				return "" + (nMethodIndex + 1);
                return "" + nMethodIndex;
            //修正 End by Bian Qinggang 2004/05/21
            case 6:
                return "9";
            default:
                return "";
        }
    }

    static public boolean isFileExistence(String strFile) {
        File file = new File(strFile);
        if (file.exists()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * ｺﾝｽﾄﾗｸﾀ1:次の何ヶ月あとの年月を取得
     * @param   sData	   Stringの日期
     * @param   戻り値	  String
     */
    static public String MonthPlus(String sDate, int months) {
        int intyear = Integer.parseInt(sDate.substring(0, 4)); //年取得
        int intmonth = Integer.parseInt(sDate.substring(4, 6)); //月取得
        int soumonths = intyear * 12 + intmonth + months;
        int aftermonth = soumonths % 12;
        if (aftermonth == 0) {
            aftermonth = 12;
        }
        int afteryear = (soumonths - aftermonth) / 12;
        return (Integer.toString(afteryear * 100 + aftermonth));
    }

    /**
     * メソッド:次の何ヶ月あとの年月日を取得
     * @param   sData	   Stringの日期(YYYYMMDD)
     * @param   戻り値	  String
     */
    static public String MonthDatePlus(String sDate, int months) {
        String strMonth = MonthPlus(sDate, months);
        String strMonthPlusCurrDate = strMonth + sDate.substring(6, 8);
        String strMonthPlusFirstDate = strMonth + "01";
        String strMonthPlusLastDate = strMonth + Matsubi(strMonthPlusFirstDate);
        String strMonthPlusDate = strMonthPlusCurrDate;
        if (toInt(strMonthPlusCurrDate) > toInt(strMonthPlusLastDate)) {
            strMonthPlusDate = strMonthPlusLastDate;
        }
        return (strMonthPlusDate);
    }

    public static boolean isDateFormEst(String strPara) {
        if (strPara.length() != 8 && strPara.length() != 10) {
            return false;
        }
        if (strPara.length() == 8) {
            if ("00".equals(strPara.substring(6, 8)) || "99".equals(strPara.substring(6, 8))) {
                strPara = strPara.substring(0, 6) + "01";
            }
        }
        if (strPara.length() == 10) {
            if ("00".equals(strPara.substring(8, 10)) || "99".equals(strPara.substring(8, 10))) {
                strPara = strPara.substring(0, 8) + "01";
            }
        }
        return isDate(strPara);
    }

    public static void printStr1(String[] strOut) {
        if (strOut == null) {
            return;
        }
        for (int i = 0; i < strOut.length; i++) {
        }
    }

    public static void printStr2(String[][] strOut) {
        if (strOut == null) {
            return;
        }
        for (int i = 0; i < strOut.length; i++) {
            for (int j = 0; j < strOut[i].length; j++) {
            }
        }
    }

    public static void printInt1(int[] strOut) {
        //			"****************begin print array "
        //				+ strOut
        //				+ "*****************");
        if (strOut == null) {
            return;
        }
        for (int i = 0; i < strOut.length; i++) {
        }
        //			"****************end print array " + strOut + "*****************");
    }

    public static void printInt2(int[][] strOut) {
        //			"****************begin print array "
        //				+ strOut
        //				+ "*****************");
        if (strOut == null) {
            return;
        }
        for (int i = 0; i < strOut.length; i++) {
            for (int j = 0; j < strOut[i].length; j++) {
            }
        }
        //			"****************end print array " + strOut + "*****************");
    }

    public static void printKeyBukken2(String[][] strOut) {
        if (strOut == null) {
            return;
        }
        for (int i = 0; i < strOut.length; i++) {
            //				strOut[i][1] + "," + strOut[i][strOut[i].length - 1]);
        }
    }

    public static void printStr2(String[][] strOut, int nOutCol) {
        if (strOut == null) {
            return;
        }
        for (int i = 0; i < strOut.length; i++) {
        }
    }

    public static void printStr2(String[][] strOut, int[] nOutCol) {
        if (strOut == null) {
            return;
        }
        for (int i = 0; i < strOut.length; i++) {
            for (int j = 0; j < nOutCol.length; j++) {
            }
        }
    }

    public static boolean isHalf(char chr) {
        if (LfcConst.CHARS.indexOf(chr) > 0) {
            return true;
        }
        return false;
    }

    public static String editDateTime8To10(String strTemp) {
        StringTokenizer st = new StringTokenizer(strTemp, " ");
        String[] strDateTime = new String[2];
        strDateTime[0] = "";
        strDateTime[1] = "";
        int k = 0;
        while (st.hasMoreTokens()) {
            strDateTime[k] = st.nextToken();
            k++;
        }
        String strDateF = "";
        String strDateTimeF = "";
        if (strDateTime[0] != null && !"".equals(strDateTime[0])) {
            strDateF = LfcFrmComm.modDate(strDateTime[0], 2);
        }
        strDateTimeF = strDateF;
        if (strDateTime[1] != null && !"".equals(strDateTime[1])) {
            strDateTimeF = strDateF + " " + strDateTime[1];
        }
        //文字列日付の有効性をﾁｪｯｸする
        if (LfcFrmComm.isDate(strDateTime[0])) {
            return strDateTimeF;
        } else {
            return strDateTime[0] + " " + strDateTime[1];
        }

    }

    public static int Fix(double dFix) {
        if (dFix > 0) {
            return (int) dFix;
        }
        return ((int) dFix) + 1;
    }

    public static String asString(String sData) {
        if (sData == null || sData.length() == 0) {
            return "";
        } else {
            //hbq 20050209 修正　開始
            return CnvStr(sData);
            //hbq 20050209 修正　終了

        }
    }

    public static String asString16(String sData) {
        if (sData == null || sData.length() == 0) {
            return "";
        } else {
            if (sData.length() >= 16) {
                return sData.substring(0, 16);
            } else {
                return sData;
            }
        }
    }

    /**************************************************
     * <P>
     * 少数点以下N桁まで表示
     * </P>
     * @param EBuffer eBuffer 編集バッファ
     * @param double dblNumber
     * @param int 　少数点以下桁数
     * @return String　変換された数値
     **************************************************/
    public static String chgFloatN(double fltNumber, int n) {

        String strFloatN = null;

        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMaximumFractionDigits(n);
        nf.setMinimumFractionDigits(n);
        strFloatN = nf.format(fltNumber);
        return strFloatN;
    }
    //20040614 ltq 追加しました。

    /** 時間(YYYYMMDD HH:MM:SS)---->時間(YYYY/MM/DD HH:MM:SS)
     *  @param 時間(YYYYMMDD HH:MM:SS)
     *
     *  @return 時間(YYYY/MM/DD HH:MM:SS)
     */
    public static String dateAmended(String _str) {
        StringBuffer sb = new StringBuffer();
        try {
            /* 全角ﾁｪｯｸ */
            boolean ret = checkZenkaku(_str);
            if (ret == false) {
                return "";
            }

            if (_str.length() >= 8) {
                sb.append(_str.substring(0, 4));
                sb.append("/");
                sb.append(_str.substring(4, 6));
                sb.append("/");
                sb.append(_str.substring(6));
                return sb.toString();

            } else {
                return "";
            }
        } catch (Exception ex) {
            return "";
        }
    }
    //20040702 LTQ

    public static String doFormatToFloat(String strText) {
        if (strText != null && !"null".equals(strText)) {
            strText = LfcFrmComm.modUnComma(strText);
            if (strText.indexOf("%") > 0) {
                strText = strText.substring(0, strText.length() - 1);
                return strText;
            }
        }
        return strText;
    }

    /**
     * <p>入力の文字列（数値）を転換する
     * 例strinput(567.9998),iTotNum(6),iFraction(3) return値は68.000
     * 適用範囲：textField,ComboBoxの入力値</p>
     * @param strInput	入力の文字列
     * @param iTotNum 数値の全部の桁数
     * @param iFraction 数値の小数部の桁数
     * @return フォーマット後のデータ---文字列
     */
    public static String InputDataFormat(
            String strInput,
            int iTotNum,
            int iFraction) {
        if (strInput == null || "".equals(strInput)) {
            return "";
        }
        //入力の文字列-->ダブル類型の対象
        double dInput = Double.parseDouble(strInput);
        //入力の文字列整数部の桁数
        int iIntPart = iTotNum - iFraction - 1;
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMaximumIntegerDigits(iIntPart);
        nf.setMinimumIntegerDigits(iIntPart);
        nf.setMaximumFractionDigits(iFraction);
        nf.setMinimumFractionDigits(iFraction);
        //フォーマット化するデータ
        String strTempInput = nf.format(dInput);
        String strIntegerpart = strTempInput.substring(0, 2);
        String strFrapart = strTempInput.substring(3);
        String strRetValue =
                Integer.valueOf(strIntegerpart).toString() + "." + strFrapart;
        return strRetValue;

    }
    //20040705 ltq

    /**
     * <p>入力の文字列（数値）を転換する
     * 例strinput(567.9998),iTotNum(6),iFraction(3) return値は68.000
     * 適用範囲：textField,ComboBoxの入力値</p>
     * @param dInput	入力のdouble値
     * @param iTotNum 数値の全部の桁数
     * @param iFraction 数値の小数部の桁数
     * @return フォーマット後のデータ---文字列
     */
    public static String chgFloatFmtToStr(
            double dInput,
            int iTotNum,
            int iFraction) {
        int iIntPart = iTotNum - iFraction - 1;
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMaximumIntegerDigits(iIntPart);
        nf.setMinimumIntegerDigits(1);
        nf.setMaximumFractionDigits(iFraction);
        nf.setMinimumFractionDigits(iFraction);
        return nf.format(dInput);

    }

    /**
     * Added by Xing Yanfang
     * <p>format the time when day is 00 or 99</p>
     * @param strDate
     * @return
     */
    public static String getOO99Date(String strDate) {
        if ("".equals(strDate)) {
            return strDate;
        }
        if (!"00".equals(strDate.substring(strDate.length() - 2)) && !"99".equals(strDate.substring(strDate.length() - 2))) {
            return strDate;
        }
        if ("00".equals(strDate.substring(strDate.length() - 2))) {
            return strDate.substring(0, strDate.length() - 2) + "01";
        }
        int[] nDayOfMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        String strYear = strDate.substring(0, 4);
        String strMonth = strDate.substring(5, 7);
        String strDay = "";
        int nYear = Integer.parseInt(strYear);
        int nMonth = Integer.parseInt(strMonth);

        GregorianCalendar calendar =
                (GregorianCalendar) GregorianCalendar.getInstance();
        // 閏年の判断
        if (nMonth == 2) {
            if (calendar.isLeapYear(nYear)) {
                strDay = "29";
            } else {
                strDay = "28";
            }
        } else {
            strDay = "" + nDayOfMonth[nMonth - 1];
        }
        return formatDate8To10(strYear + strMonth + strDay);

    }
    //hbq add

    /**
     * ｺﾝｽﾄﾗｸﾀ1:末日を取得
     * @param   sData      Stringの日期
     * @param   戻り値   String
     */
    public static String Matsubi1(String sDate) {
        int intyear = Integer.parseInt(sDate.substring(0, 4)); //年取得
        int intmonth = Integer.parseInt(sDate.substring(4, 6)); //月取得
        int matsubi = 31; //末日初期化
        if ((intmonth == 4) || (intmonth == 6) || (intmonth == 9) || (intmonth == 11)) {
            matsubi = 30;
        }
        if (intmonth == 2) {
            if (intyear % 4 == 0) {
                matsubi = 29;
            } else {
                matsubi = 28;
            }
        }
        return (Integer.toString(intyear * 10000 + intmonth * 100 + matsubi));
    }
    //hbq add

    /**
     * ｺﾝｽﾄﾗｸﾀ1:日付を取得
     * null,0   ->""
     * 200411   ->20041101
     * 20041100 ->20041101
     * 20041199 ->20041130
     * 200411　 ->20041101
     * @param   sData      Stringの日期は
     * @param   戻り値   String
     */
    public static String getOO99Date8To8(String sDate) {
        //日付無いと"0"場合　retrun　空値
        if (!(sDate == null)) {
            sDate = sDate.trim();
        }
        if ((sDate == null) || ("".equals(sDate)) || ("0".equals(sDate))) {
            return ("");
            //日付の長さ６桁とき　月頭変更
        } else if (sDate.length() == 6) {
            return (sDate + "01");
            //日付の長さ5桁とき　月数2桁に変更
        } else if (sDate.length() == 5) {
            String sMonth =
                    Integer.toString(
                    Integer.parseInt(sDate.substring(4, 5)) + 100).substring(
                    1,
                    3);
            return (sDate.substring(0, 4) + sMonth + "01");

            //日付の長さ7桁とき　日数2桁に変更
        } else if (sDate.length() == 7) {
            String sDay =
                    Integer.toString(
                    Integer.parseInt(sDate.substring(6, 7)) + 100).substring(
                    1,
                    3);
            return sDate.substring(0, 6) + sDay;

            //日付の長さ8桁とき　99->月末　00->月頭　"　"→月頭
        } else if (sDate.length() == 8) {
            if ("99".equals(sDate.substring(6, 8))) {
                return Matsubi1(sDate);
            } else if (("00".equals(sDate.substring(6, 8))) || ("  ".equals(sDate.substring(6, 8)))) {
                return sDate.substring(0, 6) + "01";
            } else {
                return sDate;
            }
        } else {
            return sDate;
        }

    }

    /**
     * @param specString
     * @return String 対象の長度
     */
    public static int getStrLength(String specString) {
        int iCount = 0;
        for (int i = 0; i < specString.length(); i++) {
            if (!(specString.charAt(i) < 0x80 || ((specString.charAt(i) > 0xff61 - 1) && (specString.charAt(i) < 0xff9f + 1)))) {
                iCount = iCount + 2;
            } else {
                iCount = iCount + 1;
            }
        }
        return iCount;
    }

    /*
     * @param      boolean flgBeforeDate
     * @param      String strData
     * Sample :
     *     Data : ttt*^&^*pppp
     * 	   flgBeforeDateがfalseの時：
     * 		    return strTemp ="ttt".
     *     その他時：
     * 			return strTemp ="ttt".
     * return: string strTemp
     */
    public static String getDivData(String strData, boolean flgBeforeDate) {
        String strTemp = "";
        if (strData.length() < 5) {
            return "";
        }
        if (flgBeforeDate) {
            strTemp = strData.substring(0, strData.indexOf("*^&^*"));
        } else {
            //false
            strTemp = strData.substring(strData.indexOf("*^&^*") + 5);

        }
        return strTemp;
    }

    /**
     * Author :ltq
     * Data   :20040926
     * @param str         入力文字全角チェック。
     * @param strType	   入力文字のタイプ。
     * @return			   全角入力時、false
     * 					   その他時、true
     */
    public static boolean doZenkakuCheck(String str, String strType) {
        boolean flgZenkaku = false;
        if (str != null && !"".equals(str)) {
            for (int i = 0; i < str.length(); i++) {
                if (strType.indexOf(str.substring(i, i + 1)) == -1) {
                    return true;
                }
            }
        }
        return flgZenkaku;
    }

    public static boolean isOldRoe(String strProduct, String strRatio) {
        if ("".equals(strProduct) && ("".equals(strRatio) || "0".equals(strRatio))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Author : ltq
     * Set specal cell on Focus .
     *
     * @param table
     * @param rowIndex
     * @param columnIndex
     */
    public static void updateSelection(
            JTable table,
            int rowIndex,
            int columnIndex) {
        // 必要があれば、自動スクロールを行なう
        Rectangle cellRect = table.getCellRect(rowIndex, columnIndex, false);
        if (cellRect != null) {
            table.scrollRectToVisible(cellRect);
        }

        ListSelectionModel rsm = table.getSelectionModel();
        ListSelectionModel csm = table.getColumnModel().getSelectionModel();

        // column selection model 上での更新
        LfcFrmComm.updateSelectionModel(csm, columnIndex);

        // row selection model 上での更新
        LfcFrmComm.updateSelectionModel(rsm, rowIndex);
    }

    public static void updateSelectionModel(ListSelectionModel sm, int index) {
        sm.setSelectionInterval(index, index);
        sm.setLeadSelectionIndex(index);
    }

    /**
     * 文字列の空白文字群を取り除きます。
     * <P>
     * 空白文字は Character#isWhitespace() が true となる文字を指します。
     * これは全角のスペースを含みます。
     * </P>
     * @param str 対象文字列
     * @return 先頭の空白文字群を取り除いた文字列
     */
    public static String trimWhitespace(String str) {
        if (str == null) {
            return str;
        }
        int len = str.length();
        int i;

        for (i = 0; i < len; i++) {
            if (Character.isWhitespace(str.charAt(i)) == false) {
                break;
            }
        }
        if (i >= len) {
            return "";
        }
        //	return str.substring(i);
        return trimRight(str.substring(i));
    }

    /**
     * 文字列の末尾の空白文字群を取り除きます。
     * <P>
     * 空白文字は Character#isWhitespace() が true となる文字を指します。
     * これは全角のスペースを含みます。
     * </P>
     * @param str 対象文字列
     * @return 末尾の空白文字群を取り除いた文字列
     */
    public static String trimRight(String str) {
        if (str == null) {
            return str;
        }
        int len = str.length();
        int i;

        for (i = len - 1; i >= 0; i--) {
            if (Character.isWhitespace(str.charAt(i)) == false) {
                break;
            }
        }
        i++;
        return str.substring(0, i);
    }

    //ydy add 20080417 s
    /**
     * 分割 String
     *
     * @param  strOldValue , len
     * @return String 配列
     */
    public static String[] getBunKatuValue(String strOldValue, int len) {
        String[] strNewValue = new String[2];
        int iCount = 0;
        int iTotalLength = LfcFrmComm.getStrLength(strOldValue);
        if (iTotalLength <= len) {
            strNewValue[0] = strOldValue;
            strNewValue[1] = "";
        } else {
            for (int i = 0; i < strOldValue.length(); i++) {
                if (!(strOldValue.charAt(i) < 0x80 || ((strOldValue.charAt(i) > 0xff61 - 1) && (strOldValue.charAt(i) < 0xff9f + 1)))) {
                    iCount = iCount + 2;
                } else {
                    iCount = iCount + 1;
                }
                if (iCount >= len) {
                    if (iCount == len) {
                        strNewValue[0] = strOldValue.substring(0, i + 1);
                        strNewValue[1] = strOldValue.substring(i + 1);
                    } else {
                        strNewValue[0] = strOldValue.substring(0, i);
                        strNewValue[1] = strOldValue.substring(i, strOldValue.length() - 1);
                    }
                    break;
                }
            }
        }
        return strNewValue;
    }
    //ydy add 20080417 e

    //WangLin Add 20100204 Start
    /**
    * 全角英数記号を半角に変換する。
    * 文字コード0xff01-0xff4eのとき0xfee0を引く。
    * @param str 全角英数記号を含む文字列
    * @return 全角英数記号が半角に変換された文字列
    */
    public static String toHalfANS(String str){
        String ret="";
        if("".equals(str) || str == null){
            return str;
        }else{
            if(!LfcFrmComm.doZenkakuCheck(str, LfcFrmBeanConst.ENG_CHARZEN)){
                for(int i=0;i<str.length();i++){
                    int code=str.charAt(i);
                    if((code>=0xff01)&&(code<=0xff4e)){
                        ret=ret+(char)(code-0xfee0);
                    }else{
                        ret=ret+(char)code;
                    }
                }
                return ret;
            }else{
                return str;
            }
        }
    }
    //WangLin Add 20100204 End
}
