package com.gecl.leaseCal.logic.comm;

import com.gecl.leaseCal.db.comm.LfcDBConfig;
import com.gecl.leaseCal.log.LfcSystemLog;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.DateFormat;
import jxl.write.Label;
import jxl.write.NumberFormat;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


/*
 * @(#)LfcWriteExcel.java     1.00 2005/09/29
 *
 * 機能：
 * <PRE>
 *  １．EXCELファイルに画面表示されたデータを書き出し
 *  ２．EXcelのセルのフォマットを設定
 * </PRE>
 * @author     DHC-HBQ
 * @version    01-01．
 */
public class LfcWriteExcel {

    private WritableSheet sheet;
    private String strTempfile;
    //読込のexcelファイル
    private Workbook rw;
    //書出しのexcelファイル
    private WritableWorkbook wwb;
    //ヘッダーのフォント
    private WritableFont headerFont;
    //タイトルのフォント
    private WritableFont titleFont;
    //詳細のフォント
    private WritableFont detFont;
    //ヘッダーのフォマット
    private jxl.write.WritableCellFormat headerFormat;
    //タイトルのフォマット
    private jxl.write.WritableCellFormat titleFormat;
    //詳細のフォマット
    private jxl.write.WritableCellFormat detFormat;
    //金額のフォマット
    private jxl.write.WritableCellFormat priceFormat;
    //日付のフォマット
    private jxl.write.WritableCellFormat dateFormat;
    //率のフォマット
    private jxl.write.WritableCellFormat rateFormat;

    public LfcWriteExcel() {
        try {
            /**********************************
             * ヘッダー向きのフォマット
             **********************************/
            headerFont =
                    new WritableFont(
                    jxl.write.WritableFont.ARIAL,
                    8,
                    jxl.write.WritableFont.NO_BOLD,
                    false,
                    UnderlineStyle.NO_UNDERLINE,
                    jxl.format.Colour.BLACK);
            headerFormat = new WritableCellFormat(headerFont);
            headerFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            //Cellの文字位置
            headerFormat.setAlignment(jxl.format.Alignment.LEFT);

            /**********************************
             * タイトル向きのフォマット
             **********************************/
            titleFont =
                    new WritableFont(
                    WritableFont.ARIAL,
                    11,
                    WritableFont.NO_BOLD,
                    false,
                    UnderlineStyle.NO_UNDERLINE,
                    jxl.format.Colour.BLACK);
            titleFormat = new WritableCellFormat(titleFont);
            titleFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            titleFormat.setBackground(Colour.ICE_BLUE);
            //Cellの文字位置
            titleFormat.setAlignment(jxl.format.Alignment.CENTRE);

            /**********************************
             * 詳細な文字のフォマット
             **********************************/
            //フォント
            detFont =
                    new WritableFont(
                    WritableFont.ARIAL,
                    10,
                    WritableFont.NO_BOLD,
                    false,
                    UnderlineStyle.NO_UNDERLINE,
                    jxl.format.Colour.BLACK);
            detFormat = new WritableCellFormat(detFont);
            detFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            detFormat.setAlignment(jxl.format.Alignment.RIGHT);

            /**********************************
             * 金額向きのフォマット
             **********************************/
            NumberFormat nf = new NumberFormat("##,##0");
            priceFormat = new WritableCellFormat(detFont, nf);
            priceFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            priceFormat.setAlignment(jxl.format.Alignment.RIGHT);


            /**********************************
             * 率向きのフォマット
             **********************************/
            NumberFormat rnf = new NumberFormat("0.00%");
            rateFormat = new WritableCellFormat(detFont, rnf);
            rateFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            rateFormat.setAlignment(jxl.format.Alignment.RIGHT);


            /**********************************
             * 日付向きのフォマット
             **********************************/
            DateFormat df = new DateFormat("yyyy/MM/dd");
            dateFormat = new WritableCellFormat(detFont, df);
            dateFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            dateFormat.setAlignment(jxl.format.Alignment.RIGHT);

            //合并第一列第一行到第六列第一行的所有単元格
            //sheet.mergeCells(0, 0, 5, 0);
        } catch (Exception e) {
            System.out.println("error0:" + e.getMessage());
        }
    }

    /**
     * 設定EXCELのセルの列幅．    <BR>
     *
     * @param col
     * @param width
     * @throws Exception
     */
    public void setColumnWidth(int col, int width) throws Exception {
        sheet.setColumnView(col, width);
    }

    /**
     * 設定EXCELのセルのデータ．    <BR>
     *
     * @param row
     * @param col
     * @param strData
     * @param strwcF
     * @return boolean		true ：設定成功　 false：設定失敗
     * @throws Exception
     * @since  2005/09/28
     */
    @SuppressWarnings({"deprecation", "deprecation", "deprecation"})
    public boolean setCellData(int row, int col, String strData, String strwcF) throws Exception {
        try {
            if ( "headerFormat".equals(strwcF)) {
                //ヘッダーのセル
                Label labelC = new Label(col - 1, row - 1, strData, headerFormat);
                sheet.addCell(labelC);
            } else if ("titleFormat".equals(strwcF)) {
                //タイトルのセル
                Label labelC = new Label(col - 1, row - 1, strData, titleFormat);
                sheet.addCell(labelC);
            } else if ("detFormat".equals(strwcF)) {
                //詳細な文字のセル
                if (null == strData) {
                    strData = "";
                }
                Label labelC = new Label(col - 1, row - 1, strData, detFormat);
                sheet.addCell(labelC);
            } else if ("priceFormat".equals(strwcF)) {
                //金額のセル
                if (null == strData || "".equals(strData)) {
                    strData = "0";
                }

                strData = LfcFrmComm.unformatDate(strData.trim());
                jxl.write.Number labelN =
                        new jxl.write.Number(col - 1, row - 1, LfcFrmComm.ToLong(strData), priceFormat);
                sheet.addCell(labelN);
            } else if ("rateFormat".equals(strwcF)) {
                //率のセル
                if (null == strData || "".equals(strData)) {
                    strData = "0";
                }
                strData = LfcFrmComm.doFormatToFloat(strData.trim());
                jxl.write.Number labelNF =
                        new jxl.write.Number(
                        col - 1,
                        row - 1,
                        LfcFrmComm.ToDouble(strData) / 100.0,
                        rateFormat);
                sheet.addCell(labelNF);
            } else if ("dateFormat".equals(strwcF)) {
                //日付のセル
                Date today = new Date();
                today.setDate(LfcFrmComm.toInt(strData.substring(6, 8)));
                today.setMonth(LfcFrmComm.toInt(strData.substring(4, 6)) - 1);
                today.setYear(LfcFrmComm.toInt(strData.substring(0, 4)) - 1900);

                SimpleDateFormat DateFormatTmp = new SimpleDateFormat("yyyy/MM/dd");
                Date strDate = DateFormatTmp.parse(DateFormatTmp.format(today));

                jxl.write.DateTime labelDTF =
                        new jxl.write.DateTime(col - 1, row - 1, strDate, dateFormat);
                sheet.addCell(labelDTF);
            }
            return true;
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 書出したEXCELファイルをクローズする．    <BR>
     *
     * @return true
     */
    public boolean ColseExcel() {
        try {
            //excelに書出し
            wwb.write();
            //excelファイルをクローズ
            wwb.close();
            //excelファイルをクローズ
            rw.close();
            //ごみを回収
            System.gc();
            //Excelファイルを表示
            Runtime runTime = Runtime.getRuntime();
            runTime.exec("cmd /c start " + strTempfile);
        } catch (Exception e) {
            //自動生成された catch ブロック
            System.out.println(e.getMessage());
        }
        return true;
    }

    //ydy add 20071121 s
    public WritableCellFormat getDetFormat() {
        return detFormat;
    }

    public WritableCellFormat getPriceFormat() {
        return priceFormat;
    }

    public WritableCellFormat getRateFormat() {
        return rateFormat;
    }

    /**
     * Excelのフォマットファイルから書出しのEXCELファイルを用意する．    <BR>
     *
     * @param OutFile
     * @return
     */
    public boolean CopytestFile(String OutFile) {
        //Folderは存在かどうかを判断する
        LfcDBConfig.getInstance();
        String strPath= LfcDBConfig.getExeclOutFolderPath();
        File fPdf = new File(strPath);
        try {
            if (!fPdf.isDirectory()) {
                if (!fPdf.mkdir()) {
                }
            }
        } catch (Exception e) {
            String strMessage = new String("EXCELフォールダを作成失敗");
            //サーバー側のログファイルを作成。
            e.printStackTrace();
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("LfcWriteExcel", //クラス名
                    "CopytestFile", //メソッド名
                    strMessage, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return false;
        }

        /**format for getting time in hh:ss:mm format*/
        java.text.SimpleDateFormat updatetime = new SimpleDateFormat("yyyyMMddHHmmss");
        /**現在の時点(日期と時間)*/
        Date date = new java.util.Date();
        String strTmpName = OutFile + updatetime.format(date) + ".xls";
        File sourcefile = null;
        sourcefile = new File(strPath+"\\" + OutFile);
        strTempfile = strPath+"\\" + strTmpName;
        File targetfile = new File(strTempfile);

        try {
            //読込EXCELファイル
            rw = Workbook.getWorkbook(sourcefile);
            //目的EXCELファイル
            wwb = Workbook.createWorkbook(targetfile, rw);
            //工作表
            sheet = wwb.getSheet(0);
            return true;
        } catch (Exception e1) {
            String strMessage = "予期せぬ例外.指定のExcelブック読込に失敗しました.データ形式が不正です.:" + e1.toString();
            //サーバー側のログファイルを作成。
            e1.printStackTrace();
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("LfcWriteExcel", //クラス名
                    "CopytestFile", //メソッド名
                    strMessage, //ロジックメッセージ
                    e1);                    //システムエラーメッセージ
            return false;
        }
    }
    //ydy add 20071121 e
}
