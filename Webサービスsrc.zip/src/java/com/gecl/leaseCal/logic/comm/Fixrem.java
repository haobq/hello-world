/*
 * @(#)CashFl.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.comm;

public class Fixrem {

    String strKishuBun[] = new String[100];	 	/* JLC機種分類   */

    String strReserve1[] = new String[100];	    /* 空白１        */

    String strKishuCd[] = new String[100];	        /* 機種コード    */

    double dFremRt[] = new double[100];            /* 期間別残価率  */

    double dFremRt2[] = new double[100];           /* 期間別残価率2 */

    double dFremRt3[] = new double[100];           /* 期間別残価率3 */

    double dFremRt4[] = new double[100];           /* 期間別残価率4 */

    double dFremRt5[] = new double[100];           /* 期間別残価率5 */

    double dFremRt6[] = new double[100];           /* 期間別残価率6 */

    double dFremRt7[] = new double[100];           /* 期間別残価率7 */


    public String getKishuBun(int index) {
        return strKishuBun[index];
    }

    public void setKishuBun(String strKishuBun, int index) {
        this.strKishuBun[index] = strKishuBun;
    }

    public String getReserve1(int index) {
        return strReserve1[index];
    }

    public void setReserve1(String strReserve1, int index) {
        this.strReserve1[index] = strReserve1;
    }

    public String getKishuCd(int index) {
        return strKishuCd[index];
    }

    public void setKishuCd(String strKishuCd, int index) {
        this.strKishuCd[index] = strKishuCd;
    }

    public double getFremRt(int index) {
        return dFremRt[index];
    }

    public void setFremRt(double dFremRt, int index) {
        this.dFremRt[index] = dFremRt;
    }

    public double getFremRt2(int index) {
        return dFremRt2[index];
    }

    public void setFremRt2(double dFremRt2, int index) {
        this.dFremRt2[index] = dFremRt2;
    }

    public double getFremRt3(int index) {
        return dFremRt3[index];
    }

    public void setFremRt3(double dFremRt3, int index) {
        this.dFremRt3[index] = dFremRt3;
    }

    public double getFremRt4(int index) {
        return dFremRt4[index];
    }

    public void setFremRt4(double dFremRt4, int index) {
        this.dFremRt4[index] = dFremRt4;
    }

    public double getFremRt5(int index) {
        return dFremRt5[index];
    }

    public void setFremRt5(double dFremRt5, int index) {
        this.dFremRt5[index] = dFremRt5;
    }

    public double getFremRt6(int index) {
        return dFremRt6[index];
    }

    public void setFremRt6(double dFremRt6, int index) {
        this.dFremRt6[index] = dFremRt6;
    }

    public double getFremRt7(int index) {
        return dFremRt7[index];
    }

    public void setFremRt7(double dFremRt7, int index) {
        this.dFremRt7[index] = dFremRt7;
    }
}
