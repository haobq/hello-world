/*
 * @(#)Stairs.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.comm;

public class Stairs {

    private boolean[] _bAct = new boolean[360];		/* 有効区分 */

    private double[] _dIncome = new double[360];		/* 回収金額 */

    private int[] _nCycle = new int[360];			/* 回収サイクル */

    private int[] _nFreque = new int[360];			/* 回数         */

    private int[] _nDateYY = new int[360];			/* 回収日（年） */

    private int[] _nDateMM = new int[360];			/* 回収日（月） */

    private int[] _nDateDD = new int[360];			/* 回収日（日） */

    private int _nRowCount = 0;
    private int _nTopRow = 0;
    private int _nLastRow = 0;
    private int _nEndActRow = 0;

    public boolean getAct(int nIndex) {
        return _bAct[nIndex];
    }

    public void setAct(boolean bAct, int nIndex) {
        this._bAct[nIndex] = bAct;
    }

    public double getIncome(int nIndex) {
        return _dIncome[nIndex];
    }

    public void setIncome(double dIncome, int nIndex) {
        this._dIncome[nIndex] = dIncome;
    }

    public int getCycle(int nIndex) {
        return _nCycle[nIndex];
    }

    public void setCycle(int nCycle, int nIndex) {
        this._nCycle[nIndex] = nCycle;
    }

    public int getFreque(int nIndex) {
        return _nFreque[nIndex];
    }

    public void setFreque(int nFreque, int nIndex) {
        this._nFreque[nIndex] = nFreque;
    }

    public int getDateYY(int nIndex) {
        return _nDateYY[nIndex];
    }

    public void setDateYY(int nDateYY, int nIndex) {
        this._nDateYY[nIndex] = nDateYY;
    }

    public int getDateMM(int nIndex) {
        return _nDateMM[nIndex];
    }

    public void setDateMM(int nDateMM, int nIndex) {
        this._nDateMM[nIndex] = nDateMM;
    }

    public int getDateDD(int nIndex) {
        return _nDateDD[nIndex];
    }

    public void setDateDD(int nDateDD, int nIndex) {
        this._nDateDD[nIndex] = nDateDD;
    }

    public int getRowCount() {
        return _nRowCount;
    }

    public void setRowCount(int nRowCount) {
        this._nRowCount = nRowCount;
    }

    public int getTopRow() {
        return _nTopRow;
    }

    public void setTopRow(int nTopRow) {
        this._nTopRow = nTopRow;
    }

    public int getLastRow() {
        return _nLastRow;
    }

    public void setLastRow(int nLastRow) {
        this._nLastRow = nLastRow;
    }

    public int getEndActRow() {
        for (int i = _nRowCount - 1; i >= 0; i--) {
            if (_bAct[i] == LfcLogicPgConst.KUBUN_YES && _dIncome[i] != 0) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public String toString() {
        String tmpStr;
        tmpStr = "";
        for (int i = 0; i < _nRowCount; i++) {
            tmpStr = tmpStr + _dIncome[i] + "   " + _nFreque[i] + "\n";
        }
        return tmpStr;
    }
}
