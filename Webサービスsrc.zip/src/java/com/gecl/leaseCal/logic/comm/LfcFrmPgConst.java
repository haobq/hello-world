/*
 * ﾌｧｲﾙ名：LfcFrmPgConst.java
 *
 * 修正履歴:
 *           ver.1.00     2003/04/15    HaoBuQian
 *                        作成
 *　修正日時：2005/01/19
 *　修正者　：王嵩
 *　修正内容：ProductCDが変更されるというメッセージを表示する条件としての
 *			 Maxの更新の物件数を格納する定数を定義する。
 *
 *           Copyright (c) 2004
 *
 *  修正日：20061005～20061124
 *  修正人：ydy
 *  修正内容：リース料システムPricing Matrix改定。
 *
 */

package com.gecl.leaseCal.logic.comm;

/**
*
* ｸﾗｽ名：Lfcの定数
*
* 概要：Lfc使用する定数を定義
*/
public interface LfcFrmPgConst
{
    /** 契約タイプ・全て */
    public final static int ALL = 0;
    /** 契約タイプ・リース */
    public final static int LEASE = 1;
    /** 契約タイプ・割賦 */
    public final static int KAPPU = 2;
    /** 契約タイプ・割賦 */
    public final static int CNTRCT_TYPE_BUG = 3;
    /** リース料計算メイン画面レイヤ */
    public final static int LEASE_MAIN_LAYER = 0;
    /** 画面タイトルを格納の最大数 */
    public final static int MAX_IFRAME_COUNT = 20;
    // 方向区分の左
    public final static int  DIRECTION_LEFT = 1;
    // 方向区分の右
    public final static int  DIRECTION_RIGHT = 2;
    // 方向区分の上
    public final static int  DIRECTION_UP = 3;
    // 方向区分の下
    public final static int  DIRECTION_DOWN = 4;
    // 一桁のｽﾍﾟｰｽ
    public final static String ONE_SPACE = " ";
    // DateﾀｲﾌﾟYYYY/MM/DD
    public final static String DATE_TYPE_YYYY_MM_DD = "yyyy/MM/dd";
    // DateﾀｲﾌﾟYYYY/MM
    public final static String DATE_TYPE_YYYY_MM = "yyyy/MM";
    // DateﾀｲﾌﾟHH:MM
    public final static String DATE_TYPE_HH_MM = "HH:mm";
    // Dateﾀｲﾌﾟ"YYYY/MM/DD HH:MM:SS"
    public final static String DATE_TYPE_YYYY_MM_DD_HH_MM = "yyyy/MM/dd HH:mm:ss";
    // Dateﾀｲﾌﾟ"HH:MM:SS"
    public final static String DATE_TYPE_HH_MM_SS = "HH:mm:ss";

    public final static int EXE_OK  = 0;
    public final static int EXE_ERR = 1;

    // add by jwz
    public final static int DATE_ADD_YEAR = 0;
    public final static int DATE_ADD_MONTH = 1;
    public final static int DATE_ADD_DAY = 2;
    // add over

    // define the mouse button
    public final static int LEFT = 2;
    public final static int CENTER = 0;
    public final static int RIGHT = 4;

    //define edit information
    public final static int BASE_INFORMATION_NOEDIT = 1;
    public final static int BASE_INFORMATION_CREATE = 2;
    public final static int BASE_INFORMATION_EDIT = 3;

    public final static int CALL_SPECIFY_BUKNO_FRM_BASEPNL = 1;
    public final static int CALL_SPECIFY_BUKNO_FRM_BASEFORM = 2;
    public final static int CALL_SPECIFY_BUKNO_FRM_RESULT = 3;

    public final static int CALL_SPECIFY_CONDITION_BASE_PNL = 1;
    public final static int CALL_SPECIFY_CONDITION_BASE_FORM = 2;
    public final static int CALL_SPECIFY_CONDITION_RESULT = 3;
    public final static int CALL_SPECIFY_CONDITION_ANKEN_FRM = 4;

    public final static int CALL_CONDISET_TOT = 1;
    public final static int CALL_CONDISET_RANGE = 2;
    public final static int CALL_CONDISET_FREE = 3;

    public final static int CNTRCT_NEW = 0;
    public final static int CNTRCT_NEW_CLEAR = 1;
    public final static int BUKEN_UPDATE = 2;
    public final static int BUKEN_DEL = 3;
    public final static int BUKEN_UPDATE_CLEAR = 4;


    public final static int NEW_NO_INSERT = 0;
    public final static int NEW_INSERT = 1;
    public final static int BUKEN_NO_EXISTENCE = 2;
    public final static int BUKEN_EXISTENCE = 3;

    public final static int SCROLLFLAG_INIT = 0;
    public final static int SCROLLFLAG_NXT = 1;

    public final static int FRM_SPECIFY_BUKNO = 0;
    public final static int FRM_RESULT = 1;

    /** 試算データ使用区分・試算結果からの登録時 */
    public final static int LEASE_COPY = 1;
    /** 試算データ使用区分・見積物件から選択時 */
    public final static int EST_COPY = 2;
    /** 試算データ使用区分・新規編集の時 */
    public final static int NO_COPY = 3;

    public final static int NO_DEL_BUTTON = 0;
    public final static int DEL_BUTTON = 1;

    public final static int NO_LEASE_FIELD = -1;
    public final static int NULL_INT = 0;
    public final static int NULL_STRING = 1;

    /** 見積From～To更新タイプ */
    public final static int BUKEN_FROMTO = 0;
    /** 見積From～To更新タイプ */
    public final static int EPROFIT_FROMTO = 1;

    /** 画面採算情報変更かどうかフラグ(変更且つ続く) */
    public final static int EPROFIT_CHANGE_GO = 0;
    /** 画面採算情報変更かどうかフラグ(変更且つ戻る) */
    public final static int EPROFIT_CHANGE_EXIT = 1;
    /** 画面採算情報変更かどうかフラグ(変更しない) */
    public final static int EPROFIT_NO_CHANGE = 2;
    /** instanceされたDB数を格納
     *  見積案件
     */
    public final static int MAX_DB_INSTANCE_NUM = 1;
    /** instanceされたDBでーた数を格納 MAXは５で
     *  見積案件・見積物件・見積物件採算・見積分割支払・見積分割回収のデータ
     */
    public final static int MAX_DB_DATA_GET_NUM = 2;
    /** instanceされたDB数を格納 MAXは５で
     *  リース物件・リース分割支払・リース分割回収
     */
    public final static int CAL_MAX_DB_INSTANCE_NUM = 1;
    public final static int CAL_MAX_DB_DATA_GET_NUM = 4;

    public final static int MAX_REPORT_INSTANCE_NUM = 4;

    public final static int DISPLAY_PNL = 0;
    public final static int DISPLAY_FORM = 1;
    public final static int MAX_SUB_DB_INSTANCE_NUM = 3;

	public final static int FOR_SW_PRE_STOP_CELL_EDIT_ROW = 1;
	public final static int FOR_SW_STOP_CELL_EDIT_ROW = 360;
	public final static int FOR_STOP_CELL_EDIT_COL = 5;

	public final static int FOR_SP_STOP_CELL_EDIT_ROW = 120;
	public final static int FOR_SP_STOP_CELL_EDIT_COL = 3;

	//ws 2005/1/01/19 add ProductCDが変更されるというメッセージを表示する条件としてのMaxの更新の物件数を格納する定数を定義する。
	public final static int MAX_UPDATA_PRODUCT_NUM = 20;

	//ydy add 20061115 s
	public final static String STRYOSINFLG = "flgTrue";
	//ydy add 20061115 e
}
