/*
 * @(#)CashFl.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.comm;

public class CashFl {

    private double[] _dCashFlow = new double[400];			/* CCashFlow */

    private double[] _dIncome = new double[400];			/* 回収金額  */

    private int _nCashCnt;
    private int _nRowCnt;
    private int _nRowTop;

    public double getCashFlow(int nIndex) {
        return _dCashFlow[nIndex];
    }

    public void setCashFlow(double dCashFlow, int nIndex) {
        _dCashFlow[nIndex] = dCashFlow;
    }

    public double getIncome(int nIndex) {
        return _dIncome[nIndex];
    }

    public void setIncome(double dIncome, int nIndex) {
        _dIncome[nIndex] = dIncome;
    }

    public int getCashCnt() {
        return _nCashCnt;
    }

    public void setCashCnt(int nCashCnt) {
        _nCashCnt = nCashCnt;
    }

    public int getRowCnt() {
        return _nRowCnt;
    }

    public void setRowCnt(int nRowCnt) {
        _nRowCnt = nRowCnt;
    }

    public int getRowTop() {
        return _nRowTop;
    }

    public void setRowTop(int nRowTop) {
        _nRowTop = nRowTop;
    }

    @Override
    public String toString() {
        String tmpStr;
        tmpStr = "";
        for (int i = 0; i < _nCashCnt; i++) {
            tmpStr = tmpStr + _dCashFlow[i] + "   " + _dIncome[i] + "\n";
        }
        return tmpStr;
    }
}
