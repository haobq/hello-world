/*
 * @(#)LsConst.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *修正日：20050512
 *修正人：潘正寛
 *修正内容：ROE区分を追加する
 *
 *修正日：20070326
 *修正人：zhangyibo
 *修正内容：ROIの税率を改定
 */
package com.gecl.leaseCal.logic.comm;

public interface LfcLogicPgConst {

    /** 回收情報行數最大値 */
    public final static int STAIRS_MAX_COUNT = 360;
    /** 支払情報行數最大値 */
    public final static int PAYDIV_MAX_COUNT = 120;
    /**  */
    public final static int STAIRS_NO_INCOME = -1;
    /** 区分１ */
    public final static boolean KUBUN_YES = true;
    /** 区分０ */
    public final static boolean KUBUN_NO = false;
    /** 期間配列最大値 */
    public final static int TERM_TBL_MAX = 7;
    /** 動産総合保険短期率 */
    //2009/03/17 Hbq S
    //public final static double DS_STR[]={0,0.25,0.35,0.45,0.55,0.65,0.70,0.75,0.80,0.85,0.90,0.95};
    public final static double DS_STR[] = {0, 0.08, 0.17, 0.25, 0.33, 0.42, 0.5, 0.58, 0.67, 0.75, 0.83, 0.92};
    //2009/03/17 Hbq e
    //ydy add 20090706 s
    /** 1引合当たりの購入額$5MM以上の場合、円貨のドル換算結果*/
    public final static long MAX_KOUNYU_VALUE = 475000000;
    //ydy add 20090706 e
    /** 米国 */
    //20070326 modi zyb s
    //public final static double USA_PERSON_TAX = 0.65;
    //20090106 modi fuling s
    //public final static double USA_PERSON_TAX = 0.59;
    public final static double USA_PERSON_TAX = 1.00;
    //20090106 modi fuling e
    //20070326 modi zyb e
    /** 時間の最大値 */
    public final static int MAX_TIME = 60000;
    /** return no error */
    public final static int NO_ERROR = 0;
    /** 指定合計料率 */
    public final static int CAL_BASE_RYORTT = 1;
    /** 指定月料率 */
    public final static int CAL_BASE_RYORTM = 2;
    /** 指定運用利回り */
    public final static int CAL_BASE_RATEUN = 3;
    /** 指定ROI */
    public final static int CAL_BASE_ROI = 4;
    /** 指定ＴＲ */
    public final static int CAL_BASE_TRUERT = 5;
//  pzk add 20050512 start
    /** 指定ROE */
    public final static int CAL_BASE_ROE = 6;
//  pzk add 20050512 end
    /** 無効の回収金額 */
    public final static int INVALID_INCOME = -1;
    /** 無効の回収サイクル */
    public final static int INVALID_FREQUE = -1;
    /** 採算項目算出 */
    public final static int CAL_ITEM_LPRO = 0;
    /** 回収金額算出 */
    public final static int CAL_ITEM_KINGAKU = 1;
    /** 残価逆算 */
    public final static int CAL_ITEM_ZANKA = 2;
    /** 回収回数逆算 */
    public final static int CAL_ITEM_KAISU = 3;
    /** 購入価額逆算 */
    public final static int CAL_ITEM_PUCHARS = 4;
    /** 採算項目算出 */
    public final static int KAP_ITEM_LPRO = 0;
    /** 回収金額算出 */
    public final static int KAP_ITEM_KINGAKU = 1;
    /** 回収金額.頭金算出 */
    public final static int KAP_ITEM_KINGAKU_INC0 = 2;
    /** 頭金逆算 */
    public final static int KAP_ITEM_INC0 = 3;
    /** 回収回数逆算 */
    public final static int KAP_ITEM_KAISU = 4;
    /** 購入価額逆算 */
    public final static int KAP_ITEM_PUCHARS = 5;
    /** 計算開始のフラグ */
    public final static int CAL_ITEM_INIT = 10;
    public final static int KAP_ITEM_INIT = 10;
    /** 契約タイプ・リース */
    public final static int LEASE = 1;
    /** 契約タイプ・割賦 */
    public final static int KAPPU = 2;
    /** TRの平元率 */
    public final static double TR_RATE_HN = 0.55;
    /** 計算フラグ */
    public final static int NOT_CALCULATE = 100;
}
