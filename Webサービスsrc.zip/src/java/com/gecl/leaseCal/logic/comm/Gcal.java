/*
 * @(#)Gcal.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 *  修正日：20061005～20061124
 *  修正人：ydy
 *  修正内容：リース料システムPricing Matrix改定。
 *
 */
package com.gecl.leaseCal.logic.comm;

/**
 * Bean。
 * @author  廖家慶
 * @version 01-01、 2003/06/04
 * @since   01-01
 * HBQ 20060815 修正残価率の保存精度。
 * 六桁目で表示される七桁目で四捨五入する
 */
public class Gcal {
	private String	_strUserNm;				/* 契約先名                 */
	private String	_strKeiyaku;			/* 契約番号                 */
	private String	_strKenshu1;			/* 検収番号１               */
	private String	_strKenshu2;			/* 検収番号２               */
	private long	_lRecno;			    /* 契約案件番号             */
	private int		_nBukken;			    /* 物件№                   */
	private int		_nBukkenF;			    /* 物件№(FROM)             */
	private int		_nBukkenT;			    /* 物件№(TO)               */
	private double	_dPurchas;				/* 購入価額                 */
	private double	_dRemVAL;				/* 残価                     */
	private double	_dRemVRT;				/* 残価率                   */
	private int		_nFremIX;			    /* 定率残価ｲﾝﾃﾞｯｸｽ          */
	private double	_dInterP;				/* 支払利息                 */
	private double	_dFatax;				/* 固定資産税               */
	private double	_dInsur;				/* 保険料                   */
	private double	_dZappi;				/* その他の雑費             */
	private double	_dKappuI;				/* 割賦保険料               */
	private double	_dIchiji1;				/* その他一時費用(ｲ)　      */
	private double	_dIchiji2;				/* その他一時費用(ﾛ)        */
	private double	_dIchiji3;				/* その他一時費用(ﾊ) 　     */
	private double	_dKurino1;				/* その他繰延費用(ﾍ)        */
	private double	_dKurino2;				/* その他繰延費用(ﾄ)        */
	private double	_dHoshury;				/* 保守料                   */
	private double	_dAssen;				/* 斡旋手数料               */
	private double	_dCostT;				/* ﾘｰｽ/割賦原価計           */
	private double	_dCharge;				/* 当社手数料               */
	private double	_dIncGt;				/* 契約額                   */
	private double	_dInc0;				    /* 前受ﾘｰｽ料/頭金           */
	private double	_dInc0M;				/* 前受ﾘｰｽ月数              */
	private double	_dCAdj;				    /* 原価調整額               */
	private double	_dCriF;				    /* 低炭信用保険料         */
	private double	_dProfT;				/* 荒利益額                 */
	private double	_dProfY;				/* 年荒利益額               */
	private double	_dCapitT;				/* 使用総資金               */
	private double	_dRtPrT;				/* 総荒利率                 */
	private double	_dRtPrY;				/* 年荒利率                 */
	private double	_dRateYr;				/* 年利回り                 */
	private double	_dRateJL;				/* 社内金利                 */
	private double	_dRateUN;				/* 運用利回り               */
	private double	_dTrueRT;				/* ＴＲ                     */
	private double	_dRateCADJ;				/* 原調計算金利             */
	private double	_dRateROI;				/* ＲＯＩ                   */
	private long		_lDKensh;			    /* 検収予定日               */
	private long		_lDPaymt;			    /* 支払予定日               */
	private int		_nAdjM;			        /* 原価調整月数             */
	private int		_nAdjD;			        /* 原価調整日数             */
	private double	_dIncT;			    	/* ﾘｰｽ料/割賦金総額         */
	private double	_dInitC;				/* 初期費用                 */
	private double	_dExecC;				/* 実行費用総額             */
	private double	_dNetRt;				/* ＮＥＴ率                 */
	private double	_dInterI;				/* 回収利息                 */
	private double	_dDosoRt;				/* 動総保険料率             */
	private String		_strSwSoft;				/* ｿﾌﾄｳｪｱ区分               */
	private String		_strSwBais;				/* 賠責保険付保区分         */
	private String		_strSwCri;				/* エコリース区分           */
	private String		_strHisai;				/* 被災補助金区分有無       */
	private String		_strSwSPro;				/* 少額資産区分             */
	private boolean	_bSwPay;				/* 分割支払有無区分         */
	private double	_dDosoIx;				/* 動総保険金額指数         */
	private double	_dDosoF;				/* 動総保険料               */
	private double	_dMachiF;				/* 機械保険料               */
	private double	_dFireF;				/* 火災保険料               */
	private double	_dEtcF;				    /* 船舶・ソノタ保険料       */
	private double	_dDansRt;				/* 団信保険料率             */
	private int		_nCriTm;			    /* 低炭素リース付保期間     */
	private double	_dCriRt;				/* 低炭素リース保険料率     */
	private String		_strCriCd;				/* 割賦信保機種コ－ド       */
	private int		_nLeaseM;			    /* ﾘｰｽ月数                  */
	private int		_nLeaveM;			    /* 据置月数                 */
	private int		_nKappuM;			    /* 割賦月数                 */
	private int		_nDuraY;			    /* 法定耐用年数             */
	private int		_nQuant;			    /* 物件数量                 */
	private long		_lDInc0;			    /* 前受ﾘｰｽ料回収日          */
	private double	_dRyortT;				/* 合計料率                 */
	private double	_dRyortM;				/* 月料率                   */
	private int		_nLeaseD;			    /* ﾘｰｽ段数                  */
	private int		_nKappuD;			    /* 割賦段数                 */
	private double	_dBaisF;				/* 賠責保険料               */
	private int		_nEvenFlg;			    /* 均等回収区分             */
	private long		_lFidtIn;			    /* 最終回収予定日           */
	private int		_nDivfreq;			    /* 分割回数（回収）         */
	private double	_dDamBas;			    /* 規定損害金基本額         */
	private double	_dDamFm;				/* 規定損害金前半逓減月数   */
	private double	_dDamLm;				/* 規定損害金後半逓減月数   */
	private double	_dDamFa;				/* 規定損害金前半逓減月額   */
	private double	_dDamLa;				/* 規定損害金後半逓減月額   */
	private double	_dFIntP;				/* ﾌﾙﾍﾟｲ支払利息            */
	private double	_dFIntI;				/* ﾌﾙﾍﾟｲ回収利息            */
	private double	_dFCharge;				/* ﾌﾙﾍﾟｲ当社手数料          */
	private double	_dFExecC;				/* ﾌﾙﾍﾟｲ実行費用総額        */
	private double	_dFKuri1;				/* ﾌﾙﾍﾟｲ繰延費用(ﾍ)         */
	private double	_dFInsur;				/* ﾌﾙﾍﾟｲ保険料              */
	private double	_dFCostT;				/* ﾌﾙﾍﾟｲﾘｰｽ原価計           */
	private double	_dFProT;				/* ﾌﾙﾍﾟｲ荒利益額            */
	private double	_dFProY;				/* ﾌﾙﾍﾟｲ年荒利益額          */
	private double	_dFCapT;				/* ﾌﾙﾍﾟｲ使用総資金          */
	private double	_dFTrueRT;				/* ﾌﾙﾍﾟｲＴＲ                */
	private double	_dFRtYr;				/* ﾌﾙﾍﾟｲ年利回り            */
	private double	_dFRtUn;				/* ﾌﾙﾍﾟｲ運用利回り          */
	private double	_dFRtPrt;				/* ﾌﾙﾍﾟｲ総荒利率            */
	private double	_dFRtPry;				/* ﾌﾙﾍﾟｲ年荒利率            */
	private double	_dFRtRoi;				/* ﾌﾙﾍﾟｲＲＯＩ              */
	private double	_dRtLossR;				/* 貸倒引当率              */
	private double	_dRtEAniO;				/* 管販比率(Origination)   */
	private double	_dRtEAniS;				/* 管販比率(Servicing)     */
	private double	_dRtEAniTotal;			/* 管販比率(合計)          */
	private double	_dRtFeeN;				/* 手数料率(NPP)           */
	private double	_dRtFeeR;				/* 手数料率(Release)       */
	private double	_dRtFeeTotal;			/* 手数料率(合計)          */
    private String  	_strCstKishuCD;         /* コスト率機種コード      */
    private String  	_strCstSelInfo;         /* コスト率選択情報        */
	private double	_dFinanceMargin;		/* FinanceMargin           */
	private double	_dPvFinanceMargin;		/* PvFinanceMargin         */
	private double	_dRaMargin;				/* RaMargin               */
	private double	_dRaPvMargin;			/* RaPvMargin             */
	private double	_dFFinanceMargin;		/* FinanceMargin           */
	private double	_dFPvFinanceMargin;		/* PvFinanceMargin         */
	private double	_dFRaMargin;			/* RaMargin               */
	private double	_dFRaPvMargin;			/* RaPvMargin             */
	private int		_nDate1YY;			    /* 検収予定日（年）         */
	private int		_nDate1MM;			    /* 検収予定日（月）         */
	private int		_nDate1DD;		    	/* 検収予定日（日）         */
	private int		_nDate2YY;			    /* 支払予定日（年）         */
	private int		_nDate2MM;			    /* 支払予定日（月）         */
	private int		_nDate2DD;			    /* 支払予定日（日）         */
	private int		_nDate3YY;			    /* 前受ﾘｰｽ料回収日（年）    */
	private int		_nDate3MM;			    /* 前受ﾘｰｽ料回収日（月）    */
	private int		_nDate3DD;			    /* 前受ﾘｰｽ料回収日（日）    */
	private int		_nInddFlg;			    /* ﾘｰｽ料回収日日付指定区分  */
	private boolean	_bPurchasFlg;			/* 購入価額入力有無区分     */
	private boolean	_bRemValFlg;			/* 残価入力有無区分         */
	private boolean	_bRemVRtFlg;			/* 残価率入力有無区分       */
	private boolean	_bInc0Flg;				/* 前受/頭金入力有無区分    */
	private boolean	_bInc0MFlg;				/* 前受ﾘｰｽ月数入力有無区分  */
	private boolean	_bRyortTFlg;			/* 合計料率入力有無区分     */
	private boolean	_bRyortMFlg;			/* 月料率入力有無区分       */
	private boolean	_bRtPrTFlg;				/* 総荒利率入力有無区分     */
	private boolean	_bRtPrYFlg;				/* 年荒利率入力有無区分     */
	private boolean	_bRateYrFlg;			/* 年利回り入力有無区分     */
	private boolean	_bRateUnFlg;			/* 運用利回り入力有無区分   */
	private boolean	_bTrueRtFlg;			/* ＴＲ入力有無区分         */
	private boolean	_bLeaseMFlg;			/* ﾘｰｽ月数入力有無区分      */
	private boolean	_bRateROIFlag;			/* Roi入力有無区分          */

//20040830 ljq add s
	private double	_dROE;					/* ROE */
	private double	_dFROE;					/* FullPay ROE */
	private int 		_nLeverage;				/*Leverage */


//20040830 ljq add e
//ydy add 20061011 s
	private String 		_strYuSin;				/*GE格付*/
//	ydy add 20061011 e
	//ydy add 20070410 s
	private String 		_strROITax = "0";				/*ROIの税率*/
	//ydy add 20070410 e
    /**
     * 契約先名を取得する． <BR>
     * @return  String 契約先名の文字列
     */
	public String getUserNm() {
	    return _strUserNm;
	}
    /**
     * 契約先名を設定する． <BR>
	 * @param strUserNm	契約先名の文字列
     */
	public void setUserNm(String strUserNm) {
	    _strUserNm = strUserNm;
	}

    /**
     * 契約番号を取得する． <BR>
     * @return  String 契約番号の文字列
     */
	public String getKeiyaku() {
	    return _strKeiyaku;
	}
    /**
     * 契約番号を設定する． <BR>
	 * @param strKeiyaku	契約番号の文字列
     */
	public void setKeiyaku(String strKeiyaku) {
	    _strKeiyaku = strKeiyaku;
	}

    /**
     * 検収番号１を取得する． <BR>
     * @return  String 検収番号１の文字列
     */
	public String getKenshu1() {
	    return _strKenshu1;
	}
    /**
     * 検収番号１を設定する． <BR>
	 * @param strKenshu1	検収番号１の文字列
     */
	public void setKenshu1(String strKenshu1) {
	    _strKenshu1 = strKenshu1;
	}

    /**
     * 検収番号２を取得する． <BR>
     * @return  String 検収番号２の文字列
     */
	public String getKenshu2() {
	    return _strKenshu2;
	}
    /**
     * 検収番号２を設定する． <BR>
	 * @param strKenshu2	検収番号２の文字列
     */
	public void setKenshu2(String strKenshu2) {
	    _strKenshu2 = strKenshu2;
	}

    /**
     * 契約案件番号を取得する． <BR>
     * @return  long 契約案件番号の文字列
     */
	public long getRecno() {
	    return _lRecno;
	}
    /**
     * 契約案件番号を設定する． <BR>
	 * @param lRecno	契約案件番号の文字列
     */
	public void setRecno(long lRecno) {
	    _lRecno = lRecno;
	}

    /**
     * 物件№を取得する． <BR>
     * @return  int 物件№の文字列
     */
	public int getBukken() {
	    return _nBukken;
	}
    /**
     * 物件№を設定する． <BR>
	 * @param nBukken	物件№の文字列
     */
	public void setBukken(int nBukken) {
	    _nBukken = nBukken;
	}

    /**
     * 物件№(FROM)を取得する． <BR>
     * @return  int 物件№(FROM)の文字列
     */
	public int getBukkenF() {
	    return _nBukkenF;
	}
    /**
     * 物件№(FROM)を設定する． <BR>
	 * @param nBukkenF	物件№(FROM)の文字列
     */
	public void setBukkenF(int nBukkenF) {
	    _nBukkenF = nBukkenF;
	}

    /**
     * 物件№(TO)を取得する． <BR>
     * @return  int 物件№(TO)の文字列
     */
	public int getBukkenT() {
	    return _nBukkenT;
	}
    /**
     * 物件№(TO)を設定する． <BR>
	 * @param nBukkenT	物件№(TO)の文字列
     */
	public void setBukkenT(int nBukkenT) {
	    _nBukkenT = nBukkenT;
	}

    /**
     * 購入価額を取得する． <BR>
     * @return  double 購入価額の文字列
     */
	public double getPurchas() {
	    return _dPurchas;
	}
    /**
     * 購入価額を設定する． <BR>
	 * @param dPurchas	購入価額の文字列
     */
	public void setPurchas(double dPurchas) {
	    _dPurchas = dPurchas;
	}


	/**
	 * 低炭信用保険料を取得する． <BR>
	 * @return  double 低炭信用保険料の文字列
	 */
	public double getCriF() {
		return _dCriF;
	}
	/**
	 * 低炭信用保険料を設定する． <BR>
	 * @param _dCriF	低炭信用保険料の文字列
	 */
	public void setCriF(double dCriF) {
		_dCriF = dCriF;
	}

    /**
     * 残価を取得する． <BR>
     * @return  double 残価の文字列
     */
	public double getRemVAL() {
	    return _dRemVAL;
	}
    /**
     * 残価を設定する． <BR>
	 * @param dRemVAL	残価の文字列
     */
	public void setRemVAL(double dRemVAL) {
	    _dRemVAL = dRemVAL;
	}

    /**
     * 残価率を取得する． <BR>
     * @return  double 残価率の文字列
     */
	public double getRemVRT() {
	    return _dRemVRT;
	}
    /**
     * 残価率を設定する． <BR>
	 * @param dRemVRT	残価率の文字列
     */
	public void setRemVRT(double dRemVRT) {
		//HBQ 20060815 begin
		//六桁目で表示される七桁目で四捨五入する
	    _dRemVRT = LfcLogicComm.dround(dRemVRT,6);
		//HBQ 20060815 end
	}

    /**
     * 定率残価ｲﾝﾃﾞｯｸｽを取得する． <BR>
     * @return  int 定率残価ｲﾝﾃﾞｯｸｽの文字列
     */
	public int getFremIX() {
	    return _nFremIX;
	}
    /**
     * 定率残価ｲﾝﾃﾞｯｸｽを設定する． <BR>
	 * @param nFremIX	定率残価ｲﾝﾃﾞｯｸｽの文字列
     */
	public void setFremIX(int nFremIX) {
	    _nFremIX = nFremIX;
	}

    /**
     * 支払利息を取得する． <BR>
     * @return  double 支払利息の文字列
     */
	public double getInterP() {
	    return _dInterP;
	}
    /**
     * 支払利息を設定する． <BR>
	 * @param dInterP	支払利息の文字列
     */
	public void setInterP(double dInterP) {
	    _dInterP = dInterP;
	}

    /**
     * 固定資産税を取得する． <BR>
     * @return  double 固定資産税の文字列
     */
	public double getFatax() {
	    return _dFatax;
	}
    /**
     * 固定資産税を設定する． <BR>
	 * @param dFatax	固定資産税の文字列
     */
	public void setFatax(double dFatax) {
	    _dFatax = dFatax;
	}

    /**
     * 保険料を取得する． <BR>
     * @return  double 保険料の文字列
     */
	public double getInsur() {
	    return _dInsur;
	}
    /**
     * 保険料を設定する． <BR>
	 * @param dInsur	保険料の文字列
     */
	public void setInsur(double dInsur) {
	    _dInsur = dInsur;
	}

    /**
     * その他の雑費 を取得する． <BR>
     * @return  double その他の雑費 の文字列
     */
	public double getZappi() {
	    return _dZappi;
	}
    /**
     * その他の雑費 を設定する． <BR>
	 * @param dZappi	その他の雑費 の文字列
     */
	public void setZappi(double dZappi) {
	    _dZappi = dZappi;
	}

    /**
     * 割賦保険料を取得する． <BR>
     * @return  double 割賦保険料の文字列
     */
	public double getKappuI() {
	    return _dKappuI;
	}
    /**
     * 割賦保険料を設定する． <BR>
	 * @param dKappuI	割賦保険料の文字列
     */
	public void setKappuI(double dKappuI) {
	    _dKappuI = dKappuI;
	}

    /**
     * その他一時費用(ｲ)を取得する． <BR>
     * @return  double その他一時費用(ｲ)の文字列
     */
	public double getIchiji1() {
	    return _dIchiji1;
	}
    /**
     * その他一時費用(ｲ)を設定する． <BR>
	 * @param dIchiji1	その他一時費用(ｲ)の文字列
     */
	public void setIchiji1(double dIchiji1) {
	    _dIchiji1 = dIchiji1;
	}

    /**
     * その他一時費用(ﾛ)を取得する． <BR>
     * @return  double その他一時費用(ﾛ)の文字列
     */
	public double getIchiji2() {
	    return _dIchiji2;
	}
    /**
     * その他一時費用(ﾛ)を設定する． <BR>
	 * @param dIchiji2	その他一時費用(ﾛ)の文字列
     */
	public void setIchiji2(double dIchiji2) {
	    _dIchiji2 = dIchiji2;
	}

    /**
     * その他一時費用(ﾊ)を取得する． <BR>
     * @return  double その他一時費用(ﾊ)の文字列
     */
	public double getIchiji3() {
	    return _dIchiji3;
	}
    /**
     * その他一時費用(ﾊ)を設定する． <BR>
	 * @param dIchiji3	その他一時費用(ﾊ)の文字列
     */
	public void setIchiji3(double dIchiji3) {
	    _dIchiji3 = dIchiji3;
	}

    /**
     * その他繰延費用(ﾍ)を取得する． <BR>
     * @return  double その他繰延費用(ﾍ)の文字列
     */
	public double getKurino1() {
	    return _dKurino1;
	}
    /**
     * その他繰延費用(ﾍ)を設定する． <BR>
	 * @param dKurino1	その他繰延費用(ﾍ)の文字列
     */
	public void setKurino1(double dKurino1) {
	    _dKurino1 = dKurino1;
	}

    /**
     * その他繰延費用(ﾄ)を取得する． <BR>
     * @return  double その他繰延費用(ﾄ)の文字列
     */
	public double getKurino2() {
	    return _dKurino2;
	}
    /**
     * その他繰延費用(ﾄ)を設定する． <BR>
	 * @param dKurino2	その他繰延費用(ﾄ)の文字列
     */
	public void setKurino2(double dKurino2) {
	    _dKurino2 = dKurino2;
	}

    /**
     * 保守料を取得する． <BR>
     * @return  double 保守料の文字列
     */
	public double getHoshury() {
	    return _dHoshury;
	}
    /**
     * 保守料を設定する． <BR>
	 * @param dHoshury	保守料の文字列
     */
	public void setHoshury(double dHoshury) {
	    _dHoshury = dHoshury;
	}

    /**
     * 斡旋手数料を取得する． <BR>
     * @return  double 斡旋手数料の文字列
     */
	public double getAssen() {
	    return _dAssen;
	}
    /**
     * 斡旋手数料を設定する． <BR>
	 * @param dAssen	斡旋手数料の文字列
     */
	public void setAssen(double dAssen) {
	    _dAssen = dAssen;
	}

    /**
     * ﾘｰｽ/割賦原価計を取得する． <BR>
     * @return  double ﾘｰｽ/割賦原価計の文字列
     */
	public double getCostT() {
	    return _dCostT;
	}
    /**
     * ﾘｰｽ/割賦原価計を設定する． <BR>
	 * @param dCostT	ﾘｰｽ/割賦原価計の文字列
     */
	public void setCostT(double dCostT) {
	    _dCostT = dCostT;
	}

    /**
     * 当社手数料を取得する． <BR>
     * @return  double 当社手数料の文字列
     */
	public double getCharge() {
	    return _dCharge;
	}

    /**
     * 当社手数料を設定する． <BR>
	 * @param dCharge	当社手数料の文字列
     */
	public void setCharge(double dCharge) {
	    _dCharge = dCharge;
	}

    /**
     * 契約額を取得する． <BR>
     * @return  double 契約額の文字列
     */
	public double getIncGt() {
	    return _dIncGt;
	}

    /**
     * 契約額を設定する． <BR>
	 * @param dIncGt	契約額の文字列
     */
	public void setIncGt(double dIncGt) {
	    _dIncGt = dIncGt;
	}

    /**
     * 前受ﾘｰｽ料/頭金を取得する． <BR>
     * @return  double 前受ﾘｰｽ料/頭金の文字列
     */
	public double getInc0() {
	    return _dInc0;
	}

    /**
     * 前受ﾘｰｽ料/頭金を設定する． <BR>
	 * @param dInc0	前受ﾘｰｽ料/頭金の文字列
     */
	public void setInc0(double dInc0) {
	    _dInc0 = dInc0;
	}

    /**
     * 前受ﾘｰｽ月数を取得する． <BR>
     * @return  double 前受ﾘｰｽ月数の文字列
     */
	public double getInc0M() {
	    return _dInc0M;
	}

    /**
     * 前受ﾘｰｽ月数を設定する． <BR>
	 * @param dInc0M	前受ﾘｰｽ月数の文字列
     */
	public void setInc0M(double dInc0M) {
	    _dInc0M = dInc0M;
	}

    /**
     * 原価調整額を取得する． <BR>
     * @return  double 原価調整額の文字列
     */
	public double getCAdj() {
	    return _dCAdj;
	}

    /**
     * 原価調整額を設定する． <BR>
	 * @param dRtLossR	原価調整額の文字列
     */
	public void setCAdj(double dCAdj) {
	    _dCAdj = dCAdj;
	}

    /**
     * 荒利益額を取得する． <BR>
     * @return  double 荒利益額の文字列
     */
	public double getProfT() {
	    return _dProfT;
	}

    /**
     * 荒利益額を設定する． <BR>
	 * @param dProfT	荒利益額の文字列
     */
	public void setProfT(double dProfT) {
	    _dProfT = dProfT;
	}

    /**
     * 年荒利益額を取得する． <BR>
     * @return  double 年荒利益額の文字列
     */
	public double getProfY() {
	    return _dProfY;
	}

    /**
     * 年荒利益額を設定する． <BR>
	 * @param dProfY	年荒利益額の文字列
     */
	public void setProfY(double dProfY) {
	    _dProfY = dProfY;
	}

    /**
     * 使用総資金を取得する． <BR>
     * @return  double 使用総資金の文字列
     */
	public double getCapitT() {
	    return _dCapitT;
	}

    /**
     * 使用総資金を設定する． <BR>
	 * @param dCapitT	使用総資金の文字列
     */
	public void setCapitT(double dCapitT) {
	    _dCapitT = dCapitT;
	}

    /**
     * 総荒利率を取得する． <BR>
     * @return  double 総荒利率の文字列
     */
	public double getRtPrT() {
	    return _dRtPrT;
	}

    /**
     * 総荒利率を設定する． <BR>
	 * @param dRtPrT	総荒利率の文字列
     */
	public void setRtPrT(double dRtPrT) {
	    _dRtPrT = dRtPrT;
	}

    /**
     * 年荒利率を取得する． <BR>
     * @return  double 年荒利率の文字列
     */
	public double getRtPrY() {
	    return _dRtPrY;
	}

    /**
     * 年荒利率を設定する． <BR>
	 * @param dRtPrY	年荒利率の文字列
     */
	public void setRtPrY(double dRtPrY) {
	    _dRtPrY = dRtPrY;
	}

    /**
     * 年利回りを取得する． <BR>
     * @return  double 年利回りの文字列
     */
	public double getRateYr() {
	    return _dRateYr;
	}

    /**
     * 年利回りを設定する． <BR>
	 * @param dRateYr	年利回りの文字列
     */
	public void setRateYr(double dRateYr) {
	    _dRateYr = dRateYr;
	}

    /**
     * 社内金利を取得する． <BR>
     * @return  double 社内金利の文字列
     */
	public double getRateJL() {
	    return _dRateJL;
	}

    /**
     * 社内金利を設定する． <BR>
	 * @param dRateJL	社内金利の文字列
     */
	public void setRateJL(double dRateJL) {
	    _dRateJL = dRateJL;
	}

    /**
     * 運用利回りを取得する． <BR>
     * @return  double 運用利回りの文字列
     */
	public double getRateUN() {
	    return _dRateUN;
	}

    /**
     * 運用利回りを設定する． <BR>
	 * @param dRateUN	運用利回りの文字列
     */
	public void setRateUN(double dRateUN) {
	    _dRateUN = dRateUN;
	}

    /**
     * ＴＲを取得する． <BR>
     * @return  double ＴＲの文字列
     */
	public double getTrueRT() {
	    return _dTrueRT;
	}

    /**
     * ＴＲを設定する． <BR>
	 * @param dTrueRT	ＴＲの文字列
     */
	public void setTrueRT(double dTrueRT) {
	    _dTrueRT = dTrueRT;
	}

    /**
     * 原調計算金利を取得する． <BR>
     * @return  double 原調計算金利の文字列
     */
	public double getRateCADJ() {
	    return _dRateCADJ;
	}

    /**
     * 原調計算金利を設定する． <BR>
	 * @param dRateCADJ	原調計算金利の文字列
     */
	public void setRateCADJ(double dRateCADJ) {
	    _dRateCADJ = dRateCADJ;
	}

    /**
     * ＲＯＩを取得する． <BR>
     * @return  double ＲＯＩの文字列
     */
	public double getRateROI() {
	    return _dRateROI;
	}

    /**
     * ＲＯＩを設定する． <BR>
	 * @param dRateROI	ＲＯＩの文字列
     */
	public void setRateROI(double dRateROI) {
	    _dRateROI = dRateROI;
	}

    /**
     * 検収予定日を取得する． <BR>
     * @return  long 検収予定日の文字列
     */
	public long getDKensh() {
	    return _lDKensh;
	}

    /**
     * 検収予定日を設定する． <BR>
	 * @param lDKensh	検収予定日の文字列
     */
	public void setDKensh(long lDKensh) {
	    _lDKensh = lDKensh;
	}

    /**
     * 支払予定日を取得する． <BR>
     * @return  long 支払予定日の文字列
     */
	public long getDPaymt() {
	    return _lDPaymt;
	}

    /**
     * 支払予定日を設定する． <BR>
	 * @param lDPaymt	支払予定日の文字列
     */
	public void setDPaymt(long lDPaymt) {
	    _lDPaymt = lDPaymt;
	}

    /**
     * 原価調整月数を取得する． <BR>
     * @return  int 原価調整月数の文字列
     */
	public int getAdjM() {
	    return _nAdjM;
	}

    /**
     * 原価調整月数を設定する． <BR>
	 * @param nAdjM	原価調整月数の文字列
     */
	public void setAdjM(int nAdjM) {
	    _nAdjM = nAdjM;
	}

    /**
     * 原価調整日数を取得する． <BR>
     * @return  int 原価調整日数の文字列
     */
	public int getAdjD() {
	    return _nAdjD;
	}

    /**
     * 原価調整日数を設定する． <BR>
	 * @param nAdjD	原価調整日数の文字列
     */
	public void setAdjD(int nAdjD) {
	    _nAdjD = nAdjD;
	}

    /**
     * ﾘｰｽ料/割賦金総額を取得する． <BR>
     * @return  double ﾘｰｽ料/割賦金総額の文字列
     */
	public double getIncT() {
	    return _dIncT;
	}

    /**
     * ﾘｰｽ料/割賦金総額を設定する． <BR>
	 * @param dIncT	ﾘｰｽ料/割賦金総額の文字列
     */
	public void setIncT(double dIncT) {
	    _dIncT = dIncT;
	}

    /**
     * 初期費用を取得する． <BR>
     * @return  double 初期費用の文字列
     */
	public double getInitC() {
	    return _dInitC;
	}

    /**
     * 初期費用を設定する． <BR>
	 * @param dInitC    	初期費用の文字列
     */
	public void setInitC(double dInitC) {
	    _dInitC = dInitC;
	}

    /**
     * 実行費用総額を取得する． <BR>
     * @return  double 実行費用総額の文字列
     */
	public double getExecC() {
	    return _dExecC;
	}

    /**
     * 実行費用総額を設定する． <BR>
	 * @param dExecC	実行費用総額の文字列
     */
	public void setExecC(double dExecC) {
	    _dExecC = dExecC;
	}

    /**
     * ＮＥＴ率を取得する． <BR>
     * @return  double ＮＥＴ率の文字列
     */
	public double getNetRt() {
	    return _dNetRt;
	}

    /**
     * ＮＥＴ率を設定する． <BR>
	 * @param dNetRt	ＮＥＴ率の文字列
     */
	public void setNetRt(double dNetRt) {
	    _dNetRt = dNetRt;
	}

    /**
     * 回収利息を取得する． <BR>
     * @return  double 回収利息の文字列
     */
	public double getInterI() {
	    return _dInterI;
	}

    /**
     * 回収利息を設定する． <BR>
	 * @param dInterI	回収利息の文字列
     */
	public void setInterI(double dInterI) {
	    _dInterI = dInterI;
	}

    /**
     * 動総保険料率を取得する． <BR>
     * @return  double 動総保険料率の文字列
     */
	public double getDosoRt() {
	    return _dDosoRt;
	}

    /**
     * 動総保険料率を設定する． <BR>
	 * @param dDosoRt	動総保険料率の文字列
     */
	public void setDosoRt(double dDosoRt) {
	    _dDosoRt = dDosoRt;
	}

    /**
     * 機械保険料率を取得する． <BR>
     * @return  double 動総保険料率の文字列
     */
	public double getMachiF() {
	    return _dMachiF;
	}

    /**
     * 機械保険料を設定する． <BR>
	 * @param dMachiF	動総保険料率の文字列
     */
	public void setMachiF(double dMachiF) {
	    _dMachiF = dMachiF;
	}
    /**
     * ｿﾌﾄｳｪｱ区分を取得する． <BR>
     * @return  String ｿﾌﾄｳｪｱ区分の文字列
     */
	public String getSwSoft() {
	    return _strSwSoft;
	}

    /**
     * ｿﾌﾄｳｪｱ区分を設定する． <BR>
	 * @param strSwSoft	ｿﾌﾄｳｪｱ区分の文字列
     */
	public void setSwSoft(String strSwSoft) {
	    _strSwSoft = strSwSoft;
	}

    /**
     * 賠責保険付保区分を取得する． <BR>
     * @return  String 賠責保険付保区分の文字列
     */
	public String getSwBais() {
	    return _strSwBais;
	}

    /**
     * 賠責保険付保区分を設定する． <BR>
	 * @param strSwBais	賠責保険付保区分の文字列
     */
	public void setSwBais(String strSwBais) {
	    _strSwBais = strSwBais;
	}

    /**
     * エコリース区分を取得する． <BR>
     * @return  String エコリース区分の文字列
     */
	public String getSwCri() {
	    return _strSwCri;
	}

    /**
     * 被災補助金区分有無を設定する． <BR>
	 * @param strSwCri	被災補助金区分有無の文字列
     */
	public void setHisai(String strHisai) {
		_strHisai = strHisai;
	}

	/**
	 * 被災補助金区分有無を取得する． <BR>
	 * @return  String 被災補助金区分有無の文字列
	 */
	public String getHisai() {
		return _strHisai;
	}

	/**
	 * エコリース区分を設定する． <BR>
	 * @param strSwCri	エコリース区分の文字列
	 */
	public void setSwCri(String strSwCri) {
		_strSwCri = strSwCri;
	}
    /**
     * 少額資産区分を取得する． <BR>
     * @return  String 少額資産区分の文字列
     */
	public String getSwSPro() {
	    return _strSwSPro;
	}

    /**
     * 少額資産区分を設定する． <BR>
	 * @param strSwSPro	少額資産区分の文字列
     */
	public void setSwSPro(String strSwSPro) {
	    _strSwSPro = strSwSPro;
	}

    /**
     * 分割支払有無区分を取得する． <BR>
     * @return  String 分割支払有無区分の文字列
     */
	public boolean getSwPay() {
	    return _bSwPay;
	}

    /**
     * 分割支払有無区分を設定する． <BR>
	 * @param strSwPay	分割支払有無区分の文字列
     */
	public void setSwPay(boolean bSwPay) {
	    _bSwPay = bSwPay;
	}

    /**
     * 動総保険金額指数を取得する． <BR>
     * @return  double 動総保険金額指数の文字列
     */
	public double getDosoIx() {
	    return _dDosoIx;
	}

    /**
     * 動総保険金額指数を設定する． <BR>
	 * @param dDosoIx	動総保険金額指数の文字列
     */
	public void setDosoIx(double dDosoIx) {
	    _dDosoIx = dDosoIx;
	}

    /**
     * 動総保険料を取得する． <BR>
     * @return  double 動総保険料の文字列
     */
	public double getDosoF() {
	    return _dDosoF;
	}

    /**
     * 動総保険料を設定する． <BR>
	 * @param dDosoF	動総保険料の文字列
     */
	public void setDosoF(double dDosoF) {
	    _dDosoF = dDosoF;
	}

    /**
     * 火災保険料を取得する． <BR>
     * @return  double 火災保険料の文字列
     */
	public double getFireF() {
	    return _dFireF;
	}

    /**
     * 火災保険料を設定する． <BR>
	 * @param dFireF	火災保険料の文字列
     */
	public void setFireF(double dFireF) {
	    _dFireF = dFireF;
	}

    /**
     * 船舶・ソノタ保険料を取得する． <BR>
     * @return  double 船舶・ソノタ保険料の文字列
     */
	public double getEtcF() {
	    return _dEtcF;
	}

    /**
     * 船舶・ソノタ保険料を設定する． <BR>
	 * @param dEtcF	船舶・ソノタ保険料の文字列
     */
	public void setEtcF(double dEtcF) {
	    _dEtcF = dEtcF;
	}

    /**
     * 団信保険料率を取得する． <BR>
     * @return  double 団信保険料率の文字列
     */
	public double getDansRt() {
	    return _dDansRt;
	}

    /**
     * 団信保険料率を設定する． <BR>
	 * @param dDansRt	団信保険料率の文字列
     */
	public void setDansRt(double dDansRt) {
	    _dDansRt = dDansRt;
	}

    /**
     * 低炭素リース付保期間を取得する． <BR>
     * @return  int 低炭素リース付保期間の文字列
     */
	public int getCriTm() {
	    return _nCriTm;
	}

    /**
     * 低炭素リース付保期間を設定する． <BR>
	 * @param nCriTm	低炭素リース付保期間の文字列
     */
	public void setCriTm(int nCriTm) {
	    _nCriTm = nCriTm;
	}

    /**
     * 低炭素リース保険料率を取得する． <BR>
     * @return  double 低炭素リース保険料率の文字列
     */
	public double getCriRt() {
	    return _dCriRt;
	}

    /**
     * 低炭素リース保険料率を設定する． <BR>
	 * @param dCriRt	低炭素リース保険料率の文字列
     */
	public void setCriRt(double dCriRt) {
	    _dCriRt = dCriRt;
	}

    /**
     * 割賦信保機種コ－ドを取得する． <BR>
     * @return  String 割賦信保機種コ－ドの文字列
     */
	public String getCriCd() {
	    return _strCriCd;
	}

    /**
     * 割賦信保機種コ－ドを設定する． <BR>
	 * @param strCriCd	割賦信保機種コ－ドの文字列
     */
	public void setCriCd(String strCriCd) {
	    _strCriCd = strCriCd;
	}

    /**
     * ﾘｰｽ月数を取得する． <BR>
     * @return  int ﾘｰｽ月数の文字列
     */
	public int getLeaseM() {
	    return _nLeaseM;
	}

    /**
     * ﾘｰｽ月数を設定する． <BR>
	 * @param nLeaseM	ﾘｰｽ月数の文字列
     */
	public void setLeaseM(int nLeaseM) {
	    _nLeaseM = nLeaseM;
	}

    /**
     * 据置月数を取得する． <BR>
     * @return  int 据置月数の文字列
     */
	public int getLeaveM() {
	    return _nLeaveM;
	}

    /**
     * 据置月数を設定する． <BR>
	 * @param nLeaveM	据置月数の文字列
     */
	public void setLeaveM(int nLeaveM) {
	    _nLeaveM = nLeaveM;
	}

    /**
     * 割賦月数を取得する． <BR>
     * @return  int 割賦月数の文字列
     */
	public int getKappuM() {
	    return _nKappuM;
	}

    /**
     * 割賦月数を設定する． <BR>
	 * @param nKappuM	割賦月数の文字列
     */
	public void setKappuM(int nKappuM) {
	    _nKappuM = nKappuM;
	}

    /**
     * 法定耐用年数を取得する． <BR>
     * @return  int 法定耐用年数の文字列
     */
	public int getDuraY() {
	    return _nDuraY;
	}

    /**
     * 法定耐用年数を設定する． <BR>
	 * @param nDuraY	法定耐用年数の文字列
     */
	public void setDuraY(int nDuraY) {
	    _nDuraY = nDuraY;
	}

    /**
     * 物件数量を取得する． <BR>
     * @return  int 物件数量の文字列
     */
	public int getQuant() {
	    return _nQuant;
	}

    /**
     * 物件数量を設定する． <BR>
	 * @param nQuant	物件数量の文字列
     */
	public void setQuant(int nQuant) {
	    _nQuant = nQuant;
	}

    /**
     * 前受ﾘｰｽ料回収日を取得する． <BR>
     * @return  long 前受ﾘｰｽ料回収日の文字列
     */
	public long getDInc0() {
	    return _lDInc0;
	}

    /**
     * 前受ﾘｰｽ料回収日を設定する． <BR>
	 * @param lDInc0	前受ﾘｰｽ料回収日の文字列
     */
	public void setDInc0(long lDInc0) {
	    _lDInc0 = lDInc0;
	}

    /**
     * 合計料率を取得する． <BR>
     * @return  double 合計料率の文字列
     */
	public double getRyortT() {
	    return _dRyortT;
	}

    /**
     * 合計料率を設定する． <BR>
	 * @param dRyortT	合計料率の文字列
     */
	public void setRyortT(double dRyortT) {
	    _dRyortT = dRyortT;
	}

    /**
     * 月料率を取得する． <BR>
     * @return  double 月料率の文字列
     */
	public double getRyortM() {
	    return _dRyortM;
	}

    /**
     * 月料率を設定する． <BR>
	 * @param dRyortM	月料率の文字列
     */
	public void setRyortM(double dRyortM) {
	    _dRyortM = dRyortM;
	}

    /**
     * ﾘｰｽ段数を取得する． <BR>
     * @return  int ﾘｰｽ段数の文字列
     */
	public int getLeaseD() {
	    return _nLeaseD;
	}

    /**
     * ﾘｰｽ段数を設定する． <BR>
	 * @param nLeaseD	ﾘｰｽ段数の文字列
     */
	public void setLeaseD(int nLeaseD) {
	    _nLeaseD = nLeaseD;
	}

    /**
     * 割賦段数を取得する． <BR>
     * @return  int 割賦段数の文字列
     */
	public int getKappuD() {
	    return _nKappuD;
	}

    /**
     * 割賦段数を設定する． <BR>
	 * @param nKappuD	割賦段数の文字列
     */
	public void setKappuD(int nKappuD) {
	    _nKappuD = nKappuD;
	}

    /**
     * 賠責保険料を取得する． <BR>
     * @return  double 賠責保険料の文字列
     */
	public double getBaisF() {
	    return _dBaisF;
	}

    /**
     * 賠責保険料を設定する． <BR>
	 * @param dBaisF	賠責保険料の文字列
     */
	public void setBaisF(double dBaisF) {
	    _dBaisF = dBaisF;
	}

    /**
     * 均等回収区分を取得する． <BR>
     * @return  int 均等回収区分の文字列
     */
	public int getEvenFlg() {
	    return _nEvenFlg;
	}

    /**
     * 均等回収区分を設定する． <BR>
	 * @param nEvenFlg	均等回収区分の文字列
     */
	public void setEvenFlg(int nEvenFlg) {
	    _nEvenFlg = nEvenFlg;
	}

    /**
     * 最終回収予定日を取得する． <BR>
     * @return  long 最終回収予定日の文字列
     */
	public long getFidtIn() {
	    return _lFidtIn;
	}

    /**
     * 最終回収予定日を設定する． <BR>
	 * @param lFidtIn	最終回収予定日の文字列
     */
	public void setFidtIn(long lFidtIn) {
	    _lFidtIn = lFidtIn;
	}

    /**
     * 分割回数（回収）を取得する． <BR>
     * @return  int 分割回数（回収）の文字列
     */
	public int getDivfreq() {
	    return _nDivfreq;
	}

    /**
     * 分割回数（回収）を設定する． <BR>
	 * @param nDivfreq	分割回数（回収）の文字列
     */
	public void setDivfreq(int nDivfreq) {
	    _nDivfreq = nDivfreq;
	}

    /**
     * 規定損害金基本額を取得する． <BR>
     * @return  double 規定損害金基本額の文字列
     */
	public double getDamBas() {
	    return _dDamBas;
	}

    /**
     * 規定損害金基本額を設定する． <BR>
	 * @param dDamBas	規定損害金基本額の文字列
     */
	public void setDamBas(double dDamBas) {
	    _dDamBas = dDamBas;
	}

    /**
     * 規定損害金前半逓減月数を取得する． <BR>
     * @return  double 規定損害金前半逓減月数の文字列
     */
	public double getDamFm() {
	    return _dDamFm;
	}

    /**
     * 規定損害金前半逓減月数を設定する． <BR>
	 * @param dDamFm	規定損害金前半逓減月数の文字列
     */
	public void setDamFm(double dDamFm) {
	    _dDamFm = dDamFm;
	}

    /**
     * 規定損害金後半逓減月数を取得する． <BR>
     * @return  double 規定損害金後半逓減月数の文字列
     */
	public double getDamLm() {
	    return _dDamLm;
	}

    /**
     * 規定損害金後半逓減月数を設定する． <BR>
	 * @param dDamLm	規定損害金後半逓減月数の文字列
     */
	public void setDamLm(double dDamLm) {
	    _dDamLm = dDamLm;
	}

    /**
     * 規定損害金前半逓減月額を取得する． <BR>
     * @return  double 規定損害金前半逓減月額の文字列
     */
	public double getDamFa() {
	    return _dDamFa;
	}

    /**
     * 規定損害金前半逓減月額を設定する． <BR>
	 * @param dDamFa	規定損害金前半逓減月額の文字列
     */
	public void setDamFa(double dDamFa) {
	    _dDamFa = dDamFa;
	}

    /**
     * 規定損害金後半逓減月額を取得する． <BR>
     * @return  double 規定損害金後半逓減月額の文字列
     */
	public double getDamLa() {
	    return _dDamLa;
	}

    /**
     * 規定損害金後半逓減月額を設定する． <BR>
	 * @param dDamLa	規定損害金後半逓減月額の文字列
     */
	public void setDamLa(double dDamLa) {
	    _dDamLa = dDamLa;
	}

    /**
     * ﾌﾙﾍﾟｲ支払利息を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ支払利息の文字列
     */
	public double getFIntP() {
	    return _dFIntP;
	}

    /**
     * ﾌﾙﾍﾟｲ支払利息を設定する． <BR>
	 * @param dFIntP	ﾌﾙﾍﾟｲ支払利息の文字列
     */
	public void setFIntP(double dFIntP) {
	    _dFIntP = dFIntP;
	}

    /**
     * ﾌﾙﾍﾟｲ回収利息を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ回収利息の文字列
     */
	public double getFIntI() {
	    return _dFIntI;
	}

    /**
     * ﾌﾙﾍﾟｲ回収利息を設定する． <BR>
	 * @param dRtLossR	ﾌﾙﾍﾟｲ回収利息の文字列
     */
	public void setFIntI(double dFIntI) {
	    _dFIntI = dFIntI;
	}

    /**
     * ﾌﾙﾍﾟｲ当社手数料を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ当社手数料の文字列
     */
	public double getFCharge() {
	    return _dFCharge;
	}

    /**
     * ﾌﾙﾍﾟｲ当社手数料を設定する． <BR>
	 * @param dFCharge	ﾌﾙﾍﾟｲ当社手数料の文字列
     */
	public void setFCharge(double dFCharge) {
	    _dFCharge = dFCharge;
	}

    /**
     * ﾌﾙﾍﾟｲ実行費用総額を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ実行費用総額の文字列
     */
	public double getFExecC() {
	    return _dFExecC;
	}

    /**
     * ﾌﾙﾍﾟｲ実行費用総額を設定する． <BR>
	 * @param dFExecC	ﾌﾙﾍﾟｲ実行費用総額の文字列
     */
	public void setFExecC(double dFExecC) {
	    _dFExecC = dFExecC;
	}

    /**
     * ﾌﾙﾍﾟｲ繰延費用(ﾍ)を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ繰延費用(ﾍ)の文字列
     */
	public double getFKuri1() {
	    return _dFKuri1;
	}

    /**
     * ﾌﾙﾍﾟｲ繰延費用(ﾍ)を設定する． <BR>
	 * @param dFKuri1	ﾌﾙﾍﾟｲ繰延費用(ﾍ)の文字列
     */
	public void setFKuri1(double dFKuri1) {
	    _dFKuri1 = dFKuri1;
	}

    /**
     * ﾌﾙﾍﾟｲ保険料を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ保険料の文字列
     */
	public double getFInsur() {
	    return _dFInsur;
	}

    /**
     * ﾌﾙﾍﾟｲ保険料を設定する． <BR>
	 * @param dFInsur	ﾌﾙﾍﾟｲ保険料の文字列
     */
	public void setFInsur(double dFInsur) {
	    _dFInsur = dFInsur;
	}

    /**
     * ﾌﾙﾍﾟｲﾘｰｽ原価計を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲﾘｰｽ原価計の文字列
     */
	public double getFCostT() {
	    return _dFCostT;
	}

    /**
     * ﾌﾙﾍﾟｲﾘｰｽ原価計を設定する． <BR>
	 * @param dFCostT	ﾌﾙﾍﾟｲﾘｰｽ原価計の文字列
     */
	public void setFCostT(double dFCostT) {
	    _dFCostT = dFCostT;
	}

    /**
     * ﾌﾙﾍﾟｲ荒利益額を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ荒利益額の文字列
     */
	public double getFProT() {
	    return _dFProT;
	}

    /**
     * ﾌﾙﾍﾟｲ荒利益額を設定する． <BR>
	 * @param dFProT	ﾌﾙﾍﾟｲ荒利益額の文字列
     */
	public void setFProT(double dFProT) {
	    _dFProT = dFProT;
	}

    /**
     * ﾌﾙﾍﾟｲ年荒利益額を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ年荒利益額の文字列
     */
	public double getFProY() {
	    return _dFProY;
	}

    /**
     * ﾌﾙﾍﾟｲ年荒利益額を設定する． <BR>
	 * @param dFProY	ﾌﾙﾍﾟｲ年荒利益額の文字列
     */
	public void setFProY(double dFProY) {
	    _dFProY = dFProY;
	}

    /**
     * ﾌﾙﾍﾟｲ使用総資金を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ使用総資金の文字列
     */
	public double getFCapT() {
	    return _dFCapT;
	}

    /**
     * ﾌﾙﾍﾟｲ使用総資金を設定する． <BR>
	 * @param dFCapT	ﾌﾙﾍﾟｲ使用総資金の文字列
     */
	public void setFCapT(double dFCapT) {
	    _dFCapT = dFCapT;
	}

    /**
     * ﾌﾙﾍﾟｲＴＲを取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲＴＲの文字列
     */
	public double getFTrueRT() {
	    return _dFTrueRT;
	}

    /**
     * ﾌﾙﾍﾟｲＴＲを設定する． <BR>
	 * @param dFTrueRT	ﾌﾙﾍﾟｲＴＲの文字列
     */
	public void setFTrueRT(double dFTrueRT) {
	    _dFTrueRT = dFTrueRT;
	}

    /**
     * ﾌﾙﾍﾟｲ年利回りを取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ年利回りの文字列
     */
	public double getFRtYr() {
	    return _dFRtYr;
	}

    /**
     * ﾌﾙﾍﾟｲ年利回りを設定する． <BR>
	 * @param dFRtYr	ﾌﾙﾍﾟｲ年利回りの文字列
     */
	public void setFRtYr(double dFRtYr) {
	    _dFRtYr = dFRtYr;
	}

    /**
     * ﾌﾙﾍﾟｲ運用利回りを取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ運用利回りの文字列
     */
	public double getFRtUn() {
	    return _dFRtUn;
	}

    /**
     * ﾌﾙﾍﾟｲ運用利回りを設定する． <BR>
	 * @param dFRtUn	ﾌﾙﾍﾟｲ運用利回りの文字列
     */
	public void setFRtUn(double dFRtUn) {
	    _dFRtUn = dFRtUn;
	}

    /**
     * ﾌﾙﾍﾟｲ総荒利率を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ総荒利率の文字列
     */
	public double getFRtPrt() {
	    return _dFRtPrt;
	}

    /**
     * ﾌﾙﾍﾟｲ総荒利率を設定する． <BR>
	 * @param dFRtPrt	ﾌﾙﾍﾟｲ総荒利率の文字列
     */
	public void setFRtPrt(double dFRtPrt) {
	    _dFRtPrt = dFRtPrt;
	}

    /**
     * ﾌﾙﾍﾟｲ年荒利率を取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲ年荒利率の文字列
     */
	public double getFRtPry() {
	    return _dFRtPry;
	}

    /**
     * ﾌﾙﾍﾟｲ年荒利率を設定する． <BR>
	 * @param dFRtPry	ﾌﾙﾍﾟｲ年荒利率の文字列
     */
	public void setFRtPry(double dFRtPry) {
	    _dFRtPry = dFRtPry;
	}

    /**
     * ﾌﾙﾍﾟｲＲＯＩを取得する． <BR>
     * @return  double ﾌﾙﾍﾟｲＲＯＩの文字列
     */
	public double getFRtRoi() {
	    return _dFRtRoi;
	}

    /**
     * ﾌﾙﾍﾟｲＲＯＩを設定する． <BR>
	 * @param dFRtRoi	ﾌﾙﾍﾟｲＲＯＩの文字列
     */
	public void setFRtRoi(double dFRtRoi) {
	    _dFRtRoi = dFRtRoi;
	}

    /**
     * 検収予定日（年）を取得する． <BR>
     * @return  int 検収予定日（年）の文字列
     */
	public int getDate1YY() {
	    return _nDate1YY;
	}

    /**
     * 検収予定日（年）を設定する． <BR>
	 * @param nDate1YY	検収予定日（年）の文字列
     */
	public void setDate1YY(int nDate1YY) {
	    _nDate1YY = nDate1YY;
	}

    /**
     * 検収予定日（月）を取得する． <BR>
     * @return  int 検収予定日（月）の文字列
     */
	public int getDate1MM() {
	    return _nDate1MM;
	}

    /**
     * 検収予定日（月）を設定する． <BR>
	 * @param nDate1MM	検収予定日（月）の文字列
     */
	public void setDate1MM(int nDate1MM) {
	    _nDate1MM = nDate1MM;
	}

    /**
     * 検収予定日（日）を取得する． <BR>
     * @return  int 検収予定日（日）の文字列
     */
	public int getDate1DD() {
	    return _nDate1DD;
	}

    /**
     * 検収予定日（日）を設定する． <BR>
	 * @param nDate1DD	検収予定日（日）の文字列
     */
	public void setDate1DD(int nDate1DD) {
	    _nDate1DD = nDate1DD;
	}

    /**
     * 支払予定日（年）を取得する． <BR>
     * @return  int 支払予定日（年）の文字列
     */
	public int getDate2YY() {
	    return _nDate2YY;
	}

    /**
     * 支払予定日（年）を設定する． <BR>
	 * @param nDate2YY	支払予定日（年）の文字列
     */
	public void setDate2YY(int nDate2YY) {
	    _nDate2YY = nDate2YY;
	}

    /**
     * 支払予定日（月）を取得する． <BR>
     * @return  int 支払予定日（月）の文字列
     */
	public int getDate2MM() {
	    return _nDate2MM;
	}

    /**
     * 支払予定日（月）を設定する． <BR>
	 * @param nDate2MM	支払予定日（月）の文字列
     */
	public void setDate2MM(int nDate2MM) {
	    _nDate2MM = nDate2MM;
	}

    /**
     * 支払予定日（日）を取得する． <BR>
     * @return  int 支払予定日（日）の文字列
     */
	public int getDate2DD() {
	    return _nDate2DD;
	}

    /**
     * 支払予定日（日）を設定する． <BR>
	 * @param nDate2DD	支払予定日（日）の文字列
     */
	public void setDate2DD(int nDate2DD) {
	    _nDate2DD = nDate2DD;
	}

    /**
     * 前受ﾘｰｽ料回収日（年）を取得する． <BR>
     * @return  int 前受ﾘｰｽ料回収日（年）の文字列
     */
	public int getDate3YY() {
	    return _nDate3YY;
	}

    /**
     * 前受ﾘｰｽ料回収日（年）を設定する． <BR>
	 * @param nDate3YY	前受ﾘｰｽ料回収日（年）の文字列
     */
	public void setDate3YY(int nDate3YY) {
	    _nDate3YY = nDate3YY;
	}

    /**
     * 前受ﾘｰｽ料回収日（月）を取得する． <BR>
     * @return  int 前受ﾘｰｽ料回収日（月）の文字列
     */
	public int getDate3MM() {
	    return _nDate3MM;
	}

    /**
     * 前受ﾘｰｽ料回収日（月）を設定する． <BR>
	 * @param nDate3MM	前受ﾘｰｽ料回収日（月）の文字列
     */
	public void setDate3MM(int nDate3MM) {
	    _nDate3MM = nDate3MM;
	}

    /**
     * ﾘｰｽ料回収日日付指定区分を取得する． <BR>
     * @return  int ﾘｰｽ料回収日日付指定区分の文字列
     */
	public int getDate3DD() {
	    return _nDate3DD;
	}

    /**
     * ﾘｰｽ料回収日日付指定区分を設定する． <BR>
	 * @param nDate3DD	ﾘｰｽ料回収日日付指定区分の文字列
     */
	public void setDate3DD(int nDate3DD) {
	    _nDate3DD = nDate3DD;
	}

    /**
     * ﾘｰｽ料回収日日付指定区分を取得する． <BR>
     * @return  int ﾘｰｽ料回収日日付指定区分の文字列
     */
	public int getInddFlg() {
	    return _nInddFlg;
	}

    /**
     * ﾘｰｽ料回収日日付指定区分を設定する． <BR>
	 * @param nInddFlg	ﾘｰｽ料回収日日付指定区分の文字列
     */
	public void setInddFlg(int nInddFlg) {
	    _nInddFlg = nInddFlg;
	}

    /**
     * 購入価額入力有無区分を取得する． <BR>
     * @return  boolean 購入価額入力有無区分の文字列
     */
	public boolean getPurchasFlg() {
	    return _bPurchasFlg;
	}

    /**
     * 購入価額入力有無区分を設定する． <BR>
	 * @param bPurchasFlg	購入価額入力有無区分の文字列
     */
	public void setPurchasFlg(boolean bPurchasFlg) {
	    _bPurchasFlg = bPurchasFlg;
	}

    /**
     * 残価入力有無区分を取得する． <BR>
     * @return  boolean 残価入力有無区分の文字列
     */
	public boolean getRemValFlg() {
	    return _bRemValFlg;
	}

    /**
     * 残価入力有無区分を設定する． <BR>
	 * @param bRemValFlg	残価入力有無区分の文字列
     */
	public void setRemValFlg(boolean bRemValFlg) {
	    _bRemValFlg = bRemValFlg;
	}

    /**
     * 残価率入力有無区分を取得する． <BR>
     * @return  boolean 残価率入力有無区分の文字列
     */
	public boolean getRemVRtFlg() {
	    return _bRemVRtFlg;
	}

    /**
     * 残価率入力有無区分を設定する． <BR>
	 * @param bRemVRtFlg	残価率入力有無区分の文字列
     */
	public void setRemVRtFlg(boolean bRemVRtFlg) {
	    _bRemVRtFlg = bRemVRtFlg;
	}

    /**
     * 前受/頭金入力有無区分を取得する． <BR>
     * @return  boolean 前受/頭金入力有無区分の文字列
     */
	public boolean getInc0Flg() {
	    return _bInc0Flg;
	}

    /**
     * 前受/頭金入力有無区分を設定する． <BR>
	 * @param bInc0Flg	前受/頭金入力有無区分の文字列
     */
	public void setInc0Flg(boolean bInc0Flg) {
	    _bInc0Flg = bInc0Flg;
	}

    /**
     * 前受ﾘｰｽ月数入力有無区分を取得する． <BR>
     * @return  boolean 前受ﾘｰｽ月数入力有無区分の文字列
     */
	public boolean getInc0MFlg() {
	    return _bInc0MFlg;
	}

    /**
     * 前受ﾘｰｽ月数入力有無区分を設定する． <BR>
	 * @param bInc0MFlg	前受ﾘｰｽ月数入力有無区分の文字列
     */
	public void setInc0MFlg(boolean bInc0MFlg) {
	    _bInc0MFlg = bInc0MFlg;
	}

    /**
     * 合計料率入力有無区分を取得する． <BR>
     * @return  boolean 合計料率入力有無区分の文字列
     */
	public boolean getRyortTFlg() {
	    return _bRyortTFlg;
	}

    /**
     * 合計料率入力有無区分を設定する． <BR>
	 * @param bRyortTFlg	合計料率入力有無区分の文字列
     */
	public void setRyortTFlg(boolean bRyortTFlg) {
	    _bRyortTFlg = bRyortTFlg;
	}

    /**
     * 月料率入力有無区分を取得する． <BR>
     * @return  boolean 月料率入力有無区分の文字列
     */
	public boolean getRyortMFlg() {
	    return _bRyortMFlg;
	}

    /**
     * 月料率入力有無区分を設定する． <BR>
	 * @param bRyortMFlg	月料率入力有無区分の文字列
     */
	public void setRyortMFlg(boolean bRyortMFlg) {
	    _bRyortMFlg = bRyortMFlg;
	}

    /**
     * 総荒利率入力有無区分を取得する． <BR>
     * @return  boolean 総荒利率入力有無区分の文字列
     */
	public boolean getRtPrTFlg() {
	    return _bRtPrTFlg;
	}

    /**
     * 総荒利率入力有無区分を設定する． <BR>
	 * @param bRtPrTFlg	総荒利率入力有無区分の文字列
     */
	public void setRtPrTFlg(boolean bRtPrTFlg) {
	    _bRtPrTFlg = bRtPrTFlg;
	}

    /**
     * 年荒利率入力有無区分を取得する． <BR>
     * @return  boolean 年荒利率入力有無区分の文字列
     */
	public boolean getRtPrYFlg() {
	    return _bRtPrYFlg;
	}

    /**
     * 年荒利率入力有無区分を設定する． <BR>
	 * @param bRtPrYFlg	年荒利率入力有無区分の文字列
     */
	public void setRtPrYFlg(boolean bRtPrYFlg) {
	    _bRtPrYFlg = bRtPrYFlg;
	}

    /**
     * 年利回り入力有無区分を取得する． <BR>
     * @return  boolean 年利回り入力有無区分の文字列
     */
	public boolean getRateYrFlg() {
	    return _bRateYrFlg;
	}

    /**
     * 年利回り入力有無区分を設定する． <BR>
	 * @param bRateYrFlg	年利回り入力有無区分の文字列
     */
	public void setRateYrFlg(boolean bRateYrFlg) {
	    _bRateYrFlg = bRateYrFlg;
	}

    /**
     * 運用利回り入力有無区分を取得する． <BR>
     * @return  boolean 運用利回り入力有無区分の文字列
     */
	public boolean getRateUnFlg() {
	    return _bRateUnFlg;
	}

    /**
     * 運用利回り入力有無区分を設定する． <BR>
	 * @param bRateUnFlg	運用利回り入力有無区分の文字列
     */
	public void setRateUnFlg(boolean bRateUnFlg) {
	    _bRateUnFlg = bRateUnFlg;
	}

    /**
     * ＴＲ入力有無区分を取得する． <BR>
     * @return  boolean ＴＲ入力有無区分の文字列
     */
	public boolean getTrueRtFlg() {
	    return _bTrueRtFlg;
	}

    /**
     * ＴＲ入力有無区分を設定する． <BR>
	 * @param bTrueRtFlg	ＴＲ入力有無区分の文字列
     */
	public void setTrueRtFlg(boolean bTrueRtFlg) {
	    _bTrueRtFlg = bTrueRtFlg;
	}

    /**
     * Roi入力有無区分を取得する． <BR>
     * @return  boolean Roi入力有無区分の文字列
     */
	public boolean getRateROIFlg() {
	    return _bRateROIFlag;
	}

    /**
     * Roi入力有無区分を設定する． <BR>
	 * @param bTrueRtFlg	Roi入力有無区分の文字列
     */
	public void setRateROIFlg(boolean bRoiFlg) {
	    _bRateROIFlag = bRoiFlg;
	}

    /**
     * ﾘｰｽ月数入力有無区分を取得する． <BR>
     * @return  boolean ﾘｰｽ月数入力有無区分の文字列
     */
	public boolean getLeaseMFlg() {
	    return _bLeaseMFlg;
	}

    /**
     * ﾘｰｽ月数入力有無区分を設定する． <BR>
	 * @param bLeaseMFlg	ﾘｰｽ月数入力有無区分の文字列
     */
	public void setLeaseMFlg(boolean bLeaseMFlg) {
	    _bLeaseMFlg = bLeaseMFlg;
	}

    /**
     * 貸倒引当率を取得する． <BR>
     * @return  double 貸倒引当率の文字列
     */
	public double getRtLossR() {
	    return _dRtLossR;
	}
    /**
     * 貸倒引当率を設定する． <BR>
	 * @param dRtLossR	貸倒引当率の文字列
     */
    public void setRtLossR(double dRtLossR) {
	    _dRtLossR = dRtLossR;
	}

    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getRtEAniO() {
	    return _dRtEAniO;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setRtEAniO(double dRtEAniO) {
	    _dRtEAniO = dRtEAniO;
	}

    /**
     * 管販比率(Servicing)を取得する． <BR>
     * @return  double 管販比率(Servicing)の文字列
     */
	public double getRtEAniS() {
	    return _dRtEAniS;
	}
    /**
     * 管販比率(Servicing)を設定する． <BR>
	 * @param dRtEAniS	管販比率(Servicing)の文字列
     */
	public void setRtEAniS(double dRtEAniS) {
	    _dRtEAniS = dRtEAniS;
	}

    /**
     * 管販比率(合計)を取得する． <BR>
     * @return  double 管販比率(合計)の文字列
     */
	public double getRtEAniTotal() {
	    return _dRtEAniTotal;
	}
    /**
     * 管販比率(合計)を設定する． <BR>
	 * @param dRtEAniTotal	管販比率(合計)の文字列
     */
	public void setRtEAniTotal(double dRtEAniTotal) {
	    _dRtEAniTotal = dRtEAniTotal;
	}

    /**
     * 手数料率(NPP)を取得する． <BR>
     * @return  double 手数料率(NPP)の文字列
     */
	public double getRtFeeN() {
	    return _dRtFeeN;
	}
    /**
     * 手数料率(NPP)を設定する． <BR>
	 * @param dRtFeeN	手数料率(NPP)の文字列
     */
	public void setRtFeeN(double dRtFeeN) {
	    _dRtFeeN = dRtFeeN;
	}

    /**
     * 手数料率(Release)を取得する． <BR>
     * @return  double 手数料率(Release)の文字列
     */
	public double getRtFeeR() {
	    return _dRtFeeR;
	}
    /**
     * 手数料率(Release)を設定する． <BR>
	 * @param dRtFeeR	手数料率(Release)の文字列
     */
	public void setRtFeeR(double dRtFeeR) {
	    _dRtFeeR = dRtFeeR;
	}

    /**
     * 手数料率(合計)を取得する． <BR>
     * @return  double 手数料率(合計)の文字列
     */
	public double getRtFeeTotal() {
	    return _dRtFeeTotal;
	}
    /**
     * 手数料率(合計)を設定する． <BR>
	 * @param dRtFeeTotal	手数料率(合計)の文字列
     */
	public void setRtFeeTotal(double dRtFeeTotal) {
	    _dRtFeeTotal = dRtFeeTotal;
	}

    /**
     * コスト率機種コードを取得する． <BR>
     * @return  double コスト率機種コードの文字列
     */
	public String getCstKishuCD() {
	    return _strCstKishuCD;
	}
    /**
     * コスト率機種コードを設定する． <BR>
	 * @param dRtFeeTotal	コスト率機種コードの文字列
     */
	public void setCstKishuCD(String strCstKishuCD) {
	    _strCstKishuCD = strCstKishuCD;
	}

    /**
     * コスト率選択情報を取得する． <BR>
     * @return  double コスト率選択情報の文字列
     */
	public String getCstSelInfo() {
	    return _strCstSelInfo;
	}
    /**
     * コスト率選択情報を設定する． <BR>
	 * @param dRtFeeTotal	コスト率選択情報の文字列
     */
	public void setCstSelInfo(String strCstSelInfo) {
	    _strCstSelInfo = strCstSelInfo;
	}

    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getFinanceMargin() {
	    return _dFinanceMargin;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setFinanceMargin(double dFinanceMargin) {
	    _dFinanceMargin = dFinanceMargin;
	}

    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getPvFinanceMargin() {
	    return _dPvFinanceMargin;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setPvFinanceMargin(double dPvFinanceMargin) {
	    _dPvFinanceMargin = dPvFinanceMargin;
	}

    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getRaMargin() {
	    return _dRaMargin;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setRaMargin(double dRaMargin) {
	    _dRaMargin = dRaMargin;
	}

    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getRaPvMargin() {
		//System.out.println("_dRaPvMargin===" + _dRaPvMargin);
	    return _dRaPvMargin;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setRaPvMargin(double dRaPvMargin) {
	    _dRaPvMargin = dRaPvMargin;
	}
//***********
    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getFFinanceMargin() {
	    return _dFFinanceMargin;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setFFinanceMargin(double dFFinanceMargin) {
	    _dFFinanceMargin = dFFinanceMargin;
	}

    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getFPvFinanceMargin() {
	    return _dFPvFinanceMargin;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setFPvFinanceMargin(double dFPvFinanceMargin) {
	    _dFPvFinanceMargin = dFPvFinanceMargin;
	}

    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getFRaMargin() {
	    return _dFRaMargin;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setFRaMargin(double dFRaMargin) {
	    _dFRaMargin = dFRaMargin;
	}

    /**
     * 管販比率(Origination)を取得する． <BR>
     * @return  double 管販比率(Origination)の文字列
     */
	public double getFRaPvMargin() {
	    return _dFRaPvMargin;
	}
    /**
     * 管販比率(Origination)を設定する． <BR>
	 * @param dRtEAniO	管販比率(Origination)の文字列
     */
	public void setFRaPvMargin(double dFRaPvMargin) {
	    _dFRaPvMargin = dFRaPvMargin;
	}
//	20040830 ljq add s
	/**
	 * ROE <BR>
	 * @param dROE	ROEの文字列
	 */
	public void setROE(double dROE) {
		_dROE = dROE;
	}

	/**
	 * ROE <BR>
	 * @return  double ROEの文字列
	 */
	public double getROE() {
		return _dROE;
	}

	/**
	 * FROE <BR>
	 * @param dROE	fullpay ROEの文字列
	 */
	public void setFROE(double dFROE) {
		_dFROE = dFROE;
	}

	/**
	 * FROE <BR>
	 * @return  double fullpay ROEの文字列
	 */
	public double getFROE() {
		return _dFROE;
	}

	/**
	 * Leverage <BR>
	 * @param dROE	Leverageの文字列
	 */
	public void setLeverage(int nLeverage) {
		_nLeverage = nLeverage;
	}

	/**
	 * Leverage <BR>
	 * @return  int Leverageの文字列
	 */
	public int getLeverage() {
		return _nLeverage;
	}
//	20040830 ljq add e

	//ydy add 20061011 s
	/**
	 * GE格付 <BR>
	 * @param String YuSinの文字列
	 */
	public void setYuSin(String strYuSin) {
		_strYuSin = strYuSin;
	}

	/**
	 * GE格付 <BR>
	 * @return  String YuSinの文字列
	 */
	public String getYuSin() {
		return _strYuSin;
	}
	//ydy add 20061011 e

	public void prt(int _nCalItem,int _nBaseProf,CashFl _cashFl) {
	  LfcWriteExcel writeExcel=new LfcWriteExcel();
	  writeExcel.CopytestFile("test.xls");
	  try {
		String sCalItem="";
		switch (_nCalItem) {
			case LfcLogicPgConst.CAL_ITEM_LPRO :
				sCalItem="採算項目算出";
				break;
			case LfcLogicPgConst.CAL_ITEM_KINGAKU :
				sCalItem="回収金額算出";
				break;
			case LfcLogicPgConst.CAL_ITEM_ZANKA :
				sCalItem="残価逆算";
				break;
			case LfcLogicPgConst.CAL_ITEM_KAISU :
				sCalItem="回収回数逆算";
				break;
			case LfcLogicPgConst.CAL_ITEM_PUCHARS :
				sCalItem="購入価額逆算";
				break;
			default :
				sCalItem="算出項目指定区分エラー";
				break;
		}

		String sBaseProf="";
		switch (_nBaseProf) {
			case LfcLogicPgConst.CAL_BASE_RYORTT :
				sBaseProf="合計料率";
				break;
			case LfcLogicPgConst.CAL_BASE_RYORTM :
				sBaseProf="月料率";
				break;
			case LfcLogicPgConst.CAL_BASE_RATEUN :
				sBaseProf="運用利回り";
				break;
			case LfcLogicPgConst.CAL_BASE_ROI :
				sBaseProf="ROI";
				break;
			case LfcLogicPgConst.CAL_BASE_ROE :
				sBaseProf="ROE";
				break;
			case LfcLogicPgConst.CAL_BASE_TRUERT :
				sBaseProf="TR";
				break;
			default :
				sBaseProf="指定TR逆算時基準項目エラー";
				break;
		}

		  int row=2;
		  int col=2;

		  writeExcel.setColumnWidth(col,20);
		  writeExcel.setColumnWidth(col+1,20);
		if ("採算項目算出".equals(sCalItem)){
			sBaseProf="";
		}else{
			sCalItem=sBaseProf+"⇒"+sCalItem;
		}
		writeExcel.setCellData(row,col,"計算方法","titleFormat");
		writeExcel.setCellData(row,col+1,sCalItem,"detFormat");

		  writeExcel.setCellData(++row,col,"項目","titleFormat");
		  writeExcel.setCellData(row,col+1,"Value","titleFormat");

		  writeExcel.setCellData(++row,col,"契約先名","detFormat");
		  writeExcel.setCellData(row,col+1,getUserNm(),"detFormat");

		  writeExcel.setCellData(++row,col,"契約番号","detFormat");
		  writeExcel.setCellData(row,col+1,getKeiyaku(),"detFormat");

		  writeExcel.setCellData(++row,col,"検収番号１","detFormat");
		  writeExcel.setCellData(row,col+1,getKenshu1(),"detFormat");

		  writeExcel.setCellData(++row,col,"検収番号２","detFormat");
		  writeExcel.setCellData(row,col+1,getKenshu2(),"detFormat");

		  writeExcel.setCellData(++row,col,"契約案件番号","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRecno(),"priceFormat");

		  writeExcel.setCellData(++row,col,"物件№","detFormat");
		  writeExcel.setCellData(row,col+1,""+getBukken(),"detFormat");

		  writeExcel.setCellData(++row,col,"物件№(FROM)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getBukkenF(),"detFormat");

		  writeExcel.setCellData(++row,col,"物件№(TO)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getBukkenT(),"detFormat");

		  writeExcel.setCellData(++row,col,"購入価額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getPurchas(),"priceFormat");

		  writeExcel.setCellData(++row,col,"残価","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRemVAL(),"priceFormat");

		  writeExcel.setCellData(++row,col,"残価率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRemVRT()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"定率残価ｲﾝﾃﾞｯｸｽ","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFremIX(),"detFormat");

		  writeExcel.setCellData(++row,col,"支払利息","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInterP(),"priceFormat");

		  writeExcel.setCellData(++row,col,"固定資産税","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFatax(),"priceFormat");

		  writeExcel.setCellData(++row,col,"保険料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInsur(),"priceFormat");

		  writeExcel.setCellData(++row,col,"その他の雑費","detFormat");
		  writeExcel.setCellData(row,col+1,""+getZappi(),"priceFormat");

		  writeExcel.setCellData(++row,col,"割賦保険料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getKappuI(),"priceFormat");

		  writeExcel.setCellData(++row,col,"その他一時費用(ｲ)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getIchiji1(),"priceFormat");

		  writeExcel.setCellData(++row,col,"その他一時費用(ﾛ)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getIchiji2(),"priceFormat");

		  writeExcel.setCellData(++row,col,"その他一時費用(ﾊ)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getIchiji3(),"priceFormat");

		  writeExcel.setCellData(++row,col,"その他繰延費用(ﾍ)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getKurino1(),"priceFormat");

		  writeExcel.setCellData(++row,col,"その他繰延費用(ﾄ)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getKurino2(),"priceFormat");

		  writeExcel.setCellData(++row,col,"保守料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getHoshury(),"priceFormat");

		  writeExcel.setCellData(++row,col,"斡旋手数料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getAssen(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾘｰｽ/割賦原価計","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCostT(),"priceFormat");

		  writeExcel.setCellData(++row,col,"当社手数料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCharge(),"priceFormat");

		  writeExcel.setCellData(++row,col,"契約額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getIncGt(),"priceFormat");

		  writeExcel.setCellData(++row,col,"前受ﾘｰｽ料/頭金","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInc0(),"priceFormat");

		  writeExcel.setCellData(++row,col,"前受ﾘｰｽ月数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInc0M(),"detFormat");

		  writeExcel.setCellData(++row,col,"原価調整額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCAdj(),"priceFormat");

		  writeExcel.setCellData(++row,col,"荒利益額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getProfT(),"priceFormat");

		  writeExcel.setCellData(++row,col,"年荒利益額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getProfY(),"priceFormat");

		  writeExcel.setCellData(++row,col,"使用総資金","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCapitT(),"priceFormat");

		  writeExcel.setCellData(++row,col,"総荒利率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtPrT()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"年荒利率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtPrY()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"年利回り","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRateYr()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"社内金利 ","detFormat");
		  if (getCriF()>0){
			writeExcel.setCellData(row,col+1,""+(getRateJL()*100+getRtLossR()*100-Math.ceil(getRtLossR()*10000/2)/100),"rateFormat");
		  }else{
			writeExcel.setCellData(row,col+1,""+getRateJL()*100,"rateFormat");
		  }

		  writeExcel.setCellData(++row,col,"運用利回り","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRateUN()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"ＴＲ","detFormat");
		  writeExcel.setCellData(row,col+1,""+getTrueRT()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"原調計算金利","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRateCADJ()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"ＲＯＩ","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRateROI()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"検収予定日","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDKensh(),"detFormat");

		  writeExcel.setCellData(++row,col,"支払予定日","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDPaymt(),"detFormat");

		  writeExcel.setCellData(++row,col,"原価調整月数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getAdjM(),"detFormat");

		  writeExcel.setCellData(++row,col,"原価調整日数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getAdjD(),"detFormat");

		  writeExcel.setCellData(++row,col,"ﾘｰｽ料/割賦金総額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getIncT(),"priceFormat");

		  writeExcel.setCellData(++row,col,"初期費用","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInitC(),"priceFormat");

		  writeExcel.setCellData(++row,col,"実行費用総額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getExecC(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ＮＥＴ率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getNetRt(),"detFormat");

		  writeExcel.setCellData(++row,col,"回収利息","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInterI(),"priceFormat");

		  writeExcel.setCellData(++row,col,"動総保険料率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDosoRt(),"detFormat");

		  writeExcel.setCellData(++row,col,"ｿﾌﾄｳｪｱ区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getSwSoft(),"detFormat");

		  writeExcel.setCellData(++row,col,"賠責保険付保区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getSwBais(),"detFormat");

		  writeExcel.setCellData(++row,col,"少額資産区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getSwSPro(),"detFormat");

		  writeExcel.setCellData(++row,col,"分割支払有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getSwPay(),"detFormat");

		  writeExcel.setCellData(++row,col,"動総保険金額指数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDosoIx(),"detFormat");

		  writeExcel.setCellData(++row,col,"動総保険料","detFormat");
		  writeExcel.setCellData(row,col+1,""+ getDosoF(),"priceFormat");

		  writeExcel.setCellData(++row,col,"機械保険料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getMachiF(),"priceFormat");

		  writeExcel.setCellData(++row,col,"火災保険料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFireF(),"priceFormat");

		  writeExcel.setCellData(++row,col,"船舶・ソノタ保険料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getEtcF(),"priceFormat");

		  writeExcel.setCellData(++row,col,"団信保険料率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDansRt(),"detFormat");

		  writeExcel.setCellData(++row,col,"エコリース区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getSwCri(),"detFormat");

		  writeExcel.setCellData(++row,col,"低炭素リース付保期間","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCriTm(),"detFormat");

		  writeExcel.setCellData(++row,col,"低炭素リース保険料率 ","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCriRt(),"detFormat");

		  writeExcel.setCellData(++row,col,"低炭素リース保険料 ","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCriF(),"priceFormat");

		  writeExcel.setCellData(++row,col,"割賦信保機種コ－ド","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCriCd(),"detFormat");

		  writeExcel.setCellData(++row,col,"ﾘｰｽ月数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getLeaseM(),"priceFormat");

		  writeExcel.setCellData(++row,col,"据置月数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getLeaveM(),"priceFormat");

		  writeExcel.setCellData(++row,col,"割賦月数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getKappuM(),"priceFormat");

		  writeExcel.setCellData(++row,col,"法定耐用年数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDuraY(),"priceFormat");

		  writeExcel.setCellData(++row,col,"物件数量","detFormat");
		  writeExcel.setCellData(row,col+1,""+getQuant(),"priceFormat");

		  writeExcel.setCellData(++row,col,"前受ﾘｰｽ料回収日","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDInc0(),"detFormat");
		  writeExcel.setCellData(++row,col,"合計料率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRyortT()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"月料率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRyortM()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"ﾘｰｽ段数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getLeaseD(),"detFormat");

		  writeExcel.setCellData(++row,col,"割賦段数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getKappuD(),"detFormat");

		  writeExcel.setCellData(++row,col,"賠責保険料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getBaisF(),"priceFormat");

		  writeExcel.setCellData(++row,col,"均等回収区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getEvenFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"最終回収予定日","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFidtIn(),"detFormat");

		  writeExcel.setCellData(++row,col,"分割回数（回収）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDivfreq(),"detFormat");

		  writeExcel.setCellData(++row,col,"規定損害金基本額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDamBas(),"priceFormat");

		  writeExcel.setCellData(++row,col,"規定損害金前半逓減月数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDamFm(),"priceFormat");

		  writeExcel.setCellData(++row,col,"規定損害金後半逓減月数","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDamLm(),"priceFormat");

		  writeExcel.setCellData(++row,col,"規定損害金前半逓減月額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDamFa(),"priceFormat");

		  writeExcel.setCellData(++row,col,"規定損害金後半逓減月額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDamLa(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ支払利息","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFIntP(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ回収利息","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFIntI(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ当社手数料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFCharge(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ実行費用総額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFExecC(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ繰延費用(ﾍ)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFKuri1(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ保険料","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFInsur(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲﾘｰｽ原価計","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFCostT(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ荒利益額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFProT(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ年荒利益額","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFProY(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ使用総資金","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFCapT(),"priceFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲＴＲ","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFTrueRT()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ年利回り","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFRtYr()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ運用利回り","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFRtUn()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ総荒利率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFRtPrt()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲ年荒利率","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFRtPry()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"ﾌﾙﾍﾟｲＲＯＩ","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFRtRoi()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"貸倒引当率","detFormat");
		  if (getCriF()>0){
			writeExcel.setCellData(row,col+1,""+(Math.ceil(getRtLossR()*10000/2)/100),"rateFormat");
		  }else{
			writeExcel.setCellData(row,col+1,""+getRtLossR()*100,"rateFormat");
		  }

		  writeExcel.setCellData(++row,col,"管販比率(Origination)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtEAniO()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"管販比率(Servicing)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtEAniS()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"管販比率(合計)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtEAniTotal()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"手数料率(NPP)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtFeeN()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"手数料率(Release)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtFeeR()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"手数料率(合計)","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtFeeTotal()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"*コスト率機種コード","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCstKishuCD(),"detFormat");

		  writeExcel.setCellData(++row,col,"*コスト率選択情報","detFormat");
		  writeExcel.setCellData(row,col+1,""+getCstSelInfo(),"detFormat");

		  writeExcel.setCellData(++row,col,"FinanceMargin","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFinanceMargin()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"PvFinanceMargin","detFormat");
		  writeExcel.setCellData(row,col+1,""+getPvFinanceMargin(),"priceFormat");

		  writeExcel.setCellData(++row,col,"RaMargin","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRaMargin()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"RaPvMargin","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRaPvMargin(),"priceFormat");

		  writeExcel.setCellData(++row,col,"FinanceMargin","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFFinanceMargin()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"PvFinanceMargin","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFPvFinanceMargin(),"priceFormat");

		  writeExcel.setCellData(++row,col,"RaMargin","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFRaMargin()*100,"rateFormat");

		  writeExcel.setCellData(++row,col,"RaPvMargin","detFormat");
		  writeExcel.setCellData(row,col+1,""+getFRaPvMargin(),"priceFormat");

		  writeExcel.setCellData(++row,col,"検収予定日（年）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate1YY(),"detFormat");

		  writeExcel.setCellData(++row,col,"検収予定日（月）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate1MM(),"detFormat");

		  writeExcel.setCellData(++row,col,"検収予定日（日）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate1DD(),"detFormat");

		  writeExcel.setCellData(++row,col,"支払予定日（年）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate2YY(),"detFormat");

		  writeExcel.setCellData(++row,col,"支払予定日（月）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate2MM(),"detFormat");

		  writeExcel.setCellData(++row,col,"支払予定日（日）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate2DD(),"detFormat");

		  writeExcel.setCellData(++row,col,"前受ﾘｰｽ料回収日（年）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate3YY(),"detFormat");

		  writeExcel.setCellData(++row,col,"前受ﾘｰｽ料回収日（月","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate3MM(),"detFormat");

		  writeExcel.setCellData(++row,col,"前受ﾘｰｽ料回収日（日）","detFormat");
		  writeExcel.setCellData(row,col+1,""+getDate3DD(),"detFormat");

		  writeExcel.setCellData(++row,col,"ﾘｰｽ料回収日日付指定区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInddFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"購入価額入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getPurchasFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"残価入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRemValFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"残価率入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRemVRtFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"前受/頭金入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInc0Flg(),"detFormat");

		  writeExcel.setCellData(++row,col,"前受ﾘｰｽ月数入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getInc0MFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"合計料率入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRyortTFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"月料率入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRyortMFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"総荒利率入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtPrTFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"年荒利率入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRtPrYFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"年利回り入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRateYrFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"運用利回り入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRateUnFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"ＴＲ入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getTrueRtFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"ﾘｰｽ月数入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getLeaseMFlg(),"detFormat");

		  writeExcel.setCellData(++row,col,"Roi入力有無区分","detFormat");
		  writeExcel.setCellData(row,col+1,""+getRateROIFlg(),"detFormat");

		  int _nCashCnt = _cashFl.getCashCnt();
		  for (int i = 0; i < _nCashCnt-1; i++) {
		      writeExcel.setCellData(++row,col,"第"+(i+1)+"回目の回収","detFormat");
		      //writeExcel.setCellData(row,col+1,""+_cashFl.getCashFlow(i),"priceFormat");
  			  writeExcel.setCellData(row,col+1,""+_cashFl.getIncome(i),"priceFormat");
		 }
	  }
	  catch (Exception e) {
		  e.printStackTrace();
	  }
	  writeExcel.ColseExcel();
  }
	//ydy add 20070410 s
	/**
	 * ROIの税率 <BR>
	 * @return String ROIの文字列
	 */
	public String getROITax() {
		return _strROITax;
	}
	/**
	 * ROIの税率 <BR>
	 * @param String ROIの文字列
	 */
	public void setROITax(String tax) {
		_strROITax = tax;
	}
	//ydy add 20070410 e
}
