/*
 * ファイル名：LfcConst.java
 *
 * 修正履歴  ：
 *             ver1.0.0     2003/03/27      王嵩
 *                          作成
 *             Copyright (c) 2003
 */
package com.gecl.leaseCal.logic.comm;

/**
 *
 * クラス名：Lfcシステムのロジックチェックえらメッセージクラス.
 *
 */
public interface LfcLogicMsgConst {

    public final static String ERR001 = "検収予定日が 暦の上で存在しない日付です。";
    public final static String ERR002 = "支払予定日が 暦の上で存在しない日付です。";
    public final static String ERR003 = "検収予定日と支払予定日の関係が正しくありません。";
    public final static String ERR004 = "分割支払に関するデータが 入力されていません。";
    //ydy modify 20090417 s
//  public final static String ERR005 = "社内コスト率が 入力されていません。";
    public final static String ERR005 = "「社内コスト率」０は計算できません。";
    //ydy modify 20090417 e
    public final static String ERR006 = "ＣＯＦが 入力されていません。";
    public final static String ERR007 = "分割支払時は 購入価額を求めることはできません。";
    public final static String ERR008 = "購入価額は1,000円以上､500億円以下で指定して下さい。500億円を超える場合は､桁あふれの為入力できません。";
    public final static String ERR009 = "残価率範囲エラー。";
    public final static String ERR010 = "残価範囲エラー。";
    public final static String ERR011 = "残価が 購入価額を越えています。";
    public final static String ERR012 = "回収回数の算出以外の場合は、リース月数に値を設定して下さい。";
    public final static String ERR013 = "リース月数が１ｶ月の時は、採算の計算のみ可能です。";
    public final static String ERR014 = "リース月数が360を超えています。";
    public final static String ERR015 = "法定耐用年数範囲エラー「1-99」。";
    public final static String ERR016 = "複数段でのリース月数以外の逆算には、前受リース料の金額指定が必要です。";
    public final static String ERR017 = "前受リース料の月数範囲エラー。";
    public final static String ERR018 = "前受リース料回収日の指定は不要です。";
    public final static String ERR019 = "前受リース料回収日を指定して下さい。";
    public final static String ERR020 = "前受リース料回収日が暦の上で存在しない日付です。";
    public final static String ERR021 = "前受リース料回収日と検収予定日の関係が正しくありません。";
    public final static String ERR022 = "前受リース料回収日と回収予定日の関係が正しくありません。";
    public final static String ERR023 = "前受リース料が購入価額を超えています。";
    public final static String ERR024 = "頭金が購入価額を超えています。";
    public final static String ERR025 = "回収金に関するデータが 入力されていません。";
    public final static String ERR026 = "段回収金を入力して下さい。";
    public final static String ERR027 = "回収金額を複数求める事が出来ません。";
    public final static String ERR028 = "求めたい回収金を0にして下さい。";
    public final static String ERR029 = "段回収予定日を入力して下さい。";
    public final static String ERR030 = "段回収予定日が暦の上で存在しない日付です。";
    public final static String ERR031 = "第１回目の回収予定日と検収予定日の関係が正しくありません。";
    public final static String ERR032 = "段回収月が重なっています。";
    public final static String ERR033 = "段回収サイクルを入力して下さい。";
    public final static String ERR034 = "段回収サイクルが360回を超えています。";
    public final static String ERR035 = "段回収回数を入力して下さい。";
    public final static String ERR036 = "段回収回数が360回を超えています。";
    public final static String ERR037 = "最終段以外の回数を求める事が出来ません。";
    public final static String ERR038 = "回数を複数求める事が出来ません。";
    public final static String ERR039 = "最終回収段数の回収回数を求めます。";
//    public final static String ERR039 = "求めたい回収回数を0にしてください。";
    public final static String ERR040 = "「合計料率」範囲エラー(100より大きく999未満を入力)。";
    public final static String ERR041 = "「月料率」範囲エラー(0以上999未満を入力)。";
    public final static String ERR042 = "「運用利回」範囲エラー(-99.99 ～ 99.99 を入力)。";
    public final static String ERR043 = "「ＲＯＩ」範囲エラー(-99.99 ～ 99.99 を入力)。";
    public final static String ERR044 = "「ＴＲ」範囲エラー(-99.99 ～ 99.99 を入力)。";
    public final static String ERR045 = "「貸倒引当率」範囲エラー。";
    public final static String ERR046 = "「管販比率(合計)」範囲エラー(0以上20未満を入力)。";
    public final static String ERR047 = "「管販比率(Origination)」範囲エラー。";
    public final static String ERR048 = "「管販比率(Servicing)」範囲エラー。";
    public final static String ERR049 = "「手数料収益(合計)」範囲エラー(0以上20未満を入力)。";
    public final static String ERR050 = "「手数料率(NPP)」範囲エラー。";
    public final static String ERR051 = "「手数料率(Release)」範囲エラー 。";
    public final static String ERR052 = "「社内コスト率」範囲エラー(0以上20未満を入力)。";
    public final static String ERR053 = "「ＣＯＦ」範囲エラー(0以上20未満を入力)。";
    public final static String ERR054 = "「動産総合保険料率」範囲エラー(0以上99以下を入力)。";
    public final static String ERR055 = "「団体信用生命保険料率」範囲エラー(0以上99以下を入力)。";
    public final static String ERR056 = "「火災保険料」範囲エラー （1000万円未満を入力）。";
    public final static String ERR057 = "「船舶･その他保険料」範囲エラー （1000万円未満を入力）。";
    public final static String ERR058 = "「公正証書費用」範囲エラー 。";
    public final static String ERR059 = "「一時費用」範囲エラー。";
    public final static String ERR060 = "「繰延費用」範囲エラー。";
    public final static String ERR061 = "「契約額込保守料」範囲エラー。";
    public final static String ERR062 = "「斡旋手数料」範囲エラー。";
    public final static String ERR063 = "契約?の３桁目(契約形態記号)が不適切です。";
    public final static String ERR064 = "物件?の指定がありません(必須項目です)。";
    public final static String ERR065 = "物件?の指定順序に誤りがあります。";
//ljq
    public final static String ERR066 = "回収金が０以下になる為、計算不能です。";
    public final static String ERR067 = "回収金が大きくなりすぎる為、計算不能です。";
    public final static String ERR068 = "値が収束せず、計算不能です。";
    public final static String ERR069 = "第";
    public final static String ERR070 = "契約Noは正しくありませんでした。";
//ljq
    public final static String ERR071 = "購入価額が１,０００円未満になる為、計算不能です。";
    public final static String ERR072 = "購入価額が大きくなりすぎる為、計算不能です。";
    public final static String ERR073 = "リース月数が３６０か月を越える為、計算不能です。";
    public final static String ERR074 = "残価がマイナス値になる為、計算不能です。";
    public final static String ERR075 = "残価が大きくなりすぎる為、計算不能です。";
    public final static String ERR076 = "パラメータエラー：　算出項目指定区分エラー。";
    public final static String ERR077 = "パラメータエラー：　逆算時基準項目エラー。";
    public final static String ERR078 = "購入価額に対して回収金額が少な過ぎます。";
    public final static String WRN001 = "リース信用保険の適用を取りやめました。";
    public final static String WRN002 = "リース信用保険を適用しました。";
    public final static String WRN003 = "指定された採算項目を調整しました。";
    public final static String WRN004 = "リース信用保険の適用を取りやめ、指定された採算項目を調整しました。";
    public final static String WRN005 = "リース信用保険を適用し、指定された採算項目を調整しました。";
    public final static String WRN006 = "運用利回とFinance Margin額がマイナスです登録してもよろしいです。";
    public final static String WRN007 = "運用利回がマイナスです登録してもよろしいです。";
    public final static String WRN008 = "Finance Margin額がマイナスです登録してもよろしいです。";

//PZK  2004.08.12 START
//  public final static String ERR084 = "リース月数と回収月数が合いません。再確認してください。";
//	PZK  2004.11.08 START
//    public final static String ERR084 = "リース月数と総回収月数が合っていませんが要求された計算が行われました。問題なければ登録して下さい。";
    public final static String ERR084 = "回収期日がリース期間を超えています。問題がなければ登録して下さい。";
//	PZK  2004.11.08 START
//PZK  2004.08.12 END
    public final static String ERR085 = "ＴＲが算出不能です。計算条件を確認して下さい。";
    public final static String ERR086 = "回収期間が長すぎます。（４００か月を越えています。）";
    public final static String ERR087 = "DOSOINSTの年数が取得できません。";
    public final static String ERR088 = "購入価額か回収金のどちらかに値を設定して下さい。";
    public final static String ERR089 = "購入価額か回数のどちらかに値を設定して下さい。";
    public final static String ERR090 = "残価か回収金のどちらかに値を設定して下さい。";
    public final static String ERR091 = "残価か回数のどちらかに値を設定して下さい。";
    public final static String ERR092 = "リ－ス月数か回収金のどちらかに値を設定して下さい。";
    public final static String ERR093 = "回収金か回数のどちらかに値を設定して下さい。";
    public final static String ERR094 = "回収金か料率／採算項目のどちらかに値を設定して下さい。";
    public final static String ERR095 = "回収金か採算項目のどちらかに値を設定して下さい。";
    public final static String ERR096 = "回数か採算項目のどちらかに値を設定して下さい。";
    public final static String ERR097 = "最終段の回数を求める場合は、リース月数を空白にして下さい。";
//割賦
    public final static String ERR098 = "頭金が購入価額を超えています。";
    public final static String ERR099 = "頭金の回収予定日＝第一回目の回収予定日はエラー。";
    public final static String ERR100 = "割賦金か購入価額のどちらかに値を設定して下さい。";
    public final static String ERR101 = "割賦金か回数のどちらかに値を設定して下さい。";
    public final static String ERR102 = "割賦金か採算項目のどちらかに値を設定して下さい。";
    public final static String ERR103 = "頭金か購入価額のどちらかに値を設定して下さい。";
    public final static String ERR104 = "頭金か回数のどちらかに値を設定して下さい。";
    public final static String ERR105 = "頭金か採算項目のどちらかに値を設定して下さい。";
    public final static String ERR106 = "回数か購入価額のどちらかに値を設定して下さい。";
    public final static String ERR107 = "回数か採算項目のどちらかに値を設定して下さい。";
    public final static String ERR108 = "購入価額か採算項目のどちらかに値を設定して下さい。";
    public final static String ERR109 = "割賦月数が１ｶ月の時は、採算の計算のみ可能です。";
    public final static String ERR110 = "頭金と途中段の割賦金は、同時に求めることはできません。";
    public final static String WRN009 = "割賦信用保険の適用を取りやめました。";
    public final static String WRN010 = "割賦信用保険を適用しました。";
    public final static String WRN011 = "割賦信保の適用を取りやめ、指定された採算項目を調整しました。";
    public final static String WRN012 = "割賦信保を適用し、指定された採算項目を調整しました。";
    public final static String ERR115 = "割賦月数が３６０か月を越える為、計算不能です。";
    public final static String ERR116 = "頭金及び割賦金が０以下になる為、計算不能です。";
    public final static String ERR117 = "割賦金が０以下になる為、計算不能です。";
    public final static String ERR118 = "頭金及び割賦金が大きくなりすぎる為、計算不能です。";
    public final static String ERR119 = "割賦金が大きくなりすぎる為、計算不能です。";
    public final static String ERR120 = "前受リース料／頭金が大きいため採算項目は99.99で表示します。\nその他の計算は正しく行われました。問題がなければ登録して下さい。";
    public final static String ERR121 = "運用利回がマイナスです。よろしければ登録ボタンを押してください。";
    public final static String ERR122 = "RA PV Margin額がマイナスです。よろしければ登録ボタンを押してください。";
    public final static String ERR123 = "運用利回とRA PV Margin額がマイナスです。よろしければ登録ボタンを押してください。";
//20040924 ljq add s
    public final static String ERR124 = "頭金がマイナス値になる為、計算不能です。";
    public final static String ERR125 = "頭金が大きくなりすぎる為、計算不能です。";
	public final static String ERR126 = "契約単位の運用利回りが15%を超えています。Pricingにご相談下さい。";
//20040924 ljq add e
    public final static String ERR127 = "信保対象物件は契約期間３年以上１０年以下です。";
    public final static String ERR128 = "信保対象物件は１年の回収回数が４回以上です。";
    public final static String ERR129 = "信保対象物件は契約額3MM以上50MM以下です。";
}
