/*
 * @(#)LsComm.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.comm;

import java.util.ArrayList;
import java.util.Iterator;
import jp.gecapital.schema.ei.pricing.pricecalculate.BukenOutputComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputRecord;


public class LfcLogicComm {
    static int _nMonDays[] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
    static int _nAdjYear;
    static int _nAdjMonth;
    static int _nAdjDay;
    private static ErrorInforOutputRecord _outErrorMsgRecord = null;


    public static double dround(double x, int y) {
        if(x < 0 ) {
            return (Math.ceil((x) * Math.pow(10.0,(double)(y)) - 0.5) / Math.pow(10.0,(double)(y)));
        } else {
            return (Math.floor((x) * Math.pow(10.0,(double)(y)) + 0.5) / Math.pow(10.0,(double)(y)));
        }
    }

    public static double drounddown(double x, int y) {
        if(x < 0 ) {
            return (Math.ceil((x) * Math.pow(10.0,(double)(y))) / Math.pow(10.0,(double)(y)));
        } else {
            return (Math.floor((x) * Math.pow(10.0,(double)(y))) / Math.pow(10.0,(double)(y)));
        }
    }

    public static int db3Year(long date) {
        return ((int)(date / 10000));
    }
    public static int db3Month(long date) {
        return ((int)((date / 100) % 100));
    }
    public static int db3Day(long date) {
        return ((int)(date % 100));
    }

    public static long db3Itod(int yy, int mm, int dd) {
        _nAdjYear = yy;
        _nAdjMonth = mm;
        _nAdjDay = dd;
        if(yy < 100) {
            yy += 1900;
        }
        //日付調整
        dtAdjust();

        //変換後日付を返却
        return (_nAdjYear * 10000 + _nAdjMonth * 100 + _nAdjDay);
    }

    private static void dtAdjust() {
        if (_nAdjMonth > 12) {                  /* 月の変換                     */
            _nAdjYear += (_nAdjMonth - 1) / 12;
            _nAdjMonth = (_nAdjMonth - 1) %12 + 1;
        }
        if (_nAdjMonth < 1) {
            _nAdjYear += _nAdjMonth / 12 - 1;
            _nAdjMonth = _nAdjMonth % 12 + 12;
        }

        dtLeap(_nAdjYear);                     /* 日の変換                     */
        while (_nAdjDay > _nMonDays[_nAdjMonth - 1]) {
            _nAdjDay   -= _nMonDays[_nAdjMonth - 1];
            _nAdjMonth += 1;
            if (_nAdjMonth > 12) {
                _nAdjMonth = 1;
                _nAdjYear += 1;
                dtLeap(_nAdjYear);
            }
        }
        while (_nAdjDay < 1) {
            _nAdjMonth -= 1;
            if (_nAdjMonth < 1) {
                _nAdjMonth = 12;
                _nAdjYear -= 1;
                dtLeap(_nAdjYear);
            }
            _nAdjDay += _nMonDays[_nAdjMonth - 1];
        }
    }

    private static void dtLeap(int year) {

        // 4で割切れない年は閏年ではない
        // 100で割切れる年は閏年ではない
        // でも400で割切れると閏年
        if ((year%4 != 0) || ((year%100 == 0) && (year%400 != 0))) {
            _nMonDays[1] = 28;
            return;
        }
        _nMonDays[1] = 29;
    }

    public static int dtLast(int year, int month) {
        _nAdjYear = year;
        _nAdjMonth = month;
        _nAdjDay = 1;
        dtAdjust();
        //該当年月の日を返却
        return (_nMonDays[_nAdjMonth - 1]);
    }
  public static int getStatus(String strX)
  {
    int nStatus =1;
    if (strX==null||"".equals(strX)){
        nStatus=0;
    }
    return nStatus;
  }
    public static double doDecCut(double x, int y) {
        return ((long)((x) * Math.pow(10.0,(double)(y))) / Math.pow(10.0,(double)(y)));
    }
    /**
     *
     * @param errMsg
     */
    public static ErrorInforOutputRecord setErrorMsgList(ArrayList<ErrorInforOutputComplexType> errMsg,ErrorInforOutputRecord _outErrorMsgRecord) {
        if (_outErrorMsgRecord == null) {
            _outErrorMsgRecord = new ErrorInforOutputRecord();
        }
        Iterator<ErrorInforOutputComplexType> iterator = errMsg.iterator();
        while (iterator.hasNext()) {
            ErrorInforOutputComplexType tempErrorOutputObject = new ErrorInforOutputComplexType();
            tempErrorOutputObject = iterator.next();
            _outErrorMsgRecord.getErrorInforOutput().add(tempErrorOutputObject);
        }
        return _outErrorMsgRecord;
    }

    public static ErrorInforOutputRecord setErrMsgRecord(BukenOutputComplexType OutBukenTmp, String strErrNo, String strErrMsg,ErrorInforOutputRecord _outErrorMsgRecord) {
        if (_outErrorMsgRecord == null) {
            _outErrorMsgRecord = new ErrorInforOutputRecord();
        }
        ErrorInforOutputComplexType outErrCom = new ErrorInforOutputComplexType();
        outErrCom.setERRORNO(strErrNo);
        outErrCom.setERRORMSG(strErrMsg);
        _outErrorMsgRecord.getErrorInforOutput().add(outErrCom);
        OutBukenTmp.setErrorRecord(_outErrorMsgRecord);
        return _outErrorMsgRecord;
    }

    /**
     *
     * @param strMessage
     * @param strTitle
     * @param errMsglist
     * @return
     */
    public  static ArrayList<ErrorInforOutputComplexType> addErrMsgList(
            String strMessage,
            String strTitle,
            ArrayList<ErrorInforOutputComplexType> errMsglist) {
        ArrayList<ErrorInforOutputComplexType> errMsglistOout = null;
        if (errMsglist.isEmpty()) {
            errMsglistOout = new ArrayList<ErrorInforOutputComplexType>();
        } else {
            errMsglistOout = errMsglist;
        }

        if (strMessage == null || "".equals(strMessage)) {
        } else {
            ErrorInforOutputComplexType errMsg = new ErrorInforOutputComplexType();
            errMsg.setERRORNO(strTitle);
            errMsg.setERRORMSG(strMessage);
            errMsglistOout.add(errMsg);
        }

        return errMsglistOout;
    }

    /**
     *
     * @param strMessage
     * @param strTitle
     * @param strField
     * @param errMsglist
     * @return
     */
    public  static ArrayList<ErrorInforOutputComplexType> addErrMsgList(
            String strMessage,
            String strTitle,
            String strField,
            ArrayList<ErrorInforOutputComplexType> errMsglist) {
        ArrayList<ErrorInforOutputComplexType> errMsglistOout = null;
        if (errMsglist.isEmpty()) {
            errMsglistOout = new ArrayList<ErrorInforOutputComplexType>();
        } else {
            errMsglistOout = errMsglist;
        }

        if (strMessage == null || "".equals(strMessage)) {
        } else {
            ErrorInforOutputComplexType errMsg = new ErrorInforOutputComplexType();
            errMsg.setERRORNO(strTitle);
            if ("".equals(strField)) {
                errMsg.setERRORMSG(strMessage);
            } else {
                errMsg.setERRORMSG("[" + strField + "]" + strMessage);
            }
            errMsglistOout.add(errMsg);
        }

        return errMsglistOout;
    }


}
