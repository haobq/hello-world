/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gecl.leaseCal.logic.comm;

import com.gecl.leaseCal.db.comm.LfcDBConst;
import com.gecl.leaseCal.db.comm.LfcDBMsgConst;
import com.gecl.leaseCal.db.comm.LfcFrmBeanConst;
import com.gecl.leaseCal.db.comm.ObjectBean;
import com.gecl.leaseCal.db.comm.PaydivBean;
import com.gecl.leaseCal.db.comm.StairsBean;
import com.gecl.leaseCal.log.LfcFrmMsgConst;
import com.gecl.leaseCal.log.LfcSystemLog;
import com.gecl.leaseCal.logic.cal.kappu.KpCalMain;
import com.gecl.leaseCal.logic.cal.lease.LsCalMain;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import jp.gecapital.schema.ei.pricing.pricecalculate.BukenInputComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.BukenOutputComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.BukenOutputResType;
import jp.gecapital.schema.ei.pricing.pricecalculate.CollectionComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.CollectionInOutRecord;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputRecord;
import jp.gecapital.schema.ei.pricing.pricecalculate.ObjectInputComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.ObjectOutputComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.PaydivComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.PaydivInOutRecord;

/**
 *
 * @author 500501825
 */
public class WebServiceIFBean implements LfcDBConst, LfcFrmBeanConst, LfcFrmMsgConst {

    private ObjectBean objectBean=new ObjectBean();
    /** Gcalのオブジェクト*(通用クラス) */
    private Gcal _gcal;
    /** Paydiv のオブジェクト(通用クラス) */
    private Paydiv _paydiv = new Paydiv();
    private PaydivBean _paydivBean =new PaydivBean();
    /** Stairs のオブジェクト(通用クラス) */
    private Stairs _stairs = new Stairs();
    private StairsBean _stairsBean =new StairsBean();
    /** 算出項目指定の整型変数を初期化する */
    private int nCalItemDefine;
    /** 逆算時基準項目の整型変数を初期化する */
    private int nConBaseItem;
    /** 定率残価ｲﾝﾃﾞｯｸｽ を初期化する*/
    //private int _nFixIndex = -1;
    //計算結果のエラーメッセージ
    //private String[][] strCalMsgResults = null;
    private ErrorInforOutputRecord _outErrorMsgRecord = null;
    private int _nReqItem = 0;
    private int _nBaseItem;

    public WebServiceIFBean() {
        _outErrorMsgRecord = new ErrorInforOutputRecord();
    }

    public ErrorInforOutputRecord getErrorMsgRecord() {
        return _outErrorMsgRecord;
    }

      public void setErrorMsgRecord(ErrorInforOutputRecord errorInforOutputRecord) {
        _outErrorMsgRecord=errorInforOutputRecord;
    }

    public void cearErrorMsgList() {
        _outErrorMsgRecord = null;
    }

    /**
     * INPUTパラメータからOUTPUTパラメータに渡す
     * @param inputPrice
     * @return　BukenOutputRecode
     * @throws Exception
     */
    //public BukenOutputResType setWebServiceIFBean(BukenInputReqType inputPrice) throws Exception {
    public BukenOutputResType setWebServiceIFBean(List<BukenInputComplexType> listBuken) throws Exception {
        BukenOutputResType bukenOutputRecode = new BukenOutputResType();
        //BukenInputReqType BukenInputRecord = new BukenInputReqType();
        //BukenInputRecord = inputPrice;
        int index_input = 0;
        //List<BukenInputComplexType> listBuken = BukenInputRecord.getBukenInput();
        for (index_input = 0; index_input < listBuken.size(); index_input++) {
            BukenInputComplexType bInputType = listBuken.get(index_input);
            ObjectInputComplexType inObjectTmp = bInputType.getBukenRecord();

            ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
            BukenOutputComplexType bOutBukenTmp = new BukenOutputComplexType();
            //物件の項目を設定
            outObjectTmp.setRECORDNO(LfcFrmComm.lostNull("" + (index_input + 1)));//
            outObjectTmp.setLSKP(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getLSKP()).toUpperCase()));//リース割賦区分
            outObjectTmp.setBUKKENFR(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getBUKKENFR())));//物件番号(from)
            outObjectTmp.setBUKKENTO(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getBUKKENTO())));//物件番号(to)
            //物件Formから物件TOに設定
            if ("".equals(LfcFrmComm.lostNull(outObjectTmp.getBUKKENTO()))) {
                outObjectTmp.setBUKKENTO(LfcFrmComm.lostNull(outObjectTmp.getBUKKENFR()));
            } else {
                if (!LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getBUKKENFR()), LfcFrmBeanConst.NUM) &&
                        !LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getBUKKENTO()), LfcFrmBeanConst.NUM)) {
                    int intBukenFrom = LfcFrmComm.toInt(outObjectTmp.getBUKKENFR());
                    int intBukenTo = LfcFrmComm.toInt(outObjectTmp.getBUKKENTO());
                    if (intBukenTo < intBukenFrom) {
                        outObjectTmp.setBUKKENTO(LfcFrmComm.lostNull(outObjectTmp.getBUKKENFR()));
                    }
                }
            }
            outObjectTmp.setBUKKENNAME(LfcFrmComm.lostNull(inObjectTmp.getBUKKENNAME()));//物件名称
            outObjectTmp.setBUKKENTYPE(LfcFrmComm.lostNull(inObjectTmp.getBUKKENTYPE()));//物件種類
            outObjectTmp.setCALCULATEBASE(LfcFrmComm.lostNull(inObjectTmp.getCALCULATEBASE()));//算出項目指定
            outObjectTmp.setCALCULATETYPE(LfcFrmComm.lostNull(inObjectTmp.getCALCULATETYPE()));//逆算時基準項目
            outObjectTmp.setBUKKENNO(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getBUKKENNO())));//物件番号
            outObjectTmp.setDATEKENSH(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getDATEKENSH())));//検収予定日
            outObjectTmp.setPURCHASE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getPURCHASE())));//購入価格
            outObjectTmp.setQUANTITY(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getQUANTITY())));//物件数量
            outObjectTmp.setDATEPAYMT(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getDATEPAYMT())));//支払予定日
            outObjectTmp.setREMAINVAL(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getREMAINVAL())));//残価
            outObjectTmp.setREMVALRT(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getREMVALRT())));//残価率
            outObjectTmp.setDURABLEY(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getDURABLEY())));//法定耐用年数
            outObjectTmp.setLEASEM(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getLEASEM())));//リース月数・割賦期間
            outObjectTmp.setRATEJLC(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEJLC())));//社内コスト率
            outObjectTmp.setRATECADJ(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATECADJ())));//原調計算金利(COF)
            outObjectTmp.setRATEEANI(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEEANI())));//管販費率
            outObjectTmp.setRATEEAO(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEEAO())));//管販費率Original
            outObjectTmp.setRATEEAS(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEEAS())));//管販費率Service
            //管販費率Original
            double dRateEAO = 0.0;
            if (!LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEEAO(), LfcFrmBeanConst.PLUSFLOAT)) {
                dRateEAO = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEEAO()));
            }
            //管販費率Service
            double dRateEAS = 0.0;
            if (!LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEEAS(), LfcFrmBeanConst.PLUSFLOAT)) {
                dRateEAS = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEEAS()));
            }
            // 管販費率合計を再計算する
            outObjectTmp.setRATEEANI(Double.toString(dRateEAO + dRateEAS));
            outObjectTmp.setRATELOSS(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATELOSS())));//貸倒引当率
            outObjectTmp.setCSTKISHUCD(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getCSTKISHUCD())));//CST機種コード
            outObjectTmp.setRATEFEE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEFEE())));//手数料収益率
            outObjectTmp.setRATEFEEN(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEFEEN())));//手数料収益率NPP
            outObjectTmp.setRATEFEER(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEFEER())));//手数料収益率Release
            //手数料収益率NPP
            double dRateFeeN = 0.0;
            if (!LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEFEEN(), LfcFrmBeanConst.PLUSFLOAT)) {
                dRateFeeN = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEFEEN()));
            }
            //手数料収益率Release
            double dRateFeeR = 0.0;
            if (!LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEFEER(), LfcFrmBeanConst.PLUSFLOAT)) {
                dRateFeeR = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEFEER()));
            }
            //手数料率(合計)を再計算する
            outObjectTmp.setRATEFEE(Double.toString(dRateFeeN + dRateFeeR));

            //原調計算金利(COF)
            double dCof = 0.0;
            if (!LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATECADJ(), LfcFrmBeanConst.PLUSFLOAT)) {
                dCof = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATECADJ()));
            }
            //貸倒引当率
            double dRATELOSS = 0.0;
            if (!LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATELOSS(), LfcFrmBeanConst.PLUSFLOAT)) {
                dRATELOSS = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATELOSS()));
            }
            // 社内コスト率を再計算する
            //社内コスト率=ＣＯＦ＋管販費率+貸倒引当率-手数料収益率合計
            outObjectTmp.setRATEJLC(Double.toString(dCof + dRateEAO + dRateEAS + dRATELOSS - (dRateFeeN + dRateFeeR)));
            outObjectTmp.setDOSORATE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getDOSORATE())));//動総保険料率
            outObjectTmp.setSWSOFT(LfcFrmComm.lostNull(inObjectTmp.getSWSOFT()));//ソフトウェア区分
            outObjectTmp.setSWBAISEKI(LfcFrmComm.lostNull(inObjectTmp.getSWBAISEKI()));//賠責保険付保区分
            outObjectTmp.setDANSHINRT(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getDANSHINRT())));//団信保険料率
            outObjectTmp.setMACHIFEE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getMACHIFEE())));//機械保険料
            outObjectTmp.setFIREFEE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getFIREFEE())));//火災保険料
            outObjectTmp.setETCFEE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getETCFEE())));//船舶・その他保険料
            outObjectTmp.setICHIJI1(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getICHIJI1())));//一時費用(イ)(公証)
            outObjectTmp.setICHIJI2(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getICHIJI2())));//一時費用(ロ)
            outObjectTmp.setICHIJI3(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getICHIJI3())));//一時費用(ハ)
            outObjectTmp.setKURINO1(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getKURINO1())));//繰延費用(ヘ)(団信)
            outObjectTmp.setKURINO2(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getKURINO2())));//繰延費用(ト)
            outObjectTmp.setHOSHURYO(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getHOSHURYO())));//保守料
            outObjectTmp.setASSEN(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getASSEN())));//斡旋手数料
            //wanglin 20120312 S
            if ("L".equals(outObjectTmp.getLSKP())) {
                outObjectTmp.setRESERVEOUTN01(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRESERVEINN01())));//低炭信用保険料率
                outObjectTmp.setRESERVEOUTN02(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRESERVEINN02())));//低炭信用保険料
                outObjectTmp.setRESERVEOUTN03(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRESERVEINN03())));//付保期間
            }
            //wanglin 20120312 E
            outObjectTmp.setKAPPUINS(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getKAPPUINS())));//割賦保険料
            outObjectTmp.setDATEINC0(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getDATEINC0())));//前受ﾘｰｽ料回収日
            if ("S".equals(outObjectTmp.getLSKP())) {
                outObjectTmp.setDATEINC0(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getDATEKENSH())));//頭金回収日
            }
            outObjectTmp.setINCOME0(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getINCOME0())));//前受リース料
            outObjectTmp.setINC0M(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getINC0M())));//前受リース月数
            outObjectTmp.setRYORITSUT(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRYORITSUT())));//合計料率
            outObjectTmp.setRYORITSUM(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRYORITSUM())));//月料率
            outObjectTmp.setRATEUNYO(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEUNYO())));//運用利回り
            outObjectTmp.setTRUERATE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getTRUERATE())));//ＴＲ
            outObjectTmp.setRATEROI(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getRATEROI())));//ＲＯＩ
            outObjectTmp.setROE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getROE())));//ROE
            outObjectTmp.setTAX(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getTAX())));//TAX
            outObjectTmp.setSWSPRO(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getSWSPRO())));//少額資産区分
            outObjectTmp.setINSURANCE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(inObjectTmp.getINSURANCE())));//保険料
            outObjectTmp.setLEVERAGERATIO(LfcFrmComm.lostNull(inObjectTmp.getLEVERAGERATIO()));//LEVERAGE_RATIO
            outObjectTmp.setPRODUCT(LfcFrmComm.lostNull(inObjectTmp.getPRODUCT()));//PRODUCT
            outObjectTmp.setGERATING(LfcFrmComm.lostNull(inObjectTmp.getGERATING()));//GE_RATING
            //物件情報をOUTPUTに格納する
            bOutBukenTmp.setBukenRecord(outObjectTmp);

            //回収情報をOUTPUTに格納する
            bOutBukenTmp.setKaisyuRecord(bInputType.getKaisyuRecord());
            //支払情報をOUTPUTに格納する
            bOutBukenTmp.setShiharaiRecord(bInputType.getShiharaiRecord());
            //回収情報
            List<CollectionComplexType> listStairs = bOutBukenTmp.getKaisyuRecord().getKaishuInOut();
            Iterator<CollectionComplexType> iteStairs = listStairs.iterator();
            while (iteStairs.hasNext()) {
                CollectionComplexType outputStairsdate = iteStairs.next();
                outputStairsdate.setINCOME(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(outputStairsdate.getINCOME())));//回収金額
                outputStairsdate.setCYCLE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(outputStairsdate.getCYCLE())));//回収サイク
                outputStairsdate.setFREQUE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(outputStairsdate.getFREQUE())));//回数
                outputStairsdate.setKAISYUDATE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(outputStairsdate.getKAISYUDATE())));//回収日
            }
            //支払情報
            List<PaydivComplexType> listPaydiv = bOutBukenTmp.getShiharaiRecord().getPaydivInOut();
            Iterator<PaydivComplexType> itePaydiv = listPaydiv.iterator();
            while (itePaydiv.hasNext()) {
                PaydivComplexType outputPaydivdate = itePaydiv.next();
                outputPaydivdate.setSHIHARAIGAKU(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(outputPaydivdate.getSHIHARAIGAKU())));//支払額
                outputPaydivdate.setSHIHARAIDATE(LfcFrmComm.toHalfANS(LfcFrmComm.lostNull(outputPaydivdate.getSHIHARAIDATE())));//支払日
            }
            //物件情報のチェックフラグをOUTPUTに格納する
            bOutBukenTmp.setCheckAttribute(Boolean.FALSE);
            //物件情報の計算フラグをOUTPUTに格納する
            bOutBukenTmp.setCalculateAttribute(Boolean.FALSE);
            //物件レコードのを出力OUTPUTに格納する
            bukenOutputRecode.getBukenOutput().add(index_input, bOutBukenTmp);
        }
        return bukenOutputRecode;
    }

    public BukenOutputComplexType doTotalPrice(ObjectOutputComplexType outObjectTmp, BukenOutputResType inputdate, String ls_kp) throws Exception {
        BukenOutputComplexType bTotalPrice = new BukenOutputComplexType();
        getWebServiceResults(inputdate);

        // 購入価格
        double dSumPurchase = 0;
        // 残価
        double dSumRemainVal = 0;
        // 社内コスト額
        double dSumInterestP = 0;
        // フルペイ社内コスト額
        double dfSumInterestP = 0;
        // 固定資産税
        double dSumFixasttax = 0;
        // 保険料
        double dSumInsurance = 0;
        // フルペイ保険料
        double dFSumInsurance = 0;
        // その他原価 (ﾘｰｽ原価計-購入価額+残価-支払利息-固定資産税-保険料)
        double dSumSonota = 0;
        // リース原価
        double dSumCostTotal = 0;
        // フルペイリース原価
        double dFSumCostTotal = 0;
        // 当社手数料
        double dSumCharge = 0;
        // フルペイ当社手数料
        double dFSumCharge = 0;
        // 契約額
        double dSumIncomeGt = 0;
        // リース料（割賦金）
        double dSumLease = 0;
        // 原価調整額
        double dSumCAdjust = 0;
        // リース月数
        double dSumLeaseM = 0;
        // リース月数Tmp
        double dSumLeaseMTmp = 0;
        // (前受月数)
        double dSumIncOM = 0;
        // 原価調整期間(ｶ月)
        double dSumAdjustM = 0;
        // 原価調整期間(ｶ月)Tmp
        double dSumAdjustMTmp = 0;
        // 原価調整期間(日)
        double dSumAdjustD = 0;
        // 原価調整期間(日)Tmp
        double dSumAdjustDTmp = 0;
        // 社内コスト率
        double dSumRateJlc = 0;
        // 社内コスト率Tmp
        double dSumfRateJlcTmp = 0;
        // フルペイ社内コスト率
        double dfSumRateJlc = 0;
        // 使用総資産
        double dSumCapitalT = 0;
        // フルペイ使用総資産
        double dfSumCapitalT = 0;
        // 年利回り
        double dSumRateYear = 0;
        // フルペイ年利回り
        double dfSumRateYear = 0;
        // 荒利益
        double dSumProfitT = 0;
        // フルペイ荒利益
        double dfSumProfitT = 0;
        // 運用利回り
        double dSumRateUnyo = 0;
        // フルペイ運用利回り
        double dfSumRateUnyo = 0;
        // 回収利息
        double dSumInterestI = 0;
        // フルペイ回収利息
        double dfSumInterestI = 0;
        // TR
        double dSumRateTrue = 0;
        // フルペイTR
        double dfSumRateTrue = 0;
        // ROI
        double dSumRateROI = 0;
        // フルペイROI
        double dfSumRateROI = 0;
        // COF
        double dSumRateCof = 0;
        // COFTmp
        double dSumRateCofTmp = 0;
        // 管販比率合計
        double dSumRateEAni = 0;
        // 管販比率O
        double dSumRateEAO = 0;
        // 管販比率OTmp
        double dSumRateEAOTmp = 0;
        // 管販比率S
        double dSumRateEAS = 0;
        // 管販比率STmp
        double dSumRateEASTmp = 0;
        // 貸倒引当率
        double dSumRateLoss = 0;
        // 貸倒引当率Tmp
        double dSumRateLossTmp = 0;
        // 手数料収益率合計
        double dSumRateFee = 0;
        // 手数料率N
        double dSumRateFeeN = 0;
        // 手数料率NTmp
        double dSumRateFeeNTmp = 0;
        // 手数料率R
        double dSumRateFeeR = 0;
        // 手数料率RTmp
        double dSumRateFeeRTmp = 0;
        // ROI額
        double dSumROI = 0;
        // フルペイROI額
        double dfSumROI = 0;
        //wanglin 20120312 S
         //低炭素リース保険料率
        double dSumRateEcol = 0;
         //低炭素リース保険料
        double dSumEcol = 0;
        //低炭素リース付保期間
        int dSumCriTm = 0;
        //wanglin 20120312 E
        // その他雑費
        double dSumZapi = 0;
        // 公正証書作成費用(一時費用(イ))
        double dSumIchiji1 = 0;
        // その他一時費用一時費用(ロ)
        double dSumIchiji2 = 0;
        // その他一時費用(一時費用(ハ))
        double dSumIchiji3 = 0;
        // その他繰延費用(ヘ)
        double dSumKurino1 = 0;
        // フルペイその他繰延費用(ヘ)
        double dfSumKurino1 = 0;
        // その他繰延費用(ト)
        double dSumKurino2 = 0;
        // 保守料
        double dSum_hoshuryo = 0;
        // 斡旋手数料
        double dSum_assen = 0;
        // 前受リース料（頭金）
        double dSumIncome0 = 0;
        // Finance Margin率
        double dSumFinanceMargin = 0;
        // フルペイFinance Margin率
        double dfSumFinanceMargin = 0;
        // RA Margin率
        double dSumRaMargin = 0;
        // フルペイPV Finance Margin額
        double dfSumRaMargin = 0;
        // PV Finance Margin額
        double dSumPvFinanceMargin = 0;
        // フルペイPV Finance Margin額
        double dfSumPvFinanceMargin = 0;
        // RA PV Margin額
        double dSumRaPvMargin = 0;
        // フルペイRA PV Margin額
        double dfSumRaPvMargin = 0;
        // 割賦料KAPPU_INS
        double dfSumKAPPU_INS = 0;
        // 割賦金総額
        double dfSumINCOMET = 0;
        // 割賦金合計
        double dSumKapuK = 0;
        // リース料EVEN_FLG
        String strLeaseEvenFlg = "1";
        // 支払
        String strSwPayFlg = "1";

        // リース月数Min
        int nLeaseMMin = 0;
        // リース月数Max
        int nLeaseMMax = 0;
        // 前 受 リース料Min
        double nInc_0_MMin = 0;
        // 前 受 リース料Max
        double nInc_0_MMax = 0;
        // 据置月数Min
        int nLeaveMMin = 0;
        // 据置月数Max
        int nLeaveMMax = 0;
        // 法定耐用年数Min
        int nDuraYMin = 0;
        // 法定耐用年数Max
        int nDuraYMax = 0;
        // 動総保険料率Min
        double dDosoRtMin = 0;
        // 動総保険料率Max
        double dDosoRtMax = 0;
        // 動総保険料
        double dDosoFEE = 0;
        //機械保険料
        double dMachiFEE = 0;
        //火災保険料
        double dFireFEE = 0;
        //船舶・その他保険料
        double dEtcFEE = 0;
        //初期費用
        double dSumINIT_COST = 0;
        //実行費用総額
        double dSumEXEC_COST = 0;
        //賠責保険料
        double dSumBAIS_FEE = 0;
        //ﾌﾙﾍﾟｲ回収利息
        double dSumF_INTER_I = 0;
        //ﾌﾙﾍﾟｲ実行費用総額
        double dSumF_EXEC_C = 0;
        //ﾌﾙﾍﾟｲ繰延費用(ヘ)
        double dSumF_KURI_1 = 0;
        //ﾌﾙﾍﾟｲ荒利益額
        double dSumF_PRO_T = 0;
        //年荒利益額
        double dSumF_PRO_Y = 0;
        //ﾌﾙﾍﾟｲ年荒利益額
        double dfSumF_PRO_Y = 0;
        // 団信保険料率Min
        double dDansRtMin = 0;
        // 団信保険料率Max
        double dDansRtMax = 0;
        // 法定耐用年数のtmp
        double tmpdDuraY = 0;
        // 法定耐用年数
        int nDuraY = 0;
        // 規定損害金 基本額
        double dSumDAMAGE_BAS = 0;
        // 規定損害金前半逓減月額
        double dSumDAMAGE_FA = 0;
        // 規定損害金後半逓減月額
        double dSumDAMAGE_LA = 0;
        // 規定損害金前半逓減月数MIN
        int nSumDAMAGE_FMMIN = 0;
        // 規定損害金前半逓減月数MAX
        int nSumDAMAGE_FMMAX = 0;
        // 規定損害金後半逓減月数MIN
        int nSumDAMAGE_LMMIN = 0;
        // 規定損害金後半逓減月数MAX
        int nSumDAMAGE_LMMAX = 0;

        // 物件No Total Flag
        int nSumTotalDisplayFlg = 1;
        // 物件No Continue Flag
        int nSumContinueFlg = 1;
        // (賠償責任保険対象物件を含む)
        int nSwBaisDisplayFlg = 1;

        // ROE
        double dSumROE = 0;
        // FullPay ROE
        double dfSumROE = 0;
        // Ratio
        int nSumRatio = 0;


        String[][] strDisplayObjectResults = null;
        strDisplayObjectResults = objectBean.getResultsForLease();

        int nBukenFrm;
        int nBukenTo;
        // 物件No TotalNumber Flag
        if (strDisplayObjectResults.length == 1) {
            nSumTotalDisplayFlg = 0;
        }
        nBukenTo = LfcFrmComm.toInt(strDisplayObjectResults[strDisplayObjectResults.length - 1][OBJECT_BUKKEN_TO]);
        if (nBukenTo == 0) {
            nBukenTo = LfcFrmComm.toInt(strDisplayObjectResults[strDisplayObjectResults.length - 1][OBJECT_BUKKEN_FR]);
        }

        if (nBukenTo == LfcFrmComm.toInt(strDisplayObjectResults[strDisplayObjectResults.length - 1][OBJECT_BUKKEN_FR])) {
            nBukenTo = LfcFrmComm.toInt(strDisplayObjectResults[strDisplayObjectResults.length - 1][OBJECT_BUKKEN_NO]);
        }

        nBukenFrm = LfcFrmComm.toInt(strDisplayObjectResults[0][OBJECT_BUKKEN_FR]);
        if (nBukenFrm == LfcFrmComm.toInt(strDisplayObjectResults[0][OBJECT_BUKKEN_TO])) {
            nBukenFrm = LfcFrmComm.toInt(strDisplayObjectResults[0][OBJECT_BUKKEN_NO]);
        }

        // 物件No continue Flag
        int nBukkenCnt = 0;
        for (int i = 0; i < strDisplayObjectResults.length; i++) {
            nBukkenCnt = nBukkenCnt + LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_BUKKEN_TO]) - LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_BUKKEN_FR]) + 1;
        }
        if (nBukenTo - nBukenFrm + 1 != nBukkenCnt) {
            nSumContinueFlg = 0;
        }

        for (int i = 0; i < strDisplayObjectResults.length; i++) {
            nBukkenCnt = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_BUKKEN_TO]) - LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_BUKKEN_FR]) + 1;
            if (i == 0) {
                // リース月数のMin
                nLeaseMMin = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEASE_M]);
                // リース月数のMax
                nLeaseMMax = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEASE_M]);
                // 前 受 リース料Min
                nInc_0_MMin = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INC_0_M]);
                // 前 受 リース料Max
                nInc_0_MMax = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INC_0_M]);
                // 据置月数のMin
                nLeaveMMin = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEAVE_M]);
                // 据置月数のMax
                nLeaveMMax = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEAVE_M]);
                // 法定耐用年数のMin
                nDuraYMin = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DURABLE_Y]);
                // 法定耐用年数のMax
                nDuraYMax = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DURABLE_Y]);
                // 動総保険料率のMin
                dDosoRtMin = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DOSO_RATE]);
                // 動総保険料率のMax
                dDosoRtMax = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DOSO_RATE]);
                // 団信保険料率のMin
                dDansRtMin = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DANSHIN_RT]);
                // 団信保険料率のMax
                dDansRtMax = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DANSHIN_RT]);
                // 20040906 ljq add s

                // Leverage
                String strTmpLeveRage = strDisplayObjectResults[i][OBJECT_LEVERAGE];
                if (strTmpLeveRage != null && !"".equals(strTmpLeveRage) && strTmpLeveRage.indexOf(":") != -1) {
                    strTmpLeveRage = strTmpLeveRage.substring(0, strTmpLeveRage.indexOf(":"));
                }

                /*
                 * // String strTmpLeveRage = "0"; if (!(strTmpLeveRage.length() <
                 * 2)) { strTmpLeveRage = strTmpLeveRage.substring( 0,
                 * strTmpLeveRage.length() - 2); }
                 */
                if (strTmpLeveRage == null) {
                    strTmpLeveRage = "16";
                }
                nSumRatio = LfcFrmComm.toInt(strTmpLeveRage);
                // 20040906 ljq add e
            }

            // 規定損害金前半逓減月数MIN
            if (nSumDAMAGE_FMMIN >= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DAMAGE_FM])) {
                nSumDAMAGE_FMMIN = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DAMAGE_FM]);
            }

            // 規定損害金前半逓減月数MAX
            if (nSumDAMAGE_FMMAX <= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DAMAGE_FM])) {
                nSumDAMAGE_FMMAX = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DAMAGE_FM]);
            }

            // 規定損害金後半逓減月数MIN
            if (nSumDAMAGE_LMMIN >= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DAMAGE_LM])) {
                nSumDAMAGE_LMMIN = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DAMAGE_LM]);
            }

            // 規定損害金後半逓減月数MIN
            if (nSumDAMAGE_LMMAX <= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DAMAGE_LM])) {
                nSumDAMAGE_LMMAX = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DAMAGE_LM]);
            }

            // リース月数のMin
            if (nLeaseMMin >= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEASE_M])) {
                nLeaseMMin = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEASE_M]);
            }
            // リース月数のMax
            if (nLeaseMMax <= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEASE_M])) {
                nLeaseMMax = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEASE_M]);
            }
            // 前 受 リース料Min
            if (nInc_0_MMin >= LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INC_0_M])) {
                nInc_0_MMin = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INC_0_M]);
            }
            // 前 受 リース料Max
            if (nInc_0_MMax <= LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INC_0_M])) {
                nInc_0_MMax = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INC_0_M]);
            }
            // 据置月数のMin
            if (nLeaveMMin >= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEAVE_M])) {
                nLeaveMMin = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEAVE_M]);
            }
            // 据置月数のMax
            if (nLeaveMMax <= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEAVE_M])) {
                nLeaveMMax = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEAVE_M]);
            }
            // 法定耐用年数のMin
            if (nDuraYMin >= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DURABLE_Y])) {
                nDuraYMin = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DURABLE_Y]);
            }
            // 法定耐用年数のMax
            if (nDuraYMax <= LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DURABLE_Y])) {
                nDuraYMax = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DURABLE_Y]);
            }

            // 動総保険料率のMin
            if (dDosoRtMin >= LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DOSO_RATE])) {
                dDosoRtMin = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DOSO_RATE]);
            }
            // 動総保険料率のMax
            if (dDosoRtMax <= LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DOSO_RATE])) {
                dDosoRtMax = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DOSO_RATE]);
            }
            // 団信保険料率のMin
            if (dDansRtMin >= LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DANSHIN_RT])) {
                dDansRtMin = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DANSHIN_RT]);
            }
            // 団信保険料率のMax
            if (dDansRtMax <= LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DANSHIN_RT])) {
                dDansRtMax = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DANSHIN_RT]);
            }

            // 規定損害金 基本額
            dSumDAMAGE_BAS = dSumDAMAGE_BAS + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DAMAGE_BAS]) * nBukkenCnt;
            // 規定損害金前半逓減月額
            dSumDAMAGE_FA = dSumDAMAGE_FA + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DAMAGE_FA]) * nBukkenCnt;
            // 規定損害金後半逓減月額
            dSumDAMAGE_LA = dSumDAMAGE_LA + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DAMAGE_LA]) * nBukkenCnt;

            // 購入価格
            dSumPurchase = dSumPurchase + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_PURCHASE]) * nBukkenCnt;
            // 残価
            dSumRemainVal = dSumRemainVal + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_REMAIN_VAL]) * nBukkenCnt;
            // 社内コスト額
            dSumInterestP = dSumInterestP + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INTEREST_P]) * nBukkenCnt;
            // フルペイ社内コスト額
            dfSumInterestP = dfSumInterestP + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_INTER_P]) * nBukkenCnt;
            // 固定資産税
            dSumFixasttax = dSumFixasttax + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_FIXASTTAX]) * nBukkenCnt;
            //動総保険料
            dDosoFEE = dDosoFEE + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_DOSO_FEE]) * nBukkenCnt;
            // 保険料
            dSumInsurance = dSumInsurance + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INSURANCE]) * nBukkenCnt;
            // フルペイ保険料
            dFSumInsurance = dFSumInsurance + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_INSUR]) * nBukkenCnt;
            // リース原価
            dSumCostTotal = dSumCostTotal + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_COST_TOTAL]) * nBukkenCnt;
            // フルペイリース原価
            dFSumCostTotal = dFSumCostTotal + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_COST_T]) * nBukkenCnt;
            // 当社手数料
            dSumCharge = dSumCharge + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CHARGE]) * nBukkenCnt;
            // フルペイ当社手数料
            dFSumCharge = dFSumCharge + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_CHARGE]) * nBukkenCnt;
            // 契約額
            dSumIncomeGt = dSumIncomeGt + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INCOME_GT]) * nBukkenCnt;
            // リース料

            // zj 2005/02/03 start
            if ("S".equals(ls_kp)) {
                String[][] strCntrctStairsResults = _stairsBean.getResultsForLease();
                String strCurrBukenNo = strDisplayObjectResults[i][OBJECT_BUKKEN_NO];
                long lStairsFreque = 0;
                for (int j = 0; j < strCntrctStairsResults.length; j++) {
                    if (strCurrBukenNo.equals(strCntrctStairsResults[j][STAIRS_BUKKEN_NO])) {
                        lStairsFreque = lStairsFreque + LfcFrmComm.toInt(strCntrctStairsResults[j][STAIRS_FREQUE]);
                    }
                }
                // 20050204 ltq 修正しました。
                dSumLease = dSumLease + (LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INCOME_GT]) - LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INCOME_0])) / (double) (lStairsFreque) * nBukkenCnt;
            } else {
                dSumLease = dSumLease + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INCOME_GT]) / LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_LEASE_M]) * nBukkenCnt;
            }
            // zj 2005/02/03 end

            // 原価調整額
            dSumCAdjust = dSumCAdjust + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_C_ADJUST]) * nBukkenCnt;
            // ﾌﾙﾍﾟｲ回収利息
            dfSumInterestI = dfSumInterestI + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_INTER_I]) * nBukkenCnt;
            // 使用総資産
            dSumCapitalT = dSumCapitalT + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CAPITAL_T]) * nBukkenCnt;
            // フルペイ使用総資産
            dfSumCapitalT = dfSumCapitalT + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_CAPIT_T]) * nBukkenCnt;

            // 荒利益
            dSumProfitT = dSumProfitT + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_PROFIT_T]) * nBukkenCnt;
            // フルペイ荒利益
            dfSumProfitT = dfSumProfitT + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_PRO_T]) * nBukkenCnt;
            //wanglin 20120312 S
             //低炭素リース保険料率
            if(dSumRateEcol <= (LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CRE_INS_RT]))){
                dSumRateEcol = LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CRE_INS_RT]);
            }
            //低炭素リース保険料
            dSumEcol = dSumEcol + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CREDIT_INS]) * nBukkenCnt;
            //低炭素リース付保期間
           if(dSumCriTm <= (LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_CRE_INS_TM]))){
                dSumCriTm = LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_CRE_INS_TM]);
            }
            //wanglin 20120312 E
            // その他雑費
            dSumZapi = dSumZapi + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ZAPI]) * nBukkenCnt;
            // 公正証書作成費用(一時費用(イ))
            dSumIchiji1 = dSumIchiji1 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ICHIJI_1]) * nBukkenCnt;
            // その他一時費用一時費用(ロ)
            dSumIchiji2 = dSumIchiji2 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ICHIJI_2]) * nBukkenCnt;
            // その他一時費用(一時費用(ハ))
            dSumIchiji3 = dSumIchiji3 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ICHIJI_3]) * nBukkenCnt;
            // その他繰延費用(ヘ)
            dSumKurino1 = dSumKurino1 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_KURINO_1]) * nBukkenCnt;
            // フルペイその他繰延費用(ヘ)
            dfSumKurino1 = dfSumKurino1 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_KURI_1]) * nBukkenCnt;
            // その他繰延費用(ト)
            dSumKurino2 = dSumKurino2 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_KURINO_2]) * nBukkenCnt;
            // 保守料
            dSum_hoshuryo = dSum_hoshuryo + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_HOSHURYO]) * nBukkenCnt;
            // 斡旋手数料
            dSum_assen = dSum_assen + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ASSEN]) * nBukkenCnt;
            //機械保険料
            dMachiFEE = dMachiFEE + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_MACHI_FEE]) * nBukkenCnt;
            //火災保険料
            dFireFEE = dFireFEE + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_FIRE_FEE]) * nBukkenCnt;
            //船舶・その他保険料
            dEtcFEE = dEtcFEE + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ETC_FEE]) * nBukkenCnt;

            //初期費用
            dSumINIT_COST = dSumINIT_COST + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INIT_COST]) * nBukkenCnt;
            //実行費用総額
            dSumEXEC_COST = dSumEXEC_COST + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_EXEC_COST]) * nBukkenCnt;
            //賠責保険料
            dSumBAIS_FEE = dSumBAIS_FEE + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_BAIS_FEE]) * nBukkenCnt;
            //ﾌﾙﾍﾟｲ回収利息
            dSumF_INTER_I = dSumF_INTER_I + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_INTER_I]) * nBukkenCnt;
            //ﾌﾙﾍﾟｲ実行費用総額
            dSumF_EXEC_C = dSumF_EXEC_C + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_EXEC_C]) * nBukkenCnt;
            //ﾌﾙﾍﾟｲ繰延費用(ヘ)
            dSumF_KURI_1 = dSumF_KURI_1 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_KURI_1]) * nBukkenCnt;
            //ﾌﾙﾍﾟｲ荒利益額
            dSumF_PRO_T = dSumF_PRO_T + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_PRO_T]) * nBukkenCnt;
            //年荒利益額
            dSumF_PRO_Y = dSumF_PRO_Y + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_PROFIT_Y]) * nBukkenCnt;
            //ﾌﾙﾍﾟｲ年荒利益額
            dfSumF_PRO_Y = dfSumF_PRO_Y + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_PRO_Y]) * nBukkenCnt;
            //回収利息
            dSumInterestI = dSumInterestI + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INTEREST_I]) * nBukkenCnt;
            // 前受リース料(頭金)
            dSumIncome0 = dSumIncome0 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INCOME_0]) * nBukkenCnt;
            // PV Finance Margin額

            dSumPvFinanceMargin = dSumPvFinanceMargin + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_PV_FINANCE_MARGIN]) * nBukkenCnt;
            // フルペイPV Finance Margin額
            dfSumPvFinanceMargin = dfSumPvFinanceMargin + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_PV_FINANCE_MARGIN]) * nBukkenCnt;
            // RA PV Margin額
            dSumRaPvMargin = dSumRaPvMargin + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_RA_PV_MARGIN]) * nBukkenCnt;
            // フルペイRA PV Margin額
            dfSumRaPvMargin = dfSumRaPvMargin + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_F_RA_PV_MARGIN]) * nBukkenCnt;
            // 割賦料KAPPU_INS
            dfSumKAPPU_INS = dfSumKAPPU_INS + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_KAPPU_INS]) * nBukkenCnt;
            // 割賦料KAPPU_INS
            dfSumINCOMET = dfSumINCOMET + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_INCOME_T]) * nBukkenCnt;

            // EVEN_FLG
            if ("0".equals(strDisplayObjectResults[i][OBJECT_EVEN_FLG])) {
                strLeaseEvenFlg = "0";
            }
            // (賠償責任保険対象物件を含む)
            if ("1".equals(strDisplayObjectResults[i][OBJECT_SW_BAISEKI])) {
                nSwBaisDisplayFlg = 0;
            }
            //
            if (LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEAVE_M]) > 1) {
                dSumKapuK = dSumKapuK + LfcFrmComm.ToLong(strDisplayObjectResults[i][OBJECT_INCOME_T]) / (LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_LEAVE_M]) - 1) * nBukkenCnt;
            } else {
                dSumKapuK = LfcFrmComm.ToLong(strDisplayObjectResults[i][OBJECT_INCOME_T]);
            }
            // 支払
            if ("2".equals(strDisplayObjectResults[i][OBJECT_SW_PAY])) {
                strSwPayFlg = "2";
            }
            // TMP
            // リース月数
            dSumLeaseMTmp = dSumLeaseMTmp + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_PURCHASE]) * LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_LEASE_M]) * nBukkenCnt;
            // 原価調整月数
            dSumAdjustMTmp = dSumAdjustMTmp + (LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_PURCHASE]) * (LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ADJUST_M]) * 30 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ADJUST_D]))) * nBukkenCnt;
            // 原価調整日数
            dSumAdjustDTmp = dSumAdjustDTmp + (LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_PURCHASE]) * (LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ADJUST_M]) * 30 + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_ADJUST_D]))) * nBukkenCnt;
            // 社内コスト率
            dSumfRateJlcTmp = dSumfRateJlcTmp + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CAPITAL_T]) * LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_RATE_JLC]) * nBukkenCnt;
            // COF
            dSumRateCofTmp = dSumRateCofTmp + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CAPITAL_T]) * LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_RATE_C_ADJ]) * nBukkenCnt;
            // 管販比率O
            dSumRateEAOTmp = dSumRateEAOTmp + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CAPITAL_T]) * LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_RATE_E_A_O]) * nBukkenCnt;
            // 管販比率S
            dSumRateEASTmp = dSumRateEASTmp + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CAPITAL_T]) * LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_RATE_E_A_S]) * nBukkenCnt;
            // 貸倒引当率
            dSumRateLossTmp = dSumRateLossTmp + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CAPITAL_T]) * LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_RATE_LOSS]) * nBukkenCnt;
            // 手数料率N
            dSumRateFeeNTmp = dSumRateFeeNTmp + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CAPITAL_T]) * LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_RATE_FEE_N]) * nBukkenCnt;
            // 手数料率R
            dSumRateFeeRTmp = dSumRateFeeRTmp + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_CAPITAL_T]) * LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_RATE_FEE_R]) * nBukkenCnt;
            // 法定耐用年数のtmp
            tmpdDuraY = tmpdDuraY + LfcFrmComm.ToDouble(strDisplayObjectResults[i][OBJECT_PURCHASE]) / LfcFrmComm.toInt(strDisplayObjectResults[i][OBJECT_DURABLE_Y]) * nBukkenCnt;
        }

//		ydy add 20061021 s
//		 ROI額
        if (dSumProfitT > 0) {
            //20070326 modi zyb s
//			dSumROI = LfcFrmComm.dround(dSumProfitT * 0.65,0);
            //20090121 modi HBQ s
            //dSumROI = LfcFrmComm.dround(dSumProfitT * LfcLogicPgConst.USA_PERSON_TAX,0);
            dSumROI = LfcFrmComm.dround(dSumProfitT * LfcLogicPgConst.USA_PERSON_TAX, 0);
            //20090121 modi HBQ e
            //20070326 modi zyb e
        } else {
            dSumROI = dSumProfitT;
        }
//		 フルペイROI額
        if (dfSumProfitT > 0) {
            //20070326 modi zyb s
            //dfSumROI = LfcFrmComm.dround(dfSumProfitT * 0.65,0);
            //20090121 modi HBQ s
            //dfSumROI = LfcFrmComm.dround(dfSumProfitT * LfcLogicPgConst.USA_PERSON_TAX,0);
            dfSumROI = LfcFrmComm.dround(dfSumProfitT * LfcLogicPgConst.USA_PERSON_TAX, 0);
            //20090121 modi HBQ e
            //20070326 modi zyb e

        } else {
            dfSumROI = dfSumProfitT;
        }
//		ydy add 20061021 e
        // 法定耐用年数
        nDuraY = (int) LfcLogicComm.dround(dSumPurchase / tmpdDuraY, 1);
        // 年利回り
        if (dSumCapitalT == 0) {
            // dSumRateYear = -0.9999;
            // dfSumRateYear = -0.9999;
            dSumRateYear = 0.0;
            dfSumRateYear = 0.0;
        } else {
            dSumRateYear = dSumProfitT / dSumCapitalT;
            dfSumRateYear = dfSumProfitT / dfSumCapitalT;
        }
        // フルペイ年利回り
        if (dfSumCapitalT == 0) {
            // dfSumRateYear = -0.9999;
            dfSumRateYear = 0.0;
        } else {
            dfSumRateYear = dfSumProfitT / dfSumCapitalT;
        }
        // pzk modi 2004/12/06 s
        if (dSumCapitalT == 0) {
            // COF
            dSumRateCof = 0.0;
            // 管販比率O
            dSumRateEAO = 0.0;
            // 管販比率S
            dSumRateEAS = 0.0;
            // 管販比率合計
            dSumRateEAni = 0.0;
            // 貸倒引当率
            dSumRateLoss = 0.0;
            // 手数料率N
            dSumRateFeeN = 0.0;
            // 手数料率R
            dSumRateFeeR = 0.0;
            // 手数料収益率合計
            dSumRateFee = 0.0;
        } else {
            // COF
            dSumRateCof = dSumRateCofTmp / dSumCapitalT;
            // 管販比率O
            dSumRateEAO = dSumRateEAOTmp / dSumCapitalT;
            // 管販比率S
            dSumRateEAS = dSumRateEASTmp / dSumCapitalT;
            // 管販比率合計
            dSumRateEAni = dSumRateEAO + dSumRateEAS;
            // 貸倒引当率
            dSumRateLoss = dSumRateLossTmp / dSumCapitalT;
            // 手数料率N
            dSumRateFeeN = dSumRateFeeNTmp / dSumCapitalT;
            // 手数料率R
            dSumRateFeeR = dSumRateFeeRTmp / dSumCapitalT;
            // 手数料収益率合計
            dSumRateFee = dSumRateFeeN + dSumRateFeeR;
        }
        // //社内コスト率=ＣＯＦ＋管販費率＋貸倒引当率?手数料収益率合計
        if (dSumCapitalT == 0) {
            dSumRateJlc = 0.0;
        } else {
            // dSumRateJlc = dSumInterestP / dSumCapitalT;
            dSumRateJlc = (dSumRateCof + dSumRateEAni + dSumRateLoss - dSumRateFee) / 100;
        }
        // pzk modi 2004/12/06 e
        // 運用利回り
        dSumRateUnyo = dSumRateYear + dSumRateJlc;
        // フルペイ運用利回り
        if (dfSumCapitalT == 0) {
            // dfSumRateUnyo = -0.9999;
            dfSumRateUnyo = 0.0;
        } else {
            dfSumRateUnyo = dfSumInterestP / dfSumCapitalT + dfSumRateYear;
        }
        // 20040802 ljq add s
        if (dfSumRateUnyo >= 0.9999) {
            dfSumRateUnyo = 0.9999;
        }
        if (dfSumRateUnyo <= -0.9999) {
            dfSumRateUnyo = -0.9999;
        }
        // 20040802 ljq add e
        // リース月数
        dSumLeaseM = dSumLeaseMTmp / dSumPurchase;
        // 原価調整期間(ｶ月)
        dSumAdjustM = dSumAdjustMTmp / dSumPurchase / 30;
        // 原価調整期間(日)
        dSumAdjustD = dSumAdjustDTmp / dSumPurchase - (int) dSumAdjustM * 30;
        // TR
        if (dSumCapitalT == 0) {
            dSumRateTrue = 0.0;
        } else {
            dSumRateTrue = (dSumInterestP + dSumCharge) * dSumRateJlc / dSumInterestP;
        }
        if (dfSumCapitalT == 0) {
            dfSumRateTrue = 0.0;
        } else {
            dfSumRateTrue = dfSumInterestI / dfSumCapitalT;
        }
        // 20040802 ljq add s
        if (dfSumRateTrue >= 0.9999) {
            dfSumRateTrue = 0.9999;
        }
        if (dfSumRateTrue <= -0.9999) {
            dfSumRateTrue = -0.9999;
        }
        // 20040802 ljq add e

        // ROI
        // 20040903 ljq change s
        // dSumRateROI = dSumRateYear * 0.65;
        if (dSumRateYear <= 0 || dSumRateYear == 0.9999) {
            dSumRateROI = dSumRateYear;
        } else {
            //20070326 modi zyb s
//			dSumRateROI = dSumRateYear * 0.65;
            //20090121 modi HBQ s
            //dSumRateROI = dSumRateYear * LfcLogicPgConst.USA_PERSON_TAX;
            dSumRateROI = dSumRateYear * LfcLogicPgConst.USA_PERSON_TAX;
            //20090121 modi HBQ e

            //20070326 modi zyb e
        }
        if (dSumRateROI >= 0.9999) {
            dSumRateROI = 0.9999;
        }
        if (dSumRateROI <= -0.9999) {
            dSumRateROI = -0.9999;
        }
        // 20040903 ljq change e
        if (dfSumRateYear <= 0 || dfSumRateYear == 0.9999) {
            dfSumRateROI = dfSumRateYear;
        } else {
            //20070326 modi zyb s
//			dfSumRateROI = dfSumRateYear * 0.65;
            //20090121 modi HBQ s
            //dfSumRateROI = dfSumRateYear * LfcLogicPgConst.USA_PERSON_TAX;
            dfSumRateROI = dfSumRateYear * LfcLogicPgConst.USA_PERSON_TAX;
            //20090121 modi HBQ e
            //20070326 modi zyb e
        }
        // 20040802 ljq add s
        if (dfSumRateROI >= 0.9999) {
            dfSumRateROI = 0.9999;
        }
        if (dfSumRateROI <= -0.9999) {
            dfSumRateROI = -0.9999;
        }
        // dfSumRateROI = LfcFrmComm.dround(dfSumRateROI, 4);
        dSumRateROI = LfcFrmComm.dround(dSumRateROI, 4);
        dfSumRateROI = LfcFrmComm.dround(dfSumRateROI, 4);

        // 20040802 ljq add e
        // 20040906 ljq add s
        if (dSumRateROI == 0) {
            dSumROE = 0;
        } else if (dSumRateROI >= 0.9999) {
            dSumROE = 0.9999;
        } else if (dSumRateROI <= -0.9999) {
            dSumROE = -0.9999;
        } else {
            if (nSumRatio == 0) {
                dSumROE = 0;
            } else {
                dSumROE = (nSumRatio + 1) * dSumRateROI;
            }

        }
        if (dSumROE >= 99.9999) {
            dSumROE = 99.9999;
        }
        if (dSumROE <= -99.9999) {
            dSumROE = -99.9999;
        }

        if (dfSumRateROI == 0) {
            dfSumROE = 0;
        } else if (dfSumRateROI >= 0.9999) {
            dfSumROE = 0.9999;
        } else if (dfSumRateROI <= -0.9999) {
            dfSumROE = -0.9999;
        } else {
            if (nSumRatio == 0) {
                dfSumROE = 0;
            } else {
                dfSumROE = (nSumRatio + 1) * dfSumRateROI;
            }

        }
        if (dfSumROE >= 99.9999) {
            dfSumROE = 99.9999;
        }
        if (dfSumROE <= -99.9999) {
            dfSumROE = -99.9999;
        }

        // pzk add 2004/12/06 e
        // Finance Margin と RA PV Margin
        if (dSumRateUnyo == -0.9999 || dSumRateUnyo == 0.9999) {
            dSumFinanceMargin = dSumRateUnyo;
            dSumRaMargin = dSumRateUnyo;
        } else {
            // Finance Margin率(式：PV Finance Margin額÷使用総資金の合計値)
            dSumFinanceMargin = dSumPvFinanceMargin / dSumCapitalT;
            // Finance Margin率(式：運用利回?ＣＯＦ)
            dSumRaMargin = dSumRateUnyo - dSumRateCof / 100 - dSumRateLoss / 100;
        }
        // フルペイFinance Margin と フルペイRA PV Margin
        if (dfSumRateUnyo == -0.9999 || dfSumRateUnyo == 0.9999) {
            dfSumFinanceMargin = dfSumRateUnyo;
            dfSumRaMargin = dfSumRateUnyo;
        } else {
            // Finance Margin率(式：PV Finance Margin額÷使用総資金の合計値)
            dfSumFinanceMargin = dfSumPvFinanceMargin / dfSumCapitalT;
            // Finance Margin率(式：運用利回?ＣＯＦ)
            dfSumRaMargin = dfSumRateUnyo - dSumRateCof / 100 - dSumRateLoss / 100;
        }
        // 20040802 ljq add s
        if (dfSumFinanceMargin >= 0.9999) {
            dfSumFinanceMargin = 0.9999;
        }
        if (dfSumFinanceMargin <= -0.9999) {
            dfSumFinanceMargin = -0.9999;
        }
        if (dfSumRaMargin >= 0.9999) {
            dfSumRaMargin = 0.9999;
        }
        if (dfSumRaMargin <= -0.9999) {
            dfSumRaMargin = -0.9999;
        }
        // 20040802 ljq add e
        outObjectTmp.setBUKKENNO("合計");
        outObjectTmp.setLSKP(ls_kp);
        outObjectTmp.setBUKKENFR("" + nBukenFrm + "---" + nBukenTo);
        if (nSumContinueFlg == 0) {
            outObjectTmp.setBUKKENTO("(途中に欠番あり)");
        }
        //outObjectTmp.setDATEKENSH("");
        outObjectTmp.setPURCHASE("" + (long) dSumPurchase);
        //outObjectTmp.setQUANTITY("");
        //outObjectTmp.setSWPAY("" + strSwPayFlg);
        //outObjectTmp.setDATEPAYMT("");
        if ("L".equals(ls_kp)) {
            outObjectTmp.setREMAINVAL("" + (long) dSumRemainVal);
            outObjectTmp.setREMVALRT("" + LfcFrmComm.dround(dSumRemainVal / dSumPurchase * 100, 2));
            if (nDuraYMin == nDuraYMax) {
                outObjectTmp.setDURABLEY("" + nDuraYMin + "年");
            } else {
                outObjectTmp.setDURABLEY("" + nDuraYMin + "---" + nDuraYMax + "年、購入価格÷耐用年数での加重平均");
            }
            if (nLeaseMMin == nLeaseMMax) {
                outObjectTmp.setLEASEM("" + nLeaseMMin + "ヵ月");
            } else {
                outObjectTmp.setLEASEM("" + (long) nLeaseMMin + "---" + "" + (long) nLeaseMMax + "ヵ月");
            }
        }
        outObjectTmp.setRATEJLC("" + LfcFrmComm.dround(dSumRateJlc * 100, 5));
        outObjectTmp.setRATECADJ("" + LfcFrmComm.dround(dSumRateCof, 2));
        outObjectTmp.setRATEEANI("" + LfcFrmComm.dround(dSumRateEAni, 2));
        outObjectTmp.setRATEEAO("" + LfcFrmComm.dround(dSumRateEAO, 2));
        outObjectTmp.setRATEEAS("" + LfcFrmComm.dround(dSumRateEAS, 2));
        outObjectTmp.setRATELOSS("" + LfcFrmComm.dround(dSumRateLoss, 2));
        outObjectTmp.setRATEFEE("" + LfcFrmComm.dround(dSumRateFee, 2));
        outObjectTmp.setRATEFEEN("" + LfcFrmComm.dround(dSumRateFeeN, 2));
        outObjectTmp.setRATEFEER("" + LfcFrmComm.dround(dSumRateFeeR, 2));
        if (dDosoRtMin == dDosoRtMax) {
            outObjectTmp.setDOSORATE("" + dDosoRtMin);
        } else {
            outObjectTmp.setDOSORATE("" + dDosoRtMin + "---" + "" + dDosoRtMax);
        }

        //outObjectTmp.setSWSOFT("");
        if ("L".equals(ls_kp)) {
            outObjectTmp.setFIXASTTAX("" + (long) dSumFixasttax);
        }
        //outObjectTmp.setDOSOINDEX("");
        outObjectTmp.setDOSOFEE("" + (long) dDosoFEE);
        if (nSwBaisDisplayFlg == 0) {
            outObjectTmp.setSWBAISEKI("賠償責任保険対象物件を含む");
        }
        if (dDansRtMin == dDansRtMax) {
            outObjectTmp.setDANSHINRT("" + dDansRtMin);
        } else {
            outObjectTmp.setDANSHINRT("" + dDansRtMin + "---" + "" + dDansRtMax);
        }
        outObjectTmp.setMACHIFEE("" + (long) dMachiFEE);
        outObjectTmp.setFIREFEE("" + (long) dFireFEE);
        outObjectTmp.setETCFEE("" + (long) dEtcFEE);
        outObjectTmp.setICHIJI1("" + (long) dSumIchiji1);
        outObjectTmp.setICHIJI2("" + (long) dSumIchiji2);
        outObjectTmp.setICHIJI3("" + (long) dSumIchiji3);
        outObjectTmp.setKURINO1("" + (long) dSumKurino1);
        outObjectTmp.setKURINO2("" + (long) dSumKurino2);
        outObjectTmp.setHOSHURYO("" + (long) dSum_hoshuryo);
        outObjectTmp.setASSEN("" + (long) dSum_assen);
        outObjectTmp.setKAPPUINS("" + (long) dfSumKAPPU_INS);
        //outObjectTmp.setDATEINC0("");
        if ("L".equals(ls_kp)) {
            if (nInc_0_MMin == nInc_0_MMax) {
                outObjectTmp.setINC0M("" + (long) nInc_0_MMin + "ヵ月");
            } else {
                outObjectTmp.setINC0M("" + (long) nInc_0_MMin + "---" + "" + (long) nInc_0_MMax + "ヵ月");
            }
        }
        outObjectTmp.setINCOME0("" + (long) dSumIncome0);
        //outObjectTmp.setLEASED("");
        outObjectTmp.setEVENFLG("" + strLeaseEvenFlg);
        //outObjectTmp.setRYORITSUT_002("");
        //outObjectTmp.setRYORITSUM("");
        outObjectTmp.setRATEUNYO("" + LfcFrmComm.dround(dSumRateUnyo * 100, 2));
        outObjectTmp.setTRUERATE("" + LfcFrmComm.dround(dSumRateTrue * 100, 2));
        outObjectTmp.setRATEROI("" + LfcFrmComm.dround(dSumRateROI * 100, 2));
        outObjectTmp.setINTERESTP("" + (long) dSumInterestP);
        outObjectTmp.setINTERESTI("" + (long) dSumInterestI);
        outObjectTmp.setZAPI("" + (long) dSumZapi);
        //wanglin 20120312 S
        if ("L".equals(ls_kp)) {
            outObjectTmp.setRESERVEOUTN01("" + LfcFrmComm.dround(dSumRateEcol, 5));
            outObjectTmp.setRESERVEOUTN02("" + (long) dSumEcol);
            outObjectTmp.setRESERVEOUTN03("" + dSumCriTm);
        }
        //wanglin 20120312 E
        outObjectTmp.setINSURANCE("" + (long) dSumInsurance);
        outObjectTmp.setCOSTTOTAL("" + (long) dSumCostTotal);
        outObjectTmp.setCHARGE("" + (long) dSumCharge);
        outObjectTmp.setINCOMEGT("" + (long) dSumIncomeGt);
        outObjectTmp.setCADJUST("" + (long) dSumCAdjust);
        outObjectTmp.setPROFITT("" + (long) dSumProfitT);
        //outObjectTmp.setPROFITY("");
        outObjectTmp.setCAPITALT("" + (long) dSumCapitalT);
        //outObjectTmp.setRATPROT("");
        //outObjectTmp.setRATPROY("");
        outObjectTmp.setRATEYEAR("" + LfcFrmComm.dround(dSumRateYear * 100, 2));
        if (dSumAdjustM > 0) {
            outObjectTmp.setADJUSTM("支払期日は平均して、検収月の末日から" + (long) dSumAdjustM + "ヵ月");
            if (dSumAdjustD >= 0) {
                outObjectTmp.setADJUSTD("" + (long) dSumAdjustD + "日後");
            } else {
                outObjectTmp.setADJUSTD("" + (long) dSumAdjustD * (-1) + "日前");
            }
        } else {
            outObjectTmp.setADJUSTM("支払期日は平均して、検収月の末日から" + (long) dSumAdjustM * (-1) + "ヵ月");
            if (dSumAdjustD >= 0) {
                outObjectTmp.setADJUSTD("" + (long) dSumAdjustD + "日前");
            } else {
                outObjectTmp.setADJUSTD("" + (long) dSumAdjustD * (-1) + "日前");
            }
        }
        outObjectTmp.setINCOMET("" + (long) dfSumINCOMET);
        outObjectTmp.setINITCOST("" + (long) dSumINIT_COST);
        outObjectTmp.setEXECCOST("" + (long) dSumEXEC_COST);
        //outObjectTmp.setNETRATE("");
        outObjectTmp.setFINANCEMARGIN("" + LfcFrmComm.dround((dSumFinanceMargin) * 100, 2));
        outObjectTmp.setRateRAM("" + LfcFrmComm.dround(dSumRaMargin * 100, 2));
        outObjectTmp.setPVFINANCEMARGIN("" + (long) dSumPvFinanceMargin);
        outObjectTmp.setRAPVDirectM("" + (long) dSumRaPvMargin);
        if (nLeaveMMin == nLeaveMMax) {
            outObjectTmp.setLEAVEM("(据置月数)" + (long) nLeaveMMin + "ヵ月");
        } else {
            outObjectTmp.setLEAVEM("(据置月数)" + (long) nLeaveMMin + "---" + "" + (long) nLeaveMMax + "ヵ月");
        }
        outObjectTmp.setBAISFEE("" + (long) dSumBAIS_FEE);
        outObjectTmp.setPROFITY("" + (long) dSumF_PRO_Y);
        if ("L".equals(ls_kp)) {
            outObjectTmp.setDAMAGEBAS("" + (long) dSumDAMAGE_BAS);
            outObjectTmp.setDAMAGEFM("1---" + nSumDAMAGE_FMMAX);
            outObjectTmp.setDAMAGELM("" + (nSumDAMAGE_FMMAX + 1) + "---" + "" + (nSumDAMAGE_FMMAX + nSumDAMAGE_LMMAX));
            outObjectTmp.setDAMAGEFA("" + (long) dSumDAMAGE_FA);
            outObjectTmp.setDAMAGELA("" + (long) dSumDAMAGE_LA);
            outObjectTmp.setFINTERP("" + (long) dfSumInterestP);
            outObjectTmp.setFINTERI("" + (long) dSumF_INTER_I);
            outObjectTmp.setFCHARGE("" + (long) dFSumCharge);
            outObjectTmp.setFEXECC("" + (long) dSumF_EXEC_C);
            outObjectTmp.setFKURI1("" + (long) dSumF_KURI_1);
            outObjectTmp.setFINSUR("" + (long) dFSumInsurance);
            outObjectTmp.setFCOSTT("" + (long) dFSumCostTotal);
            outObjectTmp.setFPROT("" + (long) dSumF_PRO_T);
            outObjectTmp.setFPROY("" + (long) dfSumF_PRO_Y);
            outObjectTmp.setFCAPITT("" + (long) dfSumCapitalT);
            outObjectTmp.setFTRUERT("" + LfcFrmComm.dround((dfSumRateTrue) * 100, 2));
            outObjectTmp.setFRTYR("" + LfcFrmComm.dround((dfSumRateYear) * 100, 2));
            outObjectTmp.setFRTUN("" + LfcFrmComm.dround((dfSumRateUnyo) * 100, 2));
            //outObjectTmp.setFRTPRT("");
            //outObjectTmp.setFRTPRY("");
            outObjectTmp.setFRTROI("" + LfcFrmComm.dround(dfSumRateROI * 100, 2));
            outObjectTmp.setFFINANCEMARGIN("" + LfcFrmComm.dround((dfSumFinanceMargin) * 100, 2));
            outObjectTmp.setFRAMARGIN("" + LfcFrmComm.dround((dfSumRaMargin) * 100, 2));
            outObjectTmp.setFPVFINANCEMARGIN("" + (long) dfSumPvFinanceMargin);
            outObjectTmp.setFRAPVMARGIN("" + (long) dfSumRaPvMargin);
            outObjectTmp.setFPROE("" + LfcFrmComm.dround(dfSumROE * 100, 2));
        }
        //outObjectTmp.setSWSPRO("");
        outObjectTmp.setROE("" + LfcFrmComm.dround(dSumROE * 100, 2));

        bTotalPrice.setBukenRecord(outObjectTmp);

        return bTotalPrice;

    }

    /**
     * 物件ごとに入力データをチェックにおこなう
     * @param inputdate
     * @return
     * @throws Exception
     * @author 500501825
     */
    public BukenOutputResType doInputDatCheck(BukenOutputResType inputdate) throws Exception {
        BukenOutputResType bukenOutputRecode = new BukenOutputResType();
        bukenOutputRecode = inputdate;
        //物件ごとチェックを行う
        List<BukenOutputComplexType> listBuken = inputdate.getBukenOutput();
        if (!listBuken.isEmpty()) {
            Iterator<BukenOutputComplexType> iteBuken = listBuken.iterator();
            ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
            while (iteBuken.hasNext()) {
                boolean bChackFlg = true;
                BukenOutputComplexType bOutBukenTmp = iteBuken.next();
                outObjectTmp = bOutBukenTmp.getBukenRecord();
                PaydivInOutRecord PaydivObjectTmp = bOutBukenTmp.getShiharaiRecord();
                //リース物件･割賦物件の区分をチェックに行う
                if (outObjectTmp.getLSKP() == null || "".equals(outObjectTmp.getLSKP()) ||
                        (!"L".equals(outObjectTmp.getLSKP().toString().toUpperCase()) &&
                        !"S".equals(outObjectTmp.getLSKP().toString().toUpperCase()))) {
                    _outErrorMsgRecord=LfcLogicComm.setErrMsgRecord(bOutBukenTmp, "E0095", LfcFrmMsgConst.E0095,_outErrorMsgRecord);
                    cearErrorMsgList();
                    bChackFlg = false;
                    bOutBukenTmp.setCheckAttribute(bChackFlg);
                }
                if (bChackFlg) {
                    ArrayList<ErrorInforOutputComplexType> errMsgConditon = doCalConditonCheck(outObjectTmp, PaydivObjectTmp);
                    if (errMsgConditon.isEmpty()) {
                        //リース物件をチェックに行う
                        if (bChackFlg && "L".equals(outObjectTmp.getLSKP().toString().toUpperCase())) {
                            //計算ためにロジックチェック
                            ArrayList<ErrorInforOutputComplexType> errMsgLS = doCalCheckLS(bOutBukenTmp);
                            if (errMsgLS.isEmpty()) {
                                bOutBukenTmp.setCheckAttribute(bChackFlg);
                            } else {
                                bChackFlg = false;
                                bOutBukenTmp.setCheckAttribute(bChackFlg);
                                //setErrorMsgList(errMsgLS);
                                _outErrorMsgRecord=LfcLogicComm.setErrorMsgList(errMsgLS,_outErrorMsgRecord);
                                bOutBukenTmp.setErrorRecord(_outErrorMsgRecord);
                                cearErrorMsgList();
                            }
                        } //割賦物件をチェックに行う
                        else if (bChackFlg && "S".equals(outObjectTmp.getLSKP().toString().toUpperCase())) {
                            //計算ためにロジックチェック
                            ArrayList<ErrorInforOutputComplexType> errMsgKS = doCalCheckKP(bOutBukenTmp);
                            if (errMsgKS.isEmpty()) {
                                bOutBukenTmp.setCheckAttribute(bChackFlg);
                            } else {
                                bChackFlg = false;
                                bOutBukenTmp.setCheckAttribute(bChackFlg);
                                _outErrorMsgRecord=LfcLogicComm.setErrorMsgList(errMsgKS,_outErrorMsgRecord);
                                bOutBukenTmp.setErrorRecord(_outErrorMsgRecord);
                                cearErrorMsgList();
                            }
                        }
                    } else {
                        bChackFlg = false;
                        bOutBukenTmp.setCheckAttribute(bChackFlg);
                        _outErrorMsgRecord=LfcLogicComm.setErrorMsgList(errMsgConditon,_outErrorMsgRecord);
                        bOutBukenTmp.setErrorRecord(_outErrorMsgRecord);
                        cearErrorMsgList();
                    }
                }
            }
        }
        //計算用データを物件、支払、回収配列に格納する
        try {
            // getWebServiceResults(bukenOutputRecode);
        } catch (Exception e) {
            e.printStackTrace();
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("ObjectBean", //クラス名
                    "getQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
        }
        return bukenOutputRecode;
    }

    /**
     *　物件ごとに計算する
     * @param inputdate
     * @return
     * @throws Exception
     * @author 500501825
     */
    public BukenOutputResType doCalculatePrice(BukenOutputResType inputdate) throws Exception {
        BukenOutputResType bukenOutputRecode = new BukenOutputResType();
        bukenOutputRecode = inputdate;
        //物件ごと計算を行う
        cearErrorMsgList();
        List<BukenOutputComplexType> listBuken = inputdate.getBukenOutput();
        if (!listBuken.isEmpty()) {
            Iterator<BukenOutputComplexType> iteBuken = listBuken.iterator();
            ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
            while (iteBuken.hasNext()) {
                boolean bCalculateFlg = true;
                BukenOutputComplexType bOutBukenTmp = iteBuken.next();
                outObjectTmp = bOutBukenTmp.getBukenRecord();
                if (bOutBukenTmp.isCheckAttribute()) {
                    //リース物件を計算に行う
                    if ("L".equals(outObjectTmp.getLSKP().toString())) {
                        bCalculateFlg = LsCalcStart(bOutBukenTmp);
                        if (!bCalculateFlg) {
                            ErrorInforOutputRecord outErrRecord = new ErrorInforOutputRecord();
                            outErrRecord = getErrorMsgRecord();
                            List<ErrorInforOutputComplexType> listErr = outErrRecord.getErrorInforOutput();
                            Iterator<ErrorInforOutputComplexType> iterator = listErr.iterator();
                            while (iterator.hasNext()) {
                                ErrorInforOutputComplexType tempErrorOutputObject = iterator.next();
                                if ("WRN".equals(tempErrorOutputObject.getERRORNO().substring(0, 3))) {
                                    bCalculateFlg = true;
                                    break;
                                }
                            }
                            if (!outErrRecord.getErrorInforOutput().isEmpty()) {
                                bOutBukenTmp.setErrorRecord(outErrRecord);
                            }
                        }
                        if (bCalculateFlg) {
                            bOutBukenTmp.setCalculateAttribute(bCalculateFlg);
                            //計算結果GCALをOUTの物件レコードに格納する
                            outObjectTmp = setBukenCalcuReslult(bOutBukenTmp);
                            //計算結果StairをOUTの回収レコードに格納する
                            if (_nReqItem == LfcLogicPgConst.CAL_ITEM_KINGAKU ||
                                    _nReqItem == LfcLogicPgConst.CAL_ITEM_KAISU) {
                                //回収金額算出,回収回数逆算時は回収情報を再設定する
                                bOutBukenTmp = setKaisyuCalcuReslult(bOutBukenTmp);
                            }
                        } else {
                            bCalculateFlg = false;
                            bOutBukenTmp.setCalculateAttribute(bCalculateFlg);
                            //エラー情報をOUTPUTに格納する
                            ErrorInforOutputRecord outErrRecord = new ErrorInforOutputRecord();
                            outErrRecord = getErrorMsgRecord();
                            if (!outErrRecord.getErrorInforOutput().isEmpty()) {
                                bOutBukenTmp.setErrorRecord(outErrRecord);
                            }
                        }
                        cearErrorMsgList();
                    } else {
                        bCalculateFlg = KpCalcStart(bOutBukenTmp);
                        if (!bCalculateFlg) {
                            ErrorInforOutputRecord outErrRecord = new ErrorInforOutputRecord();
                            outErrRecord = getErrorMsgRecord();
                            List<ErrorInforOutputComplexType> listErr = outErrRecord.getErrorInforOutput();
                            Iterator<ErrorInforOutputComplexType> iterator = listErr.iterator();
                            while (iterator.hasNext()) {
                                ErrorInforOutputComplexType tempErrorOutputObject = iterator.next();
                                if ("WRN".equals(tempErrorOutputObject.getERRORNO().substring(0, 3))) {
                                    bCalculateFlg = true;
                                    break;
                                }
                            }
                            if (!outErrRecord.getErrorInforOutput().isEmpty()) {
                                bOutBukenTmp.setErrorRecord(outErrRecord);
                            }
                        }
                        if (bCalculateFlg) {
                            bOutBukenTmp.setCalculateAttribute(bCalculateFlg);
                            //計算結果GCALをOUTの物件レコードに格納する
                            outObjectTmp = setBukenCalcuReslult(bOutBukenTmp);
                            //計算結果StairをOUTの回収レコードに格納する
                            if (_nReqItem == LfcLogicPgConst.KAP_ITEM_KINGAKU ||
                                    _nReqItem == LfcLogicPgConst.KAP_ITEM_KINGAKU_INC0 ||
                                    _nReqItem== LfcLogicPgConst.KAP_ITEM_KAISU) {
                                //回収金額算出,回収金額.頭金算出,回収回数逆算時は回収情報を再設定する
                                bOutBukenTmp = setKaisyuCalcuReslult(bOutBukenTmp);
                            }
                        } else {
                            bCalculateFlg = false;
                            bOutBukenTmp.setCalculateAttribute(bCalculateFlg);
                            //エラー情報をOUTPUTに格納する
                            ErrorInforOutputRecord outErrRecord = new ErrorInforOutputRecord();
                            outErrRecord = getErrorMsgRecord();
                            if (!outErrRecord.getErrorInforOutput().isEmpty()) {
                                bOutBukenTmp.setErrorRecord(outErrRecord);
                            }
                        }
                    }
                    cearErrorMsgList();
                }
            }
        }
        //計算用データを物件、支払、回収配列に格納する
        try {
            // getWebServiceResults(bukenOutputRecode);
        } catch (Exception e) {
            e.printStackTrace();
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("ObjectBean", //クラス名
                    "getQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
        }
        return bukenOutputRecode;
    }

    public BukenOutputComplexType setKaisyuCalcuReslult(BukenOutputComplexType bOutBukenTmp) {
        CollectionInOutRecord outCollectionRecord = new CollectionInOutRecord();
        outCollectionRecord = bOutBukenTmp.getKaisyuRecord();
        outCollectionRecord.getKaishuInOut().clear();
        _stairs.getRowCount();
        for (int i = 0; i < _stairs.getRowCount(); i++) {
            CollectionComplexType outCollTmp = new CollectionComplexType();
            outCollTmp.setCYCLE("" + _stairs.getCycle(i));
            outCollTmp.setFREQUE("" + _stairs.getFreque(i));
            outCollTmp.setINCOME("" + _stairs.getIncome(i));
            outCollTmp.setKAISYUDATE("" + _stairs.getDateYY(i) + _stairs.getDateMM(i) + _stairs.getDateDD(i));
            outCollectionRecord.getKaishuInOut().add(outCollTmp);
        }
        bOutBukenTmp.setKaisyuRecord(outCollectionRecord);
        return bOutBukenTmp;

    }

    public ObjectOutputComplexType setBukenCalcuReslult(BukenOutputComplexType bOutBukenTmp) {
        ObjectOutputComplexType outObjectTmp = bOutBukenTmp.getBukenRecord();
        outObjectTmp.setRECORDNO("" + _gcal.getRecno());
        outObjectTmp.setBUKKENFR("" + _gcal.getBukkenF());
        outObjectTmp.setBUKKENTO("" + _gcal.getBukkenT());
        outObjectTmp.setDATEKENSH("" + _gcal.getDKensh());
        outObjectTmp.setPURCHASE("" + LfcFrmComm.maxAdjust(_gcal.getPurchas(), 11));
        outObjectTmp.setQUANTITY("" + _gcal.getQuant());
        if (_gcal.getSwPay()) {
            outObjectTmp.setSWPAY("2");
        } else {
            outObjectTmp.setSWPAY("1");
        }
        //outObjectTmp.setDATEPAYMT("" + _gcal.getDPaymt());
        outObjectTmp.setREMAINVAL("" + LfcFrmComm.maxAdjust(_gcal.getRemVAL(), 11));
        outObjectTmp.setREMVALRT("" + LfcLogicComm.dround(_gcal.getRemVRT() * 100, 4));
        outObjectTmp.setDURABLEY("" + LfcFrmComm.maxAdjust(_gcal.getDuraY(), 3));
        outObjectTmp.setLEASEM("" + LfcFrmComm.maxAdjust(_gcal.getLeaseM(), 3));
        if (_gcal.getKeiyaku() != null && !"".equals(_gcal.getKeiyaku())) {
                if (_gcal.getKeiyaku().charAt(0) == 'S') {
                outObjectTmp.setLEASEM("" + LfcFrmComm.maxAdjust(_gcal.getKappuM(), 3));
                }
        }
        outObjectTmp.setRATEJLC("" + LfcLogicComm.dround(_gcal.getRateJL() * 100, 4));
        outObjectTmp.setRATECADJ("" + LfcLogicComm.dround(_gcal.getRateCADJ() * 100, 4));
        outObjectTmp.setRATEEANI("" + LfcLogicComm.dround(_gcal.getRtEAniTotal() * 100, 4));
        outObjectTmp.setRATEEAO("" + LfcLogicComm.dround(_gcal.getRtEAniO() * 100, 4));
        outObjectTmp.setRATEEAS("" + LfcLogicComm.dround(_gcal.getRtEAniS() * 100, 4));
        outObjectTmp.setRATELOSS("" + LfcLogicComm.dround(_gcal.getRtLossR() * 100, 4));
        outObjectTmp.setCSTKISHUCD("" + _gcal.getCstKishuCD());
        outObjectTmp.setRATEFEE("" + LfcLogicComm.dround(_gcal.getRtFeeTotal() * 100, 4));
        outObjectTmp.setRATEFEEN("" + LfcLogicComm.dround(_gcal.getRtFeeN() * 100, 4));
        outObjectTmp.setRATEFEER("" + LfcLogicComm.dround(_gcal.getRtFeeR() * 100, 4));
        outObjectTmp.setDOSORATE("" + LfcLogicComm.dround(_gcal.getDosoRt(), 4));
        outObjectTmp.setSWSOFT("" + _gcal.getSwSoft());
        outObjectTmp.setFIXASTTAX("" + LfcFrmComm.maxAdjust(_gcal.getFatax(), 11));
        outObjectTmp.setDOSOINDEX(String.valueOf(LfcLogicComm.dround(_gcal.getDosoIx(), 5)));
        outObjectTmp.setDOSOFEE("" + LfcFrmComm.maxAdjust(_gcal.getDosoF(), 9));
        outObjectTmp.setSWBAISEKI("" + _gcal.getSwBais());
        outObjectTmp.setDANSHINRT("" + LfcFrmComm.maxAdjust(_gcal.getDansRt(), 9));
        outObjectTmp.setMACHIFEE("" + LfcFrmComm.maxAdjust(_gcal.getMachiF(), 9));
        outObjectTmp.setFIREFEE("" + LfcFrmComm.maxAdjust(_gcal.getFireF(), 9));
        outObjectTmp.setETCFEE("" + LfcFrmComm.maxAdjust(_gcal.getEtcF(), 9));
        outObjectTmp.setICHIJI1("" + LfcFrmComm.maxAdjust(_gcal.getIchiji1(), 9));
        outObjectTmp.setICHIJI2("" + LfcFrmComm.maxAdjust(_gcal.getIchiji2(), 9));
        outObjectTmp.setICHIJI3("" + LfcFrmComm.maxAdjust(_gcal.getIchiji3(), 9));
        outObjectTmp.setKURINO1("" + LfcFrmComm.maxAdjust(_gcal.getKurino1(), 9));
        outObjectTmp.setKURINO2("" + LfcFrmComm.maxAdjust(_gcal.getKurino2(), 9));
        outObjectTmp.setHOSHURYO("" + LfcFrmComm.maxAdjust(_gcal.getHoshury(), 9));
        outObjectTmp.setASSEN("" + LfcFrmComm.maxAdjust(_gcal.getAssen(), 9));
        outObjectTmp.setKAPPUINS("" + LfcFrmComm.maxAdjust(_gcal.getHoshury(), 9));
        if (_gcal.getInc0() > 0 || _gcal.getInc0M() > 0) {
            outObjectTmp.setDATEINC0("" + _gcal.getDInc0());
        }
        outObjectTmp.setINCOME0("" + LfcFrmComm.maxAdjust(_gcal.getInc0(), 9));
        outObjectTmp.setINC0M("" + LfcFrmComm.maxAdjust(_gcal.getInc0M(), 9));
        outObjectTmp.setLEASED("" + LfcFrmComm.maxAdjust(_gcal.getLeaseD(), 3));
        outObjectTmp.setEVENFLG("" + LfcFrmComm.maxAdjust(_gcal.getEvenFlg(), 3));
        outObjectTmp.setRYORITSUT("" + LfcLogicComm.dround(_gcal.getRyortT() * 100, 4));
        outObjectTmp.setRYORITSUM("" + LfcLogicComm.dround(_gcal.getRyortM() * 100, 4));
        outObjectTmp.setRATEUNYO("" + LfcLogicComm.dround(_gcal.getRateUN() * 100, 4));
        outObjectTmp.setTRUERATE("" + LfcLogicComm.dround(_gcal.getTrueRT() * 100, 4));
        outObjectTmp.setRATEROI("" + LfcLogicComm.dround(_gcal.getRateROI() * 100, 4));
        outObjectTmp.setINTERESTP("" + LfcFrmComm.maxAdjust(_gcal.getInterP(), 11));
        outObjectTmp.setINTERESTI("" + LfcFrmComm.maxAdjust(_gcal.getInterI(), 11));
        outObjectTmp.setZAPI("" + LfcFrmComm.maxAdjust(_gcal.getZappi(), 11));
        //wanglin 20120312 S
        if (_gcal.getKeiyaku().charAt(0) == 'L') {
            outObjectTmp.setRESERVEOUTN01("" + LfcLogicComm.dround(_gcal.getCriRt(), 5));
            outObjectTmp.setRESERVEOUTN02("" + LfcFrmComm.maxAdjust(_gcal.getCriF(), 11));
            outObjectTmp.setRESERVEOUTN03("" + LfcFrmComm.maxAdjust(_gcal.getCriTm(), 3));
        }
        //wanglin 20120312 E
        outObjectTmp.setINSURANCE("" + LfcFrmComm.maxAdjust(_gcal.getInsur(), 11));
        outObjectTmp.setCOSTTOTAL("" + LfcFrmComm.maxAdjust(_gcal.getCostT(), 11));
        outObjectTmp.setCHARGE("" + LfcFrmComm.maxAdjust(_gcal.getCharge(), 11));
        outObjectTmp.setINCOMEGT("" + LfcFrmComm.maxAdjust(_gcal.getIncGt(), 11));
        outObjectTmp.setCADJUST("" + LfcFrmComm.maxAdjust(_gcal.getCAdj(), 11));
        outObjectTmp.setPROFITT("" + LfcFrmComm.maxAdjust(_gcal.getProfT(), 11));
        outObjectTmp.setPROFITY("" + LfcFrmComm.maxAdjust(_gcal.getProfY(), 11));
        outObjectTmp.setCAPITALT("" + LfcFrmComm.maxAdjust(_gcal.getCapitT(), 11));
        outObjectTmp.setRATPROT("" + LfcLogicComm.dround(_gcal.getRtPrT() * 100, 4));
        outObjectTmp.setRATPROY("" + LfcLogicComm.dround(_gcal.getRtPrY() * 100, 4));
        outObjectTmp.setRATEYEAR("" + LfcLogicComm.dround(_gcal.getRateYr() * 100, 4));
        outObjectTmp.setADJUSTM("" + LfcFrmComm.maxAdjust(_gcal.getAdjM(), 3));
        outObjectTmp.setADJUSTD("" + LfcFrmComm.maxAdjust(_gcal.getAdjD(), 3));
        outObjectTmp.setINCOMET("" + LfcFrmComm.maxAdjust(_gcal.getIncGt(), 11));
        outObjectTmp.setINITCOST("" + LfcFrmComm.maxAdjust(_gcal.getInitC(), 11));
        outObjectTmp.setEXECCOST("" + LfcFrmComm.maxAdjust(_gcal.getExecC(), 11));
        outObjectTmp.setNETRATE("" + _gcal.getNetRt());
        outObjectTmp.setFINANCEMARGIN("" + LfcLogicComm.dround(_gcal.getFinanceMargin() * 100, 4));
        outObjectTmp.setRateRAM("" + LfcLogicComm.dround(_gcal.getRaMargin() * 100, 4));
        outObjectTmp.setPVFINANCEMARGIN("" + LfcFrmComm.maxAdjust(_gcal.getPvFinanceMargin(), 11));
        outObjectTmp.setRAPVDirectM("" + LfcFrmComm.maxAdjust(_gcal.getRaPvMargin(), 11));
        outObjectTmp.setLEAVEM("" + LfcFrmComm.maxAdjust(_gcal.getLeaveM(), 3));
        outObjectTmp.setBAISFEE("" + LfcFrmComm.maxAdjust(_gcal.getBaisF(), 11));
        outObjectTmp.setDAMAGEBAS("" + LfcFrmComm.maxAdjust(_gcal.getDamBas(), 11));
        outObjectTmp.setDAMAGEFM("" + LfcFrmComm.maxAdjust(_gcal.getDamFm(), 11));
        outObjectTmp.setDAMAGELM("" + LfcFrmComm.maxAdjust(_gcal.getDamLm(), 11));
        outObjectTmp.setDAMAGEFA("" + LfcFrmComm.maxAdjust(_gcal.getDamFa(), 11));
        outObjectTmp.setDAMAGELA("" + LfcFrmComm.maxAdjust(_gcal.getDamLa(), 11));
        outObjectTmp.setFINTERP("" + LfcFrmComm.maxAdjust(_gcal.getFIntP(), 11));
        outObjectTmp.setFINTERI("" + LfcFrmComm.maxAdjust(_gcal.getFIntI(), 11));
        outObjectTmp.setFCHARGE("" + LfcFrmComm.maxAdjust(_gcal.getFCharge(), 11));
        outObjectTmp.setFEXECC("" + LfcFrmComm.maxAdjust(_gcal.getFExecC(), 11));
        outObjectTmp.setFKURI1("" + LfcFrmComm.maxAdjust(_gcal.getFKuri1(), 11));
        outObjectTmp.setFINSUR("" + LfcFrmComm.maxAdjust(_gcal.getFInsur(), 11));
        outObjectTmp.setFCOSTT("" + LfcFrmComm.maxAdjust(_gcal.getFCostT(), 11));
        outObjectTmp.setFPROT("" + LfcFrmComm.maxAdjust(_gcal.getFProT(), 11));
        outObjectTmp.setFPROY("" + LfcFrmComm.maxAdjust(_gcal.getFProY(), 11));
        outObjectTmp.setFCAPITT("" + LfcFrmComm.maxAdjust(_gcal.getFCapT(), 11));
        outObjectTmp.setFTRUERT("" + LfcLogicComm.dround(_gcal.getFTrueRT() * 100, 4));
        outObjectTmp.setFRTYR("" + LfcLogicComm.dround(_gcal.getFRtYr() * 100, 4));
        outObjectTmp.setFRTUN("" + LfcLogicComm.dround(_gcal.getFRtUn() * 100, 4));
        outObjectTmp.setFRTPRT("" + LfcLogicComm.dround(_gcal.getFRtPrt() * 100, 4));
        outObjectTmp.setFRTPRY("" + LfcLogicComm.dround(_gcal.getFRtPry() * 100, 4));
        outObjectTmp.setFRTROI("" + LfcLogicComm.dround(_gcal.getFRtRoi() * 100, 4));
        outObjectTmp.setFFINANCEMARGIN("" + LfcLogicComm.dround(_gcal.getFFinanceMargin() * 100, 4));
        outObjectTmp.setFRAMARGIN("" + LfcLogicComm.dround(_gcal.getFRaMargin() * 100, 4));
        outObjectTmp.setFPVFINANCEMARGIN("" + LfcFrmComm.maxAdjust(_gcal.getFPvFinanceMargin(), 11));
        outObjectTmp.setFRAPVMARGIN("" + LfcFrmComm.maxAdjust(_gcal.getFRaPvMargin(), 11));
        outObjectTmp.setSWSPRO("" + _gcal.getSwSPro());
        outObjectTmp.setROE("" + LfcLogicComm.dround(_gcal.getROE() * 100, 4));
        outObjectTmp.setFPROE("" + LfcLogicComm.dround(_gcal.getFROE() * 100, 4));
        return outObjectTmp;
    }

    /**
     *
     * @param inputdate
     * @return
     */
    public String[][] getWebServiceResults(BukenOutputResType inputdate) {
        int index_input = 0;
        int index_Kaisyu = 0;
        int index_Paydiv = 0;
        BukenOutputResType BukenInputRecord = new BukenOutputResType();
        BukenInputRecord = inputdate;
        List<BukenOutputComplexType> listBuken = inputdate.getBukenOutput();
        Iterator<BukenOutputComplexType> iteBuken = listBuken.iterator();
        int nlenBuken = listBuken.size();
        String[][] strResults = new String[nlenBuken][OBJECT_RECORD_COUNT];
        ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
        for (index_input = 0; index_input < nlenBuken; index_input++) {
            BukenOutputComplexType bOutBukenTmp = iteBuken.next();
            outObjectTmp = bOutBukenTmp.getBukenRecord();
            strResults[index_input][OBJECT_REC_NO] = outObjectTmp.getRECORDNO();
            strResults[index_input][OBJECT_BUKKEN_NO] = "" + (index_input + 1);
            strResults[index_input][OBJECT_BUKKEN_FR] = outObjectTmp.getBUKKENFR();
            strResults[index_input][OBJECT_BUKKEN_TO] = outObjectTmp.getBUKKENTO();
            strResults[index_input][OBJECT_DATE_KENSH] = outObjectTmp.getDATEKENSH();
            strResults[index_input][OBJECT_PURCHASE] = outObjectTmp.getPURCHASE();
            strResults[index_input][OBJECT_QUANTITY] = outObjectTmp.getQUANTITY();
            strResults[index_input][OBJECT_SW_PAY] = outObjectTmp.getSWPAY();
            strResults[index_input][OBJECT_DATE_PAYMT] = outObjectTmp.getDATEPAYMT();
            strResults[index_input][OBJECT_REMAIN_VAL] = outObjectTmp.getREMAINVAL();
            strResults[index_input][OBJECT_REM_VAL_RT] = outObjectTmp.getREMVALRT();
            strResults[index_input][OBJECT_DURABLE_Y] = outObjectTmp.getDURABLEY();
            strResults[index_input][OBJECT_LEASE_M] = outObjectTmp.getLEASEM();
            strResults[index_input][OBJECT_RATE_JLC] = outObjectTmp.getRATEJLC();
            strResults[index_input][OBJECT_RATE_C_ADJ] = outObjectTmp.getRATECADJ();
            strResults[index_input][OBJECT_RATE_E_ANI] = outObjectTmp.getRATEEANI();
            strResults[index_input][OBJECT_RATE_E_A_O] = outObjectTmp.getRATEEAO();
            strResults[index_input][OBJECT_RATE_E_A_S] = outObjectTmp.getRATEEAS();
            strResults[index_input][OBJECT_RATE_LOSS] = outObjectTmp.getRATELOSS();
            strResults[index_input][OBJECT_CSTKISHUCD] = outObjectTmp.getCSTKISHUCD();
            strResults[index_input][OBJECT_RATE_FEE] = outObjectTmp.getRATEFEE();
            strResults[index_input][OBJECT_RATE_FEE_N] = outObjectTmp.getRATEFEEN();
            strResults[index_input][OBJECT_RATE_FEE_R] = outObjectTmp.getRATEFEER();
            strResults[index_input][OBJECT_DOSO_RATE] = outObjectTmp.getDOSORATE();
            strResults[index_input][OBJECT_SW_SOFT] = outObjectTmp.getSWSOFT();
            strResults[index_input][OBJECT_FIXASTTAX] = outObjectTmp.getFIXASTTAX();
            strResults[index_input][OBJECT_DOSO_INDEX] = outObjectTmp.getDOSOINDEX();
            strResults[index_input][OBJECT_DOSO_FEE] = outObjectTmp.getDOSOFEE();
            strResults[index_input][OBJECT_SW_BAISEKI] = outObjectTmp.getSWBAISEKI();
            strResults[index_input][OBJECT_DANSHIN_RT] = outObjectTmp.getDANSHINRT();
            strResults[index_input][OBJECT_MACHI_FEE] = outObjectTmp.getMACHIFEE();
            strResults[index_input][OBJECT_FIRE_FEE] = outObjectTmp.getFIREFEE();
            strResults[index_input][OBJECT_ETC_FEE] = outObjectTmp.getETCFEE();
            strResults[index_input][OBJECT_ICHIJI_1] = outObjectTmp.getICHIJI1();
            strResults[index_input][OBJECT_ICHIJI_2] = outObjectTmp.getICHIJI2();
            strResults[index_input][OBJECT_ICHIJI_3] = outObjectTmp.getICHIJI3();
            strResults[index_input][OBJECT_KURINO_1] = outObjectTmp.getKURINO1();
            strResults[index_input][OBJECT_KURINO_2] = outObjectTmp.getKURINO2();
            strResults[index_input][OBJECT_HOSHURYO] = outObjectTmp.getHOSHURYO();
            strResults[index_input][OBJECT_ASSEN] = outObjectTmp.getASSEN();
            strResults[index_input][OBJECT_KAPPU_INS] = outObjectTmp.getKAPPUINS();
            strResults[index_input][OBJECT_DATE_INC_0] = outObjectTmp.getDATEINC0();
            strResults[index_input][OBJECT_INCOME_0] = outObjectTmp.getINCOME0();
            strResults[index_input][OBJECT_INC_0_M] = outObjectTmp.getINC0M();
            strResults[index_input][OBJECT_LEASE_D] = outObjectTmp.getLEASED();
            strResults[index_input][OBJECT_EVEN_FLG] = outObjectTmp.getEVENFLG();
            strResults[index_input][OBJECT_RYORITSU_T] = outObjectTmp.getRYORITSUT();
            strResults[index_input][OBJECT_RYORITSU_M] = outObjectTmp.getRYORITSUM();
            strResults[index_input][OBJECT_RATE_UNYO] = outObjectTmp.getRATEUNYO();
            strResults[index_input][OBJECT_TRUE_RATE] = outObjectTmp.getTRUERATE();
            strResults[index_input][OBJECT_RATE_ROI] = outObjectTmp.getRATEROI();
            strResults[index_input][OBJECT_INTEREST_P] = outObjectTmp.getINTERESTP();
            strResults[index_input][OBJECT_INTEREST_I] = outObjectTmp.getINTERESTI();
            strResults[index_input][OBJECT_ZAPI] = outObjectTmp.getZAPI();
            //wanglin 20120312 S
             strResults[index_input][OBJECT_CRE_INS_RT] = outObjectTmp.getRESERVEOUTN01();
             strResults[index_input][OBJECT_CREDIT_INS] = outObjectTmp.getRESERVEOUTN02();
             strResults[index_input][OBJECT_CRE_INS_TM] = outObjectTmp.getRESERVEOUTN03();
            //wanglin 20120312 E
            strResults[index_input][OBJECT_INSURANCE] = outObjectTmp.getINSURANCE();
            strResults[index_input][OBJECT_COST_TOTAL] = outObjectTmp.getCOSTTOTAL();
            strResults[index_input][OBJECT_CHARGE] = outObjectTmp.getCHARGE();
            strResults[index_input][OBJECT_INCOME_GT] = outObjectTmp.getINCOMEGT();
            strResults[index_input][OBJECT_C_ADJUST] = outObjectTmp.getCADJUST();
            strResults[index_input][OBJECT_PROFIT_T] = outObjectTmp.getPROFITT();
            strResults[index_input][OBJECT_PROFIT_Y] = outObjectTmp.getPROFITY();
            strResults[index_input][OBJECT_CAPITAL_T] = outObjectTmp.getCAPITALT();
            strResults[index_input][OBJECT_RAT_PRO_T] = outObjectTmp.getRATPROT();
            strResults[index_input][OBJECT_RAT_PRO_Y] = outObjectTmp.getRATPROY();
            strResults[index_input][OBJECT_RATE_YEAR] = outObjectTmp.getRATEYEAR();
            strResults[index_input][OBJECT_ADJUST_M] = outObjectTmp.getADJUSTM();
            strResults[index_input][OBJECT_ADJUST_D] = outObjectTmp.getADJUSTD();
            strResults[index_input][OBJECT_INCOME_T] = outObjectTmp.getINCOMET();
            strResults[index_input][OBJECT_INIT_COST] = outObjectTmp.getINITCOST();
            strResults[index_input][OBJECT_EXEC_COST] = outObjectTmp.getEXECCOST();
            strResults[index_input][OBJECT_NET_RATE] = outObjectTmp.getNETRATE();
            strResults[index_input][OBJECT_FINANCE_MARGIN] = outObjectTmp.getFINANCEMARGIN();
            strResults[index_input][OBJECT_RA_MARGIN] = outObjectTmp.getRateRAM();
            strResults[index_input][OBJECT_PV_FINANCE_MARGIN] = outObjectTmp.getPVFINANCEMARGIN();
            strResults[index_input][OBJECT_RA_PV_MARGIN] = outObjectTmp.getRAPVDirectM();
            strResults[index_input][OBJECT_LEAVE_M] = outObjectTmp.getLEAVEM();
            strResults[index_input][OBJECT_BAIS_FEE] = outObjectTmp.getBAISFEE();
            strResults[index_input][OBJECT_DAMAGE_BAS] = outObjectTmp.getDAMAGEBAS();
            strResults[index_input][OBJECT_DAMAGE_FM] = outObjectTmp.getDAMAGEFM();
            strResults[index_input][OBJECT_DAMAGE_LM] = outObjectTmp.getDAMAGELM();
            strResults[index_input][OBJECT_DAMAGE_FA] = outObjectTmp.getDAMAGEFA();
            strResults[index_input][OBJECT_DAMAGE_LA] = outObjectTmp.getDAMAGELA();
            strResults[index_input][OBJECT_F_INTER_P] = outObjectTmp.getFINTERP();
            strResults[index_input][OBJECT_F_INTER_I] = outObjectTmp.getFINTERI();
            strResults[index_input][OBJECT_F_CHARGE] = outObjectTmp.getFCHARGE();
            strResults[index_input][OBJECT_F_EXEC_C] = outObjectTmp.getFEXECC();
            strResults[index_input][OBJECT_F_KURI_1] = outObjectTmp.getFKURI1();
            strResults[index_input][OBJECT_F_INSUR] = outObjectTmp.getFINSUR();
            strResults[index_input][OBJECT_F_COST_T] = outObjectTmp.getFCOSTT();
            strResults[index_input][OBJECT_F_PRO_T] = outObjectTmp.getFPROT();
            strResults[index_input][OBJECT_F_PRO_Y] = outObjectTmp.getFPROY();
            strResults[index_input][OBJECT_F_CAPIT_T] = outObjectTmp.getFCAPITT();
            strResults[index_input][OBJECT_F_TRUE_RT] = outObjectTmp.getFTRUERT();
            strResults[index_input][OBJECT_F_RT_YR] = outObjectTmp.getFRTYR();
            strResults[index_input][OBJECT_F_RT_UN] = outObjectTmp.getFRTUN();
            strResults[index_input][OBJECT_F_RT_PRT] = outObjectTmp.getFRTPRT();
            strResults[index_input][OBJECT_F_RT_PRY] = outObjectTmp.getFRTPRY();
            strResults[index_input][OBJECT_F_RT_ROI] = outObjectTmp.getFRTROI();
            strResults[index_input][OBJECT_F_FINANCE_MARGIN] = outObjectTmp.getFFINANCEMARGIN();
            strResults[index_input][OBJECT_F_RA_MARGIN] = outObjectTmp.getFRAMARGIN();
            strResults[index_input][OBJECT_F_PV_FINANCE_MARGIN] = outObjectTmp.getFPVFINANCEMARGIN();
            strResults[index_input][OBJECT_F_RA_PV_MARGIN] = outObjectTmp.getFRAPVMARGIN();
            strResults[index_input][OBJECT_SW_S_PRO] = outObjectTmp.getSWSPRO();
            strResults[index_input][OBJECT_ROE] = outObjectTmp.getROE();
            strResults[index_input][OBJECT_FP_ROE] = outObjectTmp.getFPROE();
            strResults[index_input][OBJECT_RESERVE_N_01] = outObjectTmp.getRESERVEOUTN01();
            strResults[index_input][OBJECT_RESERVE_N_02] = outObjectTmp.getRESERVEOUTN02();
            strResults[index_input][OBJECT_RESERVE_N_03] = outObjectTmp.getRESERVEOUTN03();
            strResults[index_input][OBJECT_RESERVE_N_04] = outObjectTmp.getRESERVEOUTN04();
            strResults[index_input][OBJECT_RESERVE_N_05] = outObjectTmp.getRESERVEOUTN05();
            strResults[index_input][OBJECT_RESERVE_N_06] = outObjectTmp.getRESERVEOUTN06();
            strResults[index_input][OBJECT_RESERVE_N_07] = outObjectTmp.getRESERVEOUTN07();
            strResults[index_input][OBJECT_RESERVE_N_08] = outObjectTmp.getRESERVEOUTN08();
            strResults[index_input][OBJECT_RESERVE_N_09] = outObjectTmp.getRESERVEOUTN09();
            strResults[index_input][OBJECT_RESERVE_N_10] = outObjectTmp.getRESERVEOUTN10();
            strResults[index_input][OBJECT_RESERVE_C_01] = outObjectTmp.getRESERVEOUTC01();
            strResults[index_input][OBJECT_RESERVE_C_02] = outObjectTmp.getRESERVEOUTC02();
            strResults[index_input][OBJECT_RESERVE_C_03] = outObjectTmp.getRESERVEOUTC03();
            strResults[index_input][OBJECT_RESERVE_C_04] = outObjectTmp.getRESERVEOUTC04();
            strResults[index_input][OBJECT_RESERVE_C_05] = outObjectTmp.getRESERVEOUTC05();
            strResults[index_input][OBJECT_RESERVE_C_06] = outObjectTmp.getRESERVEOUTC06();
            strResults[index_input][OBJECT_RESERVE_C_07] = outObjectTmp.getRESERVEOUTC07();
            strResults[index_input][OBJECT_RESERVE_C_08] = outObjectTmp.getRESERVEOUTC08();
            strResults[index_input][OBJECT_RESERVE_C_09] = outObjectTmp.getRESERVEOUTC09();
            strResults[index_input][OBJECT_RESERVE_C_10] = outObjectTmp.getRESERVEOUTC10();
            strResults[index_input][OBJECT_ROW_INDEX] = "" + index_input;

            //回収情報を回収配列に格納する

            CollectionInOutRecord bKaisyuTmp = bOutBukenTmp.getKaisyuRecord();
            try {
                List<CollectionComplexType> ListKaisyu = bKaisyuTmp.getKaishuInOut();
                if (!ListKaisyu.isEmpty()) {
                    Iterator<CollectionComplexType> iteKaisyu = ListKaisyu.iterator();
                    int nlenKaisyu = ListKaisyu.size();
                    String[][] strKaisyuResults = new String[nlenKaisyu][STAIRS_RECORD_COUNT];
                    index_Kaisyu = 0;
                    CollectionComplexType outCollectTmp = null;

                    while (iteKaisyu.hasNext()) {
                        outCollectTmp = iteKaisyu.next();
                        strKaisyuResults[index_Kaisyu][STAIRS_REC_NO] = outObjectTmp.getLSKP() + outObjectTmp.getRECORDNO();
                        strKaisyuResults[index_Kaisyu][STAIRS_BUKKEN_NO] = outObjectTmp.getRECORDNO();
                        strKaisyuResults[index_Kaisyu][STAIRS_STAIR] = "0";
                        strKaisyuResults[index_Kaisyu][STAIRS_BUKKEN_FR] = outObjectTmp.getBUKKENFR();
                        strKaisyuResults[index_Kaisyu][STAIRS_BUKKEN_TO] = outObjectTmp.getBUKKENTO();
                        strKaisyuResults[index_Kaisyu][STAIRS_INCOME] = outCollectTmp.getINCOME();
                        strKaisyuResults[index_Kaisyu][STAIRS_CYCLE] = outCollectTmp.getCYCLE();
                        strKaisyuResults[index_Kaisyu][STAIRS_FREQUE] = outCollectTmp.getFREQUE();
                        strKaisyuResults[index_Kaisyu][STAIRS_DATE_YY] = outCollectTmp.getKAISYUDATE();
                        strKaisyuResults[index_Kaisyu][STAIRS_DATE_MM] = outCollectTmp.getKAISYUDATE();
                        strKaisyuResults[index_Kaisyu][STAIRS_DATE_DD] = outCollectTmp.getKAISYUDATE();
                        strKaisyuResults[index_Kaisyu][STAIRS_ROW_INDEX] = "" + index_Kaisyu;
                        index_Kaisyu = index_Kaisyu + 1;
                    }
                    _stairsBean.addStairsResults(strKaisyuResults);
                }

                //支払情報を支払配列に格納する
                PaydivInOutRecord bPaydiv = bOutBukenTmp.getShiharaiRecord();
                List<PaydivComplexType> Listpaydiv = bPaydiv.getPaydivInOut();
                if (!Listpaydiv.isEmpty()) {
                    Iterator<PaydivComplexType> ite = Listpaydiv.iterator();
                    int nlenPay = Listpaydiv.size();
                    String[][] strPaydivResults = new String[nlenPay][PAYDIV_RECORD_COUNT];
                    index_Paydiv = 0;
                    while (ite.hasNext()) {
                        PaydivComplexType outPaydivTmp = ite.next();
                        strPaydivResults[index_Paydiv][PAYDIV_REC_NO] = outObjectTmp.getLSKP() + outObjectTmp.getRECORDNO();
                        strPaydivResults[index_Paydiv][PAYDIV_BUKKEN_NO] = outObjectTmp.getRECORDNO();
                        strPaydivResults[index_Paydiv][PAYDIV_STAIR] = "0";
                        strPaydivResults[index_Paydiv][PAYDIV_BUKKEN_FR] = outObjectTmp.getBUKKENFR();
                        strPaydivResults[index_Paydiv][PAYDIV_BUKKEN_TO] = outObjectTmp.getBUKKENTO();
                        strPaydivResults[index_Paydiv][PAYDIV_PURCHASE] = outPaydivTmp.getSHIHARAIGAKU();
                        strPaydivResults[index_Paydiv][PAYDIV_DATE_YY] = outPaydivTmp.getSHIHARAIDATE();
                        strPaydivResults[index_Paydiv][PAYDIV_DATE_MM] = outPaydivTmp.getSHIHARAIDATE();
                        strPaydivResults[index_Paydiv][PAYDIV_DATE_DD] = outPaydivTmp.getSHIHARAIDATE();
                        strPaydivResults[index_Paydiv][PAYDIV_ROW_INDEX] = "" + index_Paydiv;
                        index_Paydiv = index_Paydiv + 1;
                    }
                    _paydivBean.addPaydivResults(strPaydivResults);
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        objectBean.setResultsForLease(strResults);

        return strResults;
    }

    /**
     * 計算を開始する     <BR>
     *
     * @param bOutBukenTmp
     * @return
     */
    public boolean LsCalcStart(BukenOutputComplexType bOutBukenTmp) {
        boolean bCalFlg = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        _nReqItem=LfcLogicPgConst.CAL_ITEM_INIT;
        //物件情報をGcalに設定する。
        doSetGcalLS(bOutBukenTmp);
        //_gcal.prt();
        //選択された算出項目インデックスを設定する。
        setOptionItemLS(bOutBukenTmp);
        //分割回収情報をStairsに設定する。
        doSetStairs(bOutBukenTmp);
        if (_gcal.getSwPay()) {
            //分割情報情報をPaydivに設定する。
            doSetPaydiv(bOutBukenTmp);
        }
        //計算メインファンクションをコールする。
        LsCalMain lsCalMain = new LsCalMain(_gcal, _paydiv, _stairs,_nReqItem,_nBaseItem);
        //計算
        errMsglist = lsCalMain.doCalculate(_nReqItem,_nBaseItem);
        if (!errMsglist.isEmpty()) {
            bCalFlg = false;
            _outErrorMsgRecord=LfcLogicComm.setErrorMsgList(errMsglist,_outErrorMsgRecord);
            return bCalFlg;
        }
        //計算結果を基本情報画面を設定する。
        bCalFlg = lsCalMain.getResultDisplayFlag();
        //_gcal.prt();
        //check 運用利回 と　Finance Margin額
        //if (_gcal.getRateUN() < 0 && _gcal.getRaPvMargin() < 0) {
        if (_gcal.getRateUN() < 0 && _gcal.getPvFinanceMargin() < 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN006, "WRN006", errMsglist);
            bCalFlg = false;
        }
        //if (_gcal.getRateUN() < 0 && _gcal.getRaPvMargin() >= 0) {
        if (_gcal.getRateUN() < 0 && _gcal.getPvFinanceMargin() >= 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN007, "WRN007", errMsglist);
            bCalFlg = false;
        }

        //if (_gcal.getRateUN() >= 0 && _gcal.getRaPvMargin() < 0) {
        if (_gcal.getRateUN() >= 0 && _gcal.getPvFinanceMargin() < 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN008, "WRN008", errMsglist);
            bCalFlg = false;
        }
        _outErrorMsgRecord=LfcLogicComm.setErrorMsgList(errMsglist,_outErrorMsgRecord);
        //bOutBukenTmp.setCheckAttribute(bCalFlg);
        return bCalFlg;
    }

    /**
     *
     * @param bOutBukenTmp
     * @return
     */
    public boolean KpCalcStart(BukenOutputComplexType bOutBukenTmp) {
        boolean bCalFlg = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        //物件情報をGcalに設定する。
        _nReqItem=LfcLogicPgConst.KAP_ITEM_INIT;
        doSetGcalKP(bOutBukenTmp);
//_gcal.prt();
        //選択された算出項目インデックスを設定する。
        setOptionItemKP(bOutBukenTmp);
        //分割回収情報をStairsに設定する。
        doSetStairs(bOutBukenTmp);
        if (_gcal.getSwPay()) {
            //分割情報情報をPaydivに設定する。
            doSetPaydiv(bOutBukenTmp);
        }
        //計算メインファンクションをコールする。
        KpCalMain kpCalMain = new KpCalMain(_gcal, _paydiv, _stairs, _nReqItem,_nBaseItem);
        //計算
        errMsglist = kpCalMain.doCalculate(_nReqItem,_nBaseItem);
        if (!errMsglist.isEmpty()) {
            bCalFlg = false;
            _outErrorMsgRecord=LfcLogicComm.setErrorMsgList(errMsglist,_outErrorMsgRecord);
            return bCalFlg;
        }
        //計算結果を基本情報画面を設定する。
        bCalFlg = kpCalMain.getResultDisplayFlag();
        //_gcal.prt();
        //check 運用利回 と　Finance Margin額
        //if (_gcal.getRateUN() < 0 && _gcal.getRaPvMargin() < 0) {
        if (_gcal.getRateUN() < 0 && _gcal.getPvFinanceMargin() < 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN006, "WRN006", errMsglist);
            bCalFlg = false;
        }
        //if (_gcal.getRateUN() < 0 && _gcal.getRaPvMargin() >= 0) {
        if (_gcal.getRateUN() < 0 && _gcal.getPvFinanceMargin() >= 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN007, "WRN007", errMsglist);
            bCalFlg = false;
        }

        //if (_gcal.getRateUN() >= 0 && _gcal.getRaPvMargin() < 0) {
        if (_gcal.getRateUN() >= 0 && _gcal.getPvFinanceMargin() < 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.WRN008, "WRN008", errMsglist);
            bCalFlg = false;
        }
        _outErrorMsgRecord=LfcLogicComm.setErrorMsgList(errMsglist,_outErrorMsgRecord);
        //wangl(DHC)20100226コメント
        //bOutBukenTmp.setCheckAttribute(bCalFlg);
        return bCalFlg;
    }

    /**
     * 指定される基準項目と逆算項目を設定するメソッド。     <BR>
     *
     */
    void setOptionItemKP(BukenOutputComplexType bOutBukenTmp) {
        ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
        outObjectTmp = bOutBukenTmp.getBukenRecord();
        if ("".equals(outObjectTmp.getCALCULATEBASE()) || "採算".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.KAP_ITEM_LPRO;
        } else if ("回収金額算出".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.KAP_ITEM_KINGAKU;
        } else if ("回収金額/頭金算出".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.KAP_ITEM_KINGAKU_INC0;
        } else if ("頭金逆算".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.KAP_ITEM_INC0;
        } else if ("回収回数逆算".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.KAP_ITEM_KAISU;
        } else if ("購入価額逆算".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.KAP_ITEM_PUCHARS;
        }
        _gcal.setKenshu1("" + nCalItemDefine);

        if ("合計料率指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_RYORTT;
        } else if ("月料率指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_RYORTM;
        } else if ("運用利回り指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_RATEUN;
        } else if ("ROI指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_ROI;
        } else if ("ROE指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_ROE;
        } else if ("TR指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_TRUERT;
        }
        _gcal.setKenshu2("" + nConBaseItem);

        _nReqItem=nCalItemDefine;
        _nBaseItem=nConBaseItem;
       // KpCalComm.setReqItem(nCalItemDefine);
        //KpCalComm.setBaseItem(nConBaseItem);
    }

    /**
     * 指定される基準項目と逆算項目を設定するメソッド。     <BR>
     *
     */
    void setOptionItemLS(BukenOutputComplexType bOutBukenTmp) {
        ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
        outObjectTmp = bOutBukenTmp.getBukenRecord();

        if ("".equals(outObjectTmp.getCALCULATEBASE()) || "採算".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.CAL_ITEM_LPRO;
        } else if ("回収金額算出".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.CAL_ITEM_KINGAKU;
        } else if ("残価逆算".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.CAL_ITEM_ZANKA;
        } else if ("回収回数逆算".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.CAL_ITEM_KAISU;
        } else if ("購入価額逆算".equals(outObjectTmp.getCALCULATEBASE())) {
            nCalItemDefine = LfcLogicPgConst.CAL_ITEM_PUCHARS;
        }
        _gcal.setKenshu1("" + nCalItemDefine);

        if ("合計料率指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_RYORTT;
        } else if ("月料率指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_RYORTM;
        } else if ("運用利回り指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_RATEUN;
        } else if ("ROI指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_ROI;
        } else if ("ROE指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_ROE;
        } else if ("TR指定".equals(outObjectTmp.getCALCULATETYPE())) {
            nConBaseItem = LfcLogicPgConst.CAL_BASE_TRUERT;
        }
        _gcal.setKenshu2("" + nConBaseItem);

        //計算情報を設定する。
        _nReqItem=nCalItemDefine;
        _nBaseItem=nConBaseItem;
        //LsCalComm.setReqItem(nCalItemDefine);
        //LsCalComm.setBaseItem(nConBaseItem);

    }

    /**
     * 計算のために画面項目のロジックチェック。
     * リース案件
     * @param bOutBukenTmp
     * @return boolean true :OK flase:NG
     * @throws Exception
     */
    public ArrayList<ErrorInforOutputComplexType> doCalCheckLS(BukenOutputComplexType bOutBukenTmp) throws Exception {
        boolean bChackFlg = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
        outObjectTmp = bOutBukenTmp.getBukenRecord();
        //物件番号未入力まだは半角数字以外データを入力された場合
        if (LfcLogicComm.getStatus(outObjectTmp.getBUKKENNO()) == BEAN_STATE_NOINPUT || LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getBUKKENNO()), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0090, "E0090", errMsglist);
            bChackFlg = false;
        }

        //物件番号(from)の半角数字以外データを入力されたチェックする
        if (LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getBUKKENFR()), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "物件番号(from)", errMsglist);
            bChackFlg = false;
        }
        // 物件No（From)を入力しないの場合、エラーが出す
        if (LfcLogicComm.getStatus(outObjectTmp.getBUKKENFR()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0008, "E0008", errMsglist);
            bChackFlg = false;
        }
        //物件番号(to)の半角数字以外データを入力されたチェックする
        if (LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getBUKKENTO()), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "物件番号(to)", errMsglist);
            bChackFlg = false;
        }
        // 検収予定日のエラーチェック(入力しない又は入力エラー)
        if (LfcLogicComm.getStatus(outObjectTmp.getDATEKENSH()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0006, "E0006", errMsglist);
            bChackFlg = false;
        } else {
            if (outObjectTmp.getDATEKENSH().length() != 10 && outObjectTmp.getDATEKENSH().length() != 8) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR001, "ERR001", errMsglist);
                bChackFlg = false;
            }
            //検収予定日を有効の日付ではありません
            if (!LfcFrmComm.isDate(outObjectTmp.getDATEKENSH()) && !"".equals(outObjectTmp.getDATEKENSH())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0005, "E0005", errMsglist);
                bChackFlg = false;
            }
        }
        //物件数量 を半角数字以外値を入力された場合
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getQUANTITY(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "物件数量", errMsglist);
            bChackFlg = false;
        }
        // 合計料率チェック
        double dRyoristsuT = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getRYORITSUT())) == BEAN_STATE_NOINPUT) {
            if ((!"残価逆算".equals(outObjectTmp.getCALCULATEBASE()) && !"回収回数逆算".equals(outObjectTmp.getCALCULATEBASE()) && !"購入価額逆算".equals(outObjectTmp.getCALCULATEBASE())) && "合計料率指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0224, "E0224", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRYORITSUT(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "合計料率", errMsglist);
                bChackFlg = false;
            } else {
                dRyoristsuT = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRYORITSUT()));
            }
        }
        // 月料率チェック
        double dRyoritsuM = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getRYORITSUM())) == BEAN_STATE_NOINPUT) {
            if ((!"残価逆算".equals(outObjectTmp.getCALCULATEBASE()) && !"回収回数逆算".equals(outObjectTmp.getCALCULATEBASE()) && !"購入価額逆算".equals(outObjectTmp.getCALCULATEBASE())) && "月料率指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0225, "E0225", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRYORITSUM(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "月料率", errMsglist);
                bChackFlg = false;
            } else {
                dRyoritsuM = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRYORITSUM()));
            }
        }
        // 運用利回チェック
        double dRateUnyo = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getRATEUNYO())) == BEAN_STATE_NOINPUT) {
            if ("残価逆算".equals(outObjectTmp.getCALCULATEBASE()) && "運用利回り指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0226, "E0226", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEUNYO(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "運用利回", errMsglist);
                bChackFlg = false;
            } else {
                dRateUnyo = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEUNYO()));
            }
        }
        double dTrueRate = 0.0;
        // TRチェック        
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getTRUERATE())) == BEAN_STATE_NOINPUT) {
            if ("残価逆算".equals(outObjectTmp.getCALCULATEBASE()) && "TR指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0227, "E0227", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getTRUERATE(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "TR", errMsglist);
                bChackFlg = false;
            } else {
                dTrueRate = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getTRUERATE()));
            }
        }
        // ROIチェック
        double dRoi = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getRATEROI())) == BEAN_STATE_NOINPUT) {
            if ("残価逆算".equals(outObjectTmp.getCALCULATEBASE()) && "ROI指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0228, "E0228", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEROI(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "ROI", errMsglist);
                bChackFlg = false;
            } else {
                dRoi = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEROI()));
            }
        }
        //ROEチェック
        double dRoe = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getROE())) == BEAN_STATE_NOINPUT) {
            if ("残価逆算".equals(outObjectTmp.getCALCULATEBASE()) && "ROE指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0229, "E0229", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getROE(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "ROE", errMsglist);
                bChackFlg = false;
            } else {
                dRoe = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getROE()));
            }
        }

        //LeverageRatioチェック
        boolean bLeverageRatioFlg = false;
        String strTmpRatio = LfcFrmComm.lostNull(outObjectTmp.getLEVERAGERATIO());
        if (!"".equals(strTmpRatio)) {
            if (strTmpRatio.length() != 4) {
                bLeverageRatioFlg = true;
            } else {
                if (LfcFrmComm.doZenkakuCheck(strTmpRatio.substring(0, strTmpRatio.length() - 2), LfcFrmBeanConst.NUM)) {
                    bLeverageRatioFlg = true;
                }
                if (!":".equals(strTmpRatio.substring(2, strTmpRatio.length() - 1))) {
                    bLeverageRatioFlg = true;
                }
                if (LfcFrmComm.doZenkakuCheck(strTmpRatio.substring(strTmpRatio.length() - 1), LfcFrmBeanConst.NUM)) {
                    bLeverageRatioFlg = true;
                }
            }
        }
        if (bLeverageRatioFlg) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0102, "E0102", errMsglist);
            bChackFlg = false;
        }

        //ＲＯEで逆算時LeverageRatioを入力してください。
        if (("回収金額算出".equals(outObjectTmp.getCALCULATEBASE()) || "残価逆算".equals(outObjectTmp.getCALCULATEBASE()) || "回収回数逆算".equals(outObjectTmp.getCALCULATEBASE()) || "購入価額逆算".equals(outObjectTmp.getCALCULATEBASE())) && "ROE指定".equals(outObjectTmp.getCALCULATETYPE())) {
            if ("".equals(LfcFrmComm.lostNull(outObjectTmp.getLEVERAGERATIO())) || LfcFrmComm.lostNull(outObjectTmp.getLEVERAGERATIO()) == null) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0223, "E0223", errMsglist);
                bChackFlg = false;
            }
        }
        //TAXチェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getTAX(), LfcFrmBeanConst.FLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "TAX", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_01チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN01(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "低炭素リース保険料率", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_02チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN02(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_02", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_03チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN03(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_03", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_04チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN04(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_04", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_05チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN05(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_05", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_06チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN06(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_06", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_07チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN07(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_07", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_08チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN08(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_08", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_09チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN09(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_09", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_10チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN10(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_10", errMsglist);
            bChackFlg = false;
        }
        // 残価
        double dRemainVal = 0;
        //残価は半角数字以外値を入力された場合
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getREMAINVAL(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "残価", errMsglist);
            bChackFlg = false;
        } else {
            dRemainVal = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getREMAINVAL()));
            // 「残価」範囲チェック(残価<0、残価>99999999999の場合、エラー)
            if (dRemainVal < 0 || dRemainVal > 99999999999.0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR010, "ERR010", errMsglist);
                bChackFlg = false;
            }
        }
        // 残価率は半角数字以外値を入力された場合
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getREMVALRT(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "残価率", errMsglist);
            bChackFlg = false;
        }
        //「残価率」範囲チェック(残価率<0、残価率>100の場合、エラー)
	/*
         * ljq delete begin if (dRemValRt < 0 || dRemValRt > 100) {
         * LfcMessageBox.show(LfcLogicMsgConst.ERR009); bChackFlg = false; } ljq
         * delete end
         */
        // 法定耐用年数は未入力まだは半角数字以外データを入力された場合
        if ("".equals(outObjectTmp.getDURABLEY()) || outObjectTmp.getDURABLEY() == null) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0011, "E0011", errMsglist);
            bChackFlg = false;
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getDURABLEY(), LfcFrmBeanConst.NUM)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0011, "E0011", errMsglist);
                bChackFlg = false;
            } else {
                int iDurableY = LfcFrmComm.toInt(LfcFrmComm.lostNull(outObjectTmp.getDURABLEY()));
                if (iDurableY < 1 || iDurableY > 99) {
                    // 法定耐用年数の［入力範囲］ 1以上99以下
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR015, "ERR015", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        // リース月数は未入力エラー
        if ("".equals(outObjectTmp.getLEASEM()) || outObjectTmp.getLEASEM() == null) {
            //リース期間を入力して下さい。
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0049, "E0049", errMsglist);
            bChackFlg = false;
        } else {
            //「リース月数」は半角数字で入力してください。
            //int iLeaseM = LfcFrmComm.toInt(LfcFrmComm.lostNull(outObjectTmp.getLEASEM()));
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getLEASEM(), LfcFrmBeanConst.NUM)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "リース月数", errMsglist);
                bChackFlg = false;
            }
            /***********************************************************************
             * ljq delete begin //リース月数の［入力範囲］ 1以上360以下 if (iLeaseM < 1 || iLeaseM >
             * 360){ LfcMessageBox.show(LfcLogicMsgConst.ERR014); bChackFlg = false; }
             * ljq delete end
             */
        }
        //社内コスト率チェック
        //「社内コスト率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEJLC(), LfcFrmBeanConst.FLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "社内コスト率", errMsglist);
            bChackFlg = false;
        } else {
            // 「社内コスト率」０は計算できません。
            double dComCostRate = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEJLC()));
            if (dComCostRate == 0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR005, "ERR005", errMsglist);
                bChackFlg = false;
            }
        }
        // COFチェック
        //原調計算金利(COF)を入力してください。
        /* String strCof = LfcFrmComm.lostNull(outObjectTmp.getRATECADJ());
        if ("".equals(strCof)) {
        errMsglist = addErrMsgList(LfcLogicMsgConst.ERR006, "ERR006", errMsglist);
        bChackFlg = false;
        }*/
        if ("".equals(outObjectTmp.getRATECADJ()) || outObjectTmp.getRATECADJ() == null) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0101, "E0101", errMsglist);
            bChackFlg = false;
        } else {
            //「原調計算金利(COF)」は半角数字で入力してください。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATECADJ(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "原調計算金利(COF)", errMsglist);
                bChackFlg = false;
            } else {
                double dCof = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATECADJ()));
                // COFが入力されていません。ＣＯＦ（原調計算金利）
                if (dCof == 0) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR006, "ERR006", errMsglist);
                    bChackFlg = false;
                } else if (dCof < 0 || dCof > 20) {
                    // 「COF」範囲チェック(COF<0、COF>20の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR053, "ERR053", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //管販費率チェック
        //「管販費率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEEANI(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "管販費率", errMsglist);
            bChackFlg = false;
        } else {
            double dRateEAni = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEEANI()));
            // 「管販費率合計」範囲チェック(管販費率合計<0、管販費率合計>20の場合、エラー)
            if (dRateEAni < 0 || dRateEAni > 20) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR046, "ERR046", errMsglist);
                bChackFlg = false;
            }
        }
        //管販費率(Origination)チェック
        //管販費率(Origination)を入力してください。［入力必須］
        if (LfcLogicComm.getStatus(outObjectTmp.getRATEEAO()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0012, "E0012", errMsglist);
            bChackFlg = false;
        } else {
            //「管販費率Original」は半角数字で入力してください。。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEEAO(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "管販費率Original", errMsglist);
                bChackFlg = false;
            } else {
                double dRateEAO = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEEAO()));
                if (dRateEAO < -99.99 || dRateEAO > 99.99) {
                    // 「管販費率(Origination)」範囲チェック(管販費率(Origination)<-99.99、管販費率(Origination)>99.99の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR047, "ERR047", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //管販費率Serviceチェック
        //管販費率Serviceを入力してください。［入力必須］
        if (LfcLogicComm.getStatus(outObjectTmp.getRATEEAS()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0013, "E0013", errMsglist);
            bChackFlg = false;
        } else {
            //「管販費率Service」は半角数字で入力してください。。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEEAS(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "管販費率Service", errMsglist);
                bChackFlg = false;
            } else {
                double dRateEAS = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEEAS()));
                if (dRateEAS < -99.99 || dRateEAS > 99.99) {
                    // 「管販費率（管販費率S）」範囲チェック(管販費率（管販費率S）<-99.99、貸倒引当率>99.99の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR048, "ERR048", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //貸倒引当率チェック
        //貸倒引当率を入力してください。
        if (LfcLogicComm.getStatus(outObjectTmp.getRATELOSS()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0014, "E0014", errMsglist);
            bChackFlg = false;
        } else {
            //「貸倒引当率」は半角数字で入力してください。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATELOSS(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "貸倒引当率", errMsglist);
                bChackFlg = false;
            } else {
                double dRateLoss = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATELOSS()));
                // 「貸倒引当率」範囲チェック(貸倒引当率<-99.99、貸倒引当率>99.99の場合、エラー)
                if (dRateLoss < -99.99 || dRateLoss > 99.99) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR045, "ERR045", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //手数料収益率チェック
        //「手数料収益率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEFEE(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "手数料収益率", errMsglist);
            bChackFlg = false;
        } else {
            double dRateFee = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEFEE()));
            // 「手数料収益率合計」範囲チェック(手数料収益率合計<0、手数料収益率合計>20の場合、エラー)
            if (dRateFee < 0 || dRateFee > 20) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR049, "ERR049", errMsglist);
                bChackFlg = false;
            }
        }
        //手数料収益率NPPチェック
        //手数料收益率(NPP)を入力してください。
        //「手数料収益率NPP」は半角数字で入力してください。
        if (LfcLogicComm.getStatus(outObjectTmp.getRATEFEEN()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0015, "E0015", errMsglist);
            bChackFlg = false;
        } else {
            //「手数料収益率NPP」は半角数字で入力してください。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEFEEN(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "手数料収益率NPP", errMsglist);
                bChackFlg = false;
            } else {
                double dRateFeeN = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEFEEN()));
                if (dRateFeeN < -99.99 || dRateFeeN > 99.99) {
                    // 「手数料收益率(NPP)」範囲チェック(手数料收益率(NPP)<-99.99、手数料收益率(NPP)>99.99の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR050, "E0114", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //手数料収益率Releaseチェック
        //手数料收益率(Release)を入力してください。
        if (LfcLogicComm.getStatus(outObjectTmp.getRATEFEER()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0016, "E0016", errMsglist);
            bChackFlg = false;
        } else {
            //「手数料収益率Release」は半角数字で入力してください。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEFEER(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "手数料収益率Release", errMsglist);
                bChackFlg = false;
            } else {
                double dRateFeeR = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEFEER()));
                if (dRateFeeR < -99.99 || dRateFeeR > 99.99) {
                    // 「手数料收益率(Release)」範囲チェック(手数料收益率(Release)<-99.99、手数料收益率(Release)>99.99の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR051, "ERR051", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        // 動産総合保険料率チェック
        //「動総保険料率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getDOSORATE(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "動産総合保険料率", errMsglist);
            bChackFlg = false;
        } else {
            double dDosoRate = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getDOSORATE()));
            // 動産総合保険料率の［入力範囲］ 0以上99以下
            if (dDosoRate < 0 || dDosoRate > 99) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR054, "ERR054", errMsglist);
                bChackFlg = false;
            }
        }
        //団信保険料率チェック
        //「団信保険料率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getDANSHINRT(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "団信保険料率", errMsglist);
            bChackFlg = false;
        }
        //「機械保険料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getMACHIFEE(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "機械保険料", errMsglist);
            bChackFlg = false;
        }
        //「火災保険料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getFIREFEE(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "火災保険料", errMsglist);
            bChackFlg = false;
        }
        //「船舶・その他保険料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getETCFEE(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "船舶・その他保険料", errMsglist);
            bChackFlg = false;
        }
        //「一時費用(イ)(公証)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getICHIJI1(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "一時費用(イ)(公証)", errMsglist);
            bChackFlg = false;
        }
        //「一時費用(ロ)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getICHIJI2(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "一時費用(ロ)", errMsglist);
            bChackFlg = false;
        }
        //「一時費用(ハ)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getICHIJI3(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "一時費用(ハ)", errMsglist);
            bChackFlg = false;
        }
        //「繰延費用(ヘ)(団信)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getKURINO1(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "繰延費用(ヘ)(団信)", errMsglist);
            bChackFlg = false;
        }
        //「繰延費用(ト)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getKURINO2(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "繰延費用(ト)", errMsglist);
            bChackFlg = false;
        }
        //「保守料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getHOSHURYO(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "保守料", errMsglist);
            bChackFlg = false;
        }
        //「斡旋手数料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getASSEN(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "斡旋手数料", errMsglist);
            bChackFlg = false;
        }
        //「保険料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getINSURANCE(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "保険料", errMsglist);
            bChackFlg = false;
        }
        //前受リース料
        String strPreLeaseM = LfcFrmComm.lostNull(outObjectTmp.getINCOME0());
        //前受リース月数
        String strIncom = LfcFrmComm.lostNull(outObjectTmp.getINC0M());
        //前受ﾘｰｽ料回収日
        String strDateInc0 = LfcFrmComm.lostNull(outObjectTmp.getDATEINC0());
        // 前受リース月数
        double dPreLeaseAmt = 0.0;
        double dPreLeaseM = 0.0;
        //前受ﾘｰｽ料(月数)を入力して下さい。
        if (!"".equals(strDateInc0) && "".equals(strPreLeaseM)) {
            if ("".equals(strIncom)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0058, "E0058", errMsglist);
                bChackFlg = false;
            } else {
                //「前受リース月数」は半角数字で入力してください。
                if (LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getINC0M()), LfcFrmBeanConst.PLUSFLOAT)) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "前受リース月数", errMsglist);
                    bChackFlg = false;
                } else {
                    dPreLeaseAmt = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(strIncom));
                    //前受ﾘｰｽ料(月数)は９９９以下を入力して下さい。
                    if (dPreLeaseAmt > 999) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0065, "E0065", errMsglist);
                        bChackFlg = false;
                    }
                }
            }
        }
        //前受リース料チェック
        // if (!"".equals(strDateInc0) && "".equals(strPreLeaseM)) {
        if (!"".equals(strDateInc0) && "".equals(strIncom)) {
            //前受リース料を入力して下さい。
            if ("".equals(strPreLeaseM)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0113, "E0113", errMsglist);
                bChackFlg = false;
            } else {
                //前受ﾘｰｽ料が半角数字を入力してください。
                //if (LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getINC0M()), LfcFrmBeanConst.PLUSFLOAT)) {
                if (LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getINCOME0()), LfcFrmBeanConst.PLUSFLOAT)) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "前受ﾘｰｽ料", errMsglist);
                    bChackFlg = false;
                } else {
                    dPreLeaseM = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(strPreLeaseM));
                }
            }
        }
        //前受ﾘｰｽ料回収日チェック
        if (dPreLeaseAmt > 0 || dPreLeaseM > 0) {
            //前受ﾘｰｽ料回収日チェック
            if (LfcLogicComm.getStatus(outObjectTmp.getDATEINC0()) == BEAN_STATE_NOINPUT) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0051, "E0051", errMsglist);
                bChackFlg = false;
            } else {
                if (!LfcFrmComm.isDate(outObjectTmp.getDATEINC0()) && !"".equals(outObjectTmp.getDATEINC0())) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0052, "E0052", errMsglist);
                    bChackFlg = false;
                } else {
                    if (outObjectTmp.getDATEINC0().length() != 10 && outObjectTmp.getDATEINC0().length() != 8) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0052, "E0052", errMsglist);
                        bChackFlg = false;
                    }
                }
            }
            /*if (!LfcFrmComm.isDate(outObjectTmp.getDATEINC0()) && !"".equals(outObjectTmp.getDATEINC0())) {
            errMsglist = addErrMsgList(LfcLogicMsgConst.ERR020, "ERR020", errMsglist);
            bChackFlg = false;
            } else {
            if (outObjectTmp.getDATEINC0().length() != 10 && outObjectTmp.getDATEINC0().length() != 8) {
            errMsglist = addErrMsgList(LfcLogicMsgConst.ERR020, "ERR020", errMsglist);
            bChackFlg = false;
            }
            }*/
        }
        //if (outObjectTmp.getINC0M() == null && outObjectTmp.getINCOME0() == null) {
        if ("".equals(strIncom) && "".equals(strPreLeaseM) && !"".equals(strDateInc0)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0231, "E0231", errMsglist);
            bChackFlg = false;
        }

//      //支払方法は一括支払の場合
        PaydivInOutRecord bPaydiv = bOutBukenTmp.getShiharaiRecord();
        List<PaydivComplexType> Listpaydiv = bPaydiv.getPaydivInOut();
        // 購入価額
        double dPurchase = 0;
        if (Listpaydiv.isEmpty()) {
            // 購入額は必ず入力される
            if (LfcLogicComm.getStatus(outObjectTmp.getPURCHASE()) == BEAN_STATE_NOINPUT) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0009, "E0009", errMsglist);
                bChackFlg = false;
            } else {
                //購入価額は半角数字以外値を入力された場合
                if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getPURCHASE(), LfcFrmBeanConst.NUM)) {
                    //購入価額の内訳金額が半角数字を入力してください。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "購入価額", errMsglist);
                    bChackFlg = false;
                } else {
                    // 購入価額
                    dPurchase = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getPURCHASE()));
                    if (dPurchase < 1000 || dPurchase > 50000000000.0) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR008, "ERR008", errMsglist);
                        bChackFlg = false;
                    }
                }
            }
            // 支払予定日は必ず入力される
            if (LfcLogicComm.getStatus(outObjectTmp.getDATEPAYMT()) == BEAN_STATE_NOINPUT) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0104, "E0104", errMsglist);
                bChackFlg = false;
            } else {
                if (outObjectTmp.getDATEPAYMT().length() != 10 && outObjectTmp.getDATEPAYMT().length() != 8) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR002, "ERR002", errMsglist);
                    bChackFlg = false;
                }
                //一括支払の場合、支払予定日が有効の日付ではありません
                if (!LfcFrmComm.isDate(outObjectTmp.getDATEPAYMT()) && !"".equals(outObjectTmp.getDATEPAYMT())) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0017, "E0017", errMsglist);
                    bChackFlg = false;
                }
            }
        } else {
            // 支払方法は分割支払の場合、
            // 支払予定日入力されば、支払予定日は歴の上で存在チェック
            dPurchase = 0;
            Iterator<PaydivComplexType> ite = Listpaydiv.iterator();
            while (ite.hasNext()) {
                PaydivComplexType outPaydivTmp = ite.next();
                // 支払予定日は必ず入力される
                if (LfcLogicComm.getStatus(outPaydivTmp.getSHIHARAIDATE()) == BEAN_STATE_NOINPUT) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0010, "E0010", errMsglist);
                    bChackFlg = false;
                } else {
                    if (outPaydivTmp.getSHIHARAIDATE().length() != 10 && outPaydivTmp.getSHIHARAIDATE().length() != 8) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR002, "ERR002", errMsglist);
                        bChackFlg = false;
                    }
                }

                if (LfcFrmComm.doZenkakuCheck(outPaydivTmp.getSHIHARAIDATE(), LfcFrmBeanConst.DATE)) {
                    //支払予定日が半角数字を入力してください。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0119, "E0119", errMsglist);
                    bChackFlg = false;
                }
                if (!LfcFrmComm.isDate(outPaydivTmp.getSHIHARAIDATE()) && !"".equals(outPaydivTmp.getSHIHARAIDATE())) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0017, "E0017", errMsglist);
                    bChackFlg = false;
                }
                // 購入額は必ず入力される
                if (LfcLogicComm.getStatus(outPaydivTmp.getSHIHARAIGAKU()) == BEAN_STATE_NOINPUT) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0009, "E0009", errMsglist);
                    bChackFlg = false;
                }
                if (LfcFrmComm.doZenkakuCheck(outPaydivTmp.getSHIHARAIGAKU(), LfcFrmBeanConst.NUM)) {
                    //購入価額の内訳金額が半角数字を入力してください。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0118, "E0118", errMsglist);
                    bChackFlg = false;
                }
                if (bChackFlg) {
                    dPurchase = dPurchase + LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outPaydivTmp.getSHIHARAIGAKU()));
                }

            }
            outObjectTmp.setPURCHASE("" + dPurchase);
            outObjectTmp.setDATEPAYMT("");
            if (bChackFlg) {
                if (dPurchase < 1000 || dPurchase > 50000000000.0) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR008, "ERR008", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //前受リース料月数<0、エラー
        if (dPreLeaseM < 0) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR017, "ERR017", errMsglist);
            bChackFlg = false;
        } /*
         * //前受リース料が購入価額を超えています if(!arrObeject[chkMoon.isSelected()) {
         * if (dPreLeaseAmt > dPurchase) {
         * LfcMessageBox.show(LfcLogicMsgConst.ERR023); bChackFlg = false; } }
         */
        String strTemp = "";
        CollectionInOutRecord bKaisyuTmp = bOutBukenTmp.getKaisyuRecord();
        List<CollectionComplexType> ListKaisyu = bKaisyuTmp.getKaishuInOut();
        if (!ListKaisyu.isEmpty()) {
            Iterator<CollectionComplexType> iteKaisyu = ListKaisyu.iterator();
            CollectionComplexType outCollectTmp = null;
            while (iteKaisyu.hasNext()) {
                outCollectTmp = iteKaisyu.next();
                String tmp1 = LfcFrmComm.lostNull(outCollectTmp.getINCOME());
                String tmp2 = LfcFrmComm.lostNull(outCollectTmp.getKAISYUDATE());
                String tmp3 = LfcFrmComm.lostNull(outCollectTmp.getCYCLE());
                String tmp4 = LfcFrmComm.lostNull(outCollectTmp.getFREQUE());
                if (LfcFrmComm.doZenkakuCheck(tmp1, LfcFrmBeanConst.NUM)) {
                    errMsglist = LfcLogicComm.addErrMsgList(
                            // "回収金額が半角数字を入力してください。",
                            LfcFrmMsgConst.E0114, "E0114", errMsglist);
                    bChackFlg = false;
                }

                if (LfcFrmComm.doZenkakuCheck(tmp2, LfcFrmBeanConst.DATE)) {
                    errMsglist = LfcLogicComm.addErrMsgList(
                            // "回収予定日が半角数字を入力してください。",
                            LfcFrmMsgConst.E0115, "E0115", errMsglist);
                    bChackFlg = false;
                }

                if (LfcFrmComm.doZenkakuCheck(tmp3, LfcFrmBeanConst.NUM)) {
                    errMsglist = LfcLogicComm.addErrMsgList(
                            // "回収ｻｲｸﾙが半角数字を入力してください。",
                            LfcFrmMsgConst.E0116, "E0116", errMsglist);
                    bChackFlg = false;
                }

                if (LfcFrmComm.doZenkakuCheck(tmp4, LfcFrmBeanConst.NUM)) {
                    errMsglist = LfcLogicComm.addErrMsgList(
                            // "回収が半角数字を入力してください。",
                            LfcFrmMsgConst.E0117, "E0117", errMsglist);
                    bChackFlg = false;
                }

                if (!"".equals(LfcFrmComm.lostNull(outCollectTmp.getKAISYUDATE()))) {
                    strTemp = outCollectTmp.getKAISYUDATE();
                    int n = 0;
                    for (int j = 0; j <
                            strTemp.length(); j++) {
                        if (strTemp.charAt(j) == '/') {
                            n = n + 1;
                        }

                    }

                    String strTemp2 = "";
                    if (n == 2) {
                        int iPosition = strTemp.indexOf("/");
                        strTemp2 =
                                strTemp.substring(0, iPosition + 1);
                        strTemp =
                                strTemp.substring(iPosition + 1);
                        iPosition =
                                strTemp.indexOf("/");
                        if (strTemp.substring(0, iPosition).length() < 2) {
                            strTemp2 = strTemp2 + "0" + strTemp.substring(0, iPosition + 1);
                        } else {
                            strTemp2 = strTemp2 + strTemp.substring(0, iPosition + 1);
                        }

                        strTemp = strTemp.substring(iPosition + 1);
                        if (strTemp.length() < 2) {
                            strTemp2 = strTemp2 + "0" + strTemp;
                        } else {
                            strTemp2 = strTemp2 + strTemp;
                        }

                    }
                    strTemp = outCollectTmp.getKAISYUDATE();
                    if (!LfcFrmComm.isDate(strTemp)) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0092, "E0092", errMsglist);
                        // arrObeject[tblSepaWithdrawList.getCellEditor.getTableCellEditorComponent.setBackground(color.red);
                        bChackFlg = false;
                    }

                }
            }
        }
        strTemp = outObjectTmp.getDATEINC0();
        if (!"".equals(strTemp)) {
            int n = 0;

            for (int j = 0; j <
                    strTemp.length(); j++) {
                if (strTemp.charAt(j) == '/') {
                    n = n + 1;
                }

            }
            String strTemp2 = "";
            if (n == 2) {
                int iPosition = strTemp.indexOf("/");
                strTemp2 =
                        strTemp.substring(0, iPosition + 1);
                strTemp =
                        strTemp.substring(iPosition + 1);
                iPosition =
                        strTemp.indexOf("/");
                if (strTemp.substring(0, iPosition).length() < 2) {
                    strTemp2 = strTemp2 + "0" + strTemp.substring(0, iPosition + 1);
                } else {
                    strTemp2 = strTemp2 + strTemp.substring(0, iPosition + 1);
                }

                strTemp = strTemp.substring(iPosition + 1);
                if (strTemp.length() < 2) {
                    strTemp2 = strTemp2 + "0" + strTemp;
                } else {
                    strTemp2 = strTemp2 + strTemp;
                }

            }
            strTemp = outObjectTmp.getDATEINC0();
            if (!LfcFrmComm.isDate(strTemp)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0230, "E0230", errMsglist);
                bChackFlg = false;
            }

        }
        Iterator<ErrorInforOutputComplexType> iterator = errMsglist.iterator();
        while (iterator.hasNext()) {
            ErrorInforOutputComplexType tempErrorOutputObject = iterator.next();
            System.out.println(tempErrorOutputObject.getERRORNO() + "  " + tempErrorOutputObject.getERRORMSG());
        }
        return errMsglist;
    }

    /**
     * 計算のために画面項目のロジックチェック。
     * 割賦案件
     * @param bOutBukenTmp
     * @return boolean true :OK flase:NG
     * @throws Exception
     */
    public ArrayList<ErrorInforOutputComplexType> doCalCheckKP(BukenOutputComplexType bOutBukenTmp) throws Exception {
        boolean bChackFlg = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
        outObjectTmp = bOutBukenTmp.getBukenRecord();

        //物件番号未入力まだは半角数字以外データを入力された場合
        if (LfcLogicComm.getStatus(outObjectTmp.getBUKKENNO()) == BEAN_STATE_NOINPUT || LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getBUKKENNO()), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0090, "E0090", errMsglist);
            bChackFlg = false;
        }

        //物件番号(from)の半角数字以外データを入力されたチェックする
        if (LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getBUKKENFR()), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "物件番号(from)", errMsglist);
            bChackFlg = false;
        }
        // 物件No（From)を入力しないの場合、エラーが出す
        if (LfcLogicComm.getStatus(outObjectTmp.getBUKKENFR()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0008, "E0008", errMsglist);
            bChackFlg = false;
        }
        //物件番号(to)の半角数字以外データを入力されたチェックする
        if (LfcFrmComm.doZenkakuCheck(LfcFrmComm.lostNull(outObjectTmp.getBUKKENTO()), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "物件番号(to)", errMsglist);
            bChackFlg = false;
        }
        // 検収予定日のエラーチェック(入力しない又は入力エラー)
        if (LfcLogicComm.getStatus(outObjectTmp.getDATEKENSH()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0006, "E0006", errMsglist);
            bChackFlg = false;
        } else {
            if (outObjectTmp.getDATEKENSH().length() != 10 && outObjectTmp.getDATEKENSH().length() != 8) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR001, "ERR001", errMsglist);
                bChackFlg = false;
            }
            //検収予定日を有効の日付ではありません
            if (!LfcFrmComm.isDate(outObjectTmp.getDATEKENSH()) && !"".equals(outObjectTmp.getDATEKENSH())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0005, "E0005", errMsglist);
                bChackFlg = false;
            }
        }
        //物件数量 を半角数字以外値を入力された場合
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getQUANTITY(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "物件数量", errMsglist);
            bChackFlg = false;
        }
        //以下頭金回収日について
        String tmpInComeo = LfcFrmComm.lostNull(outObjectTmp.getINCOME0());//頭金
        String tmpDateInco = LfcFrmComm.lostNull(outObjectTmp.getDATEINC0());//頭金回収日
        if (tmpInComeo != null || !"".equals(tmpInComeo)) {
            //頭金回収日(検収予定日)を入力しないの場合、エラーが出す
            if (LfcLogicComm.getStatus(tmpDateInco) == BEAN_STATE_NOINPUT) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0063, "E0063", errMsglist);
                bChackFlg = false;
            } else {
                //頭金回収日(検収予定日)を有効の日付ではありません
                if (!LfcFrmComm.isDate(tmpDateInco) && !"".equals(tmpDateInco)) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0064, "E0064", errMsglist);
                    bChackFlg = false;
                }
            }
            //頭金を半角数字以外値を入力された場合
            if (LfcFrmComm.doZenkakuCheck(tmpInComeo, LfcFrmBeanConst.NUM)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "頭金", errMsglist);
                bChackFlg = false;
            }
        }
        // 合計料率チェック
        double dRyoristsuT = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getRYORITSUT())) == BEAN_STATE_NOINPUT) {
            if ((!"頭金逆算".equals(outObjectTmp.getCALCULATEBASE()) && !"回収回数逆算".equals(outObjectTmp.getCALCULATEBASE()) && !"購入価額逆算".equals(outObjectTmp.getCALCULATEBASE())) && "合計料率指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0224, "E0224", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRYORITSUT(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "合計料率", errMsglist);
                bChackFlg = false;
            } else {
                dRyoristsuT = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRYORITSUT()));
            }
        }
        // 月料率チェック
        double dRyoritsuM = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getRYORITSUM())) == BEAN_STATE_NOINPUT) {
            if ((!"頭金逆算".equals(outObjectTmp.getCALCULATEBASE()) && !"回収回数逆算".equals(outObjectTmp.getCALCULATEBASE()) && !"購入価額逆算".equals(outObjectTmp.getCALCULATEBASE())) && "月料率指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0225, "E0225", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRYORITSUM(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "月料率", errMsglist);
                bChackFlg = false;
            } else {
                dRyoritsuM = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRYORITSUM()));
            }
        }
        // 運用利回チェック
        double dRateUnyo = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getRATEUNYO())) == BEAN_STATE_NOINPUT) {
            if ("頭金逆算".equals(outObjectTmp.getCALCULATEBASE()) && "運用利回り指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0226, "E0226", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEUNYO(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "運用利回", errMsglist);
                bChackFlg = false;
            } else {
                dRateUnyo = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEUNYO()));
            }
        }
        double dTrueRate = 0.0;
        // TRチェック
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getTRUERATE())) == BEAN_STATE_NOINPUT) {
            if ("頭金逆算".equals(outObjectTmp.getCALCULATEBASE()) && "TR指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0227, "E0227", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getTRUERATE(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "TR", errMsglist);
                bChackFlg = false;
            } else {
                dTrueRate = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getTRUERATE()));
            }
        }
        // ROIチェック
        double dRoi = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getRATEROI())) == BEAN_STATE_NOINPUT) {
            if ("頭金逆算".equals(outObjectTmp.getCALCULATEBASE()) && "ROI指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0228, "E0228", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEROI(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "ROI", errMsglist);
                bChackFlg = false;
            } else {
                dRoi = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEROI()));
            }
        }
        //ROEチェック
        double dRoe = 0.0;
        if (LfcLogicComm.getStatus(LfcFrmComm.lostNull(outObjectTmp.getROE())) == BEAN_STATE_NOINPUT) {
            if ("頭金逆算".equals(outObjectTmp.getCALCULATEBASE()) && "ROE指定".equals(outObjectTmp.getCALCULATETYPE())) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0229, "E0229", errMsglist);
                bChackFlg = false;
            }
        } else {
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getROE(), LfcFrmBeanConst.FLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "ROE", errMsglist);
                bChackFlg = false;
            } else {
                dRoe = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getROE()));
            }
        }

        //LeverageRatioチェック
        boolean bLeverageRatioFlg = false;
        String strTmpRatio = LfcFrmComm.lostNull(outObjectTmp.getLEVERAGERATIO());
        if (!"".equals(strTmpRatio)) {
            if (strTmpRatio.length() != 4) {
                bLeverageRatioFlg = true;
            } else {
                if (LfcFrmComm.doZenkakuCheck(strTmpRatio.substring(0, strTmpRatio.length() - 2), LfcFrmBeanConst.NUM)) {
                    bLeverageRatioFlg = true;
                }
                if (!":".equals(strTmpRatio.substring(2, strTmpRatio.length() - 1))) {
                    bLeverageRatioFlg = true;
                }
                if (LfcFrmComm.doZenkakuCheck(strTmpRatio.substring(strTmpRatio.length() - 1), LfcFrmBeanConst.NUM)) {
                    bLeverageRatioFlg = true;
                }
            }
        }
        if (bLeverageRatioFlg) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0102, "E0102", errMsglist);
            bChackFlg = false;
        }

        //ＲＯEで逆算時LeverageRatioを入力してください。
        if (("回収金額/頭金算出".equals(outObjectTmp.getCALCULATEBASE()) || "回収金額算出".equals(outObjectTmp.getCALCULATEBASE()) || "頭金逆算".equals(outObjectTmp.getCALCULATEBASE()) || "回収回数逆算".equals(outObjectTmp.getCALCULATEBASE()) || "購入価額逆算".equals(outObjectTmp.getCALCULATEBASE())) && "ROE指定".equals(outObjectTmp.getCALCULATETYPE())) {
            if ("".equals(LfcFrmComm.lostNull(outObjectTmp.getLEVERAGERATIO())) || LfcFrmComm.lostNull(outObjectTmp.getLEVERAGERATIO()) == null) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0223, "E0223", errMsglist);
                bChackFlg = false;
            }
        }
        //TAXチェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getTAX(), LfcFrmBeanConst.FLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "TAX", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_01チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN01(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_01", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_02チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN02(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_02", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_03チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN03(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_03", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_04チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN04(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_04", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_05チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN05(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_05", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_06チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN06(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_06", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_07チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN07(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_07", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_08チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN08(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_08", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_09チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN09(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_09", errMsglist);
            bChackFlg = false;
        }
        //予備_IN_N_10チェック
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRESERVEOUTN10(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "予備_IN_N_10", errMsglist);
            bChackFlg = false;
        }

        //社内コスト率チェック
        //「社内コスト率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEJLC(), LfcFrmBeanConst.FLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "社内コスト率", errMsglist);
            bChackFlg = false;
        } else {
            // 「社内コスト率」０は計算できません。
            double dComCostRate = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEJLC()));
            if (dComCostRate == 0) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR005, "ERR005", errMsglist);
                bChackFlg = false;
            }
        }
        // COFチェック
        //原調計算金利(COF)を入力してください。
        /* String strCof = LfcFrmComm.lostNull(outObjectTmp.getRATECADJ());
        if ("".equals(strCof)) {
        errMsglist = addErrMsgList(LfcLogicMsgConst.ERR006, "ERR006", errMsglist);
        bChackFlg = false;
        }*/
        if ("".equals(outObjectTmp.getRATECADJ()) || outObjectTmp.getRATECADJ() == null) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0101, "E0101", errMsglist);
            bChackFlg = false;
        } else {
            //「原調計算金利(COF)」は半角数字で入力してください。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATECADJ(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "原調計算金利(COF)", errMsglist);
                bChackFlg = false;
            } else {
                double dCof = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATECADJ()));
                // COFが入力されていません。ＣＯＦ（原調計算金利）
                if (dCof == 0) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR006, "ERR006", errMsglist);
                    bChackFlg = false;
                } else if (dCof < 0 || dCof > 20) {
                    // 「COF」範囲チェック(COF<0、COF>20の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR053, "ERR053", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //管販費率チェック
        //「管販費率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEEANI(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "管販費率", errMsglist);
            bChackFlg = false;
        } else {
            double dRateEAni = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEEANI()));
            // 「管販費率合計」範囲チェック(管販費率合計<0、管販費率合計>20の場合、エラー)
            if (dRateEAni < 0 || dRateEAni > 20) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR046, "ERR046", errMsglist);
                bChackFlg = false;
            }
        }
        //管販費率(Origination)チェック
        //管販費率(Origination)を入力してください。［入力必須］
        if (LfcLogicComm.getStatus(outObjectTmp.getRATEEAO()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0012, "E0012", errMsglist);
            bChackFlg = false;
        } else {
            //「管販費率Original」は半角数字で入力してください。。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEEAO(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "管販費率Original", errMsglist);
                bChackFlg = false;
            } else {
                double dRateEAO = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEEAO()));
                if (dRateEAO < -99.99 || dRateEAO > 99.99) {
                    // 「管販費率(Origination)」範囲チェック(管販費率(Origination)<-99.99、管販費率(Origination)>99.99の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR047, "ERR047", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //管販費率Serviceチェック
        //管販費率Serviceを入力してください。［入力必須］
        if (LfcLogicComm.getStatus(outObjectTmp.getRATEEAS()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0013, "E0013", errMsglist);
            bChackFlg = false;
        } else {
            //「管販費率Service」は半角数字で入力してください。。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEEAS(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "管販費率Service", errMsglist);
                bChackFlg = false;
            } else {
                double dRateEAS = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEEAS()));
                if (dRateEAS < -99.99 || dRateEAS > 99.99) {
                    // 「管販費率（管販費率S）」範囲チェック(管販費率（管販費率S）<-99.99、貸倒引当率>99.99の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR048, "ERR048", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //貸倒引当率チェック
        //貸倒引当率を入力してください。
        if (LfcLogicComm.getStatus(outObjectTmp.getRATELOSS()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0014, "E0014", errMsglist);
            bChackFlg = false;
        } else {
            //「貸倒引当率」は半角数字で入力してください。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATELOSS(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "貸倒引当率", errMsglist);
                bChackFlg = false;
            } else {
                double dRateLoss = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATELOSS()));
                // 「貸倒引当率」範囲チェック(貸倒引当率<-99.99、貸倒引当率>99.99の場合、エラー)
                if (dRateLoss < -99.99 || dRateLoss > 99.99) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR045, "ERR045", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //手数料収益率チェック
        //「手数料収益率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEFEE(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "手数料収益率", errMsglist);
            bChackFlg = false;
        } else {
            double dRateFee = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEFEE()));
            // 「手数料収益率合計」範囲チェック(手数料収益率合計<0、手数料収益率合計>20の場合、エラー)
            if (dRateFee < 0 || dRateFee > 20) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR049, "ERR049", errMsglist);
                bChackFlg = false;
            }
        }
        //手数料収益率NPPチェック
        //手数料收益率(NPP)を入力してください。
        //「手数料収益率NPP」は半角数字で入力してください。
        if (LfcLogicComm.getStatus(outObjectTmp.getRATEFEEN()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0015, "E0015", errMsglist);
            bChackFlg = false;
        } else {
            //「手数料収益率NPP」は半角数字で入力してください。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEFEEN(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "手数料収益率NPP", errMsglist);
                bChackFlg = false;
            } else {
                double dRateFeeN = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEFEEN()));
                if (dRateFeeN < -99.99 || dRateFeeN > 99.99) {
                    // 「手数料收益率(NPP)」範囲チェック(手数料收益率(NPP)<-99.99、手数料收益率(NPP)>99.99の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR050, "E0114", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //手数料収益率Releaseチェック
        //手数料收益率(Release)を入力してください。
        if (LfcLogicComm.getStatus(outObjectTmp.getRATEFEER()) == BEAN_STATE_NOINPUT) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0016, "E0016", errMsglist);
            bChackFlg = false;
        } else {
            //「手数料収益率Release」は半角数字で入力してください。
            if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getRATEFEER(), LfcFrmBeanConst.PLUSFLOAT)) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "手数料収益率Release", errMsglist);
                bChackFlg = false;
            } else {
                double dRateFeeR = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getRATEFEER()));
                if (dRateFeeR < -99.99 || dRateFeeR > 99.99) {
                    // 「手数料收益率(Release)」範囲チェック(手数料收益率(Release)<-99.99、手数料收益率(Release)>99.99の場合、エラー)
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR051, "ERR051", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        // 動産総合保険料率チェック
        //「動総保険料率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getDOSORATE(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "動産総合保険料率", errMsglist);
            bChackFlg = false;
        } else {
            double dDosoRate = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getDOSORATE()));
            // 動産総合保険料率の［入力範囲］ 0以上99以下
            if (dDosoRate < 0 || dDosoRate > 99) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR054, "ERR054", errMsglist);
                bChackFlg = false;
            }
        }
        //団信保険料率チェック
        //「団信保険料率」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getDANSHINRT(), LfcFrmBeanConst.PLUSFLOAT)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "団信保険料率", errMsglist);
            bChackFlg = false;
        }
        //「機械保険料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getMACHIFEE(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "機械保険料", errMsglist);
            bChackFlg = false;
        }
        //「火災保険料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getFIREFEE(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "火災保険料", errMsglist);
            bChackFlg = false;
        }
        //「船舶・その他保険料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getETCFEE(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "船舶・その他保険料", errMsglist);
            bChackFlg = false;
        }
        //「一時費用(イ)(公証)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getICHIJI1(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "一時費用(イ)(公証)", errMsglist);
            bChackFlg = false;
        }
        //「一時費用(ロ)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getICHIJI2(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "一時費用(ロ)", errMsglist);
            bChackFlg = false;
        }
        //「一時費用(ハ)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getICHIJI3(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "一時費用(ハ)", errMsglist);
            bChackFlg = false;
        }
        //「繰延費用(ヘ)(団信)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getKURINO1(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "繰延費用(ヘ)(団信)", errMsglist);
            bChackFlg = false;
        }
        //「繰延費用(ト)」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getKURINO2(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "繰延費用(ト)", errMsglist);
            bChackFlg = false;
        }
        //「保守料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getHOSHURYO(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "保守料", errMsglist);
            bChackFlg = false;
        }
        //「斡旋手数料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getASSEN(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "斡旋手数料", errMsglist);
            bChackFlg = false;
        }
        //「保険料」は半角数字で入力してください。
        if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getINSURANCE(), LfcFrmBeanConst.NUM)) {
            errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "保険料", errMsglist);
            bChackFlg = false;
        }

//      //支払方法は一括支払の場合
        PaydivInOutRecord bPaydiv = bOutBukenTmp.getShiharaiRecord();
        List<PaydivComplexType> Listpaydiv = bPaydiv.getPaydivInOut();
        // 購入価額
        double dPurchase = 0;
        if (Listpaydiv.isEmpty()) {
            // 購入額は必ず入力される
            if (LfcLogicComm.getStatus(outObjectTmp.getPURCHASE()) == BEAN_STATE_NOINPUT) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0009, "E0009", errMsglist);
                bChackFlg = false;
            } else {
                //購入価額は半角数字以外値を入力された場合
                if (LfcFrmComm.doZenkakuCheck(outObjectTmp.getPURCHASE(), LfcFrmBeanConst.NUM)) {
                    //購入価額の内訳金額が半角数字を入力してください。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0100, "E0100", "購入価額", errMsglist);
                    bChackFlg = false;
                } else {
                    // 購入価額
                    dPurchase = LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outObjectTmp.getPURCHASE()));
                    if (dPurchase < 1000 || dPurchase > 50000000000.0) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR008, "ERR008", errMsglist);
                        bChackFlg = false;
                    }
                }
            }
            // 支払予定日は必ず入力される
            if (LfcLogicComm.getStatus(outObjectTmp.getDATEPAYMT()) == BEAN_STATE_NOINPUT) {
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0104, "E0104", errMsglist);
                bChackFlg = false;
            } else {
                if (outObjectTmp.getDATEPAYMT().length() != 10 && outObjectTmp.getDATEPAYMT().length() != 8) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR002, "ERR002", errMsglist);
                    bChackFlg = false;
                }
                //一括支払の場合、支払予定日が有効の日付ではありません
                if (!LfcFrmComm.isDate(outObjectTmp.getDATEPAYMT()) && !"".equals(outObjectTmp.getDATEPAYMT())) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0017, "E0017", errMsglist);
                    bChackFlg = false;
                }
            }
        } else {
            // 支払方法は分割支払の場合、
            // 支払予定日入力されば、支払予定日は歴の上で存在チェック
            dPurchase = 0;
            Iterator<PaydivComplexType> ite = Listpaydiv.iterator();
            while (ite.hasNext()) {
                PaydivComplexType outPaydivTmp = ite.next();
                // 支払予定日は必ず入力される
                if (LfcLogicComm.getStatus(outPaydivTmp.getSHIHARAIDATE()) == BEAN_STATE_NOINPUT) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0010, "E0010", errMsglist);
                    bChackFlg = false;
                } else {
                    if (outPaydivTmp.getSHIHARAIDATE().length() != 10 && outPaydivTmp.getSHIHARAIDATE().length() != 8) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR002, "ERR002", errMsglist);
                        bChackFlg = false;
                    }
                }
                if (LfcFrmComm.doZenkakuCheck(outPaydivTmp.getSHIHARAIDATE(), LfcFrmBeanConst.DATE)) {
                    //支払予定日が半角数字を入力してください。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0119, "E0119", errMsglist);
                    bChackFlg = false;
                }
                if (!LfcFrmComm.isDate(outPaydivTmp.getSHIHARAIDATE()) && !"".equals(outPaydivTmp.getSHIHARAIDATE())) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0017, "E0017", errMsglist);
                    bChackFlg = false;
                }
                // 購入額は必ず入力される
                if (LfcLogicComm.getStatus(outPaydivTmp.getSHIHARAIGAKU()) == BEAN_STATE_NOINPUT) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0009, "E0009", errMsglist);
                    bChackFlg = false;
                }
                if (LfcFrmComm.doZenkakuCheck(outPaydivTmp.getSHIHARAIGAKU(), LfcFrmBeanConst.NUM)) {
                    //購入価額の内訳金額が半角数字を入力してください。
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0118, "E0118", errMsglist);
                    bChackFlg = false;
                }
                if (bChackFlg) {
                    dPurchase = dPurchase + LfcFrmComm.ToDouble(LfcFrmComm.lostNull(outPaydivTmp.getSHIHARAIGAKU()));
                }
            }
            outObjectTmp.setPURCHASE("" + dPurchase);
            outObjectTmp.setDATEPAYMT("");
            if (bChackFlg) {
                if (dPurchase < 1000 || dPurchase > 50000000000.0) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcLogicMsgConst.ERR008, "ERR008", errMsglist);
                    bChackFlg = false;
                }
            }
        }

        String strTemp = "";
        CollectionInOutRecord bKaisyuTmp = bOutBukenTmp.getKaisyuRecord();
        List<CollectionComplexType> ListKaisyu = bKaisyuTmp.getKaishuInOut();
        if (!ListKaisyu.isEmpty()) {
            Iterator<CollectionComplexType> iteKaisyu = ListKaisyu.iterator();
            CollectionComplexType outCollectTmp = null;
            while (iteKaisyu.hasNext()) {
                outCollectTmp = iteKaisyu.next();
                String tmp1 = LfcFrmComm.lostNull(outCollectTmp.getINCOME());
                String tmp2 = LfcFrmComm.lostNull(outCollectTmp.getKAISYUDATE());
                String tmp3 = LfcFrmComm.lostNull(outCollectTmp.getCYCLE());
                String tmp4 = LfcFrmComm.lostNull(outCollectTmp.getFREQUE());

                if (LfcFrmComm.doZenkakuCheck(tmp1, LfcFrmBeanConst.CURRENCY)) {
                    // "回収金額が半角数字を入力してください。",
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0114, "E0114", errMsglist);
                    bChackFlg = false;
                }

                if (LfcFrmComm.doZenkakuCheck(tmp2, LfcFrmBeanConst.DATE)) {
                    // "回収予定日が半角数字を入力してください。",
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0115, "E0115", errMsglist);
                    bChackFlg = false;
                }

                if (LfcFrmComm.doZenkakuCheck(tmp3, LfcFrmBeanConst.NUM)) {
                    // "回収ｻｲｸﾙが半角数字を入力してください。",
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0116, "E0116", errMsglist);
                    bChackFlg = false;
                }

                if (LfcFrmComm.doZenkakuCheck(tmp4, LfcFrmBeanConst.NUM)) {
                    // "回収が半角数字を入力してください。",
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0117, "E0117", errMsglist);
                    bChackFlg = false;
                }

                if (!"".equals(LfcFrmComm.lostNull(outCollectTmp.getKAISYUDATE()))) {

                    strTemp = outCollectTmp.getKAISYUDATE();
                    int n = 0;

                    for (int j = 0; j <
                            strTemp.length(); j++) {
                        if (strTemp.charAt(j) == '/') {
                            n = n + 1;
                        }

                    }

                    String strTemp2 = "";
                    if (n == 2) {
                        int iPosition = strTemp.indexOf("/");
                        strTemp2 =
                                strTemp.substring(0, iPosition + 1);
                        strTemp =
                                strTemp.substring(iPosition + 1);
                        iPosition =
                                strTemp.indexOf("/");
                        if (strTemp.substring(0, iPosition).length() < 2) {
                            strTemp2 = strTemp2 + "0" + strTemp.substring(0, iPosition + 1);
                        } else {
                            strTemp2 = strTemp2 + strTemp.substring(0, iPosition + 1);
                        }

                        strTemp = strTemp.substring(iPosition + 1);
                        if (strTemp.length() < 2) {
                            strTemp2 = strTemp2 + "0" + strTemp;
                        } else {
                            strTemp2 = strTemp2 + strTemp;
                        }

                    }
                    strTemp = outCollectTmp.getKAISYUDATE();
                    if (!LfcFrmComm.isDate(strTemp)) {
                        errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0092, "E0092", errMsglist);
                        // arrObeject[.tblSepaWithdrawList.getCellEditor.getTableCellEditorComponent.setBackground(color.red);
                        bChackFlg = false;
                    }
                }
            }
        }
        return errMsglist;
    }

    /**
     * 物件情報をGcalに設定するメソッド。     <BR>
     * @param bOutBukenTmp
     * @return
     */
    public boolean doSetGcalLS(BukenOutputComplexType bOutBukenTmp) {
        boolean bChackFlg = true;

        ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
        outObjectTmp = bOutBukenTmp.getBukenRecord();

        _gcal = new Gcal();
        //契約番号
        _gcal.setKeiyaku("L"+outObjectTmp.getRECORDNO());
        //試算方法
        _gcal.setKenshu1(outObjectTmp.getCALCULATEBASE().trim());
        //試算TYPE
        _gcal.setKenshu2(outObjectTmp.getCALCULATETYPE().trim());
        //物件?(FROM)
        _gcal.setBukkenF(LfcFrmComm.toInt(outObjectTmp.getBUKKENFR().trim()));
        //物件?(TO)
        _gcal.setBukkenT(LfcFrmComm.toInt(outObjectTmp.getBUKKENTO().trim()));
        //購入価額
        _gcal.setPurchas(LfcFrmComm.ToDouble(outObjectTmp.getPURCHASE().trim()));
        //残価
        _gcal.setRemVAL(LfcFrmComm.ToDouble(outObjectTmp.getREMAINVAL().trim()));
        //残価率
        _gcal.setRemVRT(LfcFrmComm.ToDouble(outObjectTmp.getREMVALRT().trim()) / 100);
        //団信保険料率
        _gcal.setDansRt(LfcFrmComm.ToDouble(outObjectTmp.getDANSHINRT()));
        //割賦保険料
        _gcal.setKappuI(0);
        //一時費用(イ)(公証)
        _gcal.setIchiji1(LfcFrmComm.ToDouble(outObjectTmp.getICHIJI1()));
        //その他一時費用(ﾛ)
        _gcal.setIchiji2(LfcFrmComm.ToDouble(outObjectTmp.getICHIJI2()));
        //その他一時費用(ﾊ)
        _gcal.setIchiji3(LfcFrmComm.ToDouble(outObjectTmp.getICHIJI3()));
        //その他繰延費用(ﾍ)
        _gcal.setKurino1(LfcFrmComm.ToDouble(outObjectTmp.getKURINO1()));
        //その他繰延費用(ﾄ)
        _gcal.setKurino2(LfcFrmComm.ToDouble(outObjectTmp.getKURINO2()));
        //wanglin 20120312 S
        //低炭素リース保険料率
        _gcal.setCriRt(LfcFrmComm.ToDouble(outObjectTmp.getRESERVEOUTN01().trim()));
        //低炭素リース保険料
        _gcal.setCriF(LfcFrmComm.ToLong(outObjectTmp.getRESERVEOUTN02().trim()));
        //低炭素リース付保期間
        _gcal.setCriTm(LfcFrmComm.toInt(outObjectTmp.getRESERVEOUTN03().trim()));
        //wanglin 20120312 E
        //保守料
        _gcal.setHoshury(LfcFrmComm.ToDouble(outObjectTmp.getHOSHURYO().trim()));
        //斡旋手数料
        _gcal.setAssen(LfcFrmComm.ToDouble(outObjectTmp.getASSEN().trim()));
        //機械保険料
        _gcal.setMachiF(LfcFrmComm.ToDouble(outObjectTmp.getMACHIFEE().trim()));
        //火災保険料
        _gcal.setFireF(LfcFrmComm.ToDouble(outObjectTmp.getFIREFEE().trim()));
        //船舶・ソノタ保険料
        _gcal.setEtcF(LfcFrmComm.ToDouble(outObjectTmp.getETCFEE().trim()));
        //社内金利
        _gcal.setRateJL(LfcFrmComm.ToDouble(outObjectTmp.getRATEJLC().trim()) / 100);
        //運用利回り
        _gcal.setRateUN(LfcFrmComm.ToDouble(outObjectTmp.getRATEUNYO().trim()) / 100);
        //ＴＲ
        _gcal.setTrueRT(LfcFrmComm.ToDouble(outObjectTmp.getTRUERATE().trim()) / 100);
        //原調計算金利
        String strCof = "";
        if (LfcFrmComm.doFormatToFloat(outObjectTmp.getRATECADJ()) != null && !"".equals(outObjectTmp.getRATECADJ())) {
            strCof = LfcFrmComm.doFormatToFloat(outObjectTmp.getRATECADJ()).toString().trim();
        }

        _gcal.setRateCADJ(LfcFrmComm.ToDouble(strCof) / 100);
        //ＲＯＩ
        _gcal.setRateROI(LfcFrmComm.ToDouble(outObjectTmp.getRATEROI().trim()) / 100);
        //pzk add 20050512 start
        _gcal.setROE(LfcFrmComm.ToDouble(outObjectTmp.getROE().trim()) / 100);
        //pzk add 20050512 end
        //動総保険料率
        String strDosoRate = "";
        if (outObjectTmp.getDOSORATE() != null && !"".equals(outObjectTmp.getDOSORATE())) {
            strDosoRate = outObjectTmp.getDOSORATE().trim();
        }

        _gcal.setDosoRt(LfcFrmComm.ToDouble(strDosoRate));
        //分割支払有無区分
        boolean bSwPayFlag; //支払(一括支払・分割支払)
        PaydivInOutRecord bPaydiv = bOutBukenTmp.getShiharaiRecord();
        List<PaydivComplexType> Listpaydiv = bPaydiv.getPaydivInOut();
        if (Listpaydiv.isEmpty()) {
            bSwPayFlag = LfcLogicPgConst.KUBUN_NO;
        } else { //支払(分割支払)
            bSwPayFlag = LfcLogicPgConst.KUBUN_YES;
        }
        _gcal.setSwPay(bSwPayFlag);

        //賠責保険付保区分
        String strSwBaisFlag;
        if (outObjectTmp.getSWBAISEKI() != null && !"".equals(outObjectTmp.getSWBAISEKI())) { //有
            strSwBaisFlag = "1";
        } else { //無
            strSwBaisFlag = "2";
        }
        _gcal.setSwBais(strSwBaisFlag);

        //少額資産区分
        String strSwSProFlag;
        if (outObjectTmp.getSWSPRO() != null && !"".equals(outObjectTmp.getSWSPRO())) { //不算入
            strSwSProFlag = "1";
        } else { //無
            strSwSProFlag = "2";
        }
        _gcal.setSwSPro(strSwSProFlag);

        String strSwSoftFlag = ""; //ソフトウェア物件区分
        if (outObjectTmp.getSWSOFT() != null && !"".equals(outObjectTmp.getSWSOFT())) { //不算入
            strSwSoftFlag = "1";
        } else {
            strSwSoftFlag = "2";
        }
        _gcal.setSwSoft(strSwSoftFlag);


        //団信保険料率
        if (_gcal.getDansRt() == -9.99999) {
            _gcal.setDansRt(0);
        }

        //ﾘｰｽ月数
        String strLeaseM = "";
        if (outObjectTmp.getLEASEM() != null && !"".equals(outObjectTmp.getLEASEM())) {
            strLeaseM = outObjectTmp.getLEASEM().trim();
        }
        _gcal.setLeaseM(LfcFrmComm.toInt(strLeaseM));

        //法定耐用年数
        String strDuraY = "";
        if (outObjectTmp.getDURABLEY() != null && !"".equals(outObjectTmp.getDURABLEY())) {
            strDuraY = outObjectTmp.getDURABLEY().trim();
        }
        _gcal.setDuraY(LfcFrmComm.toInt(strDuraY));

        //社内コスト率を再計算するを追加　HBQ　2007/07/06　begin
        //手数料率(合計)を再計算する
        outObjectTmp.setRATEFEE(Double.toString(LfcLogicComm.dround((LfcFrmComm.ToDouble(outObjectTmp.getRATEFEER()) + LfcFrmComm.ToDouble(outObjectTmp.getRATEFEEN())), 5)));
        // 管販費率合計を再計算する
        outObjectTmp.setRATEEANI(Double.toString(LfcLogicComm.dround((LfcFrmComm.ToDouble(outObjectTmp.getRATEEAO()) + LfcFrmComm.ToDouble(outObjectTmp.getRATEEAS())), 5)));
        // 社内コスト率を再計算する
        outObjectTmp.setRATEJLC(Double.toString(LfcLogicComm.dround(
                (LfcFrmComm.ToDouble(LfcFrmComm.doFormatToFloat(
                outObjectTmp.getRATECADJ())) + LfcFrmComm.ToDouble(outObjectTmp.getRATEEAO()) + LfcFrmComm.ToDouble(outObjectTmp.getRATEEAS()) + LfcFrmComm.ToDouble(outObjectTmp.getRATELOSS()) - (LfcFrmComm.ToDouble(outObjectTmp.getRATEFEEN()) + LfcFrmComm.ToDouble(outObjectTmp.getRATEFEER()))), 5)));
        //社内コスト率を再計算するを追加　HBQ　2007/07/06　end

        //物件数量
        _gcal.setQuant(LfcFrmComm.toInt(outObjectTmp.getQUANTITY()));
        //合計料率
        _gcal.setRyortT(LfcFrmComm.ToDouble(outObjectTmp.getRYORITSUT()) / 100);
        //月料率
        _gcal.setRyortM(LfcFrmComm.ToDouble(outObjectTmp.getRYORITSUM()) / 100);
        //貸倒引当率
        _gcal.setRtLossR(LfcFrmComm.ToDouble(outObjectTmp.getRATELOSS()) / 100);
        //管販比率(Origination)
        _gcal.setRtEAniO(LfcFrmComm.ToDouble(outObjectTmp.getRATEEAO()) / 100);
        //管販比率(Servicing)
        _gcal.setRtEAniS(LfcFrmComm.ToDouble(outObjectTmp.getRATEEAS()) / 100);
        //管販比率(合計)
        _gcal.setRtEAniTotal(LfcFrmComm.ToDouble(outObjectTmp.getRATEEANI()) / 100);
        //手数料率(NPP)
        _gcal.setRtFeeN(LfcFrmComm.ToDouble(outObjectTmp.getRATEFEEN()) / 100);
        //手数料率(Release)
        _gcal.setRtFeeR(LfcFrmComm.ToDouble(outObjectTmp.getRATEFEER()) / 100);
        //手数料率(合計)
        _gcal.setRtFeeTotal(LfcFrmComm.ToDouble(outObjectTmp.getRATEFEE()) / 100);
        //FinanceMargin
        _gcal.setFinanceMargin(LfcFrmComm.ToDouble(outObjectTmp.getFINANCEMARGIN()));
        //PvFinanceMargin
        _gcal.setPvFinanceMargin(LfcFrmComm.ToDouble(outObjectTmp.getPVFINANCEMARGIN()));
        //RaMargin
        _gcal.setRaMargin(LfcFrmComm.ToDouble(outObjectTmp.getRateRAM()));
        //RaPvMargin
        _gcal.setRaPvMargin(LfcFrmComm.ToDouble(outObjectTmp.getRAPVDirectM()));

        if (outObjectTmp.getDATEKENSH() != null && !"".equals(outObjectTmp.getDATEKENSH())) {
            if (outObjectTmp.getDATEKENSH().length() == 10) {
                //検収予定日（年）
                _gcal.setDate1YY(LfcFrmComm.toInt(outObjectTmp.getDATEKENSH().substring(0, 4)));
                // 検収予定日（月）
                _gcal.setDate1MM(LfcFrmComm.toInt(outObjectTmp.getDATEKENSH().substring(5, 7)));
                //検収予定日（日）
                _gcal.setDate1DD(LfcFrmComm.toInt(outObjectTmp.getDATEKENSH().substring(8, 10)));

            } else {
                //検収予定日（年）
                _gcal.setDate1YY(LfcFrmComm.toInt(outObjectTmp.getDATEKENSH().substring(0, 4)));
                // 検収予定日（月）
                _gcal.setDate1MM(LfcFrmComm.toInt(outObjectTmp.getDATEKENSH().substring(4, 6)));
                //検収予定日（日）
                _gcal.setDate1DD(LfcFrmComm.toInt(outObjectTmp.getDATEKENSH().substring(6, 8)));
            }

        } else {
            //検収予定日（年）
            _gcal.setDate1YY(0);
            // 検収予定日（月）
            _gcal.setDate1MM(0);
            //検収予定日（日）
            _gcal.setDate1DD(0);
        }
        //検収予定日
        _gcal.setDKensh(LfcLogicComm.db3Itod(_gcal.getDate1YY(), _gcal.getDate1MM(), _gcal.getDate1DD()));

        //支払予定日
        if (!_gcal.getSwPay()) { //支払(一括支払)
            if (outObjectTmp.getDATEPAYMT() != null && !"".equals(outObjectTmp.getDATEPAYMT().trim())) {
                if (outObjectTmp.getDATEPAYMT().trim().length() == 10) {
                    //支払予定日（年）
                    _gcal.setDate2YY(LfcFrmComm.toInt(outObjectTmp.getDATEPAYMT().trim().substring(0, 4)));
                    //支払予定日（月）
                    _gcal.setDate2MM(LfcFrmComm.toInt(outObjectTmp.getDATEPAYMT().trim().substring(5, 7)));
                    //支払予定日（日）
                    _gcal.setDate2DD(LfcFrmComm.toInt(outObjectTmp.getDATEPAYMT().trim().substring(8, 10)));
                } else {
                    //支払予定日（年）
                    _gcal.setDate2YY(LfcFrmComm.toInt(outObjectTmp.getDATEPAYMT().trim().substring(0, 4)));
                    //支払予定日（月）
                    _gcal.setDate2MM(LfcFrmComm.toInt(outObjectTmp.getDATEPAYMT().trim().substring(4, 6)));
                    //支払予定日（日）
                    _gcal.setDate2DD(LfcFrmComm.toInt(outObjectTmp.getDATEPAYMT().trim().substring(6, 8)));
                }
            } else {
                //支払予定日（年）
                _gcal.setDate2YY(0);
                // 支払予定日（月）
                _gcal.setDate2MM(0);
                //支払予定日（日）
                _gcal.setDate2DD(0);
            }

        } else {
            //支払予定日（年）
            _gcal.setDate2YY(0);
            // 支払予定日（月）
            _gcal.setDate2MM(0);
            //支払予定日（日）
            _gcal.setDate2DD(0);
        }
        //支払予定日
        _gcal.setDPaymt(LfcLogicComm.db3Itod(_gcal.getDate2YY(), _gcal.getDate2MM(), _gcal.getDate2DD()));

        String strPreLeaseDate = outObjectTmp.getDATEINC0();
        String strTemp = strPreLeaseDate;

        int n = 0;
        for (int i = 0; i <
                strTemp.length(); i++) {
            if (strTemp.charAt(i) == '/') {
                n = n + 1;
            }
        }

        if (n == 2) {
            String strTemp2 = "";
            int iPosition = strTemp.indexOf("/");
            strTemp2 =
                    strTemp.substring(0, iPosition + 1);
            strTemp =
                    strTemp.substring(iPosition + 1);
            iPosition =
                    strTemp.indexOf("/");
            if (strTemp.substring(0, iPosition).length() < 2) {
                strTemp2 = strTemp2 + "0" + strTemp.substring(0, iPosition + 1);
            } else {
                strTemp2 = strTemp2 + strTemp.substring(0, iPosition + 1);
            }

            strTemp = strTemp.substring(iPosition + 1);
            if (strTemp.length() < 2) {
                strTemp2 = strTemp2 + "0" + strTemp;
            } else {
                strTemp2 = strTemp2 + strTemp;
            }

            strPreLeaseDate = strTemp2;
        }
        //信保付保区分
        _gcal.setSwCri("2");
        //前受ﾘｰｽ料月数
        _gcal.setInc0M(LfcFrmComm.ToDouble(outObjectTmp.getINC0M()));
        //前受ﾘｰｽ料回収金額
        _gcal.setInc0(LfcFrmComm.ToDouble(outObjectTmp.getINCOME0()));
        if (_gcal.getInc0M() > 0 || _gcal.getInc0() > 0) {
            if ("".equals(strPreLeaseDate.trim()) || "0".equals(strPreLeaseDate.trim())) {
                //前受ﾘｰｽ料回収日（年）
                _gcal.setDate3YY(0);
                //前受ﾘｰｽ料回収日（月）
                _gcal.setDate3YY(0);
                //前受ﾘｰｽ料回収日（日）
                _gcal.setDate3YY(0);
                //前受ﾘｰｽ料月数回収予定日
                _gcal.setDInc0(0);
            } else {
                if (strPreLeaseDate != null && !"".equals(strPreLeaseDate)) {
                    if (strPreLeaseDate.length() == 10) {
                        //前受ﾘｰｽ料回収日（年）
                        _gcal.setDate3YY(
                                LfcFrmComm.toInt(strPreLeaseDate.substring(0, 4)));
                        //前受ﾘｰｽ料回収日（月）
                        _gcal.setDate3MM(
                                LfcFrmComm.toInt(strPreLeaseDate.substring(5, 7)));
                        //前受ﾘｰｽ料回収日（日）
                        _gcal.setDate3DD(
                                LfcFrmComm.toInt(strPreLeaseDate.substring(8, 10)));
                        //前受ﾘｰｽ料月数回収予定日
                        _gcal.setDInc0(
                                LfcFrmComm.ToLong(
                                strPreLeaseDate.substring(0, 4) + strPreLeaseDate.substring(5, 7) + strPreLeaseDate.substring(8, 10)));
                    } else {
                        //前受ﾘｰｽ料回収日（年）
                        _gcal.setDate3YY(
                                LfcFrmComm.toInt(strPreLeaseDate.substring(0, 4)));
                        //前受ﾘｰｽ料回収日（月）
                        _gcal.setDate3MM(
                                LfcFrmComm.toInt(strPreLeaseDate.substring(4, 6)));
                        //前受ﾘｰｽ料回収日（日）
                        _gcal.setDate3DD(
                                LfcFrmComm.toInt(strPreLeaseDate.substring(6, 8)));
                        //前受ﾘｰｽ料月数回収予定日
                        _gcal.setDInc0(LfcFrmComm.ToLong(strPreLeaseDate));
                    }

                } else {
                    //前受ﾘｰｽ料回収日（年）
                    _gcal.setDate3YY(0);
                    //前受ﾘｰｽ料回収日（月）
                    _gcal.setDate3MM(0);
                    //前受ﾘｰｽ料回収日（日）
                    _gcal.setDate3DD(0);
                    //前受ﾘｰｽ料月数回収予定日
                    _gcal.setDInc0(0);
                }
            }
        } else {
            //前受ﾘｰｽ料回収日（年）
            _gcal.setDate3YY(0);
            //前受ﾘｰｽ料回収日（月）
            _gcal.setDate3MM(0);
            //前受ﾘｰｽ料回収日（日）
            _gcal.setDate3DD(0);
            //前受ﾘｰｽ料月数回収予定日
            _gcal.setDInc0(0);
        }
        //残価率優先ﾁｪｯｸ
        _gcal.setRemValFlg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setRemVRtFlg(LfcLogicPgConst.KUBUN_YES);

        if (_gcal.getRemVRT() > 0) {
            _gcal.setFremIX(0);
            _gcal.setRemValFlg(LfcLogicPgConst.KUBUN_YES);
            _gcal.setRemVRtFlg(LfcLogicPgConst.KUBUN_NO);
        }

        //前受ﾘｰｽ月数優先ﾁｪｯｸ
        _gcal.setInc0Flg(LfcLogicPgConst.KUBUN_NO);
        _gcal.setInc0MFlg(LfcLogicPgConst.KUBUN_YES);
        if (_gcal.getInc0M() > 0) {
            _gcal.setInc0Flg(LfcLogicPgConst.KUBUN_YES);
            _gcal.setInc0MFlg(LfcLogicPgConst.KUBUN_NO);
        }


//20040907 ljq add s
//		_gcal.setLeverage(LfcFrmComm.toInt(_lsCalBaseInfoFrm.txtLeverageRatio.getText()));
        String strTmpRatio = outObjectTmp.getLEVERAGERATIO();
        if (strTmpRatio == null) {
            _gcal.setLeverage(LfcFrmComm.toInt("16"));
        } else {
            if (strTmpRatio.length() < 2) {
            } else {
                strTmpRatio = strTmpRatio.substring(0, strTmpRatio.length() - 2);
            }
            _gcal.setLeverage(LfcFrmComm.toInt(strTmpRatio));
        }

//20040907 ljq add e

//		ydy add 20061011 s
//		 機種CD
        _gcal.setCstKishuCD(outObjectTmp.getCSTKISHUCD());
        //信保機種CD
        _gcal.setCriCd("");
        //コスト率選択情報を設定する
        _gcal.setCstKishuCD("");

//		ydy add 20061011 e
        //20070410 zyb add s
        if (outObjectTmp.getTAX() != null && !"".equals(outObjectTmp.getTAX())) {
            _gcal.setROITax(outObjectTmp.getTAX());
        } else {
            String strROITax = "" + LfcFrmComm.dround(1 - LfcLogicPgConst.USA_PERSON_TAX, 2);
            _gcal.setROITax(strROITax);
        }

        //20070410 zyb add e
        return bChackFlg;
    }

    /**
     * 物件情報をPayDIVに設定するメソッド。     <BR>
     * @param bOutBukenTmp
     * @return boolean
     */
    void doSetPaydiv(BukenOutputComplexType bOutBukenTmp) {
        _paydiv = new Paydiv();
        PaydivInOutRecord bPaydiv = bOutBukenTmp.getShiharaiRecord();
        List<PaydivComplexType> Listpaydiv = bPaydiv.getPaydivInOut();
        if (!Listpaydiv.isEmpty()) {
            Iterator<PaydivComplexType> ite = Listpaydiv.iterator();
            int i = 0;
            while (ite.hasNext()) {
                PaydivComplexType outPaydivTmp = ite.next();
                _paydiv.setAct(true, i);
                _paydiv.setPurchas(Double.parseDouble(outPaydivTmp.getSHIHARAIGAKU()), i);
                if (outPaydivTmp.getSHIHARAIDATE() != null && !"".equals(outPaydivTmp.getSHIHARAIDATE().trim())) {
                    if (outPaydivTmp.getSHIHARAIDATE().length() == 10) {
                        //支払予定日（年）
                        _paydiv.setDateYY(LfcFrmComm.toInt(outPaydivTmp.getSHIHARAIDATE().trim().substring(0, 4)), i);
                        //支払予定日（月）
                        _paydiv.setDateMM(LfcFrmComm.toInt(outPaydivTmp.getSHIHARAIDATE().trim().substring(5, 7)), i);
                        //支払予定日（日）
                        _paydiv.setDateDD(LfcFrmComm.toInt(outPaydivTmp.getSHIHARAIDATE().trim().substring(8, 10)), i);
                    } else {
                        //支払予定日（年）
                        _paydiv.setDateYY(LfcFrmComm.toInt(outPaydivTmp.getSHIHARAIDATE().trim().substring(0, 4)), i);
                        //支払予定日（月）
                        _paydiv.setDateMM(LfcFrmComm.toInt(outPaydivTmp.getSHIHARAIDATE().trim().substring(4, 6)), i);

                        //支払予定日（日）
                        _paydiv.setDateDD(LfcFrmComm.toInt(outPaydivTmp.getSHIHARAIDATE().trim().substring(6, 8)), i);
                    }
                } else {
                    //支払予定日（年）
                    _paydiv.setDateYY(0, i);
                    // 支払予定日（月）
                    _paydiv.setDateMM(0, i);
                    //支払予定日（日）
                    _paydiv.setDateDD(0, i);
                }

                i++;
            }

        }

    }

    /**
     * 回収情報をStairsに設定するメソッド。     <BR>
     */
    void doSetStairs(BukenOutputComplexType bOutBukenTmp) {
        _stairs = new Stairs();
        CollectionInOutRecord bKaisyuTmp = bOutBukenTmp.getKaisyuRecord();
        List<CollectionComplexType> ListKaisyu = bKaisyuTmp.getKaishuInOut();
        if (!ListKaisyu.isEmpty()) {
            Iterator<CollectionComplexType> iteKaisyu = ListKaisyu.iterator();
            CollectionComplexType outCollectTmp = null;
            int i = 0;
            while (iteKaisyu.hasNext()) {
                outCollectTmp = iteKaisyu.next();
                String tmp1 = LfcFrmComm.lostNull(outCollectTmp.getINCOME());
                String tmp2 = LfcFrmComm.lostNull(outCollectTmp.getKAISYUDATE());
                String tmp3 = LfcFrmComm.lostNull(outCollectTmp.getCYCLE());
                String tmp4 = LfcFrmComm.lostNull(outCollectTmp.getFREQUE());
                //回収情報
                if (!"".equals(tmp1) || !"".equals(tmp2) || !"".equals(tmp3) || !"".equals(tmp4)) {
                    _stairs.setAct(true, i);
                } else {
                    _stairs.setAct(false, i);
                }

                _stairs.setIncome(LfcFrmComm.ToDouble(tmp1), i);
                _stairs.setCycle(LfcFrmComm.toInt(tmp3), i);
                _stairs.setFreque(LfcFrmComm.toInt(tmp4), i);

                String strTemp = tmp2;

                if (!"".equals(strTemp) && strTemp != null) {
                    int n = 0;
                    for (int j = 0; j <
                            strTemp.length(); j++) {
                        if (strTemp.charAt(j) == '/') {
                            n = n + 1;
                        }

                    }

                    if (n == 2) {
                        String strTemp2 = "";
                        int iPosition = strTemp.indexOf("/");
                        strTemp2 =
                                strTemp.substring(0, iPosition + 1);
                        strTemp =
                                strTemp.substring(iPosition + 1);
                        iPosition =
                                strTemp.indexOf("/");
                        if (strTemp.substring(0, iPosition).length() < 2) {
                            strTemp2 =
                                    strTemp2 + "0" + strTemp.substring(0, iPosition + 1);
                        } else {
                            strTemp2 =
                                    strTemp2 + strTemp.substring(0, iPosition + 1);
                        }

                        strTemp = strTemp.substring(iPosition + 1);
                        if (strTemp.length() < 2) {
                            strTemp2 = strTemp2 + "0" + strTemp;
                        } else {
                            strTemp2 = strTemp2 + strTemp;
                        }

                        tmp2 = strTemp2;
                    }

                }

                if (tmp2 != null && !"".equals(tmp2)) {
                    if (tmp2.length() == 10) {
                        _stairs.setDateYY(LfcFrmComm.toInt(tmp2.substring(0, 4)), i);
                        _stairs.setDateMM(LfcFrmComm.toInt(tmp2.substring(5, 7)), i);
                        _stairs.setDateDD(LfcFrmComm.toInt(tmp2.substring(8, 10)), i);
                    } else {
                        _stairs.setDateYY(LfcFrmComm.toInt(tmp2.substring(0, 4)), i);
                        _stairs.setDateMM(LfcFrmComm.toInt(tmp2.substring(4, 6)), i);
                        _stairs.setDateDD(LfcFrmComm.toInt(tmp2.substring(6, 8)), i);
                    }

                } else {
                    _stairs.setDateYY(0, i);
                    _stairs.setDateMM(0, i);
                    _stairs.setDateDD(0, i);
                }

                i++;
            }

        }
    }

    boolean isMutiple(BukenOutputComplexType bOutBukenTmp) {
        CollectionInOutRecord bKaisyuTmp = bOutBukenTmp.getKaisyuRecord();
        List<CollectionComplexType> ListKaisyu = bKaisyuTmp.getKaishuInOut();
        if (!ListKaisyu.isEmpty()) {
            Iterator<CollectionComplexType> iteKaisyu = ListKaisyu.iterator();
            CollectionComplexType outCollectTmp = null;
            int nCounter = 0;
            while (iteKaisyu.hasNext()) {
                outCollectTmp = iteKaisyu.next();
                if (!"".equals(outCollectTmp.getINCOME()) || !"".equals(outCollectTmp.getKAISYUDATE()) || !"".equals(outCollectTmp.getCYCLE()) || !"".equals(outCollectTmp.getFREQUE())) {
                    nCounter++;
                    if (nCounter > 1) {
                        return true;
                    }

                }
            }
        }
        return false;
    }

    /**
     * 物件情報をGcalに設定するメソッド。     <BR>
     * @param bOutBukenTmp
     * @return boolean
     */
    void doSetGcalKP(BukenOutputComplexType bOutBukenTmp) {
        //boolean bChackFlg = true;

        ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
        outObjectTmp = bOutBukenTmp.getBukenRecord();

        _gcal = new Gcal();
        //契約番号
        _gcal.setKeiyaku("S"+outObjectTmp.getRECORDNO());
        //試算方法
        _gcal.setKenshu1(outObjectTmp.getCALCULATEBASE());
        //試算TYPE
        _gcal.setKenshu2(outObjectTmp.getCALCULATETYPE());
        //物件?(FROM)
        _gcal.setBukkenF(LfcFrmComm.toInt(outObjectTmp.getBUKKENFR()));
        //物件?(TO)
        _gcal.setBukkenT(LfcFrmComm.toInt(outObjectTmp.getBUKKENTO()));
        //購入価額
        _gcal.setPurchas(LfcFrmComm.ToDouble(outObjectTmp.getPURCHASE()));
        //残価
        _gcal.setRemVAL(0);
        //団信保険料率
        _gcal.setDansRt(LfcFrmComm.ToDouble(outObjectTmp.getDANSHINRT()));
        //割賦保険料
        _gcal.setKappuI(LfcFrmComm.ToDouble(outObjectTmp.getKAPPUINS()));
        //一時費用(イ)(公証)
        _gcal.setIchiji1(LfcFrmComm.ToDouble(outObjectTmp.getICHIJI1()));
        //その他一時費用(ﾛ)
        _gcal.setIchiji2(LfcFrmComm.ToDouble(outObjectTmp.getICHIJI2()));
        //その他一時費用(ﾊ)
        _gcal.setIchiji3(LfcFrmComm.ToDouble(outObjectTmp.getICHIJI3()));
        //その他繰延費用(ﾍ)
        _gcal.setKurino1(LfcFrmComm.ToDouble(outObjectTmp.getKURINO1()));
        //その他繰延費用(ﾄ)
        _gcal.setKurino2(LfcFrmComm.ToDouble(outObjectTmp.getKURINO2()));
        //保守料
        _gcal.setHoshury(LfcFrmComm.ToDouble(outObjectTmp.getHOSHURYO()));
        //斡旋手数料
        _gcal.setAssen(LfcFrmComm.ToDouble(outObjectTmp.getASSEN()));
        //機械保険料
        _gcal.setMachiF(LfcFrmComm.ToDouble(outObjectTmp.getMACHIFEE()));
        //火災保険料
        _gcal.setFireF(LfcFrmComm.ToDouble(outObjectTmp.getFIREFEE()));
        //船舶・ソノタ保険料
        _gcal.setEtcF(LfcFrmComm.ToDouble(outObjectTmp.getETCFEE()));

        //運用利回り
        _gcal.setRateUN(LfcFrmComm.ToDouble(outObjectTmp.getRATEUNYO()) / 100);
        //ＴＲ
        _gcal.setTrueRT(LfcFrmComm.ToDouble(outObjectTmp.getTRUERATE()) / 100);
        //原調計算金利
        String strCof = "";
        if (LfcFrmComm.doFormatToFloat(outObjectTmp.getRATECADJ()) != null && !"".equals(
                LfcFrmComm.doFormatToFloat(outObjectTmp.getRATECADJ()))) {
            strCof = LfcFrmComm.doFormatToFloat(outObjectTmp.getRATECADJ());
        }

        _gcal.setRateCADJ(LfcFrmComm.ToDouble(strCof) / 100);
        //ＲＯＩ
        _gcal.setRateROI(LfcFrmComm.ToDouble(outObjectTmp.getRATEROI()) / 100);
//      pzk add 20050513 start
        _gcal.setROE(LfcFrmComm.ToDouble(outObjectTmp.getROE()) / 100);
//      pzk add 20050513 end
        //動総保険料率
        String strDosoRate = "";
        if (outObjectTmp.getDOSORATE() != null && !"".equals(outObjectTmp.getDOSORATE())) {
            strDosoRate = outObjectTmp.getDOSORATE();
        }

        _gcal.setDosoRt(LfcFrmComm.ToDouble(strDosoRate));
        //分割支払有無区分
        boolean bSwPayFlag; //支払(一括支払・分割支払)
        PaydivInOutRecord bPaydiv = bOutBukenTmp.getShiharaiRecord();
        List<PaydivComplexType> Listpaydiv = bPaydiv.getPaydivInOut();
        if (Listpaydiv.isEmpty()) {
            bSwPayFlag = LfcLogicPgConst.KUBUN_NO;
        } else { //支払(分割支払)
            bSwPayFlag = LfcLogicPgConst.KUBUN_YES;
        }
        _gcal.setSwPay(bSwPayFlag);

        //賠責保険付保区分
        String strSwBaisFlag;
        if (outObjectTmp.getSWBAISEKI() != null && !"".equals(outObjectTmp.getSWBAISEKI())) { //有
            strSwBaisFlag = "1";
        } else { //無
            strSwBaisFlag = "2";
        }

        // ﾘｰｽ信保付保区分
        _gcal.setSwCri("2");
        _gcal.setSwBais(strSwBaisFlag);
        //少額資産区分
        _gcal.setSwSPro("2");
        //ソフトウェア物件区分
        _gcal.setSwSoft("2");
        //団信保険料率
        if (_gcal.getDansRt() == -9.99999) {
            _gcal.setDansRt(0);
        }
        //信保機種CD
        _gcal.setCriCd("");
        //コスト率選択情報を設定する
        _gcal.setCstKishuCD("");
        //合計料率
        _gcal.setRyortT(LfcFrmComm.ToDouble(outObjectTmp.getRYORITSUT()) / 100);
        //月料率
        _gcal.setRyortM(LfcFrmComm.ToDouble(outObjectTmp.getRYORITSUM()) / 100);
        //社内コスト率を再計算するを追加　HBQ　2007/07/06　begin
        //手数料率(合計)を再計算する
        outObjectTmp.setRATEFEE(Double.toString(LfcLogicComm.dround((LfcFrmComm.ToDouble(outObjectTmp.getRATEFEER()) + LfcFrmComm.ToDouble(outObjectTmp.getRATEFEEN())), 5)));
        // 管販費率合計を再計算する
        outObjectTmp.setRATEEANI(Double.toString(LfcLogicComm.dround((LfcFrmComm.ToDouble(outObjectTmp.getRATEEAO()) + LfcFrmComm.ToDouble(outObjectTmp.getRATEEAS())), 5)));
        // 社内コスト率を再計算する
        outObjectTmp.setRATEJLC(Double.toString(LfcLogicComm.dround(
                (LfcFrmComm.ToDouble(LfcFrmComm.doFormatToFloat(
                outObjectTmp.getRATECADJ())) + LfcFrmComm.ToDouble(outObjectTmp.getRATEEAO()) + LfcFrmComm.ToDouble(outObjectTmp.getRATEEAS()) + LfcFrmComm.ToDouble(outObjectTmp.getRATELOSS()) - (LfcFrmComm.ToDouble(outObjectTmp.getRATEFEEN()) + LfcFrmComm.ToDouble(outObjectTmp.getRATEFEER()))), 5)));
        //社内コスト率を再計算するを追加　HBQ　2007/07/06　end
        //社内金利
        _gcal.setRateJL(LfcFrmComm.ToDouble(outObjectTmp.getRATEJLC()) / 100);

        //貸倒引当率
        _gcal.setRtLossR(LfcFrmComm.ToDouble(outObjectTmp.getRATELOSS()) / 100);
        //管販比率(Origination)
        _gcal.setRtEAniO(LfcFrmComm.ToDouble(outObjectTmp.getRATEEAO()) / 100);
        //管販比率(Servicing)
        _gcal.setRtEAniS(LfcFrmComm.ToDouble(outObjectTmp.getRATEEAS()) / 100);
        //管販比率(合計)
        _gcal.setRtEAniTotal(LfcFrmComm.ToDouble(outObjectTmp.getRATEEANI()) / 100);
        //手数料率(NPP)
        _gcal.setRtFeeN(LfcFrmComm.ToDouble(outObjectTmp.getRATEFEEN()) / 100);
        //手数料率(Release)
        _gcal.setRtFeeR(LfcFrmComm.ToDouble(outObjectTmp.getRATEFEER()) / 100);
        //手数料率(合計)
        _gcal.setRtFeeTotal(LfcFrmComm.ToDouble(outObjectTmp.getRATEFEE()) / 100);
        //FinanceMargin
        _gcal.setFinanceMargin(LfcFrmComm.ToDouble(outObjectTmp.getFINANCEMARGIN()));
        //PvFinanceMargin
        _gcal.setPvFinanceMargin(LfcFrmComm.ToDouble(outObjectTmp.getPVFINANCEMARGIN()));
        //RaMargin
        _gcal.setRaMargin(LfcFrmComm.ToDouble(outObjectTmp.getRateRAM()));
        //RaPvMargin
        _gcal.setRaPvMargin(LfcFrmComm.ToDouble(outObjectTmp.getRAPVDirectM()));

        if (outObjectTmp.getDATEKENSH() != null && !"".equals(outObjectTmp.getDATEKENSH())) {
            if (outObjectTmp.getDATEKENSH().trim().length() == 10) {
                //検収予定日（年）
                _gcal.setDate1YY(
                        LfcFrmComm.toInt(
                        outObjectTmp.getDATEKENSH().trim().substring(
                        0,
                        4)));
                // 検収予定日（月）
                _gcal.setDate1MM(
                        LfcFrmComm.toInt(
                        outObjectTmp.getDATEKENSH().trim().substring(
                        5,
                        7)));
                //検収予定日（日）
                _gcal.setDate1DD(
                        LfcFrmComm.toInt(
                        outObjectTmp.getDATEKENSH().trim().substring(
                        8,
                        10)));
            } else {
                //検収予定日（年）
                _gcal.setDate1YY(
                        LfcFrmComm.toInt(
                        outObjectTmp.getDATEKENSH().trim().substring(
                        0,
                        4)));
                // 検収予定日（月）
                _gcal.setDate1MM(
                        LfcFrmComm.toInt(
                        outObjectTmp.getDATEKENSH().trim().substring(
                        4,
                        6)));
                //検収予定日（日）
                _gcal.setDate1DD(
                        LfcFrmComm.toInt(
                        outObjectTmp.getDATEKENSH().trim().substring(
                        6,
                        8)));
            }

        } else {
            //検収予定日（年）
            _gcal.setDate1YY(0);
            // 検収予定日（月）
            _gcal.setDate1MM(0);
            //検収予定日（日）
            _gcal.setDate1DD(0);
        }
        //検収予定日
        _gcal.setDKensh(LfcLogicComm.db3Itod(_gcal.getDate1YY(), _gcal.getDate1MM(), _gcal.getDate1DD()));
        //支払予定日
        if (!_gcal.getSwPay()) { //支払(一括支払)
            if (outObjectTmp.getDATEPAYMT() != null && !"".equals(outObjectTmp.getDATEPAYMT().trim())) {
                if (outObjectTmp.getDATEPAYMT().trim().length() == 10) {
                    //支払予定日（年）
                    _gcal.setDate2YY(
                            LfcFrmComm.toInt(
                            outObjectTmp.getDATEPAYMT().trim().substring(
                            0,
                            4)));
                    //支払予定日（月）
                    _gcal.setDate2MM(
                            LfcFrmComm.toInt(
                            outObjectTmp.getDATEPAYMT().trim().substring(
                            5,
                            7)));
                    //支払予定日（日）
                    _gcal.setDate2DD(
                            LfcFrmComm.toInt(
                            outObjectTmp.getDATEPAYMT().trim().substring(
                            8,
                            10)));
                } else {
                    //支払予定日（年）
                    _gcal.setDate2YY(
                            LfcFrmComm.toInt(
                            outObjectTmp.getDATEPAYMT().trim().substring(
                            0,
                            4)));
                    //支払予定日（月）
                    _gcal.setDate2MM(
                            LfcFrmComm.toInt(
                            outObjectTmp.getDATEPAYMT().trim().substring(
                            4,
                            6)));
                    //支払予定日（日）
                    _gcal.setDate2DD(
                            LfcFrmComm.toInt(
                            outObjectTmp.getDATEPAYMT().trim().substring(
                            6,
                            8)));
                }

            } else {
                //支払予定日（年）
                _gcal.setDate2YY(0);
                // 支払予定日（月）
                _gcal.setDate2MM(0);
                //支払予定日（日）
                _gcal.setDate2DD(0);
            }

        } else {
            //支払予定日（年）
            _gcal.setDate2YY(0);
            // 支払予定日（月）
            _gcal.setDate2MM(0);
            //支払予定日（日）
            _gcal.setDate2DD(0);
        }
        //支払予定日
        _gcal.setDPaymt(LfcLogicComm.db3Itod(_gcal.getDate2YY(), _gcal.getDate2MM(), _gcal.getDate2DD()));

        String strPreLeaseDate = outObjectTmp.getDATEINC0();
        //前受ﾘｰｽ料回収金額
        _gcal.setInc0(LfcFrmComm.ToDouble(outObjectTmp.getINCOME0().trim()));
        if ("".equals(strPreLeaseDate.trim()) || "0".equals(strPreLeaseDate.trim())) {
            //前受ﾘｰｽ料回収日（年）
            _gcal.setDate3YY(0);
            //前受ﾘｰｽ料回収日（月）
            _gcal.setDate3YY(0);
            //前受ﾘｰｽ料回収日（日）
            _gcal.setDate3YY(0);
            //前受ﾘｰｽ料月数回収予定日
            _gcal.setDInc0(0);
        } else {
            if (strPreLeaseDate != null && !"".equals(strPreLeaseDate)) {
                if (strPreLeaseDate.length() == 10) {
                    //前受ﾘｰｽ料回収日（年）
                    _gcal.setDate3YY(
                            LfcFrmComm.toInt(strPreLeaseDate.substring(0, 4)));
                    //前受ﾘｰｽ料回収日（月）
                    _gcal.setDate3MM(
                            LfcFrmComm.toInt(strPreLeaseDate.substring(5, 7)));
                    //前受ﾘｰｽ料回収日（日）
                    _gcal.setDate3DD(
                            LfcFrmComm.toInt(strPreLeaseDate.substring(8, 10)));
                    //前受ﾘｰｽ料月数回収予定日
                    _gcal.setDInc0(
                            LfcFrmComm.ToLong(
                            strPreLeaseDate.substring(0, 4) + strPreLeaseDate.substring(5, 7) + strPreLeaseDate.substring(8, 10)));
                } else {
                    //前受ﾘｰｽ料回収日（年）
                    _gcal.setDate3YY(
                            LfcFrmComm.toInt(strPreLeaseDate.substring(0, 4)));
                    //前受ﾘｰｽ料回収日（月）
                    _gcal.setDate3MM(
                            LfcFrmComm.toInt(strPreLeaseDate.substring(4, 6)));
                    //前受ﾘｰｽ料回収日（日）
                    _gcal.setDate3DD(
                            LfcFrmComm.toInt(strPreLeaseDate.substring(6, 8)));
                    //前受ﾘｰｽ料月数回収予定日
                    _gcal.setDInc0(LfcFrmComm.ToLong(strPreLeaseDate));
                }

            } else {
                //前受ﾘｰｽ料回収日（年）
                _gcal.setDate3YY(0);
                //前受ﾘｰｽ料回収日（月）
                _gcal.setDate3MM(0);
                //前受ﾘｰｽ料回収日（日）
                _gcal.setDate3DD(0);
                //前受ﾘｰｽ料月数回収予定日
                _gcal.setDInc0(0);
            }

        }
//20040907 ljq add s
        //   _gcal.setLeverage(LfcFrmComm.toInt(_kpCalBaseInfoFrm.txtLeverageRatio.getText()));
        String strTmpRatio = outObjectTmp.getLEVERAGERATIO();
        if (strTmpRatio == null) {
            _gcal.setLeverage(LfcFrmComm.toInt("16"));
        } else {
            if (strTmpRatio.length() < 2) {
            } else {
                strTmpRatio = strTmpRatio.substring(0, strTmpRatio.length() - 2);
            }
            _gcal.setLeverage(LfcFrmComm.toInt(strTmpRatio));
        }

//20040907 ljq add e

//		ydy add 20061011 s
//		 機種CD
        //ydy modify 20061219 s
//      _gcal.setCstKishuCD("000");
        _gcal.setCstKishuCD(outObjectTmp.getCSTKISHUCD());
        //ydy modify 20061219 e
//		ydy add 20061011 e
        //20070410 zyb add s
        if (outObjectTmp.getTAX() != null && !"".equals(outObjectTmp.getTAX())) {
            _gcal.setROITax(outObjectTmp.getTAX());
        } else {
            String strROITax = "" + LfcFrmComm.dround(1 - LfcLogicPgConst.USA_PERSON_TAX, 2);
            _gcal.setROITax(strROITax);
        }
//20070410 zyb add e
    }

    /**
     * 算出項目と逆算時基準項目チェック。
     * リース案件情報
     * @param outObjectTmp
     * @param bPaydiv
     * @return boolean true :OK flase:NG
     */
    public ArrayList<ErrorInforOutputComplexType> doCalConditonCheck(ObjectOutputComplexType outObjectTmp, PaydivInOutRecord bPaydiv) {
        boolean bChackFlg = true;
        ArrayList<ErrorInforOutputComplexType> errMsglist = new ArrayList<ErrorInforOutputComplexType>();
        //算出項目指定
        String strCalculateBase = "";
        //逆算時基準項目
        String strCalculateType = "";
        //リース割賦区分
        String strLS_KP = "";
        strCalculateBase = outObjectTmp.getCALCULATEBASE().toString().trim();
        strCalculateType = outObjectTmp.getCALCULATETYPE().toString().trim();
        strLS_KP = outObjectTmp.getLSKP().toString().trim();
        List<PaydivComplexType> Listpaydiv = bPaydiv.getPaydivInOut();
        //リース物件の場合
        if ("L".equals(strLS_KP)) {
            //算出項目指定チェック
            if ("".equals(strCalculateBase) || "採算".equals(strCalculateBase) || "回収金額算出".equals(strCalculateBase) || "残価逆算".equals(strCalculateBase) || "回収回数逆算".equals(strCalculateBase) || "購入価額逆算".equals(strCalculateBase)) {
            } else {
                // "正しい算出項目指定を入力してください。"
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0096, "E0096", errMsglist);
                bChackFlg = false;
            }
            //算出項目指定と逆算時基準項目の逆算組合チェック
            if ("月料率指定".equals(strCalculateType) || "合計料率指定".equals(strCalculateType)) {
                if ("残価逆算".equals(strCalculateBase) || "回収回数逆算".equals(strCalculateBase) || "購入価額逆算".equals(strCalculateBase)) {
                    // "正しい算出項目指定と逆算時基準項目の逆算組合を設定してください。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0098, "E0098", errMsglist);
                    bChackFlg = false;
                }
            }
        } //割賦物件の場合
        else {
            //算出項目指定チェック
            if ("".equals(strCalculateBase) || "採算".equals(strCalculateBase) || "回収金額算出".equals(strCalculateBase) || "回収金額/頭金算出".equals(strCalculateBase) || "頭金逆算".equals(strCalculateBase) || "回収回数逆算".equals(strCalculateBase) || "購入価額逆算".equals(strCalculateBase)) {
            } else {
                // "正しい算出項目指定を入力してください。"
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0096, "E0096", errMsglist);
                bChackFlg = false;
            }
            if ("月料率指定".equals(strCalculateType) || "合計料率指定".equals(strCalculateType)) {
                if ("頭金逆算".equals(strCalculateBase) || "回収回数逆算".equals(strCalculateBase) || "購入価額逆算".equals(strCalculateBase)) {
                    // "正しい算出項目指定と逆算時基準項目の逆算組合を設定してください。"
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0098, "E0098", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        //共通チェック
        if ("".equals(strCalculateBase) || "採算".equals(strCalculateBase)) {
        } else {
            //逆算時基準項目チェック
            if ("合計料率指定".equals(strCalculateType) || "月料率指定".equals(strCalculateType) || "運用利回り指定".equals(strCalculateType) || "ROI指定".equals(strCalculateType) || "ROE指定".equals(strCalculateType) || "TR指定".equals(strCalculateType)) {
            } else {
                // "正しい逆算時基準項目を入力してください。"
                errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0097, "E0097", errMsglist);
                bChackFlg = false;
            }
        }

        //分割支払時
        if (!Listpaydiv.isEmpty()) {
            //分割支払時、逆算不能。
            //リース物件の場合
            if ("L".equals(strLS_KP)) {
                if ("回収金額算出".equals(strCalculateBase) || "残価逆算".equals(strCalculateBase) || "回収回数逆算".equals(strCalculateBase) || "購入価額逆算".equals(strCalculateBase)) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0099, "E0099", errMsglist);
                    bChackFlg = false;
                }
            } else {
                if ("回収金額算出".equals(strCalculateBase) || "回収金額/頭金算出".equals(strCalculateBase) || "頭金逆算".equals(strCalculateBase) || "回収回数逆算".equals(strCalculateBase) || "購入価額逆算".equals(strCalculateBase)) {
                    errMsglist = LfcLogicComm.addErrMsgList(LfcFrmMsgConst.E0099, "E0099", errMsglist);
                    bChackFlg = false;
                }
            }
        }
        return errMsglist;
    }
}
