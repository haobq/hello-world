/*
 * @(#)Paydiv.java      01-01  2003/05/20
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.logic.comm;

public class Paydiv {
	boolean[] bAct   = new boolean[120];		/* 有効区分    */
    double[] dStair   = new double[120];        /* 段数        */
	double[] dPurchas = new double[120];		/* 支払額      */
	int[]	 nDateYY  = new int[120];			/* 支払日（年）*/
	int[]	 nDateMM  = new int[120];			/* 支払日（月）*/
	int[]	 nDateDD  = new int[120];			/* 支払日（日）*/
    private String[][] _strPaydivData = new String[120][6];

    public boolean getAct(int nIndex) {
        return bAct[nIndex];
    }

    public void setAct(boolean bAct, int nIndex) {
        this.bAct[nIndex] = bAct;
    }

    public double getStair(int nIndex) {
        return dStair[nIndex];
    }

    public void setStair(double dStair, int nIndex) {
        this.dStair[nIndex] = dStair;
    }

    public double getPurchas(int nIndex) {
        return dPurchas[nIndex];
    }

    public void setPurchas(double dPurchas, int nIndex) {
        this.dPurchas[nIndex] = dPurchas;
    }

	public int getDateYY(int nIndex) {
	    return nDateYY[nIndex];
	}

	public void setDateYY(int nDateYY, int nIndex) {
	    this.nDateYY[nIndex] = nDateYY;
	}

	public int getDateMM(int nIndex) {
	    return nDateMM[nIndex];
	}

	public void setDateMM(int nDateMM, int nIndex) {
	    this.nDateMM[nIndex] = nDateMM;
	}

	public int getDateDD(int nIndex) {
	    return nDateDD[nIndex];
	}

	public void setDateDD(int nDateDD, int nIndex) {
	    this.nDateDD[nIndex] = nDateDD;
	}

    public String[][] getPaydivData() {
        return _strPaydivData;
    }

    public void setPaydivData(String[][] strPaydivData) {
        _strPaydivData = strPaydivData;
    }
}
