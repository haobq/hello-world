/*
 * @(#)DosoinstBean.java      01-01  2003/04/08
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 */
package com.gecl.leaseCal.db.comm;

import java.io.File;
import java.util.Vector;
import com.gecl.leaseCal.log.LfcSystemLog;

/**
 * クラス名：DBのDosoinstの処理共通Bean． <BR>
 *
 * 機能：
 * <PRE>
 *  １．Dosoinstのデータ検索
 *  ２．Dosoinstのデータ更新（INSERT、UPDATE、DELETE）
 * </PRE>
 * @author     DHC-楊暁舟
 * @version    01-01
 * @see        DOSOINSTType
 * @see        LfcDBConst
 * @see        LfcDBOnlySelectInterface
 * @since      01-01
 */
public class DosoinstBean implements LfcDBConst, LfcDBOnlySelectInterface {

    /** 検索結果集を格納するVectorを定義する */
    private Vector _vResults = new Vector();
    /**エラーメッセージを格納する変数を定義する */
    private String _strErrorMessage = "";
    /** Dosoinst.xmlは存在かどうかフラグ */
    private boolean _bFileExistence = false;
    /** Dosoinst.xmlパス */
    private String _strXmlFilePath = "";
    /** Dosoinst.xsdパス */
    private String _strXsdFilePath = "";

    XmlArrReader _dosoinstXmlReader = null;

    public DosoinstBean() {
        LfcDBConfig.setXmlPath();
        _strXmlFilePath = LfcDBConfig.getDosoinstXmlPath();
        _strXsdFilePath = LfcDBConfig.getDosoinstXsdPath();
    }

    /**
     * 解析されるXMLDOCを作成するメソッド．    <BR>
     *
     * param   strXmlUrl         XMLのURL
     * @return  boolean    true ：XMLDOCの作成は成功
     *                     false：XMLDOCの作成は失敗
     * @since              01-01
     */
    public boolean parseXml() {
        LfcDBConfig.getInstance();
        _strXmlFilePath=LfcDBConfig.getDosoinstXmlPath();
        //_strXmlFilePath="D:\\Price_Calculate\\DB\\xml\\DOSOINST.XML";
        File file = new File(_strXmlFilePath);
        if (file.exists()) {
            _bFileExistence = true;
        } else {
            _bFileExistence = false;
        }
        if (!_bFileExistence) {
            return true;
        }
        try {
            _dosoinstXmlReader = new XmlArrReader(_strXmlFilePath, 38);
            _dosoinstXmlReader.parse();
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("DosoinstBean", //クラス名
                    "parseXml()", //メソッド名
                    LfcDBMsgConst.ERA005, //ロジックメッセージ
                    e);                   //システムエラーメッセージ
            return false;
        }
        return true;
    }

    /**
     * エラーメッセージを取得．    <BR>
     *
     * @return   String    エラーメッセージ
     * @since              01-01
     */
    public String getErrorMessage() {
        return _strErrorMessage;
    }

    /**
     * 検索結果集を取得．    <BR>
     *
     * @return    Vector   Dosoinstの検索結果集
     * @since              01-01
     */
    public Vector getResults() {
        return _vResults;
    }

    /**
     * DBのDOSOINSTレコードの結果集を取得するメソッド．    <BR>
     *
     * param   strSql         XPATH文
     * @return  boolean true ：結果集の設定は成功
     *                  false：結果集の設定は失敗
     * @since   01-01
     */
    @SuppressWarnings("unchecked")
    public boolean getQueryResults() {
        if (!_bFileExistence) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("DosoinstBean", //クラス名
                    "removeRecord(Vector vIDs)", //メソッド名
                    _strXmlFilePath + LfcDBMsgConst.ERA018, //ロジックメッセージ
                    new Exception("File not exist"));                   //システムエラーメッセージ
            return false;
        }
        try {
            for (int i = 0; i < _dosoinstXmlReader.getRowCount(); i++) {
                Vector vDosoinst = new Vector();

                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_TERM"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_1"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_2"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_3"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_4"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_5"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_6"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_7"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_8"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_9"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_10"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_11"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_12"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_13"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_14"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_15"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_16"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_17"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_18"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_19"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_20"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_21"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_22"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_23"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_24"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_25"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_26"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_27"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_28"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_29"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_30"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_31"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_32"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_33"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_34"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_35"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_36"));
                vDosoinst.addElement(_dosoinstXmlReader.getData(i, "DOSO_IX_T"));
                _vResults.addElement(vDosoinst);
            }

            return true;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("DosoinstBean", //クラス名
                    "getQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return false;
        }
    }

    public boolean CreateXml(Vector vData) {
        return true;
    }
}
