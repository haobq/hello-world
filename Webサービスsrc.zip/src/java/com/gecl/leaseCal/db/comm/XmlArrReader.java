package com.gecl.leaseCal.db.comm;

import java.io.File;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import com.gecl.leaseCal.log.LfcSystemLog;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;

/**
 * @author liaojiaqing
 *
 * Using SAX to parse XML file
 */
public class XmlArrReader extends DefaultHandler {
    private XMLReader _xmlReader = null;
    private String[] _strResultName = null;
    private String[] _strResult = null;
    private String[][] _strResults = null;
    private String _strXmlFilePath = null;
    private int _nRecordCnt = 0;
    private int _nNameCnt = 0;
    private int _nNowPos = 0;
    private int _nResizeCnt = 0;
    private boolean _bReadFlg = false;
    private String _strRootElement = "";
    private String _strThisElement = null;
    private String _strThisElementValue = null;

    /**
	 * @param strXmlFilePath		XML file path
	 * @param nRecordCnt			XML file's record count
	 */
	public XmlArrReader(String strXmlFilePath, int nRecordCnt) {
        _strXmlFilePath = strXmlFilePath;
        _strResultName = new String[nRecordCnt];
        //_strResult = new String[nRecordCnt];
		_strResult = new String[0];
        _nRecordCnt = nRecordCnt;
    }

    /*
	 * @see org.xml.sax.ErrorHandler#error(org.xml.sax.SAXParseException)
	 */
	public void error (SAXParseException e) {
    }

    /*
	 * @see org.xml.sax.ErrorHandler#warning(org.xml.sax.SAXParseException)
	 */
	public void warning (SAXParseException e) {
    }

    /*
	 * @see org.xml.sax.ErrorHandler#fatalError(org.xml.sax.SAXParseException)
	 */
	public void fatalError (SAXParseException e) {
        System.exit(1);
    }

    /*
	 * @see org.xml.sax.ContentHandler#startDocument()
	 */
	public void startDocument() throws SAXException {
    }

    /*
     * At the end of documnt,adjust the query result
     *
	 * @see org.xml.sax.ContentHandler#endDocument()
	 */
	public void endDocument() throws SAXException {
        String[][] tmpStr = null;
		for(int i = 0; i < _strResult.length; i++) {
			   if(_strResult[i] == null) {
			   		String[] strTmpArr = new String[i];
					System.arraycopy(_strResult, 0, strTmpArr, 0, i);
					_strResult = strTmpArr;
					break;
			   }
		}
        tmpStr = new String[(int)(_strResult.length / _nRecordCnt)][_nRecordCnt];
        int nRealCnt = 0;
        nRealCnt = (int)(_strResult.length / _nRecordCnt);
        for(int i = 0; i < tmpStr.length; i++) {
//            if(!"".equals(_strResult[_nRecordCnt * i]) && _strResult[_nRecordCnt * i] != null) {


//				int nNullCnt = 0;
//				for(int j = _nRecordCnt * i; j < _nRecordCnt * (i + 1); j++) {
//					if(_strResult[j] == null) {
//						nNullCnt++;
//					}
//				}
//				if(nNullCnt >= _nRecordCnt ) {
//					nRealCnt--;
//				} else {
                	System.arraycopy(_strResult, _nRecordCnt * i, tmpStr[i], 0, tmpStr[i].length);
//				}


//            nRealCnt++;
//            }
        }
        String[][] tmpRealStr = new String[nRealCnt][_nRecordCnt];
        for(int i = 0; i < nRealCnt; i++) {
            System.arraycopy(tmpStr[i], 0, tmpRealStr[i], 0, tmpStr[i].length);
        }
        _strResults = tmpRealStr;
        _strResult = null;
        //Runtime.getRuntime().gc();
    }

    /*
     * when start the element,store the element's name and attribute's value as column's value
     *
	 * @see org.xml.sax.ContentHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	public void startElement(String namespaceURI, String localName,
                            String qName, Attributes atts) throws SAXException {
        if("".equals(_strRootElement)) {
            _strRootElement = qName;
        }
        _strThisElement = qName;
        _strThisElementValue = "";
        if ("ROW".equals(qName)) {
            _bReadFlg = true;
            for (int att = 0; att < atts.getLength(); att++) {
               String attName = atts.getQName(att);
               if(_nNameCnt < _strResultName.length) {
                    _strResultName[_nNameCnt++] = attName;
               }
			   if(_nNowPos >= _strResult.length) {
					resizeArray();
			   }
               _strResult[_nNowPos++] = atts.getValue(attName);
//               if(_nNowPos >= _strResult.length) {
//                    resizeArray();
//               }
            }
        }
    }

    /*
     * At the end of each element, store the element's value as column's value
     *
	 * @see org.xml.sax.ContentHandler#endElement(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void endElement(String namespaceURI, String localName, String qName)
                                                            throws SAXException {
        if(_bReadFlg == false || "ROW".equals(qName) || qName.equals(_strRootElement)) {
            return;
        }
        if(_nNameCnt < _strResultName.length) {
            _strResultName[_nNameCnt++] = _strThisElement;
        }
		if(_nNowPos >= _strResult.length) {
			resizeArray();
		}
        _strResult[_nNowPos++] = _strThisElementValue;
		_strThisElementValue = "";
//        if(_nNowPos >= _strResult.length) {
//            resizeArray();
//        }
    }

    /*
     * get an element's value
     *
	 * @see org.xml.sax.ContentHandler#characters(char[], int, int)
	 */
	public void characters(char[] ch, int start, int length) throws SAXException  {
        String str = new String(ch, start, length);
        _strThisElementValue = _strThisElementValue + str;
    }

    /**
	 * change array's size
	 */
	public void resizeArray() {
        int nResize = _nRecordCnt;
        if(_nResizeCnt >= 200) {
            nResize = nResize * 200;
        } else if (_nResizeCnt >= 100) {
            nResize = nResize * 100;
        } else if (_nResizeCnt >= 50) {
            nResize = nResize * 50;
        } else if (_nResizeCnt >= 10) {
            nResize = nResize * 10;
        }
        String[] strTmp = new String[_strResult.length];
        System.arraycopy(_strResult, 0, strTmp, 0, _strResult.length);
        _strResult = new String[_strResult.length + nResize];
        System.arraycopy(strTmp, 0, _strResult, 0, strTmp.length);
        _nResizeCnt++;
    }

    /**
     * get data from SAX's query results
     *
	 * @param row		row
	 * @param column	column's name
	 * @return
	 */
	public String getData(int row, String column) {
        int nColumn = 0;
        column = column.trim();
        for(int i = 0; i < _strResultName.length; i++) {
            if(column.equals(_strResultName[i])) {
                nColumn = i;
                break;
            }
        }
        if(_strResults[row][nColumn] == null ||"null".equals(_strResults[row][nColumn]) ) {
        	return "";
        }
        return _strResults[row][nColumn];
    }

    /**
     * delete row from SAX's query results
     *
	 * @param row	row
	 */
	public void removeRow(int row) {
        if(row < 0 || row > _strResults.length) {
            return;
        }
        String[][] strTmp = new String[_strResults.length - 1][_nRecordCnt];
/*
        System.arraycopy(_strResults, 0, strTmp, 0, row - 1);
        System.arraycopy(_strResults, row + 1, strTmp, row, _strResults.length - row - 1);
*/
        for(int i = 0, j = 0; i < _strResults.length; i++) {
            if(i == row) {
                continue;
            }
            System.arraycopy(_strResults[i], 0, strTmp[j++], 0, _nRecordCnt);
        }
        _strResults = strTmp;
    }

    /**
     * append a row
     *
	 * @param rowValues
	 */
	public void insertRow(String[] rowValues) {
        String[][] strTmp = new String[_strResults.length + 1][_nRecordCnt];
        System.arraycopy(_strResults, 0, strTmp, 0, _strResults.length);
        System.arraycopy(rowValues, 0, strTmp[_strResults.length], 0, _nRecordCnt);
        _strResults = strTmp;
    }
    /**
	 * @return	SAX's query results' record count
	 */
	public int getRowCount() {
	    //ydy add 20080414 s
	    if(_strResults == null) {
	        _strResults = new String[0][];
	    }
	    //ydy add 20080414 e
        return _strResults.length;
    }

    /**
	 * @return	String[][]	SAX's query results
	 */
	public String[][] getResults() {
        return _strResults;
    }

    /**
	 * @return	String[]	column's name
	 */
	public String[] getFieldName() {
        return _strResultName;
    }

    /**
	 * @param strName	column's name
	 */
	public void setFieldName(String strName[]) {
        _strResultName = strName;
    }

    public void prt() {
/*
        for(int i = 0;i < _strResultName.length; i++) {
        }
*/

    for(int i = 0; i < _strResults.length; i++) {
        for(int j = 0;j < _strResults[i].length; j++) {
        }
    }

/*
        for(int i = 0;i < _strResult.length; i++) {
        }
*/
    }
    /**
	 * Using SAX to parse XML
	 */
	public void parse() {
        try {
            File file = new File(_strXmlFilePath);
            if (!file.exists()) {
                _strResult = null;
                return;
            }

            XMLReader xmlReader = null;

            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            SAXParser saxParser = spfactory.newSAXParser();
            xmlReader = saxParser.getXMLReader();

            InputSource inputSource = new InputSource(_strXmlFilePath);

            xmlReader.setContentHandler(this);
            xmlReader.setErrorHandler(this);
            xmlReader.parse(inputSource);
        } catch (Exception  e) {
            e.printStackTrace();
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("XmlArrReader",                    //クラス名
                                   "parse()",                        //メソッド名
                                   LfcDBMsgConst.ERA001,             //ロジックメッセージ
                                   e);                    //システムエラーメッセージ
            return;
        }
        return;
    }


}
