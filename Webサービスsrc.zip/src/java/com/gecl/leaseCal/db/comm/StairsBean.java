/*
 * @(#)StairsBean.java      01-01  2003/04/08
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 * 修正日：20050706
 * 修正人：曾健
 * 修正内容：試算システムで案件コピーするために、この案件の全て回収情報を取ります
 *
 * 修正日：20050912
 * 修正人：曾健
 * 修正内容：回収金額,回収サイク,回数   0XXXX -> XXXX
 *
 * 修正日：20051109
 * 修正人：pzk
 * 修正内容：古いデータのバックアップと復元を処理します.
 *
 * 修正者：曾健
 * 修正日：20051207
 * 修正内容：試算回収表に60フィールドを追加する
 *
 * 修正者：Hao
 * 修正日：20070629
 * 修正内容：XMLファイルに書出す時のエラーLogを追加
 *
 */
package com.gecl.leaseCal.db.comm;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.gecl.leaseCal.log.LfcSystemLog;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;

/**
 * クラス名：DBのStairsの処理共通Bean． <BR>
 *
 * 機能：
 * <PRE>
 *  １．Stairsのデータ検索
 *  ２．Stairsのデータ更新（INSERT、UPDATE、DELETE）
 * </PRE>
 * @author     DHC-王嵩
 * @version    01-01
 * @see        STAIRSType
 * @see        LfcDBConst
 * @see        LfcDBInterface
 * @since      01-01
 */
public class StairsBean implements LfcDBConst {

    /**エラーメッセージを格納する変数を定義する */
    private String _strErrorMessage = "";
    /** エラー項目名前 */
    private String _strErrorItemName = "エラー項目名前 : ";
    /** エラー項目内容 */
    private String _strErrorItemValue = "エラー項目内容 : ";
    /** Stairs.xmlパス */
    private String _strXmlFilePath = "";
    //pzk add 20051109 s
    private String _strPreviousXmlFilePath = "";
    //pzk add 20051109 e
    /** Stairs.xsdパス */
    private String _strXsdFilePath = "";
    /** current RecNo */
    private String _strCurRecNo = "";
    private StringBuffer _strBufIDIndex = new StringBuffer();
    DateFormat time = new SimpleDateFormat("HH:mm:ss");
    private  final StairsBean _stairsBean = null;
    private  String[][] _strLeaseResults;
    private  String _strDisplayBukenNo;
    private  int _nRecBukenCount = 0;
    XmlArrReader _stairsXmlReader = null;
    StringBuffer _strBuffer = new StringBuffer();
    //pzk add 20051109 s
    XmlArrReader _previousStairsXmlReader = null;
    StringBuffer _strPreviousBuffer = new StringBuffer();
    private String[][] _strPreviousResults;
    private String _strPreviousCurRecNo = "";
    private int _nPreviousRecBukenCount = 0;
    private String _strPreviousErrorMessage = "";
    //pzk add 20051109 e

    public StairsBean() {
        _strXmlFilePath = LfcDBConfig.getStairsXmlPath();
        _strXsdFilePath = LfcDBConfig.getStairsXsdPath();
        //parseXml();
        getInstance();
    }

    public  boolean addStairsResults(String[][] instair) {
        boolean bFlg = true;
        if (instair == null||_strLeaseResults==null ) {
            if (_strLeaseResults == null) {
                _strLeaseResults = instair;
            }
            bFlg=false;
            return bFlg;
        }
        String[][] strRetResults = new String[_strLeaseResults.length + instair.length][STAIRS_RECORD_COUNT];
        for (int i = 0; i < _strLeaseResults.length-1; i++) {
            System.arraycopy(_strLeaseResults[i], 0, strRetResults[i], 0, STAIRS_RECORD_COUNT);
        }

        for (int i = _strLeaseResults.length; i < _strLeaseResults.length-1 + instair.length; i++) {
            System.arraycopy(instair[i-_strLeaseResults.length], 0, strRetResults[i], 0, STAIRS_RECORD_COUNT);
        }
        _strLeaseResults = strRetResults;
        return bFlg;
    }

    public  StairsBean getInstance() {
        return _stairsBean;
    }

    /**
     * 解析されるXMLDOCを作成するメソッド．    <BR>
     *
     * param   strXmlUrl         XMLのURL
     * @return  boolean    true ：XMLDOCの作成は成功
     *                     false：XMLDOCの作成は失敗
     * @since              01-01
     */
    public boolean parseXml() {
        File file = new File(_strXmlFilePath);
        if (file.exists()) {
        } else {
            CreateXml();
        }
        _stairsXmlReader = new XmlArrReader(_strXmlFilePath, STAIRS_RECORD_COUNT - 1);
        _stairsXmlReader.parse();
        getBufferString();
        /*
        long t1 = System.currentTimeMillis();
        getQueryResults("1");
        String[][] aa = new String[_strLeaseResults.length][STAIRS_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, aa, 0, _strLeaseResults.length);
        int kk = 0;
        for(int i = 1001; i <= 1500; i++) {
        for(int j = 0; j < aa.length; j++) {
        aa[j][STAIRS_REC_NO] = "" + i;
        aa[j][STAIRS_BUKKEN_NO] = aa[j][STAIRS_BUKKEN_FR];
        insertRecord(aa[j]);
        kk++;
        }
        }
        doCommit();
        long t2 = System.currentTimeMillis();
         */
        //removeRecordl("1");
        //doCommit();
/*
        String[] str1 = new String[STAIRS_RECORD_COUNT];
        for(int i = 0;i<str1.length;i++) str1[i]="0";
        str1[STAIRS_REC_NO] = "10001";
        str1[STAIRS_BUKKEN_NO] = "2";
        str1[STAIRS_STAIR] = "0";
        str1[STAIRS_INCOME] = "20000";
        str1[STAIRS_CYCLE] = "1";
        str1[STAIRS_FREQUE] = "24";
        str1[STAIRS_DATE_YY] = "2004";
        str1[STAIRS_DATE_MM] = "10";
        str1[STAIRS_DATE_DD] = "10";

        insertRecord(str1);
        doCommit();*/
        return true;
    }

    public void getBufferString() {
        try {
            _strBuffer = new StringBuffer();
            InputStream in = new FileInputStream(_strXmlFilePath);
            in = new BufferedInputStream(in);
            Reader r = new InputStreamReader(in);
            r = new BufferedReader(r, 1024);
            int c;
            while ((c = r.read()) != -1) {
                _strBuffer.append((char) c);
            }
            r.close();
        } catch (Exception ex) {
        }
    }

    //pzk add 20051109 s
    public void parsePreviousData() {
        if (_previousStairsXmlReader == null) {
            File file = new File(_strPreviousXmlFilePath);
            if (file.exists()) {
            } else {
                createPreviousXml();
            }
            _previousStairsXmlReader = new XmlArrReader(_strPreviousXmlFilePath, STAIRS_RECORD_COUNT - 1);
            _previousStairsXmlReader.parse();
            getPreviousBufferString();
        }
    }

    public void getPreviousBufferString() {
        try {
            _strPreviousBuffer = new StringBuffer();
            InputStream in = new FileInputStream(_strPreviousXmlFilePath);
            in = new BufferedInputStream(in);
            Reader r = new InputStreamReader(in);
            r = new BufferedReader(r, 1024);
            int c;
            while ((c = r.read()) != -1) {
                _strPreviousBuffer.append((char) c);
            }
            r.close();
        } catch (Exception ex) {
        }
    }
    //pzk add 20051109 e

    public boolean removeRecordl(String strRecNo) {
        String strDelete = _strBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2) {
                break;
            }
            String strKeyValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            if (strRecNo.equals(strKeyValue)) {
                int nPos6 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos6 + 6);
            }
            i = nPos1;
        }
        return true;
    }

    /**
     * エラーメッセージを取得．    <BR>
     *
     * @return   String    エラーメッセージ
     * @since              01-01
     */
    public String getErrorMessage() {
        return _strErrorMessage;
    }
    //pzk add 20051109 s

    public String getPreviousErrorMessage() {
        return _strPreviousErrorMessage;
    }
    //pzk add 20051109 e

    /**
     * 前物件インデックスを表示するメソッド。
     * param strDisplayBukenNo。
     * return  無し。
     */
    public  void setDisplayBukenNo(String strDisplayBukenNo) {
        _strDisplayBukenNo = strDisplayBukenNo;
    }

    /**
     * インデックスの_nBukenIndexの物件レコードを戻すメソッド。
     * param   無し。
     * @return  無し。
     */
    public  String[][] getDisplayRec() {
        int[] nBukenResultsNum = new int[_strLeaseResults.length];
        int j = 0;
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (_strDisplayBukenNo.equals(_strLeaseResults[i][STAIRS_BUKKEN_NO])) {
                nBukenResultsNum[j++] = i;
            }
        }
        if (j - 1 < 0) {
            return null;
        }
        String[][] strBukenResults = new String[j][STAIRS_RECORD_COUNT];
        for (int i = 0; i < j; i++) {
            System.arraycopy(_strLeaseResults, nBukenResultsNum[i], strBukenResults, i, 1);
        }
        return strBukenResults;
        //return _strLeaseResults;
    }

    public  String[][] getCalRec(String strBukenNo) {
        String[][] strTmp = null;
        int nCnt = 0;
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strBukenNo.equals(_strLeaseResults[i][STAIRS_BUKKEN_NO])) {
                nCnt = nCnt + 1;
            }
        }
        if (nCnt == 0) {
            return new String[0][0];
        }
        strTmp = new String[nCnt][STAIRS_RECORD_COUNT];
        nCnt = 0;
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strBukenNo.equals(_strLeaseResults[i][STAIRS_BUKKEN_NO])) {
                strTmp[nCnt] = _strLeaseResults[i];
                nCnt = nCnt + 1;
            }
        }
        return strTmp;
    }

    /**
     * 検索結果集を取得．    <BR>
     *
     * @return    Vector   Stairsの検索結果集
     * @since              01-01
     */
    public  String[][] getResultsForLease() {
        return _strLeaseResults;
    }

    public  void setResultsForLease(String[][] strLeaseResults) {
        _strLeaseResults = strLeaseResults;
    }

    public String[][] getQueryResultsForEstCopy(String strRecNo) {
        String[][] strResults = getQueryResults(strRecNo);
        if (strResults.length == 0) {
            return new String[0][0];
        }
        String[][] strEstResults = new String[_nRecBukenCount][STAIRS_RECORD_COUNT];
        for (int i = 0; i < _nRecBukenCount; i++) {
            System.arraycopy(strResults[i], 0, strEstResults[i], 0, STAIRS_RECORD_COUNT);
        }
        return strEstResults;
    }

    public String[][] getQueryResultsForLease(String strRecNo) {
        String[][] strResults = getQueryResults(strRecNo);
        if (strResults.length == 0) {
            return new String[0][0];
        }
        _strLeaseResults = new String[_nRecBukenCount][STAIRS_RECORD_COUNT];
        for (int i = 0; i < _nRecBukenCount; i++) {
            System.arraycopy(strResults[i], 0, _strLeaseResults[i], 0, STAIRS_RECORD_COUNT);
        }
        return _strLeaseResults;
    }

    /**
     * XPATH文により結果集を取得するメソッド．    <BR>
     *
     * <PRE>
     *  １．XPATH文によりID結果集を取得する。
     *  ２．ID結果集により対応するINDEX配列を取得する。
     *  ３．INDEX配列により、対応の結果集を取得する。
     *  　  成功の場合、結果集を_vResultsに設定する。
     *   　 失敗の場合、エラーメッセージを_strErrorMessageに設定する。
     * </PRE>
     *
     * param   strSql         XPATH文
     * @return  boolean true ：結果集の設定は成功
     *                  false：結果集の設定は失敗
     * @see     #getIDs(String)
     * @see     #getIDsIndexArray(Vector)
     * @since   01-01
     */
    public String[][] getQueryResults(String strRecNo) {
//LfcFrmComm.printStr2(_stairsXmlReader.getResults());
        String[] tmpStrName = _stairsXmlReader.getFieldName();
        if (tmpStrName[0] == null) {
            setFieldName();
        }
        _strCurRecNo = strRecNo;
        String[][] strResults = new String[_stairsXmlReader.getRowCount()][STAIRS_RECORD_COUNT];
        try {
            _nRecBukenCount = 0;
            for (int i = 0; i < strResults.length; i++) {
                if (!strRecNo.equals(_stairsXmlReader.getData(i, "REC_NO"))) {
                    continue;
                }
                strResults[_nRecBukenCount][STAIRS_REC_NO] = _stairsXmlReader.getData(i, "REC_NO");
                strResults[_nRecBukenCount][STAIRS_BUKKEN_NO] = _stairsXmlReader.getData(i, "BUKKEN_NO");
                strResults[_nRecBukenCount][STAIRS_STAIR] = _stairsXmlReader.getData(i, "STAIR");
                strResults[_nRecBukenCount][STAIRS_BUKKEN_FR] = _stairsXmlReader.getData(i, "BUKKEN_FR");
                strResults[_nRecBukenCount][STAIRS_BUKKEN_TO] = _stairsXmlReader.getData(i, "BUKKEN_TO");
                strResults[_nRecBukenCount][STAIRS_INCOME] = _stairsXmlReader.getData(i, "INCOME");
                strResults[_nRecBukenCount][STAIRS_CYCLE] = _stairsXmlReader.getData(i, "CYCLE");
                strResults[_nRecBukenCount][STAIRS_FREQUE] = _stairsXmlReader.getData(i, "FREQUE");
                strResults[_nRecBukenCount][STAIRS_DATE_YY] = _stairsXmlReader.getData(i, "DATE_YY");
                strResults[_nRecBukenCount][STAIRS_DATE_MM] = _stairsXmlReader.getData(i, "DATE_MM");
                strResults[_nRecBukenCount][STAIRS_DATE_DD] = _stairsXmlReader.getData(i, "DATE_DD");
                strResults[_nRecBukenCount][STAIRS_ROW_INDEX] = "" + i;

                //20051207 zj s
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_01] = _stairsXmlReader.getData(i, "RESERVE_C_01");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_02] = _stairsXmlReader.getData(i, "RESERVE_C_02");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_03] = _stairsXmlReader.getData(i, "RESERVE_C_03");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_04] = _stairsXmlReader.getData(i, "RESERVE_C_04");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_05] = _stairsXmlReader.getData(i, "RESERVE_C_05");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_06] = _stairsXmlReader.getData(i, "RESERVE_C_06");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_07] = _stairsXmlReader.getData(i, "RESERVE_C_07");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_08] = _stairsXmlReader.getData(i, "RESERVE_C_08");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_09] = _stairsXmlReader.getData(i, "RESERVE_C_09");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_10] = _stairsXmlReader.getData(i, "RESERVE_C_10");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_11] = _stairsXmlReader.getData(i, "RESERVE_C_11");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_12] = _stairsXmlReader.getData(i, "RESERVE_C_12");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_13] = _stairsXmlReader.getData(i, "RESERVE_C_13");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_14] = _stairsXmlReader.getData(i, "RESERVE_C_14");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_15] = _stairsXmlReader.getData(i, "RESERVE_C_15");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_16] = _stairsXmlReader.getData(i, "RESERVE_C_16");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_17] = _stairsXmlReader.getData(i, "RESERVE_C_17");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_18] = _stairsXmlReader.getData(i, "RESERVE_C_18");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_19] = _stairsXmlReader.getData(i, "RESERVE_C_19");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_20] = _stairsXmlReader.getData(i, "RESERVE_C_20");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_21] = _stairsXmlReader.getData(i, "RESERVE_C_21");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_22] = _stairsXmlReader.getData(i, "RESERVE_C_22");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_23] = _stairsXmlReader.getData(i, "RESERVE_C_23");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_24] = _stairsXmlReader.getData(i, "RESERVE_C_24");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_25] = _stairsXmlReader.getData(i, "RESERVE_C_25");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_26] = _stairsXmlReader.getData(i, "RESERVE_C_26");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_27] = _stairsXmlReader.getData(i, "RESERVE_C_27");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_28] = _stairsXmlReader.getData(i, "RESERVE_C_28");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_29] = _stairsXmlReader.getData(i, "RESERVE_C_29");
                strResults[_nRecBukenCount][STAIRS_RESERVE_C_30] = _stairsXmlReader.getData(i, "RESERVE_C_30");

                strResults[_nRecBukenCount][STAIRS_RESERVE_N_01] = _stairsXmlReader.getData(i, "RESERVE_N_01");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_02] = _stairsXmlReader.getData(i, "RESERVE_N_02");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_03] = _stairsXmlReader.getData(i, "RESERVE_N_03");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_04] = _stairsXmlReader.getData(i, "RESERVE_N_04");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_05] = _stairsXmlReader.getData(i, "RESERVE_N_05");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_06] = _stairsXmlReader.getData(i, "RESERVE_N_06");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_07] = _stairsXmlReader.getData(i, "RESERVE_N_07");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_08] = _stairsXmlReader.getData(i, "RESERVE_N_08");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_09] = _stairsXmlReader.getData(i, "RESERVE_N_09");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_10] = _stairsXmlReader.getData(i, "RESERVE_N_10");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_11] = _stairsXmlReader.getData(i, "RESERVE_N_11");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_12] = _stairsXmlReader.getData(i, "RESERVE_N_12");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_13] = _stairsXmlReader.getData(i, "RESERVE_N_13");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_14] = _stairsXmlReader.getData(i, "RESERVE_N_14");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_15] = _stairsXmlReader.getData(i, "RESERVE_N_15");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_16] = _stairsXmlReader.getData(i, "RESERVE_N_16");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_17] = _stairsXmlReader.getData(i, "RESERVE_N_17");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_18] = _stairsXmlReader.getData(i, "RESERVE_N_18");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_19] = _stairsXmlReader.getData(i, "RESERVE_N_19");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_20] = _stairsXmlReader.getData(i, "RESERVE_N_20");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_21] = _stairsXmlReader.getData(i, "RESERVE_N_21");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_22] = _stairsXmlReader.getData(i, "RESERVE_N_22");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_23] = _stairsXmlReader.getData(i, "RESERVE_N_23");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_24] = _stairsXmlReader.getData(i, "RESERVE_N_24");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_25] = _stairsXmlReader.getData(i, "RESERVE_N_25");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_26] = _stairsXmlReader.getData(i, "RESERVE_N_26");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_27] = _stairsXmlReader.getData(i, "RESERVE_N_27");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_28] = _stairsXmlReader.getData(i, "RESERVE_N_28");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_29] = _stairsXmlReader.getData(i, "RESERVE_N_29");
                strResults[_nRecBukenCount][STAIRS_RESERVE_N_30] = _stairsXmlReader.getData(i, "RESERVE_N_30");
                //20051207 zj e

                _nRecBukenCount = _nRecBukenCount + 1;
            }
            String[][] strRetResults = new String[_nRecBukenCount][STAIRS_RECORD_COUNT];
            for (int i = 0; i < strRetResults.length; i++) {
                System.arraycopy(strResults[i], 0, strRetResults[i], 0, strResults[i].length);
            }
            _strLeaseResults = strRetResults;
//LfcFrmComm.printStr2(_strLeaseResults);

            return strRetResults;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("StairsBean", //クラス名
                    "getQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return new String[0][0];
        }
    }

    //pzk add 20051109 s
    public String[][] getPreviousQueryResults(String strRecNo) {
        String[] tmpStrName = _previousStairsXmlReader.getFieldName();
        if (tmpStrName[0] == null) {
            setPreviousFieldName();
        }
        _strPreviousCurRecNo = strRecNo;
        String[][] strResults = new String[_previousStairsXmlReader.getRowCount()][STAIRS_RECORD_COUNT];
        try {
            _nPreviousRecBukenCount = 0;
            for (int i = 0; i < strResults.length; i++) {
                if (!strRecNo.equals(_previousStairsXmlReader.getData(i, "REC_NO"))) {
                    continue;
                }
                strResults[_nPreviousRecBukenCount][STAIRS_REC_NO] = _previousStairsXmlReader.getData(i, "REC_NO");
                strResults[_nPreviousRecBukenCount][STAIRS_BUKKEN_NO] = _previousStairsXmlReader.getData(i, "BUKKEN_NO");
                strResults[_nPreviousRecBukenCount][STAIRS_STAIR] = _previousStairsXmlReader.getData(i, "STAIR");
                strResults[_nPreviousRecBukenCount][STAIRS_BUKKEN_FR] = _previousStairsXmlReader.getData(i, "BUKKEN_FR");
                strResults[_nPreviousRecBukenCount][STAIRS_BUKKEN_TO] = _previousStairsXmlReader.getData(i, "BUKKEN_TO");
                strResults[_nPreviousRecBukenCount][STAIRS_INCOME] = _previousStairsXmlReader.getData(i, "INCOME");
                strResults[_nPreviousRecBukenCount][STAIRS_CYCLE] = _previousStairsXmlReader.getData(i, "CYCLE");
                strResults[_nPreviousRecBukenCount][STAIRS_FREQUE] = _previousStairsXmlReader.getData(i, "FREQUE");
                strResults[_nPreviousRecBukenCount][STAIRS_DATE_YY] = _previousStairsXmlReader.getData(i, "DATE_YY");
                strResults[_nPreviousRecBukenCount][STAIRS_DATE_MM] = _previousStairsXmlReader.getData(i, "DATE_MM");
                strResults[_nPreviousRecBukenCount][STAIRS_DATE_DD] = _previousStairsXmlReader.getData(i, "DATE_DD");
                strResults[_nPreviousRecBukenCount][STAIRS_ROW_INDEX] = "" + i;

                //20051207 zj s
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_01] = _previousStairsXmlReader.getData(i, "RESERVE_C_01");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_02] = _previousStairsXmlReader.getData(i, "RESERVE_C_02");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_03] = _previousStairsXmlReader.getData(i, "RESERVE_C_03");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_04] = _previousStairsXmlReader.getData(i, "RESERVE_C_04");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_05] = _previousStairsXmlReader.getData(i, "RESERVE_C_05");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_06] = _previousStairsXmlReader.getData(i, "RESERVE_C_06");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_07] = _previousStairsXmlReader.getData(i, "RESERVE_C_07");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_08] = _previousStairsXmlReader.getData(i, "RESERVE_C_08");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_09] = _previousStairsXmlReader.getData(i, "RESERVE_C_09");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_10] = _previousStairsXmlReader.getData(i, "RESERVE_C_10");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_11] = _previousStairsXmlReader.getData(i, "RESERVE_C_11");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_12] = _previousStairsXmlReader.getData(i, "RESERVE_C_12");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_13] = _previousStairsXmlReader.getData(i, "RESERVE_C_13");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_14] = _previousStairsXmlReader.getData(i, "RESERVE_C_14");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_15] = _previousStairsXmlReader.getData(i, "RESERVE_C_15");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_16] = _previousStairsXmlReader.getData(i, "RESERVE_C_16");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_17] = _previousStairsXmlReader.getData(i, "RESERVE_C_17");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_18] = _previousStairsXmlReader.getData(i, "RESERVE_C_18");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_19] = _previousStairsXmlReader.getData(i, "RESERVE_C_19");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_20] = _previousStairsXmlReader.getData(i, "RESERVE_C_20");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_21] = _previousStairsXmlReader.getData(i, "RESERVE_C_21");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_22] = _previousStairsXmlReader.getData(i, "RESERVE_C_22");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_23] = _previousStairsXmlReader.getData(i, "RESERVE_C_23");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_24] = _previousStairsXmlReader.getData(i, "RESERVE_C_24");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_25] = _previousStairsXmlReader.getData(i, "RESERVE_C_25");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_26] = _previousStairsXmlReader.getData(i, "RESERVE_C_26");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_27] = _previousStairsXmlReader.getData(i, "RESERVE_C_27");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_28] = _previousStairsXmlReader.getData(i, "RESERVE_C_28");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_29] = _previousStairsXmlReader.getData(i, "RESERVE_C_29");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_C_30] = _previousStairsXmlReader.getData(i, "RESERVE_C_30");

                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_01] = _previousStairsXmlReader.getData(i, "RESERVE_N_01");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_02] = _previousStairsXmlReader.getData(i, "RESERVE_N_02");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_03] = _previousStairsXmlReader.getData(i, "RESERVE_N_03");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_04] = _previousStairsXmlReader.getData(i, "RESERVE_N_04");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_05] = _previousStairsXmlReader.getData(i, "RESERVE_N_05");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_06] = _previousStairsXmlReader.getData(i, "RESERVE_N_06");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_07] = _previousStairsXmlReader.getData(i, "RESERVE_N_07");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_08] = _previousStairsXmlReader.getData(i, "RESERVE_N_08");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_09] = _previousStairsXmlReader.getData(i, "RESERVE_N_09");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_10] = _previousStairsXmlReader.getData(i, "RESERVE_N_10");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_11] = _previousStairsXmlReader.getData(i, "RESERVE_N_11");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_12] = _previousStairsXmlReader.getData(i, "RESERVE_N_12");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_13] = _previousStairsXmlReader.getData(i, "RESERVE_N_13");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_14] = _previousStairsXmlReader.getData(i, "RESERVE_N_14");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_15] = _previousStairsXmlReader.getData(i, "RESERVE_N_15");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_16] = _previousStairsXmlReader.getData(i, "RESERVE_N_16");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_17] = _previousStairsXmlReader.getData(i, "RESERVE_N_17");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_18] = _previousStairsXmlReader.getData(i, "RESERVE_N_18");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_19] = _previousStairsXmlReader.getData(i, "RESERVE_N_19");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_20] = _previousStairsXmlReader.getData(i, "RESERVE_N_20");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_21] = _previousStairsXmlReader.getData(i, "RESERVE_N_21");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_22] = _previousStairsXmlReader.getData(i, "RESERVE_N_22");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_23] = _previousStairsXmlReader.getData(i, "RESERVE_N_23");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_24] = _previousStairsXmlReader.getData(i, "RESERVE_N_24");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_25] = _previousStairsXmlReader.getData(i, "RESERVE_N_25");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_26] = _previousStairsXmlReader.getData(i, "RESERVE_N_26");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_27] = _previousStairsXmlReader.getData(i, "RESERVE_N_27");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_28] = _previousStairsXmlReader.getData(i, "RESERVE_N_28");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_29] = _previousStairsXmlReader.getData(i, "RESERVE_N_29");
                strResults[_nPreviousRecBukenCount][STAIRS_RESERVE_N_30] = _previousStairsXmlReader.getData(i, "RESERVE_N_30");
                //20051207 zj e

                _nPreviousRecBukenCount = _nPreviousRecBukenCount + 1;
            }
            String[][] strRetResults = new String[_nPreviousRecBukenCount][STAIRS_RECORD_COUNT];
            for (int i = 0; i < strRetResults.length; i++) {
                System.arraycopy(strResults[i], 0, strRetResults[i], 0, strResults[i].length);
            }
            _strPreviousResults = strRetResults;
            return strRetResults;
        } catch (Exception e) {
            _strPreviousErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("StairsBean", //クラス名
                    "getPreviousQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return new String[0][0];
        }
    }
    //pzk add 20051109 e
    //20050707 zj start

    public String[][] getQueryResults4BukSelect(String strRecNo) {
        String[] tmpStrName = _stairsXmlReader.getFieldName();
        if (tmpStrName[0] == null) {
            setFieldName();
        }
        String[][] strResults = new String[_stairsXmlReader.getRowCount()][STAIRS_RECORD_COUNT];
        try {
            int nRecBukenCount = 0;
            for (int i = 0; i < strResults.length; i++) {
                if (!strRecNo.equals(_stairsXmlReader.getData(i, "REC_NO"))) {
                    continue;
                }
                strResults[nRecBukenCount][STAIRS_REC_NO] = _stairsXmlReader.getData(i, "REC_NO");
                strResults[nRecBukenCount][STAIRS_BUKKEN_NO] = _stairsXmlReader.getData(i, "BUKKEN_NO");
                strResults[nRecBukenCount][STAIRS_STAIR] = _stairsXmlReader.getData(i, "STAIR");
                strResults[nRecBukenCount][STAIRS_BUKKEN_FR] = _stairsXmlReader.getData(i, "BUKKEN_FR");
                strResults[nRecBukenCount][STAIRS_BUKKEN_TO] = _stairsXmlReader.getData(i, "BUKKEN_TO");
                strResults[nRecBukenCount][STAIRS_INCOME] = _stairsXmlReader.getData(i, "INCOME");
                strResults[nRecBukenCount][STAIRS_CYCLE] = _stairsXmlReader.getData(i, "CYCLE");
                strResults[nRecBukenCount][STAIRS_FREQUE] = _stairsXmlReader.getData(i, "FREQUE");
                strResults[nRecBukenCount][STAIRS_DATE_YY] = _stairsXmlReader.getData(i, "DATE_YY");
                strResults[nRecBukenCount][STAIRS_DATE_MM] = _stairsXmlReader.getData(i, "DATE_MM");
                strResults[nRecBukenCount][STAIRS_DATE_DD] = _stairsXmlReader.getData(i, "DATE_DD");
                strResults[nRecBukenCount][STAIRS_ROW_INDEX] = "" + i;
                nRecBukenCount++;
            }
            String[][] strRetResults = new String[nRecBukenCount][STAIRS_RECORD_COUNT];
            for (int i = 0; i < strRetResults.length; i++) {
                System.arraycopy(strResults[i], 0, strRetResults[i], 0, strResults[i].length);
            }
            return strRetResults;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("StairsBean", //クラス名
                    "getQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return new String[0][0];
        }
    }
    //20050707 zj end

    /**
     * 検索ID集により結果集を取得するメソッド(表示出力配列の項目だけ取得する)．    <BR>
     *
     * <PRE>
     *  １．検索ID集により結果集を取得する。
     *  ２．表示出力配列により配列nOutColに設定するフィールドだけを取得する。
     *      成功の場合、結果集を_vResultsに設定する。
     *      失敗の場合、エラーメッセージを_strErrorMessageに設定する。
     * </PRE>
     *
     * @param   strSql         XPATH文
     * @param   nOutCol        表示出力項目を格納する配列
     * @return  boolean true ：結果集の設定は成功
     *                  false：結果集の設定は失敗
     * @see     #getQueryResults(String)
     * @since   01-01
     */
    public String[][] getQueryResults(String strSql, int[] nOutCol) {
        try {
            if (getQueryResultsForLease(strSql).length == 0) {
                return new String[0][0];
            }
            String[][] strOutColResults = new String[_strLeaseResults.length][nOutCol.length];
            for (int i = 0; i < _strLeaseResults.length; i++) {
                for (int j = 0; j < nOutCol.length; j++) {
                    strOutColResults[i][j] = _strLeaseResults[i][nOutCol[j]];
                }
            }
            return strOutColResults;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("StairsBean", //クラス名
                    "getQueryResults(String strSql, int[] nOutCol)", //メソッド名
                    LfcDBMsgConst.ERA009, //ロジックメッセージ
                    e);                                   //システムエラーメッセージ
            return new String[0][0];
        }
    }

    /**
     * 更新配列に設定する項目より複数のレコードを更新するメソッド．    <BR>
     *
     * <PRE>
     *  ループでupdateRecordメソッドをコールして複数レコードの更新を行う。
     * </PRE>
     *
     * @param   nFieldNameArray  更新フィールド名を格納配列
     * param   vValues          更新フィールド値を格納するVector
     * @return  boolean   true ：複数のレコードの更新は成功
     *                    false：複数のレコードの更新は失敗
     * @see     #updateRecord(int[], Vector)
     * @since   01-01
     */
    public boolean updateRecords(int[] nFieldNameArray, String[][] strValues) {
        // try {
        for (int i = 0; i < strValues.length; i++) {
            if (!updateRecord(nFieldNameArray, strValues[i])) {
                return false;
            }
        }
        return true;
        /*
        } catch (Exception e) {
        _strErrorMessage = LfcDBMsgConst.ERA000;
        LfcSystemLog.writeLog("StairsBean",                                             //クラス名
        "updateRecords(int[] nFieldNameArray, Vector vValues)",   //メソッド名
        LfcDBMsgConst.ERA004,                                      //ロジックメッセージ
        e);                                            //システムエラーメッセージ
        return false;
        }     */
    }

    /**
     * 更新配列に設定する項目より単一のレコードを更新するメソッド．    <BR>
     *
     * <PRE>
     *  キーINDEXの設定は正しいかどうかの判断。
     *  更新配列に設定する項目だけ更新する。
     * </PRE>
     *
     * @param   nFieldNameArray  更新フィールド名を格納配列
     * @param   vValues          更新フィールド値を格納するVector
     * @return  boolean   true ：単一のレコードの更新は成功
     *                    false：単一のレコードの更新は失敗
     * @see     #updateFlag(int, int[])
     * @since   01-01
     */
    public boolean updateRecord(int[] nFieldNameArray, String[] strValues) {
        String[] strValue = new String[STAIRS_RECORD_COUNT];
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strValues[STAIRS_REC_NO].equals(_strLeaseResults[i][STAIRS_REC_NO]) &&
                    strValues[STAIRS_BUKKEN_NO].equals(_strLeaseResults[i][STAIRS_BUKKEN_NO])) {
                System.arraycopy(_strLeaseResults[i], 0, strValue, 0, STAIRS_RECORD_COUNT);
                strValue[STAIRS_BUKKEN_FR] = strValues[STAIRS_BUKKEN_FR];
                strValue[STAIRS_BUKKEN_TO] = strValues[STAIRS_BUKKEN_TO];
                break;
            }
        }

        removeRecord(strValues[STAIRS_BUKKEN_NO], strValues[STAIRS_STAIR]);
        insertRecord(strValue);
        return true;
    }

    public boolean insertRecords(String[][] strValues) {
        return insertRecords(null, strValues);
    }

    /**
     * INSERT配列に設定する項目より複数のレコードをINSERTするメソッド．    <BR>
     *
     * <PRE>
     *  ループでinsertRecordメソッドをコールして複数レコードのINSERTを行う。
     * </PRE>
     *
     * @param   nFieldNameArray    INSERTフィールド名を格納配列
     * @param   vValues            INSERTフィールド値を格納するVector
     * @return  boolean   true ：  複数のレコードのINSERTは成功
     *                    false：  複数のレコードのINSERTは失敗
     * @see     #insertRecord(int, Vector)
     * @since   01-01
     */
    public boolean insertRecords(int[] nFieldNameArray, String[][] strValues) {
        try {
            int nInsertBeforeRowCnt = _stairsXmlReader.getRowCount() - 1;
            for (int i = 0; i < strValues.length; i++) {
                if (!insertRecord(strValues[i])) {
                    return false;
                }
            }
            /*
            //refresh array
            String[][] strTempArr;
            int nInsertBeforeResultsLen = 0;
            if(_strLeaseResults == null) {
            strTempArr = new String[strValues.length][STAIRS_RECORD_COUNT];
            nInsertBeforeResultsLen = 0;
            } else {
            strTempArr = new String[_strLeaseResults.length + strValues.length][STAIRS_RECORD_COUNT];
            System.arraycopy(_strLeaseResults, 0, strTempArr, 0, _strLeaseResults.length);
            nInsertBeforeResultsLen = _strLeaseResults.length;
            }
            int nStartIndex = nInsertBeforeRowCnt + 1;
            for(int i = 0; i < strValues.length; i++) {
            strValues[i][strValues[0].length - 1] = "" + (nStartIndex + i);
            System.arraycopy(strValues[i], 0, strTempArr[nInsertBeforeResultsLen + i], 0, strValues[i].length);
            nInsertBeforeRowCnt++;
            }
            _strLeaseResults = strTempArr;
             */
            return true;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("StairsBean", //クラス名
                    "insertRecords(int[] nFieldNameArray, String[][] strValues)", //メソッド名
                    LfcDBMsgConst.ERA012, //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
            return false;
        }
    }

    /**
     * INSERT配列に設定する項目より単一のレコードをINSERTするメソッド．    <BR>
     *
     * <PRE>
     *  キーユニークチェック。
     *  INSERT配列に設定する項目だけINSERTする。
     * </PRE>
     *
     * @param   nFieldNameArray    INSERTフィールド名を格納配列
     * @param   vValues            INSERTフィールド値を格納するVector
     *
     * @return  boolean    true ： 単一のレコードのINSERTは成功
     *                     false： 単一のレコードのINSERTは失敗
     * @since              01-01
     */
    public boolean insertRecord(String[] strValues) {
        //20060612回収スケジュールに回収金=0のみ場合　空白行を外す　begin
        if ("0".equals(strValues[STAIRS_INCOME]) && "".equals(strValues[STAIRS_DATE_YY])) {
            return true;
        }
        //20060612回収スケジュールに回収金=0のみ場合　空白行を外す　end
        String strOff = _strBuffer.toString();
        int nOffset = strOff.lastIndexOf("</STAIRS>");
        StringBuffer strOut = new StringBuffer();

        strOut.append("<ROW BUKKEN_NO=\"");
        strOut.append(strValues[STAIRS_BUKKEN_NO]);
        strOut.append("\" REC_NO=\"");
        strOut.append(strValues[STAIRS_REC_NO]);
        strOut.append("\" STAIR=\"");
        strOut.append(strValues[STAIRS_STAIR]);
        strOut.append("\">");
        strOut.append("<BUKKEN_FR>" + strValues[STAIRS_BUKKEN_FR] + "</BUKKEN_FR>");
        strOut.append("<BUKKEN_TO>" + strValues[STAIRS_BUKKEN_TO] + "</BUKKEN_TO>");

        //20050912 ZJ start
        //20060614 ws change start
//        strOut.append("<INCOME>" + new Long(strValues[STAIRS_INCOME]) + "</INCOME>");
//        strOut.append("<CYCLE>" + new Long(strValues[STAIRS_CYCLE]) + "</CYCLE>");
//        strOut.append("<FREQUE>" + new Long(strValues[STAIRS_FREQUE]) + "</FREQUE>");
        strOut.append("<INCOME>" + spaceTo0(strValues[STAIRS_INCOME]) + "</INCOME>");
        strOut.append("<CYCLE>" + spaceTo0(strValues[STAIRS_CYCLE]) + "</CYCLE>");
        strOut.append("<FREQUE>" + spaceTo0(strValues[STAIRS_FREQUE]) + "</FREQUE>");
        //20060614 ws change start
        //20050912 ZJ end

        strOut.append("<DATE_YY>" + strValues[STAIRS_DATE_YY] + "</DATE_YY>");
        strOut.append("<DATE_MM >" + strValues[STAIRS_DATE_MM] + "</DATE_MM >");
        strOut.append("<DATE_DD>" + strValues[STAIRS_DATE_DD] + "</DATE_DD>");

        //20051207 zj s
        strOut.append(
                "<RESERVE_C_01>" + strValues[STAIRS_RESERVE_C_01] + "</RESERVE_C_01>");
        strOut.append(
                "<RESERVE_C_02>" + strValues[STAIRS_RESERVE_C_02] + "</RESERVE_C_02>");
        strOut.append(
                "<RESERVE_C_03>" + strValues[STAIRS_RESERVE_C_03] + "</RESERVE_C_03>");
        strOut.append(
                "<RESERVE_C_04>" + strValues[STAIRS_RESERVE_C_04] + "</RESERVE_C_04>");
        strOut.append(
                "<RESERVE_C_05>" + strValues[STAIRS_RESERVE_C_05] + "</RESERVE_C_05>");
        strOut.append(
                "<RESERVE_C_06>" + strValues[STAIRS_RESERVE_C_06] + "</RESERVE_C_06>");
        strOut.append(
                "<RESERVE_C_07>" + strValues[STAIRS_RESERVE_C_07] + "</RESERVE_C_07>");
        strOut.append(
                "<RESERVE_C_08>" + strValues[STAIRS_RESERVE_C_08] + "</RESERVE_C_08>");
        strOut.append(
                "<RESERVE_C_09>" + strValues[STAIRS_RESERVE_C_09] + "</RESERVE_C_09>");
        strOut.append(
                "<RESERVE_C_10>" + strValues[STAIRS_RESERVE_C_10] + "</RESERVE_C_10>");
        strOut.append(
                "<RESERVE_C_11>" + strValues[STAIRS_RESERVE_C_11] + "</RESERVE_C_11>");
        strOut.append(
                "<RESERVE_C_12>" + strValues[STAIRS_RESERVE_C_12] + "</RESERVE_C_12>");
        strOut.append(
                "<RESERVE_C_13>" + strValues[STAIRS_RESERVE_C_13] + "</RESERVE_C_13>");
        strOut.append(
                "<RESERVE_C_14>" + strValues[STAIRS_RESERVE_C_14] + "</RESERVE_C_14>");
        strOut.append(
                "<RESERVE_C_15>" + strValues[STAIRS_RESERVE_C_15] + "</RESERVE_C_15>");
        strOut.append(
                "<RESERVE_C_16>" + strValues[STAIRS_RESERVE_C_16] + "</RESERVE_C_16>");
        strOut.append(
                "<RESERVE_C_17>" + strValues[STAIRS_RESERVE_C_17] + "</RESERVE_C_17>");
        strOut.append(
                "<RESERVE_C_18>" + strValues[STAIRS_RESERVE_C_18] + "</RESERVE_C_18>");
        strOut.append(
                "<RESERVE_C_19>" + strValues[STAIRS_RESERVE_C_19] + "</RESERVE_C_19>");
        strOut.append(
                "<RESERVE_C_20>" + strValues[STAIRS_RESERVE_C_20] + "</RESERVE_C_20>");
        strOut.append(
                "<RESERVE_C_21>" + strValues[STAIRS_RESERVE_C_21] + "</RESERVE_C_21>");
        strOut.append(
                "<RESERVE_C_22>" + strValues[STAIRS_RESERVE_C_22] + "</RESERVE_C_22>");
        strOut.append(
                "<RESERVE_C_23>" + strValues[STAIRS_RESERVE_C_23] + "</RESERVE_C_23>");
        strOut.append(
                "<RESERVE_C_24>" + strValues[STAIRS_RESERVE_C_24] + "</RESERVE_C_24>");
        strOut.append(
                "<RESERVE_C_25>" + strValues[STAIRS_RESERVE_C_25] + "</RESERVE_C_25>");
        strOut.append(
                "<RESERVE_C_26>" + strValues[STAIRS_RESERVE_C_26] + "</RESERVE_C_26>");
        strOut.append(
                "<RESERVE_C_27>" + strValues[STAIRS_RESERVE_C_27] + "</RESERVE_C_27>");
        strOut.append(
                "<RESERVE_C_28>" + strValues[STAIRS_RESERVE_C_28] + "</RESERVE_C_28>");
        strOut.append(
                "<RESERVE_C_29>" + strValues[STAIRS_RESERVE_C_29] + "</RESERVE_C_29>");
        strOut.append(
                "<RESERVE_C_30>" + strValues[STAIRS_RESERVE_C_30] + "</RESERVE_C_30>");

        strOut.append(
                "<RESERVE_N_01>" + strValues[STAIRS_RESERVE_N_01] + "</RESERVE_N_01>");
        strOut.append(
                "<RESERVE_N_02>" + strValues[STAIRS_RESERVE_N_02] + "</RESERVE_N_02>");
        strOut.append(
                "<RESERVE_N_03>" + strValues[STAIRS_RESERVE_N_03] + "</RESERVE_N_03>");
        strOut.append(
                "<RESERVE_N_04>" + strValues[STAIRS_RESERVE_N_04] + "</RESERVE_N_04>");
        strOut.append(
                "<RESERVE_N_05>" + strValues[STAIRS_RESERVE_N_05] + "</RESERVE_N_05>");
        strOut.append(
                "<RESERVE_N_06>" + strValues[STAIRS_RESERVE_N_06] + "</RESERVE_N_06>");
        strOut.append(
                "<RESERVE_N_07>" + strValues[STAIRS_RESERVE_N_07] + "</RESERVE_N_07>");
        strOut.append(
                "<RESERVE_N_08>" + strValues[STAIRS_RESERVE_N_08] + "</RESERVE_N_08>");
        strOut.append(
                "<RESERVE_N_09>" + strValues[STAIRS_RESERVE_N_09] + "</RESERVE_N_09>");
        strOut.append(
                "<RESERVE_N_10>" + strValues[STAIRS_RESERVE_N_10] + "</RESERVE_N_10>");
        strOut.append(
                "<RESERVE_N_11>" + strValues[STAIRS_RESERVE_N_11] + "</RESERVE_N_11>");
        strOut.append(
                "<RESERVE_N_12>" + strValues[STAIRS_RESERVE_N_12] + "</RESERVE_N_12>");
        strOut.append(
                "<RESERVE_N_13>" + strValues[STAIRS_RESERVE_N_13] + "</RESERVE_N_13>");
        strOut.append(
                "<RESERVE_N_14>" + strValues[STAIRS_RESERVE_N_14] + "</RESERVE_N_14>");
        strOut.append(
                "<RESERVE_N_15>" + strValues[STAIRS_RESERVE_N_15] + "</RESERVE_N_15>");
        strOut.append(
                "<RESERVE_N_16>" + strValues[STAIRS_RESERVE_N_16] + "</RESERVE_N_16>");
        strOut.append(
                "<RESERVE_N_17>" + strValues[STAIRS_RESERVE_N_17] + "</RESERVE_N_17>");
        strOut.append(
                "<RESERVE_N_18>" + strValues[STAIRS_RESERVE_N_18] + "</RESERVE_N_18>");
        strOut.append(
                "<RESERVE_N_19>" + strValues[STAIRS_RESERVE_N_19] + "</RESERVE_N_19>");
        strOut.append(
                "<RESERVE_N_20>" + strValues[STAIRS_RESERVE_N_20] + "</RESERVE_N_20>");
        strOut.append(
                "<RESERVE_N_21>" + strValues[STAIRS_RESERVE_N_21] + "</RESERVE_N_21>");
        strOut.append(
                "<RESERVE_N_22>" + strValues[STAIRS_RESERVE_N_22] + "</RESERVE_N_22>");
        strOut.append(
                "<RESERVE_N_23>" + strValues[STAIRS_RESERVE_N_23] + "</RESERVE_N_23>");
        strOut.append(
                "<RESERVE_N_24>" + strValues[STAIRS_RESERVE_N_24] + "</RESERVE_N_24>");
        strOut.append(
                "<RESERVE_N_25>" + strValues[STAIRS_RESERVE_N_25] + "</RESERVE_N_25>");
        strOut.append(
                "<RESERVE_N_26>" + strValues[STAIRS_RESERVE_N_26] + "</RESERVE_N_26>");
        strOut.append(
                "<RESERVE_N_27>" + strValues[STAIRS_RESERVE_N_27] + "</RESERVE_N_27>");
        strOut.append(
                "<RESERVE_N_28>" + strValues[STAIRS_RESERVE_N_28] + "</RESERVE_N_28>");
        strOut.append(
                "<RESERVE_N_29>" + strValues[STAIRS_RESERVE_N_29] + "</RESERVE_N_29>");
        strOut.append(
                "<RESERVE_N_30>" + strValues[STAIRS_RESERVE_N_30] + "</RESERVE_N_30>");
        //20051207 zj e

        strOut.append("</ROW>");

        _strBuffer.insert(nOffset, strOut.toString());

        //refresh array
        /*
        String[][] strTempArr;
        if(_strLeaseResults == null) {
        _strLeaseResults = new String[1][STAIRS_RECORD_COUNT];
        System.arraycopy(strValues, 0, _strLeaseResults[0], 0, STAIRS_RECORD_COUNT);
        } else {
        strTempArr = new String[_strLeaseResults.length + 1][STAIRS_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, strTempArr, 0, _strLeaseResults.length);
        System.arraycopy(strValues, 0, strTempArr[_strLeaseResults.length], 0, STAIRS_RECORD_COUNT);
        _strLeaseResults = strTempArr;
        }
         */

        String strChangeTmp = strValues[STAIRS_REC_NO];
        strValues[STAIRS_REC_NO] = strValues[STAIRS_BUKKEN_NO];
        strValues[STAIRS_BUKKEN_NO] = strChangeTmp;
        //Attention:RecNo and BukkenNo had changed!!!
        //Because XML file's order had changed!!!

        _stairsXmlReader.insertRow(strValues);
        getQueryResults(strValues[STAIRS_BUKKEN_NO]);
        return true;
    }

    //pzk add 20051109 s
    public boolean insertPreviousRecord(String[] strValues) {
        String strOff = _strPreviousBuffer.toString();
        int nOffset = strOff.lastIndexOf("</STAIRS>");
        StringBuffer strOut = new StringBuffer();

        strOut.append("<ROW BUKKEN_NO=\"");
        strOut.append(strValues[STAIRS_BUKKEN_NO]);
        strOut.append("\" REC_NO=\"");
        strOut.append(strValues[STAIRS_REC_NO]);
        strOut.append("\" STAIR=\"");
        strOut.append(strValues[STAIRS_STAIR]);
        strOut.append("\">");
        strOut.append("<BUKKEN_FR>" + strValues[STAIRS_BUKKEN_FR] + "</BUKKEN_FR>");
        strOut.append("<BUKKEN_TO>" + strValues[STAIRS_BUKKEN_TO] + "</BUKKEN_TO>");

        //20050912 ZJ start
        //20060614 ws change start
//        strOut.append("<INCOME>" + new Long(strValues[STAIRS_INCOME]) + "</INCOME>");
//        strOut.append("<CYCLE>" + new Long(strValues[STAIRS_CYCLE]) + "</CYCLE>");
//        strOut.append("<FREQUE>" + new Long(strValues[STAIRS_FREQUE]) + "</FREQUE>");
        strOut.append("<INCOME>" + spaceTo0(strValues[STAIRS_INCOME]) + "</INCOME>");
        strOut.append("<CYCLE>" + spaceTo0(strValues[STAIRS_CYCLE]) + "</CYCLE>");
        strOut.append("<FREQUE>" + spaceTo0(strValues[STAIRS_FREQUE]) + "</FREQUE>");
        //20060614 ws change end
        //20050912 ZJ end

        strOut.append("<DATE_YY>" + strValues[STAIRS_DATE_YY] + "</DATE_YY>");
        strOut.append("<DATE_MM >" + strValues[STAIRS_DATE_MM] + "</DATE_MM >");
        strOut.append("<DATE_DD>" + strValues[STAIRS_DATE_DD] + "</DATE_DD>");

        //20051207 zj s
        strOut.append(
                "<RESERVE_C_01>" + strValues[STAIRS_RESERVE_C_01] + "</RESERVE_C_01>");
        strOut.append(
                "<RESERVE_C_02>" + strValues[STAIRS_RESERVE_C_02] + "</RESERVE_C_02>");
        strOut.append(
                "<RESERVE_C_03>" + strValues[STAIRS_RESERVE_C_03] + "</RESERVE_C_03>");
        strOut.append(
                "<RESERVE_C_04>" + strValues[STAIRS_RESERVE_C_04] + "</RESERVE_C_04>");
        strOut.append(
                "<RESERVE_C_05>" + strValues[STAIRS_RESERVE_C_05] + "</RESERVE_C_05>");
        strOut.append(
                "<RESERVE_C_06>" + strValues[STAIRS_RESERVE_C_06] + "</RESERVE_C_06>");
        strOut.append(
                "<RESERVE_C_07>" + strValues[STAIRS_RESERVE_C_07] + "</RESERVE_C_07>");
        strOut.append(
                "<RESERVE_C_08>" + strValues[STAIRS_RESERVE_C_08] + "</RESERVE_C_08>");
        strOut.append(
                "<RESERVE_C_09>" + strValues[STAIRS_RESERVE_C_09] + "</RESERVE_C_09>");
        strOut.append(
                "<RESERVE_C_10>" + strValues[STAIRS_RESERVE_C_10] + "</RESERVE_C_10>");
        strOut.append(
                "<RESERVE_C_11>" + strValues[STAIRS_RESERVE_C_11] + "</RESERVE_C_11>");
        strOut.append(
                "<RESERVE_C_12>" + strValues[STAIRS_RESERVE_C_12] + "</RESERVE_C_12>");
        strOut.append(
                "<RESERVE_C_13>" + strValues[STAIRS_RESERVE_C_13] + "</RESERVE_C_13>");
        strOut.append(
                "<RESERVE_C_14>" + strValues[STAIRS_RESERVE_C_14] + "</RESERVE_C_14>");
        strOut.append(
                "<RESERVE_C_15>" + strValues[STAIRS_RESERVE_C_15] + "</RESERVE_C_15>");
        strOut.append(
                "<RESERVE_C_16>" + strValues[STAIRS_RESERVE_C_16] + "</RESERVE_C_16>");
        strOut.append(
                "<RESERVE_C_17>" + strValues[STAIRS_RESERVE_C_17] + "</RESERVE_C_17>");
        strOut.append(
                "<RESERVE_C_18>" + strValues[STAIRS_RESERVE_C_18] + "</RESERVE_C_18>");
        strOut.append(
                "<RESERVE_C_19>" + strValues[STAIRS_RESERVE_C_19] + "</RESERVE_C_19>");
        strOut.append(
                "<RESERVE_C_20>" + strValues[STAIRS_RESERVE_C_20] + "</RESERVE_C_20>");
        strOut.append(
                "<RESERVE_C_21>" + strValues[STAIRS_RESERVE_C_21] + "</RESERVE_C_21>");
        strOut.append(
                "<RESERVE_C_22>" + strValues[STAIRS_RESERVE_C_22] + "</RESERVE_C_22>");
        strOut.append(
                "<RESERVE_C_23>" + strValues[STAIRS_RESERVE_C_23] + "</RESERVE_C_23>");
        strOut.append(
                "<RESERVE_C_24>" + strValues[STAIRS_RESERVE_C_24] + "</RESERVE_C_24>");
        strOut.append(
                "<RESERVE_C_25>" + strValues[STAIRS_RESERVE_C_25] + "</RESERVE_C_25>");
        strOut.append(
                "<RESERVE_C_26>" + strValues[STAIRS_RESERVE_C_26] + "</RESERVE_C_26>");
        strOut.append(
                "<RESERVE_C_27>" + strValues[STAIRS_RESERVE_C_27] + "</RESERVE_C_27>");
        strOut.append(
                "<RESERVE_C_28>" + strValues[STAIRS_RESERVE_C_28] + "</RESERVE_C_28>");
        strOut.append(
                "<RESERVE_C_29>" + strValues[STAIRS_RESERVE_C_29] + "</RESERVE_C_29>");
        strOut.append(
                "<RESERVE_C_30>" + strValues[STAIRS_RESERVE_C_30] + "</RESERVE_C_30>");

        strOut.append(
                "<RESERVE_N_01>" + strValues[STAIRS_RESERVE_N_01] + "</RESERVE_N_01>");
        strOut.append(
                "<RESERVE_N_02>" + strValues[STAIRS_RESERVE_N_02] + "</RESERVE_N_02>");
        strOut.append(
                "<RESERVE_N_03>" + strValues[STAIRS_RESERVE_N_03] + "</RESERVE_N_03>");
        strOut.append(
                "<RESERVE_N_04>" + strValues[STAIRS_RESERVE_N_04] + "</RESERVE_N_04>");
        strOut.append(
                "<RESERVE_N_05>" + strValues[STAIRS_RESERVE_N_05] + "</RESERVE_N_05>");
        strOut.append(
                "<RESERVE_N_06>" + strValues[STAIRS_RESERVE_N_06] + "</RESERVE_N_06>");
        strOut.append(
                "<RESERVE_N_07>" + strValues[STAIRS_RESERVE_N_07] + "</RESERVE_N_07>");
        strOut.append(
                "<RESERVE_N_08>" + strValues[STAIRS_RESERVE_N_08] + "</RESERVE_N_08>");
        strOut.append(
                "<RESERVE_N_09>" + strValues[STAIRS_RESERVE_N_09] + "</RESERVE_N_09>");
        strOut.append(
                "<RESERVE_N_10>" + strValues[STAIRS_RESERVE_N_10] + "</RESERVE_N_10>");
        strOut.append(
                "<RESERVE_N_11>" + strValues[STAIRS_RESERVE_N_11] + "</RESERVE_N_11>");
        strOut.append(
                "<RESERVE_N_12>" + strValues[STAIRS_RESERVE_N_12] + "</RESERVE_N_12>");
        strOut.append(
                "<RESERVE_N_13>" + strValues[STAIRS_RESERVE_N_13] + "</RESERVE_N_13>");
        strOut.append(
                "<RESERVE_N_14>" + strValues[STAIRS_RESERVE_N_14] + "</RESERVE_N_14>");
        strOut.append(
                "<RESERVE_N_15>" + strValues[STAIRS_RESERVE_N_15] + "</RESERVE_N_15>");
        strOut.append(
                "<RESERVE_N_16>" + strValues[STAIRS_RESERVE_N_16] + "</RESERVE_N_16>");
        strOut.append(
                "<RESERVE_N_17>" + strValues[STAIRS_RESERVE_N_17] + "</RESERVE_N_17>");
        strOut.append(
                "<RESERVE_N_18>" + strValues[STAIRS_RESERVE_N_18] + "</RESERVE_N_18>");
        strOut.append(
                "<RESERVE_N_19>" + strValues[STAIRS_RESERVE_N_19] + "</RESERVE_N_19>");
        strOut.append(
                "<RESERVE_N_20>" + strValues[STAIRS_RESERVE_N_20] + "</RESERVE_N_20>");
        strOut.append(
                "<RESERVE_N_21>" + strValues[STAIRS_RESERVE_N_21] + "</RESERVE_N_21>");
        strOut.append(
                "<RESERVE_N_22>" + strValues[STAIRS_RESERVE_N_22] + "</RESERVE_N_22>");
        strOut.append(
                "<RESERVE_N_23>" + strValues[STAIRS_RESERVE_N_23] + "</RESERVE_N_23>");
        strOut.append(
                "<RESERVE_N_24>" + strValues[STAIRS_RESERVE_N_24] + "</RESERVE_N_24>");
        strOut.append(
                "<RESERVE_N_25>" + strValues[STAIRS_RESERVE_N_25] + "</RESERVE_N_25>");
        strOut.append(
                "<RESERVE_N_26>" + strValues[STAIRS_RESERVE_N_26] + "</RESERVE_N_26>");
        strOut.append(
                "<RESERVE_N_27>" + strValues[STAIRS_RESERVE_N_27] + "</RESERVE_N_27>");
        strOut.append(
                "<RESERVE_N_28>" + strValues[STAIRS_RESERVE_N_28] + "</RESERVE_N_28>");
        strOut.append(
                "<RESERVE_N_29>" + strValues[STAIRS_RESERVE_N_29] + "</RESERVE_N_29>");
        strOut.append(
                "<RESERVE_N_30>" + strValues[STAIRS_RESERVE_N_30] + "</RESERVE_N_30>");
        //20051207 zj e

        strOut.append("</ROW>");

        _strPreviousBuffer.insert(nOffset, strOut.toString());



        String strChangeTmp = strValues[STAIRS_REC_NO];
        strValues[STAIRS_REC_NO] = strValues[STAIRS_BUKKEN_NO];
        strValues[STAIRS_BUKKEN_NO] = strChangeTmp;
        //Attention:RecNo and BukkenNo had changed!!!
        //Because XML file's order had changed!!!

        _previousStairsXmlReader.insertRow(strValues);
        getPreviousQueryResults(strValues[STAIRS_BUKKEN_NO]);
        return true;
    }
    //pzk add 20051109 e

    /**
     * XPATH文により複数のレコードを削除するメソッド．    <BR>
     *
     * <PRE>
     *  １．XPATH文によりID結果集を取得する。
     *  ２．ID結果集により対応するINDEX配列を取得する。
     *  ３．INDEX配列により、対応のレコードを削除する。
     * </PRE>
     *
     * @param   strSql            XPATH文
     * @return  boolean   true ： 複数のレコードは削除成功
     *                    false： 複数のレコードは削除失敗
     * @see     #getIDs(String)
     * @see     #getIDsIndexArray(Vector)
     * @since   01-01
     */
    public boolean removeRecords(String strFrom, String strTo) {
        //try {

        int nFrom = LfcFrmComm.toInt(strFrom);
        int nTo = LfcFrmComm.toInt(strTo);
        int nIndexCnt = 0;
        if (_strLeaseResults == null) {
            return true;
        }
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (LfcFrmComm.toInt(_strLeaseResults[i][STAIRS_BUKKEN_NO]) >= nFrom && LfcFrmComm.toInt(_strLeaseResults[i][STAIRS_BUKKEN_NO]) <= nTo) {
                nIndexCnt++;
            }
        }
        String[] strRemoveBukkenNos = new String[nIndexCnt];

        for (int i = 0, j = 0; i < _strLeaseResults.length; i++) {
            if (LfcFrmComm.toInt(_strLeaseResults[i][STAIRS_BUKKEN_NO]) >= nFrom && LfcFrmComm.toInt(_strLeaseResults[i][STAIRS_BUKKEN_NO]) <= nTo) {
                strRemoveBukkenNos[j] = _strLeaseResults[i][STAIRS_BUKKEN_NO];
                j++;
            }
        }
        //remove row & refresh array
        for (int i = 0; i < strRemoveBukkenNos.length; i++) {
            removeRecord(strRemoveBukkenNos[i]);
        }
        return true;/*
        } catch (Exception e) {
        _strErrorMessage = LfcDBMsgConst.ERA000;
        LfcSystemLog.writeLog("StairsBean",                                    //クラス名
        "removeRecords(String strSql)",                  //メソッド名
        LfcDBMsgConst.ERA014,                             //ロジックメッセージ
        e);                                   //システムエラーメッセージ
        return false;
        }           */
    }

    public boolean removeRecord(String strBukkenNo) {
        String strDelete = _strBuffer.toString();
        int nRemoveCnt = 0;
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            int nPos6 = strDelete.indexOf("BUKKEN_NO", nPos1);
            int nPos7 = strDelete.indexOf("\"", nPos6);
            int nPos8 = strDelete.indexOf("\"", nPos7 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2 ||
                    nPos6 > nPos2 || nPos7 > nPos2 || nPos8 > nPos2) {
                break;
            }
            String strKeyRecNoValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            String strKeyBukkenNoValue = strDelete.substring(nPos7 + 1, nPos8).trim();
            if (_strLeaseResults != null && strBukkenNo.equals(strKeyBukkenNoValue) && strKeyRecNoValue.equals(_strCurRecNo)) {
                int nPos9 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos9 + 6);
                nRemoveCnt++;
            }
            i = nPos1;
        }
        /*
        String[][] strTmp = new String[_strLeaseResults.length - nRemoveCnt][STAIRS_RECORD_COUNT];
        for(int i = 0, j = 0; i < _strLeaseResults.length; i++) {
        if(strBukkenNo.equals(_strLeaseResults[i][STAIRS_BUKKEN_NO])) {
        continue;
        }
        System.arraycopy(_strLeaseResults[i], 0, strTmp[j++], 0, STAIRS_RECORD_COUNT);
        }
        _strLeaseResults = strTmp;
         */
        if (_strLeaseResults != null && _strLeaseResults.length > 0) {
            for (int i = _stairsXmlReader.getRowCount() - 1; i >= 0; i--) {
                if (_strCurRecNo.equals(_stairsXmlReader.getData(i, "REC_NO")) &&
                        strBukkenNo.equals(_stairsXmlReader.getData(i, "BUKKEN_NO"))) {
                    _stairsXmlReader.removeRow(i);
                }
            }
            getQueryResults(_strCurRecNo);
        } else {
            _strLeaseResults = null;
        }
        return true;
    }

    public boolean removeRecord(String strBukkenNo, String strStair) {
        String strDelete = _strBuffer.toString();
        int nRemoveCnt = 0;
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            int nPos6 = strDelete.indexOf("BUKKEN_NO", nPos1);
            int nPos7 = strDelete.indexOf("\"", nPos6);
            int nPos8 = strDelete.indexOf("\"", nPos7 + 1);
            int nPos9 = strDelete.indexOf("STAIR", nPos1);
            int nPos10 = strDelete.indexOf("\"", nPos6);
            int nPos11 = strDelete.indexOf("\"", nPos7 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2 ||
                    nPos6 > nPos2 || nPos7 > nPos2 || nPos8 > nPos2 ||
                    nPos9 > nPos2 || nPos10 > nPos2 || nPos11 > nPos2) {
                break;
            }
            String strKeyRecNoValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            String strKeyBukkenNoValue = strDelete.substring(nPos7 + 1, nPos8).trim();
            String strKeyStairValue = strDelete.substring(nPos10 + 1, nPos11).trim();
            if (strBukkenNo.equals(strKeyBukkenNoValue) && strKeyRecNoValue.equals(_strCurRecNo) && strKeyStairValue.equals(strStair)) {
                int nPos12 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos12 + 6);
                break;
            }
            i = nPos1;
        }
        /*
        String[][] strTmp = new String[_strLeaseResults.length - nRemoveCnt][STAIRS_RECORD_COUNT];
        for(int i = 0, j = 0; i < _strLeaseResults.length; i++) {
        if(strBukkenNo.equals(_strLeaseResults[i][STAIRS_BUKKEN_NO])) {
        continue;
        }
        System.arraycopy(_strLeaseResults[i], 0, strTmp[j++], 0, STAIRS_RECORD_COUNT);
        }
        _strLeaseResults = strTmp;
         */
        if (_strLeaseResults != null && _strLeaseResults.length > 0) {
            for (int i = _stairsXmlReader.getRowCount() - 1; i >= 0; i--) {
                if (_strCurRecNo.equals(_stairsXmlReader.getData(i, "REC_NO")) &&
                        strBukkenNo.equals(_stairsXmlReader.getData(i, "BUKKEN_NO")) &&
                        strStair.equals(_stairsXmlReader.getData(i, "STAIR"))) {
                    _stairsXmlReader.removeRow(i);
                }
            }
            getQueryResults(_strCurRecNo);
        } else {
            _strLeaseResults = null;
        }
        return true;
    }

    /**
     * XPATH文により複数のレコードを削除するメソッド．    <BR>
     *
     * <PRE>
     *  １．XPATH文によりID結果集を取得する。
     *  ２．ID結果集により対応するINDEX配列を取得する。
     *  ３．INDEX配列により、対応のレコードを削除する。
     * </PRE>
     *
     * @param   strEstNo            EstNo
     * @return  boolean   true ： 複数のレコードは削除成功
     *                    false： 複数のレコードは削除失敗
     * @see     #getIDs(String)
     * @see     #getIDsIndexArray(Vector)
     * @since   01-01
     */
    public boolean removeRecords(String strRecNo) {
        String strDelete = _strBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2) {
                break;
            }
            String strKeyValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            if (strRecNo.equals(strKeyValue)) {
                int nPos6 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos6 + 6);
            }
            i = nPos1;
        }
        for (int i = _stairsXmlReader.getRowCount() - 1; i >= 0; i--) {
            if (strRecNo.equals(_stairsXmlReader.getData(i, "REC_NO"))) {
                _stairsXmlReader.removeRow(i);
            }
        }
        _strLeaseResults = null;
        return true;
    }

    //pzk add 20051109 s
    public boolean removePreviousRecords(String strRecNo) {
        String strDelete = _strPreviousBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2) {
                break;
            }
            String strKeyValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            if (strRecNo.equals(strKeyValue)) {
                int nPos6 = strDelete.indexOf("</ROW>", nPos1);
                _strPreviousBuffer.delete(nPos1, nPos6 + 6);
            }
            i = nPos1;
        }
        for (int i = _previousStairsXmlReader.getRowCount() - 1; i >= 0; i--) {
            if (strRecNo.equals(_previousStairsXmlReader.getData(i, "REC_NO"))) {
                _previousStairsXmlReader.removeRow(i);
            }
        }
        _strPreviousResults = null;
        return true;
    }
    //pzk add 20051109 e

    /**
     * 結果集がNULLかどうかを判断するメソッド。
     * @param   無し。
     * @return  無し。
     */
    public  boolean isResultsNull() {
        if (_strLeaseResults == null || _strLeaseResults.length == 0) {
            return true;
        } else {
            return false;
        }
    }

    public String[][] getCopyRec(String strRecNo, String strBukenNo) {
        String[][] strEstResults = getQueryResultsForEstCopy(strRecNo);
        int nCnt = 0;
        for (int i = 0; i < strEstResults.length; i++) {
            if (strBukenNo.equals(strEstResults[i][STAIRS_BUKKEN_NO])) {
                nCnt = nCnt + 1;
            }
        }
        if (nCnt == 0) {
            return new String[0][0];
        }
        String[][] strReturnArr = new String[nCnt][STAIRS_BUKKEN_NO];
        nCnt = 0;
        for (int i = 0; i < strEstResults.length; i++) {
            if (strBukenNo.equals(strEstResults[i][STAIRS_BUKKEN_NO])) {
                strReturnArr[nCnt] = strEstResults[i];
                nCnt = nCnt + 1;
            }
        }
        return strReturnArr;
    }

    public void doCommit() {
        try {
            FileWriter fw = new FileWriter(_strXmlFilePath);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(_strBuffer.toString());
            pw.close();
        } catch (IOException e) {
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("StairsBean.doCommit()", //クラス名
                    _strBuffer.toString(), //メソッド名
                    _strXmlFilePath + "へ書き出すときエラー", //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
        }
    }
    //pzk add 20051109 s

    public void doPreviousCommit() {
        try {
            FileWriter fw = new FileWriter(_strPreviousXmlFilePath);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(_strPreviousBuffer.toString());
            pw.close();
        } catch (IOException e) {
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("StairsBean.doPreviousCommit()", //クラス名
                    _strPreviousBuffer.toString(), //メソッド名
                    _strPreviousXmlFilePath + "へ書き出すときエラー", //ロジックメッセージ
                    e);                                           //システムエラーメッセージ

        }
    }
    //pzk add 20051109 e

    public boolean copyRecords(String[][] strCopys) {
        if (isResultsNull()) {
            return true;
        }
        int nUpdateIndex = 0;
        String[][] strTmpArr = new String[_strLeaseResults.length + strCopys.length][STAIRS_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, strTmpArr, 0, _strLeaseResults.length);
        for (int i = 0; i < strCopys.length; i++) {
            for (int j = 0; j < _strLeaseResults.length; j++) {
                if (strCopys[i][STAIRS_BUKKEN_NO].equals(_strLeaseResults[j][STAIRS_BUKKEN_NO]) && strCopys[i][STAIRS_STAIR].equals(_strLeaseResults[j][STAIRS_STAIR])) {
                    nUpdateIndex = j;
                    break;
                }
            }
            String[] strInsertRecord = new String[STAIRS_RECORD_COUNT];
            for (int k = 0; k < _strLeaseResults[nUpdateIndex].length; k++) {
                strInsertRecord[k] = _strLeaseResults[nUpdateIndex][k];
            }
            strInsertRecord[STAIRS_STAIR] = strCopys[i][2];
            strInsertRecord[STAIRS_BUKKEN_NO] = strCopys[i][3];
            strInsertRecord[STAIRS_BUKKEN_FR] = strCopys[i][3];
            strInsertRecord[STAIRS_BUKKEN_TO] = strCopys[i][4];
            insertRecord(strInsertRecord);
            //refresh array
            String strChangeTmp = strInsertRecord[STAIRS_REC_NO];
            strInsertRecord[STAIRS_REC_NO] = strInsertRecord[STAIRS_BUKKEN_NO];
            strInsertRecord[STAIRS_BUKKEN_NO] = strChangeTmp;
            //Attention:RecNo and BukkenNo had changed!!!
            //Because XML file's order had changed!!!
            _stairsXmlReader.insertRow(strInsertRecord);
            getQueryResults(strInsertRecord[STAIRS_REC_NO]);

            /*
            System.arraycopy(strTmpArr[nUpdateIndex], 0, strTmpArr[_strLeaseResults.length + i], 0, strTmpArr[nUpdateIndex].length);
            strTmpArr[_strLeaseResults.length + i][STAIRS_BUKKEN_NO] = strCopys[i][3];
            strTmpArr[_strLeaseResults.length + i][STAIRS_STAIR] = strCopys[i][2];
            strTmpArr[_strLeaseResults.length + i][STAIRS_BUKKEN_FR] = strCopys[i][3];
            strTmpArr[_strLeaseResults.length + i][STAIRS_BUKKEN_TO] = strCopys[i][4];
             */
        }
        _strLeaseResults = strTmpArr;
        return true;
    }

    public boolean CreateXml() {
        _strBuffer.append(
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
        _strBuffer.append(
                "<STAIRS xmlns=\"http://www.gecl.co.jp/STAIRS\">");
        _strBuffer.append("</STAIRS>");
        doCommit();
        return true;
    }

    //pzk add 20051109 s
    public boolean createPreviousXml() {
        //ydy add 20080414 s
        _strPreviousBuffer = new StringBuffer();
        //ydy add 20080414 e
        _strPreviousBuffer.append(
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
        _strPreviousBuffer.append(
                "<STAIRS xmlns=\"http://www.gecl.co.jp/STAIRS\">");
        _strPreviousBuffer.append("</STAIRS>");
        doPreviousCommit();
        return true;
    }
    //pzk add 20051109 e

    public void CreatePDFXml() {
        String[][] strValues = _strLeaseResults;
        StringBuffer strOut = new StringBuffer();
        strOut.append(
                "<?xml version=\"1.0\" encoding=\"Shift_JIS\" standalone=\"no\"?>");
        strOut.append("<STAIRS xmlns=\"http://www.gecl.co.jp/STAIRS\">");
        for (int i = 0; i < strValues.length; i++) {
            strOut.append("<ROW BUKKEN_NO=\"");
            strOut.append(strValues[i][STAIRS_BUKKEN_NO]);
            strOut.append("\" REC_NO=\"");
            strOut.append(strValues[i][STAIRS_REC_NO]);
            strOut.append("\" STAIR=\"");
            strOut.append(strValues[i][STAIRS_STAIR]);
            strOut.append("\">");
            strOut.append("<BUKKEN_FR>" + strValues[i][STAIRS_BUKKEN_FR] + "</BUKKEN_FR>");
            strOut.append("<BUKKEN_TO>" + strValues[i][STAIRS_BUKKEN_TO] + "</BUKKEN_TO>");

            //20050912 ZJ start
            strOut.append("<INCOME>" + strValues[i][STAIRS_INCOME] + "</INCOME>");
            strOut.append("<CYCLE>" + strValues[i][STAIRS_CYCLE] + "</CYCLE>");
            strOut.append("<FREQUE>" + strValues[i][STAIRS_FREQUE] + "</FREQUE>");
            //20050912 ZJ end

            strOut.append("<DATE_YY>" + strValues[i][STAIRS_DATE_YY] + "</DATE_YY>");
            strOut.append("<DATE_MM >" + strValues[i][STAIRS_DATE_MM] + "</DATE_MM >");
            strOut.append("<DATE_DD>" + strValues[i][STAIRS_DATE_DD] + "</DATE_DD>");

            //20051207 zj s
            strOut.append(
                    "<RESERVE_C_01>" + strValues[i][STAIRS_RESERVE_C_01] + "</RESERVE_C_01>");
            strOut.append(
                    "<RESERVE_C_02>" + strValues[i][STAIRS_RESERVE_C_02] + "</RESERVE_C_02>");
            strOut.append(
                    "<RESERVE_C_03>" + strValues[i][STAIRS_RESERVE_C_03] + "</RESERVE_C_03>");
            strOut.append(
                    "<RESERVE_C_04>" + strValues[i][STAIRS_RESERVE_C_04] + "</RESERVE_C_04>");
            strOut.append(
                    "<RESERVE_C_05>" + strValues[i][STAIRS_RESERVE_C_05] + "</RESERVE_C_05>");
            strOut.append(
                    "<RESERVE_C_06>" + strValues[i][STAIRS_RESERVE_C_06] + "</RESERVE_C_06>");
            strOut.append(
                    "<RESERVE_C_07>" + strValues[i][STAIRS_RESERVE_C_07] + "</RESERVE_C_07>");
            strOut.append(
                    "<RESERVE_C_08>" + strValues[i][STAIRS_RESERVE_C_08] + "</RESERVE_C_08>");
            strOut.append(
                    "<RESERVE_C_09>" + strValues[i][STAIRS_RESERVE_C_09] + "</RESERVE_C_09>");
            strOut.append(
                    "<RESERVE_C_10>" + strValues[i][STAIRS_RESERVE_C_10] + "</RESERVE_C_10>");
            strOut.append(
                    "<RESERVE_C_11>" + strValues[i][STAIRS_RESERVE_C_11] + "</RESERVE_C_11>");
            strOut.append(
                    "<RESERVE_C_12>" + strValues[i][STAIRS_RESERVE_C_12] + "</RESERVE_C_12>");
            strOut.append(
                    "<RESERVE_C_13>" + strValues[i][STAIRS_RESERVE_C_13] + "</RESERVE_C_13>");
            strOut.append(
                    "<RESERVE_C_14>" + strValues[i][STAIRS_RESERVE_C_14] + "</RESERVE_C_14>");
            strOut.append(
                    "<RESERVE_C_15>" + strValues[i][STAIRS_RESERVE_C_15] + "</RESERVE_C_15>");
            strOut.append(
                    "<RESERVE_C_16>" + strValues[i][STAIRS_RESERVE_C_16] + "</RESERVE_C_16>");
            strOut.append(
                    "<RESERVE_C_17>" + strValues[i][STAIRS_RESERVE_C_17] + "</RESERVE_C_17>");
            strOut.append(
                    "<RESERVE_C_18>" + strValues[i][STAIRS_RESERVE_C_18] + "</RESERVE_C_18>");
            strOut.append(
                    "<RESERVE_C_19>" + strValues[i][STAIRS_RESERVE_C_19] + "</RESERVE_C_19>");
            strOut.append(
                    "<RESERVE_C_20>" + strValues[i][STAIRS_RESERVE_C_20] + "</RESERVE_C_20>");
            strOut.append(
                    "<RESERVE_C_21>" + strValues[i][STAIRS_RESERVE_C_21] + "</RESERVE_C_21>");
            strOut.append(
                    "<RESERVE_C_22>" + strValues[i][STAIRS_RESERVE_C_22] + "</RESERVE_C_22>");
            strOut.append(
                    "<RESERVE_C_23>" + strValues[i][STAIRS_RESERVE_C_23] + "</RESERVE_C_23>");
            strOut.append(
                    "<RESERVE_C_24>" + strValues[i][STAIRS_RESERVE_C_24] + "</RESERVE_C_24>");
            strOut.append(
                    "<RESERVE_C_25>" + strValues[i][STAIRS_RESERVE_C_25] + "</RESERVE_C_25>");
            strOut.append(
                    "<RESERVE_C_26>" + strValues[i][STAIRS_RESERVE_C_26] + "</RESERVE_C_26>");
            strOut.append(
                    "<RESERVE_C_27>" + strValues[i][STAIRS_RESERVE_C_27] + "</RESERVE_C_27>");
            strOut.append(
                    "<RESERVE_C_28>" + strValues[i][STAIRS_RESERVE_C_28] + "</RESERVE_C_28>");
            strOut.append(
                    "<RESERVE_C_29>" + strValues[i][STAIRS_RESERVE_C_29] + "</RESERVE_C_29>");
            strOut.append(
                    "<RESERVE_C_30>" + strValues[i][STAIRS_RESERVE_C_30] + "</RESERVE_C_30>");

            strOut.append(
                    "<RESERVE_N_01>" + strValues[i][STAIRS_RESERVE_N_01] + "</RESERVE_N_01>");
            strOut.append(
                    "<RESERVE_N_02>" + strValues[i][STAIRS_RESERVE_N_02] + "</RESERVE_N_02>");
            strOut.append(
                    "<RESERVE_N_03>" + strValues[i][STAIRS_RESERVE_N_03] + "</RESERVE_N_03>");
            strOut.append(
                    "<RESERVE_N_04>" + strValues[i][STAIRS_RESERVE_N_04] + "</RESERVE_N_04>");
            strOut.append(
                    "<RESERVE_N_05>" + strValues[i][STAIRS_RESERVE_N_05] + "</RESERVE_N_05>");
            strOut.append(
                    "<RESERVE_N_06>" + strValues[i][STAIRS_RESERVE_N_06] + "</RESERVE_N_06>");
            strOut.append(
                    "<RESERVE_N_07>" + strValues[i][STAIRS_RESERVE_N_07] + "</RESERVE_N_07>");
            strOut.append(
                    "<RESERVE_N_08>" + strValues[i][STAIRS_RESERVE_N_08] + "</RESERVE_N_08>");
            strOut.append(
                    "<RESERVE_N_09>" + strValues[i][STAIRS_RESERVE_N_09] + "</RESERVE_N_09>");
            strOut.append(
                    "<RESERVE_N_10>" + strValues[i][STAIRS_RESERVE_N_10] + "</RESERVE_N_10>");
            strOut.append(
                    "<RESERVE_N_11>" + strValues[i][STAIRS_RESERVE_N_11] + "</RESERVE_N_11>");
            strOut.append(
                    "<RESERVE_N_12>" + strValues[i][STAIRS_RESERVE_N_12] + "</RESERVE_N_12>");
            strOut.append(
                    "<RESERVE_N_13>" + strValues[i][STAIRS_RESERVE_N_13] + "</RESERVE_N_13>");
            strOut.append(
                    "<RESERVE_N_14>" + strValues[i][STAIRS_RESERVE_N_14] + "</RESERVE_N_14>");
            strOut.append(
                    "<RESERVE_N_15>" + strValues[i][STAIRS_RESERVE_N_15] + "</RESERVE_N_15>");
            strOut.append(
                    "<RESERVE_N_16>" + strValues[i][STAIRS_RESERVE_N_16] + "</RESERVE_N_16>");
            strOut.append(
                    "<RESERVE_N_17>" + strValues[i][STAIRS_RESERVE_N_17] + "</RESERVE_N_17>");
            strOut.append(
                    "<RESERVE_N_18>" + strValues[i][STAIRS_RESERVE_N_18] + "</RESERVE_N_18>");
            strOut.append(
                    "<RESERVE_N_19>" + strValues[i][STAIRS_RESERVE_N_19] + "</RESERVE_N_19>");
            strOut.append(
                    "<RESERVE_N_20>" + strValues[i][STAIRS_RESERVE_N_20] + "</RESERVE_N_20>");
            strOut.append(
                    "<RESERVE_N_21>" + strValues[i][STAIRS_RESERVE_N_21] + "</RESERVE_N_21>");
            strOut.append(
                    "<RESERVE_N_22>" + strValues[i][STAIRS_RESERVE_N_22] + "</RESERVE_N_22>");
            strOut.append(
                    "<RESERVE_N_23>" + strValues[i][STAIRS_RESERVE_N_23] + "</RESERVE_N_23>");
            strOut.append(
                    "<RESERVE_N_24>" + strValues[i][STAIRS_RESERVE_N_24] + "</RESERVE_N_24>");
            strOut.append(
                    "<RESERVE_N_25>" + strValues[i][STAIRS_RESERVE_N_25] + "</RESERVE_N_25>");
            strOut.append(
                    "<RESERVE_N_26>" + strValues[i][STAIRS_RESERVE_N_26] + "</RESERVE_N_26>");
            strOut.append(
                    "<RESERVE_N_27>" + strValues[i][STAIRS_RESERVE_N_27] + "</RESERVE_N_27>");
            strOut.append(
                    "<RESERVE_N_28>" + strValues[i][STAIRS_RESERVE_N_28] + "</RESERVE_N_28>");
            strOut.append(
                    "<RESERVE_N_29>" + strValues[i][STAIRS_RESERVE_N_29] + "</RESERVE_N_29>");
            strOut.append(
                    "<RESERVE_N_30>" + strValues[i][STAIRS_RESERVE_N_30] + "</RESERVE_N_30>");
            //20051207 zj e

            strOut.append("</ROW>");
        }
        strOut.append("</STAIRS>");
        try {
            FileWriter fw =
                    new FileWriter(LfcDBConfig.getXmlTempFolder() + "TPDFSTAIRS.xml");
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(strOut.toString());
            pw.close();
        } catch (IOException e) {
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("StairsBean.CreatePDFXml()", //クラス名
                    strOut.toString(), //メソッド名
                    LfcDBConfig.getXmlTempFolder() + "TPDFSTAIRS.xmlへ書き出すときエラー", //ロジックメッセージ
                    e);                                      //システムエラーメッセージ
        }

        return;
    }

    public void setFieldName() {
        String[] tmpStrName = {
            "BUKKEN_NO",
            "REC_NO",
            "STAIR",
            "BUKKEN_FR",
            "BUKKEN_TO",
            "INCOME",
            "CYCLE",
            "FREQUE",
            "DATE_YY",
            "DATE_MM",
            "DATE_DD" //20051207 zj s
            , "RESERVE_C_01", "RESERVE_C_02", "RESERVE_C_03", "RESERVE_C_04", "RESERVE_C_05", "RESERVE_C_06", "RESERVE_C_07", "RESERVE_C_08", "RESERVE_C_09", "RESERVE_C_10", "RESERVE_C_11", "RESERVE_C_12", "RESERVE_C_13", "RESERVE_C_14", "RESERVE_C_15", "RESERVE_C_16", "RESERVE_C_17", "RESERVE_C_18", "RESERVE_C_19", "RESERVE_C_20", "RESERVE_C_21", "RESERVE_C_22", "RESERVE_C_23", "RESERVE_C_24", "RESERVE_C_25", "RESERVE_C_26", "RESERVE_C_27", "RESERVE_C_28", "RESERVE_C_29", "RESERVE_C_30", "RESERVE_N_01", "RESERVE_N_02", "RESERVE_N_03", "RESERVE_N_04", "RESERVE_N_05", "RESERVE_N_06", "RESERVE_N_07", "RESERVE_N_08", "RESERVE_N_09", "RESERVE_N_10", "RESERVE_N_11", "RESERVE_N_12", "RESERVE_N_13", "RESERVE_N_14", "RESERVE_N_15", "RESERVE_N_16", "RESERVE_N_17", "RESERVE_N_18", "RESERVE_N_19", "RESERVE_N_20", "RESERVE_N_21", "RESERVE_N_22", "RESERVE_N_23", "RESERVE_N_24", "RESERVE_N_25", "RESERVE_N_26", "RESERVE_N_27", "RESERVE_N_28", "RESERVE_N_29", "RESERVE_N_30"
        //20051207 zj e
        };
        _stairsXmlReader.setFieldName(tmpStrName);
    }

    private void setPreviousFieldName() {
        String[] tmpStrName = {
            "BUKKEN_NO",
            "REC_NO",
            "STAIR",
            "BUKKEN_FR",
            "BUKKEN_TO",
            "INCOME",
            "CYCLE",
            "FREQUE",
            "DATE_YY",
            "DATE_MM",
            "DATE_DD" //20051207 zj s
            , "RESERVE_C_01", "RESERVE_C_02", "RESERVE_C_03", "RESERVE_C_04", "RESERVE_C_05", "RESERVE_C_06", "RESERVE_C_07", "RESERVE_C_08", "RESERVE_C_09", "RESERVE_C_10", "RESERVE_C_11", "RESERVE_C_12", "RESERVE_C_13", "RESERVE_C_14", "RESERVE_C_15", "RESERVE_C_16", "RESERVE_C_17", "RESERVE_C_18", "RESERVE_C_19", "RESERVE_C_20", "RESERVE_C_21", "RESERVE_C_22", "RESERVE_C_23", "RESERVE_C_24", "RESERVE_C_25", "RESERVE_C_26", "RESERVE_C_27", "RESERVE_C_28", "RESERVE_C_29", "RESERVE_C_30", "RESERVE_N_01", "RESERVE_N_02", "RESERVE_N_03", "RESERVE_N_04", "RESERVE_N_05", "RESERVE_N_06", "RESERVE_N_07", "RESERVE_N_08", "RESERVE_N_09", "RESERVE_N_10", "RESERVE_N_11", "RESERVE_N_12", "RESERVE_N_13", "RESERVE_N_14", "RESERVE_N_15", "RESERVE_N_16", "RESERVE_N_17", "RESERVE_N_18", "RESERVE_N_19", "RESERVE_N_20", "RESERVE_N_21", "RESERVE_N_22", "RESERVE_N_23", "RESERVE_N_24", "RESERVE_N_25", "RESERVE_N_26", "RESERVE_N_27", "RESERVE_N_28", "RESERVE_N_29", "RESERVE_N_30"
        //20051207 zj e
        };
        _previousStairsXmlReader.setFieldName(tmpStrName);
    }

    /**
     * String -> Long -> String メソッド．    <BR>
     *
     * @param   strValues  Stringタイプの値
     * @return  String     null,""の場合、""
     *                      その他の場合、String -> Long -> String
     */
    private String spaceTo0(String strValues) {
        if (strValues == null || "".equals(strValues.trim())) {
            return "";
        }
        return "" + new Long(strValues);
    }
}
