/*
 * ファイル名：   LfcDBMsgConst.java
 *
 * 修正履歴：
 *            ver.1.00    2003.03.28  王嵩
 *                作成
 *
 *     GECL Copyright(C) 2003
 */
package com.gecl.leaseCal.db.comm;

/**
 *
 * クラス名：Lfcのメッセージ定数
 *
 * 概要：LFC使用するメッセージ定数を定義
 */
public interface LfcDBMsgConst {

	//エラーメッセージ 共通
	public final static String ERA000 = "システムエラーが発生しました。サポートセンターまでご連絡下さい。";
	public final  static String ERA001 = "XMLファイルのロードが失敗しました。";

//	public static String ERA001 = "キー設定の順序はエラーでした。";
	public final  static String ERA002 = "キー値はユニークではないので、INSERTは失敗しました。";
	public final  static String ERA003 = "更新配列に設定する項目より単一のレコードを更新時、エラーが出ました。";
	public final  static String ERA004 = "複数レコードの更新時、エラーが出ました。";
	public final  static String ERA005 = "解析されるXMLDOCを作成失敗しました。";
	public final  static String ERA006 = "XPATH文によりID結果集を取得失敗しました。";
	public final  static String ERA007 = "ID結果集により対応するINDEX配列を取得失敗しました。";
	public final  static String ERA008 = "XPATH文により結果集を取得失敗しました。";
	public final  static String ERA009 = "検索ID集により結果集を取得失敗しました。";
	public final  static String ERA010 = "XPATH文により結果集を取得失敗しました。(表示出力配列の項目だけ取得する)";
	public final  static String ERA011 = "検索ID集により結果集を取得失敗しました。";
	public final  static String ERA012 = "複数のレコードをINSERT時、エラー出しました。";
	public final  static String ERA013 = "単一のレコードをINSERT時、エラー出しました。";
	public final  static String ERA014 = "XPATH文により複数のレコードを削除時、エラー出しました。";
	public final  static String ERA015 = "ID集により複数のレコードを削除時、エラー出しました。";
	public final  static String ERA016 = "IDにより単一のレコードを削除時、エラー出しました。";
	public final  static String ERA017 = "XMLファイルを作成失敗しました。";
	public final  static String ERA018 = "が存在しません。";
	public final  static String ERA019 = "指定フォルダにLFCDBCONF.txtが存在しません。";
	public final  static String ERA020 = "LFCDBCONF.txtを読む時、エラーでした。";

}
