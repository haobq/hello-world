/*
 * ファイル名：LfcDBConfig.java
 *
 * 修正履歴  ：
 *             ver1.0.0     2003/03/27      王嵩
 *                          作成
 *             Copyright (c) 2003
 */
package com.gecl.leaseCal.db.comm;

import java.util.Properties;
import java.io.FileInputStream;
import com.gecl.leaseCal.log.LfcSystemLog;
import java.util.ResourceBundle;

/**
 *
 * クラス名：LfcDBConfig
 *
 * 概要：XMLDBパスを読み込むクラス
 */
public class LfcDBConfig {

    /** filepropertyのオブジェクト */
    private static Properties proFile = new Properties();
    /** CNTRCT.XMLのPATHを格納する変数 */
    private static String strCntrctXmlPath;
//pzk 2004/11/24
    /** CREINS.XMLのPATHを格納する変数 */
    //private static String strCreinsXmlPath;
//pzk 2004/11/24
    /** DOSOINST.XMLのPATHを格納する変数 */
    private static String strDosoinstXmlPath;
    /** OBJECT.XMLのPATHを格納する変数 */
    private static String strObjectXmlPath;
    /** PAYDIV.XMLのPATHを格納する変数 */
    private static String strPaydivXmlPath;
    /** STAIRS.XMLのPATHを格納する変数 */
    private static String strStairsXmlPath;
    /** ZANKA.XMLのPATHを格納する変数 */
    private static String strZankaXmlPath;
    /** ECNTRCT.XMLのPATHを格納する変数 */
    private static String strEcntrctXmlPath;
    /** EOBJECT.XMLのPATHを格納する変数 */
    private static String strEObjectXmlPath;
    /** EPROFIT.XMLのPATHを格納する変数 */
    private static String strEProfitXmlPath;
    /** ESTAIRS.XMLのPATHを格納する変数 */
    private static String strEPaydivXmlPath;
    /** ESTAIRS.XMLのPATHを格納する変数 */
    private static String strEStairsXmlPath;
    /** EPERSON.XMLのPATHを格納する変数 */
    private static String strEPersonXmlPath;
    /** EPERSON.XMLのPATHを格納する変数 */
    private static String strTmpobjXmlPath;
    /** EPERSON.XMLのPATHを格納する変数 */
    private static String strTmprecXmlPath;
    /** Tmpbukkenno.XMLのPATHを格納する変数 */
    private static String strTmpbukkennoXmlPath;
    /** TMPPAGEINFO1.XMLのPATHを格納する変数 */
    private static String strTmppageinfo1XmlPath;
    /** TMPPAGEINFO2.XMLのPATHを格納する変数 */
    private static String strTmppageinfo2XmlPath;
    /** TMPPAGEINFO3.XMLのPATHを格納する変数 */
    private static String strTmppageinfo3XmlPath;
    /** CNTRCT.XSDのPATHを格納する変数 */
    private static String strCntrctXsdPath;
    /** CREINS.XSDのPATHを格納する変数 */
    private static String strCreinsXsdPath;
    /** DOSOINST.XSDのPATHを格納する変数 */
    private static String strDosoinstXsdPath;
    /** OBJECT.XSDのPATHを格納する変数 */
    private static String strObjectXsdPath;
    /** PAYDIV.XSDのPATHを格納する変数 */
    private static String strPaydivXsdPath;
    /** STAIRS.XSDのPATHを格納する変数 */
    private static String strStairsXsdPath;
    /** ZANKA.XSDのPATHを格納する変数 */
    private static String strZankaXsdPath;
    /** ECNTRCT.XSDのPATHを格納する変数 */
    private static String strEcntrctXsdPath;
    /** EOBJECT.XSDのPATHを格納する変数 */
    private static String strEObjectXsdPath;
    /** EPROFIT.XSDのPATHを格納する変数 */
    private static String strEProfitXsdPath;
    /** EPAYDIV.XSDのPATHを格納する変数 */
    private static String strEPaydivXsdPath;
    /** ESTAIRS.XSDのPATHを格納する変数 */
    private static String strEStairsXsdPath;
    /** EPERSON.XSDのPATHを格納する変数 */
    private static String strEPersonXsdPath;
    /** Tmpbukkenno.XSDのPATHを格納する変数 */
    private static String strTmpbukkennoXsdPath;
    /** TMPPAGEINFO1.XSDのPATHを格納する変数 */
    private static String strTmppageinfo1XsdPath;
    /** TMPPAGEINFO2.XSDのPATHを格納する変数 */
    private static String strTmppageinfo2XsdPath;
    /** TMPPAGEINFO3.XSDのPATHを格納する変数 */
    private static String strTmppageinfo3XsdPath;
    /**エラーメッセージを格納する変数を定義する */
    private String _strErrorMessage = "";
    /**ロゴフォルダを格納する変数を定義する */
    private static String strLogFolder = "";
    private static String strExeclOutFolder = "";
    private static String strMQHost = ""; 		//MQホスト
    private static String strMQPort = ""; 		//MQサービスPort
    private static String strMQDBName = ""; 	//MQサービス名
    private static String strUserName = ""; 	//ユーザー名
    private static String strPassWord = ""; 	//パスワード
    /**DBに書き出し失敗のファイル退避フォルダを格納する変数を定義する */
    private static String strXmlTempFolder = "";
    private static LfcDBConfig lfcDBConfig = null;

    private LfcDBConfig() {
        try {
            String path = getClass().getClassLoader().getResource("/").getPath();
            // プロパティファイルからキーと値のリストを読み込みます
            proFile.load(new FileInputStream(path + "LfcConst.properties"));
            setXmlPath();
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog =new LfcSystemLog();
            sysLog.writeLog("LfcDBConfig", //クラス名
                    "LfcDBConfig()", //メソッド名
                    LfcDBMsgConst.ERA020, //ロジックメッセージ
                    e);                  //システムエラーメッセージ
        }
    }

    public static LfcDBConfig getInstance() {
        if (lfcDBConfig == null) {
            lfcDBConfig = new LfcDBConfig();
            return lfcDBConfig;
        } else {
            return lfcDBConfig;
        }
    }

    public static void setXmlPath() {
        strCntrctXmlPath = proFile.getProperty("XML_CNTRCT_PATH");

        strDosoinstXmlPath = proFile.getProperty("XML_DOSOINST_PATH");
        strObjectXmlPath = proFile.getProperty("XML_OBJECT_PATH");
        strPaydivXmlPath = proFile.getProperty("XML_PAYDIV_PATH");
        strStairsXmlPath = proFile.getProperty("XML_STAIRS_PATH");
        strZankaXmlPath = proFile.getProperty("XML_ZANKA_PATH");
        strEcntrctXmlPath = proFile.getProperty("XML_ECNTRCT_PATH");
        strEObjectXmlPath = proFile.getProperty("XML_EOBJECT_PATH");
        strEProfitXmlPath = proFile.getProperty("XML_EPROFIT_PATH");
        strEPaydivXmlPath = proFile.getProperty("XML_EPAYDIV_PATH");
        strEStairsXmlPath = proFile.getProperty("XML_ESTAIRS_PATH");
        strEPersonXmlPath = proFile.getProperty("XML_EPERSON_PATH");
        strTmprecXmlPath = proFile.getProperty("XML_TMPREC_PATH");
        strTmpobjXmlPath = proFile.getProperty("XML_TMPOBJ_PATH");

        strTmpbukkennoXmlPath = proFile.getProperty("XML_TMPBUKKENNO_PATH");
        strTmppageinfo1XmlPath = proFile.getProperty("XML_TMPPAGEINFO1_PATH");
        strTmppageinfo2XmlPath = proFile.getProperty("XML_TMPPAGEINFO2_PATH");
        strTmppageinfo3XmlPath = proFile.getProperty("XML_TMPPAGEINFO3_PATH");

        strCntrctXsdPath = proFile.getProperty("XSD_CNTRCT_PATH");
        strCreinsXsdPath = proFile.getProperty("XSD_CREINS_PATH");
        strDosoinstXsdPath = proFile.getProperty("XSD_DOSOINST_PATH");
        strObjectXsdPath = proFile.getProperty("XSD_OBJECT_PATH");
        strPaydivXsdPath = proFile.getProperty("XSD_PAYDIV_PATH");
        strStairsXsdPath = proFile.getProperty("XSD_STAIRS_PATH");
        strZankaXsdPath = proFile.getProperty("XSD_ZANKA_PATH");
        strEcntrctXsdPath = proFile.getProperty("XSD_ECNTRCT_PATH");
        strEObjectXsdPath = proFile.getProperty("XSD_EOBJECT_PATH");
        strEProfitXsdPath = proFile.getProperty("XSD_EPROFIT_PATH");
        strEPaydivXsdPath = proFile.getProperty("XSD_EPAYDIV_PATH");
        strEStairsXsdPath = proFile.getProperty("XSD_ESTAIRS_PATH");
        strEPersonXsdPath = proFile.getProperty("XSD_EPERSON_PATH");

        strTmpbukkennoXsdPath = proFile.getProperty("XSD_TMPBUKKENNO_PATH");
        strTmppageinfo1XsdPath = proFile.getProperty("XSD_TMPPAGEINFO1_PATH");
        strTmppageinfo2XsdPath = proFile.getProperty("XSD_TMPPAGEINFO2_PATH");
        strTmppageinfo3XsdPath = proFile.getProperty("XSD_TMPPAGEINFO3_PATH");
        strLogFolder = proFile.getProperty("LOG_FOLDER");
        strXmlTempFolder = proFile.getProperty("XML_TEMP_FOLDER");
        strExeclOutFolder = proFile.getProperty("EXECL_OUTPUT_PATH");
        // MQ送信先ホストIPを取得します
        strMQHost = proFile.getProperty("MQHost");
        // MQ送信サービス名値を取得します
        strMQDBName = proFile.getProperty("MQDBName");
        // MQ送信サービスPort値を取得します
        strMQPort = proFile.getProperty("MQPort");
        // ユーザー名値を取得します
        strUserName = proFile.getProperty("UserName");
        // パスワード値を取得します
        strPassWord = proFile.getProperty("PassWord");

    }

    public static String getExeclOutFolderPath() {
        return strExeclOutFolder;
    }

    /**
     * MQホストIPを取得するメソッド
     * @return　MQホスト名
     */
    public static String getMQHost() {
        return strMQHost;
    }

    /**
     * MQ送信サービスを取得するメソッド
     * @return　MQ送信サービス名
     */
    public static String getMQDBName() {
        return strMQDBName;
    }

    /**
     * MQ送信のサービス Portを取得するメソッド
     * @return　MQ送信のサービス Port
     */
    public static String getMQPort() {
        return strMQPort;
    }

    /**
     * DBパースワードを取得するメソッド
     * @return　DBパースワード
     */
    public static String getPassWord() {
        return strPassWord;
    }

    /**
     * DBユーザー名を取得するメソッド
     * @return　DBユーザー名
     */
    public static String getUserName() {
        return strUserName;
    }

    public static String getCntrctXmlPath() {
        return strCntrctXmlPath;
    }

    public static String getXmlTempFolder() {
        return strXmlTempFolder;
    }

    public static String getLogFolder() {
        return strLogFolder;
    }
//  pzk 2004/11/24
//    public static String getCreinsXmlPath() {
//        return strCreinsXmlPath;
//    }
//  pzk 2004/11/24

    public static String getDosoinstXmlPath() {
        return strDosoinstXmlPath;
    }

    public static String getObjectXmlPath() {
        return strObjectXmlPath;
    }

    public static String getPaydivXmlPath() {
        return strPaydivXmlPath;
    }

    public static String getStairsXmlPath() {
        return strStairsXmlPath;
    }

    public static String getZankaXmlPath() {
        return strZankaXmlPath;
    }

    public static String getEcntrctXmlPath() {
        return strEcntrctXmlPath;
    }

    public static String getEObjectXmlPath() {
        return strEObjectXmlPath;
    }

    public static String getEProfitXmlPath() {
        return strEProfitXmlPath;
    }

    public static String getEPaydivXmlPath() {
        return strEPaydivXmlPath;
    }

    public static String getEStairsXmlPath() {
        return strEStairsXmlPath;
    }

    public static String getEPersonXmlPath() {
        return strEPersonXmlPath;
    }

    public static String getTmprecXmlPath() {
        return strTmprecXmlPath;
    }

    public static String getTmpobjXmlPath() {
        return strTmpobjXmlPath;
    }

    public static String getTmpbukkennoXmlPath() {
        return strTmpbukkennoXmlPath;
    }

    public static String getTmppageinfo1XmlPath() {
        return strTmppageinfo1XmlPath;
    }

    public static String getTmppageinfo2XmlPath() {
        return strTmppageinfo2XmlPath;
    }

    public static String getTmppageinfo3XmlPath() {
        return strTmppageinfo3XmlPath;
    }

    public static String getCntrctXsdPath() {
        return strCntrctXsdPath;
    }

    public static String getCreinsXsdPath() {
        return strCreinsXsdPath;
    }

    public static String getDosoinstXsdPath() {
        return strDosoinstXsdPath;
    }

    public static String getObjectXsdPath() {
        return strObjectXsdPath;
    }

    public static String getPaydivXsdPath() {
        return strPaydivXsdPath;
    }

    public static String getStairsXsdPath() {
        return strStairsXsdPath;
    }

    public static String getZankaXsdPath() {
        return strZankaXsdPath;
    }

    public static String getEcntrctXsdPath() {
        return strEcntrctXsdPath;
    }

    public static String getEObjectXsdPath() {
        return strEObjectXsdPath;
    }

    public static String getEProfitXsdPath() {
        return strEProfitXsdPath;
    }

    public static String getEPaydivXsdPath() {
        return strEPaydivXsdPath;
    }

    public static String getEStairsXsdPath() {
        return strEStairsXsdPath;
    }

    public static String getEPersonXsdPath() {
        return strEPersonXsdPath;
    }

    public static String getTmpbukkennoXsdPath() {
        return strTmpbukkennoXsdPath;
    }

    public static String getTmppageinfo1XsdPath() {
        return strTmppageinfo1XsdPath;
    }

    public static String getTmppageinfo2XsdPath() {
        return strTmppageinfo2XsdPath;
    }

    public static String getTmppageinfo3XsdPath() {
        return strTmppageinfo3XsdPath;
    }

    /**
     * エラーメッセージを取得．    <BR>
     *
     * @return   String    エラーメッセージ
     * @since              01-01
     */
    public String getErrorMessage() {
        return _strErrorMessage;
    }
}

