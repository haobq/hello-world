/*
 * ファイル名：LfcDBInterface.java
 *
 * 修正履歴  ：
 *	           ver1.0.0	    2003/03/27      王嵩
 *                          作成
 *             Copyright (c) 2003
 */
package com.gecl.leaseCal.db.comm;

import java.util.Vector;

/**
 *
 * クラス名：Lfcのインタフェース
 *
 * 概要：LFC使用するインタフェースを定義
 */
public interface LfcDBInterface {

    /** XMLファイルを作成するメソッド
     * @param vDatas
     * @return
     */
    public boolean CreateXml(Vector vDatas);

    /** 解析されるXMLDOCを作成するメソッド */
    public boolean parseXml();

    /** エラーメッセージを取得するメソッド */
    public String getErrorMessage();

    /** 検索されたID結果集を取得するメソッド */
    public Vector getIDs();

    /** 検索されたID結果集に対応するINDEX配列を取得するメソッド */
    public int[] getIDsIndexArray();

    /** 検索された結果集を取得するメソッド */
    public Vector getResults();

    /** XPATH文によりID結果集を取得するメソッド */
    public boolean getIDs(String strSql);

    /** ID結果集により対応するINDEX配列を取得するメソッド */
    public boolean getIDsIndexArray(Vector vIDs);

    /** XPATH文により結果集を取得するメソッド */
    public boolean getQueryResults(String strSql);

    /** XPATH文により結果集を取得するメソッド(表示出力配列の項目だけ取得する) */
    public boolean getQueryResults(String strSql, int[] nOutCol);

    /** ID集により結果集を取得するメソッド */
    public boolean getQueryResults(Vector vIDs);

    /** ID集により結果集を取得するメソッド(表示出力配列の項目だけ取得する) */
    public boolean getQueryResults(Vector vIDs, int[] nOutCol);

    /** 更新配列に設定する項目より単一のレコードを更新するメソッド */
    public boolean updateRecord(int[] nFiledNameArray, Vector vValues);

    /** 更新配列に設定する項目より複数のレコードを更新するメソッド */
    public boolean updateRecords(int[] nFiledNameArray, Vector vValues);

    /** 該当フィールド更新かどうかを判断するメソッド */
    public int updateFlag(int nIndex, int[] nFiledNameArray);

    /** INSERT配列に設定する項目より複数のレコードをINSERTするメソッド */
    public boolean insertRecords(int[] nFiledNameArray, Vector vValues);

    /** INSERT配列に設定する項目より単一のレコードをINSERTするメソッド */
    public boolean insertRecord(int[] nFiledNameArray, Vector vValues);

    /** XPATH文により複数のレコードを削除するメソッド */
    public boolean removeRecords(String strSql);

    /** ID集により複数のレコードを削除するメソッド */
    public boolean removeRecords(Vector vIDs);

    /** IDにより単一のレコードを削除するメソッド */
    public boolean removeRecord(Vector vIDs);
}
