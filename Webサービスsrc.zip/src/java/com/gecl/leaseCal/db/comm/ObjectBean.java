/*
 * @(#)ObjectBean.java      01-01  2003/04/08
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 * 修正者：林太慶
 * 修正日：20050131
 * 修正内容：物件削除ポタン。
 *
 * 修正者：曾健
 * 修正日：20051108
 * 修正内容：古いデータのバックアップと復元を処理します
 *
 * 修正者：曾健
 * 修正日：20051207
 * 修正内容：試算物件表に60フィールドを追加する
 *
 * 修正者：王嵩
 * 修正日：20060301
 * 修正内容：物件レコードがない時、ソートすれば、直接に戻るように「doSortResultArr()」を修正しました。
 *
 *
 * 修正者：Hao
 * 修正日：20070629
 * 修正内容：XMLファイルに書出す時のエラーLogを追加
 *
 */
package com.gecl.leaseCal.db.comm;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.gecl.leaseCal.log.LfcSystemLog;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;

/**
 * クラス名：DBのObjectの処理共通Bean． <BR>
 *
 * 機能：
 * <PRE>
 *  １．Objectのデータ検索
 *  ２．Objectのデータ更新（INSERT、UPDATE、DELETE）
 * </PRE>
 * @author     DHC-王嵩
 * @version    01-01
 * @see        OBJECTType
 * @see        LfcDBConst
 * @see        LfcDBInterface
 * @since      01-01
 */
public class ObjectBean implements LfcDBConst {

    private String _strErrorMessage = "";
    /** 画面表示している物件Noのインデックスを格納する変数を定義する */
    private int _nDisplayIndex;
    private boolean _fDelflg = false;
    /** エラー項目名前 */
    private String _strErrorItemName = "エラー項目名前 : ";
    /** エラー項目内容 */
    private String _strErrorItemValue = "エラー項目内容 : ";
    /** Object.xmlパス */
    private String _strXmlFilePath = "";
    //20051108 zj s
    private String _strPreviousXmlFilePath = "";
    StringBuffer _previousStrBuffer = new StringBuffer();
    XmlArrReader _previousObjectXmlReader = null;
    String[][] _strPreviousResults = null;
    //20051108 zj e
    /** Object.xsdパス */
    private String _strXsdFilePath = "";
    /** current rec no */
    private String _strCurRecNo = "";
    private StringBuffer _strBufIDIndex = new StringBuffer();
    DateFormat time = new SimpleDateFormat("HH:mm:ss");
    private ObjectBean _objectBean = null;
    private String[][] _strLeaseResults;
    private int _nRecBukenCount = 0;
    //20051108 zj s
    private String _strPreviousCurRecNo = "";
    private int _nPreviousRecBukenCount = 0;
    //20051108 zj e
    XmlArrReader _objectXmlReader = null;
    StringBuffer _strBuffer = new StringBuffer();

    public ObjectBean() {
        _strXmlFilePath = LfcDBConfig.getObjectXmlPath();
        _strXsdFilePath = LfcDBConfig.getObjectXsdPath();
        //parseXml();
        getInstance();
    }

    public ObjectBean getInstance() {
        return _objectBean;
    }

    /**
     * 解析されるXMLDOCを作成するメソッド．    <BR>
     *
     * param   strXmlUrl         XMLのURL
     * return  boolean    true ：XMLDOCの作成は成功
     *                     false：XMLDOCの作成は失敗
     * @since              01-01
     */
    public void parseXml() {
        File file = new File(_strXmlFilePath);
        if (file.exists()) {
        } else {
            CreateXml();
        }
        _objectXmlReader = new XmlArrReader(_strXmlFilePath, OBJECT_RECORD_COUNT - 1);
        _objectXmlReader.parse();
        getBufferString();
        /*
        long t1 = System.currentTimeMillis();
        getQueryResults("1");
        String[][] aa = new String[_strLeaseResults.length][OBJECT_RECORD_COUNT];
        String[][] bb = new String[_strLeaseResults.length][OBJECT_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, aa, 0, _strLeaseResults.length);
        System.arraycopy(_strLeaseResults, 0, bb, 0, _strLeaseResults.length);
        int kk = 0;
        for(int i = 201; i <= 300; i++) {
        for(int j = 0; j < aa.length; j++) {
        aa[j][OBJECT_REC_NO] = "" + i;
        aa[j][OBJECT_BUKKEN_NO] = aa[j][OBJECT_BUKKEN_FR];
        insertRecord(new int[0], aa[j]);
        kk++;
        }
        //System.arraycopy(bb, 0, aa, 0, bb.length);
        }
        doCommit();
        long t2 = System.currentTimeMillis();
         */
        //removeRecords("10032");
        //doCommit();

        return;
    }

    //20051108 zj s
    public void parsePreviousData() {
        if (_previousObjectXmlReader == null) {
            File file = new File(_strPreviousXmlFilePath);
            if (!file.exists()) {
                createPreviousXml();
            }
            _previousObjectXmlReader = new XmlArrReader(_strPreviousXmlFilePath, OBJECT_RECORD_COUNT - 1);
            _previousObjectXmlReader.parse();
            getPreviousBufferString();
        }
    }
    //20051108 zj e

    public void getBufferString() {
        try {
            _strBuffer = new StringBuffer();
            InputStream in = new FileInputStream(_strXmlFilePath);
            in = new BufferedInputStream(in);
            Reader r = new InputStreamReader(in);
            r = new BufferedReader(r, 1024);
            int c;
            while ((c = r.read()) != -1) {
                _strBuffer.append((char) c);
            }
            r.close();

        } catch (Exception ex) {
        }
    }

    //20051108 zj s
    public void getPreviousBufferString() {
        try {
            _previousStrBuffer = new StringBuffer();
            InputStream in = new FileInputStream(_strPreviousXmlFilePath);
            in = new BufferedInputStream(in);
            Reader r = new InputStreamReader(in);
            r = new BufferedReader(r, 1024);
            int c;
            while ((c = r.read()) != -1) {
                _previousStrBuffer.append((char) c);
            }
            r.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    //20051108 zj e

    /**
     * エラーメッセージを取得．    <BR>
     *
     * @return   String    エラーメッセージ
     * @since              01-01
     */
    public String getErrorMessage() {
        return _strErrorMessage;
    }

    /**
     * 検索結果集を取得．    <BR>
     *
     * @return    Vector   Paydivの検索結果集
     * @since              01-01
     */
    public String[][] getResultsForLease() {
        return _strLeaseResults;
    }

    public void setResultsForLease(String[][] strResultForLease) {
        _strLeaseResults = strResultForLease;
    }

    /**
     * sort結果集を取得．    <BR>
     *
     * @return    String[][]   Eobjectの検索結果集
     * @since              01-01
     */
    public String[][] getSortResults() {
        String[][] strSortResults = new String[_strLeaseResults.length][OBJECT_RECORD_COUNT];
        String[] strTmpArr = new String[OBJECT_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, strSortResults, 0, _strLeaseResults.length);
        for (int i = 0; i < strSortResults.length; i++) {
            for (int j = i + 1; j < strSortResults.length; j++) {
                if (LfcFrmComm.toInt(strSortResults[i][OBJECT_BUKKEN_NO]) > LfcFrmComm.toInt(strSortResults[j][OBJECT_BUKKEN_NO])) {
                    System.arraycopy(strSortResults[i], 0, strTmpArr, 0, strSortResults[i].length);
                    System.arraycopy(strSortResults[j], 0, strSortResults[i], 0, strSortResults[i].length);
                    System.arraycopy(strTmpArr, 0, strSortResults[j], 0, strSortResults[i].length);
                }
            }
        }
        return strSortResults;
    }

    public String[][] getQueryResultsForEstCopy(String strRecNo) {
        String[][] strResults = getQueryResults(strRecNo);
        if (strResults.length == 0) {
            return new String[0][0];
        }
        String[][] strEstResults = new String[_nRecBukenCount][OBJECT_RECORD_COUNT];
        for (int i = 0; i < _nRecBukenCount; i++) {
            System.arraycopy(strResults[i], 0, strEstResults[i], 0, OBJECT_RECORD_COUNT);
        }
        String[] strTmpArr = new String[OBJECT_RECORD_COUNT];
        for (int i = 0; i < strEstResults.length; i++) {
            for (int j = i + 1; j < strEstResults.length; j++) {
                if (LfcFrmComm.toInt(strEstResults[i][OBJECT_BUKKEN_NO]) > LfcFrmComm.toInt(strEstResults[j][OBJECT_BUKKEN_NO])) {
                    System.arraycopy(strEstResults[i], 0, strTmpArr, 0, strEstResults[i].length);
                    System.arraycopy(strEstResults[j], 0, strEstResults[i], 0, strEstResults[j].length);
                    System.arraycopy(strTmpArr, 0, strEstResults[j], 0, strTmpArr.length);
                }
            }
        }
        return strEstResults;
    }

    public String[][] getQueryResultsForLease(String strRecNo) {
        String[][] strResults = getQueryResults(strRecNo);
        if (strResults.length == 0) {
            return new String[0][0];
        }
        _strLeaseResults = new String[_nRecBukenCount][OBJECT_RECORD_COUNT];
        for (int i = 0; i < _nRecBukenCount; i++) {
            System.arraycopy(strResults[i], 0, _strLeaseResults[i], 0, OBJECT_RECORD_COUNT);
        }
        doSortResultArr();
        return _strLeaseResults;
    }

    public String[][] getQueryResults(String strRecNo) {
        String[] tmpStrName = _objectXmlReader.getFieldName();
        if (tmpStrName[0] == null) {
            setFieldName();
        }
        _strCurRecNo = strRecNo;
        String[][] strResults = new String[_objectXmlReader.getRowCount()][OBJECT_RECORD_COUNT];
        try {
            _nRecBukenCount = 0;
            for (int i = 0; i < strResults.length; i++) {
                boolean bContinueFlg = false;
                if (!strRecNo.equals(_objectXmlReader.getData(i, "REC_NO"))) {
                    continue;
                }
                for (int j = 0; j < strResults.length; j++) {
                    if (_objectXmlReader.getData(i, "BUKKEN_NO").equals(strResults[j][OBJECT_BUKKEN_NO]) &&
                            strRecNo.equals(_objectXmlReader.getData(i, "REC_NO"))) {
                        bContinueFlg = true;
                    }
                }
                if (bContinueFlg == true) {
                    continue;
                }
                strResults[_nRecBukenCount][OBJECT_REC_NO] = _objectXmlReader.getData(i, "REC_NO");
                strResults[_nRecBukenCount][OBJECT_BUKKEN_NO] = _objectXmlReader.getData(i, "BUKKEN_NO");
                strResults[_nRecBukenCount][OBJECT_BUKKEN_FR] = _objectXmlReader.getData(i, "BUKKEN_FR");
                strResults[_nRecBukenCount][OBJECT_BUKKEN_TO] = _objectXmlReader.getData(i, "BUKKEN_TO");
                strResults[_nRecBukenCount][OBJECT_DATE_KENSH] = _objectXmlReader.getData(i, "DATE_KENSH");
                strResults[_nRecBukenCount][OBJECT_PURCHASE] = _objectXmlReader.getData(i, "PURCHASE");
                strResults[_nRecBukenCount][OBJECT_QUANTITY] = _objectXmlReader.getData(i, "QUANTITY");
                strResults[_nRecBukenCount][OBJECT_SW_PAY] = _objectXmlReader.getData(i, "SW_PAY");
                strResults[_nRecBukenCount][OBJECT_DATE_PAYMT] = _objectXmlReader.getData(i, "DATE_PAYMT");
                strResults[_nRecBukenCount][OBJECT_REMAIN_VAL] = _objectXmlReader.getData(i, "REMAIN_VAL");
                strResults[_nRecBukenCount][OBJECT_REM_VAL_RT] = _objectXmlReader.getData(i, "REM_VAL_RT");
                strResults[_nRecBukenCount][OBJECT_DURABLE_Y] = _objectXmlReader.getData(i, "DURABLE_Y");
                strResults[_nRecBukenCount][OBJECT_LEASE_M] = _objectXmlReader.getData(i, "LEASE_M");
                strResults[_nRecBukenCount][OBJECT_RATE_JLC] = _objectXmlReader.getData(i, "RATE_JLC");
                strResults[_nRecBukenCount][OBJECT_RATE_C_ADJ] = _objectXmlReader.getData(i, "RATE_C_ADJ");
                strResults[_nRecBukenCount][OBJECT_RATE_E_ANI] = _objectXmlReader.getData(i, "RATE_E_ANI");
                strResults[_nRecBukenCount][OBJECT_RATE_E_A_O] = _objectXmlReader.getData(i, "RATE_E_A_O");
                strResults[_nRecBukenCount][OBJECT_RATE_E_A_S] = _objectXmlReader.getData(i, "RATE_E_A_S");
                strResults[_nRecBukenCount][OBJECT_RATE_LOSS] = _objectXmlReader.getData(i, "RATE_LOSS");
                strResults[_nRecBukenCount][OBJECT_CSTKISHUCD] = _objectXmlReader.getData(i, "CSTKISHUCD");
                strResults[_nRecBukenCount][OBJECT_CSTSELINFO] = _objectXmlReader.getData(i, "CSTSELINFO");
                strResults[_nRecBukenCount][OBJECT_RATE_FEE] = _objectXmlReader.getData(i, "RATE_FEE");
                strResults[_nRecBukenCount][OBJECT_RATE_FEE_N] = _objectXmlReader.getData(i, "RATE_FEE_N");
                strResults[_nRecBukenCount][OBJECT_RATE_FEE_R] = _objectXmlReader.getData(i, "RATE_FEE_R");
                strResults[_nRecBukenCount][OBJECT_DOSO_RATE] = _objectXmlReader.getData(i, "DOSO_RATE ");
                strResults[_nRecBukenCount][OBJECT_SW_SOFT] = _objectXmlReader.getData(i, "SW_SOFT");
                strResults[_nRecBukenCount][OBJECT_FIXASTTAX] = _objectXmlReader.getData(i, "FIXASTTAX");
                strResults[_nRecBukenCount][OBJECT_DOSO_INDEX] = _objectXmlReader.getData(i, "DOSO_INDEX ");
                strResults[_nRecBukenCount][OBJECT_DOSO_FEE] = _objectXmlReader.getData(i, "DOSO_FEE");
                strResults[_nRecBukenCount][OBJECT_SW_BAISEKI] = _objectXmlReader.getData(i, "SW_BAISEKI");
                strResults[_nRecBukenCount][OBJECT_DANSHIN_RT] = _objectXmlReader.getData(i, "DANSHIN_RT");
                strResults[_nRecBukenCount][OBJECT_MACHI_FEE] = _objectXmlReader.getData(i, "MACHI_FEE");
                strResults[_nRecBukenCount][OBJECT_FIRE_FEE] = _objectXmlReader.getData(i, "FIRE_FEE");
                strResults[_nRecBukenCount][OBJECT_ETC_FEE] = _objectXmlReader.getData(i, "ETC_FEE");
                strResults[_nRecBukenCount][OBJECT_ICHIJI_1] = _objectXmlReader.getData(i, "ICHIJI_1");
                strResults[_nRecBukenCount][OBJECT_ICHIJI_2] = _objectXmlReader.getData(i, "ICHIJI_2");
                strResults[_nRecBukenCount][OBJECT_ICHIJI_3] = _objectXmlReader.getData(i, "ICHIJI_3");
                strResults[_nRecBukenCount][OBJECT_KURINO_1] = _objectXmlReader.getData(i, "KURINO_1");
                strResults[_nRecBukenCount][OBJECT_KURINO_2] = _objectXmlReader.getData(i, "KURINO_2");
                strResults[_nRecBukenCount][OBJECT_HOSHURYO] = _objectXmlReader.getData(i, "HOSHURYO");
                strResults[_nRecBukenCount][OBJECT_ASSEN] = _objectXmlReader.getData(i, "ASSEN");
                strResults[_nRecBukenCount][OBJECT_KAPPU_INS] = _objectXmlReader.getData(i, "KAPPU_INS");
                strResults[_nRecBukenCount][OBJECT_DATE_INC_0] = _objectXmlReader.getData(i, "DATE_INC_0");
                strResults[_nRecBukenCount][OBJECT_INCOME_0] = _objectXmlReader.getData(i, "INCOME_0");
                strResults[_nRecBukenCount][OBJECT_INC_0_M] = _objectXmlReader.getData(i, "INC_0_M");
                strResults[_nRecBukenCount][OBJECT_LEASE_D] = _objectXmlReader.getData(i, "LEASE_D");
                strResults[_nRecBukenCount][OBJECT_EVEN_FLG] = _objectXmlReader.getData(i, "EVEN_FLG");
                strResults[_nRecBukenCount][OBJECT_RYORITSU_T] = _objectXmlReader.getData(i, "RYORITSU_T");
                strResults[_nRecBukenCount][OBJECT_RYORITSU_M] = _objectXmlReader.getData(i, "RYORITSU_M");
                strResults[_nRecBukenCount][OBJECT_RATE_UNYO] = _objectXmlReader.getData(i, "RATE_UNYO");
                strResults[_nRecBukenCount][OBJECT_TRUE_RATE] = _objectXmlReader.getData(i, "TRUE_RATE");
                strResults[_nRecBukenCount][OBJECT_RATE_ROI] = _objectXmlReader.getData(i, "RATE_ROI");
                strResults[_nRecBukenCount][OBJECT_INTEREST_P] = _objectXmlReader.getData(i, "INTEREST_P");
                strResults[_nRecBukenCount][OBJECT_INTEREST_I] = _objectXmlReader.getData(i, "INTEREST_I");
                strResults[_nRecBukenCount][OBJECT_ZAPI] = _objectXmlReader.getData(i, "ZAPI");
                strResults[_nRecBukenCount][OBJECT_INSURANCE] = _objectXmlReader.getData(i, "INSURANCE");
                strResults[_nRecBukenCount][OBJECT_COST_TOTAL] = _objectXmlReader.getData(i, "COST_TOTAL");
                strResults[_nRecBukenCount][OBJECT_CHARGE] = _objectXmlReader.getData(i, "CHARGE");
                strResults[_nRecBukenCount][OBJECT_INCOME_GT] = _objectXmlReader.getData(i, "INCOME_GT");
                strResults[_nRecBukenCount][OBJECT_C_ADJUST] = _objectXmlReader.getData(i, "C_ADJUST");
                strResults[_nRecBukenCount][OBJECT_PROFIT_T] = _objectXmlReader.getData(i, "PROFIT_T");
                strResults[_nRecBukenCount][OBJECT_PROFIT_Y] = _objectXmlReader.getData(i, "PROFIT_Y");
                strResults[_nRecBukenCount][OBJECT_CAPITAL_T] = _objectXmlReader.getData(i, "CAPITAL_T");
                strResults[_nRecBukenCount][OBJECT_RAT_PRO_T] = _objectXmlReader.getData(i, "RAT_PRO_T");
                strResults[_nRecBukenCount][OBJECT_RAT_PRO_Y] = _objectXmlReader.getData(i, "RAT_PRO_Y");
                strResults[_nRecBukenCount][OBJECT_RATE_YEAR] = _objectXmlReader.getData(i, "RATE_YEAR");
                strResults[_nRecBukenCount][OBJECT_ADJUST_M] = _objectXmlReader.getData(i, "ADJUST_M");
                strResults[_nRecBukenCount][OBJECT_ADJUST_D] = _objectXmlReader.getData(i, "ADJUST_D");
                strResults[_nRecBukenCount][OBJECT_INCOME_T] = _objectXmlReader.getData(i, "INCOME_T ");
                strResults[_nRecBukenCount][OBJECT_INIT_COST] = _objectXmlReader.getData(i, "INIT_COST");
                strResults[_nRecBukenCount][OBJECT_EXEC_COST] = _objectXmlReader.getData(i, "EXEC_COST");
                strResults[_nRecBukenCount][OBJECT_NET_RATE] = _objectXmlReader.getData(i, "NET_RATE ");
                strResults[_nRecBukenCount][OBJECT_FINANCE_MARGIN] = _objectXmlReader.getData(i, "FINANCE_MARGIN");
                strResults[_nRecBukenCount][OBJECT_RA_MARGIN] = _objectXmlReader.getData(i, "RA_MARGIN");
                strResults[_nRecBukenCount][OBJECT_PV_FINANCE_MARGIN] = _objectXmlReader.getData(i, "PV_FINANCE_MARGIN");
                strResults[_nRecBukenCount][OBJECT_RA_PV_MARGIN] = _objectXmlReader.getData(i, "RA_PV_MARGIN");
                strResults[_nRecBukenCount][OBJECT_LEAVE_M] = _objectXmlReader.getData(i, "LEAVE_M");
                strResults[_nRecBukenCount][OBJECT_BAIS_FEE] = _objectXmlReader.getData(i, "BAIS_FEE ");
                strResults[_nRecBukenCount][OBJECT_DAMAGE_BAS] = _objectXmlReader.getData(i, "DAMAGE_BAS ");
                strResults[_nRecBukenCount][OBJECT_DAMAGE_FM] = _objectXmlReader.getData(i, "DAMAGE_FM");
                strResults[_nRecBukenCount][OBJECT_DAMAGE_LM] = _objectXmlReader.getData(i, "DAMAGE_LM");
                strResults[_nRecBukenCount][OBJECT_DAMAGE_FA] = _objectXmlReader.getData(i, "DAMAGE_FA");
                strResults[_nRecBukenCount][OBJECT_DAMAGE_LA] = _objectXmlReader.getData(i, "DAMAGE_LA");
                strResults[_nRecBukenCount][OBJECT_F_INTER_P] = _objectXmlReader.getData(i, "F_INTER_P");
                strResults[_nRecBukenCount][OBJECT_F_INTER_I] = _objectXmlReader.getData(i, "F_INTER_I");
                strResults[_nRecBukenCount][OBJECT_F_CHARGE] = _objectXmlReader.getData(i, "F_CHARGE");
                strResults[_nRecBukenCount][OBJECT_F_EXEC_C] = _objectXmlReader.getData(i, "F_EXEC_C");
                strResults[_nRecBukenCount][OBJECT_F_KURI_1] = _objectXmlReader.getData(i, "F_KURI_1");
                strResults[_nRecBukenCount][OBJECT_F_INSUR] = _objectXmlReader.getData(i, "F_INSUR");
                strResults[_nRecBukenCount][OBJECT_F_COST_T] = _objectXmlReader.getData(i, "F_COST_T");
                strResults[_nRecBukenCount][OBJECT_F_PRO_T] = _objectXmlReader.getData(i, "F_PRO_T");
                strResults[_nRecBukenCount][OBJECT_F_PRO_Y] = _objectXmlReader.getData(i, "F_PRO_Y");
                strResults[_nRecBukenCount][OBJECT_F_CAPIT_T] = _objectXmlReader.getData(i, "F_CAPIT_T");
                strResults[_nRecBukenCount][OBJECT_F_TRUE_RT] = _objectXmlReader.getData(i, "F_TRUE_RT");
                strResults[_nRecBukenCount][OBJECT_F_RT_YR] = _objectXmlReader.getData(i, "F_RT_YR");
                strResults[_nRecBukenCount][OBJECT_F_RT_UN] = _objectXmlReader.getData(i, "F_RT_UN");
                strResults[_nRecBukenCount][OBJECT_F_RT_PRT] = _objectXmlReader.getData(i, "F_RT_PRT");
                strResults[_nRecBukenCount][OBJECT_F_RT_PRY] = _objectXmlReader.getData(i, "F_RT_PRY");
                strResults[_nRecBukenCount][OBJECT_F_RT_ROI] = _objectXmlReader.getData(i, "F_RT_ROI");
                strResults[_nRecBukenCount][OBJECT_F_FINANCE_MARGIN] = _objectXmlReader.getData(i, "F_FINANCE_MARGIN");
                strResults[_nRecBukenCount][OBJECT_F_RA_MARGIN] = _objectXmlReader.getData(i, "F_RA_MARGIN");
                strResults[_nRecBukenCount][OBJECT_F_PV_FINANCE_MARGIN] = _objectXmlReader.getData(i, "F_PV_FINANCE_MARGIN");
                strResults[_nRecBukenCount][OBJECT_F_RA_PV_MARGIN] = _objectXmlReader.getData(i, "F_RA_PV_MARGIN");
                strResults[_nRecBukenCount][OBJECT_CREDIT_INS] = _objectXmlReader.getData(i, "CREDIT_INS");
                strResults[_nRecBukenCount][OBJECT_SW_CRE_INS] = _objectXmlReader.getData(i, "SW_CRE_INS");
                strResults[_nRecBukenCount][OBJECT_CRE_INS_CD] = _objectXmlReader.getData(i, "CRE_INS_CD");
                strResults[_nRecBukenCount][OBJECT_CRE_INS_TM] = _objectXmlReader.getData(i, "CRE_INS_TM");
                strResults[_nRecBukenCount][OBJECT_CRE_INS_RT] = _objectXmlReader.getData(i, "CRE_INS_RT");
                strResults[_nRecBukenCount][OBJECT_SW_S_PRO] = _objectXmlReader.getData(i, "SW_S_PRO");
                strResults[_nRecBukenCount][OBJECT_RESERVE1] = _objectXmlReader.getData(i, "RESERVE1");
                strResults[_nRecBukenCount][OBJECT_PRODUCT] = _objectXmlReader.getData(i, "PRODUCT");
                strResults[_nRecBukenCount][OBJECT_LEVERAGE] = _objectXmlReader.getData(i, "LEVERAGE");
                strResults[_nRecBukenCount][OBJECT_ROE] = _objectXmlReader.getData(i, "ROE");
                strResults[_nRecBukenCount][OBJECT_FP_ROE] = _objectXmlReader.getData(i, "FP_ROE");
                strResults[_nRecBukenCount][OBJECT_PRODUCT_CD] = _objectXmlReader.getData(i, "PRODUCT_CD");
                strResults[_nRecBukenCount][OBJECT_ROW_INDEX] = "" + i;

                //20051207 zj s
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_01] = _objectXmlReader.getData(i, "RESERVE_C_01");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_02] = _objectXmlReader.getData(i, "RESERVE_C_02");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_03] = _objectXmlReader.getData(i, "RESERVE_C_03");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_04] = _objectXmlReader.getData(i, "RESERVE_C_04");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_05] = _objectXmlReader.getData(i, "RESERVE_C_05");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_06] = _objectXmlReader.getData(i, "RESERVE_C_06");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_07] = _objectXmlReader.getData(i, "RESERVE_C_07");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_08] = _objectXmlReader.getData(i, "RESERVE_C_08");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_09] = _objectXmlReader.getData(i, "RESERVE_C_09");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_10] = _objectXmlReader.getData(i, "RESERVE_C_10");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_11] = _objectXmlReader.getData(i, "RESERVE_C_11");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_12] = _objectXmlReader.getData(i, "RESERVE_C_12");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_13] = _objectXmlReader.getData(i, "RESERVE_C_13");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_14] = _objectXmlReader.getData(i, "RESERVE_C_14");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_15] = _objectXmlReader.getData(i, "RESERVE_C_15");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_16] = _objectXmlReader.getData(i, "RESERVE_C_16");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_17] = _objectXmlReader.getData(i, "RESERVE_C_17");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_18] = _objectXmlReader.getData(i, "RESERVE_C_18");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_19] = _objectXmlReader.getData(i, "RESERVE_C_19");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_20] = _objectXmlReader.getData(i, "RESERVE_C_20");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_21] = _objectXmlReader.getData(i, "RESERVE_C_21");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_22] = _objectXmlReader.getData(i, "RESERVE_C_22");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_23] = _objectXmlReader.getData(i, "RESERVE_C_23");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_24] = _objectXmlReader.getData(i, "RESERVE_C_24");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_25] = _objectXmlReader.getData(i, "RESERVE_C_25");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_26] = _objectXmlReader.getData(i, "RESERVE_C_26");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_27] = _objectXmlReader.getData(i, "RESERVE_C_27");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_28] = _objectXmlReader.getData(i, "RESERVE_C_28");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_29] = _objectXmlReader.getData(i, "RESERVE_C_29");
                strResults[_nRecBukenCount][OBJECT_RESERVE_C_30] = _objectXmlReader.getData(i, "RESERVE_C_30");

                strResults[_nRecBukenCount][OBJECT_RESERVE_N_01] = _objectXmlReader.getData(i, "RESERVE_N_01");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_02] = _objectXmlReader.getData(i, "RESERVE_N_02");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_03] = _objectXmlReader.getData(i, "RESERVE_N_03");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_04] = _objectXmlReader.getData(i, "RESERVE_N_04");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_05] = _objectXmlReader.getData(i, "RESERVE_N_05");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_06] = _objectXmlReader.getData(i, "RESERVE_N_06");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_07] = _objectXmlReader.getData(i, "RESERVE_N_07");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_08] = _objectXmlReader.getData(i, "RESERVE_N_08");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_09] = _objectXmlReader.getData(i, "RESERVE_N_09");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_10] = _objectXmlReader.getData(i, "RESERVE_N_10");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_11] = _objectXmlReader.getData(i, "RESERVE_N_11");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_12] = _objectXmlReader.getData(i, "RESERVE_N_12");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_13] = _objectXmlReader.getData(i, "RESERVE_N_13");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_14] = _objectXmlReader.getData(i, "RESERVE_N_14");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_15] = _objectXmlReader.getData(i, "RESERVE_N_15");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_16] = _objectXmlReader.getData(i, "RESERVE_N_16");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_17] = _objectXmlReader.getData(i, "RESERVE_N_17");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_18] = _objectXmlReader.getData(i, "RESERVE_N_18");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_19] = _objectXmlReader.getData(i, "RESERVE_N_19");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_20] = _objectXmlReader.getData(i, "RESERVE_N_20");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_21] = _objectXmlReader.getData(i, "RESERVE_N_21");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_22] = _objectXmlReader.getData(i, "RESERVE_N_22");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_23] = _objectXmlReader.getData(i, "RESERVE_N_23");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_24] = _objectXmlReader.getData(i, "RESERVE_N_24");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_25] = _objectXmlReader.getData(i, "RESERVE_N_25");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_26] = _objectXmlReader.getData(i, "RESERVE_N_26");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_27] = _objectXmlReader.getData(i, "RESERVE_N_27");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_28] = _objectXmlReader.getData(i, "RESERVE_N_28");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_29] = _objectXmlReader.getData(i, "RESERVE_N_29");
                strResults[_nRecBukenCount][OBJECT_RESERVE_N_30] = _objectXmlReader.getData(i, "RESERVE_N_30");
                //20051207 zj e

                _nRecBukenCount = _nRecBukenCount + 1;
            }
            String[][] strRetResults = new String[_nRecBukenCount][OBJECT_RECORD_COUNT];
            for (int i = 0; i < strRetResults.length; i++) {
                System.arraycopy(strResults[i], 0, strRetResults[i], 0, strResults[i].length);
            }
            _strLeaseResults = strRetResults;
            return strRetResults;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog = new LfcSystemLog();
            sysLog.writeLog("ObjectBean", //クラス名
                    "getQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return new String[0][0];
        }
    }

    //20051108 zj s
    public String[][] getPreviousQueryResults(String strRecNo) {
        String[] tmpStrName = _previousObjectXmlReader.getFieldName();
        if (tmpStrName[0] == null) {
            setPreviousFieldName();
        }
//        _strPreviousCurRecNo = strRecNo;
        String[][] strResults = new String[_previousObjectXmlReader.getRowCount()][OBJECT_RECORD_COUNT];
        try {
            _nPreviousRecBukenCount = 0;
            for (int i = 0; i < strResults.length; i++) {
                if (strRecNo.equals(_previousObjectXmlReader.getData(i, "REC_NO"))) {
                    strResults[_nPreviousRecBukenCount][OBJECT_REC_NO] = _previousObjectXmlReader.getData(i, "REC_NO");
                    strResults[_nPreviousRecBukenCount][OBJECT_BUKKEN_NO] = _previousObjectXmlReader.getData(i, "BUKKEN_NO");
                    strResults[_nPreviousRecBukenCount][OBJECT_BUKKEN_FR] = _previousObjectXmlReader.getData(i, "BUKKEN_FR");
                    strResults[_nPreviousRecBukenCount][OBJECT_BUKKEN_TO] = _previousObjectXmlReader.getData(i, "BUKKEN_TO");
                    strResults[_nPreviousRecBukenCount][OBJECT_DATE_KENSH] = _previousObjectXmlReader.getData(i, "DATE_KENSH");
                    strResults[_nPreviousRecBukenCount][OBJECT_PURCHASE] = _previousObjectXmlReader.getData(i, "PURCHASE");
                    strResults[_nPreviousRecBukenCount][OBJECT_QUANTITY] = _previousObjectXmlReader.getData(i, "QUANTITY");
                    strResults[_nPreviousRecBukenCount][OBJECT_SW_PAY] = _previousObjectXmlReader.getData(i, "SW_PAY");
                    strResults[_nPreviousRecBukenCount][OBJECT_DATE_PAYMT] = _previousObjectXmlReader.getData(i, "DATE_PAYMT");
                    strResults[_nPreviousRecBukenCount][OBJECT_REMAIN_VAL] = _previousObjectXmlReader.getData(i, "REMAIN_VAL");
                    strResults[_nPreviousRecBukenCount][OBJECT_REM_VAL_RT] = _previousObjectXmlReader.getData(i, "REM_VAL_RT");
                    strResults[_nPreviousRecBukenCount][OBJECT_DURABLE_Y] = _previousObjectXmlReader.getData(i, "DURABLE_Y");
                    strResults[_nPreviousRecBukenCount][OBJECT_LEASE_M] = _previousObjectXmlReader.getData(i, "LEASE_M");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_JLC] = _previousObjectXmlReader.getData(i, "RATE_JLC");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_C_ADJ] = _previousObjectXmlReader.getData(i, "RATE_C_ADJ");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_E_ANI] = _previousObjectXmlReader.getData(i, "RATE_E_ANI");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_E_A_O] = _previousObjectXmlReader.getData(i, "RATE_E_A_O");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_E_A_S] = _previousObjectXmlReader.getData(i, "RATE_E_A_S");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_LOSS] = _previousObjectXmlReader.getData(i, "RATE_LOSS");
                    strResults[_nPreviousRecBukenCount][OBJECT_CSTKISHUCD] = _previousObjectXmlReader.getData(i, "CSTKISHUCD");
                    strResults[_nPreviousRecBukenCount][OBJECT_CSTSELINFO] = _previousObjectXmlReader.getData(i, "CSTSELINFO");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_FEE] = _previousObjectXmlReader.getData(i, "RATE_FEE");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_FEE_N] = _previousObjectXmlReader.getData(i, "RATE_FEE_N");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_FEE_R] = _previousObjectXmlReader.getData(i, "RATE_FEE_R");
                    strResults[_nPreviousRecBukenCount][OBJECT_DOSO_RATE] = _previousObjectXmlReader.getData(i, "DOSO_RATE ");
                    strResults[_nPreviousRecBukenCount][OBJECT_SW_SOFT] = _previousObjectXmlReader.getData(i, "SW_SOFT");
                    strResults[_nPreviousRecBukenCount][OBJECT_FIXASTTAX] = _previousObjectXmlReader.getData(i, "FIXASTTAX");
                    strResults[_nPreviousRecBukenCount][OBJECT_DOSO_INDEX] = _previousObjectXmlReader.getData(i, "DOSO_INDEX ");
                    strResults[_nPreviousRecBukenCount][OBJECT_DOSO_FEE] = _previousObjectXmlReader.getData(i, "DOSO_FEE");
                    strResults[_nPreviousRecBukenCount][OBJECT_SW_BAISEKI] = _previousObjectXmlReader.getData(i, "SW_BAISEKI");
                    strResults[_nPreviousRecBukenCount][OBJECT_DANSHIN_RT] = _previousObjectXmlReader.getData(i, "DANSHIN_RT");
                    strResults[_nPreviousRecBukenCount][OBJECT_MACHI_FEE] = _previousObjectXmlReader.getData(i, "MACHI_FEE");
                    strResults[_nPreviousRecBukenCount][OBJECT_FIRE_FEE] = _previousObjectXmlReader.getData(i, "FIRE_FEE");
                    strResults[_nPreviousRecBukenCount][OBJECT_ETC_FEE] = _previousObjectXmlReader.getData(i, "ETC_FEE");
                    strResults[_nPreviousRecBukenCount][OBJECT_ICHIJI_1] = _previousObjectXmlReader.getData(i, "ICHIJI_1");
                    strResults[_nPreviousRecBukenCount][OBJECT_ICHIJI_2] = _previousObjectXmlReader.getData(i, "ICHIJI_2");
                    strResults[_nPreviousRecBukenCount][OBJECT_ICHIJI_3] = _previousObjectXmlReader.getData(i, "ICHIJI_3");
                    strResults[_nPreviousRecBukenCount][OBJECT_KURINO_1] = _previousObjectXmlReader.getData(i, "KURINO_1");
                    strResults[_nPreviousRecBukenCount][OBJECT_KURINO_2] = _previousObjectXmlReader.getData(i, "KURINO_2");
                    strResults[_nPreviousRecBukenCount][OBJECT_HOSHURYO] = _previousObjectXmlReader.getData(i, "HOSHURYO");
                    strResults[_nPreviousRecBukenCount][OBJECT_ASSEN] = _previousObjectXmlReader.getData(i, "ASSEN");
                    strResults[_nPreviousRecBukenCount][OBJECT_KAPPU_INS] = _previousObjectXmlReader.getData(i, "KAPPU_INS");
                    strResults[_nPreviousRecBukenCount][OBJECT_DATE_INC_0] = _previousObjectXmlReader.getData(i, "DATE_INC_0");
                    strResults[_nPreviousRecBukenCount][OBJECT_INCOME_0] = _previousObjectXmlReader.getData(i, "INCOME_0");
                    strResults[_nPreviousRecBukenCount][OBJECT_INC_0_M] = _previousObjectXmlReader.getData(i, "INC_0_M");
                    strResults[_nPreviousRecBukenCount][OBJECT_LEASE_D] = _previousObjectXmlReader.getData(i, "LEASE_D");
                    strResults[_nPreviousRecBukenCount][OBJECT_EVEN_FLG] = _previousObjectXmlReader.getData(i, "EVEN_FLG");
                    strResults[_nPreviousRecBukenCount][OBJECT_RYORITSU_T] = _previousObjectXmlReader.getData(i, "RYORITSU_T");
                    strResults[_nPreviousRecBukenCount][OBJECT_RYORITSU_M] = _previousObjectXmlReader.getData(i, "RYORITSU_M");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_UNYO] = _previousObjectXmlReader.getData(i, "RATE_UNYO");
                    strResults[_nPreviousRecBukenCount][OBJECT_TRUE_RATE] = _previousObjectXmlReader.getData(i, "TRUE_RATE");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_ROI] = _previousObjectXmlReader.getData(i, "RATE_ROI");
                    strResults[_nPreviousRecBukenCount][OBJECT_INTEREST_P] = _previousObjectXmlReader.getData(i, "INTEREST_P");
                    strResults[_nPreviousRecBukenCount][OBJECT_INTEREST_I] = _previousObjectXmlReader.getData(i, "INTEREST_I");
                    strResults[_nPreviousRecBukenCount][OBJECT_ZAPI] = _previousObjectXmlReader.getData(i, "ZAPI");
                    strResults[_nPreviousRecBukenCount][OBJECT_INSURANCE] = _previousObjectXmlReader.getData(i, "INSURANCE");
                    strResults[_nPreviousRecBukenCount][OBJECT_COST_TOTAL] = _previousObjectXmlReader.getData(i, "COST_TOTAL");
                    strResults[_nPreviousRecBukenCount][OBJECT_CHARGE] = _previousObjectXmlReader.getData(i, "CHARGE");
                    strResults[_nPreviousRecBukenCount][OBJECT_INCOME_GT] = _previousObjectXmlReader.getData(i, "INCOME_GT");
                    strResults[_nPreviousRecBukenCount][OBJECT_C_ADJUST] = _previousObjectXmlReader.getData(i, "C_ADJUST");
                    strResults[_nPreviousRecBukenCount][OBJECT_PROFIT_T] = _previousObjectXmlReader.getData(i, "PROFIT_T");
                    strResults[_nPreviousRecBukenCount][OBJECT_PROFIT_Y] = _previousObjectXmlReader.getData(i, "PROFIT_Y");
                    strResults[_nPreviousRecBukenCount][OBJECT_CAPITAL_T] = _previousObjectXmlReader.getData(i, "CAPITAL_T");
                    strResults[_nPreviousRecBukenCount][OBJECT_RAT_PRO_T] = _previousObjectXmlReader.getData(i, "RAT_PRO_T");
                    strResults[_nPreviousRecBukenCount][OBJECT_RAT_PRO_Y] = _previousObjectXmlReader.getData(i, "RAT_PRO_Y");
                    strResults[_nPreviousRecBukenCount][OBJECT_RATE_YEAR] = _previousObjectXmlReader.getData(i, "RATE_YEAR");
                    strResults[_nPreviousRecBukenCount][OBJECT_ADJUST_M] = _previousObjectXmlReader.getData(i, "ADJUST_M");
                    strResults[_nPreviousRecBukenCount][OBJECT_ADJUST_D] = _previousObjectXmlReader.getData(i, "ADJUST_D");
                    strResults[_nPreviousRecBukenCount][OBJECT_INCOME_T] = _previousObjectXmlReader.getData(i, "INCOME_T ");
                    strResults[_nPreviousRecBukenCount][OBJECT_INIT_COST] = _previousObjectXmlReader.getData(i, "INIT_COST");
                    strResults[_nPreviousRecBukenCount][OBJECT_EXEC_COST] = _previousObjectXmlReader.getData(i, "EXEC_COST");
                    strResults[_nPreviousRecBukenCount][OBJECT_NET_RATE] = _previousObjectXmlReader.getData(i, "NET_RATE ");
                    strResults[_nPreviousRecBukenCount][OBJECT_FINANCE_MARGIN] = _previousObjectXmlReader.getData(i, "FINANCE_MARGIN");
                    strResults[_nPreviousRecBukenCount][OBJECT_RA_MARGIN] = _previousObjectXmlReader.getData(i, "RA_MARGIN");
                    strResults[_nPreviousRecBukenCount][OBJECT_PV_FINANCE_MARGIN] = _previousObjectXmlReader.getData(i, "PV_FINANCE_MARGIN");
                    strResults[_nPreviousRecBukenCount][OBJECT_RA_PV_MARGIN] = _previousObjectXmlReader.getData(i, "RA_PV_MARGIN");
                    strResults[_nPreviousRecBukenCount][OBJECT_LEAVE_M] = _previousObjectXmlReader.getData(i, "LEAVE_M");
                    strResults[_nPreviousRecBukenCount][OBJECT_BAIS_FEE] = _previousObjectXmlReader.getData(i, "BAIS_FEE ");
                    strResults[_nPreviousRecBukenCount][OBJECT_DAMAGE_BAS] = _previousObjectXmlReader.getData(i, "DAMAGE_BAS ");
                    strResults[_nPreviousRecBukenCount][OBJECT_DAMAGE_FM] = _previousObjectXmlReader.getData(i, "DAMAGE_FM");
                    strResults[_nPreviousRecBukenCount][OBJECT_DAMAGE_LM] = _previousObjectXmlReader.getData(i, "DAMAGE_LM");
                    strResults[_nPreviousRecBukenCount][OBJECT_DAMAGE_FA] = _previousObjectXmlReader.getData(i, "DAMAGE_FA");
                    strResults[_nPreviousRecBukenCount][OBJECT_DAMAGE_LA] = _previousObjectXmlReader.getData(i, "DAMAGE_LA");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_INTER_P] = _previousObjectXmlReader.getData(i, "F_INTER_P");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_INTER_I] = _previousObjectXmlReader.getData(i, "F_INTER_I");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_CHARGE] = _previousObjectXmlReader.getData(i, "F_CHARGE");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_EXEC_C] = _previousObjectXmlReader.getData(i, "F_EXEC_C");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_KURI_1] = _previousObjectXmlReader.getData(i, "F_KURI_1");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_INSUR] = _previousObjectXmlReader.getData(i, "F_INSUR");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_COST_T] = _previousObjectXmlReader.getData(i, "F_COST_T");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_PRO_T] = _previousObjectXmlReader.getData(i, "F_PRO_T");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_PRO_Y] = _previousObjectXmlReader.getData(i, "F_PRO_Y");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_CAPIT_T] = _previousObjectXmlReader.getData(i, "F_CAPIT_T");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_TRUE_RT] = _previousObjectXmlReader.getData(i, "F_TRUE_RT");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_RT_YR] = _previousObjectXmlReader.getData(i, "F_RT_YR");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_RT_UN] = _previousObjectXmlReader.getData(i, "F_RT_UN");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_RT_PRT] = _previousObjectXmlReader.getData(i, "F_RT_PRT");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_RT_PRY] = _previousObjectXmlReader.getData(i, "F_RT_PRY");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_RT_ROI] = _previousObjectXmlReader.getData(i, "F_RT_ROI");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_FINANCE_MARGIN] = _previousObjectXmlReader.getData(i, "F_FINANCE_MARGIN");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_RA_MARGIN] = _previousObjectXmlReader.getData(i, "F_RA_MARGIN");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_PV_FINANCE_MARGIN] = _previousObjectXmlReader.getData(i, "F_PV_FINANCE_MARGIN");
                    strResults[_nPreviousRecBukenCount][OBJECT_F_RA_PV_MARGIN] = _previousObjectXmlReader.getData(i, "F_RA_PV_MARGIN");
                    strResults[_nPreviousRecBukenCount][OBJECT_CREDIT_INS] = _previousObjectXmlReader.getData(i, "CREDIT_INS");
                    strResults[_nPreviousRecBukenCount][OBJECT_SW_CRE_INS] = _previousObjectXmlReader.getData(i, "SW_CRE_INS");
                    strResults[_nPreviousRecBukenCount][OBJECT_CRE_INS_CD] = _previousObjectXmlReader.getData(i, "CRE_INS_CD");
                    strResults[_nPreviousRecBukenCount][OBJECT_CRE_INS_TM] = _previousObjectXmlReader.getData(i, "CRE_INS_TM");
                    strResults[_nPreviousRecBukenCount][OBJECT_CRE_INS_RT] = _previousObjectXmlReader.getData(i, "CRE_INS_RT");
                    strResults[_nPreviousRecBukenCount][OBJECT_SW_S_PRO] = _previousObjectXmlReader.getData(i, "SW_S_PRO");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE1] = _previousObjectXmlReader.getData(i, "RESERVE1");
                    strResults[_nPreviousRecBukenCount][OBJECT_PRODUCT] = _previousObjectXmlReader.getData(i, "PRODUCT");
                    strResults[_nPreviousRecBukenCount][OBJECT_LEVERAGE] = _previousObjectXmlReader.getData(i, "LEVERAGE");
                    strResults[_nPreviousRecBukenCount][OBJECT_ROE] = _previousObjectXmlReader.getData(i, "ROE");
                    strResults[_nPreviousRecBukenCount][OBJECT_FP_ROE] = _previousObjectXmlReader.getData(i, "FP_ROE");
                    strResults[_nPreviousRecBukenCount][OBJECT_PRODUCT_CD] = _previousObjectXmlReader.getData(i, "PRODUCT_CD");
                    strResults[_nPreviousRecBukenCount][OBJECT_ROW_INDEX] = "" + i;

                    //20051207 zj s
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_01] = _previousObjectXmlReader.getData(i, "RESERVE_C_01");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_02] = _previousObjectXmlReader.getData(i, "RESERVE_C_02");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_03] = _previousObjectXmlReader.getData(i, "RESERVE_C_03");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_04] = _previousObjectXmlReader.getData(i, "RESERVE_C_04");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_05] = _previousObjectXmlReader.getData(i, "RESERVE_C_05");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_06] = _previousObjectXmlReader.getData(i, "RESERVE_C_06");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_07] = _previousObjectXmlReader.getData(i, "RESERVE_C_07");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_08] = _previousObjectXmlReader.getData(i, "RESERVE_C_08");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_09] = _previousObjectXmlReader.getData(i, "RESERVE_C_09");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_10] = _previousObjectXmlReader.getData(i, "RESERVE_C_10");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_11] = _previousObjectXmlReader.getData(i, "RESERVE_C_11");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_12] = _previousObjectXmlReader.getData(i, "RESERVE_C_12");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_13] = _previousObjectXmlReader.getData(i, "RESERVE_C_13");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_14] = _previousObjectXmlReader.getData(i, "RESERVE_C_14");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_15] = _previousObjectXmlReader.getData(i, "RESERVE_C_15");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_16] = _previousObjectXmlReader.getData(i, "RESERVE_C_16");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_17] = _previousObjectXmlReader.getData(i, "RESERVE_C_17");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_18] = _previousObjectXmlReader.getData(i, "RESERVE_C_18");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_19] = _previousObjectXmlReader.getData(i, "RESERVE_C_19");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_20] = _previousObjectXmlReader.getData(i, "RESERVE_C_20");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_21] = _previousObjectXmlReader.getData(i, "RESERVE_C_21");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_22] = _previousObjectXmlReader.getData(i, "RESERVE_C_22");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_23] = _previousObjectXmlReader.getData(i, "RESERVE_C_23");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_24] = _previousObjectXmlReader.getData(i, "RESERVE_C_24");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_25] = _previousObjectXmlReader.getData(i, "RESERVE_C_25");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_26] = _previousObjectXmlReader.getData(i, "RESERVE_C_26");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_27] = _previousObjectXmlReader.getData(i, "RESERVE_C_27");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_28] = _previousObjectXmlReader.getData(i, "RESERVE_C_28");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_29] = _previousObjectXmlReader.getData(i, "RESERVE_C_29");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_C_30] = _previousObjectXmlReader.getData(i, "RESERVE_C_30");

                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_01] = _previousObjectXmlReader.getData(i, "RESERVE_N_01");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_02] = _previousObjectXmlReader.getData(i, "RESERVE_N_02");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_03] = _previousObjectXmlReader.getData(i, "RESERVE_N_03");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_04] = _previousObjectXmlReader.getData(i, "RESERVE_N_04");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_05] = _previousObjectXmlReader.getData(i, "RESERVE_N_05");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_06] = _previousObjectXmlReader.getData(i, "RESERVE_N_06");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_07] = _previousObjectXmlReader.getData(i, "RESERVE_N_07");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_08] = _previousObjectXmlReader.getData(i, "RESERVE_N_08");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_09] = _previousObjectXmlReader.getData(i, "RESERVE_N_09");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_10] = _previousObjectXmlReader.getData(i, "RESERVE_N_10");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_11] = _previousObjectXmlReader.getData(i, "RESERVE_N_11");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_12] = _previousObjectXmlReader.getData(i, "RESERVE_N_12");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_13] = _previousObjectXmlReader.getData(i, "RESERVE_N_13");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_14] = _previousObjectXmlReader.getData(i, "RESERVE_N_14");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_15] = _previousObjectXmlReader.getData(i, "RESERVE_N_15");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_16] = _previousObjectXmlReader.getData(i, "RESERVE_N_16");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_17] = _previousObjectXmlReader.getData(i, "RESERVE_N_17");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_18] = _previousObjectXmlReader.getData(i, "RESERVE_N_18");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_19] = _previousObjectXmlReader.getData(i, "RESERVE_N_19");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_20] = _previousObjectXmlReader.getData(i, "RESERVE_N_20");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_21] = _previousObjectXmlReader.getData(i, "RESERVE_N_21");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_22] = _previousObjectXmlReader.getData(i, "RESERVE_N_22");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_23] = _previousObjectXmlReader.getData(i, "RESERVE_N_23");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_24] = _previousObjectXmlReader.getData(i, "RESERVE_N_24");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_25] = _previousObjectXmlReader.getData(i, "RESERVE_N_25");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_26] = _previousObjectXmlReader.getData(i, "RESERVE_N_26");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_27] = _previousObjectXmlReader.getData(i, "RESERVE_N_27");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_28] = _previousObjectXmlReader.getData(i, "RESERVE_N_28");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_29] = _previousObjectXmlReader.getData(i, "RESERVE_N_29");
                    strResults[_nPreviousRecBukenCount][OBJECT_RESERVE_N_30] = _previousObjectXmlReader.getData(i, "RESERVE_N_30");
                    //20051207 zj e

                    _nPreviousRecBukenCount = _nPreviousRecBukenCount + 1;
                }
            }
            String[][] strRetResults = new String[_nPreviousRecBukenCount][OBJECT_RECORD_COUNT];
            for (int i = 0; i < strRetResults.length; i++) {
                System.arraycopy(strResults[i], 0, strRetResults[i], 0, strResults[i].length);
            }
            _strPreviousResults = strRetResults;
            return strRetResults;
        } catch (Exception e) {
            e.printStackTrace();
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog = new LfcSystemLog();
            sysLog.writeLog("ObjectBean", //クラス名
                    "getPreviousQueryResults()", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return new String[0][0];
        }
    }
    //20051108 zj e

    public void doSortResultArr() {
//ws 2006/03/01 change start
        if (isResultsNull()) {
            return;
        }
//ws 2006/03/01 change end
        String[] strTmpArr = new String[OBJECT_RECORD_COUNT];
        for (int i = 0; i < _strLeaseResults.length; i++) {
            for (int j = i + 1; j < _strLeaseResults.length; j++) {
                if (LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_NO]) > LfcFrmComm.toInt(_strLeaseResults[j][OBJECT_BUKKEN_NO])) {
                    System.arraycopy(_strLeaseResults[i], 0, strTmpArr, 0, _strLeaseResults[i].length);
                    System.arraycopy(_strLeaseResults[j], 0, _strLeaseResults[i], 0, _strLeaseResults[j].length);
                    System.arraycopy(strTmpArr, 0, _strLeaseResults[j], 0, strTmpArr.length);
                }
            }
        }
    }

    /**
     * 検索ID集により結果集を取得するメソッド(表示出力配列の項目だけ取得する)．    <BR>
     *
     * <PRE>
     *  １．検索ID集により結果集を取得する。
     *  ２．表示出力配列により配列nOutColに設定するフィールドだけを取得する。
     *      成功の場合、結果集を_vResultsに設定する。
     *      失敗の場合、エラーメッセージを_strErrorMessageに設定する。
     * </PRE>
     *
     * @param   strSql         XPATH文
     * @param   nOutCol        表示出力項目を格納する配列
     * @return  boolean true ：結果集の設定は成功
     *                  false：結果集の設定は失敗
     * @see     #getQueryResults(String)
     * @since   01-01
     */
    public String[][] getQueryResultsForLease(String strSql, int[] nOutCol) {
        try {
            if (getQueryResultsForLease(strSql).length == 0) {
                return new String[0][0];
            }
            String[][] strOutColResults = new String[_strLeaseResults.length][nOutCol.length];
            for (int i = 0; i < _strLeaseResults.length; i++) {
                for (int j = 0; j < nOutCol.length; j++) {
                    strOutColResults[i][j] = _strLeaseResults[i][nOutCol[j]];
                }
            }
            return strOutColResults;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog = new LfcSystemLog();
            sysLog.writeLog("ObjectBean", //クラス名
                    "getQueryResults(String strSql, int[] nOutCol)", //メソッド名
                    LfcDBMsgConst.ERA009, //ロジックメッセージ
                    e);                                   //システムエラーメッセージ
            return new String[0][0];
        }
    }

    /**
     * 更新配列に設定する項目より複数のレコードを更新するメソッド．    <BR>
     *
     * <PRE>
     *  ループでupdateRecordメソッドをコールして複数レコードの更新を行う。
     * </PRE>
     *
     * @param   nFieldNameArray  更新フィールド名を格納配列
     * @param   vValues          更新フィールド値を格納するVector
     * @return  boolean   true ：複数のレコードの更新は成功
     *                    false：複数のレコードの更新は失敗
     * @see     #updateRecord(int[], Vector)
     * @since   01-01
     */
    public boolean updateRecords(int[] nFieldNameArray, String[][] strValues) {
        for (int i = 0; i < strValues.length; i++) {
            updateRecord(nFieldNameArray, strValues[i]);
        }
        return true;
    }

    /**
     * 更新配列に設定する項目より単一のレコードを更新するメソッド．    <BR>
     *
     * <PRE>
     *  キーINDEXの設定は正しいかどうかの判断。
     *  更新配列に設定する項目だけ更新する。
     * </PRE>
     *
     * @param   nFieldNameArray  更新フィールド名を格納配列
     * @param   vValues          更新フィールド値を格納するVector
     * @return  boolean   true ：単一のレコードの更新は成功
     *                    false：単一のレコードの更新は失敗
     * @see     #updateFlag(int, int[])
     * @since   01-01
     */
    public boolean updateRecord(int[] nFieldNameArray, String[] strValues) {
        String[] strValue = new String[OBJECT_RECORD_COUNT];
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strValues[OBJECT_REC_NO].equals(_strLeaseResults[i][OBJECT_REC_NO]) &&
                    strValues[OBJECT_BUKKEN_NO].equals(_strLeaseResults[i][OBJECT_BUKKEN_NO])) {
                System.arraycopy(_strLeaseResults[i], 0, strValue, 0, OBJECT_RECORD_COUNT);
                strValue[OBJECT_BUKKEN_FR] = strValues[OBJECT_BUKKEN_FR];
                strValue[OBJECT_BUKKEN_TO] = strValues[OBJECT_BUKKEN_TO];
                break;
            }
        }
        removeRecord(strValues[OBJECT_REC_NO], strValues[OBJECT_BUKKEN_NO]);
        insertRecord(nFieldNameArray, strValue);
        return true;
    }

    public void doCommit() {
        try {
            FileWriter fw = new FileWriter(_strXmlFilePath);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(_strBuffer.toString());
            pw.close();
        } catch (IOException e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog = new LfcSystemLog();
            sysLog.writeLog("ObjectBean.doCommit()", //クラス名
                    _strBuffer.toString(), //メソッド名
                    _strXmlFilePath + "へ書き出すときエラー", //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
        }
    }

    //20051108 zj s
    public void doPreviousCommit() {
        try {
            FileWriter fw = new FileWriter(_strPreviousXmlFilePath);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(_previousStrBuffer.toString());
            pw.close();
        } catch (IOException e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("ObjectBean.doPreviousCommit()", //クラス名
                    _previousStrBuffer.toString(), //メソッド名
                    _strPreviousXmlFilePath + "へ書き出すときエラー", //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
        }
    }
    //20051108 zj e

    public boolean removeRecords(String strFrom, String strTo) {
        try {
            if (isResultsNull()) {
                return true;
            }
            int nFrom = LfcFrmComm.toInt(strFrom);
            int nTo = LfcFrmComm.toInt(strTo);
            int nIndexCnt = 0;
            for (int i = 0; i < _strLeaseResults.length; i++) {
                if (LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_NO]) >= nFrom && LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_NO]) <= nTo) {
                    nIndexCnt++;
                }
            }
            String[] strIDsIndexArray = new String[nIndexCnt];
            for (int i = 0, j = 0; i < _strLeaseResults.length; i++) {
                if (LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_NO]) >= nFrom && LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_NO]) <= nTo) {
                    strIDsIndexArray[j++] = _strLeaseResults[i][OBJECT_BUKKEN_NO];
                }
            }
            //remove row
            for (int i = 0; i < strIDsIndexArray.length; i++) {
                removeRecord(_strCurRecNo, strIDsIndexArray[i]);
            }
            return true;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("ObjectBean", //クラス名
                    "removeRecords(String strFrom, String strTo)", //メソッド名
                    LfcDBMsgConst.ERA014, //ロジックメッセージ
                    e);                                   //システムエラーメッセージ
            return false;
        }
    }

    private boolean removeRecord(String strRecNo, String strBukkenNo) {
        String strDelete = _strBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            int nPos6 = strDelete.indexOf("BUKKEN_NO", nPos1);
            int nPos7 = strDelete.indexOf("\"", nPos6);
            int nPos8 = strDelete.indexOf("\"", nPos7 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2 ||
                    nPos6 > nPos2 || nPos7 > nPos2 || nPos8 > nPos2) {
                break;
            }
            String strKeyRecNoValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            String strKeyBukkenNoValue = strDelete.substring(nPos7 + 1, nPos8).trim();

            if (strRecNo.equals(strKeyRecNoValue) && strBukkenNo.equals(strKeyBukkenNoValue)) {
                int nPos9 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos9 + 6);
            }
            i = nPos1;
        }
        //refresh array
        /*
        String[][] strTmp = new String[_strLeaseResults.length - 1][OBJECT_RECORD_COUNT];
        for(int i = 0, j = 0; i < _strLeaseResults.length; i++) {
        if(strBukkenNo.equals(_strLeaseResults[i][OBJECT_BUKKEN_NO])) {
        continue;
        }
        System.arraycopy(_strLeaseResults[i], 0, strTmp[j++], 0, OBJECT_RECORD_COUNT);
        }
        _strLeaseResults = strTmp;
         */
        //refresh array
        for (int i = _objectXmlReader.getRowCount() - 1; i >= 0; i--) {
            if (strRecNo.equals(_objectXmlReader.getData(i, "REC_NO")) &&
                    strBukkenNo.equals(_objectXmlReader.getData(i, "BUKKEN_NO"))) {
                _objectXmlReader.removeRow(i);
            }
        }
        getQueryResults(strRecNo);

        return true;
    }

    public boolean removeRecords(String strRecNo) {
        String strDelete = _strBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2) {
                break;
            }
            String strKeyValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            if (strRecNo.equals(strKeyValue)) {
                int nPos6 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos6 + 6);
            }
            i = nPos1;
        }
        for (int i = _objectXmlReader.getRowCount() - 1; i >= 0; i--) {
            if (strRecNo.equals(_objectXmlReader.getData(i, "REC_NO"))) {
                _objectXmlReader.removeRow(i);
            }
        }
        _strLeaseResults = null;
        return true;
    }

    //20051108 zj s
    public boolean removePreviousRecords(String strRecNo) {
        String strDelete = _previousStrBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2) {
                break;
            }
            String strKeyValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            if (strRecNo.equals(strKeyValue)) {
                int nPos6 = strDelete.indexOf("</ROW>", nPos1);
                _previousStrBuffer.delete(nPos1, nPos6 + 6);
            }
            i = nPos1;
        }
        for (int i = _previousObjectXmlReader.getRowCount() - 1; i >= 0; i--) {
            if (strRecNo.equals(_previousObjectXmlReader.getData(i, "REC_NO"))) {
                _previousObjectXmlReader.removeRow(i);
            }
        }
        getPreviousQueryResults(strRecNo);
        return true;
    }
    //20051108 zj e

    /**
     * INSERT配列に設定する項目より複数のレコードをINSERTするメソッド．    <BR>
     *
     * <PRE>
     *  ループでinsertRecordメソッドをコールして複数レコードのINSERTを行う。
     * </PRE>
     *
     * @param   nFieldNameArray    INSERTフィールド名を格納配列
     * @param   vValues            INSERTフィールド値を格納するVector
     * @return  boolean   true ：  複数のレコードのINSERTは成功
     *                    false：  複数のレコードのINSERTは失敗
     * @see     #insertRecord(int, Vector)
     * @since   01-01
     */
    public boolean insertRecords(int[] nFieldNameArray, String[][] strValues) {
        try {
            for (int i = 0; i < strValues.length; i++) {
                if (!insertRecord(nFieldNameArray, strValues[i])) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("ObjectBean", //クラス名
                    "insertRecords(int[] nFieldNameArray, String[][] strValues)", //メソッド名
                    LfcDBMsgConst.ERA012, //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
            return false;
        }
    }

    //20051108 zj s
    public boolean insertPreviousRecords(String[][] strValues) {
        try {
            for (int i = 0; i < strValues.length; i++) {
                if (!insertPreviousRecord(strValues[i])) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("ObjectBean", //クラス名
                    "insertPreviousRecords(String[][] strValues)", //メソッド名
                    LfcDBMsgConst.ERA012, //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
            return false;
        }
    }
    //20051108 zj e

    public boolean insertRecord(int[] nFieldNameArray, String[] strValues) {
        String strOff = _strBuffer.toString();
        int nOffset = strOff.lastIndexOf("</OBJECT>");

        StringBuffer strOut = new StringBuffer();

        strOut.append("<ROW BUKKEN_NO=\"");
        strOut.append(strValues[OBJECT_BUKKEN_NO]);
        strOut.append("\" REC_NO=\"");
        strOut.append(strValues[OBJECT_REC_NO]);
        strOut.append("\">");
        strOut.append("<BUKKEN_FR>" + strValues[OBJECT_BUKKEN_FR] + "</BUKKEN_FR>");
        strOut.append("<BUKKEN_TO>" + strValues[OBJECT_BUKKEN_TO] + "</BUKKEN_TO>");
        strOut.append("<DATE_KENSH>" + strValues[OBJECT_DATE_KENSH] + "</DATE_KENSH>");
        strOut.append("<PURCHASE>" + strValues[OBJECT_PURCHASE] + "</PURCHASE>");
        strOut.append("<QUANTITY>" + strValues[OBJECT_QUANTITY] + "</QUANTITY>");
        strOut.append("<SW_PAY>" + strValues[OBJECT_SW_PAY] + "</SW_PAY>");
        strOut.append("<DATE_PAYMT>" + strValues[OBJECT_DATE_PAYMT] + "</DATE_PAYMT>");
        strOut.append("<REMAIN_VAL>" + strValues[OBJECT_REMAIN_VAL] + "</REMAIN_VAL>");
        strOut.append("<REM_VAL_RT>" + strValues[OBJECT_REM_VAL_RT] + "</REM_VAL_RT>");
        strOut.append("<DURABLE_Y>" + strValues[OBJECT_DURABLE_Y] + "</DURABLE_Y>");
        strOut.append("<LEASE_M>" + strValues[OBJECT_LEASE_M] + "</LEASE_M>");
        strOut.append("<RATE_JLC>" + strValues[OBJECT_RATE_JLC] + "</RATE_JLC>");
        strOut.append("<RATE_C_ADJ>" + strValues[OBJECT_RATE_C_ADJ] + "</RATE_C_ADJ>");
        strOut.append("<RATE_E_ANI>" + strValues[OBJECT_RATE_E_ANI] + "</RATE_E_ANI>");
        strOut.append("<RATE_E_A_O>" + strValues[OBJECT_RATE_E_A_O] + "</RATE_E_A_O>");
        strOut.append("<RATE_E_A_S>" + strValues[OBJECT_RATE_E_A_S] + "</RATE_E_A_S>");
        strOut.append("<RATE_LOSS>" + strValues[OBJECT_RATE_LOSS] + "</RATE_LOSS>");
        strOut.append("<CSTKISHUCD>" + strValues[OBJECT_CSTKISHUCD] + "</CSTKISHUCD>");
        strOut.append("<CSTSELINFO>" + strValues[OBJECT_CSTSELINFO] + "</CSTSELINFO>");
        strOut.append("<RATE_FEE>" + strValues[OBJECT_RATE_FEE] + "</RATE_FEE>");
        strOut.append("<RATE_FEE_N>" + strValues[OBJECT_RATE_FEE_N] + "</RATE_FEE_N>");
        strOut.append("<RATE_FEE_R>" + strValues[OBJECT_RATE_FEE_R] + "</RATE_FEE_R>");
        strOut.append("<DOSO_RATE>" + strValues[OBJECT_DOSO_RATE] + "</DOSO_RATE>");
        strOut.append("<SW_SOFT>" + strValues[OBJECT_SW_SOFT] + "</SW_SOFT>");
        strOut.append("<FIXASTTAX>" + strValues[OBJECT_FIXASTTAX] + "</FIXASTTAX>");
        strOut.append("<DOSO_INDEX>" + strValues[OBJECT_DOSO_INDEX] + "</DOSO_INDEX>");
        strOut.append("<DOSO_FEE>" + strValues[OBJECT_DOSO_FEE] + "</DOSO_FEE>");
        strOut.append("<SW_BAISEKI>" + strValues[OBJECT_SW_BAISEKI] + "</SW_BAISEKI>");
        strOut.append("<DANSHIN_RT>" + strValues[OBJECT_DANSHIN_RT] + "</DANSHIN_RT>");
        strOut.append("<MACHI_FEE>" + strValues[OBJECT_MACHI_FEE] + "</MACHI_FEE>");
        strOut.append("<FIRE_FEE>" + strValues[OBJECT_FIRE_FEE] + "</FIRE_FEE>");
        strOut.append("<ETC_FEE>" + strValues[OBJECT_ETC_FEE] + "</ETC_FEE>");
        strOut.append("<ICHIJI_1>" + strValues[OBJECT_ICHIJI_1] + "</ICHIJI_1>");
        strOut.append("<ICHIJI_2>" + strValues[OBJECT_ICHIJI_2] + "</ICHIJI_2>");
        strOut.append("<ICHIJI_3>" + strValues[OBJECT_ICHIJI_3] + "</ICHIJI_3>");
        strOut.append("<KURINO_1>" + strValues[OBJECT_KURINO_1] + "</KURINO_1>");
        strOut.append("<KURINO_2>" + strValues[OBJECT_KURINO_2] + "</KURINO_2>");
        strOut.append("<HOSHURYO>" + strValues[OBJECT_HOSHURYO] + "</HOSHURYO>");
        strOut.append("<ASSEN>" + strValues[OBJECT_ASSEN] + "</ASSEN>");
        strOut.append("<KAPPU_INS>" + strValues[OBJECT_KAPPU_INS] + "</KAPPU_INS>");
        strOut.append("<DATE_INC_0>" + strValues[OBJECT_DATE_INC_0] + "</DATE_INC_0>");
        strOut.append("<INCOME_0>" + strValues[OBJECT_INCOME_0] + "</INCOME_0>");
        strOut.append("<INC_0_M>" + strValues[OBJECT_INC_0_M] + "</INC_0_M>");
        strOut.append("<LEASE_D>" + strValues[OBJECT_LEASE_D] + "</LEASE_D>");
        strOut.append("<EVEN_FLG>" + strValues[OBJECT_EVEN_FLG] + "</EVEN_FLG>");
        strOut.append("<RYORITSU_T>" + strValues[OBJECT_RYORITSU_T] + "</RYORITSU_T>");
        strOut.append("<RYORITSU_M>" + strValues[OBJECT_RYORITSU_M] + "</RYORITSU_M>");
        strOut.append("<RATE_UNYO>" + strValues[OBJECT_RATE_UNYO] + "</RATE_UNYO>");
        strOut.append("<TRUE_RATE>" + strValues[OBJECT_TRUE_RATE] + "</TRUE_RATE>");
        strOut.append("<RATE_ROI>" + strValues[OBJECT_RATE_ROI] + "</RATE_ROI>");
        strOut.append("<INTEREST_P>" + strValues[OBJECT_INTEREST_P] + "</INTEREST_P>");
        strOut.append("<INTEREST_I>" + strValues[OBJECT_INTEREST_I] + "</INTEREST_I>");
        strOut.append("<ZAPI>" + strValues[OBJECT_ZAPI] + "</ZAPI>");
        strOut.append("<INSURANCE>" + strValues[OBJECT_INSURANCE] + "</INSURANCE>");
        strOut.append("<COST_TOTAL>" + strValues[OBJECT_COST_TOTAL] + "</COST_TOTAL>");
        strOut.append("<CHARGE>" + strValues[OBJECT_CHARGE] + "</CHARGE>");
        strOut.append("<INCOME_GT>" + strValues[OBJECT_INCOME_GT] + "</INCOME_GT>");
        strOut.append("<C_ADJUST>" + strValues[OBJECT_C_ADJUST] + "</C_ADJUST>");
        strOut.append("<PROFIT_T>" + strValues[OBJECT_PROFIT_T] + "</PROFIT_T>");
        strOut.append("<PROFIT_Y>" + strValues[OBJECT_PROFIT_Y] + "</PROFIT_Y>");
        strOut.append("<CAPITAL_T>" + strValues[OBJECT_CAPITAL_T] + "</CAPITAL_T>");
        strOut.append("<RAT_PRO_T>" + strValues[OBJECT_RAT_PRO_T] + "</RAT_PRO_T>");
        strOut.append("<RAT_PRO_Y>" + strValues[OBJECT_RAT_PRO_Y] + "</RAT_PRO_Y>");
        strOut.append("<RATE_YEAR>" + strValues[OBJECT_RATE_YEAR] + "</RATE_YEAR>");
        strOut.append("<ADJUST_M>" + strValues[OBJECT_ADJUST_M] + "</ADJUST_M>");
        strOut.append("<ADJUST_D>" + strValues[OBJECT_ADJUST_D] + "</ADJUST_D>");
        strOut.append("<INCOME_T>" + strValues[OBJECT_INCOME_T] + "</INCOME_T>");
        strOut.append("<INIT_COST>" + strValues[OBJECT_INIT_COST] + "</INIT_COST>");
        strOut.append("<EXEC_COST>" + strValues[OBJECT_EXEC_COST] + "</EXEC_COST>");
        strOut.append("<NET_RATE>" + strValues[OBJECT_NET_RATE] + "</NET_RATE>");
        strOut.append("<FINANCE_MARGIN>" + strValues[OBJECT_FINANCE_MARGIN] + "</FINANCE_MARGIN>");
        strOut.append("<RA_MARGIN>" + strValues[OBJECT_RA_MARGIN] + "</RA_MARGIN>");
        strOut.append("<PV_FINANCE_MARGIN>" + strValues[OBJECT_PV_FINANCE_MARGIN] + "</PV_FINANCE_MARGIN>");
        strOut.append("<RA_PV_MARGIN>" + strValues[OBJECT_RA_PV_MARGIN] + "</RA_PV_MARGIN>");
        strOut.append("<LEAVE_M>" + strValues[OBJECT_LEAVE_M] + "</LEAVE_M>");
        strOut.append("<BAIS_FEE>" + strValues[OBJECT_BAIS_FEE] + "</BAIS_FEE>");
        strOut.append("<DAMAGE_BAS>" + strValues[OBJECT_DAMAGE_BAS] + "</DAMAGE_BAS>");
        strOut.append("<DAMAGE_FM>" + strValues[OBJECT_DAMAGE_FM] + "</DAMAGE_FM>");
        strOut.append("<DAMAGE_LM>" + strValues[OBJECT_DAMAGE_LM] + "</DAMAGE_LM>");
        strOut.append("<DAMAGE_FA>" + strValues[OBJECT_DAMAGE_FA] + "</DAMAGE_FA>");
        strOut.append("<DAMAGE_LA>" + strValues[OBJECT_DAMAGE_LA] + "</DAMAGE_LA>");
        strOut.append("<F_INTER_P>" + strValues[OBJECT_F_INTER_P] + "</F_INTER_P>");
        strOut.append("<F_INTER_I>" + strValues[OBJECT_F_INTER_I] + "</F_INTER_I>");
        strOut.append("<F_CHARGE>" + strValues[OBJECT_F_CHARGE] + "</F_CHARGE>");
        strOut.append("<F_EXEC_C>" + strValues[OBJECT_F_EXEC_C] + "</F_EXEC_C>");
        strOut.append("<F_KURI_1>" + strValues[OBJECT_F_KURI_1] + "</F_KURI_1>");
        strOut.append("<F_INSUR>" + strValues[OBJECT_F_INSUR] + "</F_INSUR>");
        strOut.append("<F_COST_T>" + strValues[OBJECT_F_COST_T] + "</F_COST_T>");
        strOut.append("<F_PRO_T>" + strValues[OBJECT_F_PRO_T] + "</F_PRO_T>");
        strOut.append("<F_PRO_Y>" + strValues[OBJECT_F_PRO_Y] + "</F_PRO_Y>");
        strOut.append("<F_CAPIT_T>" + strValues[OBJECT_F_CAPIT_T] + "</F_CAPIT_T>");
        strOut.append("<F_TRUE_RT>" + strValues[OBJECT_F_TRUE_RT] + "</F_TRUE_RT>");
        strOut.append("<F_RT_YR>" + strValues[OBJECT_F_RT_YR] + "</F_RT_YR>");
        strOut.append("<F_RT_UN>" + strValues[OBJECT_F_RT_UN] + "</F_RT_UN>");
        strOut.append("<F_RT_PRT>" + strValues[OBJECT_F_RT_PRT] + "</F_RT_PRT>");
        strOut.append("<F_RT_PRY>" + strValues[OBJECT_F_RT_PRY] + "</F_RT_PRY>");
        strOut.append("<F_RT_ROI>" + strValues[OBJECT_F_RT_ROI] + "</F_RT_ROI>");
        strOut.append("<F_FINANCE_MARGIN>" + strValues[OBJECT_F_FINANCE_MARGIN] + "</F_FINANCE_MARGIN>");
        strOut.append("<F_RA_MARGIN>" + strValues[OBJECT_F_RA_MARGIN] + "</F_RA_MARGIN>");
        strOut.append("<F_PV_FINANCE_MARGIN>" + strValues[OBJECT_F_PV_FINANCE_MARGIN] + "</F_PV_FINANCE_MARGIN>");
        strOut.append("<F_RA_PV_MARGIN>" + strValues[OBJECT_F_RA_PV_MARGIN] + "</F_RA_PV_MARGIN>");
        strOut.append("<CREDIT_INS>" + strValues[OBJECT_CREDIT_INS] + "</CREDIT_INS>");
        strOut.append("<SW_CRE_INS>" + strValues[OBJECT_SW_CRE_INS] + "</SW_CRE_INS>");
        strOut.append("<CRE_INS_CD>" + strValues[OBJECT_CRE_INS_CD] + "</CRE_INS_CD>");
        strOut.append("<CRE_INS_TM>" + strValues[OBJECT_CRE_INS_TM] + "</CRE_INS_TM>");
        strOut.append("<CRE_INS_RT>" + strValues[OBJECT_CRE_INS_RT] + "</CRE_INS_RT>");
        strOut.append("<SW_S_PRO>" + strValues[OBJECT_SW_S_PRO] + "</SW_S_PRO>");
        strOut.append("<RESERVE1>" + strValues[OBJECT_RESERVE1] + "</RESERVE1>");
        strOut.append("<PRODUCT>" + strValues[OBJECT_PRODUCT] + "</PRODUCT>");
        strOut.append("<LEVERAGE>" + strValues[OBJECT_LEVERAGE] + "</LEVERAGE>");
        strOut.append("<ROE>" + strValues[OBJECT_ROE] + "</ROE>");
        strOut.append("<FP_ROE>" + strValues[OBJECT_FP_ROE] + "</FP_ROE>");
        strOut.append("<PRODUCT_CD>" + strValues[OBJECT_PRODUCT_CD] + "</PRODUCT_CD>");

        //20051207 zj s
        strOut.append(
                "<RESERVE_C_01>" + strValues[OBJECT_RESERVE_C_01] + "</RESERVE_C_01>");
        strOut.append(
                "<RESERVE_C_02>" + strValues[OBJECT_RESERVE_C_02] + "</RESERVE_C_02>");
        strOut.append(
                "<RESERVE_C_03>" + strValues[OBJECT_RESERVE_C_03] + "</RESERVE_C_03>");
        strOut.append(
                "<RESERVE_C_04>" + strValues[OBJECT_RESERVE_C_04] + "</RESERVE_C_04>");
        strOut.append(
                "<RESERVE_C_05>" + strValues[OBJECT_RESERVE_C_05] + "</RESERVE_C_05>");
        strOut.append(
                "<RESERVE_C_06>" + strValues[OBJECT_RESERVE_C_06] + "</RESERVE_C_06>");
        strOut.append(
                "<RESERVE_C_07>" + strValues[OBJECT_RESERVE_C_07] + "</RESERVE_C_07>");
        strOut.append(
                "<RESERVE_C_08>" + strValues[OBJECT_RESERVE_C_08] + "</RESERVE_C_08>");
        strOut.append(
                "<RESERVE_C_09>" + strValues[OBJECT_RESERVE_C_09] + "</RESERVE_C_09>");
        strOut.append(
                "<RESERVE_C_10>" + strValues[OBJECT_RESERVE_C_10] + "</RESERVE_C_10>");
        strOut.append(
                "<RESERVE_C_11>" + strValues[OBJECT_RESERVE_C_11] + "</RESERVE_C_11>");
        strOut.append(
                "<RESERVE_C_12>" + strValues[OBJECT_RESERVE_C_12] + "</RESERVE_C_12>");
        strOut.append(
                "<RESERVE_C_13>" + strValues[OBJECT_RESERVE_C_13] + "</RESERVE_C_13>");
        strOut.append(
                "<RESERVE_C_14>" + strValues[OBJECT_RESERVE_C_14] + "</RESERVE_C_14>");
        strOut.append(
                "<RESERVE_C_15>" + strValues[OBJECT_RESERVE_C_15] + "</RESERVE_C_15>");
        strOut.append(
                "<RESERVE_C_16>" + strValues[OBJECT_RESERVE_C_16] + "</RESERVE_C_16>");
        strOut.append(
                "<RESERVE_C_17>" + strValues[OBJECT_RESERVE_C_17] + "</RESERVE_C_17>");
        strOut.append(
                "<RESERVE_C_18>" + strValues[OBJECT_RESERVE_C_18] + "</RESERVE_C_18>");
        strOut.append(
                "<RESERVE_C_19>" + strValues[OBJECT_RESERVE_C_19] + "</RESERVE_C_19>");
        strOut.append(
                "<RESERVE_C_20>" + strValues[OBJECT_RESERVE_C_20] + "</RESERVE_C_20>");
        strOut.append(
                "<RESERVE_C_21>" + strValues[OBJECT_RESERVE_C_21] + "</RESERVE_C_21>");
        strOut.append(
                "<RESERVE_C_22>" + strValues[OBJECT_RESERVE_C_22] + "</RESERVE_C_22>");
        strOut.append(
                "<RESERVE_C_23>" + strValues[OBJECT_RESERVE_C_23] + "</RESERVE_C_23>");
        strOut.append(
                "<RESERVE_C_24>" + strValues[OBJECT_RESERVE_C_24] + "</RESERVE_C_24>");
        strOut.append(
                "<RESERVE_C_25>" + strValues[OBJECT_RESERVE_C_25] + "</RESERVE_C_25>");
        strOut.append(
                "<RESERVE_C_26>" + strValues[OBJECT_RESERVE_C_26] + "</RESERVE_C_26>");
        strOut.append(
                "<RESERVE_C_27>" + strValues[OBJECT_RESERVE_C_27] + "</RESERVE_C_27>");
        strOut.append(
                "<RESERVE_C_28>" + strValues[OBJECT_RESERVE_C_28] + "</RESERVE_C_28>");
        strOut.append(
                "<RESERVE_C_29>" + strValues[OBJECT_RESERVE_C_29] + "</RESERVE_C_29>");
        strOut.append(
                "<RESERVE_C_30>" + strValues[OBJECT_RESERVE_C_30] + "</RESERVE_C_30>");

        strOut.append(
                "<RESERVE_N_01>" + strValues[OBJECT_RESERVE_N_01] + "</RESERVE_N_01>");
        strOut.append(
                "<RESERVE_N_02>" + strValues[OBJECT_RESERVE_N_02] + "</RESERVE_N_02>");
        strOut.append(
                "<RESERVE_N_03>" + strValues[OBJECT_RESERVE_N_03] + "</RESERVE_N_03>");
        strOut.append(
                "<RESERVE_N_04>" + strValues[OBJECT_RESERVE_N_04] + "</RESERVE_N_04>");
        strOut.append(
                "<RESERVE_N_05>" + strValues[OBJECT_RESERVE_N_05] + "</RESERVE_N_05>");
        strOut.append(
                "<RESERVE_N_06>" + strValues[OBJECT_RESERVE_N_06] + "</RESERVE_N_06>");
        strOut.append(
                "<RESERVE_N_07>" + strValues[OBJECT_RESERVE_N_07] + "</RESERVE_N_07>");
        strOut.append(
                "<RESERVE_N_08>" + strValues[OBJECT_RESERVE_N_08] + "</RESERVE_N_08>");
        strOut.append(
                "<RESERVE_N_09>" + strValues[OBJECT_RESERVE_N_09] + "</RESERVE_N_09>");
        strOut.append(
                "<RESERVE_N_10>" + strValues[OBJECT_RESERVE_N_10] + "</RESERVE_N_10>");
        strOut.append(
                "<RESERVE_N_11>" + strValues[OBJECT_RESERVE_N_11] + "</RESERVE_N_11>");
        strOut.append(
                "<RESERVE_N_12>" + strValues[OBJECT_RESERVE_N_12] + "</RESERVE_N_12>");
        strOut.append(
                "<RESERVE_N_13>" + strValues[OBJECT_RESERVE_N_13] + "</RESERVE_N_13>");
        strOut.append(
                "<RESERVE_N_14>" + strValues[OBJECT_RESERVE_N_14] + "</RESERVE_N_14>");
        strOut.append(
                "<RESERVE_N_15>" + strValues[OBJECT_RESERVE_N_15] + "</RESERVE_N_15>");
        strOut.append(
                "<RESERVE_N_16>" + strValues[OBJECT_RESERVE_N_16] + "</RESERVE_N_16>");
        strOut.append(
                "<RESERVE_N_17>" + strValues[OBJECT_RESERVE_N_17] + "</RESERVE_N_17>");
        strOut.append(
                "<RESERVE_N_18>" + strValues[OBJECT_RESERVE_N_18] + "</RESERVE_N_18>");
        strOut.append(
                "<RESERVE_N_19>" + strValues[OBJECT_RESERVE_N_19] + "</RESERVE_N_19>");
        strOut.append(
                "<RESERVE_N_20>" + strValues[OBJECT_RESERVE_N_20] + "</RESERVE_N_20>");
        strOut.append(
                "<RESERVE_N_21>" + strValues[OBJECT_RESERVE_N_21] + "</RESERVE_N_21>");
        strOut.append(
                "<RESERVE_N_22>" + strValues[OBJECT_RESERVE_N_22] + "</RESERVE_N_22>");
        strOut.append(
                "<RESERVE_N_23>" + strValues[OBJECT_RESERVE_N_23] + "</RESERVE_N_23>");
        strOut.append(
                "<RESERVE_N_24>" + strValues[OBJECT_RESERVE_N_24] + "</RESERVE_N_24>");
        strOut.append(
                "<RESERVE_N_25>" + strValues[OBJECT_RESERVE_N_25] + "</RESERVE_N_25>");
        strOut.append(
                "<RESERVE_N_26>" + strValues[OBJECT_RESERVE_N_26] + "</RESERVE_N_26>");
        strOut.append(
                "<RESERVE_N_27>" + strValues[OBJECT_RESERVE_N_27] + "</RESERVE_N_27>");
        strOut.append(
                "<RESERVE_N_28>" + strValues[OBJECT_RESERVE_N_28] + "</RESERVE_N_28>");
        strOut.append(
                "<RESERVE_N_29>" + strValues[OBJECT_RESERVE_N_29] + "</RESERVE_N_29>");
        strOut.append(
                "<RESERVE_N_30>" + strValues[OBJECT_RESERVE_N_30] + "</RESERVE_N_30>");
        //20051207 zj e

        strOut.append("</ROW>");

        _strBuffer.insert(nOffset, strOut.toString());


        //refresh array
        /*
        String[][] strTempArr;
        if(_strLeaseResults == null) {
        _strLeaseResults = new String[1][OBJECT_RECORD_COUNT];
        System.arraycopy(strValues, 0, _strLeaseResults[0], 0, OBJECT_RECORD_COUNT);
        } else {
        strTempArr = new String[_strLeaseResults.length + 1][OBJECT_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, strTempArr, 0, _strLeaseResults.length);
        System.arraycopy(strValues, 0, strTempArr[_strLeaseResults.length], 0, OBJECT_RECORD_COUNT);
        _strLeaseResults = strTempArr;
        }
         */
        String strChangeTmp = strValues[OBJECT_REC_NO];
        strValues[OBJECT_REC_NO] = strValues[OBJECT_BUKKEN_NO];
        strValues[OBJECT_BUKKEN_NO] = strChangeTmp;
        //Attention:RecNo and BukkenNo had changed!!!
        //Because XML file's order had changed!!!
        _objectXmlReader.insertRow(strValues);
        getQueryResults(strValues[OBJECT_BUKKEN_NO]);
        return true;
    }

    //20051108 zj s
    public boolean insertPreviousRecord(String[] strValues) {
        String strOff = _previousStrBuffer.toString();
        int nOffset = strOff.lastIndexOf("</OBJECT>");

        StringBuffer strOut = new StringBuffer();
        strOut.append("<ROW BUKKEN_NO=\"");
        strOut.append(strValues[OBJECT_BUKKEN_NO]);
        strOut.append("\" REC_NO=\"");
        strOut.append(strValues[OBJECT_REC_NO]);
        strOut.append("\">");
        strOut.append("<BUKKEN_FR>" + strValues[OBJECT_BUKKEN_FR] + "</BUKKEN_FR>");
        strOut.append("<BUKKEN_TO>" + strValues[OBJECT_BUKKEN_TO] + "</BUKKEN_TO>");
        strOut.append("<DATE_KENSH>" + strValues[OBJECT_DATE_KENSH] + "</DATE_KENSH>");
        strOut.append("<PURCHASE>" + strValues[OBJECT_PURCHASE] + "</PURCHASE>");
        strOut.append("<QUANTITY>" + strValues[OBJECT_QUANTITY] + "</QUANTITY>");
        strOut.append("<SW_PAY>" + strValues[OBJECT_SW_PAY] + "</SW_PAY>");
        strOut.append("<DATE_PAYMT>" + strValues[OBJECT_DATE_PAYMT] + "</DATE_PAYMT>");
        strOut.append("<REMAIN_VAL>" + strValues[OBJECT_REMAIN_VAL] + "</REMAIN_VAL>");
        strOut.append("<REM_VAL_RT>" + strValues[OBJECT_REM_VAL_RT] + "</REM_VAL_RT>");
        strOut.append("<DURABLE_Y>" + strValues[OBJECT_DURABLE_Y] + "</DURABLE_Y>");
        strOut.append("<LEASE_M>" + strValues[OBJECT_LEASE_M] + "</LEASE_M>");
        strOut.append("<RATE_JLC>" + strValues[OBJECT_RATE_JLC] + "</RATE_JLC>");
        strOut.append("<RATE_C_ADJ>" + strValues[OBJECT_RATE_C_ADJ] + "</RATE_C_ADJ>");
        strOut.append("<RATE_E_ANI>" + strValues[OBJECT_RATE_E_ANI] + "</RATE_E_ANI>");
        strOut.append("<RATE_E_A_O>" + strValues[OBJECT_RATE_E_A_O] + "</RATE_E_A_O>");
        strOut.append("<RATE_E_A_S>" + strValues[OBJECT_RATE_E_A_S] + "</RATE_E_A_S>");
        strOut.append("<RATE_LOSS>" + strValues[OBJECT_RATE_LOSS] + "</RATE_LOSS>");
        strOut.append("<CSTKISHUCD>" + strValues[OBJECT_CSTKISHUCD] + "</CSTKISHUCD>");
        strOut.append("<CSTSELINFO>" + strValues[OBJECT_CSTSELINFO] + "</CSTSELINFO>");
        strOut.append("<RATE_FEE>" + strValues[OBJECT_RATE_FEE] + "</RATE_FEE>");
        strOut.append("<RATE_FEE_N>" + strValues[OBJECT_RATE_FEE_N] + "</RATE_FEE_N>");
        strOut.append("<RATE_FEE_R>" + strValues[OBJECT_RATE_FEE_R] + "</RATE_FEE_R>");
        strOut.append("<DOSO_RATE>" + strValues[OBJECT_DOSO_RATE] + "</DOSO_RATE>");
        strOut.append("<SW_SOFT>" + strValues[OBJECT_SW_SOFT] + "</SW_SOFT>");
        strOut.append("<FIXASTTAX>" + strValues[OBJECT_FIXASTTAX] + "</FIXASTTAX>");
        strOut.append("<DOSO_INDEX>" + strValues[OBJECT_DOSO_INDEX] + "</DOSO_INDEX>");
        strOut.append("<DOSO_FEE>" + strValues[OBJECT_DOSO_FEE] + "</DOSO_FEE>");
        strOut.append("<SW_BAISEKI>" + strValues[OBJECT_SW_BAISEKI] + "</SW_BAISEKI>");
        strOut.append("<DANSHIN_RT>" + strValues[OBJECT_DANSHIN_RT] + "</DANSHIN_RT>");
        strOut.append("<MACHI_FEE>" + strValues[OBJECT_MACHI_FEE] + "</MACHI_FEE>");
        strOut.append("<FIRE_FEE>" + strValues[OBJECT_FIRE_FEE] + "</FIRE_FEE>");
        strOut.append("<ETC_FEE>" + strValues[OBJECT_ETC_FEE] + "</ETC_FEE>");
        strOut.append("<ICHIJI_1>" + strValues[OBJECT_ICHIJI_1] + "</ICHIJI_1>");
        strOut.append("<ICHIJI_2>" + strValues[OBJECT_ICHIJI_2] + "</ICHIJI_2>");
        strOut.append("<ICHIJI_3>" + strValues[OBJECT_ICHIJI_3] + "</ICHIJI_3>");
        strOut.append("<KURINO_1>" + strValues[OBJECT_KURINO_1] + "</KURINO_1>");
        strOut.append("<KURINO_2>" + strValues[OBJECT_KURINO_2] + "</KURINO_2>");
        strOut.append("<HOSHURYO>" + strValues[OBJECT_HOSHURYO] + "</HOSHURYO>");
        strOut.append("<ASSEN>" + strValues[OBJECT_ASSEN] + "</ASSEN>");
        strOut.append("<KAPPU_INS>" + strValues[OBJECT_KAPPU_INS] + "</KAPPU_INS>");
        strOut.append("<DATE_INC_0>" + strValues[OBJECT_DATE_INC_0] + "</DATE_INC_0>");
        strOut.append("<INCOME_0>" + strValues[OBJECT_INCOME_0] + "</INCOME_0>");
        strOut.append("<INC_0_M>" + strValues[OBJECT_INC_0_M] + "</INC_0_M>");
        strOut.append("<LEASE_D>" + strValues[OBJECT_LEASE_D] + "</LEASE_D>");
        strOut.append("<EVEN_FLG>" + strValues[OBJECT_EVEN_FLG] + "</EVEN_FLG>");
        strOut.append("<RYORITSU_T>" + strValues[OBJECT_RYORITSU_T] + "</RYORITSU_T>");
        strOut.append("<RYORITSU_M>" + strValues[OBJECT_RYORITSU_M] + "</RYORITSU_M>");
        strOut.append("<RATE_UNYO>" + strValues[OBJECT_RATE_UNYO] + "</RATE_UNYO>");
        strOut.append("<TRUE_RATE>" + strValues[OBJECT_TRUE_RATE] + "</TRUE_RATE>");
        strOut.append("<RATE_ROI>" + strValues[OBJECT_RATE_ROI] + "</RATE_ROI>");
        strOut.append("<INTEREST_P>" + strValues[OBJECT_INTEREST_P] + "</INTEREST_P>");
        strOut.append("<INTEREST_I>" + strValues[OBJECT_INTEREST_I] + "</INTEREST_I>");
        strOut.append("<ZAPI>" + strValues[OBJECT_ZAPI] + "</ZAPI>");
        strOut.append("<INSURANCE>" + strValues[OBJECT_INSURANCE] + "</INSURANCE>");
        strOut.append("<COST_TOTAL>" + strValues[OBJECT_COST_TOTAL] + "</COST_TOTAL>");
        strOut.append("<CHARGE>" + strValues[OBJECT_CHARGE] + "</CHARGE>");
        strOut.append("<INCOME_GT>" + strValues[OBJECT_INCOME_GT] + "</INCOME_GT>");
        strOut.append("<C_ADJUST>" + strValues[OBJECT_C_ADJUST] + "</C_ADJUST>");
        strOut.append("<PROFIT_T>" + strValues[OBJECT_PROFIT_T] + "</PROFIT_T>");
        strOut.append("<PROFIT_Y>" + strValues[OBJECT_PROFIT_Y] + "</PROFIT_Y>");
        strOut.append("<CAPITAL_T>" + strValues[OBJECT_CAPITAL_T] + "</CAPITAL_T>");
        strOut.append("<RAT_PRO_T>" + strValues[OBJECT_RAT_PRO_T] + "</RAT_PRO_T>");
        strOut.append("<RAT_PRO_Y>" + strValues[OBJECT_RAT_PRO_Y] + "</RAT_PRO_Y>");
        strOut.append("<RATE_YEAR>" + strValues[OBJECT_RATE_YEAR] + "</RATE_YEAR>");
        strOut.append("<ADJUST_M>" + strValues[OBJECT_ADJUST_M] + "</ADJUST_M>");
        strOut.append("<ADJUST_D>" + strValues[OBJECT_ADJUST_D] + "</ADJUST_D>");
        strOut.append("<INCOME_T>" + strValues[OBJECT_INCOME_T] + "</INCOME_T>");
        strOut.append("<INIT_COST>" + strValues[OBJECT_INIT_COST] + "</INIT_COST>");
        strOut.append("<EXEC_COST>" + strValues[OBJECT_EXEC_COST] + "</EXEC_COST>");
        strOut.append("<NET_RATE>" + strValues[OBJECT_NET_RATE] + "</NET_RATE>");
        strOut.append("<FINANCE_MARGIN>" + strValues[OBJECT_FINANCE_MARGIN] + "</FINANCE_MARGIN>");
        strOut.append("<RA_MARGIN>" + strValues[OBJECT_RA_MARGIN] + "</RA_MARGIN>");
        strOut.append("<PV_FINANCE_MARGIN>" + strValues[OBJECT_PV_FINANCE_MARGIN] + "</PV_FINANCE_MARGIN>");
        strOut.append("<RA_PV_MARGIN>" + strValues[OBJECT_RA_PV_MARGIN] + "</RA_PV_MARGIN>");
        strOut.append("<LEAVE_M>" + strValues[OBJECT_LEAVE_M] + "</LEAVE_M>");
        strOut.append("<BAIS_FEE>" + strValues[OBJECT_BAIS_FEE] + "</BAIS_FEE>");
        strOut.append("<DAMAGE_BAS>" + strValues[OBJECT_DAMAGE_BAS] + "</DAMAGE_BAS>");
        strOut.append("<DAMAGE_FM>" + strValues[OBJECT_DAMAGE_FM] + "</DAMAGE_FM>");
        strOut.append("<DAMAGE_LM>" + strValues[OBJECT_DAMAGE_LM] + "</DAMAGE_LM>");
        strOut.append("<DAMAGE_FA>" + strValues[OBJECT_DAMAGE_FA] + "</DAMAGE_FA>");
        strOut.append("<DAMAGE_LA>" + strValues[OBJECT_DAMAGE_LA] + "</DAMAGE_LA>");
        strOut.append("<F_INTER_P>" + strValues[OBJECT_F_INTER_P] + "</F_INTER_P>");
        strOut.append("<F_INTER_I>" + strValues[OBJECT_F_INTER_I] + "</F_INTER_I>");
        strOut.append("<F_CHARGE>" + strValues[OBJECT_F_CHARGE] + "</F_CHARGE>");
        strOut.append("<F_EXEC_C>" + strValues[OBJECT_F_EXEC_C] + "</F_EXEC_C>");
        strOut.append("<F_KURI_1>" + strValues[OBJECT_F_KURI_1] + "</F_KURI_1>");
        strOut.append("<F_INSUR>" + strValues[OBJECT_F_INSUR] + "</F_INSUR>");
        strOut.append("<F_COST_T>" + strValues[OBJECT_F_COST_T] + "</F_COST_T>");
        strOut.append("<F_PRO_T>" + strValues[OBJECT_F_PRO_T] + "</F_PRO_T>");
        strOut.append("<F_PRO_Y>" + strValues[OBJECT_F_PRO_Y] + "</F_PRO_Y>");
        strOut.append("<F_CAPIT_T>" + strValues[OBJECT_F_CAPIT_T] + "</F_CAPIT_T>");
        strOut.append("<F_TRUE_RT>" + strValues[OBJECT_F_TRUE_RT] + "</F_TRUE_RT>");
        strOut.append("<F_RT_YR>" + strValues[OBJECT_F_RT_YR] + "</F_RT_YR>");
        strOut.append("<F_RT_UN>" + strValues[OBJECT_F_RT_UN] + "</F_RT_UN>");
        strOut.append("<F_RT_PRT>" + strValues[OBJECT_F_RT_PRT] + "</F_RT_PRT>");
        strOut.append("<F_RT_PRY>" + strValues[OBJECT_F_RT_PRY] + "</F_RT_PRY>");
        strOut.append("<F_RT_ROI>" + strValues[OBJECT_F_RT_ROI] + "</F_RT_ROI>");
        strOut.append("<F_FINANCE_MARGIN>" + strValues[OBJECT_F_FINANCE_MARGIN] + "</F_FINANCE_MARGIN>");
        strOut.append("<F_RA_MARGIN>" + strValues[OBJECT_F_RA_MARGIN] + "</F_RA_MARGIN>");
        strOut.append("<F_PV_FINANCE_MARGIN>" + strValues[OBJECT_F_PV_FINANCE_MARGIN] + "</F_PV_FINANCE_MARGIN>");
        strOut.append("<F_RA_PV_MARGIN>" + strValues[OBJECT_F_RA_PV_MARGIN] + "</F_RA_PV_MARGIN>");
        strOut.append("<CREDIT_INS>" + strValues[OBJECT_CREDIT_INS] + "</CREDIT_INS>");
        strOut.append("<SW_CRE_INS>" + strValues[OBJECT_SW_CRE_INS] + "</SW_CRE_INS>");
        strOut.append("<CRE_INS_CD>" + strValues[OBJECT_CRE_INS_CD] + "</CRE_INS_CD>");
        strOut.append("<CRE_INS_TM>" + strValues[OBJECT_CRE_INS_TM] + "</CRE_INS_TM>");
        strOut.append("<CRE_INS_RT>" + strValues[OBJECT_CRE_INS_RT] + "</CRE_INS_RT>");
        strOut.append("<SW_S_PRO>" + strValues[OBJECT_SW_S_PRO] + "</SW_S_PRO>");
        strOut.append("<RESERVE1>" + strValues[OBJECT_RESERVE1] + "</RESERVE1>");
        strOut.append("<PRODUCT>" + strValues[OBJECT_PRODUCT] + "</PRODUCT>");
        strOut.append("<LEVERAGE>" + strValues[OBJECT_LEVERAGE] + "</LEVERAGE>");
        strOut.append("<ROE>" + strValues[OBJECT_ROE] + "</ROE>");
        strOut.append("<FP_ROE>" + strValues[OBJECT_FP_ROE] + "</FP_ROE>");
        strOut.append("<PRODUCT_CD>" + strValues[OBJECT_PRODUCT_CD] + "</PRODUCT_CD>");

        //20051207 zj s
        strOut.append(
                "<RESERVE_C_01>" + strValues[OBJECT_RESERVE_C_01] + "</RESERVE_C_01>");
        strOut.append(
                "<RESERVE_C_02>" + strValues[OBJECT_RESERVE_C_02] + "</RESERVE_C_02>");
        strOut.append(
                "<RESERVE_C_03>" + strValues[OBJECT_RESERVE_C_03] + "</RESERVE_C_03>");
        strOut.append(
                "<RESERVE_C_04>" + strValues[OBJECT_RESERVE_C_04] + "</RESERVE_C_04>");
        strOut.append(
                "<RESERVE_C_05>" + strValues[OBJECT_RESERVE_C_05] + "</RESERVE_C_05>");
        strOut.append(
                "<RESERVE_C_06>" + strValues[OBJECT_RESERVE_C_06] + "</RESERVE_C_06>");
        strOut.append(
                "<RESERVE_C_07>" + strValues[OBJECT_RESERVE_C_07] + "</RESERVE_C_07>");
        strOut.append(
                "<RESERVE_C_08>" + strValues[OBJECT_RESERVE_C_08] + "</RESERVE_C_08>");
        strOut.append(
                "<RESERVE_C_09>" + strValues[OBJECT_RESERVE_C_09] + "</RESERVE_C_09>");
        strOut.append(
                "<RESERVE_C_10>" + strValues[OBJECT_RESERVE_C_10] + "</RESERVE_C_10>");
        strOut.append(
                "<RESERVE_C_11>" + strValues[OBJECT_RESERVE_C_11] + "</RESERVE_C_11>");
        strOut.append(
                "<RESERVE_C_12>" + strValues[OBJECT_RESERVE_C_12] + "</RESERVE_C_12>");
        strOut.append(
                "<RESERVE_C_13>" + strValues[OBJECT_RESERVE_C_13] + "</RESERVE_C_13>");
        strOut.append(
                "<RESERVE_C_14>" + strValues[OBJECT_RESERVE_C_14] + "</RESERVE_C_14>");
        strOut.append(
                "<RESERVE_C_15>" + strValues[OBJECT_RESERVE_C_15] + "</RESERVE_C_15>");
        strOut.append(
                "<RESERVE_C_16>" + strValues[OBJECT_RESERVE_C_16] + "</RESERVE_C_16>");
        strOut.append(
                "<RESERVE_C_17>" + strValues[OBJECT_RESERVE_C_17] + "</RESERVE_C_17>");
        strOut.append(
                "<RESERVE_C_18>" + strValues[OBJECT_RESERVE_C_18] + "</RESERVE_C_18>");
        strOut.append(
                "<RESERVE_C_19>" + strValues[OBJECT_RESERVE_C_19] + "</RESERVE_C_19>");
        strOut.append(
                "<RESERVE_C_20>" + strValues[OBJECT_RESERVE_C_20] + "</RESERVE_C_20>");
        strOut.append(
                "<RESERVE_C_21>" + strValues[OBJECT_RESERVE_C_21] + "</RESERVE_C_21>");
        strOut.append(
                "<RESERVE_C_22>" + strValues[OBJECT_RESERVE_C_22] + "</RESERVE_C_22>");
        strOut.append(
                "<RESERVE_C_23>" + strValues[OBJECT_RESERVE_C_23] + "</RESERVE_C_23>");
        strOut.append(
                "<RESERVE_C_24>" + strValues[OBJECT_RESERVE_C_24] + "</RESERVE_C_24>");
        strOut.append(
                "<RESERVE_C_25>" + strValues[OBJECT_RESERVE_C_25] + "</RESERVE_C_25>");
        strOut.append(
                "<RESERVE_C_26>" + strValues[OBJECT_RESERVE_C_26] + "</RESERVE_C_26>");
        strOut.append(
                "<RESERVE_C_27>" + strValues[OBJECT_RESERVE_C_27] + "</RESERVE_C_27>");
        strOut.append(
                "<RESERVE_C_28>" + strValues[OBJECT_RESERVE_C_28] + "</RESERVE_C_28>");
        strOut.append(
                "<RESERVE_C_29>" + strValues[OBJECT_RESERVE_C_29] + "</RESERVE_C_29>");
        strOut.append(
                "<RESERVE_C_30>" + strValues[OBJECT_RESERVE_C_30] + "</RESERVE_C_30>");

        strOut.append(
                "<RESERVE_N_01>" + strValues[OBJECT_RESERVE_N_01] + "</RESERVE_N_01>");
        strOut.append(
                "<RESERVE_N_02>" + strValues[OBJECT_RESERVE_N_02] + "</RESERVE_N_02>");
        strOut.append(
                "<RESERVE_N_03>" + strValues[OBJECT_RESERVE_N_03] + "</RESERVE_N_03>");
        strOut.append(
                "<RESERVE_N_04>" + strValues[OBJECT_RESERVE_N_04] + "</RESERVE_N_04>");
        strOut.append(
                "<RESERVE_N_05>" + strValues[OBJECT_RESERVE_N_05] + "</RESERVE_N_05>");
        strOut.append(
                "<RESERVE_N_06>" + strValues[OBJECT_RESERVE_N_06] + "</RESERVE_N_06>");
        strOut.append(
                "<RESERVE_N_07>" + strValues[OBJECT_RESERVE_N_07] + "</RESERVE_N_07>");
        strOut.append(
                "<RESERVE_N_08>" + strValues[OBJECT_RESERVE_N_08] + "</RESERVE_N_08>");
        strOut.append(
                "<RESERVE_N_09>" + strValues[OBJECT_RESERVE_N_09] + "</RESERVE_N_09>");
        strOut.append(
                "<RESERVE_N_10>" + strValues[OBJECT_RESERVE_N_10] + "</RESERVE_N_10>");
        strOut.append(
                "<RESERVE_N_11>" + strValues[OBJECT_RESERVE_N_11] + "</RESERVE_N_11>");
        strOut.append(
                "<RESERVE_N_12>" + strValues[OBJECT_RESERVE_N_12] + "</RESERVE_N_12>");
        strOut.append(
                "<RESERVE_N_13>" + strValues[OBJECT_RESERVE_N_13] + "</RESERVE_N_13>");
        strOut.append(
                "<RESERVE_N_14>" + strValues[OBJECT_RESERVE_N_14] + "</RESERVE_N_14>");
        strOut.append(
                "<RESERVE_N_15>" + strValues[OBJECT_RESERVE_N_15] + "</RESERVE_N_15>");
        strOut.append(
                "<RESERVE_N_16>" + strValues[OBJECT_RESERVE_N_16] + "</RESERVE_N_16>");
        strOut.append(
                "<RESERVE_N_17>" + strValues[OBJECT_RESERVE_N_17] + "</RESERVE_N_17>");
        strOut.append(
                "<RESERVE_N_18>" + strValues[OBJECT_RESERVE_N_18] + "</RESERVE_N_18>");
        strOut.append(
                "<RESERVE_N_19>" + strValues[OBJECT_RESERVE_N_19] + "</RESERVE_N_19>");
        strOut.append(
                "<RESERVE_N_20>" + strValues[OBJECT_RESERVE_N_20] + "</RESERVE_N_20>");
        strOut.append(
                "<RESERVE_N_21>" + strValues[OBJECT_RESERVE_N_21] + "</RESERVE_N_21>");
        strOut.append(
                "<RESERVE_N_22>" + strValues[OBJECT_RESERVE_N_22] + "</RESERVE_N_22>");
        strOut.append(
                "<RESERVE_N_23>" + strValues[OBJECT_RESERVE_N_23] + "</RESERVE_N_23>");
        strOut.append(
                "<RESERVE_N_24>" + strValues[OBJECT_RESERVE_N_24] + "</RESERVE_N_24>");
        strOut.append(
                "<RESERVE_N_25>" + strValues[OBJECT_RESERVE_N_25] + "</RESERVE_N_25>");
        strOut.append(
                "<RESERVE_N_26>" + strValues[OBJECT_RESERVE_N_26] + "</RESERVE_N_26>");
        strOut.append(
                "<RESERVE_N_27>" + strValues[OBJECT_RESERVE_N_27] + "</RESERVE_N_27>");
        strOut.append(
                "<RESERVE_N_28>" + strValues[OBJECT_RESERVE_N_28] + "</RESERVE_N_28>");
        strOut.append(
                "<RESERVE_N_29>" + strValues[OBJECT_RESERVE_N_29] + "</RESERVE_N_29>");
        strOut.append(
                "<RESERVE_N_30>" + strValues[OBJECT_RESERVE_N_30] + "</RESERVE_N_30>");
        //20051207 zj e

        strOut.append("</ROW>");
        _previousStrBuffer.insert(nOffset, strOut.toString());
        String strChangeTmp = strValues[OBJECT_REC_NO];
        strValues[OBJECT_REC_NO] = strValues[OBJECT_BUKKEN_NO];
        strValues[OBJECT_BUKKEN_NO] = strChangeTmp;
        //Attention:RecNo and BukkenNo had changed!!!
        //Because XML file's order had changed!!!
        _previousObjectXmlReader.insertRow(strValues);
        getPreviousQueryResults(strValues[OBJECT_BUKKEN_NO]);
        return true;
    }
    //20051108 zj e

    /**
     * 前物件があるかどうかをチェックするメソッド。
     * @param   無し
     * @return  boolean true: 前物件がある。
     *                  false:前物件がない。
     */
    public boolean doPreBukenExistCheck() {
        if (_strLeaseResults == null || _strLeaseResults.length == 0) {
            return false;
        }
        if (_nDisplayIndex == -99999999) {
            return true;
        }
        if (_nDisplayIndex <= 0) {
            return false;
        }
        return true;
    }

    /**
     * 次物件があるかどうかをチェックするメソッド。
     * @param   無し
     * @return  boolean true: 次物件がある。
     *                  false:次物件がない。
     */
    public boolean doNextBukenExistCheck() {
        if (_strLeaseResults == null || _strLeaseResults.length == 0) {
            return false;
        }
        if (_nDisplayIndex >= _strLeaseResults.length - 1) {
            return false;
        }
        return true;
    }

    /**
     * 前物件インデックスを表示するメソッド。
     * @param   無し。
     * @return  無し。
     */
    public void setPreIndex() {
        if (_nDisplayIndex == -99999999) {
            _nDisplayIndex = 0;
        } else {
            _nDisplayIndex = _nDisplayIndex - 1;
        }
    }

    /**
     * 次物件インデックスを表示するメソッド。
     * @param   無し。
     * @return  無し。
     */
    public void setNextIndex() {
        if (_nDisplayIndex == -99999999) {
            _nDisplayIndex = 0;
        } else {
            _nDisplayIndex = _nDisplayIndex + 1;
        }
    }

    /**
     * 物件インデックスを設定するメソッド。
     * @param   無し。
     * @return  無し。
     */
    public void setIndex(int nDisplayIndex) {
        _nDisplayIndex = nDisplayIndex;
    }
//ltq 20050131 start

    public void setDelflg(boolean nDisplayIndex) {
        _fDelflg = nDisplayIndex;
    }

    public boolean getDelflg() {
        return _fDelflg;
    }

//ltq 20050131 end
    /**
     * 物件インデックスを取得するメソッド。
     * @param   無し。
     * @return  無し。
     */
    public int getIndex() {
        return _nDisplayIndex;
    }

    /**
     * インデックスの_nBukenIndexの物件レコードを戻すメソッド。
     * @param   無し。
     * @return  無し。
     */
    public String[] getDisplayRec() {
        if (isResultsNull()) {
            return new String[0];
        }
        return _strLeaseResults[_nDisplayIndex];
    }

    public String[] getCopyRec(String strRecNo, String strBukenNo) {
        String[][] strEstResults = getQueryResultsForEstCopy(strRecNo);
        for (int i = 0; i < strEstResults.length; i++) {
            if (strBukenNo.equals(strEstResults[i][OBJECT_BUKKEN_NO])) {
                return strEstResults[i];
            }
        }
        return new String[0];
    }

    /**
     * 結果集がNULLかどうかを判断するメソッド。
     * @param   無し。
     * @return  無し。
     */
    public boolean isResultsNull() {
        if (_strLeaseResults == null || _strLeaseResults.length == 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * インデックスの_nBukenIndexの物件レコードを戻すメソッド。
     * @param   無し。
     * @return  無し。
     */
    public String[] getCalRec(String strBukenNo) {
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strBukenNo.equals(_strLeaseResults[i][OBJECT_BUKKEN_NO])) {
                return _strLeaseResults[i];
            }
        }
        return new String[0];
    }

    /**
     * インデックスの_nBukenIndexの物件レコードを戻すメソッド。
     * @param   無し。
     * @return  無し。
     */
    public String getDisplayBukenNo() {
        return _strLeaseResults[_nDisplayIndex][OBJECT_BUKKEN_NO];
    }

    /**
     * 入力する物件Noは新しい物件Noかどうかのチェックメソッド．     <BR>
     *
     * @param   nBukenNo 入力の物件No。
     * @return  boolean  true：存在。
     *                   false：存在しない。
     */
    public boolean doBukenNoExistCheck(String strBukenNo) {
        if (isResultsNull()) {
            return false;
        }
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strBukenNo.equals(_strLeaseResults[i][OBJECT_BUKKEN_NO])) {
                return true;
            }
        }
        return false;
    }

    /**
     * 物件No -> 物件Fromは新しい物件Noかどうかのチェックメソッド．     <BR>
     *
     * @param   nBukenNo 入力の物件No。
     * @return  boolean  true：存在。
     *                   false：存在しない。
     */
    public int getExistBukenNoIndex(String strBukenNo) {
        if (isResultsNull()) {
            return -1;
        }
        int nBukenNo = LfcFrmComm.toInt(strBukenNo);
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_FR]) <= nBukenNo &&
                    nBukenNo <= LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_TO])) {
                return i;
            }
        }
        return -1;
    }
//20040718 ltq

    /**
     * 物件No -> 物件Fromは新しい物件Noかどうかのチェックメソッド．     <BR>
     *
     * @param   nBukenNo 入力の物件From,入力の物件To。
     * @return  boolean  true：存在。
     *                   false：存在しない。
     */
    public boolean getExistBukenFromToExitCheck(String strBukenFrom, String strBukenTo) {
        if (isResultsNull()) {
            return false;
        }
        int nBukenFrom = LfcFrmComm.toInt(strBukenFrom);
        int nBukenTo = LfcFrmComm.toInt(strBukenTo);
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_FR]) <= nBukenFrom &&
                    nBukenFrom <= LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_TO])) {
                return true;
            }
        }
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_FR]) <= nBukenTo &&
                    nBukenTo <= LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_TO])) {
                return true;
            }
        }
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (nBukenFrom <= LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_FR]) &&
                    LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_FR]) <= nBukenTo) {
                return true;
            }
        }
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (nBukenFrom <= LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_FR]) &&
                    LfcFrmComm.toInt(_strLeaseResults[i][OBJECT_BUKKEN_TO]) <= nBukenTo) {
                return true;
            }
        }
        return false;
    }

    public void setNewIndex(String strDisplayBukenNo) {
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strDisplayBukenNo.equals(_strLeaseResults[i][OBJECT_BUKKEN_NO])) {
                _nDisplayIndex = i;
                return;
            }
        }
        _nDisplayIndex = -1;
    }

    public boolean copyRecord(String[] strCopy) {
        if (isResultsNull()) {
            return true;
        }
        int nIndex = 0;
        int nUpdateIndex = 0;
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strCopy[OBJECT_BUKKEN_NO].equals(_strLeaseResults[i][OBJECT_BUKKEN_NO])) {
                nUpdateIndex = i;
                break;
            }
        }
        int[] nNoUse = new int[0];
        String[] strInsertRecord = new String[_strLeaseResults[nUpdateIndex].length];
        for (int i = 0; i < _strLeaseResults[nUpdateIndex].length; i++) {
            strInsertRecord[i] = _strLeaseResults[nUpdateIndex][i];
        }
        strInsertRecord[OBJECT_BUKKEN_NO] = strCopy[2];
        strInsertRecord[OBJECT_BUKKEN_FR] = strCopy[2];
        strInsertRecord[OBJECT_BUKKEN_TO] = strCopy[3];

        insertRecord(nNoUse, strInsertRecord);

        //refresh array
        String strChangeTmp = strInsertRecord[OBJECT_REC_NO];
        strInsertRecord[OBJECT_REC_NO] = strInsertRecord[OBJECT_BUKKEN_NO];
        strInsertRecord[OBJECT_BUKKEN_NO] = strChangeTmp;
        _objectXmlReader.insertRow(strInsertRecord);
        //Attention:RecNo and BukkenNo had changed!!!
        //Because XML file's order had changed!!!
        getQueryResults(strInsertRecord[OBJECT_REC_NO]);
        /*
        String[][] strTempArr;
        if(_strLeaseResults == null) {
        strTempArr = new String[1][OBJECT_RECORD_COUNT];
        } else {
        strTempArr = new String[_strLeaseResults.length + 1][OBJECT_RECORD_COUNT];
        }
        System.arraycopy(_strLeaseResults, 0, strTempArr, 0, _strLeaseResults.length);
        System.arraycopy(strTempArr[nUpdateIndex], 0, strTempArr[_strLeaseResults.length], 0, strTempArr[nUpdateIndex].length);
        strTempArr[_strLeaseResults.length][OBJECT_BUKKEN_NO] = strCopy[2];
        strTempArr[_strLeaseResults.length][OBJECT_BUKKEN_FR] = strCopy[2];
        strTempArr[_strLeaseResults.length][OBJECT_BUKKEN_TO] = strCopy[3];
        _strLeaseResults = strTempArr;
         */
        return true;
    }

    public boolean CreateXml() {
        _strBuffer.append("<?xml version=\"1.0\" encoding=\"Shift_JIS\" standalone=\"no\"?>");
        _strBuffer.append("<OBJECT xmlns=\"http://www.gecl.co.jp/OBJECT\">");
        _strBuffer.append("</OBJECT>");
        doCommit();
        return true;
    }

    //20051108 zj s
    public boolean createPreviousXml() {
        //ydy add 20080414 s
        _previousStrBuffer = new StringBuffer();
        //ydy add 20080414 e
        _previousStrBuffer.append("<?xml version=\"1.0\" encoding=\"Shift_JIS\" standalone=\"no\"?>");
        _previousStrBuffer.append("<OBJECT xmlns=\"http://www.gecl.co.jp/OBJECT\">");
        _previousStrBuffer.append("</OBJECT>");
        doPreviousCommit();
        return true;
    }
    //20051108 zj e

    public void CreatePDFXml() {
        String[][] strValues = _strLeaseResults;
        StringBuffer strOut = new StringBuffer();
        strOut.append(
                "<?xml version=\"1.0\" encoding=\"Shift_JIS\" standalone=\"no\"?>");
        strOut.append("<OBJECT xmlns=\"http://www.gecl.co.jp/OBJECT\">");
        for (int i = 0; i < strValues.length; i++) {
            strOut.append("<ROW BUKKEN_NO=\"");
            strOut.append(strValues[i][OBJECT_BUKKEN_NO]);
            strOut.append("\" REC_NO=\"");
            strOut.append(strValues[i][OBJECT_REC_NO]);
            strOut.append("\">");
            strOut.append("<BUKKEN_FR>" + strValues[i][OBJECT_BUKKEN_FR] + "</BUKKEN_FR>");
            strOut.append("<BUKKEN_TO>" + strValues[i][OBJECT_BUKKEN_TO] + "</BUKKEN_TO>");
            strOut.append("<DATE_KENSH>" + strValues[i][OBJECT_DATE_KENSH] + "</DATE_KENSH>");
            strOut.append("<PURCHASE>" + strValues[i][OBJECT_PURCHASE] + "</PURCHASE>");
            strOut.append("<QUANTITY>" + strValues[i][OBJECT_QUANTITY] + "</QUANTITY>");
            strOut.append("<SW_PAY>" + strValues[i][OBJECT_SW_PAY] + "</SW_PAY>");
            strOut.append("<DATE_PAYMT>" + strValues[i][OBJECT_DATE_PAYMT] + "</DATE_PAYMT>");
            strOut.append("<REMAIN_VAL>" + strValues[i][OBJECT_REMAIN_VAL] + "</REMAIN_VAL>");
            strOut.append("<REM_VAL_RT>" + strValues[i][OBJECT_REM_VAL_RT] + "</REM_VAL_RT>");
            strOut.append("<DURABLE_Y>" + strValues[i][OBJECT_DURABLE_Y] + "</DURABLE_Y>");
            strOut.append("<LEASE_M>" + strValues[i][OBJECT_LEASE_M] + "</LEASE_M>");
            strOut.append("<RATE_JLC>" + strValues[i][OBJECT_RATE_JLC] + "</RATE_JLC>");
            strOut.append("<RATE_C_ADJ>" + strValues[i][OBJECT_RATE_C_ADJ] + "</RATE_C_ADJ>");
            strOut.append("<RATE_E_ANI>" + strValues[i][OBJECT_RATE_E_ANI] + "</RATE_E_ANI>");
            strOut.append("<RATE_E_A_O>" + strValues[i][OBJECT_RATE_E_A_O] + "</RATE_E_A_O>");
            strOut.append("<RATE_E_A_S>" + strValues[i][OBJECT_RATE_E_A_S] + "</RATE_E_A_S>");
            strOut.append("<RATE_LOSS>" + strValues[i][OBJECT_RATE_LOSS] + "</RATE_LOSS>");
            strOut.append("<CSTKISHUCD>" + strValues[i][OBJECT_CSTKISHUCD] + "</CSTKISHUCD>");
            strOut.append("<CSTSELINFO>" + strValues[i][OBJECT_CSTSELINFO] + "</CSTSELINFO>");
            strOut.append("<RATE_FEE>" + strValues[i][OBJECT_RATE_FEE] + "</RATE_FEE>");
            strOut.append("<RATE_FEE_N>" + strValues[i][OBJECT_RATE_FEE_N] + "</RATE_FEE_N>");
            strOut.append("<RATE_FEE_R>" + strValues[i][OBJECT_RATE_FEE_R] + "</RATE_FEE_R>");
            strOut.append("<DOSO_RATE>" + strValues[i][OBJECT_DOSO_RATE] + "</DOSO_RATE>");
            strOut.append("<SW_SOFT>" + strValues[i][OBJECT_SW_SOFT] + "</SW_SOFT>");
            strOut.append("<FIXASTTAX>" + strValues[i][OBJECT_FIXASTTAX] + "</FIXASTTAX>");
            strOut.append("<DOSO_INDEX>" + strValues[i][OBJECT_DOSO_INDEX] + "</DOSO_INDEX>");
            strOut.append("<DOSO_FEE>" + strValues[i][OBJECT_DOSO_FEE] + "</DOSO_FEE>");
            strOut.append("<SW_BAISEKI>" + strValues[i][OBJECT_SW_BAISEKI] + "</SW_BAISEKI>");
            strOut.append("<DANSHIN_RT>" + strValues[i][OBJECT_DANSHIN_RT] + "</DANSHIN_RT>");
            strOut.append("<MACHI_FEE>" + strValues[i][OBJECT_MACHI_FEE] + "</MACHI_FEE>");
            strOut.append("<FIRE_FEE>" + strValues[i][OBJECT_FIRE_FEE] + "</FIRE_FEE>");
            strOut.append("<ETC_FEE>" + strValues[i][OBJECT_ETC_FEE] + "</ETC_FEE>");
            strOut.append("<ICHIJI_1>" + strValues[i][OBJECT_ICHIJI_1] + "</ICHIJI_1>");
            strOut.append("<ICHIJI_2>" + strValues[i][OBJECT_ICHIJI_2] + "</ICHIJI_2>");
            strOut.append("<ICHIJI_3>" + strValues[i][OBJECT_ICHIJI_3] + "</ICHIJI_3>");
            strOut.append("<KURINO_1>" + strValues[i][OBJECT_KURINO_1] + "</KURINO_1>");
            strOut.append("<KURINO_2>" + strValues[i][OBJECT_KURINO_2] + "</KURINO_2>");
            strOut.append("<HOSHURYO>" + strValues[i][OBJECT_HOSHURYO] + "</HOSHURYO>");
            strOut.append("<ASSEN>" + strValues[i][OBJECT_ASSEN] + "</ASSEN>");
            strOut.append("<KAPPU_INS>" + strValues[i][OBJECT_KAPPU_INS] + "</KAPPU_INS>");
            strOut.append("<DATE_INC_0>" + strValues[i][OBJECT_DATE_INC_0] + "</DATE_INC_0>");
            strOut.append("<INCOME_0>" + strValues[i][OBJECT_INCOME_0] + "</INCOME_0>");
            strOut.append("<INC_0_M>" + strValues[i][OBJECT_INC_0_M] + "</INC_0_M>");
            strOut.append("<LEASE_D>" + strValues[i][OBJECT_LEASE_D] + "</LEASE_D>");
            strOut.append("<EVEN_FLG>" + strValues[i][OBJECT_EVEN_FLG] + "</EVEN_FLG>");
            strOut.append("<RYORITSU_T>" + strValues[i][OBJECT_RYORITSU_T] + "</RYORITSU_T>");
            strOut.append("<RYORITSU_M>" + strValues[i][OBJECT_RYORITSU_M] + "</RYORITSU_M>");
            strOut.append("<RATE_UNYO>" + strValues[i][OBJECT_RATE_UNYO] + "</RATE_UNYO>");
            strOut.append("<TRUE_RATE>" + strValues[i][OBJECT_TRUE_RATE] + "</TRUE_RATE>");
            strOut.append("<RATE_ROI>" + strValues[i][OBJECT_RATE_ROI] + "</RATE_ROI>");
            strOut.append("<INTEREST_P>" + strValues[i][OBJECT_INTEREST_P] + "</INTEREST_P>");
            strOut.append("<INTEREST_I>" + strValues[i][OBJECT_INTEREST_I] + "</INTEREST_I>");
            strOut.append("<ZAPI>" + strValues[i][OBJECT_ZAPI] + "</ZAPI>");
            strOut.append("<INSURANCE>" + strValues[i][OBJECT_INSURANCE] + "</INSURANCE>");
            strOut.append("<COST_TOTAL>" + strValues[i][OBJECT_COST_TOTAL] + "</COST_TOTAL>");
            strOut.append("<CHARGE>" + strValues[i][OBJECT_CHARGE] + "</CHARGE>");
            strOut.append("<INCOME_GT>" + strValues[i][OBJECT_INCOME_GT] + "</INCOME_GT>");
            strOut.append("<C_ADJUST>" + strValues[i][OBJECT_C_ADJUST] + "</C_ADJUST>");
            strOut.append("<PROFIT_T>" + strValues[i][OBJECT_PROFIT_T] + "</PROFIT_T>");
            strOut.append("<PROFIT_Y>" + strValues[i][OBJECT_PROFIT_Y] + "</PROFIT_Y>");
            strOut.append("<CAPITAL_T>" + strValues[i][OBJECT_CAPITAL_T] + "</CAPITAL_T>");
            strOut.append("<RAT_PRO_T>" + strValues[i][OBJECT_RAT_PRO_T] + "</RAT_PRO_T>");
            strOut.append("<RAT_PRO_Y>" + strValues[i][OBJECT_RAT_PRO_Y] + "</RAT_PRO_Y>");
            strOut.append("<RATE_YEAR>" + strValues[i][OBJECT_RATE_YEAR] + "</RATE_YEAR>");
            strOut.append("<ADJUST_M>" + strValues[i][OBJECT_ADJUST_M] + "</ADJUST_M>");
            strOut.append("<ADJUST_D>" + strValues[i][OBJECT_ADJUST_D] + "</ADJUST_D>");
            strOut.append("<INCOME_T>" + strValues[i][OBJECT_INCOME_T] + "</INCOME_T>");
            strOut.append("<INIT_COST>" + strValues[i][OBJECT_INIT_COST] + "</INIT_COST>");
            strOut.append("<EXEC_COST>" + strValues[i][OBJECT_EXEC_COST] + "</EXEC_COST>");
            strOut.append("<NET_RATE>" + strValues[i][OBJECT_NET_RATE] + "</NET_RATE>");
            strOut.append("<FINANCE_MARGIN>" + strValues[i][OBJECT_FINANCE_MARGIN] + "</FINANCE_MARGIN>");
            strOut.append("<RA_MARGIN>" + strValues[i][OBJECT_RA_MARGIN] + "</RA_MARGIN>");
            strOut.append("<PV_FINANCE_MARGIN>" + strValues[i][OBJECT_PV_FINANCE_MARGIN] + "</PV_FINANCE_MARGIN>");
            strOut.append("<RA_PV_MARGIN>" + strValues[i][OBJECT_RA_PV_MARGIN] + "</RA_PV_MARGIN>");
            strOut.append("<LEAVE_M>" + strValues[i][OBJECT_LEAVE_M] + "</LEAVE_M>");
            strOut.append("<BAIS_FEE>" + strValues[i][OBJECT_BAIS_FEE] + "</BAIS_FEE>");
            strOut.append("<DAMAGE_BAS>" + strValues[i][OBJECT_DAMAGE_BAS] + "</DAMAGE_BAS>");
            strOut.append("<DAMAGE_FM>" + strValues[i][OBJECT_DAMAGE_FM] + "</DAMAGE_FM>");
            strOut.append("<DAMAGE_LM>" + strValues[i][OBJECT_DAMAGE_LM] + "</DAMAGE_LM>");
            strOut.append("<DAMAGE_FA>" + strValues[i][OBJECT_DAMAGE_FA] + "</DAMAGE_FA>");
            strOut.append("<DAMAGE_LA>" + strValues[i][OBJECT_DAMAGE_LA] + "</DAMAGE_LA>");
            strOut.append("<F_INTER_P>" + strValues[i][OBJECT_F_INTER_P] + "</F_INTER_P>");
            strOut.append("<F_INTER_I>" + strValues[i][OBJECT_F_INTER_I] + "</F_INTER_I>");
            strOut.append("<F_CHARGE>" + strValues[i][OBJECT_F_CHARGE] + "</F_CHARGE>");
            strOut.append("<F_EXEC_C>" + strValues[i][OBJECT_F_EXEC_C] + "</F_EXEC_C>");
            strOut.append("<F_KURI_1>" + strValues[i][OBJECT_F_KURI_1] + "</F_KURI_1>");
            strOut.append("<F_INSUR>" + strValues[i][OBJECT_F_INSUR] + "</F_INSUR>");
            strOut.append("<F_COST_T>" + strValues[i][OBJECT_F_COST_T] + "</F_COST_T>");
            strOut.append("<F_PRO_T>" + strValues[i][OBJECT_F_PRO_T] + "</F_PRO_T>");
            strOut.append("<F_PRO_Y>" + strValues[i][OBJECT_F_PRO_Y] + "</F_PRO_Y>");
            strOut.append("<F_CAPIT_T>" + strValues[i][OBJECT_F_CAPIT_T] + "</F_CAPIT_T>");
            strOut.append("<F_TRUE_RT>" + strValues[i][OBJECT_F_TRUE_RT] + "</F_TRUE_RT>");
            strOut.append("<F_RT_YR>" + strValues[i][OBJECT_F_RT_YR] + "</F_RT_YR>");
            strOut.append("<F_RT_UN>" + strValues[i][OBJECT_F_RT_UN] + "</F_RT_UN>");
            strOut.append("<F_RT_PRT>" + strValues[i][OBJECT_F_RT_PRT] + "</F_RT_PRT>");
            strOut.append("<F_RT_PRY>" + strValues[i][OBJECT_F_RT_PRY] + "</F_RT_PRY>");
            strOut.append("<F_RT_ROI>" + strValues[i][OBJECT_F_RT_ROI] + "</F_RT_ROI>");
            strOut.append("<F_FINANCE_MARGIN>" + strValues[i][OBJECT_F_FINANCE_MARGIN] + "</F_FINANCE_MARGIN>");
            strOut.append("<F_RA_MARGIN>" + strValues[i][OBJECT_F_RA_MARGIN] + "</F_RA_MARGIN>");
            strOut.append("<F_PV_FINANCE_MARGIN>" + strValues[i][OBJECT_F_PV_FINANCE_MARGIN] + "</F_PV_FINANCE_MARGIN>");
            strOut.append("<F_RA_PV_MARGIN>" + strValues[i][OBJECT_F_RA_PV_MARGIN] + "</F_RA_PV_MARGIN>");
            strOut.append("<CREDIT_INS>" + strValues[i][OBJECT_CREDIT_INS] + "</CREDIT_INS>");
            strOut.append("<SW_CRE_INS>" + strValues[i][OBJECT_SW_CRE_INS] + "</SW_CRE_INS>");
            strOut.append("<CRE_INS_CD>" + strValues[i][OBJECT_CRE_INS_CD] + "</CRE_INS_CD>");
            strOut.append("<CRE_INS_TM>" + strValues[i][OBJECT_CRE_INS_TM] + "</CRE_INS_TM>");
            strOut.append("<CRE_INS_RT>" + strValues[i][OBJECT_CRE_INS_RT] + "</CRE_INS_RT>");
            strOut.append("<SW_S_PRO>" + strValues[i][OBJECT_SW_S_PRO] + "</SW_S_PRO>");
            //ydy modify 20080417 s
//			strOut.append("<RESERVE1>" + strValues[i][OBJECT_RESERVE1] + "</RESERVE1>");
            //ydy modify 20080812 s
//			String strNewReserve[] = LfcFrmComm.getBunKatuValue(strValues[i][OBJECT_RESERVE1],25);
            String strNewReserve[] = LfcFrmComm.getBunKatuValue(strValues[i][OBJECT_RESERVE1], 26);
            //ydy modify 20080812 e
            strOut.append("<RESERVE1_1>" + strNewReserve[0] + "</RESERVE1_1>");
            strOut.append("<RESERVE1_2>" + strNewReserve[1] + "</RESERVE1_2>");
            //ydy modify 20080417 e
            strOut.append("<PRODUCT>" + strValues[i][OBJECT_PRODUCT] + "</PRODUCT>");
            strOut.append("<LEVERAGE>" + strValues[i][OBJECT_LEVERAGE] + "</LEVERAGE>");
            strOut.append("<ROE>" + strValues[i][OBJECT_ROE] + "</ROE>");
            strOut.append("<FP_ROE>" + strValues[i][OBJECT_FP_ROE] + "</FP_ROE>");
            strOut.append("<PRODUCT_CD>" + strValues[i][OBJECT_PRODUCT_CD] + "</PRODUCT_CD>");

            //20051207 zj s
            strOut.append(
                    "<RESERVE_C_01>" + strValues[i][OBJECT_RESERVE_C_01] + "</RESERVE_C_01>");
            strOut.append(
                    "<RESERVE_C_02>" + strValues[i][OBJECT_RESERVE_C_02] + "</RESERVE_C_02>");
            strOut.append(
                    "<RESERVE_C_03>" + strValues[i][OBJECT_RESERVE_C_03] + "</RESERVE_C_03>");
            strOut.append(
                    "<RESERVE_C_04>" + strValues[i][OBJECT_RESERVE_C_04] + "</RESERVE_C_04>");
            strOut.append(
                    "<RESERVE_C_05>" + strValues[i][OBJECT_RESERVE_C_05] + "</RESERVE_C_05>");
            strOut.append(
                    "<RESERVE_C_06>" + strValues[i][OBJECT_RESERVE_C_06] + "</RESERVE_C_06>");
            strOut.append(
                    "<RESERVE_C_07>" + strValues[i][OBJECT_RESERVE_C_07] + "</RESERVE_C_07>");
            strOut.append(
                    "<RESERVE_C_08>" + strValues[i][OBJECT_RESERVE_C_08] + "</RESERVE_C_08>");
            strOut.append(
                    "<RESERVE_C_09>" + strValues[i][OBJECT_RESERVE_C_09] + "</RESERVE_C_09>");
            strOut.append(
                    "<RESERVE_C_10>" + strValues[i][OBJECT_RESERVE_C_10] + "</RESERVE_C_10>");
            strOut.append(
                    "<RESERVE_C_11>" + strValues[i][OBJECT_RESERVE_C_11] + "</RESERVE_C_11>");
            strOut.append(
                    "<RESERVE_C_12>" + strValues[i][OBJECT_RESERVE_C_12] + "</RESERVE_C_12>");
            strOut.append(
                    "<RESERVE_C_13>" + strValues[i][OBJECT_RESERVE_C_13] + "</RESERVE_C_13>");
            strOut.append(
                    "<RESERVE_C_14>" + strValues[i][OBJECT_RESERVE_C_14] + "</RESERVE_C_14>");
            strOut.append(
                    "<RESERVE_C_15>" + strValues[i][OBJECT_RESERVE_C_15] + "</RESERVE_C_15>");
            strOut.append(
                    "<RESERVE_C_16>" + strValues[i][OBJECT_RESERVE_C_16] + "</RESERVE_C_16>");
            strOut.append(
                    "<RESERVE_C_17>" + strValues[i][OBJECT_RESERVE_C_17] + "</RESERVE_C_17>");
            strOut.append(
                    "<RESERVE_C_18>" + strValues[i][OBJECT_RESERVE_C_18] + "</RESERVE_C_18>");
            strOut.append(
                    "<RESERVE_C_19>" + strValues[i][OBJECT_RESERVE_C_19] + "</RESERVE_C_19>");
            strOut.append(
                    "<RESERVE_C_20>" + strValues[i][OBJECT_RESERVE_C_20] + "</RESERVE_C_20>");
            strOut.append(
                    "<RESERVE_C_21>" + strValues[i][OBJECT_RESERVE_C_21] + "</RESERVE_C_21>");
            strOut.append(
                    "<RESERVE_C_22>" + strValues[i][OBJECT_RESERVE_C_22] + "</RESERVE_C_22>");
            strOut.append(
                    "<RESERVE_C_23>" + strValues[i][OBJECT_RESERVE_C_23] + "</RESERVE_C_23>");
            strOut.append(
                    "<RESERVE_C_24>" + strValues[i][OBJECT_RESERVE_C_24] + "</RESERVE_C_24>");
            strOut.append(
                    "<RESERVE_C_25>" + strValues[i][OBJECT_RESERVE_C_25] + "</RESERVE_C_25>");
            strOut.append(
                    "<RESERVE_C_26>" + strValues[i][OBJECT_RESERVE_C_26] + "</RESERVE_C_26>");
            strOut.append(
                    "<RESERVE_C_27>" + strValues[i][OBJECT_RESERVE_C_27] + "</RESERVE_C_27>");
            strOut.append(
                    "<RESERVE_C_28>" + strValues[i][OBJECT_RESERVE_C_28] + "</RESERVE_C_28>");
            strOut.append(
                    "<RESERVE_C_29>" + strValues[i][OBJECT_RESERVE_C_29] + "</RESERVE_C_29>");
            strOut.append(
                    "<RESERVE_C_30>" + strValues[i][OBJECT_RESERVE_C_30] + "</RESERVE_C_30>");

            strOut.append(
                    "<RESERVE_N_01>" + strValues[i][OBJECT_RESERVE_N_01] + "</RESERVE_N_01>");
            strOut.append(
                    "<RESERVE_N_02>" + strValues[i][OBJECT_RESERVE_N_02] + "</RESERVE_N_02>");
            strOut.append(
                    "<RESERVE_N_03>" + strValues[i][OBJECT_RESERVE_N_03] + "</RESERVE_N_03>");
            strOut.append(
                    "<RESERVE_N_04>" + strValues[i][OBJECT_RESERVE_N_04] + "</RESERVE_N_04>");
            strOut.append(
                    "<RESERVE_N_05>" + strValues[i][OBJECT_RESERVE_N_05] + "</RESERVE_N_05>");
            strOut.append(
                    "<RESERVE_N_06>" + strValues[i][OBJECT_RESERVE_N_06] + "</RESERVE_N_06>");
            strOut.append(
                    "<RESERVE_N_07>" + strValues[i][OBJECT_RESERVE_N_07] + "</RESERVE_N_07>");
            strOut.append(
                    "<RESERVE_N_08>" + strValues[i][OBJECT_RESERVE_N_08] + "</RESERVE_N_08>");
            strOut.append(
                    "<RESERVE_N_09>" + strValues[i][OBJECT_RESERVE_N_09] + "</RESERVE_N_09>");
            strOut.append(
                    "<RESERVE_N_10>" + strValues[i][OBJECT_RESERVE_N_10] + "</RESERVE_N_10>");
            strOut.append(
                    "<RESERVE_N_11>" + strValues[i][OBJECT_RESERVE_N_11] + "</RESERVE_N_11>");
            strOut.append(
                    "<RESERVE_N_12>" + strValues[i][OBJECT_RESERVE_N_12] + "</RESERVE_N_12>");
            strOut.append(
                    "<RESERVE_N_13>" + strValues[i][OBJECT_RESERVE_N_13] + "</RESERVE_N_13>");
            strOut.append(
                    "<RESERVE_N_14>" + strValues[i][OBJECT_RESERVE_N_14] + "</RESERVE_N_14>");
            strOut.append(
                    "<RESERVE_N_15>" + strValues[i][OBJECT_RESERVE_N_15] + "</RESERVE_N_15>");
            strOut.append(
                    "<RESERVE_N_16>" + strValues[i][OBJECT_RESERVE_N_16] + "</RESERVE_N_16>");
            strOut.append(
                    "<RESERVE_N_17>" + strValues[i][OBJECT_RESERVE_N_17] + "</RESERVE_N_17>");
            strOut.append(
                    "<RESERVE_N_18>" + strValues[i][OBJECT_RESERVE_N_18] + "</RESERVE_N_18>");
            strOut.append(
                    "<RESERVE_N_19>" + strValues[i][OBJECT_RESERVE_N_19] + "</RESERVE_N_19>");
            strOut.append(
                    "<RESERVE_N_20>" + strValues[i][OBJECT_RESERVE_N_20] + "</RESERVE_N_20>");
            strOut.append(
                    "<RESERVE_N_21>" + strValues[i][OBJECT_RESERVE_N_21] + "</RESERVE_N_21>");
            strOut.append(
                    "<RESERVE_N_22>" + strValues[i][OBJECT_RESERVE_N_22] + "</RESERVE_N_22>");
            strOut.append(
                    "<RESERVE_N_23>" + strValues[i][OBJECT_RESERVE_N_23] + "</RESERVE_N_23>");
            strOut.append(
                    "<RESERVE_N_24>" + strValues[i][OBJECT_RESERVE_N_24] + "</RESERVE_N_24>");
            strOut.append(
                    "<RESERVE_N_25>" + strValues[i][OBJECT_RESERVE_N_25] + "</RESERVE_N_25>");
            strOut.append(
                    "<RESERVE_N_26>" + strValues[i][OBJECT_RESERVE_N_26] + "</RESERVE_N_26>");
            strOut.append(
                    "<RESERVE_N_27>" + strValues[i][OBJECT_RESERVE_N_27] + "</RESERVE_N_27>");
            strOut.append(
                    "<RESERVE_N_28>" + strValues[i][OBJECT_RESERVE_N_28] + "</RESERVE_N_28>");
            strOut.append(
                    "<RESERVE_N_29>" + strValues[i][OBJECT_RESERVE_N_29] + "</RESERVE_N_29>");
            strOut.append(
                    "<RESERVE_N_30>" + strValues[i][OBJECT_RESERVE_N_30] + "</RESERVE_N_30>");
            //20051207 zj e

            strOut.append("</ROW>");
        }
        strOut.append("</OBJECT>");
        try {
            FileWriter fw = new FileWriter(LfcDBConfig.getXmlTempFolder() + "TPDFOBJECT.xml");
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(strOut.toString());
            pw.close();
        } catch (IOException e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("ObjectBean.CreatePDFXml()", //クラス名
                    strOut.toString(), //メソッド名
                    LfcDBConfig.getXmlTempFolder() + "TPDFOBJECT.xmlへ書き出すときエラー", //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
        }
        return;
    }

    public void setFieldName() {
        String[] tmpStrName = {
            "BUKKEN_NO",
            "REC_NO",
            "BUKKEN_FR",
            "BUKKEN_TO",
            "DATE_KENSH",
            "PURCHASE",
            "QUANTITY",
            "SW_PAY",
            "DATE_PAYMT",
            "REMAIN_VAL",
            "REM_VAL_RT",
            "DURABLE_Y",
            "LEASE_M",
            "RATE_JLC",
            "RATE_C_ADJ",
            "RATE_E_ANI",
            "RATE_E_A_O",
            "RATE_E_A_S",
            "RATE_LOSS",
            "CSTKISHUCD",
            "CSTSELINFO",
            "RATE_FEE",
            "RATE_FEE_N",
            "RATE_FEE_R",
            "DOSO_RATE",
            "SW_SOFT",
            "FIXASTTAX",
            "DOSO_INDEX",
            "DOSO_FEE",
            "SW_BAISEKI",
            "DANSHIN_RT",
            "MACHI_FEE",
            "FIRE_FEE",
            "ETC_FEE",
            "ICHIJI_1",
            "ICHIJI_2",
            "ICHIJI_3",
            "KURINO_1",
            "KURINO_2",
            "HOSHURYO",
            "ASSEN",
            "KAPPU_INS",
            "DATE_INC_0",
            "INCOME_0",
            "INC_0_M",
            "LEASE_D",
            "EVEN_FLG",
            "RYORITSU_T",
            "RYORITSU_M",
            "RATE_UNYO",
            "TRUE_RATE",
            "RATE_ROI",
            "INTEREST_P",
            "INTEREST_I",
            "ZAPI",
            "INSURANCE",
            "COST_TOTAL",
            "CHARGE",
            "INCOME_GT",
            "C_ADJUST",
            "PROFIT_T",
            "PROFIT_Y",
            "CAPITAL_T",
            "RAT_PRO_T",
            "RAT_PRO_Y",
            "RATE_YEAR",
            "ADJUST_M",
            "ADJUST_D",
            "INCOME_T",
            "INIT_COST",
            "EXEC_COST",
            "NET_RATE",
            "FINANCE_MARGIN",
            "RA_MARGIN",
            "PV_FINANCE_MARGIN",
            "RA_PV_MARGIN",
            "LEAVE_M",
            "BAIS_FEE",
            "DAMAGE_BAS",
            "DAMAGE_FM",
            "DAMAGE_LM",
            "DAMAGE_FA",
            "DAMAGE_LA",
            "F_INTER_P",
            "F_INTER_I",
            "F_CHARGE",
            "F_EXEC_C",
            "F_KURI_1",
            "F_INSUR",
            "F_COST_T",
            "F_PRO_T",
            "F_PRO_Y",
            "F_CAPIT_T",
            "F_TRUE_RT",
            "F_RT_YR",
            "F_RT_UN",
            "F_RT_PRT",
            "F_RT_PRY",
            "F_RT_ROI",
            "F_FINANCE_MARGIN",
            "F_RA_MARGIN",
            "F_PV_FINANCE_MARGIN",
            "F_RA_PV_MARGIN",
            "CREDIT_INS",
            "SW_CRE_INS",
            "CRE_INS_CD",
            "CRE_INS_TM",
            "CRE_INS_RT",
            "SW_S_PRO",
            "RESERVE1",
            "PRODUCT",
            "LEVERAGE",
            "ROE",
            "FP_ROE",
            "PRODUCT_CD" //20051207 zj s
            , "RESERVE_C_01", "RESERVE_C_02", "RESERVE_C_03", "RESERVE_C_04", "RESERVE_C_05", "RESERVE_C_06", "RESERVE_C_07", "RESERVE_C_08", "RESERVE_C_09", "RESERVE_C_10", "RESERVE_C_11", "RESERVE_C_12", "RESERVE_C_13", "RESERVE_C_14", "RESERVE_C_15", "RESERVE_C_16", "RESERVE_C_17", "RESERVE_C_18", "RESERVE_C_19", "RESERVE_C_20", "RESERVE_C_21", "RESERVE_C_22", "RESERVE_C_23", "RESERVE_C_24", "RESERVE_C_25", "RESERVE_C_26", "RESERVE_C_27", "RESERVE_C_28", "RESERVE_C_29", "RESERVE_C_30", "RESERVE_N_01", "RESERVE_N_02", "RESERVE_N_03", "RESERVE_N_04", "RESERVE_N_05", "RESERVE_N_06", "RESERVE_N_07", "RESERVE_N_08", "RESERVE_N_09", "RESERVE_N_10", "RESERVE_N_11", "RESERVE_N_12", "RESERVE_N_13", "RESERVE_N_14", "RESERVE_N_15", "RESERVE_N_16", "RESERVE_N_17", "RESERVE_N_18", "RESERVE_N_19", "RESERVE_N_20", "RESERVE_N_21", "RESERVE_N_22", "RESERVE_N_23", "RESERVE_N_24", "RESERVE_N_25", "RESERVE_N_26", "RESERVE_N_27", "RESERVE_N_28", "RESERVE_N_29", "RESERVE_N_30"
        //20051207 zj e
        };
        _objectXmlReader.setFieldName(tmpStrName);
    }

    //20051108 zj s
    public void setPreviousFieldName() {
        String[] tmpStrName = {
            "BUKKEN_NO",
            "REC_NO",
            "BUKKEN_FR",
            "BUKKEN_TO",
            "DATE_KENSH",
            "PURCHASE",
            "QUANTITY",
            "SW_PAY",
            "DATE_PAYMT",
            "REMAIN_VAL",
            "REM_VAL_RT",
            "DURABLE_Y",
            "LEASE_M",
            "RATE_JLC",
            "RATE_C_ADJ",
            "RATE_E_ANI",
            "RATE_E_A_O",
            "RATE_E_A_S",
            "RATE_LOSS",
            "CSTKISHUCD",
            "CSTSELINFO",
            "RATE_FEE",
            "RATE_FEE_N",
            "RATE_FEE_R",
            "DOSO_RATE",
            "SW_SOFT",
            "FIXASTTAX",
            "DOSO_INDEX",
            "DOSO_FEE",
            "SW_BAISEKI",
            "DANSHIN_RT",
            "MACHI_FEE",
            "FIRE_FEE",
            "ETC_FEE",
            "ICHIJI_1",
            "ICHIJI_2",
            "ICHIJI_3",
            "KURINO_1",
            "KURINO_2",
            "HOSHURYO",
            "ASSEN",
            "KAPPU_INS",
            "DATE_INC_0",
            "INCOME_0",
            "INC_0_M",
            "LEASE_D",
            "EVEN_FLG",
            "RYORITSU_T",
            "RYORITSU_M",
            "RATE_UNYO",
            "TRUE_RATE",
            "RATE_ROI",
            "INTEREST_P",
            "INTEREST_I",
            "ZAPI",
            "INSURANCE",
            "COST_TOTAL",
            "CHARGE",
            "INCOME_GT",
            "C_ADJUST",
            "PROFIT_T",
            "PROFIT_Y",
            "CAPITAL_T",
            "RAT_PRO_T",
            "RAT_PRO_Y",
            "RATE_YEAR",
            "ADJUST_M",
            "ADJUST_D",
            "INCOME_T",
            "INIT_COST",
            "EXEC_COST",
            "NET_RATE",
            "FINANCE_MARGIN",
            "RA_MARGIN",
            "PV_FINANCE_MARGIN",
            "RA_PV_MARGIN",
            "LEAVE_M",
            "BAIS_FEE",
            "DAMAGE_BAS",
            "DAMAGE_FM",
            "DAMAGE_LM",
            "DAMAGE_FA",
            "DAMAGE_LA",
            "F_INTER_P",
            "F_INTER_I",
            "F_CHARGE",
            "F_EXEC_C",
            "F_KURI_1",
            "F_INSUR",
            "F_COST_T",
            "F_PRO_T",
            "F_PRO_Y",
            "F_CAPIT_T",
            "F_TRUE_RT",
            "F_RT_YR",
            "F_RT_UN",
            "F_RT_PRT",
            "F_RT_PRY",
            "F_RT_ROI",
            "F_FINANCE_MARGIN",
            "F_RA_MARGIN",
            "F_PV_FINANCE_MARGIN",
            "F_RA_PV_MARGIN",
            "CREDIT_INS",
            "SW_CRE_INS",
            "CRE_INS_CD",
            "CRE_INS_TM",
            "CRE_INS_RT",
            "SW_S_PRO",
            "RESERVE1",
            "PRODUCT",
            "LEVERAGE",
            "ROE",
            "FP_ROE",
            "PRODUCT_CD" //20051207 zj s
            , "RESERVE_C_01", "RESERVE_C_02", "RESERVE_C_03", "RESERVE_C_04", "RESERVE_C_05", "RESERVE_C_06", "RESERVE_C_07", "RESERVE_C_08", "RESERVE_C_09", "RESERVE_C_10", "RESERVE_C_11", "RESERVE_C_12", "RESERVE_C_13", "RESERVE_C_14", "RESERVE_C_15", "RESERVE_C_16", "RESERVE_C_17", "RESERVE_C_18", "RESERVE_C_19", "RESERVE_C_20", "RESERVE_C_21", "RESERVE_C_22", "RESERVE_C_23", "RESERVE_C_24", "RESERVE_C_25", "RESERVE_C_26", "RESERVE_C_27", "RESERVE_C_28", "RESERVE_C_29", "RESERVE_C_30", "RESERVE_N_01", "RESERVE_N_02", "RESERVE_N_03", "RESERVE_N_04", "RESERVE_N_05", "RESERVE_N_06", "RESERVE_N_07", "RESERVE_N_08", "RESERVE_N_09", "RESERVE_N_10", "RESERVE_N_11", "RESERVE_N_12", "RESERVE_N_13", "RESERVE_N_14", "RESERVE_N_15", "RESERVE_N_16", "RESERVE_N_17", "RESERVE_N_18", "RESERVE_N_19", "RESERVE_N_20", "RESERVE_N_21", "RESERVE_N_22", "RESERVE_N_23", "RESERVE_N_24", "RESERVE_N_25", "RESERVE_N_26", "RESERVE_N_27", "RESERVE_N_28", "RESERVE_N_29", "RESERVE_N_30"
        //20051207 zj e
        };
        _previousObjectXmlReader.setFieldName(tmpStrName);
    }
}
