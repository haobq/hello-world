/*
 * ﾌｧｲﾙ名：LfcFrmBeanConst.java
 *
 * 修正履歴:
 *           ver.1.00     2003/04/15    HaoBuQian
 *                        作成
 *
 * 修正日時：2005/01/19
 * 修正者　：王嵩
 * 修正内容：試算からコピーの案件一覧のソートカラムインデックスの定数定義と
 *           既存物件から複写の案件一覧のソートカラムインデックスの定数定義と追加する。
 *
 *           Copyright (c) 2004
 *
 * 修正者：潘正寛
 * 修正日：20050530
 * 修正内容：社内コスト率設定画面変更イメージ
 *
 *
 * 修正日：20050701
 * 修正人：潘正寛`、曾健
 * 修正内容：1試算システム案件一覧画面でSiebel試算NO->引合NO変更
 *           2取込項目を追加する
 *
 * 修正日：20050715
 * 修正人：潘正寛
 * 修正内容：試算システムで案件一覧画面の備考欄(1物件目)は左詰める変更
 *
 * 修正日時：20050718
 * 修正者　：曾健
 * 修正内容：取込と引合NOの表示位置を交換
 *
 * 修正日時：20051006
 * 修正者　：潘正寛
 * 修正内容：Add two flags for Subout calculate
 *
 * 修正日時：20051104
 * 修正者　：曾健
 * 修正内容：過去の見積案件一覧, tableを作成する。
 *
 * 修正日時：20051107
 * 修正者　：曾健
 * 修正内容：見積システムでサバアウト手数料を表示しない
 *
 * 修正日時：20051215
 * 修正者　：pzk
 * 修正内容：ｻﾌﾞｱｳﾄ手数料 -->ｻﾌﾞｱｳﾄ手数料(概算）
 *
 *  修正日：20061005～20061124
 *  修正人：zyb
 *  修正内容：リース料システムPricing Matrix改定。
 *
 *  修正日：20070225
 *  修正人：ydy
 *  修正内容：リース料システム社内コースト率改定。
 *
 */

package com.gecl.leaseCal.db.comm;

import java.awt.Color;

/**
 *
 * ｸﾗｽ名：Lfcの定数
 *
 * 概要：Lfc使用する定数を定義
 */
public interface LfcFrmBeanConst {

    // //public final static String LFC_FONT_NAME = "Monospaced";
    public final static String LFC_FONT_NAME = "ＭＳ Ｐゴシック";

    public final static int LFC_FONT_NORM_STYLE = 0;

    public final static int LFC_FONT_BOLD_STYLE = 1;

    // public final static int LFC_FONT_BOLD_STYLE = 0;
    public final static int LFC_FONT_NORM_SIZE = 12;

    public final static int LFC_FONT_TITLE_SIZE = 16;

    // 初期状態データを入力していない
    public static final int BEAN_STATE_NOINPUT = 0;

    // データ入力中
    public static final int BEAN_STATE_INPUTING = 1;

    // データ入力完了（エラー）
    public static final int BEAN_STATE_INPUTERR = 2;

    // データ入力完了（入力完了）
    public static final int BEAN_STATE_SUCCESS = 3;

    // TextField's BackGround
    public final static Color BK_COLOR = new Color(8454143);

    public final static String DECISION_FLAG = "*";

    // 入力可能な文字を羅列した文字列
    public static final String CHARS = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖ"
            + "ﾗﾘﾙﾚﾛﾝｦﾜｧｨｩｪｫｬｭｮｯﾞﾟ､｡ｰABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
            + "0123456789!\"#$%&'()-=^~\\|@`[{;+:*]},<.>/?_ ";

    // 半角カタカナと半角英数字を羅列した数字列と文字列
    // 20040602 ljq change start
    // public static final String ENG_KANA_CHAR =
    // "0123456789ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄ" +
    // "ﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾝｦﾜｧｨｩｪｫｬｭｮｯ";
    public static final String ENG_KANA_CHAR = "0123456789ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄ"
            + "ﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾝｦﾜｧｨｩｪｫｬｭｮｯabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    // 半角英数字と数字列と文字列
    public static final String CHARS_FULL_HALF = "";

    // 20040602 ljq change end
    // 入力可能な文字を羅列した数字列と文字列
    public static final String ENG_CHAR = "0123456789"
            + "abcdefghijklmnopqrstuvwxyz" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    // 入力可能な文字を羅列した数字列
    public static final String NUM = "0123456789";

    // 入力可能な文字を羅列した数字列
    public static final String MINUS = "-0123456789";

    // add Start by BQG 2004/07/07
    // 入力可能な文字を羅列した数字列
    public static final String PLUSFLOAT = "0123456789.";

    // add end by BQG 2004/07/07
    // 入力可能な文字を羅列した小数列
    public static final String FLOAT = "-0123456789.";

    // 入力可能な文字を羅列した数字列と文字列(全角)
    public static final String ENG_CHARZEN = "?０１２３４５６７８９．"
            + "ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ"
            + "ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ"
            + "-0123456789."
            + "abcdefghijklmnopqrstuvwxyz"
            + "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    // 入力可能な文字を羅列した金額列
    public static final String CURRENCY = "0123456789,";

    // 入力可能な文字を羅列した金額列(マイナス)
    public static final String CURRENCYM = "-0123456789,";

    // 入力可能な文字を羅列した日期列
    public static final String DATE = "0123456789/";

    public static final String TIME = "0123456789:";

    // 入力可能な文字を羅列した電話列
    public static final String TELZIP = "0123456789-";

    // 入力可能な文字を羅列した部件No.列
    public static final String BUKKENZIP = "0123456789 ,;:";

    // 全角
    public static final int FULL = 0;

    // 半角
    public static final int HALF = 1;

    // ﾃﾞｰﾀタイプ 整数
    public static final int DATA_NUMERIC = 0;

    // ﾃﾞｰﾀタイプ 小数
    public static final int DATA_FLOAT = 1;

    // ﾃﾞｰﾀタイプ 全角文字
    public static final int DATA_FULL = 2;

    // ﾃﾞｰﾀタイプ 半角文字
    public static final int DATA_HALF = 3;

    // ﾃﾞｰﾀタイプ 金額 カンマあり
    public static final int DATA_AMOUNT = 4;

    // ﾃﾞｰﾀタイプ 電話番号と郵便番号
    public static final int DATA_TEL = 5;

    // ﾃﾞｰﾀタイプ 日付 YYYY/MM/DD
    public static final int DATA_DATE_YMD = 6;

    // ﾃﾞｰﾀタイプ 日付 YYYY/MM
    public static final int DATA_DATE_YM = 7;

    // ﾃﾞｰﾀタイプ 日付 HH:MM:SS
    public static final int DATA_DATE_HMS = 8;

    // ﾃﾞｰﾀタイプ 日付 HH:MM
    public static final int DATA_DATE_HM = 9;

    // ﾃﾞｰﾀタイプ 日付 YYYY/MM/DD HH:MM
    public static final int DATA_DATE_YMDHM = 10;

    // ﾃﾞｰﾀタイプ 日付 YYYY/MM/DD HH:MM:SS
    public static final int DATA_DATE_YMDHMS = 11;

    // ０：文字
    public static final int TBL_TXT = 0;

    // 1：数字
    public static final int TBL_NUM = 1;

    // 2：金額
    public static final int TBL_CUR = 2;

    // ３：電話
    public static final int TBL_TEL = 3;

    // ４：日期
    public static final int TBL_DATE = 4;

    // ５：日時
    public static final int TBL_DATE_TIME = 5;

    // ６：年月
    public static final int TBL_YM = 6;

    // ７：確定・機種コード先頭１等
    public static final int TBL_NO = 7;

    public static final int TBL_MON = 8;

    // 9：数字(ゼルを削除、例えば、005->5)
    public static final int TBL_NUM_0 = 9;

    // define the image_button
    public final static int IMAGE_UP = 1;

    public final static int IMAGE_DOWN = 2;

    public final static int IMAGE_NOSORT = 3;

    // define the default sort column
    // public final static int DEFAULT_SORT_COLUMN = 10;
    // public final static int DEFAULT_SORT_COLUMN_EST = 8; //ws 0905 add

    // 20060224 zyb start
    // 20050701 zj start
    // public final static int DEFAULT_SORT_COLUMN = 11;
    // public final static int DEFAULT_SORT_COLUMN = 12;
    public final static int DEFAULT_SORT_COLUMN = 13;

    // 20050701 zj end
    // 20060224 zyb end
    public final static int DEFAULT_SORT_COLUMN_EST = 9; // ws 0905 add

    public final static boolean SORT_DESCEND = false;

    public final static boolean SORT_ASCEND = true;

    // ws 2005/01/19 add 試算からコピーの案件一覧のソートカラムインデックスの定数定義を追加する。
    public final static int EST_ANKEN_SORT_COLUMN = 5;

    // ws 2005/01/19 add 既存物件から複写の案件一覧のソートカラムインデックスの定数定義と追加する。
    public final static int EST_EST_ANKEN_SORT_COLUMN = 1;

    // Tableカラム名配列・カラム幅配列・カラムタイプ配列
    public final static int TBL_COMMON_REIGHT = 16;

    public final static int TBL_CBX_REIGHT = 20;

    // 案件一覧表
    public final static String[] TBL_ITEMLIST_TITLE = { "No.", "契約先名", "契約区分",
            "検収予定日",
            // "物件数(案件単位)",
            "物件数", "契約額（円）", "購入額（円）", "運用利回", "ROI",

            // 20050718 zj start
            // 20050701 zj start
            "引合No.", "取込",
            // 20050701 zj end
            // 20050718 zj end

            // 20060224 zyb start
            "FMV",
            // 20060224 zyb end
            "備考欄(1物件目)", "最終更新日時" };

    public final static int[] TBL_ITEMLIST_WIDTH =
    // 20060224 zyb start
    // 20050718 zj start
    // { 25, 95, 75, 80, 65, 90, 90, 80, 50, 55, 65, 120,110 };
    // { 25, 95, 75, 80, 65, 90, 90, 80, 50, 65, 55, 120,110 };
    // { 25, 75, 70, 85, 60, 90, 85, 73, 47, 65, 55,55, 115,110 };

    // zj 20060324 s
    { 25, 115, 65, 85, 55, 90, 80, 73, 47, 65, 45, 45, 105, 115 };

    // zj 20060324 e

    // ws 2006/03/07 change start
    /*
     * // 20050718 zj end // 20060224 zyb end public final static int[]
     * TBL_ITEMLIST_TYPE = { TBL_NUM, TBL_TXT, TBL_TXT, TBL_DATE, TBL_NUM,
     * TBL_CUR, TBL_CUR, TBL_NUM, TBL_NUM, TBL_TXT, TBL_TXT, // PZK MODI
     * 20050715 START // TBL_DATE_TIME, // TBL_TXT, TBL_TXT, TBL_DATE_TIME, //
     * PZK MODI 20050715 END TBL_TXT, TBL_TXT, TBL_TXT, // 20050701 zj start
     * TBL_TXT, TBL_TXT, // 20050701 zj end // 20060224 zyb start TBL_TXT, //
     * 20060224 zyb end TBL_TXT, TBL_NUM };
     */
    public final static int[] TBL_ITEMLIST_TYPE = { TBL_NUM, // No.
            TBL_TXT, // 契約先名
            TBL_TXT, // 契約区分
            TBL_DATE, // 検収予定日
            TBL_NUM, // 物件数
            TBL_CUR, // 契約額（円）
            TBL_CUR, // 購入額（円）
            TBL_NUM, // 運用利回
            TBL_NUM, // ROI
            TBL_TXT, // 引合No.
            TBL_TXT, // 取込
            TBL_TXT, // FMV
            TBL_TXT, // 備考欄(1物件目)
            TBL_DATE_TIME, // 最終更新日時
            TBL_TXT, // 契約No
            TBL_TXT, // 更新時刻
            TBL_TXT, // 検収Ｎｏ．１
            TBL_TXT, // 検収Ｎｏ．２
            TBL_TXT, // 物件Ｎｏ．(from)
            TBL_TXT, // 物件Ｎｏ．(to)
            TBL_NUM }; // 案件番号

    // ws 2006/03/07 change end

    // 20040610 ljq change start
    // 分割回収表
    public final static String[] TBL_WITHDRAWAL_TITLE = { "前受ﾘｰｽ料(ｶ月分)",
            "回収金額(円)", "回収予定日", "回収ｻｲｸﾙ(ｶ月毎)", "回数(回)" };

    public final static String[] TBL_KP_WITHDRAWAL_TITLE = { "", "回収金額(円)",
            "回収予定日", "回収ｻｲｸﾙ(ｶ月毎)", "回数(回)" };

    public final static int[] TBL_WITHDRAWAL_WIDTH = { 109, 80, 71, 110, 55 };

    public final static int[] TBL_WITHDRAWAL_TYPE =
    // { TBL_NUM, TBL_CUR, TBL_DATE, TBL_NUM, TBL_NUM };
    // 20040727 ltq
    { TBL_MON, TBL_CUR, TBL_DATE, TBL_NUM_0, TBL_NUM_0 };

    public final static int[] TBL_PREWITHDRAWAL_TYPE = { TBL_TXT, TBL_CUR,
            TBL_DATE, TBL_NUM, TBL_NUM };

    public final static int TBL_PRE_WITHDRAWAL_ROW_NUM = 1;

    public final static int TBL_WITHDRAWAL_ROW_NUM = 360;

    public final static int TBL_WITHDRAWAL_COL_NUM = 7;

    public final static int TBL_PRE_WITHDRAWAL_START_EDIT_COL = 0;

    public final static int TBL_PRE_WITHDRAWAL_END_EDIT_COL = 2;

    public final static int TBL_WITHDRAWAL_START_EDIT_COL = 1;

    public final static int TBL_WITHDRAWAL_END_EDIT_COL = 4;

    // コスト(COF、EANI、LOSS、Fee)
    public final static String[] TBL_COST_TITLE = { "期間", "～35", "36～47",
//ydy modify 20070225 s
//            "48～59", "60～71", "72～83", "84～95", "96～107", "108～" };
        "48～59", "60～71", "72～83", "84～95", "96～107", "108～119", "120～" };
//ydy modify 20070225 e
    public final static String[] TBL_MACHINE_TITLE = { "確定", "機種コード先頭1", "機種名称" };

//  ydy modify 20070225 s
//    public final static int[] TBL_COST_WIDTH = { 195, 70, 70, 70, 70, 70, 70,
//            70, 70 };
    public final static int[] TBL_COST_WIDTH = { 188, 63, 63, 63, 63, 63, 63,
    	63, 63, 63 };
//  ydy modify 20070225 e

    public final static int[] TBL_COST_TYPE = { TBL_TXT, TBL_NUM, TBL_NUM,
            TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM,
            TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM,
            TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM,
//  ydy modify 20070225 s
//            TBL_NUM};
            TBL_NUM, TBL_NUM, TBL_NUM, TBL_NUM};
//  ydy modify 20070225 e

    // pzk modi 20050530 start
    // public final static int[] TBL_MACHINE_WIDTH = { 50, 145, 505 };
    public final static int[] TBL_MACHINE_WIDTH = { 50, 145, 550 };

    // pzk modi 20050530 end
    public final static int[] TBL_MACHINE_TYPE = { TBL_NO, TBL_NO, TBL_TXT,
            TBL_NO };

    // 試算物件(OBJECT)表
    public final static String[] TBL_SPECIFYBUKNO_TITLE =
    // { "物件No.", "購入金額（円）", "リース期間（前受）", "月額リース料", "現調" };
    { "物件No.", "購入金額（円）", "リース期間（前受）", "月額リース料", "現調", "備考(物件単位)" };

    public final static int[] TBL_SPECIFYBUKNO_WIDTH =
    // { 80, 170, 170, 120, 60 };
    { 80, 100, 100, 100, 60, 160 };

    // public final static int[] TBL_SPECIFYBUKNO_TYPE = {TBL_TXT, TBL_CUR,
    // TBL_NUM, TBL_NUM,TBL_NUM};
    public final static int[] TBL_SPECIFYBUKNO_TYPE =
    // { TBL_TXT, TBL_CUR, TBL_DATE, TBL_CUR, TBL_DATE };
    { TBL_TXT, TBL_CUR, TBL_DATE, TBL_CUR, TBL_DATE, TBL_TXT };

    // 20050706 zj start
    public final static int[] TBL_SPE_BUKKEN_TYPE = { TBL_TXT, TBL_CUR,
            TBL_DATE, TBL_CUR, TBL_DATE, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT };

    // 20050706 zj end

    public final static String[] TBL_KP_SPECIFYBUKNO_TITLE = { "物件No.",
            "購入金額（円）", "割賦期間（頭金）", "割賦金(1回当り)", "現調", "備考(物件単位)" };

    // Tableカラム名配列
    public final static String[] TBL_COL0_COF_TITLE = { "総購入額0～9.9M",
            "総購入額10～49.9M", "総購入額50～99.9M", "総購入額100～499.9M", "総購入額500～" };

    public final static String[] TBL_COL0_LOSS_TITLE = { "（信用保険有り）A",
            "（信用保険有り）B", "（信用保険有り）C", "（信用保険有り）D", "（信用保険無し）A", "（信用保険無し）B",
            "（信用保険無し）C", "（信用保険無し）D" };

    public final static String[] TBL_COL0_FEE_TITLE = { "リース定率残価内", "リース定率残価超" };

    // Tableカラム名配列
    /*
     * public final static String[] TBL_FIXEDRTREMAINVALRT_TITLE = {"確定", "大分類",
     * "小分類"}; public final static int[] TBL_FIXEDRTREMAINVALRT_WIDTH = {50,
     * 200, 300}; public final static int[] TBL_FIXEDRTREMAINVALRT_TYPE =
     * {TBL_TXT, TBL_TXT,
     * TBL_TXT,TBL_TXT,TBL_TXT,TBL_TXT,TBL_TXT,TBL_TXT,TBL_TXT,TBL_TXT};
     */

    public final static String[] TBL_FIXEDRTREMAINVALRT_TITLE = { "確定", "大分類",
            "小分類" };

    public final static int[] TBL_FIXEDRTREMAINVALRT_WIDTH = { 50, 200, 300 };
    public final static int[] TBL_FIXEDRTREMAINVALRT_TYPE = { TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT };

    // 分割支払情報(PAYDIV)表
    public final static String[] TBL_SPEAPAY_TITLE = { "No.", "購入価額の内訳金額（円）",
            "支払予定日" };

    public final static int[] TBL_SPEAPAY_WIDTH = { 50, 150, 100 };

    public final static int[] TBL_SPEAPAY_TYPE = { TBL_TXT, TBL_CUR, TBL_DATE };

    public final static int TBL_SPEAPAY_START_EDIT_COL = 1;

    public final static int TBL_SPEAPAY_END_EDIT_COL = 2;

    // 計算結果固定カラム表
    public final static String[] TBL_RESULT_HEADER_TITLE = { "No." };

    public final static int[] TBL_RESULT_HEADER_WIDTH = { 225 };

    public final static int[] TBL_RESULT_HEADER_TYPE = { TBL_TXT };

    // 計算結果表
    public final static String[] TBL_RESULT_TITLE = { "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17",
            "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28",
            "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39",
            "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50",
            "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61",
            "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72",
            "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83",
            "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94",
            "95", "96", "97", "98", "99", "100" };

    public final static int[] TBL_RESULT_WIDTH = { 158, 158, 158, 158, 158,
            158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158,
            158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158,
            158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158,
            158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158,
            158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158,
            158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158,
            158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158,
            158, 158, 158, 158 };

    public final static int[] TBL_RESULT_TYPE = { TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT };

    public final static String[][] TBL_RESULT_COL0_TEXT = { { "物件No." },
            { "リース月数（前受月数）" }, { "原価調整期間" }, { "購入価額" }, { "残価" },
            { "社内コスト額" }, { "固定資産税" }, { "保険料" }, { "その他の原価" }, { "リース原価計" },
            { "当社手数料" }, { "契約額" }, {
            // pzk modi 2004/12/06 s
            // "原価調整額" }, {
            // "ＲＯＩ 額" }, {
            // "使用総資金 税引前ＲＯＩ" }, {
            // "運用利回り（TR）" }, {
            // "社内コスト率" }, {
            //20090112 fuling modi s
            // "約定月額ﾘｰｽ料   原価調整額" }, { "ＲＯＩ 額              税引前ＲＯＩ 額" },
            // { "使用総資金         税引前ＲＯＩ" }, { "運用利回り         TR" },
            "約定月額ﾘｰｽ料   原価調整額" }, { "ＲＯＩ 額                      " },
            { "使用総資金                 " }, { "運用利回り      TR" },
            //20090112 fuling modi e
            { "                     社内コスト率" }, {
            // pzk modi 2004/12/06 e
            "ＣＯＦ              管販費率計" }, { "管販費率O      管販費率S" },
            { "貸倒引当率　   手数料収益率計" }, { "手数料率N      手数料率R" },
            { "ＲＯＩ           　  Finance Margin率" }, { "Finance Margin額" },
            { "RA Margin率" }, { "RA PV Margin額" }, { "ＲＯＥ　LeverageRatio" },

            // zj 20051007 s
            { "ｻﾌﾞｱｳﾄ手数料(概算）" }
    // zj 20051007 e
    };

    // 20051107 ZJ S
    public final static String[][] TBL_RESULT_COL0_TEXT_EST = { { "物件No." },
            { "リース月数（前受月数）" }, { "原価調整期間" }, { "購入価額" }, { "残価" },
            { "社内コスト額" }, { "固定資産税" }, { "保険料" }, { "その他の原価" }, { "リース原価計" },
            { "当社手数料" }, { "契約額" }, { "約定月額ﾘｰｽ料   原価調整額" },
            //20090112 fuling modi s
            //{ "ＲＯＩ 額              税引前ＲＯＩ 額" }, { "使用総資金         税引前ＲＯＩ" },
            { "ＲＯＩ 額                      " }, { "使用総資金               " },
            //20090112 fuling modi e
            { "運用利回り      TR" }, { "                     社内コスト率" }, {
            // pzk modi 2004/12/06 e
            "ＣＯＦ              管販費率計" }, { "管販費率O      管販費率S" },
            { "貸倒引当率　   手数料収益率計" }, { "手数料率N      手数料率R" },
            { "ＲＯＩ           　  Finance Margin率" }, { "Finance Margin額" },
            { "RA Margin率" }, { "RA PV Margin額" }, { "ＲＯＥ　LeverageRatio" } };

    // 20051107 ZJ E

    public final static String[][] TBL_RESULT_KAPPU_COL0_TEXT = { { "物件No." },
            { "割賦期間" }, { "原価調整期間" }, { "購入価額" }, { "社内コスト額" }, { "保険料" },
            { "その他の原価" }, { "割賦原価計" }, { "当社手数料" }, { "契約額" }, {
            // pzk modi 2004/12/06
            // "原価調整額" }, {
            // "ＲＯＩ 額" }, {
            // "使用総資金 税引前ＲＯＩ" }, {
            // "運用利回り（TR）" }, {
            // "社内コスト率" }, {
            //20090112 fuling modi s
            //"割賦金一回当り   原価調整額" }, { "ＲＯＩ 額              税引前ＲＯＩ 額" },
            //{ "使用総資金         税引前ＲＯＩ" }, { "運用利回り         TR" },
            "割賦金一回当り   原価調整額" }, { "ＲＯＩ 額                      " },
            { "使用総資金                 " }, { "運用利回り      TR" },
            //20090112 fuling modi e
            { "                    社内コスト率" }, {
            // pzk modi 2004/12/06 e
            "ＣＯＦ          　 管販費率計" }, { "管販費率O   　 管販費率S" },
            { "貸倒引当率　   手数料収益率計" }, { "手数料率N   　 手数料率R" },
            { "ＲＯＩ          　   Finance Margin率" }, { "Finance Margin額" },
            { "RA Margin率" }, { "RA PV Margin額" }, { "ＲＯＥ　LeverageRatio" },

            // zj 20051007 s
            { "ｻﾌﾞｱｳﾄ手数料(概算）" }
    // zj 20051007 e
    };

    // 20051107 zj s
    public final static String[][] TBL_RESULT_KAPPU_COL0_TEXT_EST = {
            { "物件No." }, { "割賦期間" }, { "原価調整期間" }, { "購入価額" }, { "社内コスト額" },
            { "保険料" }, { "その他の原価" }, { "割賦原価計" }, { "当社手数料" }, { "契約額" },
            //20090112 fuling modi s
            //{ "割賦金一回当り   原価調整額" }, { "ＲＯＩ 額              税引前ＲＯＩ 額" },
            //{ "使用総資金         税引前ＲＯＩ" }, { "運用利回り         TR" },
            { "割賦金一回当り   原価調整額" }, { "ＲＯＩ 額                      " },
            { "使用総資金                 " }, { "運用利回り      TR" },
            //20090112 fuling modi e
            { "                    社内コスト率" }, {
            // pzk modi 2004/12/06 e
            "ＣＯＦ          　 管販費率計" }, { "管販費率O   　 管販費率S" },
            { "貸倒引当率　   手数料収益率計" }, { "手数料率N   　 手数料率R" },
            { "ＲＯＩ          　   Finance Margin率" }, { "Finance Margin額" },
            { "RA Margin率" }, { "RA PV Margin額" }, { "ＲＯＥ　LeverageRatio" } };

    // 20051107 zj e

    public final static String[] TBL_RESULT_HEAD_TITLE = { "No." };

    // 計算結果合計カラム表
    public final static String[] TBL_RESULT_TOTAL_TEXT = { "  " };

    public final static int[] TBL_RESULT_TOTAL_WIDTH = { 150 };

    public final static int[] TBL_RESULT_TOTAL_TYPE = { TBL_CUR };

    public final static int TBL_RESULT_JSCROLLBAR_UNIT_INCREMENT = 158;

    public final static int TBL_RESULT_JSCROLLBAR_BLOCK_INCREMENT = 632;

    public final static int TBL_RESULT_JSCROLLBAR_MIN_LENGTH = 0;

    public final static int TBL_RESULT_JSCROLLBAR_MAX_LENGTH = 15800;

    // ComboBox配列設定
    //20061010 zyb add s
    //GE格付
    //ydy modify 20090622 s
//    public final static String[] CBX_YUSIN_TYPE = {"","A","B","C","D","E"};
//    public final static String[] CBX_YUSIN_TYPE = {"","OR1","OR2","OR3","OR4","OR5","OR6","OR7","OR8","OR9","OR10","OR11","OR12","OR13","OR14","OR15","OR16","OR17","OR18","OR19","OR20","OR21"};
    public final static String[] CBX_YUSIN_TYPE = {"","N/A","OR1","OR2","OR3","OR4","OR5","OR6","OR7","OR8","OR9","OR10","OR11","OR12","OR13","OR14","OR15","OR16","OR17","OR18","OR19","OR20","OR21"};
    //ydy modify 20090622 e

    //20061010 zyb add e
    // 契約タイプ
    public final static String[] CBX_CNTRCT_TYPE = { "全て", "リース", "割賦" };

    // ﾘｰｽ/割賦区分
    // COF
    public final static String[] CBX_COF = { "1.011", "1.012", "1.013",
            "2.011", "3.011", "4.011" };

    // COF
    // 耐用年数
    public final static String[] CBX_DURABLE_Y = { "2", "3", "4", "5", "6",
            "7", "8", "9", "10", "11", "12", "13", "14", "15" };

    // 法定耐用年数
    // リース料月数
    public final static String[] CBX_LEASE_M = { "24", "36", "48", "60", "72",
            "84", "96", "108", "120" };

    // リース月数
    // 動産総合保険料率
    public final static String[] CBX_DOSO_RATE = { "<取消>", "1.011", "1.012",
            "1.013", "2.011", "3.011", "4.011" };

    // リース月数
    public final static String[] CBX_RESULT = { "全物件合算", "合計(横計)" };

    // 団体信用生命保険料率(千円当り)
    public final static String[] DAN_SHIN_RATE = { "<取消>", "0.7", "1.18",
            "2.23", "2.3", "56" };

    // 見積条件設定画面の各区分
    public final static String[] CBX_FLAG = { "1:有", "2:無" }; // ﾘｰｽ/割賦区分

    // 見積条件設定画面の回収方法
    public final static String[] CBX_WITHDRAWAL_METHOD = { "<取消>", "1:約束手形",
            "2:為替手形", "3:振込", "4:現金", "5:自動送金", "9:口座振替" };

    // 見積条件設定画面の単位
    // public final static String[] CBX_TANI = {"1:台", "2:式", "3:基", "4:本",
    // "5:枚", "6:個"};
    public final static String[] CBX_TANI = { "台", "式", "基", "本", "枚", "個" };

    // 見積条件設定画面の支払日
    public final static String[] CBX_PAYDATE = { "30", "60", "90", "120", "180" };

    public final static String DATE_FMT = "XXXX/XX/XX"; // Y10K!

    public final static String F_WITHDRAWAL_PRE_LEASE_M = "      ｶ月分";

    public final static String F_WITHDRAWAL_CIRCLE_ = "      ｶ月毎";

    public final static String F_WITHDRAWAL_COUNT = "      回";

    // 物件Noの表示形式( ～ )の変数
    public final static String F_BUKEN_NO = "   ～   ";

    // リース月数
    public final static String F_RT1 = "   ｶ月(   月)";

    public final static int F_RT1_STEP = 3;

    public final static int F_RT1_REMOVE_LENGTH1 = 3;

    public final static String F_RT1_KP = "   ｶ月";

    public final static int F_RT1_STEP_KP = 0;

    public final static int F_RT1_REMOVE_LENGTH1_KP = 3;

    // 原価調整期間
    public final static String F_RT2 = "   ｶ月   日";

    public final static int F_RT2_STEP = 2;

    public final static int F_RT2_REMOVE_LENGTH1 = 3;

    // 税引前ＲＯＩ
    public final static String F_RT3 = "   .  %";

    public final static int F_RT3_STEP = 0;

    public final static int F_RT3_REMOVE_LENGTH1 = 6;

    // PZK
    // 使用総資金 税引前ＲＯＩ
    //20090112 fuling modi s
    //public final static String F_RT13 = "                     .  % ";
    public final static String F_RT13 = "                          ";
    //20090112 fuling modi e

    public final static int F_RT13_STEP = 2;

    public final static int F_RT13_REMOVE_LENGTH1 = 16;

    // 運用利回り
    public final static String F_RT4 = "   .  %    .  % ";

    public final static int F_RT4_STEP = 2;

    public final static int F_RT4_REMOVE_LENGTH1 = 6;

    // pzk modi 2004/12/06
    // COF(管販費率合計),貸倒引当
    public final static String F_RT5 = "   .  %    .  % ";

    public final static int F_RT5_STEP = 2;

    public final static int F_RT5_REMOVE_LENGTH1 = 6;

    // 管販費率O,手数料率
    public final static String F_RT6 = "(   .  %,   .  %)";

    public final static int F_RT6_STEP = 2;

    public final static int F_RT6_REMOVE_LENGTH1 = 6;

    // RIO(Finance Margin率)
    // pzk modi 2004/12/06
    public final static String F_RT7 = "   .  %    .  % ";

    public final static int F_RT7_STEP = 2;

    public final static int F_RT7_REMOVE_LENGTH1 = 6;

    // RA Margin率、社内コスト率
    public final static String F_RT8 = "   .  % ";

    public final static int F_RT8_STEP = 0;

    public final static int F_RT8_REMOVE_LENGTH1 = 6;

    // 最大桁数を超える
    public final static String F_MAX = "**,***,***,***";

    // 20040912 ltq
    public final static String F_RT9 = "      .  %         ";

    public final static int F_RT9_STEP = 1;

    public final static int F_RT9_REMOVE_LENGTH1 = 9;

    // hut 2003-08-04
    public final static String[] TBL_EST_ITEMLIST_TITLE =

    { "No.", "見積No.", "契約先名", "先頭物件名",
    // "物件数（案件単位）",
            "物件数", "契約額（円）", "出力日",
            // pzk modi 20050701 start
            // "Siebel試算No.",
            "引合No.",
            // pzk modi 20050701 end
            "備考欄(1物件目)", "最終更新日時" };

    // public final static int[] TBL_EST_ITEMLIST_WIDTH = {25, 80, 150, 150, 67,
    // 150, 85, 115, 110};
    public final static int[] TBL_EST_ITEMLIST_WIDTH =
    // { 25, 100, 75, 80, 70, 90, 90, 90, 50, 100, 120,110 };

    { 25, 80, 150, 150, 70, 90, 100, 94, 120, 110 };

    // { 25, 80, 150, 150, 120, 95, 100, 139, 130 };
    public final static int[] TBL_EST_ITEMLIST_TYPE = { TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_NUM, TBL_CUR, TBL_DATE_TIME, TBL_TXT,
            TBL_TXT, TBL_DATE_TIME, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT };

    // 物件No.選択一覧表
    public final static String[] TBL_BUK_ITEMLIST_LS_TITLE = { "物件No.", "物件名",
            "検収日（期間）", "回収条件", "月額リース料（前受）" };

    public final static String[] TBL_BUK_ITEMLIST_KP_TITLE = { "物件No.", "物件名",
            "検収日（期間）", "回収条件", "割賦金(1回当り)(頭金)" };

    public final static int[] TBL_BUK_ITEMLIST_WIDTH = { 60, 140, 130, 90, 177 };

    public final static int[] TBL_BUK_ITEMLIST_TYPE = { TBL_TXT, TBL_TXT,
            TBL_DATE_TIME, TBL_TXT, TBL_CUR };

    public final static int[] TBL_EST_BUK_ITEMLIST_TYPE = { TBL_TXT, TBL_TXT,
            TBL_DATE_TIME, TBL_TXT, TBL_CUR, TBL_TXT, TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT };

    // 具体引渡場所選択
    public final static String[] TBL_EST_SELECT_TITLE = { "確定", "小分類" };

    public final static int[] TBL_EST_SELECT_WIDTH = { 50, 350 };

    public final static int[] TBL_EST_SELECT_TYPE = { TBL_TXT, TBL_TXT };

    // 20040723 ltq
    public final static String[] TBL_EST_KEIYAKUSEN_TITLE = { "確定", "契約先名１",
            "契約先名２" };

    public final static int[] TBL_EST_KEIYAKUSEN_WIDTH = { 50, 225, 225 };

    public final static int[] TBL_EST_KEIYAKUSEN_TYPE = { TBL_TXT, TBL_TXT,
            TBL_TXT };

    public final static String[] TBL_EST_PURCHASE_TITLE = { "確定", "購入先名１",
            "購入先名２" };

    public final static int[] TBL_EST_PURCHASE_WIDTH = { 50, 225, 225 };

    public final static int[] TBL_EST_PURCHASE_TYPE = { TBL_TXT, TBL_TXT,
            TBL_TXT };

    public final static String[] TBL_EST_BUKEN_TITLE = { "確定", "物件名" };

    public final static int[] TBL_EST_BUKEN_WIDTH = { 50, 350 };

    public final static int[] TBL_EST_BUKEN_TYPE = { TBL_TXT, TBL_TXT };

    // 20040723 ltq
    // 見積案件一覧情報表
    public final static String[] TBL_Anken_ITEMLIST_TITLE = { "No.", "見積No.",
            "契約先名", "先頭物件名", "物件数（案件単位）", "契約額(円)" };

    public final static int[] TBL_Anken_ITEMLIST_WIDTH = { 25, 78, 149, 122,
            120, 125 };

    // public final static int[] TBL_Anken_ITEMLIST_TYPE = {NUM,TXT,TXT,
    // TXT,NUM, CUR,DATE,NUM,DATE};
    public final static int[] TBL_Anken_ITEMLIST_TYPE =
    // { TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_CUR };
    { TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_NUM, TBL_CUR };

    // LsEstCalDisplayPnl.java
    public final static String[] TBL_EST_CALDISP_TITLE = { "No.", "1", "2",
            "3", "4", "全体" };

    public final static int[] TBL_EST_CALDISP_WIDTH = { 120, 165, 165, 165,
            165, 165 };

    public final static int[] TBL_EST_CALDISP_TYPE = { TBL_TXT, TBL_TXT,
            TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT };

    // LsEstAnkenChoose.java
    public final static String[] TBL_EST_ANKENCHS_TITLE = { "No.", "契約区分",
            "契約先名", "物件数（案件単位）", "契約額（円）", "更新日時",
            // 20060426 zyb start
            // 20050701 zj start
            "引合No.", "取込", "FMV" };

    // 20050701 zj end
    // 20060426 zyb end

    public final static int[] TBL_EST_ANKENCHS_WIDTH =
    // 20060426 zyb start
    // 20050701 zj start
    // { 25, 85, 150, 135, 95, 130, 105 };
     //20060428 zyb start
    //{ 25, 80, 100, 135, 95, 115, 65, 55, 55 };
    { 25, 75, 135, 120, 85, 110, 65, 55, 55 };
    //20060428 zyb end
    // 20050701 zj end
    // 20060426 zyb end
    public final static int[] TBL_EST_ANKENCHS_TYPE =
    // 20040707 LTQ
    // { TBL_TXT, TBL_TXT, TBL_TXT, TBL_TXT, TBL_CUR, TBL_DATE_TIME };
    { TBL_TXT, TBL_TXT, TBL_TXT, TBL_NUM, TBL_CUR,
    // TBL_DATE_TIME,
            TBL_TXT, TBL_TXT, TBL_TXT,

            // 20050701 zj start
            TBL_TXT,
            // 20050701 zj end

            // 20060426 zyb start
            TBL_TXT,
            // 20060426 zyb end

            TBL_TXT };

    // LsEstCalBukSelectFrm.java
    public final static String[] TBL_EST_CAL_BUK_LS_TITLE = { "物件No.", "購入金額",
            "リース期間（前受）", "月額リース料", "現調", "備考(物件単位)" };

    // { "物件No.", "購入金額（円）", "割賦期間（頭金）", "割賦金(1回当り)", "現調" , "備考(物件単位)" };

    public final static String[] TBL_EST_CAL_BUK_KP_TITLE = { "物件No.", "購入金額",
            "割賦期間（頭金）", "割賦金(1回当ﾘ)", "現調", "備考(物件単位)" };

    public final static int[] TBL_EST_CAL_BUK_WIDTH = { 80, 100, 100, 100, 60,
            160 };

    // { 80, 170, 170, 150, 100 };
    public final static int[] TBL_EST_CAL_BUK_TYPE =
    // { TBL_TXT, TBL_CUR, TBL_DATE, TBL_CUR, TBL_DATE ,TBL_TXT};

    { TBL_TXT, TBL_CUR, TBL_TXT, TBL_CUR, TBL_TXT, TBL_TXT, TBL_TXT };


    public static final String KEIYAKUSEN = "KEIYAKUSEN_NAME";

    public static final String PURCHASE = "PURCHASE_NAME";

    public static final String BUKEN = "BUKEN_NAME";

    public static final String LSEST = "DELIV_PLAC";

    // EstGuarantorBean.java

    public static final String LSEST_G = "JOIN_SURET";

    // 計算結果画面のコラム
    // リース月数
    public final static int LEASE_M = 0;

    // (前受月数)
    public final static int INC_0_M = 1;

    // 原価調整期間(ｶ月)
    public final static int Adjust_MD = 2;

    // 購入価格
    public final static int Purchase = 3;

    // 残価
    public final static int REMAIN_VAL = 4;

    // 支払利息
    public final static int INTEREST_P = 5;

    // 固定資産税
    public final static int FIXASTTAX = 6;

    // 保険料
    public final static int INSURANCE = 7;

    // リース原価
    public final static int COST_TOTAL = 8;

    // 当社手数料
    public final static int CHARGE = 9;

    // 契約額
    public final static int INCOME_GT = 10;

    // 原価調整額
    public final static int C_ADJUST = 11;

    // 荒利益
    public final static int PROFIT_T = 12;

    // 運用利回り
    public final static int RATE_UNYO = 13;

    // TR
    public final static int TRUE_RATE = 14;

    // 社内コスト率
    public final static int RATE_JLC = 15;

    // COF
    public final static int RATE_C_ADJ = 16;

    // 管販比率O
    public final static int RATE_E_A_O = 17;

    // 管販比率S
    public final static int RATE_E_A_S = 18;

    // 貸倒引当率
    public final static int RATE_LOSS = 19;

    // 手数料率N
    public final static int RATE_FEE_N = 20;

    // 手数料率R
    public final static int RATE_FEE_R = 21;

    // 使用総資産
    public final static int CAPITAL_T = 22;

    // 回収利息
    public final static int INTEREST_I = 23;

    // PV Finance Margin額
    public final static int PV_FINANCE_MARGIN = 24;

    // RA PV Margin額
    public final static int RA_PV_MARGIN = 25;

    // Roi 額
    public final static int ROI = 26;

    // 約定月額リース料
    public final static int INCOME = 28;

    // リース期間/割賦回数全て同じFLAG
    public final static int FLAG = 29;

    // 20050702 zj start
    // CAL ANKEN SELECT TABLE
    // No
    public final static int C_ANK_SLT_NO = 0;

    // 契約区分 LEASE OR KAPPU
    public final static int C_ANK_SLT_K_TYPE = 1;

    // 契約先名
    public final static int C_ANK_SLT_K_NAME = 2;

    // 物件数（案件単位）
    public final static int C_ANK_SLT_B_COUNT = 3;

    // 契約額
    public final static int C_ANK_SLT_IN_GT = 4;

    // 最終更新日時
    public final static int C_ANK_SLT_DATE = 5;

    // 取込Flag
    public final static int C_ANK_SLT_FLAG = 7;

    // 20060426 zyb start
    // FMV
    public final static int C_ANK_SLT_FMV = 8;

    // 引合No
    public final static int C_ANK_SLT_OPOID = 6;

    // 契約No
    public final static int C_ANK_SLT_K_NO = 9;

    // 案件番号
    public final static int C_ANK_SLT_A_NO = 10;

    // COLUM COUNT
    public final static int C_ANK_SLT_CLM_COUNT = 11;

    // 20050702 zj end
    // 20060426 zyb end
    // 20050704 zj start
    // CAL ANKEN LIST TABLE,the table is in CalMainFrm
    // No.
    public final static int C_ANK_LIST_NO = 0;

    // 契約先名.
    public final static int C_ANK_LIST_K_NAME = 1;

    // 契約区分
    public final static int C_ANK_LIST_K_TYPE = 2;

    // 検収予定日.
    public final static int C_ANK_LIST_K_DATE = 3;

    // 物件数
    public final static int C_ANK_LIST_B_COUNT = 4;

    // 契約額（円）
    public final static int C_ANK_LIST_INCOME_GT = 5;

    // 購入額（円）
    public final static int C_ANK_LIST_PURCHASE = 6;

    // 運用利回
    public final static int C_ANK_LIST_R_UNYO = 7;

    // ROI
    public final static int C_ANK_LIST_R_ROI = 8;

    // 20050718 zj start
    // 取込
    public final static int C_ANK_LIST_TORIKOMI = 10;

    // 引合No.
    public final static int C_ANK_LIST_SBL_OPOID = 9;

    // 20050718 zj end
    // 20060224 zyb start
    // FMV
    public final static int C_ANK_LIST_FMV = 11;

    // 備考欄(1物件目)
    public final static int C_ANK_LIST_RESERVE1 = 12;

    // 最終更新日時
    public final static int C_ANK_LIST_MOD_DATE = 13;

    // 契約No
    public final static int C_ANK_LIST_K_NO = 14;

    // 更新時刻
    public final static int C_ANK_MOD_TIME = 15;

    // 検収Ｎｏ．１
    public final static int C_ANK_KENSHU_NO1 = 16;

    // 検収Ｎｏ．２
    public final static int C_ANK_KENSHU_NO2 = 17;

    // 物件Ｎｏ．(from)
    public final static int C_ANK_BUKKEN_FR = 18;

    // 物件Ｎｏ．(to)
    public final static int C_ANK_BUKKEN_TO = 19;

    // 案件番号
    public final static int C_ANK_REC_NO = 20;

    // Count
    public final static int C_ANK_COLUMS_COUNT = 21;

    // 20050704 zj end
    // 20060224 zyb end
    // 20051006 pzk add start
    // excel start row
    public final static int INT_EXCEL_START_ROW = 4;

    public final static int INT_EXCEL_START_COLUMN = 3;

    // 20051006 pzk add end

    // 20051104 zj s
    // 20060224 zyb start
    // 過去の試算案件一覧
    public final static String[] TBL_CAL_RECOVER_TITLE = { "No.", "契約先名",
            "契約区分", "物件数（案件単位）", "契約額（円）", "引合No.", "取込", "FMV", "更新日時" };

    // 20060224 zyb end
    // 20060224 zyb start 追加FMV
    public final static int[] TBL_CAL_RECOVER_WIDTH = { 25, // No.
            90, // 契約先名
            75, // 契約区分
            135, // 物件数（案件単位）
            95, // 契約額（円）
            70, // "引合No.
            55, // 取込
            55, // FMV
            125 // 更新日時
    };// LENGTH = 725

    // 20060224 zyb end
    public final static int[] TBL_CAL_RECOVER_TYPE = { TBL_TXT, // No.
            TBL_TXT, // 契約先名
            TBL_TXT, // 契約区分
            TBL_NUM, // 物件数（案件単位）
            TBL_CUR, // 契約額（円）
            TBL_TXT, // 引合No.
            TBL_TXT, // 取込
            // 20060227 add zyb start
            TBL_TXT,// FMV
            // 20060227 add zyb end
            TBL_TXT, // 更新日時
            TBL_TXT, // 契約No.
            TBL_TXT // 案件番号
    };// The last two types are not visible

    // Table column
    // No.
    public final static int C_RECOVER_NO = 0;

    // 契約先名
    public final static int C_RECOVER_K_NAME = 1;

    // 契約区分
    public final static int C_RECOVER_K_TYPE = 2;

    // 物件数（案件単位）
    public final static int C_RECOVER_ANK_U = 3;

    // 契約額（円）
    public final static int C_RECOVER_K_MONEY = 4;

    // 引合No.
    public final static int C_RECOVER_Y_NO = 5;

    // 取込
    public final static int C_RECOVER_T = 6;

    // 20060227 add zyb start
    // FMV
    public final static int C_RECOVER_FMV = 7;

    // 20060227 add zyb end
    // 20060227modi zyb start
    // 更新日時
    public final static int C_RECOVER_DATE = 8;

    // 契約No.
    public final static int C_RECOVER_K_NO = 9;

    // 案件番号
    public final static int C_RECOVER_REC_NO = 10;

    // 20060227modi zyb end
    // 過去の見積案件一覧
    public final static String[] TBL_EST_RECOVER_TITLE = { "No.", "見積No.",
            "契約先名", "先頭物件名", "物件数", "更新日時" };

    public final static int[] TBL_EST_RECOVER_WIDTH = { 25, // No.
            55, // 見積No.
            165, // 契約先名
            165, // 先頭物件名
            65, // 物件数（案件単位）
            125 // 更新日時
    }; // LENGTH = 600

    public final static int[] TBL_EST_RECOVER_TYPE = { TBL_TXT, // No.
            TBL_TXT, // 見積No.
            TBL_TXT, // 契約先名
            TBL_TXT, // 先頭物件名
            TBL_NUM, // 物件数（案件単位）
            TBL_DATE_TIME // 更新日時
    };

    // Table column
    // No.
    public final static int E_RECOVER_NO = 0;

    // 見積No.
    public final static int E_RECOVER_M_NO = 1;

    // 契約先名
    public final static int E_RECOVER_K_NAME = 2;

    // 先頭物件名
    public final static int E_RECOVER_PRE_N = 3;

    // 物件数（案件単位）
    public final static int E_RECOVER_ANK_U = 4;

    // 更新日時
    public final static int E_RECOVER_DATE = 5;

    // 20051104 zj e
}
