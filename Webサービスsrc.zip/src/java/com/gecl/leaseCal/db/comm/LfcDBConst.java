/*
 * ファイル名：LfcDBConst.java
 *
 * 修正履歴  ：
 *             ver1.0.0     2003/03/27      王嵩
 *                          作成
 *             Copyright (c) 2003
 *
 *　修正者：潘正寛
 *  修正日：20051206
 *　修正内容：システム表にフィールドを追加する
 *
 *  修正者：zyb
 *  修正日：20061010
 *　修正内容：GE格付,機種追加する
 *
 *  修正者：zyb
 *  修正日：20070410
 *　修正内容：ROIの税率を変更する.
 */
package com.gecl.leaseCal.db.comm;

/**
 *
 * クラス名：Lfcの定数
 *
 * 概要：LFC使用する定数を定義
 */
public interface LfcDBConst {

    /** XMLのRoot */
    public final static String CNTRCT_ROOT = "CNTRCT";
    /** 案件番号 */
    public final static int CNTRCT_REC_NO = 0;
    /** 契約先名 */
    public final static int CNTRCT_USER_NAME = 1;
    /** 契約Ｎｏ */
    public final static int CNTRCT_KEIYAKU_NO = 2;
    /** 検収Ｎｏ．１ */
    public final static int CNTRCT_KENSHU_NO1 = 3;
    /** 検収Ｎｏ．２ */
    public final static int CNTRCT_KENSHU_NO2 = 4;
    /** 物件Ｎｏ．(from) */
    public final static int CNTRCT_BUKKEN_FR = 5;
    /** 物件Ｎｏ．(to) */
    public final static int CNTRCT_BUKKEN_TO = 6;
    /** 契約額総額 */
    public final static int CNTRCT_INCOME_GT = 7;
    /** 購入額総額 */
    public final static int CNTRCT_PURCHASE = 8;
    /** 運用利回り */
    public final static int CNTRCT_RATE_UNYO = 9;
    /** 更新日 */
    public final static int CNTRCT_MOD_DATE = 10;
    /** 更新時刻 */
    public final static int CNTRCT_MOD_TIME = 11;
    /** 部門CD */
    public final static int CNTRCT_BRANCH_CD = 12;
    /** 部門名前 */
    public final static int CNTRCT_BRANCH_NM = 13;
    /** 住所１ */
    public final static int CNTRCT_ADDRESS1 = 14;
    /** 住所２ */
    public final static int CNTRCT_ADDRESS2 = 15;
    /** 電話番号 */
    public final static int CNTRCT_TELNO = 16;
    /** 担当者CD */
    public final static int CNTRCT_PERSON_CD = 17;
    /** 担当者名前 */
    public final static int CNTRCT_PERSON_NM = 18;
    /** Fax番号 */
    public final static int CNTRCT_FAXNO = 19;
    /** シーベルROWID */
    public final static int CNTRCT_SBL_ROWID = 20;
    /** シーベル商談ID */
    public final static int CNTRCT_SBL_OPOID = 21;
    /** シーベル登録日 */
    public final static int CNTRCT_SBL_RGDATE = 22;
    /** シーベル登録時刻 */
    public final static int CNTRCT_SBL_RGTIME = 23;
    /** 見積取込カウンタ */
    public final static int CNTRCT_EST_CPYCNT = 24;
    // 20040714 ljq add s
    /** 検収予定日 */
    public final static int CNTRCT_DATE_KENSH = 25;
    /** ＲＯＩ */
    public final static int CNTRCT_RATE_ROI = 26;
    /** 物件数（案件単位） */
    public final static int CNTRCT_BUKKEN_NUM = 27;
    // 20040714 ljq add e
    /** 予備 */
    public final static int CNTRCT_RESERVE1 = 28;
    // pzk add 20051206 s
    // zyb add 20060228 s
    /** FMV判断フラグ */
    public final static int CNTRCT_RESERVE_C_01 = 29;
    /** 税務判定金利種別 */
    public final static int CNTRCT_RESERVE_C_02 = 30;
    /** 会計判定金利種別 */
    public final static int CNTRCT_RESERVE_C_03 = 31;
    // zyb add 20060228 e
    //20061010 zyb s
    /** GE格付 */
    public final static int CNTRCT_RESERVE_C_04 = 32;
    /** 機種ｺｰﾄﾞ */
    public final static int CNTRCT_RESERVE_C_05 = 33;
    /** 機種名称 */
    public final static int CNTRCT_RESERVE_C_06 = 34;
    //20061010 zyb e
    /** 予備_Ｃ_07 */
    public final static int CNTRCT_RESERVE_C_07 = 35;
    /** 予備_Ｃ_08 */
    public final static int CNTRCT_RESERVE_C_08 = 36;
    /** 予備_Ｃ_09 */
    public final static int CNTRCT_RESERVE_C_09 = 37;
    /** 予備_Ｃ_10 */
    public final static int CNTRCT_RESERVE_C_10 = 38;
    /** 予備_Ｃ_11 */
    public final static int CNTRCT_RESERVE_C_11 = 39;
    /** 予備_Ｃ_12 */
    public final static int CNTRCT_RESERVE_C_12 = 40;
    /** 予備_Ｃ_13 */
    public final static int CNTRCT_RESERVE_C_13 = 41;
    /** 予備_Ｃ_14 */
    public final static int CNTRCT_RESERVE_C_14 = 42;
    /** 予備_Ｃ_15 */
    public final static int CNTRCT_RESERVE_C_15 = 43;
    /** 予備_Ｃ_16 */
    public final static int CNTRCT_RESERVE_C_16 = 44;
    /** 予備_Ｃ_17 */
    public final static int CNTRCT_RESERVE_C_17 = 45;
    /** 予備_Ｃ_18 */
    public final static int CNTRCT_RESERVE_C_18 = 46;
    /** 予備_Ｃ_19 */
    public final static int CNTRCT_RESERVE_C_19 = 47;
    /** 予備_Ｃ_20 */
    public final static int CNTRCT_RESERVE_C_20 = 48;
    /** 予備_Ｃ_21 */
    public final static int CNTRCT_RESERVE_C_21 = 49;
    /** 予備_Ｃ_22 */
    public final static int CNTRCT_RESERVE_C_22 = 50;
    /** 予備_Ｃ_23 */
    public final static int CNTRCT_RESERVE_C_23 = 51;
    /** 予備_Ｃ_24 */
    public final static int CNTRCT_RESERVE_C_24 = 52;
    /** 予備_Ｃ_25 */
    public final static int CNTRCT_RESERVE_C_25 = 53;
    /** 予備_Ｃ_26 */
    public final static int CNTRCT_RESERVE_C_26 = 54;
    /** 予備_Ｃ_27 */
    public final static int CNTRCT_RESERVE_C_27 = 55;
    /** 予備_Ｃ_28 */
    public final static int CNTRCT_RESERVE_C_28 = 56;
    /** 予備_Ｃ_29 */
    public final static int CNTRCT_RESERVE_C_29 = 57;
    /** 予備_Ｃ_30 */
    public final static int CNTRCT_RESERVE_C_30 = 58;
    // zyb add 20060228 s
    /** 税務判定適用金利 */
    public final static int CNTRCT_RESERVE_N_01 = 59;
    /** 会計判定適用金利 */
    public final static int CNTRCT_RESERVE_N_02 = 60;
    // zyb add 20060228 e
    /** 予備_Ｎ_03 */
    public final static int CNTRCT_RESERVE_N_03 = 61;
    /** 予備_Ｎ_04 */
    public final static int CNTRCT_RESERVE_N_04 = 62;
    /** 予備_Ｎ_05 */
    public final static int CNTRCT_RESERVE_N_05 = 63;
    /** 予備_Ｎ_06 */
    public final static int CNTRCT_RESERVE_N_06 = 64;
    /** 予備_Ｎ_07 */
    public final static int CNTRCT_RESERVE_N_07 = 65;
    /** 予備_Ｎ_08 */
    public final static int CNTRCT_RESERVE_N_08 = 66;
    /** 予備_Ｎ_09 */
    public final static int CNTRCT_RESERVE_N_09 = 67;
    /** 予備_Ｎ_10 */
    public final static int CNTRCT_RESERVE_N_10 = 68;
    /** 予備_Ｎ_11 */
    public final static int CNTRCT_RESERVE_N_11 = 69;
    /** 予備_Ｎ_12 */
    public final static int CNTRCT_RESERVE_N_12 = 70;
    /** 予備_Ｎ_13 */
    public final static int CNTRCT_RESERVE_N_13 = 71;
    /** 予備_Ｎ_14 */
    public final static int CNTRCT_RESERVE_N_14 = 72;
    /** 予備_Ｎ_15 */
    public final static int CNTRCT_RESERVE_N_15 = 73;
    /** 予備_Ｎ_16 */
    public final static int CNTRCT_RESERVE_N_16 = 74;
    /** 予備_Ｎ_17 */
    public final static int CNTRCT_RESERVE_N_17 = 75;
    /** 予備_Ｎ_18 */
    public final static int CNTRCT_RESERVE_N_18 = 76;
    /** 予備_Ｎ_19 */
    public final static int CNTRCT_RESERVE_N_19 = 77;
    /** 予備_Ｎ_20 */
    public final static int CNTRCT_RESERVE_N_20 = 78;
    /** 予備_Ｎ_21 */
    public final static int CNTRCT_RESERVE_N_21 = 79;
    /** 予備_Ｎ_22 */
    public final static int CNTRCT_RESERVE_N_22 = 80;
    /** 予備_Ｎ_23 */
    public final static int CNTRCT_RESERVE_N_23 = 81;
    /** 予備_Ｎ_24 */
    public final static int CNTRCT_RESERVE_N_24 = 82;
    /** 予備_Ｎ_25 */
    public final static int CNTRCT_RESERVE_N_25 = 83;
    /** 予備_Ｎ_26 */
    public final static int CNTRCT_RESERVE_N_26 = 84;
    /** 予備_Ｎ_27 */
    public final static int CNTRCT_RESERVE_N_27 = 85;
    /** 予備_Ｎ_28 */
    public final static int CNTRCT_RESERVE_N_28 = 86;
    /** 予備_Ｎ_29 */
    public final static int CNTRCT_RESERVE_N_29 = 87;
    /** 予備_Ｎ_30 */
    public final static int CNTRCT_RESERVE_N_30 = 88;
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    /** 該当レコードのROWインデックス */
    public final static int CNTRCT_ROW_INDEX = 89;
    // 20040714 ljq change s
    /** フィールド数 */
    // public final static int CNTRCT_RECORD_COUNT = 27;
    // public final static int CNTRCT_RECORD_COUNT = 30;
    public final static int CNTRCT_RECORD_COUNT = 90;
    // 20040714 ljq change s
    // pzk add 20051206 e
    /** テーブルCNTRCTのキー(INTタイプ) */
    public final static int[] N_CNTRCT_ID = {CNTRCT_REC_NO};
    /** テーブルCNTRCTのキー(STRINGタイプ) */
    public final static String[] STR_CNTRCT_ID = {"REC_NO"};
    /** テーブルCNTRCTのSQLルート */
    public final static String CNTRCT_SQLROOT = "/" + CNTRCT_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String PAYDIV_ROOT = "PAYDIV";
    /** 案件番号 */
    public final static int PAYDIV_REC_NO = 0;
    /** 物件番号 */
    public final static int PAYDIV_BUKKEN_NO = 1;
    /** 段数 */
    public final static int PAYDIV_STAIR = 2;
    /** 物件番号(from) */
    public final static int PAYDIV_BUKKEN_FR = 3;
    /** 物件番号(to) */
    public final static int PAYDIV_BUKKEN_TO = 4;
    /** 支払額 */
    public final static int PAYDIV_PURCHASE = 5;
    /** 支払日（年） */
    public final static int PAYDIV_DATE_YY = 6;
    /** 支払日（月） */
    public final static int PAYDIV_DATE_MM = 7;
    /** 支払日（日） */
    public final static int PAYDIV_DATE_DD = 8;
    // pzk add 20051206 s
    /** 予備_Ｃ_01 */
    public final static int PAYDIV_RESERVE_C_01 = 9;
    /** 予備_Ｃ_02 */
    public final static int PAYDIV_RESERVE_C_02 = 10;
    /** 予備_Ｃ_03 */
    public final static int PAYDIV_RESERVE_C_03 = 11;
    /** 予備_Ｃ_04 */
    public final static int PAYDIV_RESERVE_C_04 = 12;
    /** 予備_Ｃ_05 */
    public final static int PAYDIV_RESERVE_C_05 = 13;
    /** 予備_Ｃ_06 */
    public final static int PAYDIV_RESERVE_C_06 = 14;
    /** 予備_Ｃ_07 */
    public final static int PAYDIV_RESERVE_C_07 = 15;
    /** 予備_Ｃ_08 */
    public final static int PAYDIV_RESERVE_C_08 = 16;
    /** 予備_Ｃ_09 */
    public final static int PAYDIV_RESERVE_C_09 = 17;
    /** 予備_Ｃ_10 */
    public final static int PAYDIV_RESERVE_C_10 = 18;
    /** 予備_Ｃ_11 */
    public final static int PAYDIV_RESERVE_C_11 = 19;
    /** 予備_Ｃ_12 */
    public final static int PAYDIV_RESERVE_C_12 = 20;
    /** 予備_Ｃ_13 */
    public final static int PAYDIV_RESERVE_C_13 = 21;
    /** 予備_Ｃ_14 */
    public final static int PAYDIV_RESERVE_C_14 = 22;
    /** 予備_Ｃ_15 */
    public final static int PAYDIV_RESERVE_C_15 = 23;
    /** 予備_Ｃ_16 */
    public final static int PAYDIV_RESERVE_C_16 = 24;
    /** 予備_Ｃ_17 */
    public final static int PAYDIV_RESERVE_C_17 = 25;
    /** 予備_Ｃ_18 */
    public final static int PAYDIV_RESERVE_C_18 = 26;
    /** 予備_Ｃ_19 */
    public final static int PAYDIV_RESERVE_C_19 = 27;
    /** 予備_Ｃ_20 */
    public final static int PAYDIV_RESERVE_C_20 = 28;
    /** 予備_Ｃ_21 */
    public final static int PAYDIV_RESERVE_C_21 = 29;
    /** 予備_Ｃ_22 */
    public final static int PAYDIV_RESERVE_C_22 = 30;
    /** 予備_Ｃ_23 */
    public final static int PAYDIV_RESERVE_C_23 = 31;
    /** 予備_Ｃ_24 */
    public final static int PAYDIV_RESERVE_C_24 = 32;
    /** 予備_Ｃ_25 */
    public final static int PAYDIV_RESERVE_C_25 = 33;
    /** 予備_Ｃ_26 */
    public final static int PAYDIV_RESERVE_C_26 = 34;
    /** 予備_Ｃ_27 */
    public final static int PAYDIV_RESERVE_C_27 = 35;
    /** 予備_Ｃ_28 */
    public final static int PAYDIV_RESERVE_C_28 = 36;
    /** 予備_Ｃ_29 */
    public final static int PAYDIV_RESERVE_C_29 = 37;
    /** 予備_Ｃ_30 */
    public final static int PAYDIV_RESERVE_C_30 = 38;
    /** 予備_Ｎ_01 */
    public final static int PAYDIV_RESERVE_N_01 = 39;
    /** 予備_Ｎ_02 */
    public final static int PAYDIV_RESERVE_N_02 = 40;
    /** 予備_Ｎ_03 */
    public final static int PAYDIV_RESERVE_N_03 = 41;
    /** 予備_Ｎ_04 */
    public final static int PAYDIV_RESERVE_N_04 = 42;
    /** 予備_Ｎ_05 */
    public final static int PAYDIV_RESERVE_N_05 = 43;
    /** 予備_Ｎ_06 */
    public final static int PAYDIV_RESERVE_N_06 = 44;
    /** 予備_Ｎ_07 */
    public final static int PAYDIV_RESERVE_N_07 = 45;
    /** 予備_Ｎ_08 */
    public final static int PAYDIV_RESERVE_N_08 = 46;
    /** 予備_Ｎ_09 */
    public final static int PAYDIV_RESERVE_N_09 = 47;
    /** 予備_Ｎ_10 */
    public final static int PAYDIV_RESERVE_N_10 = 48;
    /** 予備_Ｎ_11 */
    public final static int PAYDIV_RESERVE_N_11 = 49;
    /** 予備_Ｎ_12 */
    public final static int PAYDIV_RESERVE_N_12 = 50;
    /** 予備_Ｎ_13 */
    public final static int PAYDIV_RESERVE_N_13 = 51;
    /** 予備_Ｎ_14 */
    public final static int PAYDIV_RESERVE_N_14 = 52;
    /** 予備_Ｎ_15 */
    public final static int PAYDIV_RESERVE_N_15 = 53;
    /** 予備_Ｎ_16 */
    public final static int PAYDIV_RESERVE_N_16 = 54;
    /** 予備_Ｎ_17 */
    public final static int PAYDIV_RESERVE_N_17 = 55;
    /** 予備_Ｎ_18 */
    public final static int PAYDIV_RESERVE_N_18 = 56;
    /** 予備_Ｎ_19 */
    public final static int PAYDIV_RESERVE_N_19 = 57;
    /** 予備_Ｎ_20 */
    public final static int PAYDIV_RESERVE_N_20 = 58;
    /** 予備_Ｎ_21 */
    public final static int PAYDIV_RESERVE_N_21 = 59;
    /** 予備_Ｎ_22 */
    public final static int PAYDIV_RESERVE_N_22 = 60;
    /** 予備_Ｎ_23 */
    public final static int PAYDIV_RESERVE_N_23 = 61;
    /** 予備_Ｎ_24 */
    public final static int PAYDIV_RESERVE_N_24 = 62;
    /** 予備_Ｎ_25 */
    public final static int PAYDIV_RESERVE_N_25 = 63;
    /** 予備_Ｎ_26 */
    public final static int PAYDIV_RESERVE_N_26 = 64;
    /** 予備_Ｎ_27 */
    public final static int PAYDIV_RESERVE_N_27 = 65;
    /** 予備_Ｎ_28 */
    public final static int PAYDIV_RESERVE_N_28 = 66;
    /** 予備_Ｎ_29 */
    public final static int PAYDIV_RESERVE_N_29 = 67;
    /** 予備_Ｎ_30 */
    public final static int PAYDIV_RESERVE_N_30 = 68;
    /** 該当レコードのROWインデックス */
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    // public final static int PAYDIV_ROW_INDEX = 9;
    public final static int PAYDIV_ROW_INDEX = 69;
    /** フィールド数 */
    // public final static int PAYDIV_RECORD_COUNT = 10;
    public final static int PAYDIV_RECORD_COUNT = 70;
    // pzk add 20051206 e
    /** テーブルPAYDIVのキー(INTタイプ) */
    public final static int[] N_PAYDIV_ID = {PAYDIV_REC_NO, PAYDIV_BUKKEN_NO,
        PAYDIV_STAIR};
    /** テーブルPAYDIVのキー(STRINGタイプ) */
    public final static String[] STR_PAYDIV_ID = {"REC_NO", "BUKKEN_NO",
        "STAIR"};
    /** テーブルPAYDIVのSQLルート */
    public final static String PAYDIV_SQLROOT = "/" + PAYDIV_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String EPAYDIV_ROOT = "EPAYDIV";
    /** 案件番号 */
    public final static int EPAYDIV_ESTMAT_NO = 0;
    /** 物件番号 */
    public final static int EPAYDIV_BUKKEN_NO = 1;
    /** 段数 */
    public final static int EPAYDIV_STAIR = 2;
    /** 物件番号(from) */
    public final static int EPAYDIV_BUKKEN_FR = 3;
    /** 物件番号(to) */
    public final static int EPAYDIV_BUKKEN_TO = 4;
    /** 支払額 */
    public final static int EPAYDIV_PURCHASE = 5;
    /** 支払日（年） */
    public final static int EPAYDIV_DATE_YY = 6;
    /** 支払日（月） */
    public final static int EPAYDIV_DATE_MM = 7;
    /** 支払日（日） */
    public final static int EPAYDIV_DATE_DD = 8;
    // pzk add 20051206 s
    /** 予備_Ｃ_01 */
    public final static int EPAYDIV_RESERVE_C_01 = 9;
    /** 予備_Ｃ_02 */
    public final static int EPAYDIV_RESERVE_C_02 = 10;
    /** 予備_Ｃ_03 */
    public final static int EPAYDIV_RESERVE_C_03 = 11;
    /** 予備_Ｃ_04 */
    public final static int EPAYDIV_RESERVE_C_04 = 12;
    /** 予備_Ｃ_05 */
    public final static int EPAYDIV_RESERVE_C_05 = 13;
    /** 予備_Ｃ_06 */
    public final static int EPAYDIV_RESERVE_C_06 = 14;
    /** 予備_Ｃ_07 */
    public final static int EPAYDIV_RESERVE_C_07 = 15;
    /** 予備_Ｃ_08 */
    public final static int EPAYDIV_RESERVE_C_08 = 16;
    /** 予備_Ｃ_09 */
    public final static int EPAYDIV_RESERVE_C_09 = 17;
    /** 予備_Ｃ_10 */
    public final static int EPAYDIV_RESERVE_C_10 = 18;
    /** 予備_Ｃ_11 */
    public final static int EPAYDIV_RESERVE_C_11 = 19;
    /** 予備_Ｃ_12 */
    public final static int EPAYDIV_RESERVE_C_12 = 20;
    /** 予備_Ｃ_13 */
    public final static int EPAYDIV_RESERVE_C_13 = 21;
    /** 予備_Ｃ_14 */
    public final static int EPAYDIV_RESERVE_C_14 = 22;
    /** 予備_Ｃ_15 */
    public final static int EPAYDIV_RESERVE_C_15 = 23;
    /** 予備_Ｃ_16 */
    public final static int EPAYDIV_RESERVE_C_16 = 24;
    /** 予備_Ｃ_17 */
    public final static int EPAYDIV_RESERVE_C_17 = 25;
    /** 予備_Ｃ_18 */
    public final static int EPAYDIV_RESERVE_C_18 = 26;
    /** 予備_Ｃ_19 */
    public final static int EPAYDIV_RESERVE_C_19 = 27;
    /** 予備_Ｃ_20 */
    public final static int EPAYDIV_RESERVE_C_20 = 28;
    /** 予備_Ｃ_21 */
    public final static int EPAYDIV_RESERVE_C_21 = 29;
    /** 予備_Ｃ_22 */
    public final static int EPAYDIV_RESERVE_C_22 = 30;
    /** 予備_Ｃ_23 */
    public final static int EPAYDIV_RESERVE_C_23 = 31;
    /** 予備_Ｃ_24 */
    public final static int EPAYDIV_RESERVE_C_24 = 32;
    /** 予備_Ｃ_25 */
    public final static int EPAYDIV_RESERVE_C_25 = 33;
    /** 予備_Ｃ_26 */
    public final static int EPAYDIV_RESERVE_C_26 = 34;
    /** 予備_Ｃ_27 */
    public final static int EPAYDIV_RESERVE_C_27 = 35;
    /** 予備_Ｃ_28 */
    public final static int EPAYDIV_RESERVE_C_28 = 36;
    /** 予備_Ｃ_29 */
    public final static int EPAYDIV_RESERVE_C_29 = 37;
    /** 予備_Ｃ_30 */
    public final static int EPAYDIV_RESERVE_C_30 = 38;
    /** 予備_Ｎ_01 */
    public final static int EPAYDIV_RESERVE_N_01 = 39;
    /** 予備_Ｎ_02 */
    public final static int EPAYDIV_RESERVE_N_02 = 40;
    /** 予備_Ｎ_03 */
    public final static int EPAYDIV_RESERVE_N_03 = 41;
    /** 予備_Ｎ_04 */
    public final static int EPAYDIV_RESERVE_N_04 = 42;
    /** 予備_Ｎ_05 */
    public final static int EPAYDIV_RESERVE_N_05 = 43;
    /** 予備_Ｎ_06 */
    public final static int EPAYDIV_RESERVE_N_06 = 44;
    /** 予備_Ｎ_07 */
    public final static int EPAYDIV_RESERVE_N_07 = 45;
    /** 予備_Ｎ_08 */
    public final static int EPAYDIV_RESERVE_N_08 = 46;
    /** 予備_Ｎ_09 */
    public final static int EPAYDIV_RESERVE_N_09 = 47;
    /** 予備_Ｎ_10 */
    public final static int EPAYDIV_RESERVE_N_10 = 48;
    /** 予備_Ｎ_11 */
    public final static int EPAYDIV_RESERVE_N_11 = 49;
    /** 予備_Ｎ_12 */
    public final static int EPAYDIV_RESERVE_N_12 = 50;
    /** 予備_Ｎ_13 */
    public final static int EPAYDIV_RESERVE_N_13 = 51;
    /** 予備_Ｎ_14 */
    public final static int EPAYDIV_RESERVE_N_14 = 52;
    /** 予備_Ｎ_15 */
    public final static int EPAYDIV_RESERVE_N_15 = 53;
    /** 予備_Ｎ_16 */
    public final static int EPAYDIV_RESERVE_N_16 = 54;
    /** 予備_Ｎ_17 */
    public final static int EPAYDIV_RESERVE_N_17 = 55;
    /** 予備_Ｎ_18 */
    public final static int EPAYDIV_RESERVE_N_18 = 56;
    /** 予備_Ｎ_19 */
    public final static int EPAYDIV_RESERVE_N_19 = 57;
    /** 予備_Ｎ_20 */
    public final static int EPAYDIV_RESERVE_N_20 = 58;
    /** 予備_Ｎ_21 */
    public final static int EPAYDIV_RESERVE_N_21 = 59;
    /** 予備_Ｎ_22 */
    public final static int EPAYDIV_RESERVE_N_22 = 60;
    /** 予備_Ｎ_23 */
    public final static int EPAYDIV_RESERVE_N_23 = 61;
    /** 予備_Ｎ_24 */
    public final static int EPAYDIV_RESERVE_N_24 = 62;
    /** 予備_Ｎ_25 */
    public final static int EPAYDIV_RESERVE_N_25 = 63;
    /** 予備_Ｎ_26 */
    public final static int EPAYDIV_RESERVE_N_26 = 64;
    /** 予備_Ｎ_27 */
    public final static int EPAYDIV_RESERVE_N_27 = 65;
    /** 予備_Ｎ_28 */
    public final static int EPAYDIV_RESERVE_N_28 = 66;
    /** 予備_Ｎ_29 */
    public final static int EPAYDIV_RESERVE_N_29 = 67;
    /** 予備_Ｎ_30 */
    public final static int EPAYDIV_RESERVE_N_30 = 68;
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    /** 該当レコードのROWインデックス */
    // public final static int EPAYDIV_ROW_INDEX = 9;
    public final static int EPAYDIV_ROW_INDEX = 69;
    /** フィールド数 */
    // public final static int EPAYDIV_RECORD_COUNT = 10;
    public final static int EPAYDIV_RECORD_COUNT = 70;
    // pzk add 20051206 e
    /** テーブルEPAYDIVのSQLルート */
    public final static String EPAYDIV_SQLROOT = "/" + EPAYDIV_ROOT + "/ROW";
    /** テーブルEPAYDIVのキー(INTタイプ) */
    public final static int[] N_EPAYDIV_ID = {EPAYDIV_ESTMAT_NO,
        EPAYDIV_BUKKEN_NO, EPAYDIV_STAIR};
    /** テーブルEPAYDIVのキー(STRINGタイプ) */
    public final static String[] STR_EPAYDIV_ID = {"ESTMAT_NO", "BUKKEN_NO",
        "STAIR"};
    /** XMLのRoot */
    public final static String ECNTRCT_ROOT = "ECNTRCT";
    /** 見積番号 */
    public final static int ECNTRCT_ESTMAT_NO = 0;
    /** 案件種別 */
    public final static int ECNTRCT_CNTR_CATEG = 1;
    /** 契約先名１ */
    public final static int ECNTRCT_USER_NAME1 = 2;
    /** 契約先名２ */
    public final static int ECNTRCT_USER_NAME2 = 3;
    /** 連帯保証人 */
    public final static int ECNTRCT_JOIN_SURET = 4;
    /** その他１ */
    public final static int ECNTRCT_REMARK1 = 5;
    /** その他２ */
    public final static int ECNTRCT_REMARK2 = 6;
    /** その他３ */
    public final static int ECNTRCT_REMARK3 = 7;
    /** 先頭物件名 */
    public final static int ECNTRCT_LD_BUK_NM = 8;
    /** 検収NO（from） */
    public final static int ECNTRCT_KENSHU_FR = 9;
    /** 検収NO（to） */
    public final static int ECNTRCT_KENSHU_TO = 10;
    /** 物件Ｎｏ．(from) */
    public final static int ECNTRCT_BUKKEN_FR = 11;
    /** 物件Ｎｏ．(to) */
    public final static int ECNTRCT_BUKKEN_TO = 12;
    /** 契約額総額 */
    public final static int ECNTRCT_INCOME_GT = 13;
    /** 見積書出力回数 */
    public final static int ECNTRCT_OUT_CNT = 14;
    /** 見積書出力回日 */
    public final static int ECNTRCT_OUT_DATE = 15;
    /** 見積書発行日 */
    public final static int ECNTRCT_ISSUE_DATE = 16;
    /** 有効期限 */
    public final static int ECNTRCT_VALID_DATE = 17;
    /** 範囲指定区分 */
    public final static int ECNTRCT_RANGE_FLG = 18;
    /** 範囲指定（from） */
    public final static int ECNTRCT_RANGE_FR = 19;
    /** 範囲指定(to) */
    public final static int ECNTRCT_RANGE_TO = 20;
    /** 不連続指定 */
    public final static int ECNTRCT_FREE_SPEC = 21;
    /** 回収金額表示区分 */
    public final static int ECNTRCT_INC_DSP_F = 22;
    /** 回収料金表示区分 */
    public final static int ECNTRCT_RRT_DSP_F = 23;
    /** 売主表示区分 */
    public final static int ECNTRCT_DEAL_DSP_F = 24;
    /** 物件価格表示区分 */
    public final static int ECNTRCT_PURC_DSP_F = 25;
    /** 支払日表示区分 */
    public final static int ECNTRCT_PAYD_DSP_F = 26;
    /** 仮見積文言表示区分 */
    public final static int ECNTRCT_KARI_DSP_F = 27;
    /** 口振勧誘文言表示区分 */
    public final static int ECNTRCT_FURI_DSP_F = 28;
    /** 消費税表示区分 */
    public final static int ECNTRCT_CTAX_DSP_F = 29;
    /** 出力様式区分 */
    public final static int ECNTRCT_OUT_FORM_F = 30;
    /** 会社名表示区分 */
    public final static int ECNTRCT_COM_NM_F = 31;
    /** 角印表示区分 */
    public final static int ECNTRCT_ICON_D_F = 32;
    /** 見積NO表示区分 */
    public final static int ECNTRCT_ESTN_DSP_F = 33;
    /** 所有権留保 */
    public final static int ECNTRCT_SHOYU_KBN = 34;
    /** 更新日 */
    public final static int ECNTRCT_MOD_DATE = 35;
    /** 更新時刻 */
    public final static int ECNTRCT_MOD_TIME = 36;
    /** Siebel連係 */
    public final static int ECNTRCT_SBL_CALID = 37;
    /** シーベル商談ID */
    public final static int ECNTRCT_SBL_OPOID = 38;
    /** ホスト転送フラグ */
    public final static int ECNTRCT_HOST_SND_F = 39;
    /** ホスト転送日 */
    public final static int ECNTRCT_SEND_DATE = 40;
    /** 見積印刷ｶｳﾝﾀｰ */
    public final static int ECNTRCT_EST_CPYNO = 41;
    /** 部門CD */
    public final static int ECNTRCT_BRANCH_CD = 42;
    /** 部門名前 */
    public final static int ECNTRCT_BRANCH_NM = 43;
    /** 住所１ */
    public final static int ECNTRCT_ADDRESS1 = 44;
    /** 住所２ */
    public final static int ECNTRCT_ADDRESS2 = 45;
    /** 電話番号 */
    public final static int ECNTRCT_TELNO = 46;
    /** 担当者CD */
    public final static int ECNTRCT_PERSON_CD = 47;
    /** 担当者名前 */
    public final static int ECNTRCT_PERSON_NM = 48;
    /** Fax番号 */
    public final static int ECNTRCT_FAXNO = 49;
    /** Siebel 見積番号 */
    public final static int ECNTRCT_SBL_EST_NO = 50;
    /** SiebelRowID */
    public final static int ECNTRCT_SBL_ROWID = 51;
    /** シーベル登録日 */
    public final static int ECNTRCT_SBL_RGDATE = 52;
    /** シーベル登録時刻 */
    public final static int ECNTRCT_SBL_RGTIME = 53;
    /** 物件数（案件単位） */
    public final static int ECNTRCT_BUKKEN_NUM = 54;
    /** 予備 */
    public final static int ECNTRCT_RESERVE1 = 55;
    // pzk add 20051206 s
    /** 予備_Ｃ_01 */
    public final static int ECNTRCT_RESERVE_C_01 = 56;
    /** 予備_Ｃ_02 */
    public final static int ECNTRCT_RESERVE_C_02 = 57;
    /** 予備_Ｃ_03 */
    public final static int ECNTRCT_RESERVE_C_03 = 58;
    /** 予備_Ｃ_04 */
    public final static int ECNTRCT_RESERVE_C_04 = 59;
    /** 予備_Ｃ_05 */
    public final static int ECNTRCT_RESERVE_C_05 = 60;
    /** 予備_Ｃ_06 */
    public final static int ECNTRCT_RESERVE_C_06 = 61;
    /** 予備_Ｃ_07 */
    public final static int ECNTRCT_RESERVE_C_07 = 62;
    /** 予備_Ｃ_08 */
    public final static int ECNTRCT_RESERVE_C_08 = 63;
    /** 予備_Ｃ_09 */
    public final static int ECNTRCT_RESERVE_C_09 = 64;
    /** 予備_Ｃ_10 */
    public final static int ECNTRCT_RESERVE_C_10 = 65;
    /** 予備_Ｃ_11 */
    public final static int ECNTRCT_RESERVE_C_11 = 66;
    /** 予備_Ｃ_12 */
    public final static int ECNTRCT_RESERVE_C_12 = 67;
    /** 予備_Ｃ_13 */
    public final static int ECNTRCT_RESERVE_C_13 = 68;
    /** 予備_Ｃ_14 */
    public final static int ECNTRCT_RESERVE_C_14 = 69;
    /** 予備_Ｃ_15 */
    public final static int ECNTRCT_RESERVE_C_15 = 70;
    /** 予備_Ｃ_16 */
    public final static int ECNTRCT_RESERVE_C_16 = 71;
    /** 予備_Ｃ_17 */
    public final static int ECNTRCT_RESERVE_C_17 = 72;
    /** 予備_Ｃ_18 */
    public final static int ECNTRCT_RESERVE_C_18 = 73;
    /** 予備_Ｃ_19 */
    public final static int ECNTRCT_RESERVE_C_19 = 74;
    /** 予備_Ｃ_20 */
    public final static int ECNTRCT_RESERVE_C_20 = 75;
    /** 予備_Ｃ_21 */
    public final static int ECNTRCT_RESERVE_C_21 = 76;
    /** 予備_Ｃ_22 */
    public final static int ECNTRCT_RESERVE_C_22 = 77;
    /** 予備_Ｃ_23 */
    public final static int ECNTRCT_RESERVE_C_23 = 78;
    /** 予備_Ｃ_24 */
    public final static int ECNTRCT_RESERVE_C_24 = 79;
    /** 予備_Ｃ_25 */
    public final static int ECNTRCT_RESERVE_C_25 = 80;
    /** 予備_Ｃ_26 */
    public final static int ECNTRCT_RESERVE_C_26 = 81;
    /** 予備_Ｃ_27 */
    public final static int ECNTRCT_RESERVE_C_27 = 82;
    /** 予備_Ｃ_28 */
    public final static int ECNTRCT_RESERVE_C_28 = 83;
    /** 予備_Ｃ_29 */
    public final static int ECNTRCT_RESERVE_C_29 = 84;
    /** 予備_Ｃ_30 */
    public final static int ECNTRCT_RESERVE_C_30 = 85;
    /** 予備_Ｎ_01 */
    public final static int ECNTRCT_RESERVE_N_01 = 86;
    /** 予備_Ｎ_02 */
    public final static int ECNTRCT_RESERVE_N_02 = 87;
    /** 予備_Ｎ_03 */
    public final static int ECNTRCT_RESERVE_N_03 = 88;
    /** 予備_Ｎ_04 */
    public final static int ECNTRCT_RESERVE_N_04 = 89;
    /** 予備_Ｎ_05 */
    public final static int ECNTRCT_RESERVE_N_05 = 90;
    /** 予備_Ｎ_06 */
    public final static int ECNTRCT_RESERVE_N_06 = 91;
    /** 予備_Ｎ_07 */
    public final static int ECNTRCT_RESERVE_N_07 = 92;
    /** 予備_Ｎ_08 */
    public final static int ECNTRCT_RESERVE_N_08 = 93;
    /** 予備_Ｎ_09 */
    public final static int ECNTRCT_RESERVE_N_09 = 94;
    /** 予備_Ｎ_10 */
    public final static int ECNTRCT_RESERVE_N_10 = 95;
    /** 予備_Ｎ_11 */
    public final static int ECNTRCT_RESERVE_N_11 = 96;
    /** 予備_Ｎ_12 */
    public final static int ECNTRCT_RESERVE_N_12 = 97;
    /** 予備_Ｎ_13 */
    public final static int ECNTRCT_RESERVE_N_13 = 98;
    /** 予備_Ｎ_14 */
    public final static int ECNTRCT_RESERVE_N_14 = 99;
    /** 予備_Ｎ_15 */
    public final static int ECNTRCT_RESERVE_N_15 = 100;
    /** 予備_Ｎ_16 */
    public final static int ECNTRCT_RESERVE_N_16 = 101;
    /** 予備_Ｎ_17 */
    public final static int ECNTRCT_RESERVE_N_17 = 102;
    /** 予備_Ｎ_18 */
    public final static int ECNTRCT_RESERVE_N_18 = 103;
    /** 予備_Ｎ_19 */
    public final static int ECNTRCT_RESERVE_N_19 = 104;
    /** 予備_Ｎ_20 */
    public final static int ECNTRCT_RESERVE_N_20 = 105;
    /** 予備_Ｎ_21 */
    public final static int ECNTRCT_RESERVE_N_21 = 106;
    /** 予備_Ｎ_22 */
    public final static int ECNTRCT_RESERVE_N_22 = 107;
    /** 予備_Ｎ_23 */
    public final static int ECNTRCT_RESERVE_N_23 = 108;
    /** 予備_Ｎ_24 */
    public final static int ECNTRCT_RESERVE_N_24 = 109;
    /** 予備_Ｎ_25 */
    public final static int ECNTRCT_RESERVE_N_25 = 110;
    /** 予備_Ｎ_26 */
    public final static int ECNTRCT_RESERVE_N_26 = 111;
    /** 予備_Ｎ_27 */
    public final static int ECNTRCT_RESERVE_N_27 = 112;
    /** 予備_Ｎ_28 */
    public final static int ECNTRCT_RESERVE_N_28 = 113;
    /** 予備_Ｎ_29 */
    public final static int ECNTRCT_RESERVE_N_29 = 114;
    /** 予備_Ｎ_30 */
    public final static int ECNTRCT_RESERVE_N_30 = 115;
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    /** 該当レコードのROWインデックス */
    // public final static int ECNTRCT_ROW_INDEX = 56;
    public final static int ECNTRCT_ROW_INDEX = 116;
    /** フィールド数 */
    // public final static int ECNTRCT_RECORD_COUNT = 57;
    public final static int ECNTRCT_RECORD_COUNT = 117;
    // pzk add 20051206 e
    /** テーブルECNTRCTのキー(INTタイプ) */
    public final static int[] N_ECNTRCT_ID = {ECNTRCT_ESTMAT_NO};
    /** テーブルECNTRCTのキー(STRINGタイプ) */
    public final static String[] STR_ECNTRCT_ID = {"ESTMAT_NO"};
    /** テーブルECNTRCTのSQLルート */
    public final static String ECNTRCT_SQLROOT = "/" + ECNTRCT_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String EOBJECT_ROOT = "EOBJECT";
    /** 見積ＮＯ表示 */
    public final static int EOBJECT_ESTMAT_NO = 0;
    /** 物件番号 */
    public final static int EOBJECT_BUKKEN_NO = 1;
    /** 物件番号From */
    public final static int EOBJECT_BUKKEN_FR = 2;
    /** 物件番号To */
    public final static int EOBJECT_BUKKEN_TO = 3;
    /** 検収 */
    public final static int EOBJECT_KENSHU_NO = 4;
    /** 物件名 */
    public final static int EOBJECT_BUKKEN_NM = 5;
    /** 物件数量 */
    public final static int EOBJECT_QUANTITY = 6;
    /** 単位(半角) */
    public final static int EOBJECT_UNITS = 7;
    /** '(単位) */
    public final static int EOBJECT_UNITS_NM = 8;
    /** 検収予定日 */
    public final static int EOBJECT_DATE_KENSH = 9;
    /** 購入先名１ */
    public final static int EOBJECT_DEALER_NM1 = 10;
    /** 購入先名２ */
    public final static int EOBJECT_DEALER_NM2 = 11;
    /** 購入価額(work) */
    public final static int EOBJECT_PURCHASE = 12;
    /** 支払期日(work) */
    public final static int EOBJECT_PAY_FIX_DT = 13;
    /** 転貸有無 */
    public final static int EOBJECT_SUBLET_FLG = 14;
    /** 具体的引渡し場所 */
    public final static int EOBJECT_DELIV_PLAC = 15;
    /** リース期間(work) */
    public final static int EOBJECT_LEASE_M = 16;
    /** 割賦回数 */
    public final static int EOBJECT_KAPPU_D = 17;
    /** 月額リース料(work) */
    public final static int EOBJECT_INCOME = 18;
    /** 合計料率(work) */
    public final static int EOBJECT_RYORITSU_T = 19;
    /** 月料率(work) */
    public final static int EOBJECT_RYORITSU_M = 20;
    /** 前受リース月数(work) */
    public final static int EOBJECT_INC_0_M = 21;
    /** 前受リース料(work) */
    public final static int EOBJECT_INCOME_0 = 22;
    /** 変則回収区分 */
    public final static int EOBJECT_IRG_INC_F = 23;
    /** 前受回収日 */
    public final static int EOBJECT_DATE_INC_0 = 24;
    /** 前受回収方法１ */
    public final static int EOBJECT_MET1_INC_0 = 25;
    /** 前受回収方法２ */
    public final static int EOBJECT_MET2_INC_0 = 26;
    /** 第一月分回収日 */
    public final static int EOBJECT_DATE_INC_1 = 27;
    /** 第一月分回収方法１ */
    public final static int EOBJECT_MET1_INC_1 = 28;
    /** 第一月分回収方法２ */
    public final static int EOBJECT_MET2_INC_1 = 29;
    /** 第二月分回収日 */
    public final static int EOBJECT_DATE_INC_2 = 30;
    /** 第二月分回収方法１ */
    public final static int EOBJECT_MET1_INC_2 = 31;
    /** 第二月分回収方法２ */
    public final static int EOBJECT_MET2_INC_2 = 32;
    /** 固定資産税算入区分 */
    public final static int EOBJECT_SW_FIX_AST = 33;
    /** 動総保険付保区分 */
    public final static int EOBJECT_SW_DOSO = 34;
    /** 賠責保険付保区分 */
    public final static int EOBJECT_SW_BAISEKI = 35;
    /** 機械保険付保区分 */
    public final static int EOBJECT_SW_MACHI = 36;
    /** 火災保険付保区分 */
    public final static int EOBJECT_SW_FIRE = 37;
    /** 船舶・他保険付保区分 */
    public final static int EOBJECT_SW_ETC = 38;
    /** 団信保険付保区分 */
    public final static int EOBJECT_SW_DANSHIN = 39;
    /** 込保守料算入区分 */
    public final static int EOBJECT_SW_HOSHU = 40;
    /** 最リース料率 */
    public final static int EOBJECT_RELEASE_RT = 41;
    /** 試算データ使用区分 */
    public final static int EOBJECT_PROF_USE_F = 42;
    /** 予備 */
    public final static int EOBJECT_RESERVE1 = 43;
    // pzk add 20051206 s
    /** 予備_Ｃ_01 */
    public final static int EOBJECT_RESERVE_C_01 = 44;
    /** 予備_Ｃ_02 */
    public final static int EOBJECT_RESERVE_C_02 = 45;
    /** 予備_Ｃ_03 */
    public final static int EOBJECT_RESERVE_C_03 = 46;
    /** 予備_Ｃ_04 */
    public final static int EOBJECT_RESERVE_C_04 = 47;
    /** 予備_Ｃ_05 */
    public final static int EOBJECT_RESERVE_C_05 = 48;
    /** 予備_Ｃ_06 */
    public final static int EOBJECT_RESERVE_C_06 = 49;
    /** 予備_Ｃ_07 */
    public final static int EOBJECT_RESERVE_C_07 = 50;
    /** 予備_Ｃ_08 */
    public final static int EOBJECT_RESERVE_C_08 = 51;
    /** 予備_Ｃ_09 */
    public final static int EOBJECT_RESERVE_C_09 = 52;
    /** 予備_Ｃ_10 */
    public final static int EOBJECT_RESERVE_C_10 = 53;
    /** 予備_Ｃ_11 */
    public final static int EOBJECT_RESERVE_C_11 = 54;
    /** 予備_Ｃ_12 */
    public final static int EOBJECT_RESERVE_C_12 = 55;
    /** 予備_Ｃ_13 */
    public final static int EOBJECT_RESERVE_C_13 = 56;
    /** 予備_Ｃ_14 */
    public final static int EOBJECT_RESERVE_C_14 = 57;
    /** 予備_Ｃ_15 */
    public final static int EOBJECT_RESERVE_C_15 = 58;
    /** 予備_Ｃ_16 */
    public final static int EOBJECT_RESERVE_C_16 = 59;
    /** 予備_Ｃ_17 */
    public final static int EOBJECT_RESERVE_C_17 = 60;
    /** 予備_Ｃ_18 */
    public final static int EOBJECT_RESERVE_C_18 = 61;
    /** 予備_Ｃ_19 */
    public final static int EOBJECT_RESERVE_C_19 = 62;
    /** 予備_Ｃ_20 */
    public final static int EOBJECT_RESERVE_C_20 = 63;
    /** 予備_Ｃ_21 */
    public final static int EOBJECT_RESERVE_C_21 = 64;
    /** 予備_Ｃ_22 */
    public final static int EOBJECT_RESERVE_C_22 = 65;
    /** 予備_Ｃ_23 */
    public final static int EOBJECT_RESERVE_C_23 = 66;
    /** 予備_Ｃ_24 */
    public final static int EOBJECT_RESERVE_C_24 = 67;
    /** 予備_Ｃ_25 */
    public final static int EOBJECT_RESERVE_C_25 = 68;
    /** 予備_Ｃ_26 */
    public final static int EOBJECT_RESERVE_C_26 = 69;
    /** 予備_Ｃ_27 */
    public final static int EOBJECT_RESERVE_C_27 = 70;
    /** 予備_Ｃ_28 */
    public final static int EOBJECT_RESERVE_C_28 = 71;
    /** 予備_Ｃ_29 */
    public final static int EOBJECT_RESERVE_C_29 = 72;
    /** 予備_Ｃ_30 */
    public final static int EOBJECT_RESERVE_C_30 = 73;
    /** 予備_Ｎ_01 */
    public final static int EOBJECT_RESERVE_N_01 = 74;
    //ydy modify 20090117 s
    /** 予備_Ｎ_02 */
//	public final static int EOBJECT_RESERVE_N_02 = 75;
    /** ROIの税率 */
    public final static int EOBJECT_RESERVE_N_02 = 75;
    //ydy modify 20090117 e
    /** 予備_Ｎ_03 */
    public final static int EOBJECT_RESERVE_N_03 = 76;
    /** 予備_Ｎ_04 */
    public final static int EOBJECT_RESERVE_N_04 = 77;
    /** 予備_Ｎ_05 */
    public final static int EOBJECT_RESERVE_N_05 = 78;
    /** 予備_Ｎ_06 */
    public final static int EOBJECT_RESERVE_N_06 = 79;
    /** 予備_Ｎ_07 */
    public final static int EOBJECT_RESERVE_N_07 = 80;
    /** 予備_Ｎ_08 */
    public final static int EOBJECT_RESERVE_N_08 = 81;
    /** 予備_Ｎ_09 */
    public final static int EOBJECT_RESERVE_N_09 = 82;
    /** 予備_Ｎ_10 */
    public final static int EOBJECT_RESERVE_N_10 = 83;
    /** 予備_Ｎ_11 */
    public final static int EOBJECT_RESERVE_N_11 = 84;
    /** 予備_Ｎ_12 */
    public final static int EOBJECT_RESERVE_N_12 = 85;
    /** 予備_Ｎ_13 */
    public final static int EOBJECT_RESERVE_N_13 = 86;
    /** 予備_Ｎ_14 */
    public final static int EOBJECT_RESERVE_N_14 = 87;
    /** 予備_Ｎ_15 */
    public final static int EOBJECT_RESERVE_N_15 = 88;
    /** 予備_Ｎ_16 */
    public final static int EOBJECT_RESERVE_N_16 = 89;
    /** 予備_Ｎ_17 */
    public final static int EOBJECT_RESERVE_N_17 = 90;
    /** 予備_Ｎ_18 */
    public final static int EOBJECT_RESERVE_N_18 = 91;
    /** 予備_Ｎ_19 */
    public final static int EOBJECT_RESERVE_N_19 = 92;
    /** 予備_Ｎ_20 */
    public final static int EOBJECT_RESERVE_N_20 = 93;
    /** 予備_Ｎ_21 */
    public final static int EOBJECT_RESERVE_N_21 = 94;
    /** 予備_Ｎ_22 */
    public final static int EOBJECT_RESERVE_N_22 = 95;
    /** 予備_Ｎ_23 */
    public final static int EOBJECT_RESERVE_N_23 = 96;
    /** 予備_Ｎ_24 */
    public final static int EOBJECT_RESERVE_N_24 = 97;
    /** 予備_Ｎ_25 */
    public final static int EOBJECT_RESERVE_N_25 = 98;
    /** 予備_Ｎ_26 */
    public final static int EOBJECT_RESERVE_N_26 = 99;
    /** 予備_Ｎ_27 */
    public final static int EOBJECT_RESERVE_N_27 = 100;
    /** 予備_Ｎ_28 */
    public final static int EOBJECT_RESERVE_N_28 = 101;
    /** 予備_Ｎ_29 */
    public final static int EOBJECT_RESERVE_N_29 = 102;
    /** 予備_Ｎ_30 */
    public final static int EOBJECT_RESERVE_N_30 = 103;
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    /** 該当レコードのROWインデックス */
    // public final static int EOBJECT_ROW_INDEX = 44;
    public final static int EOBJECT_ROW_INDEX = 104;
    /** フィールド数 */
    // public final static int EOBJECT_RECORD_COUNT = 45;
    public final static int EOBJECT_RECORD_COUNT = 105;
    // pzk add 20051206 e
    /** テーブルEOBJECTのキー(INTタイプ) */
    public final static int[] N_EOBJECT_ID = {EOBJECT_ESTMAT_NO,
        EOBJECT_BUKKEN_NO};
    /** テーブルEOBJECTのキー(STRINGタイプ) */
    public final static String[] STR_EOBJECT_ID = {"ESTMAT_NO", "BUKKEN_NO"};
    /** テーブルEOBJECTのSQLルート */
    public final static String EOBJECT_SQLROOT = "/" + EOBJECT_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String EPROFIT_ROOT = "EPROFIT";
    /** 見積番号 */
    public final static int EPROFIT_ESTMAT_NO = 0;
    /** 物件番号 */
    public final static int EPROFIT_BUKKEN_NO = 1;
    /** 物件番号(From) */
    public final static int EPROFIT_BUKKEN_FR = 2;
    /** 物件番号(To) */
    public final static int EPROFIT_BUKKEN_TO = 3;
    /** 残価 */
    public final static int EPROFIT_REMAIN_VAL = 4;
    /** 残価率 */
    public final static int EPROFIT_REM_VAL_RT = 5;
    /** 法定耐用年数 */
    public final static int EPROFIT_DURABLE_Y = 6;
    /** 動総保険料率 */
    public final static int EPROFIT_DOSO_RATE = 7;
    /** 団信保険付保料率 */
    public final static int EPROFIT_DANSHIN_RT = 8;
    /** 信保付保期間 */
    public final static int EPROFIT_CRE_INS_TM = 9;
    /** 信保付保料率 */
    public final static int EPROFIT_CRE_INS_RT = 10;
    /** 公正証書作成費用 */
    public final static int EPROFIT_ICHIJI_1 = 11;
    /** 一時費用（ロ） */
    public final static int EPROFIT_ICHIJI_2 = 12;
    /** 一時費用（ハ） */
    public final static int EPROFIT_ICHIJI_3 = 13;
    /** 斡旋手数料 */
    public final static int EPROFIT_ASSEN = 14;
    /** 固定資産税 */
    public final static int EPROFIT_FIXASTTAX = 15;
    /** 動総保険料 */
    public final static int EPROFIT_DOSO_FEE = 16;
    /** 賠責保険料 */
    public final static int EPROFIT_BAIS_FEE = 17;
    /** 機械保険料 */
    public final static int EPROFIT_MACHI_FEE = 18;
    /** 火災保険料 */
    public final static int EPROFIT_FIRE_FEE = 19;
    /** 船舶・その他保険料 */
    public final static int EPROFIT_ETC_FEE = 20;
    /** 割賦保険料 */
    public final static int EPROFIT_KAPPU_INS = 21;
    /** 繰延費用(ヘ) */
    public final static int EPROFIT_KURINO_1 = 22;
    /** 繰延費用(ト) */
    public final static int EPROFIT_KURINO_2 = 23;
    /** 保守料 */
    public final static int EPROFIT_HOSHURYO = 24;
    /** 機械類ﾘｰｽ信用保険 */
    public final static int EPROFIT_CREDIT_INS = 25;
    /** 契約額 */
    public final static int EPROFIT_INCOME_GT = 26;
    /** 分割支払区分 */
    public final static int EPROFIT_SW_PAY = 27;
    /** 支払予定日 */
    public final static int EPROFIT_DATE_PAYMT = 28;
    /** 原価調整月数 */
    public final static int EPROFIT_ADJUST_M = 29;
    /** 原価調整日数 */
    public final static int EPROFIT_ADJUST_D = 30;
    /** 回収利息 */
    public final static int EPROFIT_INTEREST_I = 31;
    /** ＴＲ */
    public final static int EPROFIT_TRUE_RATE = 32;
    /** 支払利息 */
    public final static int EPROFIT_INTEREST_P = 33;
    /** 使用総資産 */
    public final static int EPROFIT_CAPITAL_T = 34;
    /** 当社手数料 */
    public final static int EPROFIT_CHARGE = 35;
    /** 原価調整額 */
    public final static int EPROFIT_C_ADJUST = 36;
    /** 荒利益額 */
    public final static int EPROFIT_PROFIT_T = 37;
    /** 社内金利 */
    public final static int EPROFIT_RATE_JLC = 38;
    /** 年利廻り */
    public final static int EPROFIT_RATE_YEAR = 39;
    /** 運用利回り */
    public final static int EPROFIT_RATE_UNYO = 40;
    /** 原調計算金利 */
    public final static int EPROFIT_RATE_C_ADJ = 41;
    /** ＲＯＩ */
    public final static int EPROFIT_RATE_ROI = 42;
    /** 管販費率 */
    public final static int EPROFIT_RATE_E_ANI = 43;
    /** 管販費率Original */
    public final static int EPROFIT_RATE_E_A_O = 44;
    /** 管販費率Service */
    public final static int EPROFIT_RATE_E_A_S = 45;
    /** 貸倒引当率 */
    public final static int EPROFIT_RATE_LOSS = 46;
    /** 手数料収益率 */
    public final static int EPROFIT_RATE_FEE = 47;
    /** 手数料収益率NPP */
    public final static int EPROFIT_RATE_FEE_N = 48;
    /** 手数料収益率Release */
    public final static int EPROFIT_RATE_FEE_R = 49;
    /** CST機種コード */
    public final static int EPROFIT_CSTKISHUCD = 50;
    /** ﾌﾙﾍﾟｲ支払利息 */
    public final static int EPROFIT_F_INTER_P = 51;
    /** ﾌﾙﾍﾟｲ回収利息 */
    public final static int EPROFIT_F_INTER_I = 52;
    /** ﾌﾙﾍﾟｲ当社手数料 */
    public final static int EPROFIT_F_CHARGE = 53;
    /** ﾌﾙﾍﾟｲ実行費用総額 */
    public final static int EPROFIT_F_EXEC_C = 54;
    /** ﾌﾙﾍﾟｲ繰延費用(ヘ) */
    public final static int EPROFIT_F_KURI_1 = 55;
    /** ﾌﾙﾍﾟｲ保険料 */
    public final static int EPROFIT_F_INSUR = 56;
    /** ﾌﾙﾍﾟｲﾘｰｽ原価計 */
    public final static int EPROFIT_F_COST_T = 57;
    /** ﾌﾙﾍﾟｲ荒利益額 */
    public final static int EPROFIT_F_PRO_T = 58;
    /** ﾌﾙﾍﾟｲ年荒利益額 */
    public final static int EPROFIT_F_PRO_Y = 59;
    /** ﾌﾙﾍﾟｲ使用総資産 */
    public final static int EPROFIT_F_CAPIT_T = 60;
    /** ﾌﾙﾍﾟｲＴＲ */
    public final static int EPROFIT_F_TRUE_RT = 61;
    /** ﾌﾙﾍﾟｲ年利廻り */
    public final static int EPROFIT_F_RT_YR = 62;
    /** ﾌﾙﾍﾟｲ運用利回り */
    public final static int EPROFIT_F_RT_UN = 63;
    /** ﾌﾙﾍﾟｲ総荒利率 */
    public final static int EPROFIT_F_RT_PRT = 64;
    /** ﾌﾙﾍﾟｲ年荒利率 */
    public final static int EPROFIT_F_RT_PRY = 65;
    /** ﾌﾟﾙﾍﾟｲROI */
    public final static int EPROFIT_F_RT_ROI = 66;
    /** RA_Margin */
    public final static int EPROFIT_RA_MARGIN = 67;
    /** RA_PV_Margin */
    public final static int EPROFIT_RA_PV_MARGIN = 68;
    /** Finance_Margin */
    public final static int EPROFIT_FINANCE_MARGIN = 69;
    /** PV_Finance_Margin */
    public final static int EPROFIT_PV_FINANCE_MARGIN = 70;
    /** ﾌﾙﾍﾟｲRA_Margin */
    public final static int EPROFIT_F_RA_MARGIN = 71;
    /** ﾌﾙﾍﾟｲRA_PV_Margin */
    public final static int EPROFIT_F_RA_PV_MARGIN = 72;
    /** ﾌﾙﾍﾟｲFinance_Margin */
    public final static int EPROFIT_F_FINANCE_MARGIN = 73;
    /** ﾌﾟﾙﾍﾟｲPV_Finance_Margin */
    public final static int EPROFIT_F_PV_FINANCE_MARGIN = 74;
    /** リース原価 */
    public final static int EPROFIT_COST_TOTAL = 75;
    /** 保険料 */
    public final static int EPROFIT_INSURANCE = 76;
    /** 均等回収区分 */
    public final static int EPROFIT_EVEN_FLG = 77;
    /** 回収段数 */
    public final static int EPROFIT_COLLECT_D = 78;
    /** 支払段数 */
    public final static int EPROFIT_PAYDIV_D = 79;
    /** 予備 */
    public final static int EPROFIT_RESERVE1 = 80;
    /** Product */
    public final static int EPROFIT_PRODUCT = 81;
    /** Leverage */
    public final static int EPROFIT_LEVERAGE = 82;
    /** ROE */
    public final static int EPROFIT_ROE = 83;
    /** FP_ROE */
    public final static int EPROFIT_FP_ROE = 84;
    /** PRODUCT_CD */
    public final static int EPROFIT_PRODUCT_CD = 85;
    // pzk add 20051206 s
    /** 予備_Ｃ_01 */
    public final static int EPROFIT_RESERVE_C_01 = 86;
    /** 予備_Ｃ_02 */
    public final static int EPROFIT_RESERVE_C_02 = 87;
    /** 予備_Ｃ_03 */
    public final static int EPROFIT_RESERVE_C_03 = 88;
    /** 予備_Ｃ_04 */
    public final static int EPROFIT_RESERVE_C_04 = 89;
    /** 予備_Ｃ_05 */
    public final static int EPROFIT_RESERVE_C_05 = 90;
    /** 予備_Ｃ_06 */
    public final static int EPROFIT_RESERVE_C_06 = 91;
    /** 予備_Ｃ_07 */
    public final static int EPROFIT_RESERVE_C_07 = 92;
    /** 予備_Ｃ_08 */
    public final static int EPROFIT_RESERVE_C_08 = 93;
    /** 予備_Ｃ_09 */
    public final static int EPROFIT_RESERVE_C_09 = 94;
    /** 予備_Ｃ_10 */
    public final static int EPROFIT_RESERVE_C_10 = 95;
    /** 予備_Ｃ_11 */
    public final static int EPROFIT_RESERVE_C_11 = 96;
    /** 予備_Ｃ_12 */
    public final static int EPROFIT_RESERVE_C_12 = 97;
    /** 予備_Ｃ_13 */
    public final static int EPROFIT_RESERVE_C_13 = 98;
    /** 予備_Ｃ_14 */
    public final static int EPROFIT_RESERVE_C_14 = 99;
    /** 予備_Ｃ_15 */
    public final static int EPROFIT_RESERVE_C_15 = 100;
    /** 予備_Ｃ_16 */
    public final static int EPROFIT_RESERVE_C_16 = 101;
    /** 予備_Ｃ_17 */
    public final static int EPROFIT_RESERVE_C_17 = 102;
    /** 予備_Ｃ_18 */
    public final static int EPROFIT_RESERVE_C_18 = 103;
    /** 予備_Ｃ_19 */
    public final static int EPROFIT_RESERVE_C_19 = 104;
    /** 予備_Ｃ_20 */
    public final static int EPROFIT_RESERVE_C_20 = 105;
    /** 予備_Ｃ_21 */
    public final static int EPROFIT_RESERVE_C_21 = 106;
    /** 予備_Ｃ_22 */
    public final static int EPROFIT_RESERVE_C_22 = 107;
    /** 予備_Ｃ_23 */
    public final static int EPROFIT_RESERVE_C_23 = 108;
    /** 予備_Ｃ_24 */
    public final static int EPROFIT_RESERVE_C_24 = 109;
    /** 予備_Ｃ_25 */
    public final static int EPROFIT_RESERVE_C_25 = 110;
    /** 予備_Ｃ_26 */
    public final static int EPROFIT_RESERVE_C_26 = 111;
    /** 予備_Ｃ_27 */
    public final static int EPROFIT_RESERVE_C_27 = 112;
    /** 予備_Ｃ_28 */
    public final static int EPROFIT_RESERVE_C_28 = 113;
    /** 予備_Ｃ_29 */
    public final static int EPROFIT_RESERVE_C_29 = 114;
    /** 予備_Ｃ_30 */
    public final static int EPROFIT_RESERVE_C_30 = 115;
    /** 予備_Ｎ_01 */
    public final static int EPROFIT_RESERVE_N_01 = 116;
    /** 予備_Ｎ_02 */
    public final static int EPROFIT_RESERVE_N_02 = 117;
    /** 予備_Ｎ_03 */
    public final static int EPROFIT_RESERVE_N_03 = 118;
    /** 予備_Ｎ_04 */
    public final static int EPROFIT_RESERVE_N_04 = 119;
    /** 予備_Ｎ_05 */
    public final static int EPROFIT_RESERVE_N_05 = 120;
    /** 予備_Ｎ_06 */
    public final static int EPROFIT_RESERVE_N_06 = 121;
    /** 予備_Ｎ_07 */
    public final static int EPROFIT_RESERVE_N_07 = 122;
    /** 予備_Ｎ_08 */
    public final static int EPROFIT_RESERVE_N_08 = 123;
    /** 予備_Ｎ_09 */
    public final static int EPROFIT_RESERVE_N_09 = 124;
    /** 予備_Ｎ_10 */
    public final static int EPROFIT_RESERVE_N_10 = 125;
    /** 予備_Ｎ_11 */
    public final static int EPROFIT_RESERVE_N_11 = 126;
    /** 予備_Ｎ_12 */
    public final static int EPROFIT_RESERVE_N_12 = 127;
    /** 予備_Ｎ_13 */
    public final static int EPROFIT_RESERVE_N_13 = 128;
    /** 予備_Ｎ_14 */
    public final static int EPROFIT_RESERVE_N_14 = 129;
    /** 予備_Ｎ_15 */
    public final static int EPROFIT_RESERVE_N_15 = 130;
    /** 予備_Ｎ_16 */
    public final static int EPROFIT_RESERVE_N_16 = 131;
    /** 予備_Ｎ_17 */
    public final static int EPROFIT_RESERVE_N_17 = 132;
    /** 予備_Ｎ_18 */
    public final static int EPROFIT_RESERVE_N_18 = 133;
    /** 予備_Ｎ_19 */
    public final static int EPROFIT_RESERVE_N_19 = 134;
    /** 予備_Ｎ_20 */
    public final static int EPROFIT_RESERVE_N_20 = 135;
    /** 予備_Ｎ_21 */
    public final static int EPROFIT_RESERVE_N_21 = 136;
    /** 予備_Ｎ_22 */
    public final static int EPROFIT_RESERVE_N_22 = 137;
    /** 予備_Ｎ_23 */
    public final static int EPROFIT_RESERVE_N_23 = 138;
    /** 予備_Ｎ_24 */
    public final static int EPROFIT_RESERVE_N_24 = 139;
    /** 予備_Ｎ_25 */
    public final static int EPROFIT_RESERVE_N_25 = 140;
    /** 予備_Ｎ_26 */
    public final static int EPROFIT_RESERVE_N_26 = 141;
    /** 予備_Ｎ_27 */
    public final static int EPROFIT_RESERVE_N_27 = 142;
    /** 予備_Ｎ_28 */
    public final static int EPROFIT_RESERVE_N_28 = 143;
    /** 予備_Ｎ_29 */
    public final static int EPROFIT_RESERVE_N_29 = 144;
    /** 予備_Ｎ_30 */
    public final static int EPROFIT_RESERVE_N_30 = 145;
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    /** 該当レコードのROWインデックス */
    // public final static int EPROFIT_ROW_INDEX = 86;
    public final static int EPROFIT_ROW_INDEX = 146;
    /** フィールド数 */
    // public final static int EPROFIT_RECORD_COUNT = 87;
    public final static int EPROFIT_RECORD_COUNT = 147;
    // pzk add 20051206 e
    /** テーブルEPROFITのキー(INTタイプ) */
    public final static int[] N_EPROFIT_ID = {EPROFIT_ESTMAT_NO,
        EPROFIT_BUKKEN_NO};
    /** テーブルEPROFITのキー(STRINGタイプ) */
    public final static String[] STR_EPROFIT_ID = {"ESTMAT_NO", "BUKKEN_NO"};
    /** テーブルEPROFITのSQLルート */
    public final static String EPROFIT_SQLROOT = "/" + EPROFIT_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String STAIRS_ROOT = "STAIRS";
    /** 案件番号 */
    public final static int STAIRS_REC_NO = 0;
    /** 物件番号 */
    public final static int STAIRS_BUKKEN_NO = 1;
    /** 段数 */
    public final static int STAIRS_STAIR = 2;
    /** 物件番号(from) */
    public final static int STAIRS_BUKKEN_FR = 3;
    /** 物件番号(to) */
    public final static int STAIRS_BUKKEN_TO = 4;
    /** 回収金額 */
    public final static int STAIRS_INCOME = 5;
    /** 回収サイク */
    public final static int STAIRS_CYCLE = 6;
    /** 回数 */
    public final static int STAIRS_FREQUE = 7;
    /** 回収年 */
    public final static int STAIRS_DATE_YY = 8;
    /** 回収月 */
    public final static int STAIRS_DATE_MM = 9;
    /** 回収日 */
    public final static int STAIRS_DATE_DD = 10;
    // pzk add 20051206 s
    /** 予備_Ｃ_01 */
    public final static int STAIRS_RESERVE_C_01 = 11;
    /** 予備_Ｃ_02 */
    public final static int STAIRS_RESERVE_C_02 = 12;
    /** 予備_Ｃ_03 */
    public final static int STAIRS_RESERVE_C_03 = 13;
    /** 予備_Ｃ_04 */
    public final static int STAIRS_RESERVE_C_04 = 14;
    /** 予備_Ｃ_05 */
    public final static int STAIRS_RESERVE_C_05 = 15;
    /** 予備_Ｃ_06 */
    public final static int STAIRS_RESERVE_C_06 = 16;
    /** 予備_Ｃ_07 */
    public final static int STAIRS_RESERVE_C_07 = 17;
    /** 予備_Ｃ_08 */
    public final static int STAIRS_RESERVE_C_08 = 18;
    /** 予備_Ｃ_09 */
    public final static int STAIRS_RESERVE_C_09 = 19;
    /** 予備_Ｃ_10 */
    public final static int STAIRS_RESERVE_C_10 = 20;
    /** 予備_Ｃ_11 */
    public final static int STAIRS_RESERVE_C_11 = 21;
    /** 予備_Ｃ_12 */
    public final static int STAIRS_RESERVE_C_12 = 22;
    /** 予備_Ｃ_13 */
    public final static int STAIRS_RESERVE_C_13 = 23;
    /** 予備_Ｃ_14 */
    public final static int STAIRS_RESERVE_C_14 = 24;
    /** 予備_Ｃ_15 */
    public final static int STAIRS_RESERVE_C_15 = 25;
    /** 予備_Ｃ_16 */
    public final static int STAIRS_RESERVE_C_16 = 26;
    /** 予備_Ｃ_17 */
    public final static int STAIRS_RESERVE_C_17 = 27;
    /** 予備_Ｃ_18 */
    public final static int STAIRS_RESERVE_C_18 = 28;
    /** 予備_Ｃ_19 */
    public final static int STAIRS_RESERVE_C_19 = 29;
    /** 予備_Ｃ_20 */
    public final static int STAIRS_RESERVE_C_20 = 30;
    /** 予備_Ｃ_21 */
    public final static int STAIRS_RESERVE_C_21 = 31;
    /** 予備_Ｃ_22 */
    public final static int STAIRS_RESERVE_C_22 = 32;
    /** 予備_Ｃ_23 */
    public final static int STAIRS_RESERVE_C_23 = 33;
    /** 予備_Ｃ_24 */
    public final static int STAIRS_RESERVE_C_24 = 34;
    /** 予備_Ｃ_25 */
    public final static int STAIRS_RESERVE_C_25 = 35;
    /** 予備_Ｃ_26 */
    public final static int STAIRS_RESERVE_C_26 = 36;
    /** 予備_Ｃ_27 */
    public final static int STAIRS_RESERVE_C_27 = 37;
    /** 予備_Ｃ_28 */
    public final static int STAIRS_RESERVE_C_28 = 38;
    /** 予備_Ｃ_29 */
    public final static int STAIRS_RESERVE_C_29 = 39;
    /** 予備_Ｃ_30 */
    public final static int STAIRS_RESERVE_C_30 = 40;
    /** 予備_Ｎ_01 */
    public final static int STAIRS_RESERVE_N_01 = 41;
    /** 予備_Ｎ_02 */
    public final static int STAIRS_RESERVE_N_02 = 42;
    /** 予備_Ｎ_03 */
    public final static int STAIRS_RESERVE_N_03 = 43;
    /** 予備_Ｎ_04 */
    public final static int STAIRS_RESERVE_N_04 = 44;
    /** 予備_Ｎ_05 */
    public final static int STAIRS_RESERVE_N_05 = 45;
    /** 予備_Ｎ_06 */
    public final static int STAIRS_RESERVE_N_06 = 46;
    /** 予備_Ｎ_07 */
    public final static int STAIRS_RESERVE_N_07 = 47;
    /** 予備_Ｎ_08 */
    public final static int STAIRS_RESERVE_N_08 = 48;
    /** 予備_Ｎ_09 */
    public final static int STAIRS_RESERVE_N_09 = 49;
    /** 予備_Ｎ_10 */
    public final static int STAIRS_RESERVE_N_10 = 50;
    /** 予備_Ｎ_11 */
    public final static int STAIRS_RESERVE_N_11 = 51;
    /** 予備_Ｎ_12 */
    public final static int STAIRS_RESERVE_N_12 = 52;
    /** 予備_Ｎ_13 */
    public final static int STAIRS_RESERVE_N_13 = 53;
    /** 予備_Ｎ_14 */
    public final static int STAIRS_RESERVE_N_14 = 54;
    /** 予備_Ｎ_15 */
    public final static int STAIRS_RESERVE_N_15 = 55;
    /** 予備_Ｎ_16 */
    public final static int STAIRS_RESERVE_N_16 = 56;
    /** 予備_Ｎ_17 */
    public final static int STAIRS_RESERVE_N_17 = 57;
    /** 予備_Ｎ_18 */
    public final static int STAIRS_RESERVE_N_18 = 58;
    /** 予備_Ｎ_19 */
    public final static int STAIRS_RESERVE_N_19 = 59;
    /** 予備_Ｎ_20 */
    public final static int STAIRS_RESERVE_N_20 = 60;
    /** 予備_Ｎ_21 */
    public final static int STAIRS_RESERVE_N_21 = 61;
    /** 予備_Ｎ_22 */
    public final static int STAIRS_RESERVE_N_22 = 62;
    /** 予備_Ｎ_23 */
    public final static int STAIRS_RESERVE_N_23 = 63;
    /** 予備_Ｎ_24 */
    public final static int STAIRS_RESERVE_N_24 = 64;
    /** 予備_Ｎ_25 */
    public final static int STAIRS_RESERVE_N_25 = 65;
    /** 予備_Ｎ_26 */
    public final static int STAIRS_RESERVE_N_26 = 66;
    /** 予備_Ｎ_27 */
    public final static int STAIRS_RESERVE_N_27 = 67;
    /** 予備_Ｎ_28 */
    public final static int STAIRS_RESERVE_N_28 = 68;
    /** 予備_Ｎ_29 */
    public final static int STAIRS_RESERVE_N_29 = 69;
    /** 予備_Ｎ_30 */
    public final static int STAIRS_RESERVE_N_30 = 70;
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    /** 該当レコードのROWインデックス */
    // public final static int STAIRS_ROW_INDEX = 11;
    public final static int STAIRS_ROW_INDEX = 71;
    /** フィールド数 */
    // public final static int STAIRS_RECORD_COUNT = 12;
    public final static int STAIRS_RECORD_COUNT = 72;
    // pzk add 20051206 e
    /** テーブルSTAIRSのキー(INTタイプ) */
    public final static int[] N_STAIRS_ID = {STAIRS_REC_NO, STAIRS_BUKKEN_NO,
        STAIRS_STAIR};
    /** テーブルSTAIRSのキー(STRINGタイプ) */
    public final static String[] STR_STAIRS_ID = {"REC_NO", "BUKKEN_NO",
        "STAIR"};
    /** テーブルSTAIRSのSQLルート */
    public final static String STAIRS_SQLROOT = "/" + STAIRS_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String ESTAIRS_ROOT = "ESTAIRS";
    /** 案件番号 */
    public final static int ESTAIRS_ESTMAT_NO = 0;
    /** 物件番号 */
    public final static int ESTAIRS_BUKKEN_NO = 1;
    /** 段数 */
    public final static int ESTAIRS_STAIR = 2;
    /** 物件番号(from) */
    public final static int ESTAIRS_BUKKEN_FR = 3;
    /** 物件番号(to) */
    public final static int ESTAIRS_BUKKEN_TO = 4;
    /** 回収金額 */
    public final static int ESTAIRS_INCOME = 5;
    /** 回収サイク */
    public final static int ESTAIRS_CYCLE = 6;
    /** 回数 */
    public final static int ESTAIRS_FREQUE = 7;
    /** 回収年 */
    public final static int ESTAIRS_DATE_YY = 8;
    /** 回収月 */
    public final static int ESTAIRS_DATE_MM = 9;
    /** 回収日 */
    public final static int ESTAIRS_DATE_DD = 10;
    // pzk add 20051206 s
    /** 予備_Ｃ_01 */
    public final static int ESTAIRS_RESERVE_C_01 = 11;
    /** 予備_Ｃ_02 */
    public final static int ESTAIRS_RESERVE_C_02 = 12;
    /** 予備_Ｃ_03 */
    public final static int ESTAIRS_RESERVE_C_03 = 13;
    /** 予備_Ｃ_04 */
    public final static int ESTAIRS_RESERVE_C_04 = 14;
    /** 予備_Ｃ_05 */
    public final static int ESTAIRS_RESERVE_C_05 = 15;
    /** 予備_Ｃ_06 */
    public final static int ESTAIRS_RESERVE_C_06 = 16;
    /** 予備_Ｃ_07 */
    public final static int ESTAIRS_RESERVE_C_07 = 17;
    /** 予備_Ｃ_08 */
    public final static int ESTAIRS_RESERVE_C_08 = 18;
    /** 予備_Ｃ_09 */
    public final static int ESTAIRS_RESERVE_C_09 = 19;
    /** 予備_Ｃ_10 */
    public final static int ESTAIRS_RESERVE_C_10 = 20;
    /** 予備_Ｃ_11 */
    public final static int ESTAIRS_RESERVE_C_11 = 21;
    /** 予備_Ｃ_12 */
    public final static int ESTAIRS_RESERVE_C_12 = 22;
    /** 予備_Ｃ_13 */
    public final static int ESTAIRS_RESERVE_C_13 = 23;
    /** 予備_Ｃ_14 */
    public final static int ESTAIRS_RESERVE_C_14 = 24;
    /** 予備_Ｃ_15 */
    public final static int ESTAIRS_RESERVE_C_15 = 25;
    /** 予備_Ｃ_16 */
    public final static int ESTAIRS_RESERVE_C_16 = 26;
    /** 予備_Ｃ_17 */
    public final static int ESTAIRS_RESERVE_C_17 = 27;
    /** 予備_Ｃ_18 */
    public final static int ESTAIRS_RESERVE_C_18 = 28;
    /** 予備_Ｃ_19 */
    public final static int ESTAIRS_RESERVE_C_19 = 29;
    /** 予備_Ｃ_20 */
    public final static int ESTAIRS_RESERVE_C_20 = 30;
    /** 予備_Ｃ_21 */
    public final static int ESTAIRS_RESERVE_C_21 = 31;
    /** 予備_Ｃ_22 */
    public final static int ESTAIRS_RESERVE_C_22 = 32;
    /** 予備_Ｃ_23 */
    public final static int ESTAIRS_RESERVE_C_23 = 33;
    /** 予備_Ｃ_24 */
    public final static int ESTAIRS_RESERVE_C_24 = 34;
    /** 予備_Ｃ_25 */
    public final static int ESTAIRS_RESERVE_C_25 = 35;
    /** 予備_Ｃ_26 */
    public final static int ESTAIRS_RESERVE_C_26 = 36;
    /** 予備_Ｃ_27 */
    public final static int ESTAIRS_RESERVE_C_27 = 37;
    /** 予備_Ｃ_28 */
    public final static int ESTAIRS_RESERVE_C_28 = 38;
    /** 予備_Ｃ_29 */
    public final static int ESTAIRS_RESERVE_C_29 = 39;
    /** 予備_Ｃ_30 */
    public final static int ESTAIRS_RESERVE_C_30 = 40;
    /** 予備_Ｎ_01 */
    public final static int ESTAIRS_RESERVE_N_01 = 41;
    /** 予備_Ｎ_02 */
    public final static int ESTAIRS_RESERVE_N_02 = 42;
    /** 予備_Ｎ_03 */
    public final static int ESTAIRS_RESERVE_N_03 = 43;
    /** 予備_Ｎ_04 */
    public final static int ESTAIRS_RESERVE_N_04 = 44;
    /** 予備_Ｎ_05 */
    public final static int ESTAIRS_RESERVE_N_05 = 45;
    /** 予備_Ｎ_06 */
    public final static int ESTAIRS_RESERVE_N_06 = 46;
    /** 予備_Ｎ_07 */
    public final static int ESTAIRS_RESERVE_N_07 = 47;
    /** 予備_Ｎ_08 */
    public final static int ESTAIRS_RESERVE_N_08 = 48;
    /** 予備_Ｎ_09 */
    public final static int ESTAIRS_RESERVE_N_09 = 49;
    /** 予備_Ｎ_10 */
    public final static int ESTAIRS_RESERVE_N_10 = 50;
    /** 予備_Ｎ_11 */
    public final static int ESTAIRS_RESERVE_N_11 = 51;
    /** 予備_Ｎ_12 */
    public final static int ESTAIRS_RESERVE_N_12 = 52;
    /** 予備_Ｎ_13 */
    public final static int ESTAIRS_RESERVE_N_13 = 53;
    /** 予備_Ｎ_14 */
    public final static int ESTAIRS_RESERVE_N_14 = 54;
    /** 予備_Ｎ_15 */
    public final static int ESTAIRS_RESERVE_N_15 = 55;
    /** 予備_Ｎ_16 */
    public final static int ESTAIRS_RESERVE_N_16 = 56;
    /** 予備_Ｎ_17 */
    public final static int ESTAIRS_RESERVE_N_17 = 57;
    /** 予備_Ｎ_18 */
    public final static int ESTAIRS_RESERVE_N_18 = 58;
    /** 予備_Ｎ_19 */
    public final static int ESTAIRS_RESERVE_N_19 = 59;
    /** 予備_Ｎ_20 */
    public final static int ESTAIRS_RESERVE_N_20 = 60;
    /** 予備_Ｎ_21 */
    public final static int ESTAIRS_RESERVE_N_21 = 61;
    /** 予備_Ｎ_22 */
    public final static int ESTAIRS_RESERVE_N_22 = 62;
    /** 予備_Ｎ_23 */
    public final static int ESTAIRS_RESERVE_N_23 = 63;
    /** 予備_Ｎ_24 */
    public final static int ESTAIRS_RESERVE_N_24 = 64;
    /** 予備_Ｎ_25 */
    public final static int ESTAIRS_RESERVE_N_25 = 65;
    /** 予備_Ｎ_26 */
    public final static int ESTAIRS_RESERVE_N_26 = 66;
    /** 予備_Ｎ_27 */
    public final static int ESTAIRS_RESERVE_N_27 = 67;
    /** 予備_Ｎ_28 */
    public final static int ESTAIRS_RESERVE_N_28 = 68;
    /** 予備_Ｎ_29 */
    public final static int ESTAIRS_RESERVE_N_29 = 69;
    /** 予備_Ｎ_30 */
    public final static int ESTAIRS_RESERVE_N_30 = 70;
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    /** 該当レコードのROWインデックス */
    // public final static int ESTAIRS_ROW_INDEX = 11;
    public final static int ESTAIRS_ROW_INDEX = 71;
    /** フィールド数 */
    // public final static int ESTAIRS_RECORD_COUNT = 12;
    public final static int ESTAIRS_RECORD_COUNT = 72;
    // pzk add 20051206 e
    /** テーブルESTAIRSのSQLルート */
    public final static String ESTAIRS_SQLROOT = "/" + ESTAIRS_ROOT + "/ROW";
    /** テーブルSTAIRSのキー(INTタイプ) */
    public final static int[] N_ESTAIRS_ID = {ESTAIRS_ESTMAT_NO,
        ESTAIRS_BUKKEN_NO, ESTAIRS_STAIR};
    /** テーブルSTAIRSのキー(STRINGタイプ) */
    public final static String[] STR_ESTAIRS_ID = {"ESTMAT_NO", "BUKKEN_NO",
        "STAIR"};
    /** XMLのRoot */
    public final static String OBJECT_ROOT = "OBJECT";
    /** 案件番号 */
    public final static int OBJECT_REC_NO = 0;
    /** 物件番号 */
    public final static int OBJECT_BUKKEN_NO = 1;
    /** 物件番号(from) */
    public final static int OBJECT_BUKKEN_FR = 2;
    /** 物件番号(to) */
    public final static int OBJECT_BUKKEN_TO = 3;
    /** 検収予定日 */
    public final static int OBJECT_DATE_KENSH = 4;
    /** 購入価格 */
    public final static int OBJECT_PURCHASE = 5;
    /** 物件数量 */
    public final static int OBJECT_QUANTITY = 6;
    /** 分割支払区分 */
    public final static int OBJECT_SW_PAY = 7;
    /** 支払予定日 */
    public final static int OBJECT_DATE_PAYMT = 8;
    /** 残価 */
    public final static int OBJECT_REMAIN_VAL = 9;
    /** 残価率 */
    public final static int OBJECT_REM_VAL_RT = 10;
    /** 法定耐用年数 */
    public final static int OBJECT_DURABLE_Y = 11;
    /** リース月数・割賦期間 */
    public final static int OBJECT_LEASE_M = 12;
    /** 社内コスト率 */
    public final static int OBJECT_RATE_JLC = 13;
    /** 原調計算金利(COF) */
    public final static int OBJECT_RATE_C_ADJ = 14;
    /** 管販費率 */
    public final static int OBJECT_RATE_E_ANI = 15;
    /** 管販費率Original */
    public final static int OBJECT_RATE_E_A_O = 16;
    /** 管販費率Service */
    public final static int OBJECT_RATE_E_A_S = 17;
    /** 貸倒引当率 */
    public final static int OBJECT_RATE_LOSS = 18;
    /** CST機種コード */
    public final static int OBJECT_CSTKISHUCD = 19;
    /** CSTSEL情報 */
    public final static int OBJECT_CSTSELINFO = 20;
    /** 手数料収益率 */
    public final static int OBJECT_RATE_FEE = 21;
    /** 手数料収益率NPP */
    public final static int OBJECT_RATE_FEE_N = 22;
    /** 手数料収益率Release */
    public final static int OBJECT_RATE_FEE_R = 23;
    /** 動総保険料率 */
    public final static int OBJECT_DOSO_RATE = 24;
    /** ソフトウェア区分 */
    public final static int OBJECT_SW_SOFT = 25;
    /** 固定資産税 */
    public final static int OBJECT_FIXASTTAX = 26;
    /** 動総保険金総指数 */
    public final static int OBJECT_DOSO_INDEX = 27;
    /** 動総保険料 */
    public final static int OBJECT_DOSO_FEE = 28;
    /** 賠責保険付保区分 */
    public final static int OBJECT_SW_BAISEKI = 29;
    /** 団信保険料率 */
    public final static int OBJECT_DANSHIN_RT = 30;
    /** 機械保険料 */
    public final static int OBJECT_MACHI_FEE = 31;
    /** 火災保険料 */
    public final static int OBJECT_FIRE_FEE = 32;
    /** 船舶・その他保険料 */
    public final static int OBJECT_ETC_FEE = 33;
    /** 一時費用(イ)(公証) */
    public final static int OBJECT_ICHIJI_1 = 34;
    /** 一時費用(ロ) */
    public final static int OBJECT_ICHIJI_2 = 35;
    /** 一時費用(ハ) */
    public final static int OBJECT_ICHIJI_3 = 36;
    /** 繰延費用(ヘ)(団信) */
    public final static int OBJECT_KURINO_1 = 37;
    /** 繰延費用(ト) */
    public final static int OBJECT_KURINO_2 = 38;
    /** 保守料 */
    public final static int OBJECT_HOSHURYO = 39;
    /** 斡旋手数料 */
    public final static int OBJECT_ASSEN = 40;
    /** 割賦保険料 */
    public final static int OBJECT_KAPPU_INS = 41;
    /** 前受ﾘｰｽ料回収日 */
    public final static int OBJECT_DATE_INC_0 = 42;
    /** 前受リース料 */
    public final static int OBJECT_INCOME_0 = 43;
    /** 前受リース月数 */
    public final static int OBJECT_INC_0_M = 44;
    /** リース段数・割賦段数 */
    public final static int OBJECT_LEASE_D = 45;
    /** 均等回収区分 */
    public final static int OBJECT_EVEN_FLG = 46;
    /** 合計料率 */
    public final static int OBJECT_RYORITSU_T = 47;
    /** 月料率 */
    public final static int OBJECT_RYORITSU_M = 48;
    /** 運用利回り */
    public final static int OBJECT_RATE_UNYO = 49;
    /** ＴＲ */
    public final static int OBJECT_TRUE_RATE = 50;
    /** ＲＯＩ */
    public final static int OBJECT_RATE_ROI = 51;
    /** 支払利息(社内コスト額) */
    public final static int OBJECT_INTEREST_P = 52;
    /** 回収利息 */
    public final static int OBJECT_INTEREST_I = 53;
    /** その他雑費 */
    public final static int OBJECT_ZAPI = 54;
    /** 保険料 */
    public final static int OBJECT_INSURANCE = 55;
    /** リース原価 */
    public final static int OBJECT_COST_TOTAL = 56;
    /** 当社手数料 */
    public final static int OBJECT_CHARGE = 57;
    /** 契約額 */
    public final static int OBJECT_INCOME_GT = 58;
    /** 原価調整額 */
    public final static int OBJECT_C_ADJUST = 59;
    /** 荒利益額 */
    public final static int OBJECT_PROFIT_T = 60;
    /** 年荒利益額 */
    public final static int OBJECT_PROFIT_Y = 61;
    /** 使用総資産 */
    public final static int OBJECT_CAPITAL_T = 62;
    /** 総荒利率 */
    public final static int OBJECT_RAT_PRO_T = 63;
    /** 年荒利率 */
    public final static int OBJECT_RAT_PRO_Y = 64;
    /** 年利廻り */
    public final static int OBJECT_RATE_YEAR = 65;
    /** 原価調整月数 */
    public final static int OBJECT_ADJUST_M = 66;
    /** 原価調整日数 */
    public final static int OBJECT_ADJUST_D = 67;
    /** ﾘｰｽ料総額(保険料抜き) */
    public final static int OBJECT_INCOME_T = 68;
    /** 初期費用 */
    public final static int OBJECT_INIT_COST = 69;
    /** 実行費用総額 */
    public final static int OBJECT_EXEC_COST = 70;
    /** ＮＥＴ率 */
    public final static int OBJECT_NET_RATE = 71;
    /** Finance Margin率 */
    public final static int OBJECT_FINANCE_MARGIN = 72;
    /** RA Margin率 */
    public final static int OBJECT_RA_MARGIN = 73;
    /** PV Finance Margin額 */
    public final static int OBJECT_PV_FINANCE_MARGIN = 74;
    /** RA PV Margin額 */
    public final static int OBJECT_RA_PV_MARGIN = 75;
    /** 据置月数 */
    public final static int OBJECT_LEAVE_M = 76;
    /** 賠責保険料 */
    public final static int OBJECT_BAIS_FEE = 77;
    /** 規定損害金基本額 */
    public final static int OBJECT_DAMAGE_BAS = 78;
    /** 規定損害金前半逓減月数 */
    public final static int OBJECT_DAMAGE_FM = 79;
    /** 規定損害金後半逓減月数 */
    public final static int OBJECT_DAMAGE_LM = 80;
    /** 規定損害金前半逓減月額 */
    public final static int OBJECT_DAMAGE_FA = 81;
    /** 規定損害金後半逓減月額 */
    public final static int OBJECT_DAMAGE_LA = 82;
    /** ﾌﾙﾍﾟｲ支払利息 */
    public final static int OBJECT_F_INTER_P = 83;
    /** ﾌﾙﾍﾟｲ回収利息 */
    public final static int OBJECT_F_INTER_I = 84;
    /** ﾌﾙﾍﾟｲ当社手数料 */
    public final static int OBJECT_F_CHARGE = 85;
    /** ﾌﾙﾍﾟｲ実行費用総額 */
    public final static int OBJECT_F_EXEC_C = 86;
    /** ﾌﾙﾍﾟｲ繰延費用(ヘ) */
    public final static int OBJECT_F_KURI_1 = 87;
    /** ﾌﾙﾍﾟｲ保険料 */
    public final static int OBJECT_F_INSUR = 88;
    /** ﾌﾙﾍﾟｲﾘｰｽ原価計 */
    public final static int OBJECT_F_COST_T = 89;
    /** ﾌﾙﾍﾟｲ荒利益額 */
    public final static int OBJECT_F_PRO_T = 90;
    /** ﾌﾙﾍﾟｲ年荒利益額 */
    public final static int OBJECT_F_PRO_Y = 91;
    /** ﾌﾙﾍﾟｲ使用総資産 */
    public final static int OBJECT_F_CAPIT_T = 92;
    /** ﾌﾙﾍﾟｲＴＲ */
    public final static int OBJECT_F_TRUE_RT = 93;
    /** ﾌﾙﾍﾟｲ年利廻り */
    public final static int OBJECT_F_RT_YR = 94;
    /** ﾌﾙﾍﾟｲ運用利回り */
    public final static int OBJECT_F_RT_UN = 95;
    /** ﾌﾙﾍﾟｲ総荒利率 */
    public final static int OBJECT_F_RT_PRT = 96;
    /** ﾌﾙﾍﾟｲ年荒利率 */
    public final static int OBJECT_F_RT_PRY = 97;
    /** ﾌﾙﾍﾟｲROI */
    public final static int OBJECT_F_RT_ROI = 98;
    /** ﾌﾙﾍﾟｲFinanceMargin率 */
    public final static int OBJECT_F_FINANCE_MARGIN = 99;
    /** ﾌﾙﾍﾟｲRAMargin率 */
    public final static int OBJECT_F_RA_MARGIN = 100;
    /** ﾌﾙﾍﾟｲPVFinanceMargin額 */
    public final static int OBJECT_F_PV_FINANCE_MARGIN = 101;
    /** ﾌﾙﾍﾟｲRAPVMargin額 */
    public final static int OBJECT_F_RA_PV_MARGIN = 102;
    /** 機械類ﾘｰｽ信用保険 */
    public final static int OBJECT_CREDIT_INS = 103;
    /** ﾘｰｽ信保付保区分 */
    public final static int OBJECT_SW_CRE_INS = 104;
    /** 信保機種CD */
    public final static int OBJECT_CRE_INS_CD = 105;
    /** ﾘｰｽ信保付保期間 */
    public final static int OBJECT_CRE_INS_TM = 106;
    /** ﾘｰｽ信保保険料率 */
    public final static int OBJECT_CRE_INS_RT = 107;
    /** 少額資産区分 */
    public final static int OBJECT_SW_S_PRO = 108;
    /** 予備 */
    public final static int OBJECT_RESERVE1 = 109;
    /** Product */
    public final static int OBJECT_PRODUCT = 110;
    /** Leverage */
    public final static int OBJECT_LEVERAGE = 111;
    public final static int OBJECT_LEVERAGERATE = 27;
    /** ROE */
    public final static int OBJECT_ROE = 112;
    /** FP_ROE */
    public final static int OBJECT_FP_ROE = 113;
    /** Product_CD */
    public final static int OBJECT_PRODUCT_CD = 114;
    // zyb add 20060228 s
    // pzk add 20051206 s
    /** 購入選択権の有無 */
    public final static int OBJECT_RESERVE_C_01 = 115;
    // zyb add 20060228 e
    //20061010 zyb modi s
    //** 予備_Ｃ_02 */
    //public final static int OBJECT_RESERVE_C_02 = 116;
    //GE格付
    public final static int OBJECT_RESERVE_C_02 = 116;
    //20061010 zyb modi e
    //ydy modify 20071211 s
//	/** 予備_Ｃ_03 */
//	public final static int OBJECT_RESERVE_C_03 = 117;
    //Assumption
    public final static int OBJECT_RESERVE_C_03 = 117;
    //ydy modify 20071211 e
    //ydy modify 20080225 s
//	/** 予備_Ｃ_04 */
//	public final static int OBJECT_RESERVE_C_04 = 118;
    /** 機種小分類コード */
    public final static int OBJECT_RESERVE_C_04 = 118;
    //ydy modify 20080225 e
    //ydy add 20080519 s
//	/** 予備_Ｃ_05 */
//	public final static int OBJECT_RESERVE_C_05 = 119;
    /** 適用期間１ */
    public final static int OBJECT_RESERVE_C_05 = 119;
//	/** 予備_Ｃ_06 */
//	public final static int OBJECT_RESERVE_C_06 = 120;
    /** 適用期間２ */
    public final static int OBJECT_RESERVE_C_06 = 120;
    //ydy add 20080519 e
    /** 予備_Ｃ_07 */
    public final static int OBJECT_RESERVE_C_07 = 121;
    /** 予備_Ｃ_08 */
    public final static int OBJECT_RESERVE_C_08 = 122;
    /** 予備_Ｃ_09 */
    public final static int OBJECT_RESERVE_C_09 = 123;
    /** 予備_Ｃ_10 */
    public final static int OBJECT_RESERVE_C_10 = 124;
    /** 予備_Ｃ_11 */
    public final static int OBJECT_RESERVE_C_11 = 125;
    /** 予備_Ｃ_12 */
    public final static int OBJECT_RESERVE_C_12 = 126;
    /** 予備_Ｃ_13 */
    public final static int OBJECT_RESERVE_C_13 = 127;
    /** 予備_Ｃ_14 */
    public final static int OBJECT_RESERVE_C_14 = 128;
    /** 予備_Ｃ_15 */
    public final static int OBJECT_RESERVE_C_15 = 129;
    /** 予備_Ｃ_16 */
    public final static int OBJECT_RESERVE_C_16 = 130;
    /** 予備_Ｃ_17 */
    public final static int OBJECT_RESERVE_C_17 = 131;
    /** 予備_Ｃ_18 */
    public final static int OBJECT_RESERVE_C_18 = 132;
    /** 予備_Ｃ_19 */
    public final static int OBJECT_RESERVE_C_19 = 133;
    /** 予備_Ｃ_20 */
    public final static int OBJECT_RESERVE_C_20 = 134;
    /** 予備_Ｃ_21 */
    public final static int OBJECT_RESERVE_C_21 = 135;
    /** 予備_Ｃ_22 */
    public final static int OBJECT_RESERVE_C_22 = 136;
    /** 予備_Ｃ_23 */
    public final static int OBJECT_RESERVE_C_23 = 137;
    /** 予備_Ｃ_24 */
    public final static int OBJECT_RESERVE_C_24 = 138;
    /** 予備_Ｃ_25 */
    public final static int OBJECT_RESERVE_C_25 = 139;
    /** 予備_Ｃ_26 */
    public final static int OBJECT_RESERVE_C_26 = 140;
    /** 予備_Ｃ_27 */
    public final static int OBJECT_RESERVE_C_27 = 141;
    /** 予備_Ｃ_28 */
    public final static int OBJECT_RESERVE_C_28 = 142;
    /** 予備_Ｃ_29 */
    public final static int OBJECT_RESERVE_C_29 = 143;
    /** 予備_Ｃ_30 */
    public final static int OBJECT_RESERVE_C_30 = 144;
    // zyb add 20060228 s
    /** 購入選択行使権額 */
    public final static int OBJECT_RESERVE_N_01 = 145;
    // zyb add 20060228 e
    //20070410 zyb modi s
    /** 予備_Ｎ_02 */
    //public final static int OBJECT_RESERVE_N_02 = 146;
    /** ROIの税率 */
    public final static int OBJECT_RESERVE_N_02 = 146;
    //20070410 zyb modi e
    /** 予備_Ｎ_03 */
    public final static int OBJECT_RESERVE_N_03 = 147;
    /** 予備_Ｎ_04 */
    public final static int OBJECT_RESERVE_N_04 = 148;
    /** 予備_Ｎ_05 */
    public final static int OBJECT_RESERVE_N_05 = 149;
    /** 予備_Ｎ_06 */
    public final static int OBJECT_RESERVE_N_06 = 150;
    /** 予備_Ｎ_07 */
    public final static int OBJECT_RESERVE_N_07 = 151;
    /** 予備_Ｎ_08 */
    public final static int OBJECT_RESERVE_N_08 = 152;
    /** 予備_Ｎ_09 */
    public final static int OBJECT_RESERVE_N_09 = 153;
    /** 予備_Ｎ_10 */
    public final static int OBJECT_RESERVE_N_10 = 154;
    /** 予備_Ｎ_11 */
    public final static int OBJECT_RESERVE_N_11 = 155;
    /** 予備_Ｎ_12 */
    public final static int OBJECT_RESERVE_N_12 = 156;
    /** 予備_Ｎ_13 */
    public final static int OBJECT_RESERVE_N_13 = 157;
    /** 予備_Ｎ_14 */
    public final static int OBJECT_RESERVE_N_14 = 158;
    /** 予備_Ｎ_15 */
    public final static int OBJECT_RESERVE_N_15 = 159;
    /** 予備_Ｎ_16 */
    public final static int OBJECT_RESERVE_N_16 = 160;
    /** 予備_Ｎ_17 */
    public final static int OBJECT_RESERVE_N_17 = 161;
    /** 予備_Ｎ_18 */
    public final static int OBJECT_RESERVE_N_18 = 162;
    /** 予備_Ｎ_19 */
    public final static int OBJECT_RESERVE_N_19 = 163;
    /** 予備_Ｎ_20 */
    public final static int OBJECT_RESERVE_N_20 = 164;
    /** 予備_Ｎ_21 */
    public final static int OBJECT_RESERVE_N_21 = 165;
    /** 予備_Ｎ_22 */
    public final static int OBJECT_RESERVE_N_22 = 166;
    /** 予備_Ｎ_23 */
    public final static int OBJECT_RESERVE_N_23 = 167;
    /** 予備_Ｎ_24 */
    public final static int OBJECT_RESERVE_N_24 = 168;
    /** 予備_Ｎ_25 */
    public final static int OBJECT_RESERVE_N_25 = 169;
    /** 予備_Ｎ_26 */
    public final static int OBJECT_RESERVE_N_26 = 170;
    /** 予備_Ｎ_27 */
    public final static int OBJECT_RESERVE_N_27 = 171;
    /** 予備_Ｎ_28 */
    public final static int OBJECT_RESERVE_N_28 = 172;
    /** 予備_Ｎ_29 */
    public final static int OBJECT_RESERVE_N_29 = 173;
    /** 予備_Ｎ_30 */
    public final static int OBJECT_RESERVE_N_30 = 174;
    /** 該当レコードのROWインデックスフィルだを追加すれば、この番号はフィルだ最大番号より大きいです */
    /** 該当レコードのROWインデックス */
    // public final static int OBJECT_ROW_INDEX = 115;
    public final static int OBJECT_ROW_INDEX = 175;
    /** フィールド数 */
    // public final static int OBJECT_RECORD_COUNT = 116;
    public final static int OBJECT_RECORD_COUNT = 176;
    // pzk add 20051206 e
    /** テーブルOBJECTのキー(INTタイプ) */
    public final static int[] N_OBJECT_ID = {OBJECT_REC_NO, OBJECT_BUKKEN_NO};
    /** テーブルOBJECTのキー(STRINGタイプ) */
    public final static String[] STR_OBJECT_ID = {"REC_NO", "BUKKEN_NO"};
    /** テーブルOBJECTのSQLルート */
    public final static String OBJECT_SQLROOT = "/" + OBJECT_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String TMPREC_ROOT = "TMPREC";
    /** 案件番号 */
    public final static int TMPREC_REC_NO = 0;
    /** フィールド数 */
    public final static int TMPREC_RECORD_COUNT = 1;
    /** テーブルTMPRECのキー(INTタイプ) */
    public final static int[] N_TMPREC_ID = {TMPREC_REC_NO};
    /** テーブルTMPRECのキー(STRINGタイプ) */
    public final static String[] STR_TMPREC_ID = {"REC_NO"};
    /** テーブルTMPRECのSQLルート */
    public final static String TMPREC_SQLROOT = "/" + TMPREC_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String EPERSON_ROOT = "EPERSON";
    /** 部店コード */
    public final static int EPERSON_BRANCH_CD = 0;
    /** 部店名 */
    public final static int EPERSON_BRANCH_NM = 1;
    /** 郵政番号 */
    public final static int EPERSON_ZIPCODE = 2;
    /** 住所(上段) */
    public final static int EPERSON_ADDRESS1 = 3;
    /** 住所(下段) */
    public final static int EPERSON_ADDRESS2 = 4;
    /** 電話番号 */
    public final static int EPERSON_TELNO = 5;
    /** Fax */
    public final static int EPERSON_FAXNO = 6;
    /** 社員コード */
    public final static int EPERSON_PERSON_CD = 7;
    /** 担当者名 */
    public final static int EPERSON_PERSON_NM = 8;
    /** 更新日 */
    public final static int EPERSON_UPDATE_DATE = 9;
    /** 更新時刻 */
    public final static int EPERSON_UPDATE_TIME = 10;
    /** Product */
    public final static int EPERSON_SYOYUGROUP = 11;
    /** Product_cd */
    public final static int EPERSON_FUNCTION_CD = 12;
    // pzk add 20051206 s
    /** 予備_Ｃ_01 */
    public final static int EPERSON_RESERVE_C_01 = 13;
    /** 予備_Ｃ_02 */
    public final static int EPERSON_RESERVE_C_02 = 14;
    /** 予備_Ｃ_03 */
    public final static int EPERSON_RESERVE_C_03 = 15;
    /** 予備_Ｃ_04 */
    public final static int EPERSON_RESERVE_C_04 = 16;
    /** 予備_Ｃ_05 */
    public final static int EPERSON_RESERVE_C_05 = 17;
    /** 予備_Ｃ_06 */
    public final static int EPERSON_RESERVE_C_06 = 18;
    /** 予備_Ｃ_07 */
    public final static int EPERSON_RESERVE_C_07 = 19;
    /** 予備_Ｃ_08 */
    public final static int EPERSON_RESERVE_C_08 = 20;
    /** 予備_Ｃ_09 */
    public final static int EPERSON_RESERVE_C_09 = 21;
    /** 予備_Ｃ_10 */
    public final static int EPERSON_RESERVE_C_10 = 22;
    /** 予備_Ｃ_11 */
    public final static int EPERSON_RESERVE_C_11 = 23;
    /** 予備_Ｃ_12 */
    public final static int EPERSON_RESERVE_C_12 = 24;
    /** 予備_Ｃ_13 */
    public final static int EPERSON_RESERVE_C_13 = 25;
    /** 予備_Ｃ_14 */
    public final static int EPERSON_RESERVE_C_14 = 26;
    /** 予備_Ｃ_15 */
    public final static int EPERSON_RESERVE_C_15 = 27;
    /** 予備_Ｃ_16 */
    public final static int EPERSON_RESERVE_C_16 = 28;
    /** 予備_Ｃ_17 */
    public final static int EPERSON_RESERVE_C_17 = 29;
    /** 予備_Ｃ_18 */
    public final static int EPERSON_RESERVE_C_18 = 30;
    /** 予備_Ｃ_19 */
    public final static int EPERSON_RESERVE_C_19 = 31;
    /** 予備_Ｃ_20 */
    public final static int EPERSON_RESERVE_C_20 = 32;
    /** 予備_Ｃ_21 */
    public final static int EPERSON_RESERVE_C_21 = 33;
    /** 予備_Ｃ_22 */
    public final static int EPERSON_RESERVE_C_22 = 34;
    /** 予備_Ｃ_23 */
    public final static int EPERSON_RESERVE_C_23 = 35;
    /** 予備_Ｃ_24 */
    public final static int EPERSON_RESERVE_C_24 = 36;
    /** 予備_Ｃ_25 */
    public final static int EPERSON_RESERVE_C_25 = 37;
    /** 予備_Ｃ_26 */
    public final static int EPERSON_RESERVE_C_26 = 38;
    /** 予備_Ｃ_27 */
    public final static int EPERSON_RESERVE_C_27 = 39;
    /** 予備_Ｃ_28 */
    public final static int EPERSON_RESERVE_C_28 = 40;
    /** 予備_Ｃ_29 */
    public final static int EPERSON_RESERVE_C_29 = 41;
    /** 予備_Ｃ_30 */
    public final static int EPERSON_RESERVE_C_30 = 42;
    /** 予備_Ｎ_01 */
    public final static int EPERSON_RESERVE_N_01 = 43;
    /** 予備_Ｎ_02 */
    public final static int EPERSON_RESERVE_N_02 = 44;
    /** 予備_Ｎ_03 */
    public final static int EPERSON_RESERVE_N_03 = 45;
    /** 予備_Ｎ_04 */
    public final static int EPERSON_RESERVE_N_04 = 46;
    /** 予備_Ｎ_05 */
    public final static int EPERSON_RESERVE_N_05 = 47;
    /** 予備_Ｎ_06 */
    public final static int EPERSON_RESERVE_N_06 = 48;
    /** 予備_Ｎ_07 */
    public final static int EPERSON_RESERVE_N_07 = 49;
    /** 予備_Ｎ_08 */
    public final static int EPERSON_RESERVE_N_08 = 50;
    /** 予備_Ｎ_09 */
    public final static int EPERSON_RESERVE_N_09 = 51;
    /** 予備_Ｎ_10 */
    public final static int EPERSON_RESERVE_N_10 = 52;
    /** 予備_Ｎ_11 */
    public final static int EPERSON_RESERVE_N_11 = 53;
    /** 予備_Ｎ_12 */
    public final static int EPERSON_RESERVE_N_12 = 54;
    /** 予備_Ｎ_13 */
    public final static int EPERSON_RESERVE_N_13 = 55;
    /** 予備_Ｎ_14 */
    public final static int EPERSON_RESERVE_N_14 = 56;
    /** 予備_Ｎ_15 */
    public final static int EPERSON_RESERVE_N_15 = 57;
    /** 予備_Ｎ_16 */
    public final static int EPERSON_RESERVE_N_16 = 58;
    /** 予備_Ｎ_17 */
    public final static int EPERSON_RESERVE_N_17 = 59;
    /** 予備_Ｎ_18 */
    public final static int EPERSON_RESERVE_N_18 = 60;
    /** 予備_Ｎ_19 */
    public final static int EPERSON_RESERVE_N_19 = 61;
    /** 予備_Ｎ_20 */
    public final static int EPERSON_RESERVE_N_20 = 62;
    /** 予備_Ｎ_21 */
    public final static int EPERSON_RESERVE_N_21 = 63;
    /** 予備_Ｎ_22 */
    public final static int EPERSON_RESERVE_N_22 = 64;
    /** 予備_Ｎ_23 */
    public final static int EPERSON_RESERVE_N_23 = 65;
    /** 予備_Ｎ_24 */
    public final static int EPERSON_RESERVE_N_24 = 66;
    /** 予備_Ｎ_25 */
    public final static int EPERSON_RESERVE_N_25 = 67;
    /** 予備_Ｎ_26 */
    public final static int EPERSON_RESERVE_N_26 = 68;
    /** 予備_Ｎ_27 */
    public final static int EPERSON_RESERVE_N_27 = 69;
    /** 予備_Ｎ_28 */
    public final static int EPERSON_RESERVE_N_28 = 70;
    /** 予備_Ｎ_29 */
    public final static int EPERSON_RESERVE_N_29 = 71;
    /** 予備_Ｎ_30 */
    public final static int EPERSON_RESERVE_N_30 = 72;
    /** フィールド数 */
    // public final static int EPERSON_RECORD_COUNT = 13;
    public final static int EPERSON_RECORD_COUNT = 73;
    // pzk add 20051206 e
    /** テーブルEPERSONのキー(INTタイプ) */
    public final static int[] N_EPERSON_ID = {EPERSON_BRANCH_CD};
    /** テーブルEPERSONのキー(STRINGタイプ) */
    public final static String[] STR_EPERSON_ID = {"BRANCH_CD"};
    /** テーブルEPERSONのSQLルート */
    public final static String EPERSON_SQLROOT = "/" + EPERSON_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String TMPXML_ROOT = "TMPXML";
    /** 案件番号 */
    public final static int TMPXML_REC_NO = 0;
    /** 購入価格 */
    public final static int TMPXML_PURCHASE = 1;
    /** 残価 */
    public final static int TMPXML_REMAIN_VAL = 2;
    /** 支払利息 */
    public final static int TMPXML_INTEREST_P = 3;
    /** 固定資産税 */
    public final static int TMPXML_FIXASTTAX = 4;
    /** 保険料 */
    public final static int TMPXML_INSURANCE = 5;
    /** その他雑費 */
    public final static int TMPXML_ZAPI = 6;
    /** 一時費用(イ) */
    public final static int TMPXML_ICHIJI_1 = 7;
    /** 一時費用(ロ) */
    public final static int TMPXML_ICHIJI_2 = 8;
    /** 一時費用(ハ) */
    public final static int TMPXML_ICHIJI_3 = 9;
    /** 繰延費用(ヘ) */
    public final static int TMPXML_KURINO_1 = 10;
    /** 繰延費用(ト) */
    public final static int TMPXML_KURINO_2 = 11;
    /** 保守料 */
    public final static int TMPXML_HOSHURYO = 12;
    /** 斡旋手数料 */
    public final static int TMPXML_ASSEN = 13;
    /** リース原価 */
    public final static int TMPXML_COST_TOTAL = 14;
    /** 当社手数料 */
    public final static int TMPXML_CHARGE = 15;
    /** 契約額 */
    public final static int TMPXML_INCOME_GT = 16;
    /** 前受リース料 */
    public final static int TMPXML_INCOME_0 = 17;
    /** 前受リース月数 */
    public final static int TMPXML_INC_0_M = 18;
    /** 原価調整額 */
    public final static int TMPXML_C_ADJUST = 19;
    /** 荒利益額 */
    public final static int TMPXML_PROFIT_T = 20;
    /** 使用総資産 */
    public final static int TMPXML_CAPITAL_T = 21;
    /** 総荒利率 */
    public final static int TMPXML_RAT_PRO_T = 22;
    /** 社内金利 */
    public final static int TMPXML_RATE_JLC = 23;
    /** 運用利回り */
    public final static int TMPXML_RATE_UNYO = 24;
    /** ＴＲ */
    public final static int TMPXML_TRUE_RATE = 25;
    /** ＲＯＩ */
    public final static int TMPXML_RATE_ROI = 26;
    /** 管販費率Original */
    public final static int TMPXML_RATE_E_A_O = 27;
    /** 管販費率Service */
    public final static int TMPXML_RATE_E_A_S = 28;
    /** 貸倒引当率 */
    public final static int TMPXML_RATE_LOSS = 29;
    /** 手数料収益率NPP */
    public final static int TMPXML_RATE_FEE_N = 30;
    /** 手数料収益率Release */
    public final static int TMPXML_RATE_FEE_R = 31;
    /** 原価調整月数 */
    public final static int TMPXML_ADJUST_M = 32;
    /** 原価調整日数 */
    public final static int TMPXML_ADJUST_D = 33;
    /** 動総保険料率 */
    public final static int TMPXML_DOSO_RATE = 34;
    /** 団信保険料率 */
    public final static int TMPXML_DANSHIN_RT = 35;
    /** リース月数 */
    public final static int TMPXML_LEASE_M = 36;
    /** 据置月数 */
    public final static int TMPXML_LEAVE_M = 37;
    /** 法定耐用年数 */
    public final static int TMPXML_DURABLE_Y = 38;
    /** ﾌﾙﾍﾟｲ支払利息 */
    public final static int TMPXML_F_INTER_P = 39;
    /** ﾌﾙﾍﾟｲ当社手数料 */
    public final static int TMPXML_F_CHARGE = 40;
    /** ﾌﾙﾍﾟｲ実行費用総額 */
    public final static int TMPXML_F_EXEC_C = 41;
    /** 77.ﾌﾙﾍﾟｲ繰延費用(ヘ) */
    public final static int TMPXML_F_KURI_1 = 42;
    /** ﾌﾙﾍﾟｲ保険料 */
    public final static int TMPXML_F_INSUR = 43;
    /** ﾌﾙﾍﾟｲﾘｰｽ原価計 */
    public final static int TMPXML_F_COST_T = 44;
    /** ﾌﾙﾍﾟｲ荒利益額 */
    public final static int TMPXML_F_PRO_T = 45;
    /** ﾌﾙﾍﾟｲ使用総資産 */
    public final static int TMPXML_F_CAPIT_T = 46;
    /** ﾌﾙﾍﾟｲＴＲ */
    public final static int TMPXML_F_TRUE_RT = 47;
    /** ﾌﾙﾍﾟｲ年利廻り */
    public final static int TMPXML_F_RT_YR = 48;
    /** ﾌﾙﾍﾟｲ運用利回り */
    public final static int TMPXML_F_RT_UN = 49;
    /** ﾌﾙﾍﾟｲ総荒利率 */
    public final static int TMPXML_F_RT_PRT = 50;
    /** ﾌﾟﾙﾍﾟｲROI */
    public final static int TMPXML_F_RT_ROI = 51;
    /** 原調計算金利 */
    public final static int TMPXML_RATE_C_ADJ = 52;
    /** Finance Margin率 */
    public final static int TMPXML_FINANCE_MARGIN = 53;
    /** RA Margin率 */
    public final static int TMPXML_RA_MARGIN = 54;
    /** PV Finance Margin額 */
    public final static int TMPXML_PV_FINANCE_MARGIN = 55;
    /** RA PV Margin額 */
    public final static int TMPXML_RA_PV_MARGIN = 56;
    /** ﾌﾙﾍﾟｲFinance Margin率 */
    public final static int TMPXML_F_FINANCE_MARGIN = 57;
    /** ﾌﾙﾍﾟｲRA Margin率 */
    public final static int TMPXML_F_RA_MARGIN = 58;
    /** ﾌﾙﾍﾟｲPV Finance Margin額 */
    public final static int TMPXML_F_PV_FINANCE_MARGIN = 59;
    /** ﾌﾟﾙﾍﾟRA PV Margin額 */
    public final static int TMPXML_F_RA_PV_MARGIN = 60;
    /** フィールド数 */
    public final static int TMPXML_RECORD_COUNT = 61;
    /** テーブルTMPXMLのキー(INTタイプ) */
    public final static int[] N_TMPXML_ID = {TMPXML_REC_NO};
    /** テーブルTMPXMLのキー(STRINGタイプ) */
    public final static String[] STR_TMPXML_ID = {"REC_NO"};
    /** テーブルTMPXMLのSQLルート */
    public final static String TMPXML_SQLROOT = "/" + TMPXML_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String TMPOBJ_ROOT = "TMPOBJ";
    /** 案件番号 */
    public final static int TMPOBJ_REC_NO = 0;
    /** 物件番号 */
    public final static int TMPOBJ_BUKKEN_NO = 1;
    /** 合計 */
    public final static int TMPOBJ_STAIR_TOTAL = 2;
    /** フィールド数 */
    public final static int TMPOBJ_RECORD_COUNT = 3;
    /** テーブルTMPOBJのキー(INTタイプ) */
    public final static int[] N_TMPOBJ_ID = {TMPOBJ_REC_NO, TMPOBJ_BUKKEN_NO};
    /** テーブルTMPOBJのキー(STRINGタイプ) */
    public final static String[] STR_TMPOBJ_ID = {"REC_NO", "BUKKEN_NO"};
    /** テーブルTMPOBJのSQLルート */
    public final static String TMPOBJ_SQLROOT = "/" + TMPOBJ_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String TMPSTAIR_ROOT = "TMPSTAIR";
    /** 案件番号 */
    public final static int TMPSTAIR_REC_NO = 0;
    /** 物件番号 */
    public final static int TMPSTAIR_BUKKEN_NO = 1;
    /** 段数 */
    public final static int TMPSTAIR_STAIR = 2;
    /** 支払日（年） */
    public final static int TMPSTAIR_DATE_YY = 3;
    /** 支払日（月） */
    public final static int TMPSTAIR_DATE_MM = 4;
    /** 支払日（日） */
    public final static int TMPSTAIR_DATE_DD = 5;
    /** フィールド数 */
    public final static int TMPSTAIR_RECORD_COUNT = 6;
    /** テーブルTMPSTAIRのキー(INTタイプ) */
    public final static int[] N_TMPSTAIR_ID = {TMPSTAIR_REC_NO,
        TMPSTAIR_BUKKEN_NO, TMPSTAIR_STAIR};
    /** テーブルTMPSTAIRのキー(STRINGタイプ) */
    public final static String[] STR_TMPSTAIR_ID = {"TMPSTAIR_REC_NO",
        "TMPSTAIR_BUKKEN_NO", "TMPSTAIR_STAIR"};
    /** テーブルTMPSTAIRのSQLルート */
    public final static String TMPSTAIR_SQLROOT = "/" + TMPSTAIR_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String XMLKISHU_ROOT = "XMLKISHU";
    /** 内部保持CD */
    public final static int XMLKISHU_KISHUCD = 0;
    /** 機種 */
    public final static int XMLKISHU_KISHU = 1;
    /** 2桁ｺｰﾄﾞ先頭 */
    public final static int XMLKISHU_OTHERS = 2;
    /** フィールド数 */
    public final static int XMLKISHU_RECORD_COUNT = 3;
    /** テーブルXMLKISHUのキー(INTタイプ) */
    public final static int[] N_XMLKISHU_ID = {XMLKISHU_KISHUCD};
    /** テーブルXMLKISHUのキー(STRINGタイプ) */
    public final static String[] STR_XMLKISHU_ID = {"XMLKISHU_KISHUCD"};
    /** テーブルXMLKISHUのSQLルート */
    public final static String XMLKISHU_SQLROOT = "/" + XMLKISHU_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String TMPPAGEINFO1_ROOT = "TMPPAGEINFO1";
    /** ページ */
    public final static int TMPPAGEINFO1_PAGE = 0;
    /** カラム1(From) */
    public final static int TMPPAGEINFO1_COLUMN1_FR = 1;
    /** カラム1(To) */
    public final static int TMPPAGEINFO1_COLUMN1_TO = 2;
    /** 物件番号1 */
    public final static int TMPPAGEINFO1_BUKKEN_NO1 = 3;
    /** 保険種類1 */
    public final static int TMPPAGEINFO1_INSUR_TYPE1 = 4;
    /** カラム2(From) */
    public final static int TMPPAGEINFO1_COLUMN2_FR = 5;
    /** カラム2(To) */
    public final static int TMPPAGEINFO1_COLUMN2_TO = 6;
    /** 物件番号2 */
    public final static int TMPPAGEINFO1_BUKKEN_NO2 = 7;
    /** 保険種類2 */
    public final static int TMPPAGEINFO1_INSUR_TYPE2 = 8;
    /** カラム3(From) */
    public final static int TMPPAGEINFO1_COLUMN3_FR = 9;
    /** カラム3(To) */
    public final static int TMPPAGEINFO1_COLUMN3_TO = 10;
    /** 物件番号3 */
    public final static int TMPPAGEINFO1_BUKKEN_NO3 = 11;
    /** 保険種類3 */
    public final static int TMPPAGEINFO1_INSUR_TYPE3 = 12;
    /** カラム4(From) */
    public final static int TMPPAGEINFO1_COLUMN4_FR = 13;
    /** カラム4(To) */
    public final static int TMPPAGEINFO1_COLUMN4_TO = 14;
    /** 物件番号4 */
    public final static int TMPPAGEINFO1_BUKKEN_NO4 = 15;
    /** 保険種類4 */
    public final static int TMPPAGEINFO1_INSUR_TYPE4 = 16;
    /** フィールド数 */
    public final static int TMPPAGEINFO1_RECORD_COUNT = 17;
    /** テーブルTMPPAGEINFO1のキー(INTタイプ) */
    public final static int[] N_TMPPAGEINFO1_ID = {TMPPAGEINFO1_PAGE};
    /** テーブルTMPPAGEINFO1のキー(STRINGタイプ) */
    public final static String[] STR_TMPPAGEINFO1_ID = {"TMPPAGEINFO1_PAGE"};
    /** テーブルTMPPAGEINFO1のSQLルート */
    public final static String TMPPAGEINFO1_SQLROOT = "/" + TMPPAGEINFO1_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String TMPPAGEINFO2_ROOT = "TMPPAGEINFO2";
    /** ページ */
    public final static int TMPPAGEINFO2_PAGE = 0;
    /** カラム1(From) */
    public final static int TMPPAGEINFO2_COLUMN1_FR = 1;
    /** カラム1(To) */
    public final static int TMPPAGEINFO2_COLUMN1_TO = 2;
    /** 物件番号1 */
    public final static int TMPPAGEINFO2_BUKKEN_NO1 = 3;
    /** 固定資産税 および 保険料MSG */
    public final static int TMPPAGEINFO2_MSG_FIXASTTAX1 = 4;
    /** 前受回収日DD1 */
    public final static int TMPPAGEINFO2_DATE_INC_0_DD1 = 5;
    /** 第一月分回収日DD1 */
    public final static int TMPPAGEINFO2_DATE_INC_1_DD1 = 6;
    /** 第二月分回収日DD1 */
    public final static int TMPPAGEINFO2_DATE_INC_2_DD1 = 7;
    /** 前受回収の支払期日欄 BB1 */
    public final static int TMPPAGEINFO2_MSG_0_BB1 = 8;
    /** 第一月分回収の支払期日欄 BB1 */
    public final static int TMPPAGEINFO2_MSG_1_BB1 = 9;
    /** 第二月分回収の支払期日欄 BB1 */
    public final static int TMPPAGEINFO2_MSG_2_BB1 = 10;
    /** カラム2(From) */
    public final static int TMPPAGEINFO2_COLUMN2_FR = 11;
    /** カラム2(To) */
    public final static int TMPPAGEINFO2_COLUMN2_TO = 12;
    /** 物件番号2 */
    public final static int TMPPAGEINFO2_BUKKEN_NO2 = 13;
    /** 固定資産税 および 保険料MSG */
    public final static int TMPPAGEINFO2_MSG_FIXASTTAX2 = 14;
    /** 前受回収日DD2 */
    public final static int TMPPAGEINFO2_DATE_INC_0_DD2 = 15;
    /** 第一月分回収日DD2 */
    public final static int TMPPAGEINFO2_DATE_INC_1_DD2 = 16;
    /** 第二月分回収日DD2 */
    public final static int TMPPAGEINFO2_DATE_INC_2_DD2 = 17;
    /** 前受回収の支払期日欄 BB2 */
    public final static int TMPPAGEINFO2_MSG_0_BB2 = 18;
    /** 第一月分回収の支払期日欄 BB2 */
    public final static int TMPPAGEINFO2_MSG_1_BB2 = 19;
    /** 第二月分回収の支払期日欄 BB2 */
    public final static int TMPPAGEINFO2_MSG_2_BB2 = 20;
    /** 検収予定日 */
    public final static int TMPPAGEINFO2_DATE_KENSH = 21;
    /** 転貸有無 */
    public final static int TMPPAGEINFO2_SUBLET_FLG = 22;
    /** 具体的引渡し場所 */
    public final static int TMPPAGEINFO2_DELIV_PLAC = 23;
    /** リース期間(work) */
    public final static int TMPPAGEINFO2_LEASE_M = 24;
    /** 前受回収日 */
    public final static int TMPPAGEINFO2_DATE_INC_0 = 25;
    /** 前受リース月数 */
    public final static int TMPPAGEINFO2_INC_0_M = 26;
    /** 第一月分回収日 */
    public final static int TMPPAGEINFO2_DATE_INC_1 = 27;
    /** 第ニ月分回収日 */
    public final static int TMPPAGEINFO2_DATE_INC_2 = 28;
    /** フィールド数 */
    public final static int TMPPAGEINFO2_RECORD_COUNT = 29;
    /** テーブルTMPPAGEINFO2のキー(INTタイプ) */
    public final static int[] N_TMPPAGEINFO2_ID = {TMPPAGEINFO2_PAGE};
    /** テーブルTMPPAGEINFO2のキー(STRINGタイプ) */
    public final static String[] STR_TMPPAGEINFO2_ID = {"TMPPAGEINFO2_PAGE"};
    /** テーブルTMPPAGEINFO2のSQLルート */
    public final static String TMPPAGEINFO2_SQLROOT = "/" + TMPPAGEINFO2_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String TMPPAGEINFO3_ROOT = "TMPPAGEINFO3";
    /** ページ */
    public final static int TMPPAGEINFO3_PAGE = 0;
    /** カラム1(From) */
    public final static int TMPPAGEINFO3_COLUMN1_FR = 1;
    /** カラム1(To) */
    public final static int TMPPAGEINFO3_COLUMN1_TO = 2;
    /** 物件番号1 */
    public final static int TMPPAGEINFO3_BUKKEN_NO1 = 3;
    /** カラム2(From) */
    public final static int TMPPAGEINFO3_COLUMN2_FR = 4;
    /** カラム2(To) */
    public final static int TMPPAGEINFO3_COLUMN2_TO = 5;
    /** 物件番号2 */
    public final static int TMPPAGEINFO3_BUKKEN_NO2 = 6;
    /** カラム3(From) */
    public final static int TMPPAGEINFO3_COLUMN3_FR = 7;
    /** カラム3(To) */
    public final static int TMPPAGEINFO3_COLUMN3_TO = 8;
    /** 物件番号3 */
    public final static int TMPPAGEINFO3_BUKKEN_NO3 = 9;
    /** カラム4(From) */
    public final static int TMPPAGEINFO3_COLUMN4_FR = 10;
    /** カラム4(To) */
    public final static int TMPPAGEINFO3_COLUMN4_TO = 11;
    /** 物件番号4 */
    public final static int TMPPAGEINFO3_BUKKEN_NO4 = 12;
    /** カラム5(From) */
    public final static int TMPPAGEINFO3_COLUMN5_FR = 13;
    /** カラム5(To) */
    public final static int TMPPAGEINFO3_COLUMN5_TO = 14;
    /** 物件番号5 */
    public final static int TMPPAGEINFO3_BUKKEN_NO5 = 15;
    /** カラム6(From) */
    public final static int TMPPAGEINFO3_COLUMN6_FR = 16;
    /** カラム6(To) */
    public final static int TMPPAGEINFO3_COLUMN6_TO = 17;
    /** 物件番号6 */
    public final static int TMPPAGEINFO3_BUKKEN_NO6 = 18;
    /** カラム7(From) */
    public final static int TMPPAGEINFO3_COLUMN7_FR = 19;
    /** カラム7(To) */
    public final static int TMPPAGEINFO3_COLUMN7_TO = 20;
    /** 物件番号7 */
    public final static int TMPPAGEINFO3_BUKKEN_NO7 = 21;
    /** カラム8(From) */
    public final static int TMPPAGEINFO3_COLUMN8_FR = 22;
    /** カラム8(To) */
    public final static int TMPPAGEINFO3_COLUMN8_TO = 23;
    /** 物件番号8 */
    public final static int TMPPAGEINFO3_BUKKEN_NO8 = 24;
    /** カラム9(From) */
    public final static int TMPPAGEINFO3_COLUMN9_FR = 25;
    /** カラム9(To) */
    public final static int TMPPAGEINFO3_COLUMN9_TO = 26;
    /** 物件番号9 */
    public final static int TMPPAGEINFO3_BUKKEN_NO9 = 27;
    /** 購入先名１ */
    public final static int TMPPAGEINFO3_DEALER_NM1 = 28;
    /** 購入先名２ */
    public final static int TMPPAGEINFO3_DEALER_NM2 = 29;
    /** 支払期日(work) */
    public final static int TMPPAGEINFO3_PAY_FIX_DT = 30;
    /** リース期間(work) */
    public final static int TMPPAGEINFO3_LEASE_M = 31;
    /** 前受リース月数(work) */
    public final static int TMPPAGEINFO3_INC_0_M = 32;
    /** 試算データ使用区分 */
    public final static int TMPPAGEINFO3_PROF_USE_F = 33;
    /** 前受回収日 */
    public final static int TMPPAGEINFO3_DATE_INC_0 = 34;
    /** 前受回収方法１ */
    public final static int TMPPAGEINFO3_MET1_INC_0 = 35;
    /** 前受回収方法２ */
    public final static int TMPPAGEINFO3_MET2_INC_0 = 36;
    /** 第一月分回収日 */
    public final static int TMPPAGEINFO3_DATE_INC_1 = 37;
    /** 第一月分回収方法１ */
    public final static int TMPPAGEINFO3_MET1_INC_1 = 38;
    /** 第一月分回収方法２ */
    public final static int TMPPAGEINFO3_MET2_INC_1 = 39;
    /** 第二月分回収日 */
    public final static int TMPPAGEINFO3_DATE_INC_2 = 40;
    /** 第二月分回収方法１ */
    public final static int TMPPAGEINFO3_MET1_INC_2 = 41;
    /** 第二月分回収方法２ */
    public final static int TMPPAGEINFO3_MET2_INC_2 = 42;
    /** 合計価額 */
    public final static int TMPPAGEINFO3_TOTAL_COST = 43;
    /** 前受リース料(work) */
    public final static int TMPPAGEINFO3_INCOME_0 = 44;
    /** 具体的引渡し場所 */
    public final static int TMPPAGEINFO3_DELIV_PLAC = 45;
    /** 転貸有無 */
    public final static int TMPPAGEINFO3_SUBLET_FLG = 46;
    /** 件数 */
    public final static int TMPPAGEINFO3_BUKKEN_CNT = 47;
    /** 固定資産税 および 保険料MSG */
    public final static int TMPPAGEINFO3_MSG_FIXASTTAX = 48;
    /** 月額リース料(work) */
    public final static int TMPPAGEINFO3_INCOME = 49;
    /** 変則回収区分 */
    public final static int TMPPAGEINFO3_IRG_INC_F = 50;
    /** 割賦回数 */
    public final static int TMPPAGEINFO3_KAPPU_D = 51;
    /** 込保守料算入区分 */
    public final static int TMPPAGEINFO3_SW_HOSHU = 52;
    /** 予備 */
    public final static int TMPPAGEINFO3_RESERVE1 = 53;
    /** 回収段数 */
    public final static int TMPPAGEINFO3_COLLECT_D = 54;
    /** 前受リース料(work) * 消費税 CUT */
    public final static int TMPPAGEINFO3_INCOME_0_TAX_CUT = 55;
    /** 月額リース料(work) * 消費税 CUT */
    public final static int TMPPAGEINFO3_INCOME_TAX_CUT = 56;
    /** 回収サイクル */
    public final static int TMPPAGEINFO3_COLLECT_CYCLE = 57;
    /** 回収サイクル */
    public final static int TMPPAGEINFO3_COLLECT_KAISHU = 58;
    /** フィールド数 */
    public final static int TMPPAGEINFO3_RECORD_COUNT = 59;
    /** テーブルTMPPAGEINFO3のキー(INTタイプ) */
    public final static int[] N_TMPPAGEINFO3_ID = {TMPPAGEINFO3_PAGE};
    /** テーブルTMPPAGEINFO3のキー(STRINGタイプ) */
    public final static String[] STR_TMPPAGEINFO3_ID = {"TMPPAGEINFO3_PAGE"};
    /** テーブルTMPPAGEINFO3のSQLルート */
    public final static String TMPPAGEINFO3_SQLROOT = "/" + TMPPAGEINFO3_ROOT + "/ROW";
    /** XMLのRoot */
    public final static String TMPBUKKENNO_ROOT = "TMPBUKKENNO";
    /** NOUSEKEY */
    public final static int TMPBUKKENNO_NOUSE = 0;
    /** カラム1(From) */
    public final static int TMPBUKKENNO_COLUMN1_FR = 1;
    /** カラム1(To) */
    public final static int TMPBUKKENNO_COLUMN1_TO = 2;
    /** 合計 */
    public final static int TMPBUKKENNO_TOTAL_AMOUNT = 3;
    /** フィールド数 */
    public final static int TMPBUKKENNO_RECORD_COUNT = 4;
    /** テーブルTMPBUKKENNOのキー(INTタイプ) */
    public final static int[] N_TMPBUKKENNO_ID = {TMPBUKKENNO_NOUSE};
    /** テーブルTMPBUKKENNOのキー(STRINGタイプ) */
    public final static String[] STR_TMPBUKKENNO_ID = {"TMPBUKKENNO_NOUSE"};
    /** テーブルTMPBUKKENNOのSQLルート */
    public final static String TMPBUKKENNO_SQLROOT = "/" + TMPBUKKENNO_ROOT + "/ROW";
}
