/*
 * ファイル名：LfcDBOnlySelectInterface.java
 *
 * 修正履歴  ：
 *	           ver1.0.0	    2003/03/27      王嵩
 *                          作成
 *             Copyright (c) 2003
 */

package com.gecl.leaseCal.db.comm;

import java.util.Vector;

/**
 *
 * クラス名：Lfcのインタフェース
 *
 * 概要：LFC使用するインタフェースを定義
 */
public interface LfcDBOnlySelectInterface{
    /** XMLファイルを作成するメソッド
     * @param vDatas
     * @return
     */
    public boolean CreateXml(Vector vDatas);
    /** 解析されるXMLDOCを作成するメソッド
     * @return
     */
    public boolean parseXml();
    /** エラーメッセージを取得するメソッド
     * @return
     */
    public String getErrorMessage();
    /** 検索された結果集を取得するメソッド
     * @return
     */
    public Vector getResults();
    /** XPATH文により結果集を取得するメソッド
     * @return
     */
    public boolean getQueryResults();
}
