/*
 * @(#)PaydivBean.java      01-01  2003/04/08
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 * 修正日：20050706
 * 修正人：曾健
 * 修正内容：試算システムで案件コピーするために、この案件の全て支払情報を取ります
 *
 * 修正日：20050912
 * 修正人：曾健
 * 修正内容：支払額 0XXXX -> XXXX
 *
 * 修正日：20051109
 * 修正人：pzk
 * 修正内容：古いデータのバックアップと復元を処理します.
 *
 * 修正者：曾健
 * 修正日：20051207
 * 修正内容：試算支払表に60フィールドを追加する
 *
 * 修正者：Hao
 * 修正日：20070629
 * 修正内容：XMLファイルに書出す時のエラーLogを追加
 *
 */
package com.gecl.leaseCal.db.comm;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.gecl.leaseCal.log.LfcSystemLog;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;

/**
 * クラス名：DBのPaydivの処理共通Bean． <BR>
 *
 * 機能：
 * <PRE>
 *  １．Paydivのデータ検索
 *  ２．Paydivのデータ更新（INSERT、UPDATE、DELETE）
 * </PRE>
 * @author     DHC-王嵩
 * @version    01-01
 * @see        PAYDIVType
 * @see        LfcDBConst
 * @see        LfcDBInterface
 * @since      01-01
 */
public class PaydivBean implements LfcDBConst {

    /**エラーメッセージを格納する変数を定義する */
    private String _strErrorMessage = "";
    /** エラー項目名前 */
    private String _strErrorItemName = "エラー項目名前 : ";
    /** エラー項目内容 */
    private String _strErrorItemValue = "エラー項目内容 : ";
    /** Paydiv.xmlパス */
    private String _strXmlFilePath = "";
    //pzk add 20051109 s
    private String _strPreviousXmlFilePath = "";
    //pzk add 20051109 e
    /** Paydiv.xsdパス */
    private String _strXsdFilePath = "";
    /** current rec no */
    private String _strCurRecNo = "";
    private StringBuffer _strBufIDIndex = new StringBuffer();
    DateFormat time = new SimpleDateFormat("HH:mm:ss");
    private final PaydivBean _paydivBean = null;
    private  String[][] _strLeaseResults;
    private  String[][] _strEstResults;
    private  int _nRecBukenCount = 0;
    private  String _strDisplayBukenNo;
    XmlArrReader _paydivXmlReader = null;
    StringBuffer _strBuffer = new StringBuffer();
    //pzk add 20051109 s
    XmlArrReader _previousPaydivXmlReader = null;
    StringBuffer _strPreviousBuffer = new StringBuffer();
    private String[][] _strPreviousResults;
    private String _strPreviousCurRecNo = "";
    private  int _nPreviousRecBukenCount = 0;
    private String _strPreviousErrorMessage = "";
    //pzk add 20051109 e

    public PaydivBean() {
        _strXmlFilePath = LfcDBConfig.getPaydivXmlPath();
        _strXsdFilePath = LfcDBConfig.getPaydivXsdPath();
        //parseXml();
        getInstance();
    }

    public  boolean addPaydivResults(String[][] inpaydiv) {
        boolean bFlg = true;
        if (inpaydiv == null || _strLeaseResults == null) {
            if (_strLeaseResults == null) {
                _strLeaseResults = inpaydiv;
            }
            return bFlg;
        }
        String[][] strRetResults = new String[_strLeaseResults.length + inpaydiv.length][PAYDIV_RECORD_COUNT - 1];
        for (int i = 0; i < _strLeaseResults.length; i++) {
            System.arraycopy(_strLeaseResults[i], 0, strRetResults[i], 0, PAYDIV_RECORD_COUNT - 1);
        }

        for (int i = _strLeaseResults.length; i < _strLeaseResults.length + inpaydiv.length; i++) {
            System.arraycopy(inpaydiv[i-_strLeaseResults.length], 0, strRetResults[i], 0, PAYDIV_RECORD_COUNT - 1);
        }
        _strLeaseResults = strRetResults;
        return bFlg;
    }

    public  PaydivBean getInstance() {
        return _paydivBean;
    }

    /**
     * 解析されるXMLDOCを作成するメソッド．    <BR>
     *
     * param   strXmlUrl         XMLのURL
     * @return  boolean    true ：XMLDOCの作成は成功
     *                     false：XMLDOCの作成は失敗
     * @since              01-01
     */
    public boolean parseXml() {
        File file = new File(_strXmlFilePath);
        if (file.exists()) {
        } else {
            CreateXml();
        }
        _paydivXmlReader = new XmlArrReader(_strXmlFilePath, PAYDIV_RECORD_COUNT - 1);
        _paydivXmlReader.parse();
        getBufferString();
        /*
        long t1 = System.currentTimeMillis();
        getQueryResults("1");
        String[][] aa = new String[_strLeaseResults.length][PAYDIV_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, aa, 0, _strLeaseResults.length);
        int kk = 0;
        for(int i = 201; i <= 300; i++) {
        for(int j = 0; j < aa.length; j++) {
        aa[j][PAYDIV_REC_NO] = "" + i;
        aa[j][PAYDIV_BUKKEN_NO] = aa[j][PAYDIV_BUKKEN_FR];
        insertRecord(aa[j]);
        kk++;
        }
        }
        doCommit();
        long t2 = System.currentTimeMillis();
         */
        //removeRecordl("1");
        //doCommit();
        return true;
    }
    //pzk add 20051109 s

    /**
     * 解析されるXMLDOCを作成するメソッド．    <BR>
     *
     * return   boolean
     */
    public void parsePreviousData() {
        if (_previousPaydivXmlReader == null) {
            File file = new File(_strPreviousXmlFilePath);
            if (!file.exists()) {
                createPreviousXml();
            }
            _previousPaydivXmlReader =
                    new XmlArrReader(_strPreviousXmlFilePath, PAYDIV_RECORD_COUNT - 1);
            _previousPaydivXmlReader.parse();
            getPreviousBufferString();
        }
    }

    public void getPreviousBufferString() {
        try {
            _strPreviousBuffer = new StringBuffer();
            InputStream in = new FileInputStream(_strPreviousXmlFilePath);
            in = new BufferedInputStream(in);
            Reader r = new InputStreamReader(in);
            r = new BufferedReader(r, 1024);
            int c;
            while ((c = r.read()) != -1) {
                _strPreviousBuffer.append((char) c);
            }
            r.close();
        } catch (Exception ex) {
        }
    }
    //pzk add 20051109 e

    public void getBufferString() {
        try {
            _strBuffer = new StringBuffer();
            InputStream in = new FileInputStream(_strXmlFilePath);
            in = new BufferedInputStream(in);
            Reader r = new InputStreamReader(in);
            r = new BufferedReader(r, 1024);
            int c;
            while ((c = r.read()) != -1) {
                _strBuffer.append((char) c);
            }
            r.close();
        } catch (Exception ex) {
        }
    }

    public boolean removeRecordl(String strRecNo) {
        String strDelete = _strBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2) {
                break;
            }
            String strKeyValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            if (strRecNo.equals(strKeyValue)) {
                int nPos6 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos6 + 6);
            }
            i = nPos1;
        }
        return true;
    }

    /**
     * エラーメッセージを取得．    <BR>
     *
     * @return   String    エラーメッセージ
     * @since              01-01
     */
    public String getErrorMessage() {
        return _strErrorMessage;
    }
    //pzk add 20051109 s

    public String getPreviousErrorMessage() {
        return _strPreviousErrorMessage;
    }
    //pzk add 20051109 e

    /**
     * 前物件インデックスを表示するメソッド。
     * param   無し。
     * return  無し。
     */
    public  void setDisplayBukenNo(String strDisplayBukenNo) {
        _strDisplayBukenNo = strDisplayBukenNo;
    }

    /**
     * インデックスの_nBukenIndexの物件レコードを戻すメソッド。
     * param   無し。
     * @return  無し。
     */
    public  String[][] getDisplayRec() {
        if (isResultsNull()) {
            return new String[0][PAYDIV_RECORD_COUNT];
        }

        int[] nBukenResultsNum = new int[_strLeaseResults.length];
        int j = 0;
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (_strDisplayBukenNo.equals(_strLeaseResults[i][PAYDIV_BUKKEN_NO])) {
                nBukenResultsNum[j++] = i;
            }
        }
        if (j - 1 < 0) {
            return null;
        }
        String[][] strBukenResults = new String[j][PAYDIV_RECORD_COUNT];
        for (int i = 0; i < j; i++) {
            System.arraycopy(_strLeaseResults, nBukenResultsNum[i], strBukenResults, i, 1);
        }
        return strBukenResults;
    }

    public  String[][] getCalRec(String strBukenNo) {
        String[][] strTmp = null;
        int nCnt = 0;
        if (_strLeaseResults == null || _strLeaseResults.length == 0) {
            return new String[0][0];
        }
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strBukenNo.equals(_strLeaseResults[i][PAYDIV_BUKKEN_NO])) {
                nCnt = nCnt + 1;
            }
        }
        if (nCnt == 0) {
            return new String[0][0];
        }
        strTmp = new String[nCnt][PAYDIV_RECORD_COUNT];
        nCnt = 0;
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strBukenNo.equals(_strLeaseResults[i][PAYDIV_BUKKEN_NO])) {
                strTmp[nCnt] = _strLeaseResults[i];
                nCnt = nCnt + 1;
            }
        }
        return strTmp;
    }

    /**
     * 検索結果集を取得．    <BR>
     *
     * @return    Vector   Paydivの検索結果集
     * @since              01-01
     */
    public  String[][] getResultsForLease() {
        return _strLeaseResults;
    }

    public  void setResultsForLease(String[][] strLeaseResults) {
        _strLeaseResults = strLeaseResults;
    }

    public String[][] getQueryResultsForEstCopy(String strRecNo) {
        String[][] strResults = getQueryResults(strRecNo);
        if (strResults.length == 0) {
            return new String[0][0];
        }
        String[][] strEstResults = new String[_nRecBukenCount][PAYDIV_RECORD_COUNT];
        for (int i = 0; i < _nRecBukenCount; i++) {
            System.arraycopy(strResults[i], 0, strEstResults[i], 0, PAYDIV_RECORD_COUNT);
        }
        return strEstResults;
    }

    public String[][] getQueryResultsForLease(String strRecNo) {
        String[][] strResults = getQueryResults(strRecNo);
        if (strResults.length == 0) {
            return new String[0][0];
        }
        _strLeaseResults = new String[_nRecBukenCount][PAYDIV_RECORD_COUNT];
        for (int i = 0; i < _nRecBukenCount; i++) {
            System.arraycopy(strResults[i], 0, _strLeaseResults[i], 0, PAYDIV_RECORD_COUNT);
        }
        return _strLeaseResults;
    }

    /**
     * XPATH文により結果集を取得するメソッド．    <BR>
     *
     * <PRE>
     *  １．XPATH文によりID結果集を取得する。
     *  ２．ID結果集により対応するINDEX配列を取得する。
     *  ３．INDEX配列により、対応の結果集を取得する。
     *  　  成功の場合、結果集を_vResultsに設定する。
     *   　 失敗の場合、エラーメッセージを_strErrorMessageに設定する。
     * </PRE>
     *
     * param   strSql         XPATH文
     * @return  boolean true ：結果集の設定は成功
     *                  false：結果集の設定は失敗
     * @see     #getIDs(String)
     * @see     #getIDsIndexArray(Vector)
     * @since   01-01
     */
    public String[][] getQueryResults(String strRecNo) {
        String[] tmpStrName = _paydivXmlReader.getFieldName();
        if (tmpStrName[0] == null) {
            setFieldName();
        }
        _strCurRecNo = strRecNo;
        String[][] strResults = new String[_paydivXmlReader.getRowCount()][PAYDIV_RECORD_COUNT];
        try {
            _nRecBukenCount = 0;
            for (int i = 0; i < strResults.length; i++) {
                if (!strRecNo.equals(_paydivXmlReader.getData(i, "REC_NO"))) {
                    continue;
                }
                strResults[_nRecBukenCount][PAYDIV_REC_NO] = _paydivXmlReader.getData(i, "REC_NO");
                strResults[_nRecBukenCount][PAYDIV_BUKKEN_NO] = _paydivXmlReader.getData(i, "BUKKEN_NO");
                strResults[_nRecBukenCount][PAYDIV_STAIR] = _paydivXmlReader.getData(i, "STAIR");
                strResults[_nRecBukenCount][PAYDIV_BUKKEN_FR] = _paydivXmlReader.getData(i, "BUKKEN_FR");
                strResults[_nRecBukenCount][PAYDIV_BUKKEN_TO] = _paydivXmlReader.getData(i, "BUKKEN_TO");
                strResults[_nRecBukenCount][PAYDIV_PURCHASE] = _paydivXmlReader.getData(i, "PURCHASE");
                strResults[_nRecBukenCount][PAYDIV_DATE_YY] = _paydivXmlReader.getData(i, "DATE_YY");
                strResults[_nRecBukenCount][PAYDIV_DATE_MM] = _paydivXmlReader.getData(i, "DATE_MM");
                strResults[_nRecBukenCount][PAYDIV_DATE_DD] = _paydivXmlReader.getData(i, "DATE_DD");
                strResults[_nRecBukenCount][PAYDIV_ROW_INDEX] = "" + i;

                //20051207 zj s
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_01] = _paydivXmlReader.getData(i, "RESERVE_C_01");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_02] = _paydivXmlReader.getData(i, "RESERVE_C_02");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_03] = _paydivXmlReader.getData(i, "RESERVE_C_03");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_04] = _paydivXmlReader.getData(i, "RESERVE_C_04");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_05] = _paydivXmlReader.getData(i, "RESERVE_C_05");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_06] = _paydivXmlReader.getData(i, "RESERVE_C_06");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_07] = _paydivXmlReader.getData(i, "RESERVE_C_07");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_08] = _paydivXmlReader.getData(i, "RESERVE_C_08");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_09] = _paydivXmlReader.getData(i, "RESERVE_C_09");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_10] = _paydivXmlReader.getData(i, "RESERVE_C_10");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_11] = _paydivXmlReader.getData(i, "RESERVE_C_11");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_12] = _paydivXmlReader.getData(i, "RESERVE_C_12");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_13] = _paydivXmlReader.getData(i, "RESERVE_C_13");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_14] = _paydivXmlReader.getData(i, "RESERVE_C_14");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_15] = _paydivXmlReader.getData(i, "RESERVE_C_15");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_16] = _paydivXmlReader.getData(i, "RESERVE_C_16");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_17] = _paydivXmlReader.getData(i, "RESERVE_C_17");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_18] = _paydivXmlReader.getData(i, "RESERVE_C_18");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_19] = _paydivXmlReader.getData(i, "RESERVE_C_19");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_20] = _paydivXmlReader.getData(i, "RESERVE_C_20");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_21] = _paydivXmlReader.getData(i, "RESERVE_C_21");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_22] = _paydivXmlReader.getData(i, "RESERVE_C_22");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_23] = _paydivXmlReader.getData(i, "RESERVE_C_23");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_24] = _paydivXmlReader.getData(i, "RESERVE_C_24");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_25] = _paydivXmlReader.getData(i, "RESERVE_C_25");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_26] = _paydivXmlReader.getData(i, "RESERVE_C_26");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_27] = _paydivXmlReader.getData(i, "RESERVE_C_27");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_28] = _paydivXmlReader.getData(i, "RESERVE_C_28");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_29] = _paydivXmlReader.getData(i, "RESERVE_C_29");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_C_30] = _paydivXmlReader.getData(i, "RESERVE_C_30");

                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_01] = _paydivXmlReader.getData(i, "RESERVE_N_01");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_02] = _paydivXmlReader.getData(i, "RESERVE_N_02");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_03] = _paydivXmlReader.getData(i, "RESERVE_N_03");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_04] = _paydivXmlReader.getData(i, "RESERVE_N_04");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_05] = _paydivXmlReader.getData(i, "RESERVE_N_05");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_06] = _paydivXmlReader.getData(i, "RESERVE_N_06");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_07] = _paydivXmlReader.getData(i, "RESERVE_N_07");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_08] = _paydivXmlReader.getData(i, "RESERVE_N_08");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_09] = _paydivXmlReader.getData(i, "RESERVE_N_09");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_10] = _paydivXmlReader.getData(i, "RESERVE_N_10");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_11] = _paydivXmlReader.getData(i, "RESERVE_N_11");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_12] = _paydivXmlReader.getData(i, "RESERVE_N_12");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_13] = _paydivXmlReader.getData(i, "RESERVE_N_13");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_14] = _paydivXmlReader.getData(i, "RESERVE_N_14");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_15] = _paydivXmlReader.getData(i, "RESERVE_N_15");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_16] = _paydivXmlReader.getData(i, "RESERVE_N_16");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_17] = _paydivXmlReader.getData(i, "RESERVE_N_17");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_18] = _paydivXmlReader.getData(i, "RESERVE_N_18");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_19] = _paydivXmlReader.getData(i, "RESERVE_N_19");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_20] = _paydivXmlReader.getData(i, "RESERVE_N_20");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_21] = _paydivXmlReader.getData(i, "RESERVE_N_21");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_22] = _paydivXmlReader.getData(i, "RESERVE_N_22");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_23] = _paydivXmlReader.getData(i, "RESERVE_N_23");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_24] = _paydivXmlReader.getData(i, "RESERVE_N_24");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_25] = _paydivXmlReader.getData(i, "RESERVE_N_25");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_26] = _paydivXmlReader.getData(i, "RESERVE_N_26");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_27] = _paydivXmlReader.getData(i, "RESERVE_N_27");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_28] = _paydivXmlReader.getData(i, "RESERVE_N_28");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_29] = _paydivXmlReader.getData(i, "RESERVE_N_29");
                strResults[_nRecBukenCount][PAYDIV_RESERVE_N_30] = _paydivXmlReader.getData(i, "RESERVE_N_30");
                //20051207 zj e

                _nRecBukenCount = _nRecBukenCount + 1;
            }
            String[][] strRetResults = new String[_nRecBukenCount][PAYDIV_RECORD_COUNT];
            for (int i = 0; i < strRetResults.length; i++) {
                System.arraycopy(strResults[i], 0, strRetResults[i], 0, strResults[i].length);
            }
            _strLeaseResults = strRetResults;
            return strRetResults;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("PaydivBean", //クラス名
                    "getQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return new String[0][0];
        }
    }
    //pzk add 20051109 s

    public String[][] getPreviousQueryResults(String strRecNo) {
        String[] tmpStrName = _previousPaydivXmlReader.getFieldName();
        if (tmpStrName[0] == null) {
            setPreviousFieldName();
        }
        _strPreviousCurRecNo = strRecNo;
        String[][] strResults = new String[_previousPaydivXmlReader.getRowCount()][PAYDIV_RECORD_COUNT];
        try {
            _nPreviousRecBukenCount = 0;
            for (int i = 0; i < strResults.length; i++) {
                if (!strRecNo.equals(_previousPaydivXmlReader.getData(i, "REC_NO"))) {
                    continue;
                }
                strResults[_nPreviousRecBukenCount][PAYDIV_REC_NO] = _previousPaydivXmlReader.getData(i, "REC_NO");
                strResults[_nPreviousRecBukenCount][PAYDIV_BUKKEN_NO] = _previousPaydivXmlReader.getData(i, "BUKKEN_NO");
                strResults[_nPreviousRecBukenCount][PAYDIV_STAIR] = _previousPaydivXmlReader.getData(i, "STAIR");
                strResults[_nPreviousRecBukenCount][PAYDIV_BUKKEN_FR] = _previousPaydivXmlReader.getData(i, "BUKKEN_FR");
                strResults[_nPreviousRecBukenCount][PAYDIV_BUKKEN_TO] = _previousPaydivXmlReader.getData(i, "BUKKEN_TO");
                strResults[_nPreviousRecBukenCount][PAYDIV_PURCHASE] = _previousPaydivXmlReader.getData(i, "PURCHASE");
                strResults[_nPreviousRecBukenCount][PAYDIV_DATE_YY] = _previousPaydivXmlReader.getData(i, "DATE_YY");
                strResults[_nPreviousRecBukenCount][PAYDIV_DATE_MM] = _previousPaydivXmlReader.getData(i, "DATE_MM");
                strResults[_nPreviousRecBukenCount][PAYDIV_DATE_DD] = _previousPaydivXmlReader.getData(i, "DATE_DD");
                strResults[_nPreviousRecBukenCount][PAYDIV_ROW_INDEX] = "" + i;

                //20051207 zj s
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_01] = _previousPaydivXmlReader.getData(i, "RESERVE_C_01");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_02] = _previousPaydivXmlReader.getData(i, "RESERVE_C_02");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_03] = _previousPaydivXmlReader.getData(i, "RESERVE_C_03");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_04] = _previousPaydivXmlReader.getData(i, "RESERVE_C_04");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_05] = _previousPaydivXmlReader.getData(i, "RESERVE_C_05");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_06] = _previousPaydivXmlReader.getData(i, "RESERVE_C_06");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_07] = _previousPaydivXmlReader.getData(i, "RESERVE_C_07");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_08] = _previousPaydivXmlReader.getData(i, "RESERVE_C_08");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_09] = _previousPaydivXmlReader.getData(i, "RESERVE_C_09");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_10] = _previousPaydivXmlReader.getData(i, "RESERVE_C_10");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_11] = _previousPaydivXmlReader.getData(i, "RESERVE_C_11");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_12] = _previousPaydivXmlReader.getData(i, "RESERVE_C_12");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_13] = _previousPaydivXmlReader.getData(i, "RESERVE_C_13");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_14] = _previousPaydivXmlReader.getData(i, "RESERVE_C_14");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_15] = _previousPaydivXmlReader.getData(i, "RESERVE_C_15");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_16] = _previousPaydivXmlReader.getData(i, "RESERVE_C_16");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_17] = _previousPaydivXmlReader.getData(i, "RESERVE_C_17");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_18] = _previousPaydivXmlReader.getData(i, "RESERVE_C_18");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_19] = _previousPaydivXmlReader.getData(i, "RESERVE_C_19");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_20] = _previousPaydivXmlReader.getData(i, "RESERVE_C_20");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_21] = _previousPaydivXmlReader.getData(i, "RESERVE_C_21");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_22] = _previousPaydivXmlReader.getData(i, "RESERVE_C_22");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_23] = _previousPaydivXmlReader.getData(i, "RESERVE_C_23");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_24] = _previousPaydivXmlReader.getData(i, "RESERVE_C_24");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_25] = _previousPaydivXmlReader.getData(i, "RESERVE_C_25");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_26] = _previousPaydivXmlReader.getData(i, "RESERVE_C_26");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_27] = _previousPaydivXmlReader.getData(i, "RESERVE_C_27");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_28] = _previousPaydivXmlReader.getData(i, "RESERVE_C_28");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_29] = _previousPaydivXmlReader.getData(i, "RESERVE_C_29");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_C_30] = _previousPaydivXmlReader.getData(i, "RESERVE_C_30");

                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_01] = _previousPaydivXmlReader.getData(i, "RESERVE_N_01");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_02] = _previousPaydivXmlReader.getData(i, "RESERVE_N_02");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_03] = _previousPaydivXmlReader.getData(i, "RESERVE_N_03");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_04] = _previousPaydivXmlReader.getData(i, "RESERVE_N_04");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_05] = _previousPaydivXmlReader.getData(i, "RESERVE_N_05");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_06] = _previousPaydivXmlReader.getData(i, "RESERVE_N_06");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_07] = _previousPaydivXmlReader.getData(i, "RESERVE_N_07");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_08] = _previousPaydivXmlReader.getData(i, "RESERVE_N_08");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_09] = _previousPaydivXmlReader.getData(i, "RESERVE_N_09");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_10] = _previousPaydivXmlReader.getData(i, "RESERVE_N_10");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_11] = _previousPaydivXmlReader.getData(i, "RESERVE_N_11");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_12] = _previousPaydivXmlReader.getData(i, "RESERVE_N_12");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_13] = _previousPaydivXmlReader.getData(i, "RESERVE_N_13");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_14] = _previousPaydivXmlReader.getData(i, "RESERVE_N_14");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_15] = _previousPaydivXmlReader.getData(i, "RESERVE_N_15");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_16] = _previousPaydivXmlReader.getData(i, "RESERVE_N_16");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_17] = _previousPaydivXmlReader.getData(i, "RESERVE_N_17");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_18] = _previousPaydivXmlReader.getData(i, "RESERVE_N_18");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_19] = _previousPaydivXmlReader.getData(i, "RESERVE_N_19");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_20] = _previousPaydivXmlReader.getData(i, "RESERVE_N_20");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_21] = _previousPaydivXmlReader.getData(i, "RESERVE_N_21");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_22] = _previousPaydivXmlReader.getData(i, "RESERVE_N_22");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_23] = _previousPaydivXmlReader.getData(i, "RESERVE_N_23");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_24] = _previousPaydivXmlReader.getData(i, "RESERVE_N_24");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_25] = _previousPaydivXmlReader.getData(i, "RESERVE_N_25");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_26] = _previousPaydivXmlReader.getData(i, "RESERVE_N_26");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_27] = _previousPaydivXmlReader.getData(i, "RESERVE_N_27");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_28] = _previousPaydivXmlReader.getData(i, "RESERVE_N_28");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_29] = _previousPaydivXmlReader.getData(i, "RESERVE_N_29");
                strResults[_nPreviousRecBukenCount][PAYDIV_RESERVE_N_30] = _previousPaydivXmlReader.getData(i, "RESERVE_N_30");
                //20051207 zj e

                _nPreviousRecBukenCount = _nPreviousRecBukenCount + 1;
            }
            String[][] strRetResults = new String[_nPreviousRecBukenCount][PAYDIV_RECORD_COUNT];
            for (int i = 0; i < strRetResults.length; i++) {
                System.arraycopy(strResults[i], 0, strRetResults[i], 0, strResults[i].length);
            }
            _strPreviousResults = strRetResults;
            return strRetResults;
        } catch (Exception e) {
            _strPreviousErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("PaydivBean", //クラス名
                    "getPreviousQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return new String[0][0];
        }
    }
    //pzk add 20051109 e

    //20050706 zj start
    public String[][] getQueryResults4BukSelect(String strRecNo) {
        String[] tmpStrName = _paydivXmlReader.getFieldName();
        if (tmpStrName[0] == null) {
            setFieldName();
        }
        String[][] strResults = new String[_paydivXmlReader.getRowCount()][PAYDIV_RECORD_COUNT];
        try {
            int nRecBukenCount = 0;
            for (int i = 0; i < strResults.length; i++) {
                if (!strRecNo.equals(_paydivXmlReader.getData(i, "REC_NO"))) {
                    continue;
                }
                strResults[nRecBukenCount][PAYDIV_REC_NO] = _paydivXmlReader.getData(i, "REC_NO");
                strResults[nRecBukenCount][PAYDIV_BUKKEN_NO] = _paydivXmlReader.getData(i, "BUKKEN_NO");
                strResults[nRecBukenCount][PAYDIV_STAIR] = _paydivXmlReader.getData(i, "STAIR");
                strResults[nRecBukenCount][PAYDIV_BUKKEN_FR] = _paydivXmlReader.getData(i, "BUKKEN_FR");
                strResults[nRecBukenCount][PAYDIV_BUKKEN_TO] = _paydivXmlReader.getData(i, "BUKKEN_TO");
                strResults[nRecBukenCount][PAYDIV_PURCHASE] = _paydivXmlReader.getData(i, "PURCHASE");
                strResults[nRecBukenCount][PAYDIV_DATE_YY] = _paydivXmlReader.getData(i, "DATE_YY");
                strResults[nRecBukenCount][PAYDIV_DATE_MM] = _paydivXmlReader.getData(i, "DATE_MM");
                strResults[nRecBukenCount][PAYDIV_DATE_DD] = _paydivXmlReader.getData(i, "DATE_DD");
                strResults[nRecBukenCount][PAYDIV_ROW_INDEX] = "" + i;
                nRecBukenCount++;
            }
            String[][] strRetResults = new String[nRecBukenCount][PAYDIV_RECORD_COUNT];
            for (int i = 0; i < strRetResults.length; i++) {
                System.arraycopy(strResults[i], 0, strRetResults[i], 0, strResults[i].length);
            }
//            _strLeaseResults = strRetResults;
            return strRetResults;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("PaydivBean", //クラス名
                    "getQueryResults(String strSql)", //メソッド名
                    LfcDBMsgConst.ERA008, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            return new String[0][0];
        }
    }
    //20050706 zj end

    /**
     * 検索ID集により結果集を取得するメソッド(表示出力配列の項目だけ取得する)．    <BR>
     *
     * <PRE>
     *  １．検索ID集により結果集を取得する。
     *  ２．表示出力配列により配列nOutColに設定するフィールドだけを取得する。
     *      成功の場合、結果集を_vResultsに設定する。
     *      失敗の場合、エラーメッセージを_strErrorMessageに設定する。
     * </PRE>
     *
     * @param   strSql         XPATH文
     * @param   nOutCol        表示出力項目を格納する配列
     * @return  boolean true ：結果集の設定は成功
     *                  false：結果集の設定は失敗
     * @see     #getQueryResults(String)
     * @since   01-01
     */
    public String[][] getQueryResults(String strSql, int[] nOutCol) {
        try {
            if (getQueryResultsForLease(strSql).length == 0) {
                return new String[0][0];
            }
            String[][] strOutColResults = new String[_strLeaseResults.length][nOutCol.length];
            for (int i = 0; i < _strLeaseResults.length; i++) {
                for (int j = 0; j < nOutCol.length; j++) {
                    strOutColResults[i][j] = _strLeaseResults[i][nOutCol[j]];
                }
            }
            return strOutColResults;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("PaydivBean", //クラス名
                    "getQueryResults(String strSql, int[] nOutCol)", //メソッド名
                    LfcDBMsgConst.ERA009, //ロジックメッセージ
                    e);                                   //システムエラーメッセージ
            return new String[0][0];
        }
    }

    /**
     * 更新配列に設定する項目より複数のレコードを更新するメソッド．    <BR>
     *
     * <PRE>
     *  ループでupdateRecordメソッドをコールして複数レコードの更新を行う。
     * </PRE>
     *
     * @param   nFieldNameArray  更新フィールド名を格納配列
     * @param   vValues          更新フィールド値を格納するVector
     * @return  boolean   true ：複数のレコードの更新は成功
     *                    false：複数のレコードの更新は失敗
     * @see     #updateRecord(int[], Vector)
     * @since   01-01
     */
    public boolean updateRecords(int[] nFieldNameArray, String[][] strValues) {
        for (int i = 0; i < strValues.length; i++) {
            updateRecord(nFieldNameArray, strValues[i]);
        }
        return true;
    }

    /**
     * 更新配列に設定する項目より単一のレコードを更新するメソッド．    <BR>
     *
     * <PRE>
     *  キーINDEXの設定は正しいかどうかの判断。
     *  更新配列に設定する項目だけ更新する。
     * </PRE>
     *
     * @param   nFieldNameArray  更新フィールド名を格納配列
     * @param   vValues          更新フィールド値を格納するVector
     * @return  boolean   true ：単一のレコードの更新は成功
     *                    false：単一のレコードの更新は失敗
     * @see     #updateFlag(int, int[])
     * @since   01-01
     */
    public boolean updateRecord(int[] nFieldNameArray, String[] strValues) {
        String[] strValue = new String[PAYDIV_RECORD_COUNT];
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (strValues[PAYDIV_REC_NO].equals(_strLeaseResults[i][PAYDIV_REC_NO]) &&
                    strValues[PAYDIV_BUKKEN_NO].equals(_strLeaseResults[i][PAYDIV_BUKKEN_NO])) {
                System.arraycopy(_strLeaseResults[i], 0, strValue, 0, PAYDIV_RECORD_COUNT);
                strValue[PAYDIV_BUKKEN_FR] = strValues[PAYDIV_BUKKEN_FR];
                strValue[PAYDIV_BUKKEN_TO] = strValues[PAYDIV_BUKKEN_TO];
                break;
            }
        }

        removeRecord(strValues[PAYDIV_BUKKEN_NO], strValues[PAYDIV_STAIR]);
        insertRecord(strValue);
        return true;
    }

    /**
     * INSERT配列に設定する項目より複数のレコードをINSERTするメソッド．    <BR>
     *
     * <PRE>
     *  ループでinsertRecordメソッドをコールして複数レコードのINSERTを行う。
     * </PRE>
     *
     * @param   nFieldNameArray    INSERTフィールド名を格納配列
     * @param   vValues            INSERTフィールド値を格納するVector
     * @return  boolean   true ：  複数のレコードのINSERTは成功
     *                    false：  複数のレコードのINSERTは失敗
     * @see     #insertRecord(int, Vector)
     * @since   01-01
     */
    public boolean insertRecords(int[] nFieldNameArray, String[][] strValues) {
        try {
            int nInsertBeforeRowCnt = _paydivXmlReader.getRowCount() - 1;
            for (int i = 0; i < strValues.length; i++) {
                if (!insertRecord(strValues[i])) {
                    return false;
                }
            }
            /*
            //refresh array
            String[][] strTempArr;
            int nInsertBeforeResultsLen = 0;
            if(_strLeaseResults == null) {
            strTempArr = new String[strValues.length][PAYDIV_RECORD_COUNT];
            nInsertBeforeResultsLen = 0;
            } else {
            strTempArr = new String[_strLeaseResults.length + strValues.length][PAYDIV_RECORD_COUNT];
            System.arraycopy(_strLeaseResults, 0, strTempArr, 0, _strLeaseResults.length);
            nInsertBeforeResultsLen = _strLeaseResults.length;
            }
            int nStartIndex = nInsertBeforeRowCnt + 1;
            for(int i = 0; i < strValues.length; i++) {
            strValues[i][strValues[0].length - 1] = "" + (nStartIndex + i);
            System.arraycopy(strValues[i], 0, strTempArr[nInsertBeforeResultsLen + i], 0, strValues[i].length);
            nInsertBeforeRowCnt++;
            }
            _strLeaseResults = strTempArr;
             */
            return true;
        } catch (Exception e) {
            _strErrorMessage = LfcDBMsgConst.ERA000;
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("PaydivBean", //クラス名
                    "insertRecords(int[] nFieldNameArray, String[][] strValues)", //メソッド名
                    LfcDBMsgConst.ERA012, //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
            return false;
        }
    }

    /**
     * INSERT配列に設定する項目より単一のレコードをINSERTするメソッド．    <BR>
     *
     * <PRE>
     *  キーユニークチェック。
     *  INSERT配列に設定する項目だけINSERTする。
     * </PRE>
     *
     * @param   nFieldNameArray    INSERTフィールド名を格納配列
     * @param   vValues            INSERTフィールド値を格納するVector
     *
     * @return  boolean    true ： 単一のレコードのINSERTは成功
     *                     false： 単一のレコードのINSERTは失敗
     * @since              01-01
     */
    public boolean insertRecord(String[] strValues) {
        //20060612支払い金額=0のみ場合　空白行を外す　begin
        if ("0".equals(strValues[PAYDIV_PURCHASE]) && "".equals(strValues[PAYDIV_DATE_YY])) {
            return true;
        }
        //20060612支払い金額=0のみ場合　空白行を外す　end
        String strOff = _strBuffer.toString();
        int nOffset = strOff.lastIndexOf("</PAYDIV>");
        StringBuffer strOut = new StringBuffer();

        strOut.append("<ROW BUKKEN_NO=\"");
        strOut.append(strValues[PAYDIV_BUKKEN_NO]);
        strOut.append("\" REC_NO=\"");
        strOut.append(strValues[PAYDIV_REC_NO]);
        strOut.append("\" STAIR=\"");
        strOut.append(strValues[PAYDIV_STAIR]);
        strOut.append("\">");
        strOut.append("<BUKKEN_FR>" + strValues[PAYDIV_BUKKEN_FR] + "</BUKKEN_FR>");
        strOut.append("<BUKKEN_TO>" + strValues[PAYDIV_BUKKEN_TO] + "</BUKKEN_TO>");

        //20050912 ZJ start
        //20060614 ws change start
//        strOut.append("<PURCHASE>" + new Long(strValues[PAYDIV_PURCHASE]) + "</PURCHASE>");
        strOut.append("<PURCHASE>" + spaceTo0(strValues[PAYDIV_PURCHASE]) + "</PURCHASE>");
        //20060614 ws change end
        //20050912 ZJ end

        strOut.append("<DATE_YY>" + strValues[PAYDIV_DATE_YY] + "</DATE_YY>");
        strOut.append("<DATE_MM>" + strValues[PAYDIV_DATE_MM] + "</DATE_MM>");
        strOut.append("<DATE_DD >" + strValues[PAYDIV_DATE_DD] + "</DATE_DD >");

        //20051207 zj s
        strOut.append(
                "<RESERVE_C_01>" + strValues[PAYDIV_RESERVE_C_01] + "</RESERVE_C_01>");
        strOut.append(
                "<RESERVE_C_02>" + strValues[PAYDIV_RESERVE_C_02] + "</RESERVE_C_02>");
        strOut.append(
                "<RESERVE_C_03>" + strValues[PAYDIV_RESERVE_C_03] + "</RESERVE_C_03>");
        strOut.append(
                "<RESERVE_C_04>" + strValues[PAYDIV_RESERVE_C_04] + "</RESERVE_C_04>");
        strOut.append(
                "<RESERVE_C_05>" + strValues[PAYDIV_RESERVE_C_05] + "</RESERVE_C_05>");
        strOut.append(
                "<RESERVE_C_06>" + strValues[PAYDIV_RESERVE_C_06] + "</RESERVE_C_06>");
        strOut.append(
                "<RESERVE_C_07>" + strValues[PAYDIV_RESERVE_C_07] + "</RESERVE_C_07>");
        strOut.append(
                "<RESERVE_C_08>" + strValues[PAYDIV_RESERVE_C_08] + "</RESERVE_C_08>");
        strOut.append(
                "<RESERVE_C_09>" + strValues[PAYDIV_RESERVE_C_09] + "</RESERVE_C_09>");
        strOut.append(
                "<RESERVE_C_10>" + strValues[PAYDIV_RESERVE_C_10] + "</RESERVE_C_10>");
        strOut.append(
                "<RESERVE_C_11>" + strValues[PAYDIV_RESERVE_C_11] + "</RESERVE_C_11>");
        strOut.append(
                "<RESERVE_C_12>" + strValues[PAYDIV_RESERVE_C_12] + "</RESERVE_C_12>");
        strOut.append(
                "<RESERVE_C_13>" + strValues[PAYDIV_RESERVE_C_13] + "</RESERVE_C_13>");
        strOut.append(
                "<RESERVE_C_14>" + strValues[PAYDIV_RESERVE_C_14] + "</RESERVE_C_14>");
        strOut.append(
                "<RESERVE_C_15>" + strValues[PAYDIV_RESERVE_C_15] + "</RESERVE_C_15>");
        strOut.append(
                "<RESERVE_C_16>" + strValues[PAYDIV_RESERVE_C_16] + "</RESERVE_C_16>");
        strOut.append(
                "<RESERVE_C_17>" + strValues[PAYDIV_RESERVE_C_17] + "</RESERVE_C_17>");
        strOut.append(
                "<RESERVE_C_18>" + strValues[PAYDIV_RESERVE_C_18] + "</RESERVE_C_18>");
        strOut.append(
                "<RESERVE_C_19>" + strValues[PAYDIV_RESERVE_C_19] + "</RESERVE_C_19>");
        strOut.append(
                "<RESERVE_C_20>" + strValues[PAYDIV_RESERVE_C_20] + "</RESERVE_C_20>");
        strOut.append(
                "<RESERVE_C_21>" + strValues[PAYDIV_RESERVE_C_21] + "</RESERVE_C_21>");
        strOut.append(
                "<RESERVE_C_22>" + strValues[PAYDIV_RESERVE_C_22] + "</RESERVE_C_22>");
        strOut.append(
                "<RESERVE_C_23>" + strValues[PAYDIV_RESERVE_C_23] + "</RESERVE_C_23>");
        strOut.append(
                "<RESERVE_C_24>" + strValues[PAYDIV_RESERVE_C_24] + "</RESERVE_C_24>");
        strOut.append(
                "<RESERVE_C_25>" + strValues[PAYDIV_RESERVE_C_25] + "</RESERVE_C_25>");
        strOut.append(
                "<RESERVE_C_26>" + strValues[PAYDIV_RESERVE_C_26] + "</RESERVE_C_26>");
        strOut.append(
                "<RESERVE_C_27>" + strValues[PAYDIV_RESERVE_C_27] + "</RESERVE_C_27>");
        strOut.append(
                "<RESERVE_C_28>" + strValues[PAYDIV_RESERVE_C_28] + "</RESERVE_C_28>");
        strOut.append(
                "<RESERVE_C_29>" + strValues[PAYDIV_RESERVE_C_29] + "</RESERVE_C_29>");
        strOut.append(
                "<RESERVE_C_30>" + strValues[PAYDIV_RESERVE_C_30] + "</RESERVE_C_30>");

        strOut.append(
                "<RESERVE_N_01>" + strValues[PAYDIV_RESERVE_N_01] + "</RESERVE_N_01>");
        strOut.append(
                "<RESERVE_N_02>" + strValues[PAYDIV_RESERVE_N_02] + "</RESERVE_N_02>");
        strOut.append(
                "<RESERVE_N_03>" + strValues[PAYDIV_RESERVE_N_03] + "</RESERVE_N_03>");
        strOut.append(
                "<RESERVE_N_04>" + strValues[PAYDIV_RESERVE_N_04] + "</RESERVE_N_04>");
        strOut.append(
                "<RESERVE_N_05>" + strValues[PAYDIV_RESERVE_N_05] + "</RESERVE_N_05>");
        strOut.append(
                "<RESERVE_N_06>" + strValues[PAYDIV_RESERVE_N_06] + "</RESERVE_N_06>");
        strOut.append(
                "<RESERVE_N_07>" + strValues[PAYDIV_RESERVE_N_07] + "</RESERVE_N_07>");
        strOut.append(
                "<RESERVE_N_08>" + strValues[PAYDIV_RESERVE_N_08] + "</RESERVE_N_08>");
        strOut.append(
                "<RESERVE_N_09>" + strValues[PAYDIV_RESERVE_N_09] + "</RESERVE_N_09>");
        strOut.append(
                "<RESERVE_N_10>" + strValues[PAYDIV_RESERVE_N_10] + "</RESERVE_N_10>");
        strOut.append(
                "<RESERVE_N_11>" + strValues[PAYDIV_RESERVE_N_11] + "</RESERVE_N_11>");
        strOut.append(
                "<RESERVE_N_12>" + strValues[PAYDIV_RESERVE_N_12] + "</RESERVE_N_12>");
        strOut.append(
                "<RESERVE_N_13>" + strValues[PAYDIV_RESERVE_N_13] + "</RESERVE_N_13>");
        strOut.append(
                "<RESERVE_N_14>" + strValues[PAYDIV_RESERVE_N_14] + "</RESERVE_N_14>");
        strOut.append(
                "<RESERVE_N_15>" + strValues[PAYDIV_RESERVE_N_15] + "</RESERVE_N_15>");
        strOut.append(
                "<RESERVE_N_16>" + strValues[PAYDIV_RESERVE_N_16] + "</RESERVE_N_16>");
        strOut.append(
                "<RESERVE_N_17>" + strValues[PAYDIV_RESERVE_N_17] + "</RESERVE_N_17>");
        strOut.append(
                "<RESERVE_N_18>" + strValues[PAYDIV_RESERVE_N_18] + "</RESERVE_N_18>");
        strOut.append(
                "<RESERVE_N_19>" + strValues[PAYDIV_RESERVE_N_19] + "</RESERVE_N_19>");
        strOut.append(
                "<RESERVE_N_20>" + strValues[PAYDIV_RESERVE_N_20] + "</RESERVE_N_20>");
        strOut.append(
                "<RESERVE_N_21>" + strValues[PAYDIV_RESERVE_N_21] + "</RESERVE_N_21>");
        strOut.append(
                "<RESERVE_N_22>" + strValues[PAYDIV_RESERVE_N_22] + "</RESERVE_N_22>");
        strOut.append(
                "<RESERVE_N_23>" + strValues[PAYDIV_RESERVE_N_23] + "</RESERVE_N_23>");
        strOut.append(
                "<RESERVE_N_24>" + strValues[PAYDIV_RESERVE_N_24] + "</RESERVE_N_24>");
        strOut.append(
                "<RESERVE_N_25>" + strValues[PAYDIV_RESERVE_N_25] + "</RESERVE_N_25>");
        strOut.append(
                "<RESERVE_N_26>" + strValues[PAYDIV_RESERVE_N_26] + "</RESERVE_N_26>");
        strOut.append(
                "<RESERVE_N_27>" + strValues[PAYDIV_RESERVE_N_27] + "</RESERVE_N_27>");
        strOut.append(
                "<RESERVE_N_28>" + strValues[PAYDIV_RESERVE_N_28] + "</RESERVE_N_28>");
        strOut.append(
                "<RESERVE_N_29>" + strValues[PAYDIV_RESERVE_N_29] + "</RESERVE_N_29>");
        strOut.append(
                "<RESERVE_N_30>" + strValues[PAYDIV_RESERVE_N_30] + "</RESERVE_N_30>");
        //20051207 zj e

        strOut.append("</ROW>");

        _strBuffer.insert(nOffset, strOut.toString());

        //refresh array
        /*
        String[][] strTempArr;
        if(_strLeaseResults == null) {
        _strLeaseResults = new String[1][PAYDIV_RECORD_COUNT];
        System.arraycopy(strValues, 0, _strLeaseResults[0], 0, PAYDIV_RECORD_COUNT);
        } else {
        strTempArr = new String[_strLeaseResults.length + 1][PAYDIV_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, strTempArr, 0, _strLeaseResults.length);
        System.arraycopy(strValues, 0, strTempArr[_strLeaseResults.length], 0, PAYDIV_RECORD_COUNT);
        _strLeaseResults = strTempArr;
        }
         */

        String strChangeTmp = strValues[PAYDIV_REC_NO];
        strValues[PAYDIV_REC_NO] = strValues[PAYDIV_BUKKEN_NO];
        strValues[PAYDIV_BUKKEN_NO] = strChangeTmp;

        //Attention:RecNo and BukkenNo had changed!!!
        //Because XML file's order had changed!!!

        _paydivXmlReader.insertRow(strValues);
        getQueryResults(strValues[PAYDIV_BUKKEN_NO]);
        return true;
    }

    //pzk add 20051109 s
    public boolean insertPreviousRecord(String[] strValues) {
        String strOff = _strPreviousBuffer.toString();
        int nOffset = strOff.lastIndexOf("</PAYDIV>");
        StringBuffer strOut = new StringBuffer();

        strOut.append("<ROW BUKKEN_NO=\"");
        strOut.append(strValues[PAYDIV_BUKKEN_NO]);
        strOut.append("\" REC_NO=\"");
        strOut.append(strValues[PAYDIV_REC_NO]);
        strOut.append("\" STAIR=\"");
        strOut.append(strValues[PAYDIV_STAIR]);
        strOut.append("\">");
        strOut.append("<BUKKEN_FR>" + strValues[PAYDIV_BUKKEN_FR] + "</BUKKEN_FR>");
        strOut.append("<BUKKEN_TO>" + strValues[PAYDIV_BUKKEN_TO] + "</BUKKEN_TO>");

        //20060614 ws change start
//        strOut.append("<PURCHASE>" + new Long(strValues[PAYDIV_PURCHASE]) + "</PURCHASE>");
        strOut.append("<PURCHASE>" + spaceTo0(strValues[PAYDIV_PURCHASE]) + "</PURCHASE>");
        //20060614 ws change end

        strOut.append("<DATE_YY>" + strValues[PAYDIV_DATE_YY] + "</DATE_YY>");
        strOut.append("<DATE_MM>" + strValues[PAYDIV_DATE_MM] + "</DATE_MM>");
        strOut.append("<DATE_DD >" + strValues[PAYDIV_DATE_DD] + "</DATE_DD >");

        //20051207 zj s
        strOut.append(
                "<RESERVE_C_01>" + strValues[PAYDIV_RESERVE_C_01] + "</RESERVE_C_01>");
        strOut.append(
                "<RESERVE_C_02>" + strValues[PAYDIV_RESERVE_C_02] + "</RESERVE_C_02>");
        strOut.append(
                "<RESERVE_C_03>" + strValues[PAYDIV_RESERVE_C_03] + "</RESERVE_C_03>");
        strOut.append(
                "<RESERVE_C_04>" + strValues[PAYDIV_RESERVE_C_04] + "</RESERVE_C_04>");
        strOut.append(
                "<RESERVE_C_05>" + strValues[PAYDIV_RESERVE_C_05] + "</RESERVE_C_05>");
        strOut.append(
                "<RESERVE_C_06>" + strValues[PAYDIV_RESERVE_C_06] + "</RESERVE_C_06>");
        strOut.append(
                "<RESERVE_C_07>" + strValues[PAYDIV_RESERVE_C_07] + "</RESERVE_C_07>");
        strOut.append(
                "<RESERVE_C_08>" + strValues[PAYDIV_RESERVE_C_08] + "</RESERVE_C_08>");
        strOut.append(
                "<RESERVE_C_09>" + strValues[PAYDIV_RESERVE_C_09] + "</RESERVE_C_09>");
        strOut.append(
                "<RESERVE_C_10>" + strValues[PAYDIV_RESERVE_C_10] + "</RESERVE_C_10>");
        strOut.append(
                "<RESERVE_C_11>" + strValues[PAYDIV_RESERVE_C_11] + "</RESERVE_C_11>");
        strOut.append(
                "<RESERVE_C_12>" + strValues[PAYDIV_RESERVE_C_12] + "</RESERVE_C_12>");
        strOut.append(
                "<RESERVE_C_13>" + strValues[PAYDIV_RESERVE_C_13] + "</RESERVE_C_13>");
        strOut.append(
                "<RESERVE_C_14>" + strValues[PAYDIV_RESERVE_C_14] + "</RESERVE_C_14>");
        strOut.append(
                "<RESERVE_C_15>" + strValues[PAYDIV_RESERVE_C_15] + "</RESERVE_C_15>");
        strOut.append(
                "<RESERVE_C_16>" + strValues[PAYDIV_RESERVE_C_16] + "</RESERVE_C_16>");
        strOut.append(
                "<RESERVE_C_17>" + strValues[PAYDIV_RESERVE_C_17] + "</RESERVE_C_17>");
        strOut.append(
                "<RESERVE_C_18>" + strValues[PAYDIV_RESERVE_C_18] + "</RESERVE_C_18>");
        strOut.append(
                "<RESERVE_C_19>" + strValues[PAYDIV_RESERVE_C_19] + "</RESERVE_C_19>");
        strOut.append(
                "<RESERVE_C_20>" + strValues[PAYDIV_RESERVE_C_20] + "</RESERVE_C_20>");
        strOut.append(
                "<RESERVE_C_21>" + strValues[PAYDIV_RESERVE_C_21] + "</RESERVE_C_21>");
        strOut.append(
                "<RESERVE_C_22>" + strValues[PAYDIV_RESERVE_C_22] + "</RESERVE_C_22>");
        strOut.append(
                "<RESERVE_C_23>" + strValues[PAYDIV_RESERVE_C_23] + "</RESERVE_C_23>");
        strOut.append(
                "<RESERVE_C_24>" + strValues[PAYDIV_RESERVE_C_24] + "</RESERVE_C_24>");
        strOut.append(
                "<RESERVE_C_25>" + strValues[PAYDIV_RESERVE_C_25] + "</RESERVE_C_25>");
        strOut.append(
                "<RESERVE_C_26>" + strValues[PAYDIV_RESERVE_C_26] + "</RESERVE_C_26>");
        strOut.append(
                "<RESERVE_C_27>" + strValues[PAYDIV_RESERVE_C_27] + "</RESERVE_C_27>");
        strOut.append(
                "<RESERVE_C_28>" + strValues[PAYDIV_RESERVE_C_28] + "</RESERVE_C_28>");
        strOut.append(
                "<RESERVE_C_29>" + strValues[PAYDIV_RESERVE_C_29] + "</RESERVE_C_29>");
        strOut.append(
                "<RESERVE_C_30>" + strValues[PAYDIV_RESERVE_C_30] + "</RESERVE_C_30>");

        strOut.append(
                "<RESERVE_N_01>" + strValues[PAYDIV_RESERVE_N_01] + "</RESERVE_N_01>");
        strOut.append(
                "<RESERVE_N_02>" + strValues[PAYDIV_RESERVE_N_02] + "</RESERVE_N_02>");
        strOut.append(
                "<RESERVE_N_03>" + strValues[PAYDIV_RESERVE_N_03] + "</RESERVE_N_03>");
        strOut.append(
                "<RESERVE_N_04>" + strValues[PAYDIV_RESERVE_N_04] + "</RESERVE_N_04>");
        strOut.append(
                "<RESERVE_N_05>" + strValues[PAYDIV_RESERVE_N_05] + "</RESERVE_N_05>");
        strOut.append(
                "<RESERVE_N_06>" + strValues[PAYDIV_RESERVE_N_06] + "</RESERVE_N_06>");
        strOut.append(
                "<RESERVE_N_07>" + strValues[PAYDIV_RESERVE_N_07] + "</RESERVE_N_07>");
        strOut.append(
                "<RESERVE_N_08>" + strValues[PAYDIV_RESERVE_N_08] + "</RESERVE_N_08>");
        strOut.append(
                "<RESERVE_N_09>" + strValues[PAYDIV_RESERVE_N_09] + "</RESERVE_N_09>");
        strOut.append(
                "<RESERVE_N_10>" + strValues[PAYDIV_RESERVE_N_10] + "</RESERVE_N_10>");
        strOut.append(
                "<RESERVE_N_11>" + strValues[PAYDIV_RESERVE_N_11] + "</RESERVE_N_11>");
        strOut.append(
                "<RESERVE_N_12>" + strValues[PAYDIV_RESERVE_N_12] + "</RESERVE_N_12>");
        strOut.append(
                "<RESERVE_N_13>" + strValues[PAYDIV_RESERVE_N_13] + "</RESERVE_N_13>");
        strOut.append(
                "<RESERVE_N_14>" + strValues[PAYDIV_RESERVE_N_14] + "</RESERVE_N_14>");
        strOut.append(
                "<RESERVE_N_15>" + strValues[PAYDIV_RESERVE_N_15] + "</RESERVE_N_15>");
        strOut.append(
                "<RESERVE_N_16>" + strValues[PAYDIV_RESERVE_N_16] + "</RESERVE_N_16>");
        strOut.append(
                "<RESERVE_N_17>" + strValues[PAYDIV_RESERVE_N_17] + "</RESERVE_N_17>");
        strOut.append(
                "<RESERVE_N_18>" + strValues[PAYDIV_RESERVE_N_18] + "</RESERVE_N_18>");
        strOut.append(
                "<RESERVE_N_19>" + strValues[PAYDIV_RESERVE_N_19] + "</RESERVE_N_19>");
        strOut.append(
                "<RESERVE_N_20>" + strValues[PAYDIV_RESERVE_N_20] + "</RESERVE_N_20>");
        strOut.append(
                "<RESERVE_N_21>" + strValues[PAYDIV_RESERVE_N_21] + "</RESERVE_N_21>");
        strOut.append(
                "<RESERVE_N_22>" + strValues[PAYDIV_RESERVE_N_22] + "</RESERVE_N_22>");
        strOut.append(
                "<RESERVE_N_23>" + strValues[PAYDIV_RESERVE_N_23] + "</RESERVE_N_23>");
        strOut.append(
                "<RESERVE_N_24>" + strValues[PAYDIV_RESERVE_N_24] + "</RESERVE_N_24>");
        strOut.append(
                "<RESERVE_N_25>" + strValues[PAYDIV_RESERVE_N_25] + "</RESERVE_N_25>");
        strOut.append(
                "<RESERVE_N_26>" + strValues[PAYDIV_RESERVE_N_26] + "</RESERVE_N_26>");
        strOut.append(
                "<RESERVE_N_27>" + strValues[PAYDIV_RESERVE_N_27] + "</RESERVE_N_27>");
        strOut.append(
                "<RESERVE_N_28>" + strValues[PAYDIV_RESERVE_N_28] + "</RESERVE_N_28>");
        strOut.append(
                "<RESERVE_N_29>" + strValues[PAYDIV_RESERVE_N_29] + "</RESERVE_N_29>");
        strOut.append(
                "<RESERVE_N_30>" + strValues[PAYDIV_RESERVE_N_30] + "</RESERVE_N_30>");
        //20051207 zj e

        strOut.append("</ROW>");

        _strPreviousBuffer.insert(nOffset, strOut.toString());


        String strChangeTmp = strValues[PAYDIV_REC_NO];
        strValues[PAYDIV_REC_NO] = strValues[PAYDIV_BUKKEN_NO];
        strValues[PAYDIV_BUKKEN_NO] = strChangeTmp;

        //Attention:RecNo and BukkenNo had changed!!!
        //Because XML file's order had changed!!!

        _previousPaydivXmlReader.insertRow(strValues);
        getPreviousQueryResults(strValues[PAYDIV_BUKKEN_NO]);
        return true;
    }
    //pzk add 20051109 e

    /**
     * XPATH文により複数のレコードを削除するメソッド．    <BR>
     *
     * <PRE>
     *  １．XPATH文によりID結果集を取得する。
     *  ２．ID結果集により対応するINDEX配列を取得する。
     *  ３．INDEX配列により、対応のレコードを削除する。
     * </PRE>
     *
     * @param   strSql            XPATH文
     * @return  boolean   true ： 複数のレコードは削除成功
     *                    false： 複数のレコードは削除失敗
     * @see     #getIDs(String)
     * @see     #getIDsIndexArray(Vector)
     * @since   01-01
     */
    public boolean removeRecords(String strFrom, String strTo) {
//        try {
        if (isResultsNull()) {
            return true;
        }
        int nFrom = LfcFrmComm.toInt(strFrom);
        int nTo = LfcFrmComm.toInt(strTo);
        int nIndexCnt = 0;
        for (int i = 0; i < _strLeaseResults.length; i++) {
            if (LfcFrmComm.toInt(_strLeaseResults[i][PAYDIV_BUKKEN_NO]) >= nFrom && LfcFrmComm.toInt(_strLeaseResults[i][PAYDIV_BUKKEN_NO]) <= nTo) {
                nIndexCnt++;
            }
        }
        String[] strRemoveBukkenNos = new String[nIndexCnt];
        for (int i = 0, j = 0; i < _strLeaseResults.length; i++) {
            if (LfcFrmComm.toInt(_strLeaseResults[i][PAYDIV_BUKKEN_NO]) >= nFrom && LfcFrmComm.toInt(_strLeaseResults[i][PAYDIV_BUKKEN_NO]) <= nTo) {
                strRemoveBukkenNos[j] = _strLeaseResults[i][PAYDIV_BUKKEN_NO];
                j++;
            }
        }

        //remove row & refresh array
        for (int i = 0; i < strRemoveBukkenNos.length; i++) {
            removeRecord(strRemoveBukkenNos[i]);
        }
        return true;
        /*
        } catch (Exception e) {
        _strErrorMessage = LfcDBMsgConst.ERA000;
        LfcSystemLog.writeLog("PaydivBean",                                    //クラス名
        "removeRecords(String strSql)",                  //メソッド名
        LfcDBMsgConst.ERA014,                             //ロジックメッセージ
        e);                                   //システムエラーメッセージ
        return false;
        }
         */
    }

    public boolean removeRecord(String strBukkenNo) {
        int nRemoveCnt = 0;
        String strDelete = _strBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            int nPos6 = strDelete.indexOf("BUKKEN_NO", nPos1);
            int nPos7 = strDelete.indexOf("\"", nPos6);
            int nPos8 = strDelete.indexOf("\"", nPos7 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2 ||
                    nPos6 > nPos2 || nPos7 > nPos2 || nPos8 > nPos2) {
                break;
            }
            String strKeyRecNoValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            String strKeyBukkenNoValue = strDelete.substring(nPos7 + 1, nPos8).trim();
            if (strBukkenNo.equals(strKeyBukkenNoValue) && strKeyRecNoValue.equals(_strCurRecNo)) {
                int nPos9 = strDelete.indexOf("</ROW>", nPos1);
                nRemoveCnt++;
                _strBuffer.delete(nPos1, nPos9 + 6);
            }
            i = nPos1;
        }
        //refresh array

        /*
        String[][] strTmp = new String[_strLeaseResults.length - nRemoveCnt][PAYDIV_RECORD_COUNT];
        for(int i = 0, j = 0; i < _strLeaseResults.length; i++) {
        if(strBukkenNo.equals(_strLeaseResults[i][PAYDIV_BUKKEN_NO])) {
        continue;
        }
        System.arraycopy(_strLeaseResults[i], 0, strTmp[j++], 0, PAYDIV_RECORD_COUNT);
        }
        _strLeaseResults = strTmp;
         */
        if (_strLeaseResults != null && _strLeaseResults.length > 0) {
            for (int i = _paydivXmlReader.getRowCount() - 1; i >= 0; i--) {
                if (_strCurRecNo.equals(_paydivXmlReader.getData(i, "REC_NO")) &&
                        strBukkenNo.equals(_paydivXmlReader.getData(i, "BUKKEN_NO"))) {
                    _paydivXmlReader.removeRow(i);
                }
            }
            getQueryResults(_strCurRecNo);
        } else {
            _strLeaseResults = null;
        }
        return true;
    }

    public boolean removeRecord(String strBukkenNo, String strStair) {
        String strDelete = _strBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            int nPos6 = strDelete.indexOf("BUKKEN_NO", nPos1);
            int nPos7 = strDelete.indexOf("\"", nPos6);
            int nPos8 = strDelete.indexOf("\"", nPos7 + 1);
            int nPos9 = strDelete.indexOf("STAIR", nPos1);
            int nPos10 = strDelete.indexOf("\"", nPos6);
            int nPos11 = strDelete.indexOf("\"", nPos7 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2 ||
                    nPos6 > nPos2 || nPos7 > nPos2 || nPos8 > nPos2 ||
                    nPos9 > nPos2 || nPos10 > nPos2 || nPos11 > nPos2) {
                break;
            }
            String strKeyRecNoValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            String strKeyBukkenNoValue = strDelete.substring(nPos7 + 1, nPos8).trim();
            String strKeyStairValue = strDelete.substring(nPos10 + 1, nPos11).trim();
            if (strBukkenNo.equals(strKeyBukkenNoValue) && strKeyRecNoValue.equals(_strCurRecNo) && strKeyStairValue.equals(strStair)) {
                int nPos12 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos12 + 6);
                break;
            }
            i = nPos1;
        }
        //refresh array

        /*
        String[][] strTmp = new String[_strLeaseResults.length - nRemoveCnt][PAYDIV_RECORD_COUNT];
        for(int i = 0, j = 0; i < _strLeaseResults.length; i++) {
        if(strBukkenNo.equals(_strLeaseResults[i][PAYDIV_BUKKEN_NO])) {
        continue;
        }
        System.arraycopy(_strLeaseResults[i], 0, strTmp[j++], 0, PAYDIV_RECORD_COUNT);
        }
        _strLeaseResults = strTmp;
         */
        if (_strLeaseResults != null && _strLeaseResults.length > 0) {
            for (int i = _paydivXmlReader.getRowCount() - 1; i >= 0; i--) {
                if (_strCurRecNo.equals(_paydivXmlReader.getData(i, "REC_NO")) &&
                        strBukkenNo.equals(_paydivXmlReader.getData(i, "BUKKEN_NO")) &&
                        strStair.equals(_paydivXmlReader.getData(i, "STAIR"))) {
                    _paydivXmlReader.removeRow(i);
                }
            }
            getQueryResults(_strCurRecNo);
        } else {
            _strLeaseResults = null;
        }
        return true;
    }

    /**
     * XPATH文により複数のレコードを削除するメソッド．    <BR>
     *
     * <PRE>
     *  １．XPATH文によりID結果集を取得する。
     *  ２．ID結果集により対応するINDEX配列を取得する。
     *  ３．INDEX配列により、対応のレコードを削除する。
     * </PRE>
     *
     * @param   strEstNo            EstNo
     * @return  boolean   true ： 複数のレコードは削除成功
     *                    false： 複数のレコードは削除失敗
     * @see     #getIDs(String)
     * @see     #getIDsIndexArray(Vector)
     * @since   01-01
     */
    public boolean removeRecords(String strRecNo) {
        String strDelete = _strBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2) {
                break;
            }
            String strKeyValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            if (strRecNo.equals(strKeyValue)) {
                int nPos6 = strDelete.indexOf("</ROW>", nPos1);
                _strBuffer.delete(nPos1, nPos6 + 6);
            }
            i = nPos1;
        }
        for (int i = _paydivXmlReader.getRowCount() - 1; i >= 0; i--) {
            if (strRecNo.equals(_paydivXmlReader.getData(i, "REC_NO"))) {
                _paydivXmlReader.removeRow(i);
            }
        }
        _strLeaseResults = null;
        return true;
    }

    //pzk add 20051109 s
    public boolean removePreviousRecords(String strRecNo) {
        String strDelete = _strPreviousBuffer.toString();
        for (int i = strDelete.length(); i > 0; i--) {
            int nPos1 = strDelete.lastIndexOf("<ROW", i);
            int nPos2 = strDelete.indexOf(">", nPos1);
            int nPos3 = strDelete.indexOf("REC_NO", nPos1);
            int nPos4 = strDelete.indexOf("\"", nPos3);
            int nPos5 = strDelete.indexOf("\"", nPos4 + 1);
            if (nPos3 > nPos2 || nPos4 > nPos2 || nPos5 > nPos2) {
                break;
            }
            String strKeyValue = strDelete.substring(nPos4 + 1, nPos5).trim();
            if (strRecNo.equals(strKeyValue)) {
                int nPos6 = strDelete.indexOf("</ROW>", nPos1);
                _strPreviousBuffer.delete(nPos1, nPos6 + 6);
            }
            i = nPos1;
        }
        for (int i = _previousPaydivXmlReader.getRowCount() - 1; i >= 0; i--) {
            if (strRecNo.equals(_previousPaydivXmlReader.getData(i, "REC_NO"))) {
                _previousPaydivXmlReader.removeRow(i);
            }
        }
        _strPreviousResults = null;
        return true;
    }
    //pzk add 20051109 e

    /**
     * 結果集がNULLかどうかを判断するメソッド。
     * @param   無し。
     * @return  無し。
     */
    public  boolean isResultsNull() {
        if (_strLeaseResults == null || _strLeaseResults.length == 0) {
            return true;
        } else {
            return false;
        }
    }

    public String[][] getCopyRec(String strRecNo, String strBukenNo) {
        String[][] strEstResults = getQueryResultsForEstCopy(strRecNo);
        int nCnt = 0;
        for (int i = 0; i < strEstResults.length; i++) {
            if (strBukenNo.equals(strEstResults[i][PAYDIV_BUKKEN_NO])) {
                nCnt = nCnt + 1;
            }
        }
        if (nCnt == 0) {
            return new String[0][0];
        }
        String[][] strReturnArr = new String[nCnt][PAYDIV_RECORD_COUNT];
        nCnt = 0;
        for (int i = 0; i < strEstResults.length; i++) {
            if (strBukenNo.equals(strEstResults[i][EPAYDIV_BUKKEN_NO])) {
                strReturnArr[nCnt] = strEstResults[i];
                nCnt = nCnt + 1;
            }
        }
        return strReturnArr;
    }

    public void doCommit() {
        try {
            FileWriter fw = new FileWriter(_strXmlFilePath);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(_strBuffer.toString());
            pw.close();
        } catch (IOException e) {
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("PaydivBean.doCommit()", //クラス名
                    _strBuffer.toString(), //メソッド名
                    _strXmlFilePath + "へ書き出すときエラー", //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
        }
    }
    //pzk add 20051109 s

    public void doPreviousCommit() {
        try {
            FileWriter fw = new FileWriter(_strPreviousXmlFilePath);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(_strPreviousBuffer.toString());
            pw.close();
        } catch (IOException e) {
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("PaydivBean.doPreviousCommit()", //クラス名
                    _strPreviousBuffer.toString(), //メソッド名
                    _strPreviousXmlFilePath + "へ書き出すときエラー", //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
        }
    }
    //pzk add 20051109 e

    public boolean copyRecords(String[][] strCopys) {
        if (isResultsNull()) {
            return true;
        }
        int nUpdateIndex = 0;
        String[][] strTmpArr = new String[_strLeaseResults.length + strCopys.length][PAYDIV_RECORD_COUNT];
        System.arraycopy(_strLeaseResults, 0, strTmpArr, 0, _strLeaseResults.length);
        for (int i = 0; i < strCopys.length; i++) {
            for (int j = 0; j < _strLeaseResults.length; j++) {
                if (strCopys[i][PAYDIV_BUKKEN_NO].equals(_strLeaseResults[j][PAYDIV_BUKKEN_NO]) && strCopys[i][PAYDIV_STAIR].equals(_strLeaseResults[j][PAYDIV_STAIR])) {
                    nUpdateIndex = j;
                    break;
                }
            }
//            String[] strInsertRecord = new String[_strLeaseResults[nUpdateIndex].length];
            String[] strInsertRecord = new String[PAYDIV_RECORD_COUNT];
            for (int k = 0; k < _strLeaseResults[nUpdateIndex].length; k++) {
                strInsertRecord[k] = _strLeaseResults[nUpdateIndex][k];
            }
            strInsertRecord[PAYDIV_BUKKEN_NO] = strCopys[i][3];
            strInsertRecord[PAYDIV_BUKKEN_FR] = strCopys[i][3];
            strInsertRecord[PAYDIV_BUKKEN_TO] = strCopys[i][4];
            insertRecord(strInsertRecord);

            /*
            System.arraycopy(strTmpArr[nUpdateIndex], 0, strTmpArr[_strLeaseResults.length + i], 0, strTmpArr[nUpdateIndex].length);
            strTmpArr[_strLeaseResults.length + i][PAYDIV_BUKKEN_NO] = strCopys[i][3];
            strTmpArr[_strLeaseResults.length + i][PAYDIV_STAIR] = strCopys[i][2];
            strTmpArr[_strLeaseResults.length + i][PAYDIV_BUKKEN_FR] = strCopys[i][3];
            strTmpArr[_strLeaseResults.length + i][PAYDIV_BUKKEN_TO] = strCopys[i][4];
             */
            //refresh array
            String strChangeTmp = strInsertRecord[PAYDIV_REC_NO];
            strInsertRecord[PAYDIV_REC_NO] = strInsertRecord[PAYDIV_BUKKEN_NO];
            strInsertRecord[PAYDIV_BUKKEN_NO] = strChangeTmp;
            //Attention:RecNo and BukkenNo had changed!!!
            //Because XML file's order had changed!!!

            _paydivXmlReader.insertRow(strInsertRecord);
            getQueryResults(strInsertRecord[PAYDIV_REC_NO]);

        }
        _strLeaseResults = strTmpArr;
        return true;
    }

    public boolean CreateXml() {
        _strBuffer.append(
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
        _strBuffer.append(
                "<PAYDIV xmlns=\"http://www.gecl.co.jp/PAYDIV\">");
        _strBuffer.append("</PAYDIV>");
        doCommit();
        return true;
    }

    //pzk add 20051109 s
    public boolean createPreviousXml() {
        //ydy add 20080414 s
        _strPreviousBuffer = new StringBuffer();
        //ydy add 20080414 e
        _strPreviousBuffer.append(
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
        _strPreviousBuffer.append(
                "<PAYDIV xmlns=\"http://www.gecl.co.jp/PAYDIV\">");
        _strPreviousBuffer.append("</PAYDIV>");
        doPreviousCommit();
        return true;
    }
    //pzk add 20051109 e

    public void CreatePDFXml() {
        String[][] strValues = _strLeaseResults;
        StringBuffer strOut = new StringBuffer();
        strOut.append(
                "<?xml version=\"1.0\" encoding=\"Shift_JIS\" standalone=\"no\"?>");
        strOut.append("<PAYDIV xmlns=\"http://www.gecl.co.jp/PAYDIV\">");
        for (int i = 0; i < strValues.length; i++) {
            strOut.append("<ROW BUKKEN_NO=\"");
            strOut.append(strValues[i][PAYDIV_BUKKEN_NO]);
            strOut.append("\" REC_NO=\"");
            strOut.append(strValues[i][PAYDIV_REC_NO]);
            strOut.append("\" STAIR=\"");
            strOut.append(strValues[i][PAYDIV_STAIR]);
            strOut.append("\">");
            strOut.append("<BUKKEN_FR>" + strValues[i][PAYDIV_BUKKEN_FR] + "</BUKKEN_FR>");
            strOut.append("<BUKKEN_TO>" + strValues[i][PAYDIV_BUKKEN_TO] + "</BUKKEN_TO>");

            //20050912 ZJ start
            //20060614 ws change start
//			strOut.append("<PURCHASE>" + new Long(strValues[i][PAYDIV_PURCHASE]) + "</PURCHASE>");
            strOut.append("<PURCHASE>" + spaceTo0(strValues[i][PAYDIV_PURCHASE]) + "</PURCHASE>");
            //20060614 ws change end
            //20050912 ZJ end

            strOut.append("<DATE_YY>" + strValues[i][PAYDIV_DATE_YY] + "</DATE_YY>");
            strOut.append("<DATE_MM>" + strValues[i][PAYDIV_DATE_MM] + "</DATE_MM>");
            strOut.append("<DATE_DD >" + strValues[i][PAYDIV_DATE_DD] + "</DATE_DD >");

            //20051207 zj s
            strOut.append(
                    "<RESERVE_C_01>" + strValues[i][PAYDIV_RESERVE_C_01] + "</RESERVE_C_01>");
            strOut.append(
                    "<RESERVE_C_02>" + strValues[i][PAYDIV_RESERVE_C_02] + "</RESERVE_C_02>");
            strOut.append(
                    "<RESERVE_C_03>" + strValues[i][PAYDIV_RESERVE_C_03] + "</RESERVE_C_03>");
            strOut.append(
                    "<RESERVE_C_04>" + strValues[i][PAYDIV_RESERVE_C_04] + "</RESERVE_C_04>");
            strOut.append(
                    "<RESERVE_C_05>" + strValues[i][PAYDIV_RESERVE_C_05] + "</RESERVE_C_05>");
            strOut.append(
                    "<RESERVE_C_06>" + strValues[i][PAYDIV_RESERVE_C_06] + "</RESERVE_C_06>");
            strOut.append(
                    "<RESERVE_C_07>" + strValues[i][PAYDIV_RESERVE_C_07] + "</RESERVE_C_07>");
            strOut.append(
                    "<RESERVE_C_08>" + strValues[i][PAYDIV_RESERVE_C_08] + "</RESERVE_C_08>");
            strOut.append(
                    "<RESERVE_C_09>" + strValues[i][PAYDIV_RESERVE_C_09] + "</RESERVE_C_09>");
            strOut.append(
                    "<RESERVE_C_10>" + strValues[i][PAYDIV_RESERVE_C_10] + "</RESERVE_C_10>");
            strOut.append(
                    "<RESERVE_C_11>" + strValues[i][PAYDIV_RESERVE_C_11] + "</RESERVE_C_11>");
            strOut.append(
                    "<RESERVE_C_12>" + strValues[i][PAYDIV_RESERVE_C_12] + "</RESERVE_C_12>");
            strOut.append(
                    "<RESERVE_C_13>" + strValues[i][PAYDIV_RESERVE_C_13] + "</RESERVE_C_13>");
            strOut.append(
                    "<RESERVE_C_14>" + strValues[i][PAYDIV_RESERVE_C_14] + "</RESERVE_C_14>");
            strOut.append(
                    "<RESERVE_C_15>" + strValues[i][PAYDIV_RESERVE_C_15] + "</RESERVE_C_15>");
            strOut.append(
                    "<RESERVE_C_16>" + strValues[i][PAYDIV_RESERVE_C_16] + "</RESERVE_C_16>");
            strOut.append(
                    "<RESERVE_C_17>" + strValues[i][PAYDIV_RESERVE_C_17] + "</RESERVE_C_17>");
            strOut.append(
                    "<RESERVE_C_18>" + strValues[i][PAYDIV_RESERVE_C_18] + "</RESERVE_C_18>");
            strOut.append(
                    "<RESERVE_C_19>" + strValues[i][PAYDIV_RESERVE_C_19] + "</RESERVE_C_19>");
            strOut.append(
                    "<RESERVE_C_20>" + strValues[i][PAYDIV_RESERVE_C_20] + "</RESERVE_C_20>");
            strOut.append(
                    "<RESERVE_C_21>" + strValues[i][PAYDIV_RESERVE_C_21] + "</RESERVE_C_21>");
            strOut.append(
                    "<RESERVE_C_22>" + strValues[i][PAYDIV_RESERVE_C_22] + "</RESERVE_C_22>");
            strOut.append(
                    "<RESERVE_C_23>" + strValues[i][PAYDIV_RESERVE_C_23] + "</RESERVE_C_23>");
            strOut.append(
                    "<RESERVE_C_24>" + strValues[i][PAYDIV_RESERVE_C_24] + "</RESERVE_C_24>");
            strOut.append(
                    "<RESERVE_C_25>" + strValues[i][PAYDIV_RESERVE_C_25] + "</RESERVE_C_25>");
            strOut.append(
                    "<RESERVE_C_26>" + strValues[i][PAYDIV_RESERVE_C_26] + "</RESERVE_C_26>");
            strOut.append(
                    "<RESERVE_C_27>" + strValues[i][PAYDIV_RESERVE_C_27] + "</RESERVE_C_27>");
            strOut.append(
                    "<RESERVE_C_28>" + strValues[i][PAYDIV_RESERVE_C_28] + "</RESERVE_C_28>");
            strOut.append(
                    "<RESERVE_C_29>" + strValues[i][PAYDIV_RESERVE_C_29] + "</RESERVE_C_29>");
            strOut.append(
                    "<RESERVE_C_30>" + strValues[i][PAYDIV_RESERVE_C_30] + "</RESERVE_C_30>");

            strOut.append(
                    "<RESERVE_N_01>" + strValues[i][PAYDIV_RESERVE_N_01] + "</RESERVE_N_01>");
            strOut.append(
                    "<RESERVE_N_02>" + strValues[i][PAYDIV_RESERVE_N_02] + "</RESERVE_N_02>");
            strOut.append(
                    "<RESERVE_N_03>" + strValues[i][PAYDIV_RESERVE_N_03] + "</RESERVE_N_03>");
            strOut.append(
                    "<RESERVE_N_04>" + strValues[i][PAYDIV_RESERVE_N_04] + "</RESERVE_N_04>");
            strOut.append(
                    "<RESERVE_N_05>" + strValues[i][PAYDIV_RESERVE_N_05] + "</RESERVE_N_05>");
            strOut.append(
                    "<RESERVE_N_06>" + strValues[i][PAYDIV_RESERVE_N_06] + "</RESERVE_N_06>");
            strOut.append(
                    "<RESERVE_N_07>" + strValues[i][PAYDIV_RESERVE_N_07] + "</RESERVE_N_07>");
            strOut.append(
                    "<RESERVE_N_08>" + strValues[i][PAYDIV_RESERVE_N_08] + "</RESERVE_N_08>");
            strOut.append(
                    "<RESERVE_N_09>" + strValues[i][PAYDIV_RESERVE_N_09] + "</RESERVE_N_09>");
            strOut.append(
                    "<RESERVE_N_10>" + strValues[i][PAYDIV_RESERVE_N_10] + "</RESERVE_N_10>");
            strOut.append(
                    "<RESERVE_N_11>" + strValues[i][PAYDIV_RESERVE_N_11] + "</RESERVE_N_11>");
            strOut.append(
                    "<RESERVE_N_12>" + strValues[i][PAYDIV_RESERVE_N_12] + "</RESERVE_N_12>");
            strOut.append(
                    "<RESERVE_N_13>" + strValues[i][PAYDIV_RESERVE_N_13] + "</RESERVE_N_13>");
            strOut.append(
                    "<RESERVE_N_14>" + strValues[i][PAYDIV_RESERVE_N_14] + "</RESERVE_N_14>");
            strOut.append(
                    "<RESERVE_N_15>" + strValues[i][PAYDIV_RESERVE_N_15] + "</RESERVE_N_15>");
            strOut.append(
                    "<RESERVE_N_16>" + strValues[i][PAYDIV_RESERVE_N_16] + "</RESERVE_N_16>");
            strOut.append(
                    "<RESERVE_N_17>" + strValues[i][PAYDIV_RESERVE_N_17] + "</RESERVE_N_17>");
            strOut.append(
                    "<RESERVE_N_18>" + strValues[i][PAYDIV_RESERVE_N_18] + "</RESERVE_N_18>");
            strOut.append(
                    "<RESERVE_N_19>" + strValues[i][PAYDIV_RESERVE_N_19] + "</RESERVE_N_19>");
            strOut.append(
                    "<RESERVE_N_20>" + strValues[i][PAYDIV_RESERVE_N_20] + "</RESERVE_N_20>");
            strOut.append(
                    "<RESERVE_N_21>" + strValues[i][PAYDIV_RESERVE_N_21] + "</RESERVE_N_21>");
            strOut.append(
                    "<RESERVE_N_22>" + strValues[i][PAYDIV_RESERVE_N_22] + "</RESERVE_N_22>");
            strOut.append(
                    "<RESERVE_N_23>" + strValues[i][PAYDIV_RESERVE_N_23] + "</RESERVE_N_23>");
            strOut.append(
                    "<RESERVE_N_24>" + strValues[i][PAYDIV_RESERVE_N_24] + "</RESERVE_N_24>");
            strOut.append(
                    "<RESERVE_N_25>" + strValues[i][PAYDIV_RESERVE_N_25] + "</RESERVE_N_25>");
            strOut.append(
                    "<RESERVE_N_26>" + strValues[i][PAYDIV_RESERVE_N_26] + "</RESERVE_N_26>");
            strOut.append(
                    "<RESERVE_N_27>" + strValues[i][PAYDIV_RESERVE_N_27] + "</RESERVE_N_27>");
            strOut.append(
                    "<RESERVE_N_28>" + strValues[i][PAYDIV_RESERVE_N_28] + "</RESERVE_N_28>");
            strOut.append(
                    "<RESERVE_N_29>" + strValues[i][PAYDIV_RESERVE_N_29] + "</RESERVE_N_29>");
            strOut.append(
                    "<RESERVE_N_30>" + strValues[i][PAYDIV_RESERVE_N_30] + "</RESERVE_N_30>");
            //20051207 zj e

            strOut.append("</ROW>");
        }
        strOut.append("</PAYDIV>");
        try {
            FileWriter fw =
                    new FileWriter(LfcDBConfig.getXmlTempFolder() + "TPDFPAYDIV.xml");
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(strOut.toString());
            pw.close();
        } catch (IOException e) {
            LfcSystemLog sysLog=new LfcSystemLog();
            sysLog.writeLog("PaydivBean.CreatePDFXml()", //クラス名
                    strOut.toString(), //メソッド名
                    LfcDBConfig.getXmlTempFolder() + "TPDFPAYDIV.xmlへ書き出すときエラー", //ロジックメッセージ
                    e);                                           //システムエラーメッセージ
        }

        return;
    }

    public void setFieldName() {
        String[] tmpStrName = {
            "BUKKEN_NO",
            "REC_NO",
            "STAIR",
            "BUKKEN_FR",
            "BUKKEN_TO",
            "PURCHASE",
            "DATE_YY",
            "DATE_MM",
            "DATE_DD" //20051207 zj s
            , "RESERVE_C_01", "RESERVE_C_02", "RESERVE_C_03", "RESERVE_C_04", "RESERVE_C_05", "RESERVE_C_06", "RESERVE_C_07", "RESERVE_C_08", "RESERVE_C_09", "RESERVE_C_10", "RESERVE_C_11", "RESERVE_C_12", "RESERVE_C_13", "RESERVE_C_14", "RESERVE_C_15", "RESERVE_C_16", "RESERVE_C_17", "RESERVE_C_18", "RESERVE_C_19", "RESERVE_C_20", "RESERVE_C_21", "RESERVE_C_22", "RESERVE_C_23", "RESERVE_C_24", "RESERVE_C_25", "RESERVE_C_26", "RESERVE_C_27", "RESERVE_C_28", "RESERVE_C_29", "RESERVE_C_30", "RESERVE_N_01", "RESERVE_N_02", "RESERVE_N_03", "RESERVE_N_04", "RESERVE_N_05", "RESERVE_N_06", "RESERVE_N_07", "RESERVE_N_08", "RESERVE_N_09", "RESERVE_N_10", "RESERVE_N_11", "RESERVE_N_12", "RESERVE_N_13", "RESERVE_N_14", "RESERVE_N_15", "RESERVE_N_16", "RESERVE_N_17", "RESERVE_N_18", "RESERVE_N_19", "RESERVE_N_20", "RESERVE_N_21", "RESERVE_N_22", "RESERVE_N_23", "RESERVE_N_24", "RESERVE_N_25", "RESERVE_N_26", "RESERVE_N_27", "RESERVE_N_28", "RESERVE_N_29", "RESERVE_N_30"
        //20051207 zj e
        };
        _paydivXmlReader.setFieldName(tmpStrName);
    }

    //pzk add 20051109 s
    public void setPreviousFieldName() {
        String[] tmpStrName = {
            "BUKKEN_NO",
            "REC_NO",
            "STAIR",
            "BUKKEN_FR",
            "BUKKEN_TO",
            "PURCHASE",
            "DATE_YY",
            "DATE_MM",
            "DATE_DD" //20051207 zj s
            , "RESERVE_C_01", "RESERVE_C_02", "RESERVE_C_03", "RESERVE_C_04", "RESERVE_C_05", "RESERVE_C_06", "RESERVE_C_07", "RESERVE_C_08", "RESERVE_C_09", "RESERVE_C_10", "RESERVE_C_11", "RESERVE_C_12", "RESERVE_C_13", "RESERVE_C_14", "RESERVE_C_15", "RESERVE_C_16", "RESERVE_C_17", "RESERVE_C_18", "RESERVE_C_19", "RESERVE_C_20", "RESERVE_C_21", "RESERVE_C_22", "RESERVE_C_23", "RESERVE_C_24", "RESERVE_C_25", "RESERVE_C_26", "RESERVE_C_27", "RESERVE_C_28", "RESERVE_C_29", "RESERVE_C_30", "RESERVE_N_01", "RESERVE_N_02", "RESERVE_N_03", "RESERVE_N_04", "RESERVE_N_05", "RESERVE_N_06", "RESERVE_N_07", "RESERVE_N_08", "RESERVE_N_09", "RESERVE_N_10", "RESERVE_N_11", "RESERVE_N_12", "RESERVE_N_13", "RESERVE_N_14", "RESERVE_N_15", "RESERVE_N_16", "RESERVE_N_17", "RESERVE_N_18", "RESERVE_N_19", "RESERVE_N_20", "RESERVE_N_21", "RESERVE_N_22", "RESERVE_N_23", "RESERVE_N_24", "RESERVE_N_25", "RESERVE_N_26", "RESERVE_N_27", "RESERVE_N_28", "RESERVE_N_29", "RESERVE_N_30"
        //20051207 zj e
        };
        _previousPaydivXmlReader.setFieldName(tmpStrName);
    }
    //pzk add 20051109 e

    /**
     * String -> Long -> String メソッド．    <BR>
     *
     * @param   strValues  Stringタイプの値
     * @return  String     null,""の場合、""
     *                      その他の場合、String -> Long -> String
     */
    private String spaceTo0(String strValues) {
        if (strValues == null || "".equals(strValues.trim())) {
            return "";
        }
        return "" + new Long(strValues);
    }
}
