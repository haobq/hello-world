/*
 * @(#)LfcMessageBox.java      01-01  2003/06/13
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 * 修正日：20051024
 * 修正人：HBQ
 * 修正内容：Add log for WebService calculate
 */
package com.gecl.leaseCal.log;

public class LfcMessageBox extends Thread implements LfcFrmMsgConst {

    public  String[][] setErrMsg(
            String strMessage,
            String strTitle,
            String[][] errMsg) {
        int _nPreviousRecBukenCount=1;
        if (errMsg!=null){
            _nPreviousRecBukenCount=errMsg.length+1;
        }
        String[][] strRetResults = new String[_nPreviousRecBukenCount][2];
        for (int i = 0; i < strRetResults.length; i++) {
            System.arraycopy(errMsg[i], 0, strRetResults[i], 0, errMsg[i].length);
        }
        strRetResults[strRetResults.length][0]=strTitle;
        strRetResults[strRetResults.length][1]=strMessage;

        return strRetResults;
    }
}
