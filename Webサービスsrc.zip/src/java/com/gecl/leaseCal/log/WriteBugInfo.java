package com.gecl.leaseCal.log;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;


import com.gecl.leaseCal.db.comm.LfcDBConfig;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * Logファイル出力
 */
public class WriteBugInfo {

    private  String CTRL = "\n";
    private  String SPAC = " ";
    private  String UNIT_FLAG = "------------------------------------";
    private StringBuffer strBtnInfo = new StringBuffer();
    private  String BTN_INFO_LOG_FILE = "";
    private  DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd");
    private  DateFormat timeFormat1 = new SimpleDateFormat("HH:mm:ss");
    private  String strTestStartDate = "";
    // ydy add 20060731 start
    private  DateFormat dateFormat2 = new SimpleDateFormat("yyyyMMdd");
    private  DateFormat timeFormat2 = new SimpleDateFormat("hhmmss");
    // ydy add 20060731 end
    private  boolean bFirst = true;
    // ydy add 20060731 start
    private  int FIELNUM = 7;

    // ydy add 20060731 end
    public  void writeBtnInfoSeparator() {
        strBtnInfo.append(UNIT_FLAG).append(CTRL);
    }

    public  void WriteCntrctInfo(String strCntrct) {
        strBtnInfo.append(strCntrct).append(SPAC).append(CTRL);
    }


    public  void writeBtnInfo(String strBtnCaption) {
        java.util.Date date = new java.util.Date();
        String strDate = dateFormat1.format(date) + SPAC + timeFormat1.format(date);

        if (bFirst) {
            strBtnInfo.append(CTRL);
            strTestStartDate = strDate;
            bFirst = false;
        }
        // strBtnInfo.insert(0, strBtnCaption + CTRL);
        strBtnInfo.append(strBtnCaption).append(SPAC).append(strDate).append(
                CTRL);
    }

    // ydy add 20060724
    public  void filePross() {
        LfcDBConfig.getInstance();
        BTN_INFO_LOG_FILE = LfcDBConfig.getLogFolder() + "/workLog";
        try {
            File dir = new File(BTN_INFO_LOG_FILE);
            String dirs[] = dir.list();
            if (dirs.length > FIELNUM) {

                Arrays.sort(dirs);

                int intFileLength = dirs.length;
                for (int i = 0; i < intFileLength - FIELNUM; i++) {
                    File d = new File(dir, dirs[i]);
                    if (d.isDirectory()) {
                        String strPath = BTN_INFO_LOG_FILE + "/" + dirs[i];
                        File fNewFile = new File(strPath);
                        String files[] = fNewFile.list();
                        for (int j = 0; j < files.length; j++) {
                            File f = new File(fNewFile, files[j]);
                            f.delete();
                        }
                    }
                    d.delete();

                }

            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    // ydy add 20060724...
    public  void writeSystemLog(
            String strClassName,
            String strMethodName,
            String strLogicMessage,
            Exception e) {
        // ydy add 20060731 start
        java.util.Date date = new java.util.Date();
        String strDate = dateFormat2.format(date);
        /**format for getting time in hh:ss:mm format*/
        DateFormat exceptionDate = new SimpleDateFormat("yyyyyMMdd");
        //zj 20051024 s
        DateFormat exceptionTime = new SimpleDateFormat("HHmmssSSS");
        // String strDateDir = dateFormat2.format(date) +
        // timeFormat2.format(date);
        try {
            LfcDBConfig.getInstance();
            BTN_INFO_LOG_FILE = LfcDBConfig.getLogFolder() + "/workLog";
            String strDateLog = dateFormat2.format(date) + "_" + timeFormat2.format(date);
            File dirWorkLog = new File(BTN_INFO_LOG_FILE);
            if (!dirWorkLog.exists()) {
                dirWorkLog.mkdir();
            }

            String dirFilePath = BTN_INFO_LOG_FILE + "/" + strDate;
            File dirFile = new File(dirFilePath);

            if (!dirFile.exists()) {
                dirFile.mkdir();
            }
            filePross();

            String strTestEndDate = dateFormat1.format(date) + SPAC + timeFormat1.format(date);
            String strLogName = dirFilePath + "/" + strDateLog + ".log";
            // ydy add 20060731 end


            // ファイルを開く
            FileOutputStream fw = new FileOutputStream(strLogName);
            //入力ストリームを取得
            BufferedOutputStream bw = new BufferedOutputStream(fw);
            PrintWriter pw = new PrintWriter(bw);
            FileInputStream in = new FileInputStream(strLogName);

            //ＵＲＬの取得
            InputStreamReader isr = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(isr);
            String line;
            while ((line = reader.readLine()) != null) {
                pw.println(line);	//txtに書き込み
            }
            in.close();
            pw.println(exceptionTime.format(date) + "のシステムの異常エラーメッセージ：");
            pw.println("-----------------------------------------------------------------");
            pw.println("クラス名：" + strClassName);
            pw.println("メソッド名：" + strMethodName);
            pw.println("詳細：" + strLogicMessage);
            pw.println(e.toString());
            for (int i = 0; i < e.getStackTrace().length; i++) {
                pw.println("    at " + e.getStackTrace()[i].toString());
            }
            pw.println("以上 確認下さい");
            pw.println("-----------------------------------------------------------------");
            pw.close();
        } catch (Exception ie) {
            System.out.println(ie);
        }
    }
}
