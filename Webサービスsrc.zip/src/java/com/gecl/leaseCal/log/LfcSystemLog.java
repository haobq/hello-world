/*
 * @(#)LfcSystemLog.java      01-01  2003/06/13
 *
 * Copyright 2003 by GECL、 Ltd、 All rights reserved
 *
 * 修正日：20051014
 * 修正人：曾健
 * 修正内容：Change subout log's name form yyyyyMMdd -> yyyyyMMdd:mm:ss:SSS
 *
 * 修正日：20051024
 * 修正人：曾健
 * 修正内容：Change subout log's name form yyyyyMMdd:mm:ss:SSS -> yyyyyMMddHHmmssSSS
 *
 * 修正日：20051025
 * 修正人：曾健
 * 修正内容：ログを続きないバグを修正しました
 */
package com.gecl.leaseCal.log;

import com.gecl.leaseCal.db.comm.LfcDBConfig;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class LfcSystemLog {

    /**format for getting time in hh:ss:mm format*/
    private  DateFormat exceptionDate = new SimpleDateFormat("yyyyyMMdd");
    //zj 20051024 s
    private  DateFormat exceptionTime = new SimpleDateFormat("HHmmssSSS");
    //zj 20051024 e
    /**現在の時点(日期と時間)*/
    private  java.util.Date date = new java.util.Date();

    public  void writeLog(
            String strClassName,
            String strMethodName,
            String strLogicMessage,
            Exception e) {
        //LfcDBConfig lfcDBConfig = new LfcDBConfig();
        LfcDBConfig.getInstance();
        String strFileName = LfcDBConfig.getLogFolder();
        strFileName = strFileName + exceptionDate.format(date)+exceptionTime.format(date) + ".log";
        try {
            //ファイルを開く
            FileOutputStream fw = new FileOutputStream(strFileName);
            FileInputStream in = new FileInputStream(strFileName);

            //ＵＲＬの取得
            InputStreamReader isr = new InputStreamReader(in);
            //入力ストリームを取得
            BufferedOutputStream bw = new BufferedOutputStream(fw);
            BufferedReader reader = new BufferedReader(isr);
            String line;
            PrintWriter pw = new PrintWriter(bw);
            while ((line = reader.readLine()) != null) {
                pw.println(line);	//txtに書き込み
            }
            in.close();
            pw.println(exceptionTime.format(date) + "のシステムの異常エラーメッセージ：");
            pw.println("-----------------------------------------------------------------");
            pw.println("クラス名：" + strClassName);
            pw.println("メソッド名：" + strMethodName);
            pw.println("詳細：" + strLogicMessage);
            pw.println(e.toString());
            for (int i = 0; i < e.getStackTrace().length; i++) {
                pw.println("    at " + e.getStackTrace()[i].toString());
            }
            pw.println("以上 確認下さい");
            pw.println("-----------------------------------------------------------------");
            //ファイルクローズ
            pw.close();
        } catch (IOException ie) {
            //e.printStackTrace();
        }
    }

    public  void writeSubOutLog(String strLogicMessage) {

        //zj 20051025 s
        java.util.Date subDate = new java.util.Date();

        //zj 20051014 s
        //LfcDBConfig lfcDBConfig = new LfcDBConfig();
        LfcDBConfig.getInstance();
        String strFileName = LfcDBConfig.getLogFolder();
        strFileName = strFileName + "SubOut" + exceptionDate.format(subDate) + exceptionTime.format(subDate) + ".log";
        //zj 20051014 e
        //zj 20051025 e

        try {
            //ファイルを開く
            FileOutputStream fw = new FileOutputStream(strFileName);
            FileInputStream in = new FileInputStream(strFileName);

            //INPutの取得
            InputStreamReader isr = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(isr);
            String line;
            //入力ストリームを取得
            BufferedOutputStream bw = new BufferedOutputStream(fw);
            PrintWriter pw = new PrintWriter(bw);
            while ((line = reader.readLine()) != null) {
                pw.println(line);	//txtに書き込み
            }
            in.close();
            pw.println(exceptionTime.format(date) + "のサブアウト計算のエラーメッセージ：");
            pw.println("-----------------------------------------------------------------");
            pw.println("メッセージ：" + strLogicMessage);
            pw.println("-----------------------------------------------------------------");
            pw.println("以上 確認下さい");
            //ファイルクローズ
            pw.close();
        } catch (IOException ie) {
            //e.printStackTrace();
        }
    }
}
