/*
 * ファイル名：LfcFrmPgConst.java
 *
 * 修正履歴  ：
 *             ver1.0.0     2003/03/27      王嵩
 *                          作成
 *             Copyright (c) 2003
 *
 ******************************************************************************
 *             ver1.0.1     2005/01/19      林太慶
 *                          作成
 *             Copyright (c) 2005
 *
 * 修正履歴内容：
 *
 *!)@．レスポンスを改善（案件一覧の削除、試算からコピー、案件一覧へ、複数物件の登録の反応時間短いに修正しました）。
 *!)A．Shift keyと↓を押すと3行が選択され、それ以上選べない。1行づつ追加選択される通常の動きに変更しました。
 *!)B．Shift keyと↑を押すと2行づつ追加選択される。1行づつ追加選択される通常の動きに変しました。
 *!)C．前受けリース料の行の入力不可欄(回収サイクル・回数)2つを入力不可であることが判り易いように変更しました。
 *!)D．プロファイルの社員コードにアルファベットが入れられない。
 *!)E．月額リース料/割賦金一回当リで小数点以下桁数が発生した際は切り上げる
 *!)F．見積部分で新規割賦案件場合、お見積書に割賦回数と割賦金を出力ように修正しました。
 *
 ******************************************************************************
 *             ver1.0.2     2005/02/14      Haobuqian
 *                          作成
 *             Copyright (c) 2005
 *
 * 修正履歴内容：
 *
 * !)@．OJ050028   試算からコピーのレスポンス対応
 * !)A．OJ050029   採算テーブルが３つ出来る件の調査
 * !)B．OJ050031   物件削除時に次物件に移動させる
 * !)C．OJ050032   登録済案件を編集で開くと値が空白のバグ対応
 * !)D．OJ050035   試算編集画面で　契約先名を入力したの値なかに半角スピースある時　帳票出力時、　契約先名を完全表示されなかった。
 * !)E．OJ050047   COF変更が出来ないバグ対応
 * !)F．OJ050048   割賦試算結果合計表-割賦金表示バグ対応
 * !)G．OJ050049   試算システムの「社内コスト率選択」を選択できない

 ******************************************************************************
 *             ver1.0.3     2005/03/02      Haobuqian
 *                          作成
 *             Copyright (c) 2005
 *
 * 修正履歴内容：
 *
 * !)@．OJ050081   試算帳票：リース料試算結果の社内コスト率おかしいです
 * !)A．           試算帳票: 割賦金試算結果の手数料R　NaNを出力

 ******************************************************************************
 *             ver1.0.4     2005/03/11      Haobuqian
 *                          作成
 *             Copyright (c) 2005
 *
 * 修正履歴内容：
 *
 * !)@．OJ050086   見積帳票：お見積書の物件名位置ずらいことです
 * *
 *
 *修正者：　　潘正寛
 *修正日：　　2005/04/25
 *修正内容：　メッセージE0121を追加する
 *
 *修正者：　　曾健
 *修正日：　　20050711
 *修正内容：　I0016とI0017を追加する
 *
 *修正者：　　曾健
 *修正日：　　20051110
 *修正内容：　過去データをバックアップと復元のメッセージ。
 *
 *修正者：　　pzk
 *修正日：　　20051114
 *修正内容：　メッセージI0023を追加する。
 *
 *修正者：　　pzk
 *修正日：　　20051114
 *修正内容：　メッセージI0024を追加する。
 *
 *修正者：　　pzk
 *修正日：　　20051227
 *修正内容：　メッセージI0018、I0020を変更する。
 *
 * 修正人：曾健
 * 修正日：20060106
 * 修正内容：一時保管のメッセージ
 *
 * 修正人：HBQ
 * 修正日：20060110
 * 修正内容：I0024の内容を変更しました
 *
 * 修正人：曾健
 * 修正日：20060110
 * 修正内容：I0021の内容を変更しました
 *
 * 修正人：曾健
 * 修正日：20060110
 * 修正内容：E0122,E0123の内容を変更しました
 *
 * 修正人：王嵩
 * 修正日：20060225
 * 修正内容：E0124の内容を追加しました
 *
 * 修正人：王嵩
 * 修正日：20060317
 * 修正内容：E0125の内容を追加しました
 *
 * 修正人：yangdy
 * 修正日：20060330
 * 修正内容：E0126,E127,E128の内容を追加しました
 *
 *  修正日：20061005～20061124
 *  修正人：ydy,zyb
 *  修正内容：リース料システムPricing Matrix改定。
 *
 */
package com.gecl.leaseCal.log;

/**
 *
 * クラス名：Lfcシステムのロジックチェックえらメッセージクラス.
 *
 */
public interface LfcFrmMsgConst {
    // エラーメッセージ

    public final static String E0001 = "システムエラーが発生しました。\nサポートセンターまでご連絡下さい。";
    public final static String E0002 = "契約Noは正しくありませんでした。";
    public final static String E0003 = "";
    public final static String E0004 = "分割支払情報を入力してください。";
    public final static String E0005 = "正しい検収予定日を入力してください。";
    public final static String E0006 = "検収予定日を入力してください。";
    public final static String E0007 = "契約Noを入力してください。";
    public final static String E0008 = "物件No（From)を入力してください。";
    public final static String E0009 = "購入価額を入力してください。";
    public final static String E0010 = "支払予定日を入力してください。";
    public final static String E0011 = "法定耐用年数を入力してください。";
    public final static String E0012 = "管販費率(Origination)を入力してください。";
    public final static String E0013 = "管販費率(Servicing)を入力してください。";
    public final static String E0014 = "貸倒引当率を入力してください。";
    public final static String E0015 = "手数料收益率(NPP)を入力してください。";
    public final static String E0016 = "手数料收益率(Release)を入力してください。";
    public final static String E0017 = "正しい支払予定日を入力してください。";
    public final static String E0018 = "契約No.の２～３桁目(契約形態記号)が不適切です。";
    public final static String E0019 = "契約No.の３桁目(契約形態記号)が不適切です。";
    public final static String E0020 = "物件No.の指定がありません(必須項目です)。";
    public final static String E0021 = "物件No.の指定順序に誤りがあります。";
    public final static String E0022 = "計算を行った後、更新して下さい。";
    public final static String E0023 = "ﾌﾙﾍﾟｲｱｳﾄ表示は計算終了後行なってください。";
    public final static String E0024 = "契約No.が不適切です。";
    public final static String E0025 = "既にPDFファイルを開いていたため。\n見積書を出力できませんでした。\nPDFファイルを閉じてから再度実行して下さい。";
    public final static String E0026 = "物件は存在しません。";
    public final static String E0027 = "(計算結果表示はできません)";
    public final static String E0028 = "正しい物件NO.を指定してください。";
    public final static String E0029 = "発行日が、暦の上で存在しない日付です。";
    public final static String E0030 = "有効期限が、暦の上で存在しない日付です。";
    public final static String E0031 = "担当者を入力して下さい。";
    public final static String E0032 = "消費税率を入力して下さい。";
    public final static String E0033 = "部店コードを入力して下さい。";
    public final static String E0034 = "部店名を入力して下さい。";
    public final static String E0035 = "住所（上段)を入力して下さい。";
    public final static String E0036 = "住所（下段）を入力して下さい。";
    public final static String E0037 = "電話番号を入力して下さい。";
    public final static String E0038 = "Fax番号を入力して下さい。";
    public final static String E0039 = "社員コードを入力して下さい。";
    public final static String E0040 = "発行日を入力して下さい。";
    public final static String E0041 = "正しい発行日を入力して下さい。";
    public final static String E0042 = "登録処理エラー：契約先名(漢字)を入力して下さい。";
    public final static String E0043 = "登録処理エラー：物件名を入力して下さい。(全角)";
    public final static String E0044 = "登録処理エラー：数量に正しい数値を入力して下さい。";
    public final static String E0045 = "登録処理エラー：単位を入力して下さい。";
    public final static String E0046 = "登録処理エラー：引渡予定日を入力して下さい。";
    public final static String E0047 = "登録処理エラー：引渡予定日が 暦の上で存在しない日付です。";
    public final static String E0048 = "購入価額は １０００円以上を入力して下さい。";
    public final static String E0049 = "リース期間を入力して下さい。";
    public final static String E0050 = "前受リース料を入力して下さい。";
    public final static String E0051 = "前受予定日を入力して下さい。";
    public final static String E0052 = "前受予定日が 暦の上で存在しない日付です。";
    public final static String E0053 = "登録処理エラー：第１月分回収日を入力して下さい。";
    public final static String E0054 = "登録処理エラー：第１月分回収日が 暦の上で存在しない日付です。";
    public final static String E0055 = "登録処理エラー：第２月分回収日を入力して下さい。";
    public final static String E0056 = "登録処理エラー：第２月分回収日が 暦の上で存在しない日付です。";
    public final static String E0057 = "登録処理エラー：具体的引渡場所を入力して下さい。(全角)";
    public final static String E0058 = "前受ﾘｰｽ料(月数)を入力して下さい。";
    public final static String E0059 = "登録処理エラー：月額リース料を入力して下さい。";
    public final static String E0060 = "登録処理エラー：割賦回数を入力して下さい。";
    public final static String E0061 = "頭金を入力して下さい。";
    public final static String E0062 = "登録処理エラー：割賦金(１回当り)を入力して下さい。";
    public final static String E0063 = "頭金 回収日を入力して下さい。";
    public final static String E0064 = "頭金 回収日が 暦の上で存在しない日付です。";
    public final static String E0065 = "前受ﾘｰｽ料(月数)は ９９９以下を入力して下さい。";
    public final static String E0066 = "指定された範囲に、採算未計算物件が有るので、表示不能。";
    // 20040721 ltq
    public final static String E1001 = "登録処理エラー：社員コードは５桁目を入力して下さい。";
    public final static String E1002 = "登録処理エラー：部店コードは３桁目を入力して下さい。";
    public final static String E0067 = "採算に影響する項目が変更されています。更新続行：はい 中止：いいえ。";
    public final static String E0068 = "月額ﾘｰｽ料か合計料率か月料率のいずれかを入力して下さい。";
    public final static String E0069 = "前受回収方法２のみの指定はできません。";
    public final static String E0070 = "前受回収方法１，２が重複しています。";
    public final static String E0071 = "第１月分回収方法２のみの指定はできません。";
    public final static String E0072 = "第１月分回収方法１，２が重複しています。";
    public final static String E0073 = "第２月分回収方法２のみの指定はできません。";
    public final static String E0074 = "第２月分回収方法１，２が重複しています。";
    public final static String E0075 = "頭金回収方法２のみの指定はできません。";
    public final static String E0076 = "頭金回収方法１，２が重複しています。";
    public final static String E0077 = "第１回目回収方法２のみの指定はできません。";
    public final static String E0078 = "第１回目回収方法１，２が重複しています。";
    public final static String E0079 = "第２回目回収方法２のみの指定はできません。";
    public final static String E0080 = "第２回目回収方法１，２が重複しています。";
    public final static String E0081 = "頭金の口座振替回収はできません。";
    public final static String E0082 = "検収予定日と前受予定日の関係が正しくありません。";
    public final static String E0083 = "検収予定日と第１月分回収日の関係が正しくありません。";
    public final static String E0084 = "検収予定日と第２月分以降回収日の関係が正しくありません。";
    public final static String E0085 = "第１月分回収日と第２月分以降回収日の関係が正しくありません。";
    public final static String E0086 = "物件Noを入力して下さい。";
    public final static String E0087 = "不連続NO指定に誤りが有ります(Space)。";
    public final static String E0088 = "不連続NO指定に誤りが有ります(半角数値のみ入力)。";
    public final static String E0089 = "不連続物件No指定内の物件NOが重複しています。";
    public final static String E0090 = "正しい物件Noを指定して下さい。";
    public final static String E0091 = "正しい消費税率を入力して下さい。";
    public final static String E0092 = "正しい回収予定日を入力して下さい。";
    public final static String E0093 = "バックアップファイルは存在しません。バックアップことができません。";
    public final static String E0094 = "全て物件のILeverage RatioとInternal Product値合わせない。";
    public final static String E0095 = "[L]、[S]以外の入力した場合の後程処理不可。";
    public final static String E0096 = "正しい算出項目指定を入力してください。";
    public final static String E0097 = "正しい逆算時基準項目を入力してください。";
    public final static String E0098 = "正しい算出項目指定と逆算時基準項目の組合を設定してください。";
    public final static String E0099 = "分割支払時、購入額を逆算不能。";
    public final static String E0100 = "は半角数字で入力してください。";
    public final static String E0101 = "原調計算金利(COF)を入力してください。";
    public final static String E0102 = "LeverageRatioは99:9で入力してください";
    public final static String E0103 = "Siebel7からﾘｰｽ料/割賦金計算ｼｽﾃﾑと見積書作成ｼｽﾃﾑへ遷移する場合、インターフェースのパラメータは正しくありません。";
    public final static String E0104 = "一括支払の場合、支払予定日を入力してください。";
    public final static String E0105 = "入力した条件に該当するデータは存在しない。";
    public final static String E0106 = "正しい日付を入力してください。";
    public final static String E0107 = "複数選択されている場合は、この処理はできません。";
    // 20040810 ljq add s
    public final static String E0108 = "合計は採算未計算物件があるので、表示不能！";
    // 20040810 ljq add e
    public final static String E0109 = "登録処理エラー：口座振替の回収日は";
    public final static String E0111 = "を指定して下さい。";
    public final static String E0110 = "登録処理エラー：口座振替の回収日は27日を指定して下さい。";
    public final static String E0112 = "頭金の口座振替回収はできません。";
    public final static String E0113 = "前受ﾘｰｽ料が半角数字を入力してください。";
    public final static String E0114 = "回収金額は半角数字で入力してください。";
    public final static String E0115 = "回収予定日は半角数字で入力してください。";
    public final static String E0116 = "回収サイクルは半角数字で入力してください。";
    public final static String E0117 = "回数は半角数字で入力してください。";
    public final static String E0118 = "購入価額の内訳金額は半角数字で入力してください。";
    public final static String E0119 = "支払予定日は半角数字で入力してください。";
    // pzk 2004/11/18
    public final static String E0120 = "登録処理エラー：前受回収日を入力して下さい。";
    // pzk add 2005/04/25 start
    public final static String E0121 = "有効期間は発行日以降にして下さい。";
    // pzk add 2005/04/25 end
    public final static String E0122 = "Functionに変更がありました。\nFunctionを選択しなおして下さい。";
    public final static String E0123 = "Functionを選択して下さい。";
    // ws add 2006/02/25 start
    public final static String E0124 = "購入選択行使権額を入力して下さい。";
    //ydy modify 20090702 s
//    public final static String E0125 = "購入額合計が６００ＭＭ以上となりますので、\n財務企画部へＣＯＦを問い合わせる必要があります。";
    public final static String E0125 = "1引合当たりの購入額$5MM以上のCOFは個別設定となります。\n円貨のドル換算は月次レートで変わりますので、Pricingにお問合せ下さい。";
    //ydy modify 20090702 e
    // ws add 2006/02/25 end
    // Ydy add 20060330 start
    public final static String E0126 = "税務判定金利種別、会計判定金利種別のどちらかが入力されていません。";
    public final static String E0127 = "税務判定金利種別、会計判定金利種別が入力されていません。";
    public final static String E0128 = "購入選択権の有無が入力されていません。";
    // Ydy add 20060330 end
    //zyb add 20061103 s
    //ydy add 20061013 s
    //ful 修正　20081203　start
    //public final static String E0129 = "与信ランクが変更されました。\nこの案件は物件が複数登録されています。\n各物件の社内コスト率を再選択してください。\n社内コスト率の再選択が必要な物件は下記の通りです。\n";
    public final static String E0129 = "GE格付が変更されました。\nこの案件は物件が複数登録されています。\n各物件の社内コスト率を再選択してください。\n社内コスト率の再選択が必要な物件は下記の通りです。\n";
    //ful 修正　20081203　end
    public final static String E0130 = "  ・物件No:";
    //public final static String E0131 = "もう一度社内コスト率を選択してください。";
//    public final static String E0132 = "機種を変更しました、社内コスト率を再度選択してください。";
    //ful 修正　20081203　start
    //public final static String E0135 = "与信ランクが変更されました。\n正しい社内コスト率を再選択してください。";
    //public final static String E0133 = "与信ランクを選択してください。";
    //public final static String E0136 = "与信ランクを変更すると社内コスト率を再選択する必要があります。\n◆複数物件の登録がある場合、特に注意して下さい◆\n与信ランクを変更しますか？";
    public final static String E0135 = "GE格付が変更されました。\n正しい社内コスト率を再選択してください。";
    public final static String E0133 = "同じGE格付を入力してください。";
    public final static String E0136 = "GE格付を変更すると社内コスト率を再選択する必要があります。\n◆複数物件の登録がある場合、特に注意して下さい◆\nGE格付を変更しますか？";
    //ful 修正　20081203　end
    public final static String E0137 = "機種を変更すると残価率、残価、社内コスト率がクリアされます。\n機種を変更しますか？";
    //ydy add 20061219 s
    public final static String E0138 = "機種を変更すると社内コスト率がクリアされます。\n機種を変更しますか？";
    //ydy add 20061219 e
    //20070510 zyb modi s
    //20070410 zyb add s
    public final static String E0139 = "2009年2月1日よりROIの計算基準が変更されました。\n再計算をしてから案件を登録して下さい。\n\n再計算が必要な物件は下記の通りです。\n";
    //20070410 zyb add e
    //20070510 zyb modi e
    //ydy add 20061013 s
    //zyb add 20061103 e
    //ydy add 20070908 s
    public final static String E0200 = "「GELのリース料回収日の翌月」に\n「1～28」を入力してください\n";
    //ydy add 20070908 s
    //ydy add 20071121 s
    public final static String E0210 = "割賦案件は通期採算表出力対象外です。";
    public final static String E0211 = "通期採算表を作成できません。\nシステム管理員を連絡してください。";
    public final static String E0212 = "2008年1月1日より固定資産税の計算基準が変更されました。\n再計算をしてから案件を登録して下さい。\n\n再計算が必要な物件は下記の通りです。\n";
    //ydy add 20071121 e
    //20061114 zyb add s
//    public final static String E0134 = "機種と定率残価の大分類不一致ので\nもう一度確認してください。";
    //20061114 zyb add e
    //ydy add 20080331 s
    //ydy modify 20080806 s
//    public final static String E0220 = "社内コスト率の選択に誤りがある可能性があります。";
    public final static String E0220 = "リース期間・社内コスト率の設定に相違があります。";
    public final static String E0222 = "割賦期間・社内コスト率の設定に相違があります。";
    //ydy modify 20080806 s
    public final static String E0221 = "登録してもよろしいですか？";
    public final static String E0223 = "ＲＯEで逆算時LeverageRatioを入力してください。";
    public final static String E0224 = "合計料率を入力してください。";
    public final static String E0225 = "月料率を入力してください。";
    public final static String E0226 = "運用利回りを入力してください。";
    public final static String E0227 = "ＴＲを入力してください。";
    public final static String E0228 = "ＲＯＩを入力してください。";
    public final static String E0229 = "ＲＯEを入力してください。";
    public final static String E0230 = "正しい前受予定日を入力してください。";
    public final static String E0231 = "前受予定日を入力不要です。";

    //ydy add 20080331 e
    // 警告メッセージ
    public final static String I0001 = "案件を削除します。よろしいですか ?";
    public final static String I0002 = "前物件Ｎｏ．は存在しません。";
    public final static String I0003 = "次物件Ｎｏ．は存在しません。";
    public final static String I0004 = "物件No.";
    public final static String I0005 = "を削除します。よろしいですか ?";
    public final static String I0006 = "は削除されました。";
    public final static String I0007 = "データをクリアします。よろしいですか ?";
    // pzk modi 2004/11/15 start
    // public final static String I0008 =
    public final static String I0008 = "案件情報のバックアップを作成しますか ?";
    // pzk modi 2004/11/15 end
    public final static String I0009 = "」を帳票出力しますか?";
    public final static String I0010 = "試算条件が変更されています。登録しないでよろしいですか ?";
    public final static String I0011 = "終了するなら:はい 中止するなら:いいえ";
    public final static String I0012 = "見積条件が変更されています。登録しないでよろしいですか ?";
    public final static String I0013 = "試算案件がありません。";
    public final static String I0014 = "「団体信用生命保険料率」範囲エラー（0以上99以下を入力）！";
    public final static String I0015 = "ProductCDは変更されましたので、この操作を行うために１分ぐらい掛かります。続けますか。";
    // 20050711 zj start
    public final static String I0016 = "コピー元のリース案件がありません。";
    public final static String I0017 = "コピー元の割賦案件がありません。";
    // 20050711 zj end
    // 20051110 zj s
    // PZK modi 20051227 S
    // public final static String I0018 = "案件を復元します、よろしいでしょうか。";
    public final static String I0018 = "選択したデータを案件一覧に戻します。\nよろしいでしょうか。";
    // PZK modi 20051227 E
    public final static String I0019 = "案件を削除します、よろしいでしょうか。";
    // pzk modi 20051227 S
    // public final static String I0020 = "案件を過去データに移動します。よろしいですか？";
    public final static String I0020 = "選択したデータを一時保存先に移動します。\nよろしいですか？";
    // pzk modi 20051227 E
    public final static String I0021 = "一時保存先にデータはありません。";
    public final static String I0022 = "バックアップ元データを存在しません。";
    // 20051110 zj e
    //ydy add 20080414 s
    public final static String Y0001 = "EXPORT元データを存在しません。";
    public final static String Y0002 = "選択したデータをEXPORTします。\nよろしいですか？";
    public final static String Y0003 = "IMPORTできません。\n正確ファイルを選択してください。";
    //ydy add 20080414 e
    // pzk 20051114 s
    public final static String I0023 = "自動バックアップをできません。";
    // pzk 20051114 e
    // pzk add 20051215 s
    public final static String I0024 = "残価が設定されています。作業を中止しますか？";
    // pzk add 20051215 e
    // 20060106 zj s
    public final static String I0025 = "案件数が５００件を超えています。\nシステムを快適に利用するために不要な案件を\n［一時保存先へ］移動することをお勧めします。\n\n［一時保存先へ］不要な案件を移動しますか？";
    public final static String I0026 = "【一時保存先の取扱い】\n　１．一時保存先への移動方法\n　　　案件一覧で不要な案件を選択して［一時保存先へ］ボタンをクリックします。\n\n　２．一時保存先からの復元方法\n　　　オプションから［一時保存先の整理］を選択し、一時保存・案件一覧を表示。\n　　　復元したい案件を選択して［案件一覧へ戻す］ボタンをクリックします。";
    // 20060106 zj e
    // ログメッセージ
    public final static String L0001 = "ファイルは見付けません。";
    public final static String L0002 = "ファイル操作の時、エラーでした。";
    public final static String L0003 = "PDF出力時にエラーが発生しました。ITにご連絡下さい。";
    public final static String L0004 = "データベースにエラーが発生しました。ITにご連絡下さい。";
    // ダイアログタイトル
    public final static String T0001 = "リース料/割賦金計算";
    public final static String T0002 = "エラー";
    public final static String A0001 = "登録しました。";
    public final static String A0002 = "物件が削除されました。";
    // ﾊﾞｰｼﾞｮﾝ情報
    // public final static String V0001 = "ﾘｰｽ料・割賦金計算/見積書作成システム \nﾊﾞｰｼﾞｮﾝ 1.0.0
    // 2005/01/05\nＧＥキャピタルリーシング";
    // ltq 20050119 修正しました。
    // public final static String V0001 = "ﾘｰｽ料・割賦金計算/見積書作成システム \nﾊﾞｰｼﾞｮﾝ 1.0.1
    // 2005/01/24\nＧＥキャピタルリーシング";
    // hbq 20050207 修正しました。
    // public final static String V0001 = "ﾘｰｽ料・割賦金計算/見積書作成システム \nﾊﾞｰｼﾞｮﾝ 1.0.2
    // 2005/02/14\nＧＥキャピタルリーシング";
    // hbq 20050302 修正しました。
    // public final static String V0001 = "ﾘｰｽ料・割賦金計算/見積書作成システム \nﾊﾞｰｼﾞｮﾝ 1.0.3
    // 2005/03/05\nＧＥキャピタルリーシング";
    // public final static String V0001 = "ﾘｰｽ料・割賦金計算/見積書作成システム   \nﾊﾞｰｼﾞｮﾝ 1.0.4    2005/03/11\nGEフィナンシャルサービス";
    // ys 20091127 修正しました。
    public final static String V0001 = "ﾘｰｽ料・割賦金計算/見積書作成システム   \nﾊﾞｰｼﾞｮﾝ 1.0.4    2005/03/11\n日本GE株式会社　GEキャピタル";
}
