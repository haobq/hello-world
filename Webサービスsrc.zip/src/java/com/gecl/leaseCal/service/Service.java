/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gecl.leaseCal.service;

import jp.gecapital.schema.ei.eiwsexception.EIWSExceptionsType;
import jp.gecapital.wsdl.ei.pricing.pricecalculate.EIWSException;

/**
 *
 * @author 500919551
 */
public class Service {

    protected EIWSExceptionsType faultInfos = null;
    protected EIWSException exception = null;

    public Service() {
        faultInfos = new EIWSExceptionsType();
        exception = new EIWSException("Server Error", faultInfos);
    }

    protected void checkIFThrowException() throws EIWSException {
        if (faultInfos.getEIWSException().size() > 0) {
            throw exception;
        }
    }
}
