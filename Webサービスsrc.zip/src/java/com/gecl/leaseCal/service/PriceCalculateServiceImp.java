/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gecl.leaseCal.service;

import com.gecl.leaseCal.db.comm.LfcDBMsgConst;
import com.gecl.leaseCal.log.LfcFrmMsgConst;
import com.gecl.leaseCal.log.WriteBugInfo;
import com.gecl.leaseCal.logic.comm.LfcFrmComm;
import com.gecl.leaseCal.logic.comm.LfcLogicComm;
import com.gecl.leaseCal.logic.comm.LfcLogicMsgConst;
import com.gecl.leaseCal.logic.comm.WebServiceIFBean;
import ei.jp.gecapital.util.ExceptionUtil;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import jp.gecapital.schema.ei.pricing.pricecalculate.BukenOutputComplexType;
import jp.gecapital.schema.ei.pricing.pricecalculate.BukenOutputResType;
import jp.gecapital.schema.ei.pricing.pricecalculate.ErrorInforOutputRecord;
import jp.gecapital.schema.ei.pricing.pricecalculate.ObjectOutputComplexType;
import jp.gecapital.wsdl.ei.pricing.pricecalculate.EIWSException;

/**
 *
 * @author 500919551
 */
public class PriceCalculateServiceImp  extends Service {

    public java.util.List<jp.gecapital.schema.ei.pricing.pricecalculate.BukenOutputComplexType> priceCal(java.util.List<jp.gecapital.schema.ei.pricing.pricecalculate.BukenInputComplexType> bukenInput) throws EIWSException {
        BukenOutputResType bukenOutputRecode = new BukenOutputResType();
        try {
            //*************************************************************************
            //Input情報をOutPutの構造体に格納
            //*************************************************************************
            WebServiceIFBean bWebServiceIFBean = new WebServiceIFBean();
            bukenOutputRecode = bWebServiceIFBean.setWebServiceIFBean(bukenInput);
            //*************************************************************************
            //OutPutの構造体のデータの整合性をチェック、チェック結果をOutPutに保存
            //チェック結果OKだったら、次に進める；そうではないの場合処理を中止させる
            //*************************************************************************
            boolean bCheck = true;
            boolean bCalculate = true;
            int index_input = 0;
            boolean bLsKpFlg = true;
            boolean bLeverFlg = true;
            boolean bGERATING = true;
            String sFlgLsKp = "";
            //PRODUCT
            String strProduct = "";
            //LEVERAGE_RATIO
            String strLeverageRatio = "";
            //GE_RATING
            String strGERATING = "";
            BukenOutputComplexType bOutBukenTmp = new BukenOutputComplexType();
            bukenOutputRecode = bWebServiceIFBean.doInputDatCheck(bukenOutputRecode);
            List<BukenOutputComplexType> listBuken = bukenOutputRecode.getBukenOutput();
            for (index_input = 0; index_input < listBuken.size(); index_input++) {
                bOutBukenTmp = listBuken.get(index_input);
                if (!bOutBukenTmp.isCheckAttribute()) {
                    bCheck = false;
                    bCalculate = false;
                    break;
                }
            }
            //すべで物件はリースとか、割賦とか判断する　true　ほかの場合　false
            if (listBuken.size() > 1) {
                bOutBukenTmp = listBuken.get(0);
                sFlgLsKp = bOutBukenTmp.getBukenRecord().getLSKP().toString().trim();
                for (index_input = 1; index_input < listBuken.size(); index_input++) {
                    bOutBukenTmp = listBuken.get(index_input);
                    String sFlgLsKpTmp = bOutBukenTmp.getBukenRecord().getLSKP().toString().trim();
                    if (!sFlgLsKp.equals(sFlgLsKpTmp)) {
                        bLsKpFlg = false;
                        break;
                    }
                    sFlgLsKp = bOutBukenTmp.getBukenRecord().getLSKP().toString().trim();
                }
            }
            //全て物件のInternalProduct値違う
            //全て物件のLeverageRatio値違う
            if (listBuken.size() > 1) {
                bOutBukenTmp = listBuken.get(0);
                strProduct = bOutBukenTmp.getBukenRecord().getPRODUCT().toString().trim();
                strLeverageRatio = bOutBukenTmp.getBukenRecord().getLEVERAGERATIO().toString().trim();
                strGERATING = bOutBukenTmp.getBukenRecord().getGERATING().toString().trim();
                for (int i = 1; i < listBuken.size(); i++) {
                    bOutBukenTmp = listBuken.get(i);
                    String strProductTmp = bOutBukenTmp.getBukenRecord().getPRODUCT().toString().trim();
                    String strLeverageRatioTmp = bOutBukenTmp.getBukenRecord().getLEVERAGERATIO().toString().trim();
                    String strGERATINGTmp = bOutBukenTmp.getBukenRecord().getGERATING().toString().trim();
                    //全て物件のLeverageRatioとInternalProduct値合わせない。
                    if (!strProduct.equals(strProductTmp) || !strLeverageRatio.equals(strLeverageRatioTmp)) {
                        ErrorInforOutputRecord tempErr = bWebServiceIFBean.getErrorMsgRecord();
                        tempErr = LfcLogicComm.setErrMsgRecord(bOutBukenTmp, "E0094", LfcFrmMsgConst.E0094, tempErr);
                        bWebServiceIFBean.setErrorMsgRecord(tempErr);
                        bWebServiceIFBean.cearErrorMsgList();
                        bLeverFlg = false;
                    }

                    //GE_RATING
                    if (!strGERATING.equals(strGERATINGTmp)) {
                        ErrorInforOutputRecord tempErr = bWebServiceIFBean.getErrorMsgRecord();
                        tempErr = LfcLogicComm.setErrMsgRecord(bOutBukenTmp, "E0133", LfcFrmMsgConst.E0133, tempErr);
                        bWebServiceIFBean.setErrorMsgRecord(tempErr);
                        bWebServiceIFBean.cearErrorMsgList();
                        bGERATING = false;
                    }
                }
            }
            //*************************************************************************
            //OutPutの構造体のデータを使ってリース料を計算する
            //*************************************************************************
            if (bCheck) {
                index_input = 0;
                bukenOutputRecode = bWebServiceIFBean.doCalculatePrice(bukenOutputRecode);
                listBuken = bukenOutputRecode.getBukenOutput();
                for (index_input = 0; index_input < listBuken.size(); index_input++) {
                    bOutBukenTmp = listBuken.get(index_input);
                    if (!bOutBukenTmp.isCalculateAttribute()) {
                        bCalculate = false;
                        break;
                    }
                }
            }

            //wanglin(DHC) Add Start 20101116
            //*************************************************************************
            //単一物件の場合は　運用利回りが15%超えています
            //*************************************************************************
            if (bCalculate && listBuken.size() == 1 && bLsKpFlg && bLeverFlg && bGERATING) {
                    if(LfcFrmComm.ToDouble(bOutBukenTmp.getBukenRecord().getRATEUNYO()) >15.00
                            && bOutBukenTmp.getBukenRecord().getLSKP().equals("S")){
                        bOutBukenTmp.setCalculateAttribute(false);
                        ErrorInforOutputRecord tempErr = bWebServiceIFBean.getErrorMsgRecord();
                        tempErr = LfcLogicComm.setErrMsgRecord(bOutBukenTmp, "ERR126", LfcLogicMsgConst.ERR126, tempErr);
                        bWebServiceIFBean.setErrorMsgRecord(tempErr);
                        bWebServiceIFBean.cearErrorMsgList();
                    }
            }
            //wanglin(DHC) Add End 20101116

            //*************************************************************************
            //合計するbCheck && bLeverFlg && bGERATING
            //*************************************************************************
            if (bCalculate && listBuken.size() > 1 && bLsKpFlg && bLeverFlg && bGERATING) {
                //合計レコードを追加
                ObjectOutputComplexType outObjectTmp = new ObjectOutputComplexType();
                BukenOutputComplexType bOutBukenTotal = new BukenOutputComplexType();
                bOutBukenTotal = bWebServiceIFBean.doTotalPrice(outObjectTmp, bukenOutputRecode, sFlgLsKp);
                //wanglin(DHC) Add Start 20101116
                //契約運用利回りが15%を超過した場合
                if(LfcFrmComm.ToDouble(bOutBukenTotal.getBukenRecord().getRATEUNYO()) > 15.00 
                        && bOutBukenTotal.getBukenRecord().getLSKP().equals("S")){
                    bOutBukenTotal.setCalculateAttribute(false);
                    bOutBukenTotal.setCheckAttribute(true);
                    ErrorInforOutputRecord tempErr = bWebServiceIFBean.getErrorMsgRecord();
                    tempErr = LfcLogicComm.setErrMsgRecord(bOutBukenTotal, "ERR126", LfcLogicMsgConst.ERR126, tempErr);
                    bWebServiceIFBean.setErrorMsgRecord(tempErr);
                    bWebServiceIFBean.cearErrorMsgList();
                }
                //wanglin(DHC) Add End 20101116
                bukenOutputRecode.getBukenOutput().add(index_input, bOutBukenTotal);
            }
            return bukenOutputRecode.getBukenOutput();
        } catch (Exception e) {

            //サーバー側のログファイルを作成。
            WriteBugInfo wtInfo = new WriteBugInfo();
            wtInfo.writeSystemLog("PriceCalculateWebService", //クラス名
                    "PriceCalculateWebService", //メソッド名
                    LfcDBMsgConst.ERA000, //ロジックメッセージ
                    e);                    //システムエラーメッセージ
            //Clientに異常情報を投げる
            StringWriter stackTrace = new StringWriter();
            e.printStackTrace(new PrintWriter(stackTrace));
            faultInfos.getEIWSException().add(ExceptionUtil.getException("99001", stackTrace.getBuffer().toString()));
            throw exception;
        } finally {
            bukenOutputRecode = null;
        }
    }
}