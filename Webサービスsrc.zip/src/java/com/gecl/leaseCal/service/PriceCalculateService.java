/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gecl.leaseCal.service;

import javax.ejb.Stateless;
import javax.jws.WebService;
import jp.gecapital.wsdl.ei.pricing.pricecalculate.EIWSException;
import jp.gecapital.wsdl.ei.pricing.pricecalculate.PriceCalculatePortType;

/**
 *
 * @author 500919551
 */
@WebService(serviceName = "PriceCalculateService", portName = "PriceCalculatePortType", endpointInterface = "jp.gecapital.wsdl.ei.pricing.pricecalculate.PriceCalculatePortType", targetNamespace = "http://www.gecapital.jp/wsdl/ei/pricing/PriceCalculate", wsdlLocation = "META-INF/wsdl/PriceCalculateService/PriceCalculateService.wsdl")
@Stateless
public class PriceCalculateService implements PriceCalculatePortType{

    public java.util.List<jp.gecapital.schema.ei.pricing.pricecalculate.BukenOutputComplexType> priceCal(java.util.List<jp.gecapital.schema.ei.pricing.pricecalculate.BukenInputComplexType> bukenInput) throws EIWSException {
        PriceCalculateServiceImp imp = new PriceCalculateServiceImp();
        return imp.priceCal(bukenInput);
    }

}
