package jp.co.inc.media.video.utils;

/**
 * 概要：格納動画ファイルフォルダと動画ファイルJSON管理クラスです。
 * 
 * @version 1.0.0
 * @author HaoBuqian
 */
public class FolderListBean {
	String folderPath ="";
	String jsonfilePath = "";

	public FolderListBean(){
		 folderPath ="";
		 jsonfilePath = "";
	}
	public String getFolderPath() {
		return folderPath;
	}
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}
	public String getJsonfilePath() {
		return jsonfilePath;
	}
	public void setJsonfilePath(String jsonfilePath) {
		this.jsonfilePath = jsonfilePath;
	}
}

