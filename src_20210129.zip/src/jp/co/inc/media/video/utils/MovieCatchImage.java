package jp.co.inc.media.video.utils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.MessageConst;

public class MovieCatchImage implements BasConst {

	//動画エンコード方式
	public static boolean isMovHEVC;

	public static void CatchImage(File file) throws Exception {
		try {
			// フォルダを作成
			if (!Files.exists(Paths.get(imgPath))) {
				Files.createDirectory(Paths.get(imgPath));
			}
			//値初期化
			isMovHEVC = false;
			String inputfile = file.getPath();
			// サムネイル１取得する
			String outputFirst = imgPath + PANE_IMAGE_NAME1;
			List<String> resultFirst = ToolsUtils.MovieCatchImage(inputfile, "1", PANE_IMAGE_NAME1, outputFirst);
			// 実行結果
			String resultEx = (resultFirst.size() > 0) ? resultFirst.get(resultFirst.size() - 1) : null;
			if (!resultEx.equals("0")) {
				throw new Exception(MessageConst.E0030);
			}
			// 動画時長とコーデック取得する
			int videoTime = 0;
			String keyWordVideoTime = "Duration:";
			String keyWordVideoEncoder = "encoder";
			for (String line : resultFirst) {
				if (line.contains(keyWordVideoTime)) {
					String duration = line
							.substring(line.indexOf(keyWordVideoTime) + keyWordVideoTime.length(), line.length()).trim()
							.split(",")[0].trim();
					videoTime = (int) (ToolsUtils.dateParseRegExp(duration) / 2);
				}
				if (line.contains(keyWordVideoEncoder)) {
					 String encode  = line.substring(line.indexOf(keyWordVideoEncoder)+ keyWordVideoEncoder.length(), line.length()).trim().split(":")[1].trim();
					 if (encode.toUpperCase().contains("HEVC")) {
						 isMovHEVC = true;
					 }
				 }
			}
			resultFirst.clear();
			// サムネイル2取得する
			if (videoTime > 0) {
				String outputMid = imgPath + PANE_IMAGE_NAME2;
				List<String> resultMid = ToolsUtils.MovieCatchImage(inputfile, String.valueOf(videoTime),
						PANE_IMAGE_NAME2, outputMid);
				// 実行結果
				resultEx = (resultMid.size() > 0) ? resultMid.get(resultMid.size() - 1) : null;
				if (!resultEx.equals("0")) {
					throw new Exception(MessageConst.E0030);
				}
				resultMid.clear();
			} else {
				throw new Exception(MessageConst.E0030);
			}

			// サムネイル3取得する
			String outputLast = imgPath + PANE_IMAGE_NAME3;
			List<String> resultLast = ToolsUtils.MovieCatchImage(inputfile, "-1", PANE_IMAGE_NAME3, outputLast);
			// 実行結果
			resultEx = (resultLast.size() > 0) ? resultLast.get(resultLast.size() - 1) : null;
			if (!resultEx.equals("0")) {
				throw new Exception(MessageConst.E0030);
			}
			resultLast.clear();

		} catch (Exception e) {
			throw new Exception(MessageConst.E0030);
		}
	}
}
