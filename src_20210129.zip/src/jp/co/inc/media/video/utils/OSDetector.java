package jp.co.inc.media.video.utils;

import java.awt.Desktop;
import java.io.File;

/**
 * 概要：windowsとmacパソコンの識別のクラスです。
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class OSDetector {
	private static boolean isWindows = false;
	private static boolean isLinux = false;
	private static boolean isMac = false;

	static {
		String os = System.getProperty("os.name").toLowerCase();
		isWindows = os.contains("win");
		isLinux = os.contains("nux") || os.contains("nix");
		isMac = os.contains("mac");
	}

	public static boolean isWindows() {
		return isWindows;
	}

	public static boolean isLinux() {
		return isLinux;
	}

	public static boolean isMac() {
		return isMac;
	};

	public static boolean open(String pdfFilePath) {
		try {
			if (OSDetector.isWindows()) {
		        File pdfFile = new File(pdfFilePath);
		        if (pdfFile.exists()) {
		            if (Desktop.isDesktopSupported()) {
		                Desktop.getDesktop().open(pdfFile);
		            } 
		        } 
				return true;
			} else if (OSDetector.isLinux() || OSDetector.isMac()) {
				Runtime.getRuntime().exec(new String[] { "/usr/bin/open", pdfFilePath });
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
