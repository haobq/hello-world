package jp.co.inc.media.video.utils;

import jp.co.inc.media.video.common.BasConst;

/**
 * 概要：MP4の動画ファイル情報格納BEAN
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class FileInfoBean implements BasConst {

	/** 動画ファイル名 */
	private String fileName = "";
	/** ローカル動画ファイルパス */
	private String filePath = "";
	public FileInfoBean() {
		super();
		this.fileName = "";
		this.filePath = "";
		this.fileSize = 0;
		this.updateDate = "";
		this.lastUpdateDate = "";
		this.status = Status.STATUS_NEW;
		this.uploadFileName = "";
		this.bikou = "";
		this.hosp_id = "";
		this.patient_id = "";
		this.movie_index = 0;
		this.movie_date = "";
		this.movie_send_time = "";
		this.bunrui = "";
		this.title = "";
		this.image_no = 0;
	}

	/** 動画ファイルサイズ(byte) */
	private long fileSize = 0;
	// 動画ファイル最新更新日時 */
	private String updateDate = "";
	// ファイル変更した最新更新日時 */
	private String lastUpdateDate = "";
	// アップロード状況 */
	private Status status = Status.STATUS_NEW;
	// アップロードのファイル名 */
	private String uploadFileName = "";
	/** 備考 */
	private String bikou = "";

	/** 医院ID */
	private String hosp_id = "";
	/** 患者ID */
	private String patient_id = "";
	/** 連番 */
	private int movie_index = 0;
	/** 撮影日 */
	private String movie_date = "";
	/** 送信時間 */
	private String movie_send_time = "";
	/** 分類 */
	private String bunrui = "";
	/** タイトル */
	private String title = "";
	/** image_no */
	private int image_no = 0;

	/**
	 * @return image_no
	 */
	public int getImage_no() {
		return image_no;
	}

	/**
	 * @param image_no セットする image_no
	 */
	public void setImage_no(int image_no) {
		this.image_no = image_no;
	}
	/**
	 * @return bunrui
	 */
	public String getBunrui() {
		return bunrui;
	}

	/**
	 * @param bunrui セットする bunrui
	 */
	public void setBunrui(String bunrui) {
		this.bunrui = bunrui;
	}

	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title セットする title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return 備考 bikou
	 */
	public String getBikou() {
		return bikou;
	}

	/**
	 * @param bikou セットする 備考
	 */
	public void setBikou(String bikou) {
		this.bikou = bikou;
	}

	/**
	 * 動画ファイル名取得
	 * @return 動画ファイル名
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * 動画ファイル名設定
	 *
	 * @param fileName　動画ファイル名
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * 動画ファイル名サイズ取得
	 *
	 * @return 動画ファイル名サイズ
	 */
	public long getFileSize() {
		return fileSize;
	}

	/**
	 * 動画ファイルサイズ設定
	 *
	 * @param fileSize　動画ファイルサイズ
	 */
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	/**
	 * 動画ファイル撮影日取得
	 *
	 * @return 動画ファイル撮影日
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * 動画ファイル撮影日設定
	 *
	 * @param updateDate　動画ファイル撮影日
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	
	/**
	 * @return lastUpdateDate
	 */
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	/**
	 * @param lastUpdateDate セットする lastUpdateDate
	 */
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	
	/**
	 * アップロード状況取得<br>
	 *
	 *  [未] アップロードしていない <br>
	 *  [中] アップロード処理中 <br>
	 *  [完] アップロード処理完了<br>
	 *
	 * @return アップロード状況
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * アップロード状況設定 <br>
	 *
	 * [未] アップロードしていない<br>
	 * [中] アップロード処理中 <br>
	 * [完] アップロード処理完了<br>
	 *
	 * @param status アップロード状況
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * アップロードファイル名取得
	 *
	 * @return String アップロードファイル名
	 */
	public String getUploadFileName() {
		return uploadFileName;
	}

	/**
	 * アップロードファイル名設定
	 *
	 * @param uploadFileName アップロードファイル名
	 */
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	/**
	 * ローカル動画ファイルパス取得
	 *
	 * @return ローカル動画ファイルパス
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * ローカル動画ファイルパス設定
	 *
	 * @param filePath ローカル動画ファイルパス
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	/**
	 * @return hosp_id
	 */
	public String getHosp_id() {
		return hosp_id;
	}

	/**
	 * @param hosp_id セットする hosp_id
	 */
	public void setHosp_id(String hosp_id) {
		this.hosp_id = hosp_id;
	}

	/**
	 * @return patient_id
	 */
	public String getPatient_id() {
		return patient_id;
	}

	/**
	 * @param patient_id セットする patient_id
	 */
	public void setPatient_id(String patient_id) {
		this.patient_id = patient_id;
	}

	/**
	 * @return movie_index
	 */
	public int getMovie_index() {
		return movie_index;
	}

	/**
	 * @param movie_index セットする movie_index
	 */
	public void setMovie_index(int movie_index) {
		this.movie_index = movie_index;
	}

	/**
	 * @return movie_date
	 */
	public String getMovie_date() {
		return movie_date;
	}

	/**
	 * @param movie_date セットする movie_date
	 */
	public void setMovie_date(String movie_date) {
		this.movie_date = movie_date;
	}

	/**
	 * @return movie_send_time
	 */
	public String getMovie_send_time() {
		return movie_send_time;
	}

	/**
	 * @param movie_send_time セットする movie_send_time
	 */
	public void setMovie_send_time(String movie_send_time) {
		this.movie_send_time = movie_send_time;
	}

}
