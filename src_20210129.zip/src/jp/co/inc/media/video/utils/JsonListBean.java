package jp.co.inc.media.video.utils;
import jp.co.inc.media.video.common.BasConst;

/**
 * 概要：履歴情報格納BEAN
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class JsonListBean implements BasConst {

	/** JSONファイル名 */
	public String fileName = "";

	public String status = "";

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * JSONファイル名取得
	 *
	 * @return JSONファイル名
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * JSONファイル名設定
	 *
	 * @param fileName　JSONファイル名
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}
