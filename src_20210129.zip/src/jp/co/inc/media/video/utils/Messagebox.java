package jp.co.inc.media.video.utils;

import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasImage;
import jp.co.inc.media.video.common.MessageConst;

/**
 * 概要：メッセージポップアップ画面作成のクラスです。
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class Messagebox extends Stage implements BasConst, MessageConst {
	DialogPane dpane = null;
	Alert alert = null;
	public Optional<ButtonType> buttonType = null;
	static Logger logger = Logger.getLogger(Messagebox.class.getName());
	static ImageView icon = new BasImage("error.png").getImageView(48, 48);

	public static void Error(Stage stage, String errMsg) {
		Messagebox aot = new Messagebox( stage , AlertType.ERROR , errMsg  , ButtonType.YES);
		aot.setWidth(MESSAGE_WIDTH);
		aot.dpane.setGraphic(icon);
		ButtonType button  =  aot.getResult().orElse( ButtonType.CANCEL );
		if( button.getText().equals("はい") ) {
			return;							 
		}
	}

	public static void Info(Stage stage, String errMsg) {
		Messagebox aot = new Messagebox( stage , AlertType.INFORMATION , errMsg  , ButtonType.YES);
		aot.setWidth(MESSAGE_WIDTH);
		ButtonType button  =  aot.getResult().orElse( ButtonType.CANCEL );
		if( button.getText().equals("はい") ) {
			return;							 
		}
	}

	public static boolean Confirmation(Stage stage, String errMsg) {
		Messagebox aot = new Messagebox( stage , AlertType.CONFIRMATION , errMsg  , ButtonType.YES, ButtonType.CANCEL);
		aot.setWidth(MESSAGE_WIDTH);
		ButtonType button  =  aot.getResult().orElse( ButtonType.CANCEL );
		if( button.getText().equals("はい") ) {
			return true;							 
		} else {
			return false;
		}
	}

	private Messagebox(Stage stage , AlertType alertType , String message , ButtonType b1 ) {
		super(StageStyle.UTILITY);
		logger.log(Level.FINE,message);
		System.out.println(message);
		alert = new Alert(alertType , message , b1 );
		alert.setWidth(MESSAGE_WIDTH);
		this.setOnTop();
		this.setPosition( stage );
	}

	private Messagebox(Stage stage , AlertType alertType , String message , ButtonType b1, ButtonType b2 ) {
		super(StageStyle.UTILITY);
		logger.log(Level.FINE,message);
		System.out.println(message);
		alert = new Alert(alertType , message , b1 , b2 );
		alert.setWidth(MESSAGE_WIDTH);
		this.setOnTop();
		this.setPosition( stage );
	}

	/**位置を親STAGEの中心にする*/
	private void setPosition( Stage stage ){
		if(stage==null){ return; }
		//this.setX( stage.getX() + stage.getWidth()/2. -dpane.getPrefWidth()/2. );
		//this.setY( stage.getY() + stage.getHeight()/2. -dpane.getPrefHeight()/2. );
		return;
	}


	/**常に前面に表示*/
	private void setOnTop(){
		alert.getDialogPane().setPrefSize(500, 200);
		dpane = alert.getDialogPane();
		for (ButtonType buttonType : dpane.getButtonTypes()) {
			ButtonBase button = (ButtonBase) dpane.lookupButton(buttonType);
			button.setOnAction(evt -> {
				dpane.setUserData(buttonType);
				this.close();
			});
		}
		dpane.getScene().setRoot(new Group());
		dpane.setPadding(new Insets(10, 0, 10, 0));
		Scene scene = new Scene(dpane);
		this.setScene(scene);
		this.initModality(Modality.APPLICATION_MODAL);
		this.setAlwaysOnTop(true);
		this.setResizable(false);
		return;
	}

	/**結果を返す*/
	private Optional<ButtonType> getResult(){
		this.showAndWait();
		//System.out.println("result: "+result.orElse(null));
		buttonType = Optional.ofNullable((ButtonType) dpane.getUserData());
		return buttonType ;
	}

}
