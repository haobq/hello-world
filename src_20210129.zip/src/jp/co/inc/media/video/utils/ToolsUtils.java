package jp.co.inc.media.video.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.MessageConst;

/**
 * 概要：utilityクラスです。
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class ToolsUtils implements BasConst{

	/**
	 *動画からサムネイル画像を取得する
	 * @param inputfile
	 * @param startTime
	 * @param imgNo
	 * @param outputfile
	 * @return
	 */
	public static List<String> MovieCatchImage(String inputfile,String startTime,String imgNo,String outputfile)  throws IOException{

		List<String> parm = new ArrayList<String>();
		parm.add("-y");
		if (imgNo.equals(PANE_IMAGE_NAME1) || imgNo.equals(PANE_IMAGE_NAME2)) {
			parm.add("-ss");
		}else if (imgNo.equals(PANE_IMAGE_NAME3)) {
			parm.add("-sseof");
		}else {
			return null;
		}
		parm.add(startTime);
		parm.add("-i");
		parm.add(inputfile.trim());
		parm.add("-vframes");
		parm.add("1");
		parm.add("-vcodec");
		parm.add("png");
		parm.add(outputfile);
		List<String> processExeRe = new ArrayList<String>();
		try {
			processExeRe = ProcessExecutor(parm);
		} catch (IOException e) {
			e.printStackTrace();
			throw new IOException(MessageConst.E0030);
		}

		return processExeRe;
	}
	/**
	 * ffmpeg 命令実行
	 * @param parm
	 * @return
	 * @throws IOException
	 */
	public static List<String> ProcessExecutor(List<String> parm ) throws IOException{

		String tools = null;
		//OS別ffmpeg命令を選択
		if (OSDetector.isMac()) {
			//Macの場合はこちら
			tools= toolsPath+"mac64/ffmpeg";
		}else if (OSDetector.isWindows()) {
			// Windowsの場合はこちら
			tools = toolsPath+"win64/ffmpeg.exe";
		}else {
			System.out.println("ffmpegインストールされません。");
			return null;
		}

		List<String> cmd = new ArrayList<String>();
		cmd.add(tools);
		//変数を追加
		for(String s : parm){
			cmd.add(s.trim());
		}

		System.out.println(cmd);
		// 結果を受け取る
		List<String> resultStream = new ArrayList<String>();
		try {
			ProcessBuilder p = new ProcessBuilder(cmd);
			p.redirectErrorStream(true);
			// プロセスを開始する
			Process process = p.start();
			try (BufferedReader r = new BufferedReader(
					new InputStreamReader(process.getInputStream(), Charset.defaultCharset()))) {
				String line;
				while ((line = r.readLine()) != null) {
					resultStream.add(line);
				}
			}
			process.waitFor();
			resultStream.add(String.valueOf(process.exitValue()));
			process = null;
			System.gc();
		} catch (InterruptedException e) {
			e.printStackTrace();
			throw new IOException(MessageConst.E0030);
		}
		return resultStream;
	}

	/**
	 * 文字列時間を数字時間に変更する
	 * @param period
	 * @return 数字時間秒
	 */
	public static double dateParseRegExp(String period) {
		String time[] = period.split(":");
		if (time.length==3) {
	        return Double.parseDouble(time[0]) * 3600L
	            + Double.parseDouble(time[1]) * 60
		            + Double.parseDouble((time[2])) ;
	    } else {
	        throw new IllegalArgumentException("Invalid format " + period);
	    }
	}

	/**
	 * 全角文字は２桁、半角文字は１桁として文字数をカウントする
	 * @param str 対象文字列
	 * @return 文字数
	 */
	public static int getHan1Zen2(String str) {

	  //戻り値
	  int ret = 0;

	  //全角半角判定
	  char[] c = str.toCharArray();
	  for(int i=0;i<c.length;i++) {
	    if(String.valueOf(c[i]).getBytes().length <= 1){
	      ret += 1; //半角文字なら＋１
	    }else{
	      ret += 2; //全角文字なら＋２
	    }
	  }

	  return ret;
	}
	/**
	 * 日付の妥当性チェックを行います。
	 * 指定した日付文字列（yyyy/MM/dd or yyyy-MM-dd）が
	 * カレンダーに存在するかどうかを返します。
	 * @param strDate チェック対象の文字列
	 * @return 存在する日付の場合true
	 */
	public static boolean checkDate(String strDate) {
		if (strDate.equals("")) {
			return true;
		}
		strDate = strDate.replace('-', '/');
		DateFormat format = DateFormat.getDateInstance();
		// 日付/時刻解析を厳密に行うかどうかを設定する。
		format.setLenient(false);
		try {
			format.parse(strDate);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 時間を取得する
	 * @param seconds
	 * @return
	 */
	public static String calculateTime(long seconds) {
	    long hours = TimeUnit.SECONDS.toHours(seconds);
	    long minute = TimeUnit.SECONDS.toMinutes(seconds) -
	                  TimeUnit.HOURS.toMinutes(TimeUnit.SECONDS.toHours(seconds));
	    long second = TimeUnit.SECONDS.toSeconds(seconds) -
	                  TimeUnit.MINUTES.toSeconds(TimeUnit.SECONDS.toMinutes(seconds));
	    String infoStr = String.format("%02d", (int)hours)+":"+String.format("%02d", (int)minute)+":"+String.format("%02d", (int)second);
	    return infoStr;

	}
}
