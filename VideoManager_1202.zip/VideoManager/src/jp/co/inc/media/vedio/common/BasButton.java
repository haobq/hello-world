package jp.co.inc.media.vedio.common;

import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class BasButton extends Button implements BasConst, MessageConst {

	private int width = ICON_SIZE;
	private int height = ICON_SIZE;
	private ImageView folderIV = new BasImage("folder.png").getImageView(width, height);
	private ImageView folder_disable = new BasImage("folder_disable.png").getImageView(width, height);

	private ImageView sendIV = new BasImage("send.png").getImageView(width, height);
	private ImageView send_disable = new BasImage("send_disable.png").getImageView(width, height);

	private ImageView deleteIV = new BasImage("delete.png").getImageView(width, height);
	private ImageView delete_disable = new BasImage("delete_disable.png").getImageView(width, height);

	private ImageView searchIV = new BasImage("search.png").getImageView(width, height);
	private ImageView search_disable = new BasImage("search_disable.png").getImageView(width, height);

	private ImageView playIV = new BasImage("play.png").getImageView(width, height);
	private ImageView play_disable = new BasImage("play_disable.png").getImageView(width, height);

	private ImageView pauseIV = new BasImage("pause.png").getImageView(width, height);
	private ImageView pause_disable = new BasImage("pause_disable.png").getImageView(width, height);

	private ImageView stopIV = new BasImage("stop.png").getImageView(width, height);
	private ImageView stop_disable = new BasImage("stop_disable.png").getImageView(width, height);

	public BasButton(String title) {
		setText(title);
	}

	public BasButton(String title, String Id) {
		setId(Id);
	}

	public BasButton(String imgFile, int width, int height) {
		ImageView imgView = new BasImage(imgFile).getImageView(width, height);
		setGraphic(imgView);
	}

	public BasButton(String imgFile, int width, int height, String title) {
		ImageView imgView = new BasImage(imgFile).getImageView(width, height);
		setGraphic(imgView);
		setText(title);
	}

	public void setToDisable(boolean enable) {
		setDisable(enable);
		if (enable == true) {
			if (getText() != null) {
				switch (getText()) {
				case BUTTON_FOLD_SELECT:
					setGraphic(folderIV);
					break;
				case BUTTON_SEND:
					setGraphic(sendIV);
					break;
				case BUTTON_DELETE:
					setGraphic(deleteIV);
					break;
				default:
					break;
				}
				;
			}
			if (getText() == null && getId() != null) {
				switch (getId()) {
				case BUTTON_ID_SEARCH:
					setGraphic(searchIV);
					break;
				case BUTTON_ID_PLAY:
					setGraphic(playIV);
					break;
				case BUTTON_ID_PAUSE:
					setGraphic(pauseIV);
					break;
				case BUTTON_ID_STOP:
					setGraphic(stopIV);
					break;
				default:
					break;
				}
			}
		} else {
			if (getText() != null) {
				switch (getText()) {
				case BUTTON_FOLD_SELECT:
					setGraphic(folder_disable);
					break;
				case BUTTON_SEND:
					setGraphic(send_disable);
					break;
				case BUTTON_DELETE:
					setGraphic(delete_disable);
					break;
				default:
					break;
				}
				;
			}
			if (getText() == null && getId() != null) {
				switch (getId()) {
				case BUTTON_ID_SEARCH:
					setGraphic(search_disable);
					break;
				case BUTTON_ID_PLAY:
					setGraphic(play_disable);
					break;
				case BUTTON_ID_PAUSE:
					setGraphic(pause_disable);
					break;
				case BUTTON_ID_STOP:
					setGraphic(stop_disable);
					break;
				default:
					break;
				}
			}
		}
	}
}