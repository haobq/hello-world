package jp.co.inc.media.vedio.test;

import java.awt.Dimension;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class CameraFx extends Application {
	Stage primaryStage;
	private BorderPane root = new BorderPane();
	private MyWebcaomPane webCamPane = new MyWebcaomPane();
	Label label = new Label("テスト");
	Canvas canvas=new Canvas(176,144);

	@Override
	public void start(Stage primaryStage) throws Exception {
		this.primaryStage = primaryStage;
		root.setCenter(webCamPane);
		root.setTop(label);
		root.setBottom(canvas);
		webCamPane.app=this;
		label.setStyle("-fx-font-size: 20pt; -fx-color: black;");
		primaryStage.setScene(new Scene(root));
		Dimension size = webCamPane.webCam.getViewSize();
		primaryStage.setWidth( webCamPane.cameraSize.width << 2 );
		primaryStage.setHeight(webCamPane.cameraSize.height<< 2 );
		primaryStage.centerOnScreen();
		primaryStage.show();
	}

	public static void main(String... args) throws Exception {
		Application.launch(args);
	}
}