package jp.co.inc.media.vedio.test;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import javax.imageio.ImageIO;

import com.github.sarxos.webcam.Webcam;

import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.concurrent.Task;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.Pane;

class MyWebcaomPane extends Pane {
	CameraFx app;//作品全体参照用

	ImageView imageViewWebcam = new ImageView();

	Webcam webCam = null;//カメラオブジェクト
	BufferedImage img;//カメラから取得したイメージ
	BufferedImage imgRev;//上記の左右反転イメージ

	Dimension cameraSize;//上記の左右反転イメージ描画用のJavaFxイメージビュー
	ObjectProperty<Image> imageProperty = new SimpleObjectProperty<Image>();//cameraViewカメラアクセス用

	private boolean stopCamera = false;

	MyWebcaomPane(){
		this.getChildren().addAll(imageViewWebcam);
		initCamera();
	}

	//カメラの初期化
	void initCamera(){
		//カメラ名列挙
		List <Webcam> webcomList = Webcam.getWebcams();
		for (Webcam webcam : webcomList) {
			System.out.println(webcam.getName());
		}
		webCam = webcomList.get(0);
		webCam.open();

		this.cameraSize = webCam.getViewSize();

		double height = ((int)cameraSize.getHeight())<<2;//4倍
		double width = ((int)cameraSize.getWidth())<<2;

		imageViewWebcam.setFitHeight(height);
		imageViewWebcam.setFitWidth(width);

		System.out.printf("サイズカメラ:(%d,%d)\n", cameraSize.width, cameraSize.height);

		startWebCamStream();

		imageViewWebcam.setOnMouseMoved(e->{
			int x = (int) e.getX();
			int y = (int) e.getY();
			int color = imgRev.getRGB(x>>2, y>>2);
			String s = String.format("(%3d,%3d)色#%07X", x,y,color&0x0FFFFFF);
			app.label.setText(s);
		});
	}

	protected void startWebCamStream() {

		stopCamera = false;

		Task<Void> task = new Task<Void>() {

			@Override
			protected Void call() throws Exception {

				final AtomicReference<WritableImage> ref = new AtomicReference<>();

				while (!stopCamera) {//カメラを撮る繰り返し
					try {
						img = webCam.getImage();//撮ったイメージを得る
						if (img != null) {

							imgRev = createMirrorImage(img);//イメージの左右逆転

							ImageIO.write(imgRev, "JPG", new File("testfx.jpg"));//ファイルに残す

							ref.set(SwingFXUtils.toFXImage(imgRev, ref.get()));
							img.flush();

							Platform.runLater(new Runnable() {

								@Override
								public void run() {
									imageProperty.set(ref.get());//イメージビューへセット

									GraphicsContext gc =app.canvas.getGraphicsContext2D();
									gc.drawImage(SwingFXUtils.toFXImage(img,null), 0, 0);
								}
							});
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				return null;
			}
		};

		Thread th = new Thread(task);
		th.setDaemon(true);
		th.start();//スレッド実行（上記callを実行）
		imageViewWebcam.imageProperty().bind(imageProperty);//imageProperty変更をイメージビュー反映する設定
	}

	// 鏡に移ったイメージを生成して返す。
	public static BufferedImage createMirrorImage(BufferedImage img){
		int width = img.getWidth();
		int height = img.getHeight();
		int size = width * height;
		int []buf = new int[ size ];
		img.getRGB(0, 0, width, height, buf, 0, width);//イメージを配列に変換

		//bufのイメージ配列で、左右を変換する。
		int x1, x2, temp;
		for(int y = 0; y < size; y+=width){
			x1 = 0;
			x2 = width -1;
			while(x1 < x2){// 交換の繰り返し
				temp = buf[y+x1];
				buf[y+x1++] = buf[y+x2];
				buf[y+x2--] = temp;
			}
		}
		BufferedImage img2= new BufferedImage(width, height, BufferedImage.TYPE_4BYTE_ABGR);
		img2.setRGB(0, 0, width, height, buf, 0, width);//配列をイメージに書き込む
		return img2;
	}
}