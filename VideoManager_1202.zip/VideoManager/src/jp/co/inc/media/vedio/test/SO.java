package jp.co.inc.media.vedio.test;
import java.awt.AWTException;
import java.awt.DisplayMode;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;

import javax.swing.SwingUtilities;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.Window;

public class SO extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        final Pane pane = new StackPane();

//		final Rectangle2D bounds = Screen.getPrimary().getBounds();
//		initStage.setScene(splashScene);
//		initStage.setX(bounds.getMinX() + bounds.getWidth() / 2 - SPLASH_WIDTH / 2);
//		initStage.setY(bounds.getMinY() + bounds.getHeight() / 2 - SPLASH_HEIGHT / 2);
//		initStage.initStyle(StageStyle.TRANSPARENT);
//		initStage.setAlwaysOnTop(true);
//		initStage.show();
//

		 Rectangle2D primaryScreenBounds = Screen.getPrimary().getBounds();

		 //set Stage boundaries to visible bounds of the main screen
		 stage.setX(primaryScreenBounds.getMinX());
		 stage.setY(primaryScreenBounds.getMinY());
		 stage.setWidth(primaryScreenBounds.getWidth());
		 stage.setHeight(primaryScreenBounds.getHeight());

		 stage.show();


        Scene scene = new Scene(pane, stage.getWidth(), stage.getHeight());
        stage.setScene(scene);
        Button b = new Button("Snap");
        final ImageView iv = new ImageView();
        iv.fitWidthProperty().bind(pane.widthProperty());
        iv.fitHeightProperty().bind(pane.heightProperty());
        pane.getChildren().add(iv);
        pane.getChildren().add(b);
        b.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        doSnap(iv, scene);
                    }
                });
            }
        });
        stage.show();
    }

    protected void doSnap(final ImageView iv, Scene scene) {
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice[] gs = ge.getScreenDevices();
    	Rectangle virtualBounds = new Rectangle();

        for (int j = 0; j < gs.length; j++) {

            GraphicsDevice gd = gs[j];

            GraphicsConfiguration[] gc = gd.getConfigurations();

            for (int i=0; i < gc.length; i++) {

                virtualBounds = virtualBounds.union(gc[i].getBounds());

           		System.out.println("virtualBounds.getX():" + gc[i]);
           		System.out.println("virtualBounds.getX():" + virtualBounds.getX());
        		System.out.println("virtualBounds.getY():" + virtualBounds.getY());

            }

        }


        Robot robot = null;
        try {
            robot = new java.awt.Robot();
        } catch (AWTException e) {
            e.printStackTrace();
            return;
        }

		System.out.println("scene.getX():" + scene.getX());
		System.out.println("scene.getY():" + scene.getY());

		Window w = scene.getWindow();


        DisplayMode mode = gs[0].getDisplayMode();
        Rectangle bounds = new Rectangle((int)scene.getX(), (int)scene.getY(), (int)(scene.getWidth()+7.333333492279053), (int)(scene.getHeight()+30.0));
        final BufferedImage bi = robot.createScreenCapture(bounds);
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                Image im = SwingFXUtils.toFXImage(bi, null);
                iv.setImage(im);
            }
        });
    }

    public static void main(String[] args) {
        System.setProperty("javafx.macosx.embedded", "true");
        java.awt.Toolkit.getDefaultToolkit();
        Application.launch(args);
    }

}