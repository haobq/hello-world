package jp.co.inc.media.vedio.test;

import java.io.File;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Video extends Application{
     private static File file = new File("C:\\tmp1\\sample2.mp4");
     private static final String MEDIA_URL = file.toURI().toString();

     public static void main(String[] args) throws Exception{
               launch(args);
     }

     @Override
     public void start(Stage stage) throws Exception {

     //goes to user Directory


    //Converts media to string URL
    Media media = new Media(MEDIA_URL);
    MediaPlayer player = new MediaPlayer(media);
    MediaView viewer = new MediaView(player);

    //change width and height to fit video
    DoubleProperty width = viewer.fitWidthProperty();
    DoubleProperty height = viewer.fitHeightProperty();
    width.bind(Bindings.selectDouble(viewer.sceneProperty(), "width"));
    height.bind(Bindings.selectDouble(viewer.sceneProperty(), "height"));
    viewer.setPreserveRatio(true);


    StackPane root = new StackPane();
    root.getChildren().add(viewer);

    //set the Scene
    Scene scenes = new Scene(root, 500, 500, Color.BLACK);
    stage.setScene(scenes);
    stage.setTitle("Riddle Game");
    stage.setFullScreen(true);
    stage.show();
  //  player.play();
  }
}