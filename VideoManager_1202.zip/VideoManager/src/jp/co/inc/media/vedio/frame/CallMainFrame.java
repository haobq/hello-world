package jp.co.inc.media.vedio.frame;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.StandardOpenOption;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import jp.co.inc.media.vedio.common.BasConst;
import jp.co.inc.media.vedio.common.BasFrame;
import jp.co.inc.media.vedio.common.BasImage;
import jp.co.inc.media.vedio.common.MessageConst;
import jp.co.inc.media.vedio.components.LoginDialog;
import jp.co.inc.media.vedio.logic.VedioUploadServiceLogic;
import jp.co.inc.media.vedio.service.LoginRespone;
import jp.co.inc.media.vedio.utils.FileProperty;
import jp.co.inc.media.vedio.utils.Messagebox;

public class CallMainFrame extends Application implements BasConst, MessageConst {
	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(BasFrame.class.getName());
	public static BasFrame callBaseFrm;
	private Pane splashLayout;
	private Label progressText;
	public static Stage mainStage;
	public static Stage loginDialog;

	@Override
	public void init() throws Exception {
		GridPane gridpane = new GridPane();
		gridpane.setPadding(new Insets(5));
		gridpane.setHgap(5);
		gridpane.setVgap(5);
		FileProperty filePro = new FileProperty(verFilePath);

		String ver = filePro.getProperty("Ver");
		String update = filePro.getProperty("Date");

		Label titleNameLbl = new Label("画像アップローダー");
		titleNameLbl.setStyle(RUNTITLE_STYLE);
		titleNameLbl.setAlignment(Pos.CENTER_RIGHT);
		BorderPane titlePane = new BorderPane();
		titlePane.setCenter(titleNameLbl);

		Label verNameLbl = new Label("バージョン: ");
		gridpane.add(verNameLbl, 0, 1);

		Label updatanameLbl = new Label("最新更新日: ");
		gridpane.add(updatanameLbl, 0, 2);

		Label verVauleLbl = new Label(ver);
		gridpane.add(verVauleLbl, 1, 1);

		Label updataVauleLbl = new Label(update);
		gridpane.add(updataVauleLbl, 1, 2);

		ImageView splash = new BasImage("mast1.gif").getImageView(371, 68);
		progressText = new Label("起動中 . . .");
		splashLayout = new VBox();
		splashLayout.getChildren().addAll(splash, titlePane, gridpane, progressText);

		progressText.setAlignment(Pos.CENTER);
		splashLayout.setStyle(SPLASH_STYLE);
		splashLayout.setEffect(new DropShadow());
	}

	/**
	 * 画面スタート
	 * @param primaryStage システムのステージ
	 * @throws Exception 起動異常
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		Image img = new Image(getClass().getResourceAsStream("media.jpg"));
		primaryStage.getIcons().add(img);

		mainStage = primaryStage;
		final Task<Void> runTask = new Task<Void>() {
			@Override
			protected Void call() throws InterruptedException, Exception {
				updateMessage("起動中 . . .");
				Thread.sleep(2000);
				return null;
			}
		};
		showSplash(
				mainStage,
				runTask,
				() -> showMainStage(runTask));
		new Thread(runTask).start();
	}

	private void showMainStage(Task<Void> runTask) {
		mainStage = new Stage(StageStyle.DECORATED);
		try {
			loginDialog = new LoginDialog(new BasFrame(), mainStage, LOGIN_TITLE, 350, 200);
			loginDialog.sizeToScene();
			loginDialog.show();
			loginDialog.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {

					System.out.println("loginDialog close");
					// ログアウト
					logout();
				}
			});

			// 終了 イベント登録
			mainStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {

					if (BasFrame.btnSend.isDisable() && BasFrame.btnSend.isVisible()) {
						// 閉じるを阻止！
						event.consume();

					} else {

						// ログアウト
						logout();
						loginDialog.close();

						Platform.exit();
						Thread start = new Thread(new Runnable() {
							@Override
							public void run() {
								// メモリ解放
								BasFrame.mediaSetClear();

								// 画面閉じる
								System.exit(0);
							}
						});
						start.start();
					}

				}
			});
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			String repl = "VedioUploadService.BizException:";
			if (e.getMessage().indexOf(repl) > 0) {
				int beginIndex = e.getMessage().indexOf(repl);
				String errMsg = e.getMessage().substring(beginIndex);
				int endIndex = errMsg.indexOf("。");
				errMsg = errMsg.substring(0, endIndex).replaceAll(repl, "");
				System.out.println("errMsg:" + errMsg);

				// 文字置き換え
				if (e.toString().indexOf(FAILED_TO_CREATE_SERVICE) > 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE) > 0) {
					Messagebox.Error(ServiceConstructionException);

				} else {

					Messagebox.Error(errMsg);
				}

				return;
			} else {

				// 文字置き換え
				if (e.toString().indexOf(FAILED_TO_CREATE_SERVICE) > 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE) > 0) {
					Messagebox.Error(ServiceConstructionException);

				} else {

					Messagebox.Error(e.getMessage());
				}

				return;
			}
		}
	}

	/**
	 * ログアウト
	 */
	public static void logout() {
		try {
			LoginRespone loginReponse = VedioUploadServiceLogic.getLoginReponse();
			if (loginReponse != null && loginReponse.getCert().getMediaAuth() != null) {
				boolean _logout__return = VedioUploadServiceLogic.getPort().logout(loginReponse.getCert());
				System.out.println("logout.result=" + _logout__return);
			}

		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			Messagebox.Error(E0001);
		}
	}

	private void showSplash(
			final Stage initStage,
			Task<?> task,
			InitCompletionHandler initCompletionHandler) {
		progressText.textProperty().bind(task.messageProperty());
		task.stateProperty().addListener((observableValue, oldState, newState) -> {
			if (newState == Worker.State.SUCCEEDED) {
				initStage.toFront();
				FadeTransition fadeSplash = new FadeTransition(Duration.seconds(1.2), splashLayout);
				fadeSplash.setFromValue(1.0);
				fadeSplash.setToValue(0.0);
				fadeSplash.setOnFinished(actionEvent -> initStage.hide());
				fadeSplash.play();

				initCompletionHandler.complete();
			} // todo add code to gracefully handle other task states.
		});

		Scene splashScene = new Scene(splashLayout, Color.TRANSPARENT);
		final Rectangle2D bounds = Screen.getPrimary().getBounds();
		initStage.setScene(splashScene);
		initStage.setX(bounds.getMinX() + bounds.getWidth() / 2 - SPLASH_WIDTH / 2);
		initStage.setY(bounds.getMinY() + bounds.getHeight() / 2 - SPLASH_HEIGHT / 2);
		initStage.initStyle(StageStyle.TRANSPARENT);
		initStage.setAlwaysOnTop(true);
		initStage.show();
	}

	public interface InitCompletionHandler {
		void complete();
	}

	/**
	 * メイン
	 * @param args 起動パラメータ
	 * @throws IOException システム起動異常
	 */
	public static void main(String[] args) throws IOException {
		// 二重起動防止のチェックを行う
		File lockFile = new File(lockPath);
		FileOutputStream fos = new FileOutputStream(lockFile);
		try {
			FileChannel fc = FileChannel.open(lockFile.toPath(), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
			FileLock lock = fc.tryLock();
			if (lock == null) {

				// 二重起動防止
				Platform.runLater(
						() -> {
							Messagebox.Error(E0000);
							System.exit(-1);
						});

			} else {
				// Handlerを生成しloggerに登録
				FileHandler fHandler = null;
				try {
					fHandler = new FileHandler("log/VedioManager.log", true);
					// LogManagerのインスタンスを生成しlogging.propertiesを読み込む
					LogManager manager = LogManager.getLogManager();
					manager.readConfiguration(new FileInputStream("conf/logging.properties"));
				} catch (SecurityException | IOException e) {
					e.printStackTrace();
					Platform.runLater(
							() -> {
								Messagebox.Error(E0001);
								System.exit(-1);
							}

					);
				}
				fHandler.setFormatter(new SimpleFormatter());
				launch(args);
			}

		} finally {
			fos.close();
		}
	}
}
