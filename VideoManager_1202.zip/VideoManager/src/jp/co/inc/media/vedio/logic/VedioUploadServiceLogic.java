package jp.co.inc.media.vedio.logic;

import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.namespace.QName;

import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import jp.co.inc.media.vedio.common.BasConst;
import jp.co.inc.media.vedio.common.BasFrame;
import jp.co.inc.media.vedio.common.MessageConst;
import jp.co.inc.media.vedio.components.HospitalSelect;
import jp.co.inc.media.vedio.frame.CallMainFrame;
import jp.co.inc.media.vedio.service.ArrayOfClinicReponse;
import jp.co.inc.media.vedio.service.ArrayOfFacilityReponse;
import jp.co.inc.media.vedio.service.ClinicReponse;
import jp.co.inc.media.vedio.service.FacilityReponse;
import jp.co.inc.media.vedio.service.LoginRespone;
import jp.co.inc.media.vedio.service.VedioUploadService;
import jp.co.inc.media.vedio.service.VedioUploadServiceSoap;
import jp.co.inc.media.vedio.utils.Messagebox;

public class VedioUploadServiceLogic extends VedioUploadService implements BasConst, MessageConst {
	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(VedioUploadServiceLogic.class.getName());
	// サービス
	public static QName SERVICE_NAME = new QName("http://vedio.media.inc.co.jp/service", "VedioUploadService");
	// レスポンス
	private static LoginRespone loginReponse = null;
	// ポート
	private static VedioUploadServiceSoap port = null;
	// 医院ID
	private static String hosp_id = null;

	public static Stage hospitalSelect = new Stage();

	/**
	 * @return hosp_id
	 */
	public static String getHosp_id() {
		return hosp_id;
	}

	/**
	 * @param hosp_id セットする hosp_id
	 */
	public static void setHosp_id(String hosp_id) {
		VedioUploadServiceLogic.hosp_id = hosp_id;
	}

	/**
	 * @return port
	 */
	public static VedioUploadServiceSoap getPort() {
		return port;
	}

	/**
	 * @param port セットする port
	 */
	public static void setPort(VedioUploadServiceSoap port) {
		VedioUploadServiceLogic.port = port;
	}

	/**
	 * @return loginReponse
	 */
	public static LoginRespone getLoginReponse() {
		return loginReponse;
	}

	/**
	 * @param loginReponse セットする loginReponse
	 */
	public static void setLoginReponse(LoginRespone loginReponse) {
		VedioUploadServiceLogic.loginReponse = loginReponse;
	}

	public VedioUploadServiceLogic() {
		final URL wsdlURL = VedioUploadService.WSDL_LOCATION;
		final VedioUploadService service = new VedioUploadService(wsdlURL, SERVICE_NAME);
		// port設定
		setPort(service.getVedioUploadServiceSoap12());
	}

	public LoginRespone LoginManager(BasFrame callBaseFrm, Stage owner, String groupId, String userId,
			String paasword) {
		try {

			// 初期化
			setHosp_id(null);
			// ログレスポンス設定
			setLoginReponse(getPort().login(groupId, userId, paasword, ""));
			String hosp_id = getLoginReponse().getCert().getHospId();
			// 訪問先取得
			ArrayOfClinicReponse clinicReponse = getLoginReponse().getClinicList();
			if ("".equals(hosp_id) && !clinicReponse.getClinicReponse().isEmpty()) {
				// ログイン画面非表示
				CallMainFrame.loginDialog.hide();

				if (clinicReponse.getClinicReponse().size() > 1) {
					// 医院選択画面表示
					hospitalSelect = new HospitalSelect(callBaseFrm, owner, HOSPITAL_SELECT_TITLE, clinicReponse,
							groupId, userId, paasword, 300, 150);
					hospitalSelect.sizeToScene();
					hospitalSelect.show();
					hospitalSelect.setOnCloseRequest(new EventHandler<WindowEvent>() {
						@Override
						public void handle(WindowEvent event) {
							System.out.println("hospitalSelect close");
							// ログアウト
							CallMainFrame.logout();
						}
					});
				} else {
					// 医院ID設定
					setHosp_id(clinicReponse.getClinicReponse().get(0).getHospId());

					getLogInfo(clinicReponse, groupId, userId, paasword);
				}
			}

		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			String repl = "VedioUploadService.BizException:";
			if (e.getMessage().indexOf(repl) > 0) {
				int beginIndex = e.getMessage().indexOf(repl);
				String errMsg = e.getMessage().substring(beginIndex);
				int endIndex = errMsg.indexOf("。");
				errMsg = errMsg.substring(0, endIndex).replaceAll(repl, "");
				System.out.println("errMsg:" + errMsg);

				// 文字置き換え
				if (e.toString().indexOf(FAILED_TO_CREATE_SERVICE) > 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE) > 0) {
					Messagebox.Error(ServiceConstructionException);
				} else {
					Messagebox.Error(errMsg);
				}
				return null;
			} else {
				// 文字置き換え
				if (e.toString().indexOf(FAILED_TO_CREATE_SERVICE) > 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE) > 0) {
					Messagebox.Error(ServiceConstructionException);

				} else {

					Messagebox.Error(e.getMessage());
				}
				return null;
			}
		}
		return getLoginReponse();
	}

	/**
	 * ログイン情報取得
	 * @param pa パネル
	 * @param mediafile メディアファイル
	 */
	public static LoginRespone getLogInfo(ArrayOfClinicReponse clinicReponse, String groupId, String userId,
			String paasword) {
		logger.log(Level.INFO, "START -getLogInfo");

		try {

			if (getHosp_id() != null) {
				// レスポンス設定
				setLoginReponse(getPort().login(groupId, userId, paasword, getHosp_id()));

				System.out.println("==============認証情報==========");
				System.out.println("GroupId:" + loginReponse.getCert().getGroupId());
				System.out.println("HospId:" + loginReponse.getCert().getHospId());
				System.out.println("UserId:" + loginReponse.getCert().getUserId());
				System.out.println("MediaAuth:" + loginReponse.getCert().getMediaAuth());
				ArrayOfClinicReponse clinic = loginReponse.getClinicList();
				System.out.println("==============医院情報==========");
				for (ClinicReponse tmp : clinic.getClinicReponse()) {
					System.out.println("HospId:" + tmp.getHospId());
					System.out.println("HospName:" + tmp.getHospName());
				}
				ArrayOfFacilityReponse faci = loginReponse.getFacilityList();
				System.out.println("==============訪問先情報==========");
				for (FacilityReponse tmp : faci.getFacilityReponse()) {
					System.out.println("VisitId:" + tmp.getVisitId());
					System.out.println("VisitName：" + tmp.getVisitName());
				}
			}

		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			String repl = "VedioUploadService.BizException:";
			if (e.getMessage().indexOf(repl) > 0) {
				int beginIndex = e.getMessage().indexOf(repl);
				String errMsg = e.getMessage().substring(beginIndex);
				int endIndex = errMsg.indexOf("。");
				errMsg = errMsg.substring(0, endIndex).replaceAll(repl, "");
				System.out.println("errMsg:" + errMsg);

				// 文字置き換え
				if (e.toString().indexOf(FAILED_TO_CREATE_SERVICE) > 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE) > 0) {
					Messagebox.Error(ServiceConstructionException);
				} else {
					Messagebox.Error(errMsg);
				}
				return null;

			} else {
				// 文字置き換え
				if (e.toString().indexOf(FAILED_TO_CREATE_SERVICE) > 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE) > 0) {
					Messagebox.Error(ServiceConstructionException);

				} else {

					Messagebox.Error(e.getMessage());
				}
				return null;
			}

		}
		logger.log(Level.INFO, "END -getLogInfo");
		return getLoginReponse();

	}

}
