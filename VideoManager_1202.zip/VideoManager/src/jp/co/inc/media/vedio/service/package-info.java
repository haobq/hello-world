@javax.xml.bind.annotation.XmlSchema(namespace = "http://vedio.media.inc.co.jp/service", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package jp.co.inc.media.vedio.service;
