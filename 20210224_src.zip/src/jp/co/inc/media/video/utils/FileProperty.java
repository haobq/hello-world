package jp.co.inc.media.video.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectOutputStream;

/**
 * 概要：ファイルプロパティのクラスです。
 * 
 * @version 1.0.0
 * @author HaoBuqian
 *
 */public class FileProperty {

	/** filepropertyのオブジェクト */
	private LfcProperties proFile = new LfcProperties();
	/** filepropertyのパス */
	private String strFileName;

	public FileProperty(String strFilePath) throws Exception {
		try {
			strFileName = strFilePath;
			FileInputStream in = new FileInputStream(strFilePath);
			proFile.load(in);
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Propertyの内容を読み． <BR>
	 * @param   strKey キー
	 * @return  String  Propertyの内容
	 */
	public String getProperty(String strKey) {
		return proFile.getProperty(strKey, "");
	}

	/**
	 * Propertyを設定する． <BR>
	 * @param   strKey キー
	 * @param  strValue  Propertyの内容
	 */
	public void setProperty(String strKey, String strValue) {
		proFile.setProperty(strKey, strValue);
	}

	public int getCount(String str) {
		int i = 0;
		int propCount = 0;
		boolean flag = true;

		while (flag) {
			String strTemp = str + i;
			flag = proFile.containsKey(strTemp);
			i = i + 1;
		}
		propCount = i - 1;
		return propCount;
	}

	/**
	 * FilePropertyを設定する． <BR>
	 * @throws Exception 保存異常
	 */
	public void storeProperty() throws Exception {
		try {
			FileOutputStream out = new FileOutputStream(strFileName);
			proFile.store(out, null);
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Section Title を設定する． <BR>
	 * @param ptitle パラメータの区分
	 * @throws Exception 保存異常
	 */
	public void setSection(String ptitle) throws Exception {
		try {
			boolean flag = true;
			BufferedReader br = new BufferedReader(new FileReader(strFileName));
			String s;
			while (br.ready()) {
				s = br.readLine();
				if (s.equals("[" + ptitle + "]")) {
					flag = false;
				}
			}

			if (flag) {
				FileOutputStream out = new FileOutputStream(strFileName, false);
				ObjectOutputStream p = new ObjectOutputStream(out);
				if (ptitle != null) {
					p.writeObject(ptitle);
					p.flush();
				}
				out.close();
				br.close();
			}
		} catch (Exception e) {
			throw e;
		}
	}
}
