package jp.co.inc.media.video.utils;

/**
 * 概要：格納動画ファイルフォルダと動画ファイルJSON管理クラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class FolderListBean {
	/**作業フォルダーパス */
	String folderPath ="";
	/**作業フォルダーのファイル情報の管理 JSONファイルパス*/
	String jsonfilePath = "";
//	/**予備1*/
//	private String prepare1 ="";
//	/**予備2*/
//	private String prepare2 ="";
//	/**予備3*/
//	private String prepare3 ="";
//	/**予備4*/
//	private String prepare4 ="";
//	/**予備5*/
//	private String prepare5 ="";
//	/**予備6*/
//	private String prepare6 ="";
//	/**予備7*/
//	private String prepare7 ="";
//	/**予備8*/
//	private String prepare8 ="";
//	/**予備9*/
//	private String prepare9 ="";
//	/**予備10*/
//	private String prepare10 ="";

	public FolderListBean() {
		folderPath = "";
		jsonfilePath = "";
//		prepare1 = "";
//		prepare2 = "";
//		prepare3 = "";
//		prepare4 = "";
//		prepare5 = "";
//		prepare6 = "";
//		prepare7 = "";
//		prepare8 = "";
//		prepare9 = "";
//		prepare10 = "";
	}

	/**
	 * 作業フォルダーパスを取得する
	 * @return 作業フォルダーパス
	 */
	public String getFolderPath() {
		return folderPath;
	}

	/**
	 * 作業フォルダーパスを設定する
	 * @param folderPath 作業フォルダーパス
	 */
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	/**
	 * 作業フォルダーのファイル情報の管理 JSONファイルパスを取得する
	 * @return 管理 JSONファイルパス
	 */
	public String getJsonfilePath() {
		return jsonfilePath;
	}

	/**
	 * 作業フォルダーのファイル情報の管理 JSONファイルパスを設定する
	 * @param jsonfilePath 管理 JSONファイルパス
	 */
	public void setJsonfilePath(String jsonfilePath) {
		this.jsonfilePath = jsonfilePath;
	}

//	/**
//	 *  予備1を取得する
//	 * @return 予備1
//	 */
//	public String getPrepare1() {
//		return prepare1;
//	}
//
//	/**
//	 *  予備1をセットする
//	 * @param prepare1 予備1
//	 */
//	public void setPrepare1(String prepare1) {
//		this.prepare1 = prepare1;
//	}
//
//	/**
//	 *  予備2を取得する
//	 * @return 予備2
//	 */
//	public String getPrepare2() {
//		return prepare2;
//	}
//
//	/**
//	 *  予備2をセットする
//	 * @param prepare2 予備2
//	 */
//	public void setPrepare2(String prepare2) {
//		this.prepare2 = prepare2;
//	}
//
//	/**
//	 *  予備3を取得する
//	 * @return 予備3
//	 */
//	public String getPrepare3() {
//		return prepare3;
//	}
//
//	/**
//	 *  予備3をセットする
//	 * @param prepare3 予備3
//	 */
//	public void setPrepare3(String prepare3) {
//		this.prepare3 = prepare3;
//	}
//
//	/**
//	 *  予備4を取得する
//	 * @return 予備4
//	 */
//	public String getPrepare4() {
//		return prepare4;
//	}
//
//	/**
//	 *  予備4をセットする
//	 * @param prepare4 予備4
//	 */
//	public void setPrepare4(String prepare4) {
//		this.prepare4 = prepare4;
//	}
//
//	/**
//	 *  予備5を取得する
//	 * @return 予備5
//	 */
//	public String getPrepare5() {
//		return prepare5;
//	}
//
//	/**
//	 *  予備5をセットする
//	 * @param prepare5 予備5
//	 */
//	public void setPrepare5(String prepare5) {
//		this.prepare5 = prepare5;
//	}
//
//	/**
//	 *  予備6を取得する
//	 * @return 予備6
//	 */
//	public String getPrepare6() {
//		return prepare6;
//	}
//
//	/**
//	 *  予備6をセットする
//	 * @param prepare6 予備6
//	 */
//	public void setPrepare6(String prepare6) {
//		this.prepare6 = prepare6;
//	}
//
//	/**
//	 *  予備7を取得する
//	 * @return 予備7
//	 */
//	public String getPrepare7() {
//		return prepare7;
//	}
//
//	/**
//	 *  予備7をセットする
//	 * @param prepare7 予備7
//	 */
//	public void setPrepare7(String prepare7) {
//		this.prepare7 = prepare7;
//	}
//
//	/**
//	 *  予備8を取得する
//	 * @return 予備8
//	 */
//	public String getPrepare8() {
//		return prepare8;
//	}
//
//	/**
//	 *  予備8をセットする
//	 * @param prepare8 予備8
//	 */
//	public void setPrepare8(String prepare8) {
//		this.prepare8 = prepare8;
//	}
//
//	/**
//	 *  予備9を取得する
//	 * @return 予備9
//	 */
//	public String getPrepare9() {
//		return prepare9;
//	}
//
//	/**
//	 *  予備9をセットする
//	 * @param prepare9 予備9
//	 */
//	public void setPrepare9(String prepare9) {
//		this.prepare9 = prepare9;
//	}
//
//	/**
//	 *  予備10を取得する
//	 * @return 予備10
//	 */
//	public String getPrepare10() {
//		return prepare10;
//	}
//
//	/**
//	 *  予備10をセットする
//	 * @param prepare10 予備10
//	 */
//	public void setPrepare10(String prepare10) {
//		this.prepare10 = prepare10;
//	}
}

