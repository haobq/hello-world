package jp.co.inc.media.video.utils;

import javafx.beans.property.StringProperty;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;

/**
 * 概要：メニュー作成のクラス
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class ClickableMenu extends Menu {

    private final Label label;

    /**
     * タイトルなしで新しいClickableMenuを作成.
     */
    public ClickableMenu() {
        this("");
    }

    /**
     * 指定されたタイトルで新しいClickableMenuを作成.
     * @param title 初期タイトル
     */
    public ClickableMenu(String title) {
        MenuItem dummyItem = new MenuItem();
        dummyItem.setVisible(false);
        getItems().add(dummyItem);

        this.label = new Label();
        label.setText(title);
        label.setOnMouseClicked(evt -> {
            dummyItem.fire();
        });
        setGraphic(label);
    }

    /**
     * タイトル取得
     * @return メニュータイトル
     */
    public String getTitle() {
        return label.getText();
    }

    /**
     * タイトル設定
     * @param text メニュータイトル
     */
    public void setTitle(String text) {
        label.setText(text);
    }

    /**
     * タイトル属性取得
     * @return title property
     */
    public StringProperty titleProperty() {
        return label.textProperty();
    }

}