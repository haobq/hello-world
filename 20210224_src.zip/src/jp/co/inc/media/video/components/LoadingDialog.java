package jp.co.inc.media.video.components;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jp.co.inc.media.video.common.BasImage;

/**
 * 概要：処理待ち画面のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class LoadingDialog extends Stage {
	public Pane loadingPane = new Pane();
	public Group root = new Group();
	public LoadingDialog(Stage owner, String title, int width, int height) {
		
		initOwner(owner);
		initModality(Modality.WINDOW_MODAL);
		setTitle(title);
		setAlwaysOnTop(true);
		setResizable(false);
		setMaximized(false);
		Scene scene = new Scene(root, width, height, Color.TRANSPARENT);
		setScene(scene);
		
		initStyle(StageStyle.TRANSPARENT);

		ImageView loadingView = new BasImage("loader.gif").getImageView(200, 200);
		loadingView.setPreserveRatio(false);
		loadingPane.getChildren().add(loadingView);
		loadingPane.prefWidthProperty().bind(root.getScene().widthProperty());
		loadingPane.prefHeightProperty().bind(root.getScene().heightProperty());
		loadingView = null;
		loadingPane.setOnMouseClicked(event -> {
			System.out.println("=======LoadingDialog close===============");
			this.close();

		});

		root.getChildren().add(loadingPane);

	}


}
