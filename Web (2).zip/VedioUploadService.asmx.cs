﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using VedioUploadService.Models;
using VedioUploadService.Models.Common;

namespace VedioUploadService
{
    /// <summary>
    /// VedioUploadService の概要の説明です
    /// </summary>
    [WebService(Namespace = "http://vedio.media.inc.co.jp/service")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class VedioUploadService : System.Web.Services.WebService
    {
        /// <summary>
        /// 患者検索サービス
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public List<PatientResponse> SearchPatient(PatientRequest request)
        {
            try
            {
                //1.リクエストパラメータのValidation処理を行う​
                if (Tools.IsCorrect(request.Certification.Group_id) == false)
                {
                    BizException biz = new BizException(Constants.MsgGroudIdError);
                    throw biz;
                }

                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth) == false)
                {
                    BizException biz = new BizException(Constants.MsgUnauthorized);
                    throw biz;
                };

                //3.tbl_patientテーブルを下記条件で検索する
                List<PatientResponse> patientList = Tools.GetPatient_data(request);
                return patientList;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.Message);
                throw biz;
            }
            catch (Exception )
            {
                BizException biz = new BizException(Constants.MsgInternalServerError);
                throw biz;
            }

        }
        /// <summary>
        /// 動画ファイル確認フォルダの容量計算
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public FolderSizeReponse GetFolderSize(Certification certification)
        {
            FolderSizeReponse folderSize = new FolderSizeReponse
            {
                Contract_size = 0,
                Used_size = 0
            };
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(certification.Group_id) == false)
                {
                    BizException biz = new BizException(Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth) == false)
                {
                    BizException biz = new BizException(Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.契約上の容量を取得する
                //4．使った容量計算
                folderSize.Used_size = Tools.GetFolderSize(certification.Group_id);
                return folderSize;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException(Constants.MsgInternalServerError);
                throw biz;
            }
        }
        /// <summary>
        /// 医院の一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public List<ClinicReponse> GetHospList(Certification certification)
        {
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(certification.Group_id) ==false)
                {
                    BizException biz = new BizException(Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth) == false)
                {
                    BizException biz = new BizException(Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.医院の一覧を返す
                List<ClinicReponse>  clinicList = Tools.GetClinic_data(certification.Group_id, certification.User_id);
                return clinicList;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException(Constants.MsgInternalServerError);
                throw biz;
            }
        }

        /// <summary>
        /// 施設一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public List<FacilityReponse> GetFacilityList(Certification certification)
        {
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(certification.Group_id) == false)
                {
                    BizException biz = new BizException(Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth) == false)
                {
                    BizException biz = new BizException(Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.施設一覧を返す
                List<FacilityReponse> facilityList = Tools.GetFacility_data(certification.Hosp_id);
                return facilityList;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException(Constants.MsgInternalServerError);
                throw biz;
            }
        }

        /// <summary>
        /// 動画情報格納
        /// </summary>
        /// <param name="movieRequest"></param>
        /// <returns></returns>
        [WebMethod]
        public MovieReponse MediaUpload(MovieRequest request)
        {
            MovieReponse movieReponse = new MovieReponse();
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(request.Certification.Group_id) == false)
                {
                    BizException biz = new BizException(Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth) == false)
                {
                    BizException biz = new BizException(Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.動画ファイルをフォルダを格納
                //TODO
                //4.動画情報をDBに登録処理
                Movie insertMovie = new Movie();
                //TODO
                bool movieRet = Tools.InsertMovie(insertMovie);
                //5. 動画情報をDBに登録処理失敗の場合、動画ファイルを削除
                if (movieRet == false)
                {
                    //TODO
                    BizException biz = new BizException(Constants.MsgFailedRegister);
                    throw biz;
                }

                return movieReponse;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException(Constants.MsgInternalServerError);
                throw biz;
            }
        }
        /// <summary>
        /// 動画情報削除
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public bool MediaDelete(DeleteRequest request)
        {
            bool del = false;
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(request.Certification.Group_id) == false)
                {
                    BizException biz = new BizException(Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth) == false)
                {
                    BizException biz = new BizException(Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.動画ファイルをフォルダから削除
                //TODO
                //4.動画情報のDB情報を削除
                //TODO
                return del;
            }
            catch (BizException bz)
            {
                BizException biz = new BizException(bz.Message);
                throw biz;
            }
            catch (Exception)
            {
                BizException biz = new BizException(Constants.MsgInternalServerError);
                throw biz;
            }
        }
    }
}
