﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class MovieRequest
    {
        //認証情報
        public Certification Certification { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //撮影日
        public string Movie_date { get; set; }
        //備考
        public string Remarks { get; set; }
        //動画ファイル名
        public string Movie_name { get; set; }
        public int FileCount { get; set; }
        //動画内容
        public byte[] Movie_context { get; set; }
        //サイズ(Byte)
        public long Movie_size { get; set; }
        //動画タイプ
        public string Movie_type { get; set; }
    }
}