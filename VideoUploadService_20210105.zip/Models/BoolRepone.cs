﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class BoolRepone
    {
        public int retReslt { get; set; }
        public bool ret { get; set; }
        //エラー
        public ErrorReponse Error { get; set; }
    }
}