﻿namespace VideoUploadService.Models.Common
{
    public class Constants
    {
        #region メッセージ
        // メッセージ
        public const string MsgOK = "0";
        public const string MsgHospError = "医院データが取得できません。";
        public const string MsgFacilityError = "訪問先を取得できません。";
        public const string MsgGroudIdError = "グループIDが不正です。";
        public const string MsgExistedAuthentication = "有効な認証データが既にあります。";
        public const string MsgUnauthorized = "認証キーが不正。";
        public const string MsgWrongUserIdOrPassword = "ユーザID／パスワードが不正です。";
        public const string MsgNotUseTerminalId = "この端末IDは利用できません。";
        public const string MsgFailedRegister = "データ登録に失敗しました。";
        public const string MsgFailedDelete = "データ削除に失敗しました。";
        public const string MsgFailedGetPath = "動画ファイル格納場所が見つかりません。";
        public const string MsgInternalServerError = "サーバ側で何らかのエラーが発生した。";
        public const string MsgAlreadyUpLoaded = "ファイルが既にアップロードされました。";
        public const string MsgSqlError = "データ取得時エラーが発生しました。";
        public const string MsgDelMoviFileFailed = "動画ファイルの削除が失敗しました。";
        public const string MsgDelImgFileFailed = "画像ファイルの削除が失敗しました。";
        public const string MsgFolderNoExist = "作業用フォルダが存在していない。";
        public const string MsgFileSizeNotEqual = "アップロードファイルのファイルサイズが不正です。";
        public const string MsgMillisecondl = "ミリ秒引数が空白です。";
        public const string MsgFileConnect = "ファイル結合処理でエラーが発生しました。";
        public const string MsgMoviType = "動画/静止画の区分がありません。";
        public const string MsgMoviNoData = "動画/静止画のデータが存在ありません。";
        public const string MsgMoviNotSettedConfig = "Web.config環境ファイルに動画フォルダを設定をしてください。";
        public const string MsgimgNotSettedConfig = "Web.config環境ファイルに静止画フォルダを設定がしてください。";
        public const string MsgtmpNotSettedConfig = "Web.config環境ファイルにtmpフォルダを設定がしてください。";

        #endregion

        // 分割サイズ
        public const int ConDIV_BYTE = 1024 * 3;
        // session_flg
        public const int SESSION_FLG = 4;
    }
}