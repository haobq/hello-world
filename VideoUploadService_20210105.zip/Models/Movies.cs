﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class Movies
    {
        //患者ID
        public string Patient_id { get; set; }
        //動画・写真番号
        public int Movie_no { get; set; }
        // 撮影日
        public string Photo_date { get; set; }
        //タイトル
         public string Title { get; set; }
        //パス
        public string Movie_path { get; set; }
        //タグ
        public string Movie_tag { get; set; }
        //コメント
        public string Remarks { get; set; }
        // 登録日
        public string Regist_date { get; set; }
        //動画・写真区分(1：動画 2:写真)
        public string Kbn { get; set; }
        //非表示フラグ 0：表示 1：非表示
        public string Mask { get; set; }
    }
}