package jp.co.inc.meida.video.utils;

import jp.co.inc.meida.video.common.BasConst;

/**
 * 送信履歴情報格納BEAN
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class JsonFileListBean  implements BasConst{

	/** JSONファイル名 */
	public String fileName = "";

	public String deleteflg = "";

	public String getDeleteflg() {
		return deleteflg;
	}

	public void setDeleteflg(String deleteflg) {
		this.deleteflg = deleteflg;
	}

	/**
	 * JSONファイル名取得
	 *
	 * @return JSONファイル名
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * JSONファイル名設定
	 *
	 * @param fileName　JSONファイル名
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}
