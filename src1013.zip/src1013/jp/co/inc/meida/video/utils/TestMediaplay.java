package jp.co.inc.meida.video.utils;

import java.awt.Panel;
import java.io.File;

import javax.swing.JSlider;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import javafx.application.Application;
import javafx.embed.swing.SwingNode;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class TestMediaplay  extends Application {
	Group root = new Group();
	Media		media;
	MediaPlayer	mediaPlayer;
	MediaView	mediaView;
	Button		playButton;
	public static void main(String[] args) {
		launch(args);
	}
	@Override
	public void start(Stage stage) {
		stage.show(); // ウィンドウを表示する

		File file = new File("C:\\temp\\sample.mp4"); // 動画ファイルを読み込む

		media		= new Media(file.toURI().toString());
		mediaPlayer	= new MediaPlayer(media);
		mediaView	= new MediaView(mediaPlayer);
		root.getChildren().add(mediaView); // MediaViewを追加

		mediaPlayer.setOnReady(() -> { // 動画が読み込めたら
			int width, height;

			width = media.getWidth(); // 動画の幅を取得
			height = media.getHeight(); // 動画の高さを取得
			mediaView.setFitWidth(600); // 幅を600に設定
			mediaView.setFitHeight(height * 600 / width); // 高さを調整

			playButton = new Button("■");
			playButton.setLayoutX(0); // X座標を設定
			playButton.setLayoutY(mediaView.getFitHeight()); // Y座標を設定
			root.getChildren().add(playButton); // 再生ボタンを追加
			playButton.setOnAction(e -> { // ボタンを押した時の挙動
				switch(mediaPlayer.getStatus()) {
					case READY: // 再生前
						playButton.setText("▶︎");
						mediaPlayer.play(); // 動画を再生
						break;
					case PLAYING: // 再生中
						playButton.setText("■");
						mediaPlayer.pause(); // 動画を一時停止
						break;
					case PAUSED: // ポーズ中
						playButton.setText("▶︎");
						mediaPlayer.play(); // 動画を再生
						break;
				}
			});

			Slider seekSlider = new Slider();
			seekSlider.setMin(mediaPlayer.getStartTime().toSeconds()); // 最小値の設定（動画の開始時間）
			seekSlider.setMax(mediaPlayer.getStopTime().toSeconds()); // 最大値の設定（動画の終了時間）
			seekSlider.setLayoutX(playButton.getLayoutX() + mediaView.getFitWidth() / 20); // X座標の設定
			seekSlider.setLayoutY(mediaView.getFitHeight()); // Ｙ座標の設定
			seekSlider.setPrefWidth(mediaView.getFitWidth() / 2); // シークバーの幅を設定
			root.getChildren().add(seekSlider); // シークバーを追加

			int startTime = (int)mediaPlayer.getCurrentTime().toSeconds(); // 開始時間
			int totalDuration = (int)mediaPlayer.getTotalDuration().toSeconds(); // 終了時間

			Text seekText = new Text(String.format("%d:%d", startTime / 60, startTime % 60) + "/" + // 開始時間
									 String.format("%d:%d", totalDuration / 60, totalDuration % 60)); // 終了時間
			seekText.setLayoutX(seekSlider.getLayoutX() + seekSlider.getPrefWidth()); // X座標を設定
			seekText.setLayoutY(mediaView.getFitHeight() + 15); // Y座標を設定
			root.getChildren().add(seekText); // Textを追加

			mediaPlayer.currentTimeProperty().addListener((ob, ov, nv) -> { // 動画が再生されている間に呼ばれる
				int currentTime = (int)mediaPlayer.getCurrentTime().toSeconds(); // 現在時間を取得
				seekSlider.setValue(currentTime); // シークバーを移動

				String text = String.format("%d:%d", currentTime / 60, currentTime % 60) + "/" + //現在時間
							  String.format("%d:%d", totalDuration / 60, totalDuration % 60); // 終了時間
				seekText.setText(text); // 文字列を設定
			});
			seekSlider.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> { // シークバー操作（マウス押下時点）
				mediaPlayer.pause(); // 動画を一時停止
			});
			seekSlider.addEventFilter(MouseEvent.MOUSE_RELEASED, e -> { // シークバー操作（マウスが離されたら）
				mediaPlayer.seek(Duration.seconds(seekSlider.getValue())); // シークバーの位置から、再生位置を設定
				mediaPlayer.play(); // 動画を再生
			});

		//	Slider volumeSlider = new Slider();
			JSlider volumeSlider = new JSlider();
			volumeSlider.setUI(new TriSliderUI());
			volumeSlider.setMinimum(1); // 最小値を設定
			volumeSlider.setMaximum(100);; // 最大値を設定

			volumeSlider.setLocation((int)seekText.getLayoutX() + 60, (int)seekText.getLayoutX() + 60);

			Panel p = new Panel();
			p.add(volumeSlider);



			 final SwingNode swingNode = new SwingNode();
	         createAndSetSwingContent(swingNode);


			root.getChildren().add(swingNode); // Sliderを追加

			volumeSlider.setValue(10); // 音量の初期値を設定
			mediaPlayer.setVolume(40); // 音量の初期値を設定

			Text volumeText = new Text((int)(volumeSlider.getValue() * 100) + "/" + 100); // ０〜１００に変換して表示
			volumeText.setLayoutX(1.0); // X座標を設定
			volumeText.setLayoutY(mediaView.getFitHeight() + 15); // Y座標を設定
			root.getChildren().add(volumeText); // Textを追加

			volumeSlider.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					volumeText.setText((int)(volumeSlider.getValue() * 100) + "/" + 100); // ０〜１００に変換して表示
					mediaPlayer.setVolume(volumeSlider.getValue()); // 音量を設定

				}
			});

			Scene scene = new Scene(root, mediaView.getFitWidth(), mediaView.getFitHeight() + 30); // ウィンドウサイズを指定
			stage.setScene(scene); // Sceneを設定
		});
	}

	 private void createAndSetSwingContent(final SwingNode swingNode) {
         SwingUtilities.invokeLater(new Runnable() {
             @Override
             public void run() {
     			JSlider slider = new JSlider();
    			slider.setUI(new TriSliderUI());
                swingNode.setContent(slider);
             }
         });
     }

}