package jp.co.inc.meida.video.utils;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;

public class JSliderSample5 extends JFrame {
	public static void main(String[] args) {
		new JSliderSample5();
	}

	public JSliderSample5() {
		setTitle("JSliderサンプル ボリューム調整みたいなスライダ");
		setBounds(200, 100, 300, 90);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new FlowLayout());

		init();

		setVisible(true);
	}

	private void init() {
		add(new JLabel("ボリューム調整みたいなスライダ"));
		JSlider slider = new JSlider();
		slider.setUI(new TriSliderUI());
		add(slider);
	}
}

