package jp.co.inc.meida.video.common;

import javax.swing.JPanel;

public class BasPane  extends JPanel implements BasConst{
	 public BasPane() {
	        super();
	 }
}
