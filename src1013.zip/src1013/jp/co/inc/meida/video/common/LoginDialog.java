package jp.co.inc.meida.video.common;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LoginDialog extends Stage {

	public LoginDialog(Stage owner) {
		super();
		initOwner(owner);
		setTitle("ログイン画面");
		Group root = new Group();
		Scene scene = new Scene(root, 250, 150, Color.WHITE);
		setScene(scene);

		GridPane gridpane = new GridPane();
		gridpane.setPadding(new Insets(5));
		gridpane.setHgap(5);
		gridpane.setVgap(5);

		Label groupNameLbl = new Label("グループID: ");
		gridpane.add(groupNameLbl, 0, 1);

		Label userNameLbl = new Label("ユーザーID: ");
		gridpane.add(userNameLbl, 0, 2);

		Label passwordLbl = new Label("パスワード: ");
		gridpane.add(passwordLbl, 0, 3);
		final TextField groupNameFld = new TextField("G0001");
		gridpane.add(groupNameFld, 1, 1);


		final TextField userNameFld = new TextField("Admin");
		gridpane.add(userNameFld, 1, 2);

		final PasswordField passwordFld = new PasswordField();
		passwordFld.setText("password");
		gridpane.add(passwordFld, 1, 3);

		Button login = new Button("ログイン");
		login.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				close();
			}
		});
		gridpane.add(login, 1, 4);
		GridPane.setHalignment(login, HPos.RIGHT);
		root.getChildren().add(gridpane);
	}
}
