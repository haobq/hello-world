/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */

package jp.co.inc.meida.video.common;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class SystemLog {

	private static DateFormat exceptionDate = new SimpleDateFormat("yyyyyMMdd") ;
    private static DateFormat exceptionTime = new SimpleDateFormat("HHmmssSSS") ;

    // 現在の時点(日期と時間)
    private static java.util.Date date = new java.util.Date();

	public static void writeLog(
		String strClassName,
		String strMethodName,
		String strLogicMessage,
		Exception e) {
		String strFileName = "log/" + exceptionDate.format(date) + ".log";
		try {
			//ファイルを開く
			FileOutputStream fw = new FileOutputStream(strFileName);
			FileInputStream in = new FileInputStream(strFileName);

			//ＵＲＬの取得
			InputStreamReader isr = new InputStreamReader (in);
			//入力ストリームを取得
			BufferedOutputStream bw = new BufferedOutputStream(fw);
			BufferedReader reader = new BufferedReader (isr);
			String line;
			PrintWriter pw = new PrintWriter(bw);
			while ((line = reader.readLine()) != null){
				pw.println(line);	//txtに書き込み
			}
			in.close();
			pw.println(exceptionTime.format(date)+ "のシステムの異常エラーメッセージ：");
			pw.println("-----------------------------------------------------------------");
			pw.println("クラス名："+ strClassName);
			pw.println("メソッド名："+ strMethodName);
			pw.println("詳細："+ strLogicMessage);
			pw.println(e.toString());
			for (int i = 0; i < e.getStackTrace().length; i++) {
				pw.println("    at " + e.getStackTrace()[i].toString());
			}
			pw.println("以上 確認下さい");
			pw.println("-----------------------------------------------------------------");
			//ファイルクローズ
			pw.close();
		}
		catch (IOException ie) {
			//e.printStackTrace();
		}
	}

}