﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class VersionResponse
    {
        //バージョン情報
        public Version Ver { get; set; }
        //エラー
        public ErrorResponse Error { get; set; }
    }
}