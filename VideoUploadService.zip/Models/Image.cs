﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class Img
    {
        //認証情報
        public Certification Certification { get; set; }
        public string Patient_id { get; set; }
        //image_no
        public int Image_no { get; set; }
        // 撮影日
        public string Photo_date { get; set; }
        //タイトル
         public string Title { get; set; }
        //パス
        public string Image_path { get; set; }
        //タグ
        public string Image_tag { get; set; }
        //コメント
        public string Remarks { get; set; }
        //動画・写真区分(1：動画 2:写真)
        public string Image_Kbn { get; set; }
        //非表示フラグ 0：表示 1：非表示
        public string Mask { get; set; }
        // 登録日
        public string Regist_date { get; set; }
    }
}