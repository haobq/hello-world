/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0  2020/09/01
 */

package jp.co.inc.meida.video.common;

/**
 * クラス名：システムメッセージクラス.
 *
 */
public interface MessageConst {
    public final static String V0001 = "動画管理システム   \nﾊﾞｰｼﾞｮﾝ 1.0.0    2020/09/01\nメディア株式会社";
    public final static String E0000 = "システム	は二重起動できない";
    public final static String E0001 = "システムエラーが発生しました。\nサポートセンターまでご連絡下さい。";
    public final static String E0002 = "動画格納していない,別のフォルダを選択してください。";
    public final static String E0003 = "動画ファイル格納フォルダの管理JSON作成できません。";
    public final static String E0004 = "動画ファイル格納フォルダを選択してください。";
    public final static String E0005 = "患者を選択してください。";
    public final static String E0006 = "訪問日日付が正しくありません。";
    public final static String E0007 = "動画ファイル格納フォルダを選択してください。";

    public final static String E0008 = "正しいプロキシURLを入力してください";
    public final static String E0009 = "正しいログインURLを入力してください";
    public final static String E0010 = "ポートは数字を入力してください";
    public final static String E0011 = "プロキシURLを入力してください";
    public final static String E0012 = "プロキシポートを入力してください";
    public final static String E0013 = "ユーザー名を入力してください";
    public final static String E0014 = "パスワードを入力してください";
    public final static String E0015 = "作業フォルダ名を入力してください";
    public final static String E0016 = "正しいログファイル名を入力してください";

    public final static String E0017 = "既に送信済みです。";


    public final static String I0001 = "動画ファイルをアップロードします。よろしいですか。";
    public final static String I0002 = "アップロードされた動画ファイルを削除します。よろしいですか。";
    public final static String I0003 = "動画ファイルを選択してください。";
}
