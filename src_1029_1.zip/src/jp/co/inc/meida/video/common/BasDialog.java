package jp.co.inc.meida.video.common;

import java.util.logging.Logger;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class BasDialog extends Stage implements BasConst,MessageConst {
	public Group root = new Group();


	// Loggerクラスのインスタンスを生成
	public static Logger logger = Logger.getLogger(BasDialog.class.getName());

	public BasDialog(Stage owner ,String title ,int width, int height) {
		initOwner(owner);
		initModality(Modality.WINDOW_MODAL);
		//アイコンの設定
	//	Image img = new Image(getClass().getResourceAsStream("media.jpg"));
	//	this.getIcons().add(img);
		setTitle(title);
		setResizable(false);
		setMaximized(false);

		Scene scene = new Scene(root, width, height, Color.WHITE);
		setScene(scene);
	}

}
