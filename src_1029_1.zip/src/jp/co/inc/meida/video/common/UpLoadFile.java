package jp.co.inc.meida.video.common;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FilenameUtils;

import javafx.concurrent.Task;
import jp.co.inc.meida.video.utils.FileInfoBean;

public class UpLoadFile extends Task<String> implements BasConst {

	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(UpLoadFile.class.getName());

	/**
	 * 進捗処理.
	 */
	@Override
	protected String call() throws Exception {
		// 連番
		int renBan = 1;
		try {

			for (FileInfoBean file : BasFrame.fileInfolist) {
				if (file.fileName.equals(BasFrame.sysInfoBean.getSelectedFileName())) {

					// ファイルコピー
					// 病院ID + _ + 患者ID + _ + カレンダー日付 + _ + 連番
					String strUploadFileName = BasFrame.patientInfo.getHospitalId() + "_"
							+ BasFrame.patientInfo.getPatientId() + "_"
							+ BasFrame.datePicker.getValue().toString().replace("-", "") + "_" + renBan + EXTENTTION;

					String strUploadFilePath = mp4Path;

					if (!Files.exists(Paths.get(strUploadFilePath))) {

						Files.createDirectory(Paths.get(strUploadFilePath));
						System.out.println("Directory created");
					} else {

						System.out.println("Directory already exists");
					}
					Path destinationPath = Paths.get(strUploadFilePath + strUploadFileName);

					Path sourcePath = Paths.get(file.filePath);

					try {
						Files.copy(sourcePath, destinationPath);
						System.out.println("コピーが成功しました");
					} catch (IOException e) {
						e.printStackTrace();
						logger.log(Level.SEVERE, THROW_INFO, e.getMessage());
					}

					// ファイル分割
					FileSplit fileSplit = new FileSplit();
					try {
						fileSplit.split((strUploadFilePath + strUploadFileName), strUploadFilePath, SPLITE_SIZE);
					} catch (Exception e) {
						// TODO 自動生成された catch ブロック
						e.printStackTrace();
						logger.log(Level.SEVERE, THROW_INFO, e.getMessage());
					}

					// ファイル削除
					File dir = destinationPath.toFile();
					dir.delete();

					// 圧縮」、送信、削除　処理開始

					dir = Paths.get(strUploadFilePath).toFile();
					File files[] = dir.listFiles();
					int fileCount = 0;
					fileCount = files.length;
					// ファイルソード
					java.util.Arrays.sort(files, new java.util.Comparator<File>() {
						public int compare(File file1, File file2) {
							return file1.getName().compareTo(file2.getName());
						}
					});


					long fileLength = 0;
					for (File f : files) {

						String zipFilePath = FilenameUtils.removeExtension(f.getPath())
								+ FilenameUtils.getExtension(f.getName());
						String zipFile = zipFilePath + "\\" + FilenameUtils.removeExtension(f.getName())
								+ FilenameUtils.getExtension(f.getName()) + ".zip";

						File newfile = new File(zipFilePath);

						// byte定義
						byte[] media;
						if (newfile.mkdir()) {

							// 圧縮 .zip
							fileSplit.archive(f.getPath(), zipFile);

							fileLength = fileLength + f.length();

							// 圧縮元ファイル削除
							f.delete();

							// 進捗バーの更新
							updateProgress(fileLength, file.getFileSize());
							// 進捗バー表示
							BasFrame.hBoxPrpgress.setVisible(true);

							// 進捗メッセージの更新
							updateMessage(String.format(" %d/%d", fileLength, file.getFileSize()));
							// 待機
							//TimeUnit.SECONDS.sleep(1);

							// zipファイルをByte[]に変換
							media = ZipCompressUtils.readBytesFromFile(zipFile);

							//						// パラメータ　設定
							//						_mediaUpload_media = media;
							//						_mediaUpload_mediaName =  f.getName();
							//
							//
							//						_mediaUpload_fileCount = fileCount;
							//						_mediaUpload_hospId = "HOSPITAL_ID";
							//						_mediaUpload_patientId = "KANNJYA_ID";

							//						//　サービス呼び出す
							//						String _mediaUpload__return = port.mediaUpload(_mediaUpload_media, _mediaUpload_mediaName, _mediaUpload_fileCount, _mediaUpload_hospId, _mediaUpload_patientId);

							// 結果判定
							//						if (_mediaUpload__return.equals("fileUploadSuccess")) {
							//

							// zipファイル削除
							File zip = new File(zipFile);
							zip.delete();

							// zipファイルディレクトリ削除
							dir = new File(zipFilePath);
							dir.delete();

						}
					}

				}

			}



			updateMessage("アップロード完了！");
			// 待機
			TimeUnit.SECONDS.sleep(1);

			BasFrame.hBoxPrpgress.setVisible(false);

			// 完に更新
			BasFrame.updateFileStatus(STATUS_COMPLETED);


		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e.getMessage());
			return null;
		}

		return "Done";
	}

}
