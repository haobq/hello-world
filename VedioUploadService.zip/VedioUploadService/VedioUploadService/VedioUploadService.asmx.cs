﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using VedioUploadService.Models;

namespace VedioUploadService
{
    /// <summary>
    /// VedioUploadService の概要の説明です
    /// </summary>
    [WebService(Namespace = "http://media.inc.co.jp/videoservice")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class VedioUploadService : System.Web.Services.WebService
    {
        /// <summary>
        /// 患者検索サービス
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public List<PatientResponse> SearchPatient(PatientRequest request)
        {
            List<PatientResponse> patientList = new List<PatientResponse>();

            try
            {
                //1.リクエストパラメータのValidation処理を行う​
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                //3.tbl_patientテーブルを下記条件で検索する

                return patientList;
            }
            catch (Exception ex)
            {
                BizException biz = new BizException(ex.Message);
                throw biz;
            }

        }
        /// <summary>
        /// 動画ファイル確認フォルダの容量計算
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public FolderSizeReponse GetFolderSize(Certification certification)
        {
            FolderSizeReponse folderSize = new FolderSizeReponse();
            folderSize.Contract_size = 0;
            folderSize.Used_size = 0;
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                //3.契約上の容量を取得する
                //4．使った容量計算

                return folderSize;
            }
            catch (Exception ex)
            {
                BizException biz = new BizException(ex.Message);
                throw biz;
            }
        }
        /// <summary>
        /// 医院の一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public List<ClinicReponse> GetHospList(Certification certification)
        {
            List<ClinicReponse> clinicList = new List<ClinicReponse>();
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                //3.医院の一覧を返す
                return clinicList;
            }
            catch (Exception ex)
            {
                BizException biz = new BizException(ex.Message);
                throw biz;
            }
        }

        /// <summary>
        /// 施設一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public List<FacilityReponse> GetFacilityList(Certification certification)
        {
            List<FacilityReponse> clinicList = new List<FacilityReponse>();

            try
            {
                //1. リクエストパラメータのValidation処理を行う
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                //3.施設一覧を返す
                return clinicList;
            }
            catch (Exception ex)
            {
                BizException biz = new BizException(ex.Message);
                throw biz;
            }
        }

        /// <summary>
        /// 動画情報格納
        /// </summary>
        /// <param name="movieRequest"></param>
        /// <returns></returns>
        [WebMethod]
        public List<MovieReponse> MediaUpload(List<MovieRequest> request)
        {
            List<MovieReponse> movieList = new List<MovieReponse>();
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                //3.動画情報格納処理
                return movieList;
            }
            catch (Exception ex)
            {
                BizException biz = new BizException(ex.Message);
                throw biz;
            }
        }
    }
}
