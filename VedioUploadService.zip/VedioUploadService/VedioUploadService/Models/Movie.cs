﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class Movie
    {
        //グループID
        public string Group_id { get; set; }
        //医院ID
        public string Hosp_id { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //UserID
        public string User_id { get; set; }
        //動画番号
        public string Vedio_no { get; set; }
        //画像区分1：初回訪問ガイド
        public string Vedio_kbn { get; set; }
       // 非表示フラグ 0：表示 1：非表示
        public string Mask { get; set; }
        //撮影日
        public DateTime Photo_date { get; set; }
        //備考
        public string Remarks { get; set; }
        //保存パス
        public string Vedio_path { get; set; }
        //修正者
        public string Edit_user { get; set; }
        //修正日
        public DateTime Edit_date { get; set; }
        //登録日
        public DateTime Regist_date { get; set; }
        //タグ
        public string Vedio_tag { get; set; }
        //サイズ
        public long Vedio_size { get; set; }
        //通番
        public int Seq_no { get; set; }
    }
}