﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models.Common
{
    public class Tools
    {
        //パラメータの有無をチェック
        public static bool IsCheckParm(string parm)
        {
            if (string.IsNullOrEmpty(parm))
            {
                return false;
            }
            return true;
        }

        //文字数の範囲をチェック
        public static bool IsCheckStrLen(string str, int length)
        {
            if (str != null && length > 0 && str.Length <= length)
            {
                return true;
            }
            return false;
        }

        //日付が正しいかをチェックする
        public static bool IsCheckDate(string date)
        {
            _ = new DateTime();

            if (!string.IsNullOrEmpty(date) &&

                DateTime.TryParse(date, out _))
            {
                return true;
            }
            return false;
        }

        //日付の前後妥当性をチェック
        public static bool IsCheckDate(string str1, string str2)
        {

            if (DateTime.TryParse(str1, out DateTime date1) && DateTime.TryParse(str2, out DateTime date2))
            {
                TimeSpan span = date2.Subtract(date1);
                if (span.TotalDays >= 0)
                {
                    return true;
                }
            }
            return false;
        }

        //ユーザID、パスワードをチェックする。
        public static bool IsCorrect(string GroupId, string UserId, string Pswd)
        {
            return SqlHelper.IsCorrect(GroupId, UserId, Pswd);
        }

        //グループIDが正しいかをチェックする。
        public static bool IsCorrect(string GroupId)
        {
            return SqlHelper.IsCorrect(GroupId);
        }

        //時間形式を変更する
        public static string GetTimeStr(string time)
        {
            string validDate = "";

            if (!string.IsNullOrEmpty(time))
            {
                validDate = time.Replace("/", "-").Split(' ')[0];
            }

            return validDate;
        }

        public static string GetString(string value)
        {
            return value ?? "";
        }

        //数値をチェックする
        public static bool IsCheckNum(int num)
        {
            int[] nums = { 1, 2 };

            if (Array.IndexOf(nums, num) < 0)
            {
                return false;
            }
            return true;
        }

        //String To Datime
        public static DateTime ToDateTime(string str)
        {
            System.Globalization.DateTimeFormatInfo dateTimeFormatInfo = new System.Globalization.DateTimeFormatInfo();
            System.Globalization.DateTimeFormatInfo dtFormat = dateTimeFormatInfo;

            dtFormat.ShortDatePattern = "yyyy-MM-dd";

            return Convert.ToDateTime(str, dtFormat);

        }
        //動画ファイル登録
        public static Movie InsertMovie(Movie movie)
        {
            return SqlHelper.InsertMovie(movie);
        }
        public static List<PatientResponse>  GetPatient_data(PatientRequest patientRequest)
        {
            return SqlHelper.GetPatient_data(patientRequest);
        }
        //医院の施設リスト取得する
        public static List<FacilityReponse> GetFacility_data(string hosp_id)
        {
            return SqlHelper.GetFacility_data(hosp_id);
        }

        //医院リスト取得する
        public static List<ClinicReponse> GetAllMedia_data(string groupID, string user_id)
        {
            return SqlHelper.GetAllMedia_data(groupID, user_id);
        }

        //認証キーをチェックする
        public static bool KEY_CHK(string groupID, string user_id, string mediaAuth)
        {
            return SqlHelper.KEY_CHK(groupID, user_id, mediaAuth);
        }
    }
}