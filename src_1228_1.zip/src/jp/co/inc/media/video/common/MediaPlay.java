package jp.co.inc.media.video.common;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import jp.co.inc.media.video.utils.SysInfoBean;
import jp.co.inc.media.video.utils.ToolsUtils;

public class MediaPlay implements BasConst {

	static Image speaker00 = new BasImage("speaker00.png").getImage();
	static Image speaker20 = new BasImage("speaker20.png").getImage();
	static Image speaker40 = new BasImage("speaker40.png").getImage();
	static Image speaker70 = new BasImage("speaker70.png").getImage();

	public static Button stopButton = new BasButton("stop.png", ICON_SIZE, ICON_SIZE);
	public static Button playButton = new BasButton("play.png", ICON_SIZE, ICON_SIZE);
	public static Button pauseButton = new BasButton("pause.png", ICON_SIZE, ICON_SIZE);

	/**
	 * 再生、一時停止、停止、連続再生ボタンを作成
	 * @param mp メディアプレー
	 * @return Node
	 */
	public static Node createButton(final MediaPlayer mp) {
		// 表示コンポーネントを作成
		HBox root = new HBox(5);
		StackPane playPane = new StackPane();

		stopButton = new BasButton("stop.png", ICON_SIZE, ICON_SIZE);
		playButton = new BasButton("play.png", ICON_SIZE, ICON_SIZE);
		pauseButton = new BasButton("pause.png", ICON_SIZE, ICON_SIZE);
		
		root.getChildren().add(stopButton);
		playPane.getChildren().add(pauseButton);
		playPane.getChildren().add(playButton);
		root.getChildren().add(playPane);

		stopButton.setVisible(false);
		playButton.setVisible(true);
		pauseButton.setVisible(false);
		root.setAlignment(Pos.TOP_CENTER);

		// 再生ボタンにイベントを登録
		EventHandler<ActionEvent> playHandler = (e) -> {
			if (mp != null) {
				// 再生開始
				
				System.out.println("再生開始:" + mp);
				mp.play();
				stopButton.setVisible(true);
				playButton.setVisible(false);
				pauseButton.setVisible(true);
			}
		};
        playButton.addEventHandler( ActionEvent.ACTION , playHandler );
		// 一時停止ボタンにイベントを登録
		EventHandler<ActionEvent> pauseHandler = (e) -> {
			
			if (mp != null) {
				// 一時停止
				mp.pause();
				playButton.setVisible(true);
				pauseButton.setVisible(false);
				stopButton.setVisible(false);
			}
		};
		pauseButton.addEventHandler(ActionEvent.ACTION, pauseHandler);

		// 停止ボタンにイベントを登録
		EventHandler<ActionEvent> stopHandler = (e) -> {
			
			if (mp != null) {
				// 頭だしして停止
				mp.seek(mp.getStartTime());
				mp.stop();
				playButton.setVisible(true);
				pauseButton.setVisible(false);
				stopButton.setVisible(false);
			}
		};
		stopButton.addEventHandler(ActionEvent.ACTION, stopHandler);
		return root;
	}

	/**
	 * 再生時間を表示・操作するスライダを作成
	 * @param mp メディアプレー
	 * @param sliderWidth 幅
	 * @return Node
	 */
	public static Node createTimeSlider(MediaPlayer mp, double sliderWidth) {

		// 表示コンポーネントを作成
		HBox root = new HBox();
		final Slider slider = new Slider();
		slider.setPrefWidth(sliderWidth);
		final Label info = new Label();
		root.getChildren().add(slider);
		root.setSpacing(10);
		root.getChildren().add(info);

		// 再生準備完了時に各種情報を取得する関数を登録
		final Runnable beforeFunc = mp.getOnReady(); // 現在のレディ関数
		Runnable readyFunc = () -> {
			// 先に登録された関数を実行
			if (beforeFunc != null) {
				beforeFunc.run();
			} else {

				// 動画の情報をラベル出力
				String infoStr = ToolsUtils.calculateTime((long)mp.getCurrentTime().toSeconds())
						    + "/" + ToolsUtils.calculateTime((long)mp.getTotalDuration().toSeconds());
				info.setText(infoStr);

				// スライダを移動
				slider.setValue(mp.getCurrentTime().toSeconds());
			}

			// スライダの値を設定
			slider.setMin(mp.getStartTime().toSeconds());
			slider.setMax(mp.getStopTime().toSeconds());
			slider.setSnapToTicks(true);
			// 終了時間設定
			SysInfoBean.setEndTime(mp.getStopTime());
		};
		mp.setOnReady(readyFunc);

		// 再生中にスライダを移動
		// プレイヤの現在時間が変更されるたびに呼び出されるリスナを登録
		ChangeListener<? super Duration> playListener = (ov, old, current) -> {
			// 動画の情報をラベル出力
			String infoStr = ToolsUtils.calculateTime((long)mp.getCurrentTime().toSeconds())
					+ "/"
					+ ToolsUtils.calculateTime((long) mp.getTotalDuration().toSeconds());
			info.setText(infoStr);

			// スライダを移動
			slider.setValue(mp.getCurrentTime().toSeconds());
		};
		mp.currentTimeProperty().addListener(playListener);

		// スライダを操作するとシークする
		EventHandler<MouseEvent> sliderHandler = (e) -> {
			if (playButton.isVisible()) {
				// スライダを操作すると、シークする
				mp.seek(javafx.util.Duration.seconds(slider.getValue()));
				String infoStr = ToolsUtils.calculateTime((long)mp.getCurrentTime().toSeconds())
						+ "/"
						+ ToolsUtils.calculateTime((long) mp.getTotalDuration().toSeconds());
				info.setText(infoStr);
			}

		};
		slider.addEventFilter(MouseEvent.MOUSE_RELEASED, sliderHandler);

		return root;
	}

	/**
	 * ボリュームを表示・操作するスライダを作成
	 * @param mp メディアプレー
	 * @return Node
	 */
	public static Node createVolumeSlider(MediaPlayer mp) {
		// 表示コンポーネントを作成
		HBox root = new HBox();
		final Label info = new Label();
		ImageView speaker = new BasImage("speaker00.png").getImageView(ICON_SIZE + 10, ICON_SIZE + 10);
		final Slider slider = new Slider();
		slider.setId("custom-slider");
		// 再生準備完了時に各種情報を取得する関数を登録
		final Runnable beforeFunc = mp.getOnReady(); // 現在のレディ関数
		Runnable readyFunc = () -> {
			// 先に登録された関数を実行
			if (beforeFunc != null) {
				beforeFunc.run();
			}
			// スライダの値を設定
            slider.setMin( 0.0 );
            slider.setMax( 1.0 );
			slider.setValue(mp.getVolume());
		};
		mp.setOnReady(readyFunc);

		// 再生中にボリュームを表示
		// プレイヤの現在時間が変更されるたびに呼び出されるリスナを登録
		ChangeListener<? super Number> sliderListener = (ov, old, current) -> {
			// スライダにあわせてボリュームを変更
			mp.setVolume(slider.getValue());
			// 保存
			SysInfoBean.setMediaVolume(slider.getValue());

			final double vol = mp.getVolume();
			// 動画の情報をラベル出力
            String  infoStr = String.format( "%4.0f" , mp.getVolume()*100 );
			info.setText(infoStr);

			System.out.println("vol:" + vol);

			if (vol == 0) {
				speaker.setImage(speaker00);
			} else if (vol > 0 && vol <= 0.4) {
				speaker.setImage(speaker20);
			} else if (vol > 0.4 && vol <= 0.7) {
				speaker.setImage(speaker40);
			} else if (vol > 0.7) {
				speaker.setImage(speaker70);
			}
		};

		VBox rootVBox = new VBox();
		HBox rootHBox = new HBox();
		rootHBox.getChildren().addAll(slider, info);
		Label space = new Label();
		space.setMaxHeight(8);
		space.setMinHeight(8);
		rootVBox.getChildren().add(space);
		rootVBox.getChildren().add(rootHBox);

		slider.valueProperty().addListener(sliderListener);
		root.getChildren().addAll(speaker, rootVBox);
		return root;
	}
}
