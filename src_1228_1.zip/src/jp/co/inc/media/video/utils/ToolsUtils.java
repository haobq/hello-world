package jp.co.inc.media.video.utils;

import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.media.MediaView;

public class ToolsUtils {

	public static ImageView CaptureImage(MediaView mediaView, double width, double height) {
		WritableImage wi = new WritableImage((int) width, (int) height);
		WritableImage snapshot = mediaView.snapshot(new SnapshotParameters(), wi);
		ByteArrayOutputStream stream =new  ByteArrayOutputStream();
		try {
			ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", stream);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Image image = new Image(new java.io.ByteArrayInputStream(stream.toByteArray()),width,height,true,true);
		ImageView imgView = new ImageView(image);
		imgView.setFitWidth(width);
		imgView.setFitHeight(height);
		return imgView;
	}


	/**
	 * 全角文字は２桁、半角文字は１桁として文字数をカウントする
	 * @param str 対象文字列
	 * @return 文字数
	 */
	public static int getHan1Zen2(String str) {

	  //戻り値
	  int ret = 0;

	  //全角半角判定
	  char[] c = str.toCharArray();
	  for(int i=0;i<c.length;i++) {
	    if(String.valueOf(c[i]).getBytes().length <= 1){
	      ret += 1; //半角文字なら＋１
	    }else{
	      ret += 2; //全角文字なら＋２
	    }
	  }

	  return ret;
	}
	/**
	 * 日付の妥当性チェックを行います。
	 * 指定した日付文字列（yyyy/MM/dd or yyyy-MM-dd）が
	 * カレンダーに存在するかどうかを返します。
	 * @param strDate チェック対象の文字列
	 * @return 存在する日付の場合true
	 */
	public static boolean checkDate(String strDate) {
		if (strDate.equals("")) {
			return true;
		}
		strDate = strDate.replace('-', '/');
		DateFormat format = DateFormat.getDateInstance();
		// 日付/時刻解析を厳密に行うかどうかを設定する。
		format.setLenient(false);
		try {
			format.parse(strDate);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public static String calculateTime(long seconds) {
	    long hours = TimeUnit.SECONDS.toHours(seconds);
	    long minute = TimeUnit.SECONDS.toMinutes(seconds) -
	                  TimeUnit.HOURS.toMinutes(TimeUnit.SECONDS.toHours(seconds));
	    long second = TimeUnit.SECONDS.toSeconds(seconds) -
	                  TimeUnit.MINUTES.toSeconds(TimeUnit.SECONDS.toMinutes(seconds));
	    String infoStr = String.format("%02d", (int)hours)+":"+String.format("%02d", (int)minute)+":"+String.format("%02d", (int)second);
	    return infoStr;

	}
}
