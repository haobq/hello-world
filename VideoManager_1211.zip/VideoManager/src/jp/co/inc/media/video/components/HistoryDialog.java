package jp.co.inc.media.video.components;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.SortType;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasDialog;
import jp.co.inc.media.video.common.BasImage;
import jp.co.inc.media.video.common.MessageConst;
import jp.co.inc.media.video.utils.FileInfoBean;
import jp.co.inc.media.video.utils.FolderManager;
import jp.co.inc.media.video.utils.JsonListBean;

/**
 * 履歴管理のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class HistoryDialog extends BasDialog implements BasConst, MessageConst {

	private StackPane paneFileDetail = new StackPane();
	private static final Image imageNew = new BasImage("unreg.png").getImage();
	private static final Image imageWorking = new BasImage("loading.png").getImage();
	private static final Image imageFinish = new BasImage("finish.png").getImage();

	/**
	 * 画像アップローダー用JSONファイル詳細
	 *
	 * @param jsonfileDetail JSONファイル詳細
	 */
	@SuppressWarnings("unchecked")
	private void setJsonFileDetail(List<FileInfoBean> jsonfileDetail) {

		paneFileDetail.getChildren().clear();
		TableView<FileInfoBean> jsonDetailTable = new TableView<>();
		ObservableList<FileInfoBean> observableDetail = FXCollections.observableList(jsonfileDetail);

		final TableColumn<FileInfoBean, Label> fileStatusColumn = new TableColumn<FileInfoBean, Label>(
				FILE_TITLE_STATAS);
		fileStatusColumn.setMaxWidth(45);
		fileStatusColumn.setMinWidth(45);
		final TableColumn<FileInfoBean, String> fileNameColumn = new TableColumn<>(FILE_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory<>("fileName"));
		fileNameColumn.setMaxWidth(200);
		fileNameColumn.setMinWidth(200);
		final TableColumn<FileInfoBean, String> lastedUpdateColumn = new TableColumn<>(FILE_TITLE_LASTED_UPDATE);
		lastedUpdateColumn.setCellValueFactory(new PropertyValueFactory<>("updateDate"));
		lastedUpdateColumn.setMaxWidth(180);
		lastedUpdateColumn.setMinWidth(180);
		lastedUpdateColumn.setSortType(SortType.DESCENDING);
		final TableColumn<FileInfoBean, String> fileSizeColumn = new TableColumn<>(FILE_TITLE_SIZE);
		fileSizeColumn.setCellValueFactory(new PropertyValueFactory<>("fileSize"));
		fileSizeColumn.setMaxWidth(100);
		fileSizeColumn.setMinWidth(100);
		fileSizeColumn.setStyle("-fx-alignment: CENTER-RIGHT;");
		final TableColumn<FileInfoBean, String> patient_idColumn = new TableColumn<>(FILE_TITLE_PATIENT_ID);
		patient_idColumn.setCellValueFactory(new PropertyValueFactory<>("patient_id"));
		patient_idColumn.setMaxWidth(100);
		patient_idColumn.setMinWidth(100);
		patient_idColumn.setStyle("-fx-alignment: CENTER-RIGHT;");
		final TableColumn<FileInfoBean, String> movie_send_timeColumn = new TableColumn<>(FILE_TITLE_MOVIE_SEND_TIME);
		movie_send_timeColumn.setCellValueFactory(new PropertyValueFactory<>("movie_send_time"));
		movie_send_timeColumn.setMaxWidth(180);
		movie_send_timeColumn.setMinWidth(180);

		final TableColumn<FileInfoBean, String> filePathColumn = new TableColumn<>(FILE_PATH_NAME);
		filePathColumn.setCellValueFactory(new PropertyValueFactory<>("filePath"));
		filePathColumn.setMinWidth(100);
		final TableColumn<FileInfoBean, String> fileUploadFileNameColumn = new TableColumn<>(
				FILE_TITLE_UPLOAD_FILE_NAME);
		fileUploadFileNameColumn.setCellValueFactory(new PropertyValueFactory<>("uploadFileName"));
		fileUploadFileNameColumn.setMaxWidth(170);
		fileUploadFileNameColumn.setMinWidth(170);
		final TableColumn<FileInfoBean, String> fileBikouColumn = new TableColumn<>(FILE_TITLE_BIKOU);
		fileBikouColumn.setCellValueFactory(new PropertyValueFactory<>("bikou"));
		patient_idColumn.setPrefWidth(200);
		patient_idColumn.setMinWidth(200);
		jsonDetailTable.getColumns().setAll(fileStatusColumn, fileNameColumn, lastedUpdateColumn, fileSizeColumn,
				patient_idColumn, movie_send_timeColumn, filePathColumn, fileUploadFileNameColumn, fileBikouColumn);
		jsonDetailTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		jsonDetailTable.setItems(observableDetail);

		// sort
		Comparator<FileInfoBean> comparator = Comparator
				.<FileInfoBean, String> comparing(model -> model.getMovie_send_time()).reversed();

		FXCollections.sort(jsonDetailTable.getItems(), comparator);

		paneFileDetail.getChildren().add(jsonDetailTable);

		/** ファイルリストクリックイベント処理 */
		setCellValueFactory_his(fileStatusColumn);
	}

	/**
	 * 履歴管理画面
	 *
	 * @param owner 親パネル名
	 * @param title 画面名
	 * @param width 画面幅
	 * @param height 画面高
	 */
	public HistoryDialog(Stage owner, String title, int width, int height) {
		super(owner, title, width, height);

		BorderPane listPane = new BorderPane();

		setResizable(true);

		listPane.prefWidthProperty().bind(owner.getScene().widthProperty());
		listPane.prefHeightProperty().bind(owner.getScene().heightProperty());

		//JSONファイル一覧
		List<JsonListBean> jsonfileList = FolderManager.getJsonListBean(jsonFolder);
		try {
			List<FileInfoBean> list = new ArrayList<FileInfoBean>();
			for (JsonListBean jsonfile : jsonfileList) {
				String workingDirJson = jsonFolder + jsonfile.getFileName();
				List<FileInfoBean> fileInfoLst = FolderManager.getJsonInfoBean(workingDirJson);

				for (FileInfoBean fileInfo : fileInfoLst) {
					String path = fileInfo.getFilePath();
					path = path.replace(fileInfo.getFileName(), "").replace("\\", "/");
					fileInfo.setFilePath(path);
				}

				list.addAll(fileInfoLst);
			}

			//// 送信済みデータを抽出し、結果をリストに格納
			//List<FileInfoBean> datasetList = list.stream().filter(dataset -> {
			//	if (dataset.getStatus().equals(Status.STATUS_COMPLETED)) {
			//		return true;
			//	}
			//	return false;
			//
			//}).collect(Collectors.toList());

			setJsonFileDetail(list);
		} catch (Exception e) {
			e.printStackTrace();
		}

		listPane.setCenter(paneFileDetail);

		root.getChildren().add(listPane);

		listPane.prefWidthProperty().bind(root.getScene().widthProperty());
		listPane.prefHeightProperty().bind(root.getScene().heightProperty());
	}

	/**
	 * セールファクトリー
	 * @param fileStatusColumn
	 */
	private static void setCellValueFactory_his(TableColumn<FileInfoBean, Label> fileStatusColumn) {
		fileStatusColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<FileInfoBean, Label>, ObservableValue<Label>>() {
					@Override
					public ObservableValue<Label> call(TableColumn.CellDataFeatures<FileInfoBean, Label> arg0) {
						FileInfoBean data = arg0.getValue();
						final Label label = new Label();
						label.setTextFill(Color.RED);

						label.setBackground(new Background(
								new BackgroundFill(Color.BLUEVIOLET, new CornerRadii(10), new Insets(5))));
						label.setPrefSize(10, 10);

						if (data.getStatus().equals(Status.STATUS_NEW)) {
							ImageView img = new ImageView(imageNew);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(Status.STATUS_WORKING)) {
							ImageView img = new ImageView(imageWorking);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(Status.STATUS_COMPLETED)) {
							ImageView img = new ImageView(imageFinish);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);
						}

						return new SimpleObjectProperty<Label>(label);
					}

				});
	}
}
