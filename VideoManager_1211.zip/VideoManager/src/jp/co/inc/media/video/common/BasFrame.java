/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.media.video.common;

import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.xml.ws.WebServiceException;

import org.apache.commons.io.FilenameUtils;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.Duration;
import jp.co.inc.media.video.components.HistoryDialog;
import jp.co.inc.media.video.logic.UpLoadFile;
import jp.co.inc.media.video.logic.VideoUploadServiceLogic;
import jp.co.inc.media.video.service.ArrayOfFacility;
import jp.co.inc.media.video.service.DeleteRequest;
import jp.co.inc.media.video.service.Facility;
import jp.co.inc.media.video.service.LoginRespone;
import jp.co.inc.media.video.service.Patient;
import jp.co.inc.media.video.service.PatientRequest;
import jp.co.inc.media.video.utils.ClickableMenu;
import jp.co.inc.media.video.utils.FileInfoBean;
import jp.co.inc.media.video.utils.FileProperty;
import jp.co.inc.media.video.utils.FolderManager;
import jp.co.inc.media.video.utils.MemoInfo;
import jp.co.inc.media.video.utils.Messagebox;
import jp.co.inc.media.video.utils.OSDetector;
import jp.co.inc.media.video.utils.PatientInfo;
import jp.co.inc.media.video.utils.SysInfoBean;

public class BasFrame extends Application implements BasConst, MessageConst {

	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(BasFrame.class.getName());
	Scene scene;
	public static Stage mainStage;

	private static String workingDir = "";
	private static String workingDirJson = "";
	private static String strStats = "初期化";
	private static Label sText;
	private static Label lbPatientID;
	private static Label lbPatientName;
	private static StackPane stackFileList;
	private static StackPane stackPatientList;
	private static SplitPane splitHorizontal;
	private static Pane hboxButtomMain;
	private static double posSplitHorizonta[] = { 0.35f, 0.65f };

	private static final Image imageNew = new BasImage("unreg.png").getImage();
	private static final Image imageWorking = new BasImage("loading.png").getImage();
	private static final Image imageFinish = new BasImage("finish.png").getImage();

	// フォルダ選択ボタン
	private static BasButton btnSelectFolder;
	// 訪問先VBox
	private static HBox hvBoxFacility;
	// 検索VBox
	private static VBox serchVbox;
	// RadioButton
	private RadioButton[] rButtons = new RadioButton[3];
	private ToggleGroup tGroup;
	private String[] vehicle = { "全部訪問先", "ご自宅(居宅)のみ", "ご自宅(居宅)以外" };
	// タグ
	private static String tag[] = { null, "服用中薬剤", "口腔内", "食事", "保険証", "その他" };
	// 削除 ボタン
	private static BasButton btnDelete;
	// プログレスバー
	private ProgressBar progressBar = new ProgressBar(-1);
	// 備考
	private static TextArea textArea = new TextArea();
	// タイトル
	public static TextField txtTitle = new TextField();
	// 分類
	public static ComboBox<String> comboBunrui;
	// カレンダー（訪問日)
	private DatePicker dateVisitPicker;
	// 訪問先リスト
	private ComboBox<String> combo;
	// 動画ファイルリストを取得する
	public static List<FileInfoBean> fileInfolist;
	// 患者名検索
	public static TextField txtFind;
	// 患者リストを取得する
	private List<PatientInfo> patientInfolist;
	// ファイルリストテーブル
	private static TableView<FileInfoBean> table;
	// 患者リストテーブル
	private TableView<PatientInfo> tablePatient;
	// 静止画pane
	public static Pane imagePane = new Pane();
	// 動画タブ
	public static Tab movi;
	// 静止画タブ
	public static Tab image;
	// タブ
	public static TabPane tabPane;
	// カレンダー
	public static DatePicker datePicker;
	// progressHBox
	public Label labelProgress;
	public static Label labelPetcent;
	// progressLabel
	public static HBox hBoxPrpgress;
	// 動画送信 ボタン
	public static BasButton btnSend;
	public static SysInfoBean sysInfoBean = new SysInfoBean();
	public static PatientInfo patientInfo = new PatientInfo();
	// 検索ボタン
	private ObservableMap<String, String> FacilitMap = FXCollections.observableHashMap();
	// 検索VBox
	private static HBox hvBoxSearch;
	// ファイル一覧テーブルヘッダクリック
	private static boolean blnCliked = false;

	/**
	 * 画面スタート
	 * @param primaryStage システムのステージ
	 */
	@Override
	public void start(Stage primaryStage) {
		// 初期化
		initUI(primaryStage);
		mainStage = primaryStage;
		//アイコンの設定
		Image img = new Image(getClass().getResourceAsStream("media.jpg"));
		primaryStage.getIcons().add(img);
		mainStage.getIcons().add(img);
	}

	/**
	 * 画面コントロール設定
	 * @param primaryStage システムのステージ
	 */
	public void initUI(Stage primaryStage) {
		logger.log(Level.INFO, "START -initUI");
		try {
			// 初期化
			init(primaryStage);

			//作業フォルダ
			FileProperty filePro = new FileProperty(proFilePath);
			workingDirJson = filePro.getProperty("WorkingDirJson");
			workingDir = filePro.getProperty("WorkingDir");
			if (!"".equals(workingDir) && workingDirJson != null) {
				try {
					fileInfolist = FolderManager.getJsonInfoBean(workingDirJson);
				} catch (Exception e) {
					e.getStackTrace();
					logger.log(Level.SEVERE, THROW_INFO, e);
					fileInfolist = new ArrayList<FileInfoBean>();
				}
			} else {
				fileInfolist = new ArrayList<FileInfoBean>();
			}

			//イベント設定
			// 最大化状態を監視
			primaryStage.maximizedProperty().addListener(new ChangeListener<Boolean>() {
				@Override
				public void changed(ObservableValue<? extends Boolean> ov, Boolean t, Boolean t1) {
					splitHorizontal.setDividerPositions(posSplitHorizonta);
					if (primaryStage.isMaximized()) {
						//TODO
					} else {
						//TODO
					}
				}
			});

			// ファイルリスト呼び出す
			initFileList(fileInfolist, stackFileList);

			// 患者リスト初期化
			initPatientList(new ArrayList<PatientInfo>(), stackPatientList);
		} catch (Exception e) {
			e.getStackTrace();
			logger.log(Level.SEVERE, THROW_INFO, e);
			Messagebox.Error(mainStage, E0006);
		}
		logger.log(Level.INFO, "END -initUI");
	}

	/**
	 * 画面コントロール初期化
	 * @param primaryStage システムのステージ
	 * @throws Exception システム異常
	 */
	public void init(Stage primaryStage) throws Exception {
		splitHorizontal = new SplitPane();
		splitHorizontal.setOrientation(Orientation.HORIZONTAL);
		splitHorizontal.setDividerPositions(posSplitHorizonta);

		splitHorizontal.getItems().add(getLeftRootPane(topPane, bottomPane, primaryStage));
		splitHorizontal.getItems()
				.add(getRightRootPane(paneSub1, paneSub2, paneSub3, paneMain, primaryStage));

		final BorderPane rootPane = new BorderPane();
		rootPane.setStyle("-fx-border-style: solid; -fx-border-width: 0 0 0 0;");
		rootPane.setCenter(splitHorizontal);
		rootPane.setBottom(getBottomRootPane(strStats, primaryStage));

		// ウィンドウサイズ設定
		final StackPane gui = new StackPane(rootPane);
		Scene scene = new Scene(gui, WINDOWS_WHITH, WINDOWS_HEIGHT);
		primaryStage.setMaximized(false);

		rootPane.prefWidthProperty().bind(scene.widthProperty());
		rootPane.prefHeightProperty().bind(scene.heightProperty());

		gui.prefWidthProperty().bind(scene.widthProperty());
		gui.prefHeightProperty().bind(scene.heightProperty());

		final MenuBar menuBar = new MenuBar();
		rootPane.setTop(menuBar);

		final Menu menualMenu = menualMenu();
		final Menu historyMenu = historyMenu();
		FileProperty filePro = new FileProperty(proFilePath);
		String setting = filePro.getProperty("setting");
		if ("true".equals(setting) || "TRUE".equals(setting)) {
			menuBar.getMenus().addAll(menualMenu, historyMenu);
		} else {
			menuBar.getMenus().addAll(menualMenu, historyMenu);
		}

		//ウィンドウタイトル
		primaryStage.setTitle(SYSTEM_NAME);

		//ウィンドウサイズ変更の無効化
		primaryStage.setResizable(true);

		//フルスクリーンモードのオン、オフ
		//フルスクリーンオンの時はescキーで解除できます
		primaryStage.setFullScreen(false);
		primaryStage.setScene(scene);

		scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
		primaryStage.show();
		primaryStage.hide();

		// 無効に設定
		controlDisabled(true, ALL_ACTION);

	}

	/**
	 * 状態バーパネル取得
	 * @param strStats
	 */
	private StackPane getBottomRootPane(String strStats, Stage primaryStage) {

		BorderPane borderPane = new BorderPane();

		final HBox hBox = new HBox();
		sText = new Label(strStats);
		sText.setAlignment(Pos.BASELINE_LEFT);
		hBox.getChildren().addAll(sText);
		borderPane.setLeft(hBox);

		// プログレスバー
		progressBar.setPrefHeight(25);
		progressBar.setPrefWidth(200);
		// progressLabel
		labelProgress = new Label();
		labelProgress.setMinWidth(100);
		labelProgress.setMaxWidth(100);
		labelProgress.setText("");
		labelProgress.setAlignment(Pos.CENTER_RIGHT);

		labelPetcent = new Label();
		labelPetcent.setMinWidth(20);
		labelPetcent.setMaxWidth(20);
		labelPetcent.setText("%");
		labelPetcent.setAlignment(Pos.CENTER_LEFT);
		// progressLabel
		hBoxPrpgress = new HBox();
		hBoxPrpgress.getChildren().addAll(progressBar, labelProgress, labelPetcent);
		hBoxPrpgress.setVisible(false);
		borderPane.setRight(hBoxPrpgress);

		final StackPane pane = new StackPane(borderPane);
		return pane;
	}

	/**
	 * getLeftRootPane
	 * @param topPane
	 * @param bottomPane
	 * @param primaryStage
	 * @return
	 */
	private StackPane getLeftRootPane(BorderPane topPane, BorderPane bottomPane, Stage primaryStage) {

		// フォルダ選択ボタン
		btnSelectFolder = new BasButton("folder.png", ICON_SIZE, ICON_SIZE, BUTTON_FOLD_SELECT);

		// フォルダ選択ボタンイベント登録
		btnSelectFolder.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				DirectoryChooser directoryChooser = new DirectoryChooser();
				directoryChooser.setTitle("画像ファイルの格納フォルダを選択してください");
				System.out.println("workingDir=" + workingDir);
				if (!"".equals(workingDir) && new File(workingDir).isDirectory()) {
					directoryChooser.setInitialDirectory(new File(workingDir));
				}

				try {
					File file = directoryChooser.showDialog(primaryStage);
					if (file != null) {
						// 初期化
						workingDir = file.getAbsolutePath().replace("\\", "/");
						try {
							fileInfolist = FolderManager.getFileInfoList(workingDir);
							initFileList(fileInfolist, stackFileList);
						} catch (Exception e1) {
							String errmsg = e1.getMessage();
							logger.log(Level.SEVERE, THROW_INFO, e1);
							Messagebox.Error(mainStage, errmsg);
						}
					}
				} catch (Exception e1) {
					logger.log(Level.SEVERE, THROW_INFO, e1);
					Messagebox.Error(mainStage, E0014);

				}

			}
		});

		final HBox btnFoldSelect = new HBox();
		btnSelectFolder.setStyle(BUTTON_STYLE);
		btnSelectFolder.setAlignment(Pos.TOP_LEFT);
		btnFoldSelect.getChildren().add(btnSelectFolder);
		btnFoldSelect.setAlignment(Pos.TOP_LEFT);
		topPane.setTop(btnFoldSelect);

		// ファイル一覧
		stackFileList = new StackPane();
		stackFileList.setStyle("-fx-font-size: " + FONT_LIST_SIZE + "; -fx-font-weight: " + FONT_NORMAL);
		topPane.setCenter(stackFileList);

		// 訪問先VBox
		hvBoxFacility = new HBox();
		// 訪問先リスト
		combo = new ComboBox<>();
		combo.setCellFactory(new Callback<ListView<String>, ListCell<String>>() {
			@Override
			public ListCell<String> call(final ListView<String> list) {
				return new ListCell<String>() {

					@Override
					protected void updateItem(String item, boolean empty) {
						super.updateItem(item, empty);
						if (empty || item == null || item == null) {
							setText(null);
						} else {
							setText(item.toUpperCase());
						}
					}

					{
						Text text = new Text();
						setGraphic(text);
					}
				};
			}
		});

		// データ設定
		LoginRespone loginReponse = VideoUploadServiceLogic.getLoginReponse();
		if (loginReponse != null && loginReponse.getFacilityList() != null) {
			FacilitMap = FXCollections.observableHashMap();
			List<Facility> faci = loginReponse.getFacilityList().getFacility();
			System.out.println("==============訪問先情報==========");
			combo.getItems().add(null);
			if (faci != null) {
				for (Facility fac : faci) {
					System.out.println("VisitId:" + fac.getVisitId());
					System.out.println("VisitName：" + fac.getVisitName());
					combo.getItems().add(fac.getVisitName());

					if (!FacilitMap.containsKey(fac.getVisitName())) {
						FacilitMap.putIfAbsent(fac.getVisitName(), fac.getVisitId());
					}
				}
			}
		}
		combo.setPromptText(FACILITY_STYLE);
		combo.setStyle(COMBOLIST_STYLE);
		// カレンダー（訪問日)
		dateVisitPicker = new DatePicker();
		dateVisitPicker.setMinWidth(DATA_PICKER_SIZE);
		dateVisitPicker.setMaxWidth(DATA_PICKER_SIZE);
		dateVisitPicker.setStyle(PICKER_STYLE);
		dateVisitPicker.setPromptText(DATE_TYPE_YYYY_MM_DD);
		dateVisitPicker.setValue(LocalDate.now());
		// 入力無効に設定
		//dateVisitPicker.getEditor().setDisable(true);
		dateVisitPicker.setEditable(true);
		dateVisitPicker.setDisable(false);

		dateVisitPicker.getEditor().textProperty().addListener((observable, oldValue, newValue) -> {
			dateVisitPicker.getEditor().textProperty().setValue(newValue);
			try {
				dateVisitPicker
						.setValue(dateVisitPicker.getConverter().fromString(dateVisitPicker.getEditor().getText()));
				// 訪問先リスト設定
				setVisitList(dateVisitPicker, loginReponse, combo, FacilitMap,
						tGroup.getSelectedToggle().getUserData().toString());
			} catch (DateTimeParseException e) {
				if (newValue != null && newValue.length() >= 10) {
					dateVisitPicker.getEditor().textProperty().setValue(oldValue);
				}
			}
		});

		// 初期空白
		dateVisitPicker.setValue(null);

		final GridPane gridPane1 = new GridPane();
		gridPane1.setHgap(10);
		gridPane1.setVgap(10);
		gridPane1.add(dateVisitPicker, 0, 0);

		// 訪問日
		final Label labelVisitDate = new Label();
		labelVisitDate.setText(LABEL_VISIT_DATE);
		labelVisitDate.setStyle(LBL_STYLE);
		labelVisitDate.setAlignment(Pos.CENTER_LEFT);
		labelVisitDate.setMinWidth(80);
		labelVisitDate.setMaxWidth(80);
		labelVisitDate.setMinHeight(hvBoxFacility.getMinHeight());
		labelVisitDate.setMaxHeight(hvBoxFacility.getMaxHeight());

		// 訪問先
		final Label labelVisitSite = new Label();
		labelVisitSite.setText(LABVEL_ViSITNAME);
		labelVisitSite.setStyle(LBL_STYLE);
		labelVisitSite.setAlignment(Pos.CENTER_LEFT);
		labelVisitSite.setMinWidth(80);
		labelVisitSite.setMaxWidth(80);
		labelVisitSite.setMinHeight(hvBoxFacility.getMinHeight());
		labelVisitSite.setMaxHeight(hvBoxFacility.getMaxHeight());

		hvBoxFacility.getChildren().addAll(labelVisitDate, gridPane1);
		combo.prefWidthProperty().bind(hvBoxFacility.widthProperty());
		combo.prefHeightProperty().bind(hvBoxFacility.heightProperty());

		//トグルグループの作成
		tGroup = new ToggleGroup();
		final HBox radioHBox = new HBox();
		radioHBox.prefWidthProperty().bind(hvBoxFacility.widthProperty());

		radioHBox.getChildren().add(hvBoxFacility);
		for (int i = 0; i < rButtons.length; i++) {
			//ラジオボタンの作成
			rButtons[i] = new RadioButton(vehicle[i]);
			//タジオボタンをトグルグループに追加
			rButtons[i].setToggleGroup(tGroup);
		}
		//１番目のボタンを選択
		rButtons[0].setSelected(true);

		//ラジオボタンをHBoxに入れる
		int iradio = 0;
		for (RadioButton r : rButtons) {
			radioHBox.getChildren().add(r);
			radioHBox.setSpacing(10);
			// 0:全部訪問先 ;1:ご自宅(居宅)のみ ;2:ご自宅(居宅)以外
			r.setUserData(iradio);
			iradio++;
		}
		radioHBox.setAlignment(Pos.BASELINE_LEFT);
		radioHBox.setStyle(PICKER_STYLE);
		// changeEvent
		tGroup.selectedToggleProperty().addListener((obserableValue, old_toggle, new_toggle) -> {
			if (tGroup.getSelectedToggle() != null) {
				// 訪問先リスト設定
				setVisitList(dateVisitPicker, loginReponse, combo, FacilitMap,
						tGroup.getSelectedToggle().getUserData().toString());
			}
		});

		// 訪問先VBox
		HBox hvBoxVisit = new HBox();
		hvBoxVisit.getChildren().add(labelVisitSite);
		hvBoxVisit.getChildren().add(combo);

		serchVbox = new VBox();
		serchVbox.getChildren().add(hvBoxFacility);
		serchVbox.getChildren().add(radioHBox);
		serchVbox.getChildren().add(hvBoxVisit);

		// 検索
		hvBoxSearch = new HBox();
		// 検索テクストボックス
		txtFind = new TextField();
		txtFind.setPromptText(TXT_FIND);
		txtFind.setStyle(COMBOLIST_STYLE);
		txtFind.prefWidthProperty().bind(hvBoxSearch.widthProperty());
		txtFind.prefHeightProperty().bind(hvBoxSearch.heightProperty());
		// 検索ボタン
		final BasButton btnSearch = new BasButton("search.png", ICON_SIZE, ICON_SIZE);
		btnSearch.setId(BUTTON_ID_SEARCH);
		btnSearch.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickBtnSearch(e);
				} catch (IOException e1) {
					logger.log(Level.SEVERE, THROW_INFO, e1);
					Messagebox.Error(mainStage, E0015);
				}
			}
		});
		btnSearch.setStyle(BUTTON_STYLE);
		hvBoxSearch.getChildren().addAll(txtFind, btnSearch);
		bottomPane.setTop(hvBoxSearch);

		stackPatientList = new StackPane();
		stackPatientList.setStyle(COMBOLIST_STYLE);
		bottomPane.setCenter(stackPatientList);

		final SplitPane liftVerticalPane = new SplitPane();
		liftVerticalPane.setOrientation(Orientation.VERTICAL);
		liftVerticalPane.getItems().addAll(topPane, serchVbox, bottomPane);

		//Javafx splitpane 分割 固定
		double posRootLeft[] = { 0.50f, 0.50f };
		liftVerticalPane.setDividerPositions(posRootLeft);
		for (int i = 0; i < liftVerticalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = liftVerticalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootLeft[ind]);
				}
			});
		}
		final StackPane pane = new StackPane(liftVerticalPane);
		return pane;
	}

	/**
	 * 訪問先リスト設定
	 * @param dateVisitPicker
	 * @param loginReponse
	 * @param combo
	 * @param FacilitMap
	 * @param kubun
	 */
	private static void setVisitList(DatePicker dateVisitPicker, LoginRespone loginReponse, ComboBox<String> combo,
			ObservableMap<String, String> FacilitMap, String kubun) {
		logger.log(Level.INFO, "START -setVisitList");

		System.out.println("dateVisitPicker_changed:");
		System.out.println("Invoking getVisitList...");

		// 訪問日
		String dt = "";
		if (dateVisitPicker.getValue() != null) {
			dt = dateVisitPicker.getConverter().fromString(dateVisitPicker.getEditor().getText()).toString();
		}
		jp.co.inc.media.video.service.FacilityReponse _getVisitList__return;
		try {
			_getVisitList__return = VideoUploadServiceLogic
					.getPort()
					.getVisitList(loginReponse.getCert(), dt, kubun);
			System.out.println("getVisitList.result=" + _getVisitList__return.getError().getErrorMessage());

			combo.getItems().clear();
			if (SUCCESS.equals(_getVisitList__return.getError().getErrorCode())) {
				// データ設定
				if (_getVisitList__return.getFacilities() != null) {
					FacilitMap = FXCollections.observableHashMap();
					ArrayOfFacility facReponse = _getVisitList__return.getFacilities();
					List<Facility> faci = facReponse.getFacility();
					System.out.println("==============訪問先情報==========");
					combo.getItems().add(null);
					for (Facility fac : faci) {
						System.out.println("VisitId:" + fac.getVisitId());
						System.out.println("VisitName：" + fac.getVisitName());
						combo.getItems().add(fac.getVisitName());

						if (!FacilitMap.containsKey(fac.getVisitName())) {
							FacilitMap.putIfAbsent(fac.getVisitName(), fac.getVisitId());
						}
					}
				}
			} else {
				Messagebox.Error(mainStage, _getVisitList__return.getError().getErrorMessage());
			}

		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0017);
		}

		logger.log(Level.INFO, "END -setVisitList");
	}

	/**
	 * メディア メインパネル設定
	 * @param pa パネル
	 * @param mediafile メディアファイル
	 */
	private static void mediaMainSet(Pane pa, File mediafile) {
		logger.log(Level.INFO, "START -mediaMainSet");

		try {
			pa.getChildren().clear();
			// 動画再生クラスをインスタンス化
			Media Video = new Media(mediafile.toURI().toString());
			MediaPlayer player = new MediaPlayer(Video);
			MediaView mediaView = new MediaView(player);

			mediaView.setFitWidth(pa.getWidth());
			mediaView.setFitHeight(pa.getHeight());
			mediaView.fitHeightProperty().bind(pa.heightProperty());
			mediaView.fitWidthProperty().bind(pa.widthProperty());

			pa.getChildren().add(mediaView);
			StackPane.setAlignment(mediaView, Pos.CENTER);

			// ボリューム保存
			player.setVolume(SysInfoBean.getMediaVolume());

			pa.minWidthProperty().bind(hboxButtomMain.widthProperty());

			// 画面下に表示する情報バーを作成
			final VBox bottomNode = new VBox();
			// 時間表示スライダ作成
			final HBox topHNode = new HBox();
			topHNode.getChildren().add(MediaPlay.createTimeSlider(player, mediaView.getFitWidth() - 100));
			bottomNode.getChildren().add(topHNode);

			final HBox bottomHNode = new HBox(8);
			// 再生・停止・繰り返しボタン作成
			bottomHNode.getChildren().add(MediaPlay.createButton(player));

			// ボリューム表示スライダ作成
			bottomHNode.getChildren().add(MediaPlay.createVolumeSlider(player));
			bottomHNode.setAlignment(Pos.BASELINE_CENTER);
			bottomNode.getChildren().add(bottomHNode);
			pa.minWidthProperty().bind(bottomNode.widthProperty());

			hboxButtomMain.getChildren().clear();
			hboxButtomMain.getChildren().add(bottomNode);

		} catch (IllegalArgumentException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			Messagebox.Error(mainStage, E0018);
		} catch (SecurityException e) {
			Messagebox.Error(mainStage, E0018);
			logger.log(Level.SEVERE, THROW_INFO, e);
		}
		logger.log(Level.INFO, "END -mediaMainSet");
	}

	/**
	 * コントロールサブパネルを画面に設定
	 * @param pa
	 * @param mediafile
	 * @param subPane
	 * @throws InterruptedException
	 */
	private static void mediaSubSet(Pane pa, File mediafile, int subPane) throws InterruptedException {
		logger.log(Level.INFO, "START -mediaSubSet");

		try {
			// 動画再生クラスをインスタンス化
			final Media video = new Media(mediafile.toURI().toString());
			final MediaPlayer player = new MediaPlayer(video);
			final MediaView mediaView = new MediaView(player);
			mediaView.setFitWidth(pa.getWidth());
			mediaView.setFitHeight(pa.getHeight());
			mediaView.fitHeightProperty().bind(pa.heightProperty());
			mediaView.fitWidthProperty().bind(pa.widthProperty());

			// 音声を停止
			player.setVolume(0);

			final ExecutorService executor = Executors.newFixedThreadPool(1);
			Task<Long> task = new Task<Long>() {
				@Override
				public Long call() {
					long result = 1;

					executor.submit(() -> {
						if (subPane == MOVI_PANE1) {
							// 動画開始
							player.setStartTime(new Duration(MOVI_RUNTIME));
						} else if (subPane == MOVI_PANE2) {
							// 動画真ん中
							player.setStartTime(new Duration(sysInfoBean.getEndTime().toMillis() / 2));

						} else if (subPane == MOVI_PANE3) {
							// 動画終了
							player.setStartTime(
									new Duration(sysInfoBean.getEndTime().toMillis() - MOVI_RUNTIME));
						}
						// 開始設定
						player.startTimeProperty();

						// 再生開始
						((MediaView) pa.getChildren().get(0)).getMediaPlayer().play();

						try {
							Thread.sleep(MOVI_SLEEP);
						} catch (InterruptedException e) {
						}

						// 一時停止
						((MediaView) pa.getChildren().get(0)).getMediaPlayer().pause();

					});

					try {
						Thread.sleep(MOVI_SLEEP);
					} catch (InterruptedException e) {
					}

					// 一時停止
					((MediaView) pa.getChildren().get(0)).getMediaPlayer().pause();

					return result;
				}

			};

			// ExecutorService を利用してバックグラウンドスレッドを開始
			executor.submit(task);
			pa.getChildren().add(mediaView);

		} catch (IllegalArgumentException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			Messagebox.Error(mainStage, E0019);
		} catch (SecurityException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			Messagebox.Error(mainStage, E0019);
		}

		logger.log(Level.INFO, "END -mediaSubSet");

	}

	/**
	 * 静止画を撮る
	 * @param mediaView
	 * @param mediafileName
	 */
	public static void CaptureImage(MediaView mediaView, String mediafileName) {
		logger.log(Level.INFO, "START -CaptureImage");

		try {

			// フォルダを作成
			if (!Files.exists(Paths.get(imgPath))) {
				Files.createDirectory(Paths.get(imgPath));
			}

			try {
				Thread.sleep(CAPTURE_SLEEP);
			} catch (InterruptedException e) {
			}

			// 静止画名称
			final String imgName = imgPath + FilenameUtils.removeExtension(mediafileName);

			Platform.runLater(
					() -> {
						WritableImage snapshot = mediaView.snapshot(new SnapshotParameters(), null);

						// 静止画を保存
						try {
							saveImage(
									snapshot, imgName, EXTENSION_PNG.replace(".", ""));
						} catch (IOException e) {
							e.printStackTrace();
							logger.log(Level.SEVERE, THROW_INFO, e);
						}
					});

		} catch (IOException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);

		}

		logger.log(Level.INFO, "END -CaptureImage");

	}

	/**
	 * 静止画を保存
	 * @param image
	 * @param imagePath
	 * @param imageExtension
	 * @return
	 * @throws IOException
	 */
	private static boolean saveImage(WritableImage image, String imagePath, String imageExtension) throws IOException {
		File f = new File(imagePath + "." + imageExtension);
		return ImageIO.write(SwingFXUtils.fromFXImage(image, null), imageExtension, f);
	}

	/**
	 * パネルクリア
	 */
	public static void clearMemori() {
		logger.log(Level.INFO, "START -clearMemori");
		MemoInfo.viewMemoryInfo();
		for (Node node : paneSub1.getChildren()) {
			// メモリ解放
			((MediaView) node).getMediaPlayer().dispose();
			((MediaView) paneSub2.getChildren().get(0)).getMediaPlayer().dispose();
			((MediaView) paneSub3.getChildren().get(0)).getMediaPlayer().dispose();
			((MediaView) paneMain.getChildren().get(0)).getMediaPlayer().dispose();
			System.gc();
			System.out.println("メモリ解放 OK");
		}
		logger.log(Level.INFO, "END -clearMemori");
	}

	/**
	 * パネルクリア
	 */
	public static void mediaSetClear() {
		logger.log(Level.INFO, "START -mediaSetClear");
		paneMain.getChildren().clear();
		paneSub1.getChildren().clear();
		paneSub2.getChildren().clear();
		paneSub3.getChildren().clear();
		MemoInfo.viewMemoryInfo();
		logger.log(Level.INFO, "END -mediaSetClear");
	}

	private StackPane getRightRootPane(Pane paneSub1, Pane paneSub2, Pane bp3, Pane paneMain, Stage primaryStage) {
		paneSub1.setStyle(THUMBNAIL_PANE);
		paneSub2.setStyle(THUMBNAIL_PANE);
		bp3.setStyle(THUMBNAIL_PANE);

		final double posSubMedia[] = { 0.3333f, 0.6666f, 0.9999f };
		// サムネイルパネルSplitPane
		final SplitPane thumbnailPane = new SplitPane();
		thumbnailPane.setOrientation(Orientation.HORIZONTAL);
		thumbnailPane.getItems().addAll(paneSub1, paneSub2, bp3);
		thumbnailPane.setDividerPositions(posSubMedia);
		for (int i = 0; i < thumbnailPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = thumbnailPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posSubMedia[ind]);
				}
			});
		}

		final BorderPane mediaPane = new BorderPane();

		hboxButtomMain = new HBox();
		hboxButtomMain.setPrefHeight(40);
		mediaPane.setCenter(paneMain);
		mediaPane.setBottom(hboxButtomMain);

		final SplitPane vediaoHorizonalPane = new SplitPane();
		vediaoHorizonalPane.setOrientation(Orientation.HORIZONTAL);
		paneMain.setStyle(THUMBNAIL_PANE);
		vediaoHorizonalPane.getItems().addAll(mediaPane);
		final double posVideo[] = { 0.75f, 1.0f };
		vediaoHorizonalPane.setDividerPositions(posVideo);
		for (int i = 0; i < vediaoHorizonalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = vediaoHorizonalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posVideo[ind]);
				}
			});
		}

		final SplitPane rightVerticalPane = new SplitPane();
		rightVerticalPane.setOrientation(Orientation.VERTICAL);
		//		rightVerticalPane.getItems().addAll(thumbnailPane, vediaoHorizonalPane);

		double posRootRight[] = { 0.20f, 0.80f };

		// タブ
		tabPane = new TabPane();

		final SplitPane moviGroupSplitPane = new SplitPane();
		moviGroupSplitPane.getItems().addAll(thumbnailPane, vediaoHorizonalPane);
		moviGroupSplitPane.setOrientation(Orientation.VERTICAL);
		moviGroupSplitPane.setDividerPositions(posRootRight);
		for (int i = 0; i < moviGroupSplitPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = moviGroupSplitPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootRight[ind]);
				}
			});
		}

		// "動画タブ
		movi = new Tab("動画", moviGroupSplitPane);
		// "静止画タブ
		image = new Tab("静止画", imagePane);

		tabPane.getTabs().add(movi);
		tabPane.getTabs().add(image);
		rightVerticalPane.getItems().addAll(tabPane);
		rightVerticalPane.setDividerPositions(posRootRight);
		for (int i = 0; i < rightVerticalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = rightVerticalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootRight[ind]);
				}
			});
		}

		final HBox hvBoxRightBottom = new HBox();
		final HBox hBoxPatientID = new HBox();

		hBoxPatientID.setMinWidth(350);
		hBoxPatientID.setMaxWidth(350);

		// 患者ID
		lbPatientID = new Label();
		lbPatientID.setStyle(LBL_STYLE);
		lbPatientID.setAlignment(Pos.BASELINE_LEFT);
		hBoxPatientID.getChildren().add(lbPatientID);
		hBoxPatientID.setSpacing(10);

		// 患者名称
		lbPatientName = new Label();
		lbPatientName.setStyle(LBL_STYLE);
		lbPatientName.setAlignment(Pos.BASELINE_LEFT);
		hBoxPatientID.getChildren().add(lbPatientName);

		final FlowPane flowPaneAddDel = new FlowPane();
		final VBox inputAreaVBox = new VBox();
		final HBox inputAreaTileHbox = new HBox();
		final HBox inputTitleHbox = new HBox();

		// タイトル
		final Label labTitle = new Label(LABEL_TITLE);
		labTitle.setStyle(LBL_STYLE);
		labTitle.setMaxWidth(80);
		labTitle.setMinWidth(80);
		txtTitle = new TextField();
		txtTitle.setMaxWidth(290);
		txtTitle.setMinWidth(290);
		txtTitle.setStyle(COMBOLIST_STYLE);

		// 分類
		final Label labBunrui = new Label(LABEL_BUNRUI);
		labBunrui.setStyle(LBL_STYLE);
		labBunrui.setMaxWidth(80);
		labBunrui.setMinWidth(80);
		labBunrui.setAlignment(Pos.CENTER_LEFT);
		comboBunrui = new ComboBox<>();
		comboBunrui.setStyle(COMBOLIST_STYLE);
		comboBunrui.setCellFactory(new Callback<ListView<String>, ListCell<String>>() {
			@Override
			public ListCell<String> call(final ListView<String> list) {
				return new ListCell<String>() {

					@Override
					protected void updateItem(String item, boolean empty) {
						super.updateItem(item, empty);
						if (empty || item == null || item == null) {
							setText(null);
						} else {
							setText(item.toUpperCase());
						}
					}

					{
						Text text = new Text();
						setGraphic(text);
					}
				};
			}
		});
		comboBunrui.getItems().addAll(tag);
		comboBunrui.setMaxWidth(290);
		comboBunrui.setMinWidth(290);
		inputTitleHbox.getChildren().add(labBunrui);
		inputTitleHbox.getChildren().add(comboBunrui);

		final HBox titalHbox = new HBox();
		titalHbox.getChildren().add(labTitle);
		labTitle.setAlignment(Pos.CENTER_LEFT);
		titalHbox.getChildren().add(txtTitle);

		// 備考
		final Label labBikou = new Label(TEXTARIA_BIKOU);
		labBikou.setAlignment(Pos.CENTER_RIGHT);
		labBikou.setStyle(LBL_STYLE);
		labBikou.setMaxWidth(80);
		labBikou.setMinWidth(80);

		textArea = new TextArea();
		textArea.setStyle(COMBOLIST_STYLE);
		textArea.setWrapText(true);

		inputAreaTileHbox.getChildren().add(labBikou);
		inputAreaTileHbox.getChildren().add(textArea);
		textArea.setMaxHeight(75);
		textArea.setMinHeight(75);
		textArea.prefWidthProperty().bind(inputAreaVBox.widthProperty());

		final VBox titalVbox = new VBox();
		titalVbox.getChildren().add(titalHbox);
		titalVbox.setSpacing(10);
		titalVbox.getChildren().add(inputTitleHbox);

		final HBox connectTagRemarkHBox = new HBox();
		connectTagRemarkHBox.getChildren().add(titalVbox);
		connectTagRemarkHBox.setSpacing(10);
		connectTagRemarkHBox.getChildren().add(inputAreaTileHbox);

		flowPaneAddDel.prefWidthProperty().bind(rightBottomPane.widthProperty());

		inputAreaVBox.getChildren().add(connectTagRemarkHBox);
		inputAreaVBox.getChildren().add(flowPaneAddDel);
		inputAreaVBox.setSpacing(10);

		// カレンダーコントロール
		datePicker = new DatePicker();
		datePicker.setMinWidth(DATA_PICKER_SIZE);
		datePicker.setMaxWidth(DATA_PICKER_SIZE);
		datePicker.setStyle(PICKER_STYLE);
		datePicker.setPromptText(DATE_TYPE_YYYY_MM_DD);
		datePicker.setValue(LocalDate.now());
		// 入力無効に設定
		datePicker.getEditor().setDisable(true);

		final GridPane gridPane = new GridPane();
		gridPane.setHgap(10);
		gridPane.setVgap(10);
		gridPane.add(datePicker, 0, 0);

		flowPaneAddDel.getChildren().add(hBoxPatientID);
		flowPaneAddDel.getChildren().add(gridPane);

		final Label space = new Label();
		space.setAlignment(Pos.BOTTOM_LEFT);
		space.setStyle(LBL_STYLE);
		space.setMaxWidth(40);
		space.setMinWidth(40);

		flowPaneAddDel.getChildren().add(space);

		// 動画送信 ボタン
		btnSend = new BasButton("send.png", ICON_SIZE, ICON_SIZE, BUTTON_SEND);

		StackPane buttonPane = new StackPane();

		flowPaneAddDel.getChildren().add(buttonPane);
		btnSend.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickSend(e);
				} catch (IOException e1) {
					logger.log(Level.SEVERE, THROW_INFO, e1);
					Messagebox.Error(mainStage, E0020);
				}
			}
		});
		btnSend.setStyle(BUTTON_STYLE);

		// 削除 ボタン
		btnDelete = new BasButton("delete.png", ICON_SIZE, ICON_SIZE, BUTTON_DELETE);

		buttonPane.getChildren().add(btnSend);
		buttonPane.getChildren().add(btnDelete);

		btnDelete.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					onClickBtnDelete(e);
				} catch (IOException e1) {
					logger.log(Level.SEVERE, THROW_INFO, e1);
					Messagebox.Error(mainStage, E0001);
				}
			}
		});
		btnDelete.setStyle(BUTTON_STYLE);
		hvBoxRightBottom.setAlignment(Pos.BASELINE_CENTER);
		hvBoxRightBottom.setPadding(new Insets(5, 5, 5, 5));
		hvBoxRightBottom.getChildren().addAll(inputAreaVBox);
		rightBottomPane.setCenter(hvBoxRightBottom);

		final BorderPane borderPane = new BorderPane();
		borderPane.setCenter(rightVerticalPane);
		borderPane.setBottom(rightBottomPane);

		final StackPane pane = new StackPane(borderPane);

		return pane;
	}

	/**
	 * 動画リスト初期化
	 * @param List<FileInfoBean> 動画ファイルリスト
	 * @param Pane stackFileList パネル
	 * @param fileList
	 */
	@SuppressWarnings("unchecked")
	private static void initFileList(List<FileInfoBean> fileList, StackPane stackFileList) {
		logger.log(Level.INFO, "START -initScreen");

		// 動画ファイルリスト作成
		//初期化
		stackFileList.getChildren().clear();
		table = new TableView<>();
		final ObservableList<FileInfoBean> observableList = FXCollections.observableList(fileList);

		final TableColumn<FileInfoBean, CheckBox> fileCheckBoxColumn = new TableColumn<FileInfoBean, CheckBox>(
				FILE_TITLE_CHECKED);
		fileCheckBoxColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<FileInfoBean, CheckBox>, ObservableValue<CheckBox>>() {

					@Override
					public ObservableValue<CheckBox> call(TableColumn.CellDataFeatures<FileInfoBean, CheckBox> arg0) {
						final FileInfoBean data = arg0.getValue();
						final CheckBox checkBox = new CheckBox();
						checkBox.selectedProperty().setValue(data.isChecked());

						if (data.getStatus().equals(Status.STATUS_COMPLETED)) {
							// 無効に設定
							checkBox.setDisable(true);
						}

						checkBox.selectedProperty().addListener(new ChangeListener<Boolean>() {
							@Override
							public void changed(ObservableValue<? extends Boolean> ov, Boolean old_val,
									Boolean new_val) {
								data.setChecked(new_val);
								checkBox.setSelected(new_val);
							}
						});

						return new SimpleObjectProperty<CheckBox>(checkBox);
					}

				});

		fileCheckBoxColumn.setMaxWidth(40);
		fileCheckBoxColumn.setMinWidth(40);

		final TableColumn<FileInfoBean, Label> fileStatusColumn = new TableColumn<FileInfoBean, Label>(
				FILE_TITLE_STATAS);
		fileStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
		fileStatusColumn.setMaxWidth(60);
		fileStatusColumn.setMinWidth(60);

		final TableColumn<FileInfoBean, String> fileNameColumn = new TableColumn<>(FILE_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory<>("fileName"));
		fileNameColumn.setPrefWidth(300);
		fileNameColumn.setMinWidth(300);

		final TableColumn<FileInfoBean, String> lastedUpdateColumn = new TableColumn<>(FILE_TITLE_LASTED_UPDATE);
		lastedUpdateColumn.setCellValueFactory(new PropertyValueFactory<>("updateDate"));
		lastedUpdateColumn.setMaxWidth(180);
		lastedUpdateColumn.setMinWidth(180);
		final TableColumn<FileInfoBean, String> fileSizeColumn = new TableColumn<>(FILE_TITLE_SIZE);
		fileSizeColumn.setCellValueFactory(new PropertyValueFactory<>("fileSize"));
		fileSizeColumn.setMaxWidth(150);
		fileSizeColumn.setMinWidth(150);
		fileSizeColumn.setStyle("-fx-alignment: CENTER-RIGHT;");
		final TableColumn<FileInfoBean, String> patient_idColumn = new TableColumn<>(FILE_TITLE_PATIENT_ID);
		patient_idColumn.setCellValueFactory(new PropertyValueFactory<>("patient_id"));
		patient_idColumn.setPrefWidth(150);
		patient_idColumn.setMinWidth(150);
		patient_idColumn.setStyle("-fx-alignment: CENTER-RIGHT;");
		final TableColumn<FileInfoBean, String> movie_send_timeColumn = new TableColumn<>(FILE_TITLE_MOVIE_SEND_TIME);
		movie_send_timeColumn.setCellValueFactory(new PropertyValueFactory<>("movie_send_time"));
		movie_send_timeColumn.setMaxWidth(180);
		movie_send_timeColumn.setMinWidth(180);
		final TableColumn<FileInfoBean, String> fileBikouColumn = new TableColumn<>(FILE_TITLE_BIKOU);
		fileBikouColumn.setCellValueFactory(new PropertyValueFactory<>("bikou"));
		patient_idColumn.setMaxWidth(200);
		patient_idColumn.setMinWidth(200);
		final TableColumn<FileInfoBean, String> fileUploadFileNameColumn = new TableColumn<>(
				FILE_TITLE_UPLOAD_FILE_NAME);
		fileUploadFileNameColumn.setCellValueFactory(new PropertyValueFactory<>("uploadFileName"));

		/** ファイルリストクリックイベント処理 */
		setCellValueFactory(fileStatusColumn);

		// カラム追加
		//table.getColumns().setAll(fileCheckBoxColumn, fileStatusColumn, fileNameColumn, lastedUpdateColumn,
		//		fileSizeColumn, fileBikouColumn, fileUploadFileNameColumn);
		// checkkbox　アップロードファイル名　表示しない
		table.getColumns().setAll(fileStatusColumn, fileNameColumn, lastedUpdateColumn,
				fileSizeColumn, patient_idColumn, movie_send_timeColumn, fileBikouColumn);
		table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		table.setItems(observableList);
		// sort
		table.sort();

		//// sort
		//Comparator<FileInfoBean> comparator = Comparator
		//		.<FileInfoBean, String> comparing(model -> model.getStatus().toString());
		//FXCollections.sort(table.getItems(), comparator);

		// ヘッダクリックイベント作成（状況）
		table.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				double headerHeight = table.lookup(".column-header-background").getBoundsInLocal().getHeight();
				if (headerHeight > event.getY() && event.getX() < 60) {
					if (blnCliked) {
						blnCliked = false;
						Comparator<FileInfoBean> comparator = Comparator
								.<FileInfoBean, String> comparing(model -> model.getStatus().toString());
						FXCollections.sort(table.getItems(), comparator);
					} else {
						blnCliked = true;
						Comparator<FileInfoBean> comparator = Comparator
								.<FileInfoBean, String> comparing(model -> model.getStatus().toString()).reversed();
						FXCollections.sort(table.getItems(), comparator);
					}
				}
			}
		});

		table.setMinWidth(300);
		stackFileList.getChildren().add(table);
		stackFileList.prefHeightProperty().bind(table.heightProperty());
		//		stackFileList.prefWidthProperty().bind(table.widthProperty());

		if (fileList.size() > 0) {
			//選択状態を検知するバインディングの設定
			table_addListener(observableList);

		}

		// ファイル一覧選択
		table.requestFocus();
		table.getSelectionModel().select(sysInfoBean.getSelectedRow());
		table.getFocusModel().focus(sysInfoBean.getSelectedRow());

		logger.log(Level.INFO, "END -initScreen");
	}

	/**
	 * 患者リスト初期化
	 * @param List<PatientInfo> 患者情報リスト
	 * @param Pane stackPatientList パネル
	 */
	@SuppressWarnings("unchecked")
	private void initPatientList(List<PatientInfo> patientInfolist, Pane stackPatientList) {
		logger.log(Level.INFO, "START -initPatientList");
		//初期化
		stackPatientList.getChildren().clear();
		tablePatient = new TableView<>();
		ObservableList<PatientInfo> patient_observableList = FXCollections.observableList(patientInfolist);

		final TableColumn<PatientInfo, String> patientIdColumn = new TableColumn<PatientInfo, String>(
				PATIENT_TITLE_PATIENT_ID);
		patientIdColumn.setCellValueFactory(new PropertyValueFactory<>("patientId"));
		patientIdColumn.setPrefWidth(100);
		patientIdColumn.setMinWidth(100);
		patientIdColumn.setStyle("-fx-alignment: CENTER-RIGHT;");
		final TableColumn<PatientInfo, String> patientNameColumn = new TableColumn<>(PATIENT_TITLE_PATIENT_NAME);
		patientNameColumn.setCellValueFactory(new PropertyValueFactory<>("patientName"));
		patientNameColumn.setPrefWidth(200);
		patientNameColumn.setMinWidth(200);
		final TableColumn<PatientInfo, String> birthdayColumn = new TableColumn<>(PATIENT_TITLE_BIRTHDAY);
		birthdayColumn.setCellValueFactory(new PropertyValueFactory<>("birthday"));
		birthdayColumn.setMaxWidth(150);
		birthdayColumn.setMinWidth(150);
		final TableColumn<PatientInfo, String> visitName = new TableColumn<>(PATIENT_TITLE_ViSITNAME);
		visitName.setCellValueFactory(new PropertyValueFactory<>("visitName"));
		visitName.setPrefWidth(250);
		visitName.setMinWidth(250);
		final TableColumn<PatientInfo, String> sexColumn = new TableColumn<>(PATIENT_TITLE_SEX);
		sexColumn.setCellValueFactory(new PropertyValueFactory<>("sex"));
		sexColumn.setMaxWidth(55);
		sexColumn.setMinWidth(55);

		// カラム追加
		tablePatient.setItems(patient_observableList);

		tablePatient.getColumns().setAll(patientIdColumn, patientNameColumn, visitName, birthdayColumn, sexColumn);
		//tablePatient.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		// sort
		tablePatient.sort();

		tablePatient.setMinWidth(300);
		stackPatientList.getChildren().add(tablePatient);
		stackPatientList.prefHeightProperty().bind(tablePatient.heightProperty());
		tablePatient.prefWidthProperty().bind(stackPatientList.widthProperty());

		//選択状態を検知するバインディングの設定
		tablePatient_addListener(patient_observableList);

		logger.log(Level.INFO, "END -initPatientList");
	}

	/**
	 * 動画ファイルリストリスナー登録
	 * @param fileList
	 */
	private static void table_addListener(final ObservableList<FileInfoBean> fileList) {

		logger.log(Level.INFO, "START -table_addListener");

		table.getSelectionModel().selectedItemProperty().addListener((ov, old, current) -> {

			logger.log(Level.INFO, "選択したファイル:" + current.getFilePath());
			// タスクバーに設定
			strStats = "  選択したファイル:" + current.getFilePath();
			textArea.setText(current.getBikou());
			txtTitle.setText(current.getTitle());
			comboBunrui.getSelectionModel().select(current.getBunrui());

			sText.setText(strStats);
			if (fileList != null) {
				table_selected(fileList, current);
			}

			// 送信済の判定
			if (current.getStatus().equals(Status.STATUS_COMPLETED)) {
				// 無効に設定
				controlDisabled(true, FILE_LIST_SELECT_ACTION);

			} else {
				// 有効に設定
				controlDisabled(false, FILE_LIST_SELECT_ACTION);
			}
		});

		logger.log(Level.INFO, "END -table_addListener");
	}

	/**
	 * 患者リストリスナー登録
	 * @param fileList
	 */
	private void tablePatient_addListener(final ObservableList<PatientInfo> fileList) {

		logger.log(Level.INFO, "START -tablePatient_addListener");

		tablePatient.getSelectionModel().selectedItemProperty().addListener((ov, old, current) -> {
			// 病院ID
			patientInfo.setHospitalId(current.getHospitalId());
			// 患者ID
			patientInfo.setPatientId(current.getPatientId());

			// 患者ID
			lbPatientID.setText(current.getPatientId());
			// 患者名称
			lbPatientName.setText(current.getPatientName());

		});

		logger.log(Level.INFO, "END -tablePatient_addListener");
	}

	/**
	 * 動画ファイルリスト選択
	 * @param fileList
	 * @param current 選択したファイル
	 */
	private static void table_selected(ObservableList<FileInfoBean> fileList, FileInfoBean current) {
		logger.log(Level.INFO, "START -table_selected");

		if (fileList != null) {
			// 初期化
			for (int count = 0; count < fileList.size(); count++) {
				FileInfoBean fileInfo = new FileInfoBean();
				fileInfo = fileList.get(count);
				if (fileInfo.getFileName().equals(current.getFileName())) {
					// 選択した列を保存
					sysInfoBean.setSelectedRow(count);
					// 選択したファイル名称
					sysInfoBean.setSelectedFileName(current.getFileName());
					datePicker.getEditor().clear();
					// カレンダーにファイル最終更新日を設定
					// ofPatternスタティックメソッドでフォーマットを指定してインスタンスを生成する
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_TYPE_YYYY_MM_DD_HH_MM);
					// 書式を指定してLocalDateTimeのインスタンスを作成する
					LocalDateTime dt = LocalDateTime.parse(current.getUpdateDate(), dtf);
					datePicker.setValue(datePicker.getConverter().fromString(datePicker.getEditor().getText()));
					datePicker.setValue(LocalDate.of(dt.getYear(), dt.getMonth(), dt.getDayOfMonth()));
					// 動画ファイル取得
					final File file = new File(fileList.get(count).getFilePath());

					SingleSelectionModel<Tab> selectionModel = tabPane.getSelectionModel();

					if (FilenameUtils.getExtension(fileList.get(count).getFileName())
							.equals(EXTENSION_MP4.replace(".", ""))) {
						// 動画
						selectionModel.select(movi);

						// メディア設定
						mediaSetClear();
						// メモリクリア
						clearMemori();

						if (file != null) {
							try {
								Thread.sleep(MOVI_SETTING_SLEEP);
							} catch (InterruptedException e) {
							}
							for (int imedia = 0; imedia < 4; imedia++) {
								// 動画ファイルのパスを取得
								if (imedia == MOVI_PANE1) {
									try {
										mediaSubSet(paneSub1, file, MOVI_PANE1);
									} catch (InterruptedException e) {
									}
								} else if (imedia == MOVI_PANE2) {
									// 動画ファイル設定
									try {
										mediaSubSet(paneSub2, file, MOVI_PANE2);
									} catch (InterruptedException e) {
									}
								} else if (imedia == MOVI_PANE3) {
									// 動画ファイル設定
									try {
										mediaSubSet(paneSub3, file, MOVI_PANE3);
									} catch (InterruptedException e) {
									}
								} else if (imedia == MOVI_MAIN_PANE) {
									// メインパネル設定
									mediaMainSet(paneMain, file);
								}
							}
						}

					} else {
						// 静止画
						selectionModel.select(image);

						imagePane.getChildren().clear();
						if (file != null) {
							Image image = new Image("file:" + file.getPath());
							ImageView imgView = new ImageView(image);
							imagePane.getChildren().add(imgView);

							imgView.fitHeightProperty().bind(imagePane.heightProperty());
							imgView.fitWidthProperty().bind(imagePane.widthProperty());

						}
					}

				}

			}
		}
		logger.log(Level.INFO, "END -table_selected");
	}

	/**
	 * セールファクトリー
	 * @param fileStatusColumn
	 */
	private static void setCellValueFactory(TableColumn<FileInfoBean, Label> fileStatusColumn) {
		fileStatusColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<FileInfoBean, Label>, ObservableValue<Label>>() {
					@Override
					public ObservableValue<Label> call(TableColumn.CellDataFeatures<FileInfoBean, Label> arg0) {
						FileInfoBean data = arg0.getValue();
						final Label label = new Label();
						label.setTextFill(Color.RED);

						label.setBackground(new Background(
								new BackgroundFill(Color.BLUEVIOLET, new CornerRadii(10), new Insets(5))));
						label.setPrefSize(10, 10);

						if (data.getStatus().equals(Status.STATUS_NEW)) {
							ImageView img = new ImageView(imageNew);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(Status.STATUS_WORKING)) {
							ImageView img = new ImageView(imageWorking);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(Status.STATUS_COMPLETED)) {
							ImageView img = new ImageView(imageFinish);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);
						}

						return new SimpleObjectProperty<Label>(label);
					}

				});
	}

	private Menu menualMenu() {
		final ClickableMenu clickableMenu = new ClickableMenu(MENU_TITLE);
		clickableMenu.setOnAction(evt -> menualHandle());
		return clickableMenu;
	}

	private void menualHandle() {
		try {
			OSDetector.open(pdfFilePath);
		} catch (Exception e) {
			e.printStackTrace();
			logger.log(Level.SEVERE, THROW_INFO, e);
			Messagebox.Error(mainStage, E0022);
		}
	}

	private Menu historyMenu() {
		final ClickableMenu clickableMenu = new ClickableMenu(SEND_HIS_TITLE);
		clickableMenu.setOnAction(evt -> historyHandle());
		return clickableMenu;
	}

	private void historyHandle() {
		final Stage historyDialog = new HistoryDialog(mainStage, SEND_HIS_TITLE, 800, 600);
		historyDialog.sizeToScene();
		historyDialog.show();
	}

	/**
	 * ファイルステータス更新
	 * @param status システムのステージ
	 */
	public static void updateFileStatus(Status status) {
		// ステータス更新
		for (FileInfoBean file : fileInfolist) {
			if (file.getFileName().equals(sysInfoBean.getSelectedFileName())) {

				// 送信中に更新
				file.setStatus(status);
				System.out.println("ステータス更新" + file.getFileName() + ":" + file.getStatus());
			}

		}
	}

	/**
	 * 日付の妥当性チェックを行います。
	 * 指定した日付文字列（yyyy/MM/dd or yyyy-MM-dd）が
	 * カレンダーに存在するかどうかを返します。
	 * @param strDate チェック対象の文字列
	 * @return 存在する日付の場合true
	 */
	public static boolean checkDate(String strDate) {
		if (strDate.equals("")) {
			return true;
		}
		strDate = strDate.replace('-', '/');
		DateFormat format = DateFormat.getDateInstance();
		// 日付/時刻解析を厳密に行うかどうかを設定する。
		format.setLenient(false);
		try {
			format.parse(strDate);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 検索処理
	 * @param event
	 * @throws IOException
	 */
	private void onClickBtnSearch(ActionEvent event) throws IOException {
		logger.log(Level.INFO, "START -onClickBtnSearch");

		if (!checkDate(dateVisitPicker.getEditor().getText())) {
			Messagebox.Error(mainStage, E0005);
			return;
		}

		// 病院ID初期化
		patientInfo.setHospitalId(null);
		// 患者ID初期化
		patientInfo.setPatientId(null);
		// 患者ID
		lbPatientID.setText(null);
		// 患者名称
		lbPatientName.setText(null);

		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// Date型変換
		Date formatDate = null;

		try {
			//ロケールを指定してCalendarインスタンスを取得
			final Locale locale = new Locale("ja", "JP", "JP");
			//和暦にフォーマットする
			final DateFormat japaseseFormat = new SimpleDateFormat("GGGGy年M月d日", locale);

			// 初期化
			patientInfolist = new ArrayList<PatientInfo>();
			System.out.println("Invoking searchPatient...");
			LoginRespone loginReponse = VideoUploadServiceLogic.getLoginReponse();
			if (loginReponse != null) {
				PatientRequest _searchPatient_request = new PatientRequest();
				_searchPatient_request.setCertification(loginReponse.getCert());
				_searchPatient_request.setPatientName(txtFind.getText());
				_searchPatient_request.setVisitId(FacilitMap.get(combo.getValue()));
				_searchPatient_request.setVisitDate(dateVisitPicker.getEditor().getText().replace("/", "-"));

				jp.co.inc.media.video.service.PatientResponse _searchPatient__return = VideoUploadServiceLogic
						.getPort()
						.searchPatient(_searchPatient_request);
				if (SUCCESS.equals(_searchPatient__return.getError().getErrorCode())) {
					if (_searchPatient__return.getPatients() != null) {
						List<Patient> patientList = _searchPatient__return.getPatients().getPatient();
						System.out.println("==============患者検索==========");
						for (Patient patient : patientList) {

							PatientInfo patientInfo = new PatientInfo();
							patientInfo.setHospitalId(patient.getHospId());
							patientInfo.setPatientId(patient.getPatientId());
							patientInfo.setPatientName(patient.getPatientName());
							if (!patient.getPatientBirthday().equals("")) {
								try {
									formatDate = sdf.parse(patient.getPatientBirthday());
								} catch (ParseException e) {
									logger.log(Level.SEVERE, THROW_INFO, e);
									Messagebox.Error(mainStage, E0015);
								}
								patientInfo.setBirthday(japaseseFormat.format(formatDate));

							}
							patientInfo.setVisitName(patient.getVisitName());
							patientInfo.setSex(patient.getPatientSex());

							patientInfolist.add(patientInfo);

						}
					}
				} else {
					Messagebox.Error(mainStage, _searchPatient__return.getError().getErrorMessage());
				}
			}
		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, E0021);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0015);
		}

		// 患者に設定
		initPatientList(patientInfolist, stackPatientList);

		//tablePatient.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		logger.log(Level.INFO, "END -onClickBtnSearch");
	}

	/**
	 * 送信処理
	 * @param event
	 * @throws IOException
	 */
	private void onClickSend(ActionEvent event) throws IOException {
		logger.log(Level.INFO, "START -onClickSend");
		boolean result = Messagebox.Confirmation(mainStage, I0001);
		if (result) {
		} else {
			return;
		}
		// 患者情報が無い場合、エラー
		if (patientInfo.getPatientId() == null) {
			Messagebox.Error(mainStage, E0004);
			return;
		}
		// 選択なしの場合
		if (sysInfoBean.getSelectedFileName().isEmpty()) {
			Messagebox.Info(mainStage, I0003);
			return;
		}
		// 備考桁数チェック
		if (textArea.getText().getBytes().length > BIKOIU_MAX_LENGTH) {
			Messagebox.Info(mainStage, I0005);
			return;
		}
		// タイトル桁数チェック
		if (txtTitle.getText().getBytes().length > TITAL_MAX_LENGTH) {
			Messagebox.Info(mainStage, I0008);
			return;
		}
		// ステータスチェック
		for (FileInfoBean file : fileInfolist) {
			if (file.getFileName().equals(sysInfoBean.getSelectedFileName())) {
				// ステータスが完了の場合
				if (file.getStatus().equals(Status.STATUS_COMPLETED)) {
					Messagebox.Info(mainStage, I0006);
					return;
				}

				// 送信中に更新
				file.setStatus(Status.STATUS_WORKING);
				// 撮影日
				file.setMovie_date(BasFrame.datePicker.getValue().toString());
				// 医院ID
				file.setHosp_id(BasFrame.patientInfo.getHospitalId());
				// 患者ID
				file.setPatient_id(BasFrame.patientInfo.getPatientId());
				// 備考を設定
				file.setBikou(textArea.getText());
				// 分類を設定
				file.setBunrui(comboBunrui.getValue());
				// タイトルを設定
				file.setTitle(txtTitle.getText());
			}
		}

		try {
			//容量のチェック
			LoginRespone loginReponse = VideoUploadServiceLogic.getLoginReponse();
			System.out.println("Invoking isOverCapacity...");
			jp.co.inc.media.video.service.BoolRepone _isOverCapacity__return = VideoUploadServiceLogic.getPort()
					.isOverCapacity(loginReponse.getCert());
			System.out.println("isOverCapacity.result=" + _isOverCapacity__return.getError().getErrorMessage());

			if (SUCCESS.equals(_isOverCapacity__return.getError().getErrorCode())) {
				// 容量のチェック
				if (_isOverCapacity__return.isRet()) {
					Messagebox.Info(mainStage, I0007);
					return;
				}
			} else {
				Messagebox.Error(mainStage, _isOverCapacity__return.getError().getErrorMessage());
				return;
			}

		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0023);
		}

		// ファイルリスト初期化
		initFileList(fileInfolist, stackFileList);
		// 画面制御
		controlDisabled(true, SEND_ACTION);

		// ファイル送信
		for (FileInfoBean file : fileInfolist) {
			if (file.getFileName().equals(sysInfoBean.getSelectedFileName())) {

				// ファイルアップロード開始
				final UpLoadFile uploadfile = new UpLoadFile();

				// プログレスバーのプロパティバインド
				progressBar.progressProperty().bind(uploadfile.progressProperty());
				labelProgress.textProperty().bind(uploadfile.messageProperty());

				// アップロード実行
				final ExecutorService executor = Executors.newSingleThreadExecutor();
				executor.submit(uploadfile);

				// 完了時のイベント
				uploadfile.addEventHandler(WorkerStateEvent.WORKER_STATE_SUCCEEDED, wse -> {

					// ファイルリスト初期化
					initFileList(fileInfolist, stackFileList);

					try {
						FolderManager.saveFileintoBeanToJson(workingDirJson, fileInfolist);
					} catch (Exception e) {
						String errmsg = e.getMessage();
						Messagebox.Error(mainStage, errmsg);
						e.printStackTrace();
						logger.log(Level.SEVERE, THROW_INFO, e);
					}

					// タスク終了
					executor.shutdown();
				});
			}
		}

		logger.log(Level.INFO, "END -onClickSend");
	}

	/**
	 * 削除処理
	 * @param event
	 * @throws IOException
	 */
	private void onClickBtnDelete(ActionEvent event) throws IOException {
		logger.log(Level.INFO, "START -onClickBtnDelete");

		boolean result = Messagebox.Confirmation(mainStage, I0002);
		if (result) {
		} else {
			return;
		}
		try {
			// 初期化
			patientInfolist = new ArrayList<PatientInfo>();
			System.out.println("Invoking delete...");

			LoginRespone loginReponse = VideoUploadServiceLogic.getLoginReponse();
			if (loginReponse != null) {
				DeleteRequest _mediaDelete_request = new DeleteRequest();

				// ステータスチェック
				for (FileInfoBean file : fileInfolist) {
					if (file.getFileName().equals(sysInfoBean.getSelectedFileName())) {

						_mediaDelete_request.setCertification(loginReponse.getCert());
						_mediaDelete_request.setPatientId(file.getPatient_id());
						_mediaDelete_request.setMovieDate(file.getMovie_date().toString().replace("-", "/"));
						_mediaDelete_request.setMovieIndex(file.getMovie_index());

						if (file.getFileName().toUpperCase().endsWith(EXTENSION_MP4.toUpperCase())) {
							// 動画
							System.out.println("Invoking mediaDelete...");
							_mediaDelete_request.setMovieName(file.getFileName());
							_mediaDelete_request.setPhotoDate(file.getMovie_date().toString().replace("-", "/"));
							jp.co.inc.media.video.service.BoolRepone _mediaDelete__return = VideoUploadServiceLogic
									.getPort()
									.mediaDelete(_mediaDelete_request);
							System.out.println("mediaDelete.result=" + _mediaDelete__return);

							if (SUCCESS.equals(_mediaDelete__return.getError().getErrorCode())) {
								System.out.println("==============動画削除完了==========");
							} else {
								Messagebox.Error(mainStage, _mediaDelete__return.getError().getErrorMessage());
								return;
							}

							// 静止画
							_mediaDelete_request.setPhotoDate(file.getUpdateDate().toString().replace("-", "/"));
							System.out.println("Invoking mediaDeleteImg...");
							_mediaDelete_request
									.setMovieName(FilenameUtils.removeExtension(file.getFileName()) + EXTENSION_PNG);

							jp.co.inc.media.video.service.BoolRepone _mediaDeleteImg__return = VideoUploadServiceLogic
									.getPort()
									.mediaDeleteImg(_mediaDelete_request);
							System.out.println("mediaDeleteImg.result=" + _mediaDeleteImg__return);
							if (SUCCESS.equals(_mediaDeleteImg__return.getError().getErrorCode())) {
								System.out.println("==============静止画削除完了==========");
							} else {
								Messagebox.Error(mainStage, _mediaDeleteImg__return.getError().getErrorMessage());
								return;
							}

						} else {
							// 静止画
							_mediaDelete_request.setPhotoDate(file.getUpdateDate().toString().replace("-", "/"));
							System.out.println("Invoking mediaDeleteImg...");
							jp.co.inc.media.video.service.BoolRepone _mediaDeleteImg__return = VideoUploadServiceLogic
									.getPort()
									.mediaDeleteImg(_mediaDelete_request);
							System.out.println("mediaDeleteImg.result=" + _mediaDeleteImg__return);
							if (SUCCESS.equals(_mediaDeleteImg__return.getError().getErrorCode())) {
								System.out.println("==============静止画削除完了==========");
							} else {
								Messagebox.Error(mainStage, _mediaDeleteImg__return.getError().getErrorMessage());
								return;
							}
						}
					}
				}
			}
		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(mainStage, E0024);
		}

		// 未に更新
		updateFileStatus(Status.STATUS_NEW);

		try {
			FolderManager.saveFileintoBeanToJson(workingDirJson, fileInfolist);
		} catch (Exception e) {
			String errmsg = e.getMessage();
			Messagebox.Error(mainStage, errmsg);
			e.printStackTrace();
			logger.log(Level.SEVERE, THROW_INFO, e);
		}

		// ファイルリスト初期化
		initFileList(fileInfolist, stackFileList);

		logger.log(Level.INFO, "END -onClickBtnDelete");
	}

	/**
	 *  画面項目制御
	 * @param enable true:非活性 false:活性
	 * @param intButton 0:送信ボタン、1:削除ボタン、2:ファイルリスト選択、3:すべて
	 */
	public static void controlDisabled(boolean enable, int intButton) {
		logger.log(Level.INFO, "START -btnAllDisabled:" + enable);

		if (intButton == SEND_ACTION) {
			// ファイルリストテーブル
			stackFileList.setDisable(enable);
			// ファイルリストテーブル
			stackPatientList.setDisable(enable);
			// 削除 ボタン
			btnDelete.setVisible(false);
			// 動画送信 ボタン
			//btnSend.setVisible(!enable);
			btnSend.setDisable(enable);
			// ファイルリストテーブル
			stackPatientList.setDisable(enable);
			// 訪問先
			hvBoxFacility.setDisable(enable);
			// 備考ボタン
			textArea.setDisable(enable);
			// 分類
			comboBunrui.setDisable(enable);
			// 検索VBox
			serchVbox.setDisable(enable);
			hvBoxSearch.setDisable(enable);
			// カレンダー
			datePicker.setDisable(enable);
			// フォルダ選択ボタン
			btnSelectFolder.setDisable(enable);
		} else if (intButton == FILE_LIST_SELECT_ACTION) {
			// ファイルリストテーブル
			stackFileList.setDisable(false);
			// 削除 ボタン
			btnDelete.setVisible(enable);
			// 動画送信 ボタン
			btnSend.setVisible(!enable);
			btnSend.setDisable(enable);
			// ファイルリストテーブル
			stackPatientList.setDisable(enable);
			// 訪問先
			hvBoxFacility.setDisable(enable);
			// 備考ボタン
			textArea.setDisable(enable);
			// タイトル
			txtTitle.setDisable(enable);
			// 分類
			comboBunrui.setDisable(enable);
			// 検索VBox
			serchVbox.setDisable(enable);
			hvBoxSearch.setDisable(enable);
			// カレンダー
			datePicker.setDisable(enable);
			// フォルダ選択ボタン
			btnSelectFolder.setDisable(false);
		} else if (intButton == ALL_ACTION) {
			// ファイルリストテーブル
			stackFileList.setDisable(enable);
			// 削除 ボタン
			btnDelete.setVisible(!enable);
			// 動画送信 ボタン
			btnSend.setVisible(!enable);
			// ファイルリストテーブル
			stackPatientList.setDisable(enable);
			// 訪問先
			hvBoxFacility.setDisable(enable);
			// 備考ボタン
			textArea.setDisable(enable);
			// タイトル
			txtTitle.setDisable(enable);
			// 分類
			comboBunrui.setDisable(enable);
			// 検索VBox
			serchVbox.setDisable(enable);
			hvBoxSearch.setDisable(enable);
			// カレンダー
			datePicker.setDisable(enable);
		}
		logger.log(Level.INFO, "END -btnAllDisabled:" + enable);
	}

	/**
	 * 画面表示制御
	 * @param primaryStage  システムのステージ
	 * @param blnVisial true:画面表示、false:画面非表
	 */
	public void show(Stage primaryStage, boolean blnVisial) {
		if (blnVisial) {
			primaryStage.show();
		} else {
			primaryStage.hide();
		}
	}
}
