using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VideoUploadService
{
    public partial class Download : System.Web.UI.Page
    {
        readonly String basePath = System.Configuration.ConfigurationManager.AppSettings["DownloadFolder"].ToString();
        private static string winPackgeRecognizer = ".msi";
        private static string macPackgeRecognizer = ".dmg";
        private static string macManualRecognizer = "mac";
        private static string winManualRecognizer = "win";
        private static string packgePath = "Packge";
        private static string manualPath = "Manual";

        //�p�b�P�[�W�t�@�C��
        string packgeFilePath;
        //�}�j���A���t�@�C��
        string manualFilePath;

        protected void Page_Load(object sender, EventArgs e)
        {
            String osInfo = Request.UserAgent.ToLower();

            if (osInfo.IndexOf("windows nt") != -1)
            {
                var winPackgeInfo =  FileInfoGet(basePath + @packgePath, winPackgeRecognizer);
                packgeFilePath = winPackgeInfo["file"];
                DrawDownloadTable(packgeTable, winPackgeInfo, Packge_Click);

                var winManualInfo = FileInfoGet(basePath + @manualPath, winManualRecognizer);
                manualFilePath = winManualInfo["file"];
                DrawDownloadTable(manualTable, winManualInfo, Manual_Click);
            }
            else if (osInfo.IndexOf("mac os") != -1)
            {
                var macPackgeInfo = FileInfoGet(basePath + @packgePath, macPackgeRecognizer);
                packgeFilePath = macPackgeInfo["file"];
                DrawDownloadTable(packgeTable, macPackgeInfo, Packge_Click);

                var macManualInfo = FileInfoGet(basePath + @manualPath, macManualRecognizer);
                manualFilePath = macManualInfo["file"];
                DrawDownloadTable(manualTable, macManualInfo, Manual_Click);
            }
            else
            {
                Label1.Text = "�K�p�ȃp�b�P�[�W������܂���B";
            }
        }

        /// <summary>
        /// �t�@�C�������擾����
        /// </summary>
        /// <param name="path"></param>
        /// <param name="fileRecognizer"></param>
        /// <returns></returns>
        private Dictionary<string, string> FileInfoGet(string filePath, string fileRecognizer)
        {
            var fileInfo = new Dictionary<string, string>();
            string[] fileVsions = Directory.GetDirectories(filePath);
            //�ŐV�o�[�W�����ԍ�
            string latestVison = Path.GetFileName(fileVsions.Max());
            fileInfo.Add("vision", latestVison);
            string[] releaseDate = Directory.GetDirectories(fileVsions.Max());
            //�ŐV�X�V��
            string lasteReleaseDate = Path.GetFileName(releaseDate.Max());
            fileInfo.Add("lasteUpdate", lasteReleaseDate);
            //�t�@�C�������擾
            string[] files = Directory.GetFiles(releaseDate.Max());
            if (files.Length != 0)
            {
                foreach (string file in files)
                {
                    if (file.ToLower().Contains(fileRecognizer))
                    {
                        fileInfo.Add("file", file);
                    }
                }
            }
            return fileInfo;
        }

        /// <summary>
        /// �\���쐬����
        /// </summary>
        /// <param name="table"></param>
        /// <param name="htData"></param>
        /// <param name="handler"></param>
        private void DrawDownloadTable(Table table, Dictionary<string, string> fileInfo, EventHandler handler)
        {
            TableHeaderRow headerRow = new TableHeaderRow();
            TableHeaderCell headerCell;
            headerCell = new TableHeaderCell();
            if (fileInfo["file"].Contains(packgePath))
            {
                headerCell.Text = "�p�b�P�[�W��";
            }
            else if (fileInfo["file"].Contains(manualPath))
            {
                headerCell.Text = "�}�j���A����";
            }
            else
            {
                headerCell.Text = "���O";
            }
            headerCell.Width = Unit.Pixel(450);
            headerRow.Cells.Add(headerCell);

            headerCell = new TableHeaderCell();
            headerCell.Text = "�o�b�W����";
            headerCell.Width = Unit.Pixel(150);
            headerRow.Cells.Add(headerCell);

            headerCell = new TableHeaderCell();
            headerCell.Text = "�X�V���t";
            headerCell.Width = Unit.Pixel(150);
            headerRow.Cells.Add(headerCell);

            table.Rows.Add(headerRow);
            TableRow row = new TableRow();
            TableCell cell;

            //�t�@�C����
            cell = new TableCell();
            LinkButton winLinkButton = new LinkButton();
            winLinkButton.Text = Path.GetFileName(fileInfo["file"]);
            winLinkButton.Click += handler;
            cell.Controls.Add(winLinkButton);
            row.Cells.Add(cell);

            //�t�@�C���o�[�W����
            cell = new TableCell();
            cell.Text = fileInfo["vision"];
            row.Cells.Add(cell);

            //���t
            cell = new TableCell();
            string date = fileInfo["lasteUpdate"];
            cell.Text = date.Substring(0, 4) + "/" + date.Substring(4, 2) + "/" + date.Substring(date.Length - 2, 2);
            row.Cells.Add(cell);
            table.Rows.Add(row);

        }

        /// <summary>
        /// �p�b�P�[�W�_�E�����[�h
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Packge_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"" + Path.GetFileName(packgeFilePath) + "\"");
            Response.WriteFile(packgeFilePath);
            Response.End();
        }

        /// <summary>
        /// �}�j���A���t�@�C���_�E�����[�h
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Manual_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"" + Path.GetFileName(manualFilePath) + "\"");
            Response.WriteFile(manualFilePath);
            Response.End();
        }

    }
}