﻿using System.Collections.Generic;

namespace VideoUploadService.Models
{
    public class MovieReponse
    {
        //グループID
        public string Group_id { get; set; }
        //医院ID
        public string Hosp_id { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //UserID
        public string User_id { get; set; }
        //アップロード動画ファイル名
        public List<string> Upload_movie_name { get; set; }
        //エラー
        public ErrorReponse Error { get; set; }

    }
}