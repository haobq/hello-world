package jp.co.inc.meida.video.common;

import java.nio.file.Paths;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class BasImage implements  BasConst, MessageConst {
	private Image image;
	private String imgPath ="";
	private ImageView imageView;


	public ImageView getImageView(int width,int height ) {
		imageView = new ImageView(image);
		imageView.setFitWidth(width);
		imageView.setFitHeight(height);
		return imageView;
	}


	public Image getImage() {
		return image;
	}

	public BasImage(String imgName) {
		imgPath =imgFilePath + imgName;
		image = new Image(Paths.get(imgPath).toUri().toString(), true);
	}


	public String getImageFile() {
		return imgPath;
	}
}
