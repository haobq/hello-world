package jp.co.inc.meida.video.utils;

import javafx.beans.property.SimpleBooleanProperty;
import jp.co.inc.meida.video.common.BasConst;

/**
 * MP4の動画ファイル情報格納BEAN
 *
 * @author HaoBuQian
 * @version 1.0.0
 */
public class FileInfoBean  implements BasConst{

	/** チェックボックス */
	public SimpleBooleanProperty checked = new SimpleBooleanProperty();

	/** 送信済 */
	public boolean fileSended = false;

	public boolean isFileSended() {
		return fileSended;
	}

	public void setFileSended(boolean fileSended) {
		this.fileSended = fileSended;
	}

	/** 動画ファイル名 */
	public String fileName = "";

	/** ローカル動画ファイルパス */
	public String filePath = "";

	/** 動画ファイルサイズ(byte) */
	public long fileSize = 0;

	// 動画ファイル最新更新日時 */
	public String updateDate = "";

	// アップロード状況 */
	public String status = STATUS_NEW;

	// アップロードのファイル名 */
	public String uploadFileName = "";


	/** 備考 */
	public String bikou = "";

	/**
	 * @return 備考 bikou
	 */
	public String getBikou() {
		return bikou;
	}

	/**
	 * @param bikou セットする 備考
	 */
	public void setBikou(String bikou) {
		this.bikou = bikou;
	}

	/** 病院ID */
	public String hospitalId = "";

	/** 患者ID */
	public String patientID = "";

    public boolean isChecked() {
        return checked.get();
    }

    public void setChecked(boolean checked) {
        this.checked.set(checked);
    }

	/**
	 * 動画ファイル名取得
	 * @return 動画ファイル名
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * 動画ファイル名設定
	 *
	 * @param fileName　動画ファイル名
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * 動画ファイル名サイズ取得
	 *
	 * @return 動画ファイル名サイズ
	 */
	public long getFileSize() {
		return fileSize;
	}

	/**
	 * 動画ファイルサイズ設定
	 *
	 * @param fileSize　動画ファイルサイズ
	 */
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	/**
	 * 動画ファイル撮影日取得
	 *
	 * @return 動画ファイル撮影日
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * 動画ファイル撮影日設定
	 *
	 * @param updateDate　動画ファイル撮影日
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * アップロード状況取得<br>
	 *
	 *  [未] アップロードしていない <br>
	 *  [中] アップロード処理中 <br>
	 *  [完] アップロード処理完了<br>
	 *
	 * @return アップロード状況
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * アップロード状況設定 <br>
	 *
	 * [未] アップロードしていない<br>
	 * [中] アップロード処理中 <br>
	 * [完] アップロード処理完了<br>
	 *
	 * @param status アップロード状況
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * アップロードファイル名取得
	 *
	 * @return String アップロードファイル名
	 */
	public String getUploadFileName() {
		return uploadFileName;
	}

	/**
	 * アップロードファイル名設定
	 *
	 * @param uploadFileName アップロードファイル名
	 */
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	/**
	 * 病院ID取得
	 *
	 * @return String 病院ID
	 */
	public String getHospitalId() {
		return hospitalId;
	}

	/**
	 * 病院ID設定
	 *
	 * @param hospitalId 病院ID
	 */
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}

	/**
	 * 患者ID取得
	 *
	 * @return 患者ID
	 */
	public String getPatientID() {
		return patientID;
	}

	/**
	 * 患者ID設定
	 *
	 * @param patientID 患者ID
	 */
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}

	/**
	 * ローカル動画ファイルパス取得
	 *
	 * @return ローカル動画ファイルパス
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * ローカル動画ファイルパス設定
	 *
	 * @param filePath ローカル動画ファイルパス
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

}
