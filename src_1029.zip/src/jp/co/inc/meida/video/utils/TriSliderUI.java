package jp.co.inc.meida.video.utils;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import javax.swing.JSlider;
import javax.swing.plaf.metal.MetalSliderUI;

//スライダー描画クラス
public class TriSliderUI extends MetalSliderUI {
	// マーカー描画スレッド
	@Override
	public void paintThumb(Graphics g) {
		if (slider.getOrientation() == JSlider.HORIZONTAL) {
			Graphics2D g2 = (Graphics2D) g;
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g2.setPaint(Color.LIGHT_GRAY);
			int x = thumbRect.x + thumbRect.width / 2 - 2;
			int y = thumbRect.y;
			int w = 5;
			int h = thumbRect.height;
			g2.fill3DRect(x, y, w, h, true);
		} else {
			super.paintThumb(g);
		}
	}

	// トラック描画スレッド
	@Override
	public void paintTrack(Graphics g) {
		int cx, cy, cw, ch;
		int pad;
		Rectangle trackBounds = trackRect;
		if (slider.getOrientation() == JSlider.HORIZONTAL) {
			Graphics2D g2 = (Graphics2D) g;
			// いろいろ座標設定
			pad = trackBuffer;
			cx = pad;
			cy = -2 + trackBounds.height / 2;
			cw = trackBounds.width;

			// アンチエイリアス設定
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g2.translate(trackBounds.x, trackBounds.y + cy);

			// トラックの背景描画（ライトグレー
			g2.setPaint(Color.LIGHT_GRAY);
			Polygon polygon1 = new Polygon();
			polygon1.addPoint(0, cy);
			polygon1.addPoint(cw, cy);
			polygon1.addPoint(cw, -cy);
			g2.fillPolygon(polygon1);

			// トラックの支点から現在地までの描画（白
			g2.setPaint(Color.ORANGE);
			Polygon polygon2 = new Polygon();
			polygon2.addPoint(0, cy);
			polygon2.addPoint(thumbRect.x, cy);
			polygon2.addPoint(thumbRect.x, cy - (int) (cy * 2 / (double) cw * thumbRect.x));
			g2.fillPolygon(polygon2);
			polygon2.reset();

			// 黒い枠線描画
			g2.setPaint(Color.black);
			g2.drawPolygon(polygon1);

			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g2.translate(-trackBounds.x, -(trackBounds.y + cy));
		} else {
			super.paintTrack(g);
		}
	}
}
