package jp.co.inc.meida.video.common;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import jp.co.inc.meida.video.utils.SysInfoBean;

public interface MediaPlay {

	ImageView imgRepeat = new BasImage("repeat.png").getImageView(16, 16);

	/**
	 * 再生、一時停止、停止、連続再生ボタンを作成
	 * @param mp
	 * @return
	 */
	public static Node createButton(final MediaPlayer mp) {
		// 表示コンポーネントを作成
		StackPane root = new StackPane();
		Button playButton = new  BasButton("play.png",16,16);
		Button pauseButton = new  BasButton("pause.png",16,16);
		ToggleButton repeatButton = new ToggleButton();
		root.getChildren().add(pauseButton);
		root.getChildren().add(playButton);

		root.setAlignment(Pos.TOP_CENTER);


		// 再生ボタンにイベントを登録
		EventHandler<ActionEvent> playHandler = (e) -> {
			// 再生開始
			mp.play();

			playButton.setVisible(false);
			pauseButton.setVisible(true);

		};
		playButton.addEventHandler(ActionEvent.ACTION, playHandler);

		// 一時停止ボタンにイベントを登録
		EventHandler<ActionEvent> pauseHandler = (e) -> {
			// 一時停止
			mp.pause();
			playButton.setVisible(true);
			pauseButton.setVisible(false);
		};
		pauseButton.addEventHandler(ActionEvent.ACTION, pauseHandler);

		// 連続再生設定
		Runnable repeatFunc = () -> {
			// 連続再生ボタンの状態を取得し
			if (repeatButton.isSelected()) {
				// 頭だしして再生
				mp.seek(mp.getStartTime());
				mp.play();
			} else {
				// 頭だしして停止
				mp.seek(mp.getStartTime());
				mp.stop();
			}
			;
		};
		mp.setOnEndOfMedia(repeatFunc);

		return root;
	}


	/**
	 * 再生、一時停止、停止、連続再生ボタンを設定
	 * @param mp
	 * @return
	 */
	public static Node setButton( MediaPlayer mp) {
		// 表示コンポーネントを作成
		HBox root = new HBox(1.0);
		Button playButton = new Button("Play");
		Button pauseButton = new Button("Pause");
		Button stopButton = new Button("Stop");
		ToggleButton repeatButton = new ToggleButton("Repeat");
		root.getChildren().add(playButton);
		root.getChildren().add(pauseButton);
		root.getChildren().add(stopButton);
		root.getChildren().add(repeatButton);

		// 再生ボタンにイベントを登録
		EventHandler<ActionEvent> playHandler = (e) -> {
			// 再生開始
			mp.play();
		};
		playButton.addEventHandler(ActionEvent.ACTION, playHandler);

		// 一時停止ボタンにイベントを登録
		EventHandler<ActionEvent> pauseHandler = (e) -> {
			// 一時停止
			mp.pause();
		};
		pauseButton.addEventHandler(ActionEvent.ACTION, pauseHandler);

		//root.setPaddingnew Insets(5, 5, 5, 5));

		return root;
	}


	/**
	 * 再生時間を表示・操作するスライダを作成
	 * @param mp
	 * @return
	 */
	public static Node createTimeSlider(MediaPlayer mp, double sliderWidth) {
		// 表示コンポーネントを作成
		HBox root = new HBox();
		final Slider slider = new Slider();
		slider.setPrefWidth(sliderWidth);
		final Label info = new Label();
		root.getChildren().add(slider);
		root.setSpacing(10);
		root.getChildren().add(info);

		// 再生準備完了時に各種情報を取得する関数を登録
		final Runnable beforeFunc = mp.getOnReady(); // 現在のレディ関数
		Runnable readyFunc = () -> {
			// 先に登録された関数を実行
			if (beforeFunc != null) {
				beforeFunc.run();
			}

			// スライダの値を設定
			slider.setMin(mp.getStartTime().toSeconds());
			slider.setMax(mp.getStopTime().toSeconds());
			slider.setSnapToTicks(true);
			// 終了時間設定
			SysInfoBean.setEndTime(mp.getStopTime()) ;
		};
		mp.setOnReady(readyFunc);

		// 再生中にスライダを移動
		// プレイヤの現在時間が変更されるたびに呼び出されるリスナを登録
		ChangeListener<? super Duration> playListener = (ov, old, current) -> {
			// 動画の情報をラベル出力
			String infoStr = String.format("%4.2f", mp.getCurrentTime().toSeconds())
					+ "/"
					+ String.format("%4.2f", mp.getTotalDuration().toSeconds());
			info.setText(infoStr);

			// スライダを移動
			slider.setValue(mp.getCurrentTime().toSeconds());

		};
		mp.currentTimeProperty().addListener(playListener);

		// スライダを操作するとシークする
		EventHandler<MouseEvent> sliderHandler = (e) -> {
			// スライダを操作すると、シークする
			mp.seek(javafx.util.Duration.seconds(slider.getValue()));

		};
		slider.addEventFilter(MouseEvent.MOUSE_RELEASED, sliderHandler);

		return root;
	}

	/**
	 * ボリュームを表示・操作するスライダを作成
	 * @param mp
	 * @return
	 */
	public static Node createVolumeSlider(MediaPlayer mp) {
		// 表示コンポーネントを作成
		HBox root = new HBox(5.0);
		final Label info = new Label();
		final Slider slider = new Slider();

		// 再生準備完了時に各種情報を取得する関数を登録
		final Runnable beforeFunc = mp.getOnReady(); // 現在のレディ関数
		Runnable readyFunc = () -> {
			// 先に登録された関数を実行
			if (beforeFunc != null) {
				beforeFunc.run();
			}
			// スライダの値を設定
			slider.setMin(0);
			slider.setMax(50);

			slider.setValue(mp.getVolume());
		};
		mp.setOnReady(readyFunc);

		// 再生中にボリュームを表示
		// プレイヤの現在時間が変更されるたびに呼び出されるリスナを登録
		ChangeListener<? super Number> sliderListener = (ov, old, current) -> {
			// 動画の情報をラベル出力
			String infoStr = String.format("Vol:%4.2f", mp.getVolume());
			info.setText(infoStr);

			// スライダにあわせてボリュームを変更
			mp.setVolume(slider.getValue());
			SysInfoBean.setMediaVolume(slider.getValue());

		};
		slider.valueProperty().addListener(sliderListener);

		double sliderWidth = 200;
		slider.setId("custom-slider");

        slider.setMinWidth(sliderWidth);
        slider.setMaxWidth(sliderWidth);

		final ProgressBar pb = new ProgressBar(0);
		pb.setMinHeight(20);
		pb.setMaxHeight(20);
		pb.setMinWidth(slider.getMinWidth());
		pb.setMaxWidth(slider.getMaxWidth());

		final ProgressIndicator pi = new ProgressIndicator(0);

		slider.valueProperty().addListener(
				(ObservableValue<? extends Number> ov, Number old_val,
						Number new_val) -> {
							pb.setProgress(new_val.doubleValue()/50);
							pi.setProgress(pb.getProgress());
						});

		Pane pane = new Pane();
		pane.getChildren().addAll(pb, slider);
		root.getChildren().add(pane);
		//root.getChildren().add(info);

		return root;
	}

}
