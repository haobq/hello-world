package jp.co.inc.meida.video.components;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import jp.co.inc.meida.video.common.BasDialog;
import jp.co.inc.meida.video.utils.FileProperty;

public class VersioneDialog extends BasDialog {

	public VersioneDialog(Stage owner, String title, int width, int height) throws Exception {
		super(owner, title, width, height);
		FileProperty filePro = new FileProperty(verFilePath);

		GridPane gridpane = new GridPane();
		gridpane.setPadding(new Insets(5));
		gridpane.setHgap(5);
		gridpane.setVgap(5);
		String ver = filePro.getProperty("Ver");
		String update = filePro.getProperty("Date");

		Label verNameLbl = new Label("バージョン: ");
		gridpane.add(verNameLbl, 0, 1);

		Label updatanameLbl = new Label("最新更新日: ");
		gridpane.add(updatanameLbl, 0, 2);

		Label verVauleLbl = new Label(ver);
		gridpane.add(verVauleLbl, 1, 1);

		Label updataVauleLbl = new Label(update);
		gridpane.add(updataVauleLbl, 1, 2);

		Label compLbl = new Label("メディア株式会社");
		gridpane.add(compLbl, 0, 3);


		Button closebtn = new Button("確認");
		closebtn.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				close();
			}
		});
		gridpane.add(closebtn, 1, 4);
		gridpane.setAlignment(Pos.CENTER);
		GridPane.setHalignment(closebtn, HPos.RIGHT);
		root.getChildren().add(gridpane);
	}
}
