﻿namespace VideoUploadService.Models
{
    public class DeleteRequest
    {
        //認証情報
        public Certification Certification { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //連番
        public int Movie_index { get; set; }
        //撮影日
        public string Movie_date { get; set; }
        //ファイル名称
        public string Movie_name { get; set; }
        //保存パス
        public string Video_path { get; set; }
    }
}