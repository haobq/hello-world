﻿namespace VideoUploadService.Models
{
    public class MovieRequest
    {
        //認証情報
        public Certification Certification { get; set; }
        //患者ID
        public string Patient_id { get; set; }
        //動画番号
        public string Video_no { get; set; }
        //画像区分1：初回訪問ガイド
        public string Video_kbn { get; set; }
        //備考
        public string Remarks { get; set; }
        //保存パス
        public string Video_path { get; set; }
        //修正者
        public string Edit_user { get; set; }
        //タイトル
        public string Title { get; set; }
        //分類
        public string Video_tag { get; set; }
        //連番
        public int Movie_index { get; set; }
        //撮影日
        public string Movie_date { get; set; }
        //動画ファイル名
        public string Movie_name { get; set; }
        //動画ファイル総分割件数
        public int FileCount { get; set; }
        //動画内容
        public byte[] Movie_context { get; set; }
        //サイズ(Byte)
        public long Movie_size { get; set; }
        //分割したファイル番号
        public int SpriteFileNo { get; set; }
        //クライアント登録時間(yyyyMMddmmddsssss(ミリ秒） 
        public string Millisecond { get; set; }
    }
}