using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Services;
using VideoUploadService.Models;
using VideoUploadService.Models.Common;
using System.IO.Compression;
using log4net;


namespace VideoUploadService
{
    /// <summary>
    /// VideoUploadService の概要の説明です
    /// </summary>
    [WebService(Namespace = "http://video.media.inc.co.jp/service")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
  
    public class VideoUploadService : System.Web.Services.WebService
    {
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// ログイン
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public LoginRespone Login(string group_id, string user_id, string password, string hosp_id,string session_flg)
        {
            string temp_hosp_id = hosp_id;
            LoginRespone cer = new LoginRespone();
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            try
            {
                string userpw = password;
                //パスワードSHA256バッシュ
                string secPass = Tools.GetEncryptString(userpw, group_id, user_id);
                Certification cert = new Certification();
                cert.Group_id = group_id;
                cert.Hosp_id = hosp_id;
                cert.User_id = user_id;
                cert.Session_flg = session_flg;
                //1.グループIDの存在確認処理を行う​
                if (Tools.IsCorrect(group_id) == false)
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgWrongUserIdOrPassword);
                    BizException biz = new BizException("GroupID", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.ユーザの存在確認処理を行う​
                if (Tools.IsCorrect(group_id, user_id, secPass) == false)
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgWrongUserIdOrPassword);
                    BizException biz = new BizException("UserIdOrPassword", Constants.MsgWrongUserIdOrPassword);
                    throw biz;
                }

                //3.端末ID取得
                string terminal_id = Tools.GetTerminalId(group_id, user_id);
                if (string.IsNullOrEmpty(terminal_id))
                {
                    BizException biz = new BizException("terminal_id", Constants.MsgNotUseTerminalId);
                    throw biz;
                }

                //4.グループに紐付けた医院リストを取得する
                if (string.IsNullOrEmpty(temp_hosp_id))
                {
                    List<Clinic> clinicList = Tools.GetClinic_data(group_id, user_id);
                    cer.ClinicList = clinicList;
                    if (!clinicList.Any())
                    {
                        BizException biz = new BizException("HospError", Constants.MsgHospError);
                        throw biz;
                    }

                    //医院リスト一つの場合、訪問先リストを取得する
                    if (clinicList.Count == 1)
                    {
                        hosp_id = clinicList[0].Hosp_id;
                        temp_hosp_id = hosp_id;
                    }
                    else
                    {
                        // 医院リストが複数の場合、画面に戻って医院を選択する
                        cer.Cert = cert;
                        cer.Error = error;
                        return cer;
                    }
                }

                //5.医院リスト一つの場合、訪問先リストを取得する
                if (!string.IsNullOrEmpty(temp_hosp_id))
                {
                    List<Clinic> clinicList = Tools.GetClinic_data(group_id, user_id);
                    foreach (Clinic clinic in clinicList)
                    {
                        if (temp_hosp_id.Equals(clinic.Hosp_id))
                        {
                            List<Clinic> temp = new List<Clinic>();
                            temp.Add(clinic);
                            cer.ClinicList = temp;
                            break;
                        }
                    }

                    List<Facility> facilityList = Tools.GetFacility_data(temp_hosp_id);
                    cer.FacilityList = facilityList;
                    if (!facilityList.Any())
                    {
                        logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgFacilityError);
                        BizException biz = new BizException("FacilityError", Constants.MsgFacilityError);
                        throw biz;
                    }
                }

                //6.セッション情報を追加
                if (Tools.InsertTblSession(user_id, hosp_id, group_id, terminal_id,session_flg) == false)
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + Constants.MsgExistedAuthentication);
                    BizException biz = new BizException("Authentication", Constants.MsgExistedAuthentication);
                    throw biz;
                }
                //7.認証キー取得する
                cert.Media_auth = Tools.GetMedia_auth(user_id, hosp_id, group_id, session_flg);
                cert.Hosp_id = temp_hosp_id;
                cer.Cert = cert;
            }
            catch (BizException bz)
            {
                logger.Error(hosp_id + "-" + user_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode,biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            catch (Exception e)
            {
                logger.Error(hosp_id + "-" + user_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            cer.Error = error;
            return cer;

        }
        /// <summary>
        /// 訪問日の訪問先リスト取得する
        /// </summary>
        /// <param name="certification"></param>
        /// <param name="visitDate"></param>
        /// <returns></returns>
        [WebMethod]
        public FacilityReponse GetVisitList(Certification certification, string visitDate, string kbn)
        {
            FacilityReponse facilityReponse = new FacilityReponse();
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            try
            {
                string temp_hosp_id = certification.Hosp_id;
                List<Facility> facilityList = Tools.GetFacility_data(temp_hosp_id, visitDate, kbn);
                facilityReponse.facilities = facilityList;
            } catch (Exception)
            {
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            facilityReponse.Error = error;
            return facilityReponse;
        }

        /// <summary>
        /// 動画・写真の情報取得
        /// </summary>
        /// <param name="certification"></param>
        /// <param name="patient_id"></param>
        /// <param name="movie_index"></param>
        /// <param name="movie_type"></param>
        /// <returns></returns>
        [WebMethod]
        public MovieListReponse GetMovieList(Certification cert, string patient_id, string movie_type, string movie_index)
        {
            MovieListReponse movieList = new MovieListReponse();
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            try
            {
                //1. tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(cert.Group_id, cert.User_id, cert.Media_auth, cert.Session_flg) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2. 動画・写真の情報取得
                if (string.IsNullOrEmpty(movie_type))
                {
                    BizException biz = new BizException("MsgMoviType", Constants.MsgMoviType);
                    throw biz;
                }
                movieList.movies = Tools.GetMovieList(cert.Hosp_id,patient_id, movie_index, movie_type);
            }
            catch (BizException bz)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            movieList.Error = error;
            return movieList;
        }

        /// <summary>
        /// 動画削除
        /// </summary>
        /// <param name="certification"></param>
        /// <param name="patient_id"></param>
        /// <param name="movie_index"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolRepone VideoDelete(Certification cert, string patient_id, string movie_index)
        {
            BoolRepone boolRepone = new BoolRepone();
            boolRepone.ret = false;
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(cert.Group_id, cert.User_id, cert.Media_auth, cert.Session_flg) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2.動画の情報取得
                List<Movies> movies =Tools.GetMovieList(cert.Hosp_id, patient_id, movie_index, "1");
                if (movies == null || movies.Count!= 1)
                {
                    BizException biz = new BizException("MsgMoviNoData", Constants.MsgMoviNoData);
                    throw biz;
                }

                DeleteRequest request = new DeleteRequest();
                request.Certification = cert;
                request.Patient_id = patient_id;
                request.Movie_index = movies[0].Movie_no;
                request.Video_path = movies[0].Movie_path;
                request.Movie_date = movies[0].Photo_date;
                // 動画ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadMoviFolder"].ToString();
                //3.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgFolderNoExist);
                    throw biz;
                }
                //4.動画ファイルをフォルダから削除
                String mibiePath = movies[0].Movie_path;
                if (string.IsNullOrEmpty(mibiePath))
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFailedGetPath);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedGetPath);
                    throw biz;
                }

                try
                {
                    // 5.動画ファイル削除
                    File.Delete(basePath + @"\" + mibiePath);
                }
                catch (Exception)
                {
                    BizException biz = new BizException("ServerError", Constants.MsgDelFile);
                    throw biz;
                }

                //6.動画情報のDB情報を削除
                bool movieRet = Tools.DeleteMovie(request);
                if (movieRet == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedDelete);
                    throw biz;
                }

                boolRepone.ret = true;
            }
            catch (BizException bz)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            boolRepone.Error = error;
            return boolRepone;
        }

        /// <summary>
        /// 静止画削除
        /// </summary>
        /// <param name="certification"></param>
        /// <param name="patient_id"></param>
        /// <param name="movie_index"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolRepone ImageDelete(Certification cert, string patient_id, string movie_index)
        {
            BoolRepone boolRepone = new BoolRepone();
            boolRepone.ret = false;
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;

            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(cert.Group_id, cert.User_id, cert.Media_auth, cert.Session_flg) == false)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2.静止画の情報取得
                List<Movies> movies = Tools.GetMovieList(cert.Hosp_id, patient_id, movie_index, "2");
                if (movies == null || movies.Count != 1)
                {
                    BizException biz = new BizException("MsgMoviNoData", Constants.MsgMoviNoData);
                    throw biz;
                }

                DeleteRequest request = new DeleteRequest();
                request.Certification = cert;
                request.Patient_id = patient_id;
                request.Movie_index = movies[0].Movie_no;
                request.Video_path = movies[0].Movie_path;
                request.Movie_date = movies[0].Photo_date;

                //3. 静止画ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadImgFolder"].ToString();
                //4.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgFolderNoExist);
                    throw biz;
                }
                //5.静止画ファイルをフォルダから削除
                String mibiePath = movies[0].Movie_path;
                if (string.IsNullOrEmpty(mibiePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedGetPath);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedGetPath);
                    throw biz;
                }

                try
                {
                    //6.静止画ファイル削除
                    File.Delete(basePath + @"\" + mibiePath);
                }
                catch (Exception) { }

                //7.静止画情報のDB情報を削除
                bool movieRet = Tools.DeleteImg(request);
                if (movieRet == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedDelete);
                    throw biz;
                }

                boolRepone.ret = true;
            }
            catch (BizException bz)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            boolRepone.Error = error;
            return boolRepone;
        }

        /// <summary>
        /// ログアウト
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolRepone Logout(Certification certification)
        {
            BoolRepone boolRepone = new BoolRepone();
            boolRepone.ret = false;
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };

                //2.セッション情報を削除
                if (Tools.DeleteTblSession(certification) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("Authentication", Constants.MsgFailedDelete);
                    throw biz;
                }

                boolRepone.ret = true;
            }
            catch (BizException bz)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            boolRepone.Error = error;
            return boolRepone;

        }

        /// <summary>
        /// 患者検索サービス
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public PatientResponse SearchPatient(PatientRequest request)
        {
            PatientResponse patientRes = new PatientResponse();
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };

                //2.tbl_patientテーブルを下記条件で検索する
                patientRes.patients = Tools.GetPatient_data(request);
            }
            catch (BizException bz)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            finally
            {
            }
            patientRes.Error = error;
            return patientRes;
        }
        /// <summary>
        /// 動画ファイル確認フォルダの容量計算
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolRepone IsOverCapacity(Certification certification)
        {
            BoolRepone boolRepone = new BoolRepone();
            boolRepone.ret = false;
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;

            FolderSizeReponse folderSize = new FolderSizeReponse
            {
                Contract_size = 0,
                Used_size = 0
            };
            try
            {
                //1. リクエストパラメータのValidation処理を行う
                if (Tools.IsCorrect(certification.Group_id) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgGroudIdError);
                    BizException biz = new BizException("GroudIdError", Constants.MsgGroudIdError);
                    throw biz;
                }
                //2.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //3.契約上の容量を超えているかを返す（true:超える；false:超えていない）
                boolRepone.retReslt = Tools.IsOverCapacity(certification.Group_id);
            }
            catch (BizException bz)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }

            boolRepone.Error = error;
            return boolRepone;
        }

        /// <summary>
        /// 医院の一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public ClinicReponse GetHospList(Certification certification)
        {
            ClinicReponse clinicReponse = new ClinicReponse();
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2.医院の一覧を返す
                List<Clinic> clinicList = Tools.GetClinic_data(certification.Group_id, certification.User_id);
                clinicReponse.Clinics = clinicList;
            }
            catch (BizException bz)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            clinicReponse.Error = error;
            return clinicReponse;
        }

        /// <summary>
        /// 訪問先一覧を返す
        /// </summary>
        /// <param name="certification"></param>
        /// <returns></returns>
        [WebMethod]
        public FacilityReponse GetFacilityList(Certification certification)
        {
            FacilityReponse facilityReponse = new FacilityReponse();
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;

            try
            {
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(certification.Group_id, certification.User_id, certification.Media_auth, certification.Session_flg) == false)
                {
                    logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2.訪問先一覧を返す
                List<Facility> facilityList = Tools.GetFacility_data(certification.Hosp_id);
                facilityReponse.facilities = facilityList;
            }
            catch (BizException bz)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            catch (Exception e)
            {
                logger.Error(certification.Hosp_id + "-" + certification.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            facilityReponse.Error = error;
            return facilityReponse;
        }

        /// <summary>
        /// 動画情報格納
        /// </summary>
        /// <param name="movieRequest"></param>
        /// <returns></returns>
        [WebMethod]
        public MovieReponse MediaUploadMovi(MovieRequest request)
        {
 
            MovieReponse movieReponse = new MovieReponse();
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;

            try
            {

                if (string.IsNullOrEmpty(request.Millisecond))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("ServerError", Constants.MsgMillisecondl);
                    throw biz;
                }

                // ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadMoviFolder"].ToString().Replace("//", "\\\\");
                // ファイル格納暫定フォルダを取得
                String tmp = System.Configuration.ConfigurationManager.AppSettings["UpLoadTempFolder"].ToString().Replace("//", "\\\\")
                            + @"\" + request.Millisecond;

                //0.ディレクトリ作成
                if (!Directory.Exists(basePath))
                {
                    Directory.CreateDirectory(basePath);
                }

                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2.動画ファイルをフォルダを格納

                // grupId + 病院ID　＋　患者ID
                String kannjyaIdDrect = basePath + @"\" + request.Certification.Group_id + @"\" + request.Certification.Hosp_id + @"\" + request.Patient_id;
                //　ディレクトリ作成
                if (!Directory.Exists(kannjyaIdDrect))
                {
                    Directory.CreateDirectory(kannjyaIdDrect);
                }

                // 患者ID　＋　メディア名称
                String mediaPath = tmp + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name);

                // zip動画をローカルに保存
                String mediaPathZip = mediaPath + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + Path.GetExtension(request.Movie_name).Replace(".", "") + ".zip";
                //　ディレクトリ作成
                if (!Directory.Exists(mediaPath))
                {
                    Directory.CreateDirectory(mediaPath);
                }

                // 解凍したファイルフォルダ
                String extractPath = tmp + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name);
                //　ディレクトリ作成
                if (!Directory.Exists(extractPath))
                {
                    Directory.CreateDirectory(extractPath);
                }


                // 移動先解凍したファイル
                String moveUnZipFile = mediaPath + @"\" + request.Movie_name;

                // 結合したmp4ファイル
                string file_name = kannjyaIdDrect + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + Path.GetExtension(request.Movie_name);

                //既にmp4ファイルアップされた場合エラーを返却
                if (File.Exists(moveUnZipFile) || File.Exists(file_name))
                {
                    // ディレクトリ直下のすべてのファイルを削除
                    Tools.CleanUp(tmp);
                    BizException biz = new BizException("AlreadyUpLoaded", Constants.MsgAlreadyUpLoaded);
                    throw biz;

                }
                else
                {
                    // byte[] -> ファイル変換
                    FileStream objfilestream = new FileStream(mediaPathZip, FileMode.Create, FileAccess.ReadWrite);
                    objfilestream.Write(request.Movie_context, 0, request.Movie_context.Length);
                    objfilestream.Close();

                    // Zipファイル解凍
                    ZipFile.ExtractToDirectory(mediaPathZip, extractPath);

                    // Zipフォルダを削除
                    File.Delete(mediaPathZip);

                }

                // DirectoryInfoのインスタンスを生成する
                DirectoryInfo d = new DirectoryInfo(extractPath);

                // ディレクトリ直下のすべてのファイル一覧を取得する
                FileInfo[] fiAlls = d.GetFiles();

                int uploadFilesCount = fiAlls.Length;


                // -------------結合処理
                // 分割したファイルの総合＝＝クライアントで送信したファイル総数
                if (request.FileCount == uploadFilesCount)
                {
                    // 読込バッファサイズ
                    const int READ_BYTE = Constants.ConDIV_BYTE / 10;

                    // 分割ファイルをリストアップ
                    List<string> divFiles = new List<string>();

                    // ディレクトリ直下のすべてのファイル一覧を取得する
                    foreach (FileInfo f in fiAlls)
                    {
                        divFiles.Add(f.FullName);
                    }

                    // 結合先ファイルを開く
                    using (FileStream wf = new FileStream(file_name, FileMode.Create, FileAccess.Write))
                    {
                        int readByte = 0;
                        long leftByte = 0;
                        byte[] readBuf = new byte[READ_BYTE];
                        foreach (string divFile in divFiles)
                        {
                            // 分割ファイルを開く
                            using (FileStream rf = new FileStream(divFile, FileMode.Open, FileAccess.Read))
                            {
                                leftByte = rf.Length;
                                while (leftByte > 0)
                                {
                                    try
                                    {
                                        // 分割ファイルから読み込むGetFolderSize
                                        readByte = rf.Read(readBuf, 0, (int)Math.Min(READ_BYTE, leftByte));
                                        // 結合先ファイルに書きこむ
                                        wf.Write(readBuf, 0, readByte);
                                        // 読込情報の設定
                                        leftByte -= readByte;
                                    }
                                    catch (Exception e)
                                    {
                                        logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                                        BizException biz1 = new BizException("ServerError", Constants.MsgFileConnect);
                                        throw biz1;
                                    }

                                }
                            }
                        }
                    }

                    // ディレクトリ直下のすべてのファイルを削除
                    Tools.CleanUp(tmp);

                    // 4. ファイルサイズチェック
                    FileInfo file = new FileInfo(file_name);
                    if (file.Length != request.Movie_size)
                    {
                        try
                        {
                            // 動画ファイルを削除
                            File.Delete(file_name);
                        }
                        catch (Exception e)
                        {
                            logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                            BizException biz1 = new BizException("ServerError", Constants.MsgDelFile);
                            throw biz1;
                        }
                        logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedRegister);
                        BizException biz = new BizException("ServerError", Constants.MsgFileSizeNotEqual);
                        Tools.WriteLog("ServerError", biz, logger);
                        throw biz;
                    }

                    // 5.動画情報をDBに登録処理
                    Certification cer = new Certification();
                    cer.Group_id = request.Certification.Group_id;
                    cer.Hosp_id = request.Certification.Hosp_id;
                    cer.User_id = request.Certification.User_id;
                    cer.Media_auth = request.Certification.Media_auth;

                    MovieRequest insertMovie = new MovieRequest();
                    insertMovie.Certification = cer;
                    insertMovie.Patient_id = request.Patient_id;
                    insertMovie.Video_no = request.Movie_index.ToString();
                    insertMovie.Movie_date = request.Movie_date;
                    insertMovie.Remarks = request.Remarks;
                    insertMovie.Video_path = file_name.Replace(basePath, "").Replace(@"\", "/").Substring(1);
                    insertMovie.Edit_user = request.Certification.User_id;
                    insertMovie.Movie_size = request.Movie_size;
                    insertMovie.Video_tag = request.Video_tag;
                    insertMovie.Title = request.Title;
                    //insert
                    bool movieRet = Tools.InsertMovie(insertMovie);
                    // 6. 動画情報をDBに登録処理失敗の場合、動画ファイルを削除
                    if (movieRet == false)
                    {
                        try
                        {
                            // 動画ファイルを削除
                            File.Delete(file_name);
                        }
                        catch (Exception e) {
                            logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                            BizException biz1 = new BizException("ServerError", Constants.MsgDelFile);
                            throw biz1;
                        }

                        logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedRegister);
                        BizException biz = new BizException("ServerError", Constants.MsgFailedRegister);
                        Tools.WriteLog("ServerError", biz, logger);
                        throw biz;
                    }
                }
            }
            catch (BizException bz)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;

            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            movieReponse.Error = error;
            return movieReponse;
        }

        /// <summary>
        /// 静止画情報格納
        /// </summary>
        /// <param name="movieRequest"></param>
        /// <returns></returns>
        [WebMethod]
        public MovieReponse MediaUploadImg(MovieRequest request)
        {
            // ファイル格納フォルダを取得
            String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadImgFolder"].ToString().Replace("//", "\\\\");
            DateTime photo_date = DateTime.Parse(request.Movie_date);
            MovieReponse movieReponse = new MovieReponse();
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            try
            {
                //0.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    Directory.CreateDirectory(basePath);
                }
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2.静止画ファイルをフォルダを格納
               
                // grupId + 病院ID　＋　患者ID
                String kannjyaIdDrect = basePath + @"\"  + request.Certification.Hosp_id + @"\" + request.Patient_id + @"\" + photo_date.ToString("yyyy_M_d") + @"\"  + "img";
                //　ディレクトリ作成
                if (!Directory.Exists(kannjyaIdDrect))
                {
                    Directory.CreateDirectory(kannjyaIdDrect);
                }

                // 静止画ファイル
                string file_name = kannjyaIdDrect + @"\" + Path.GetFileNameWithoutExtension(request.Movie_name) + Path.GetExtension(request.Movie_name);

                //既に静止画ファイルアップされた場合エラーを返却
                if (File.Exists(file_name))
                {
                    BizException biz = new BizException("AlreadyUpLoaded", Constants.MsgAlreadyUpLoaded);
                    throw biz;

                }
                else
                {
                    // byte[] -> ファイル変換
                    FileStream objfilestream = new FileStream(file_name, FileMode.Create, FileAccess.ReadWrite);
                    objfilestream.Write(request.Movie_context, 0, request.Movie_context.Length);
                    objfilestream.Close();

                }

                //4.静止画情報をDBに登録処理
                Certification cer = new Certification();
                cer.Group_id = request.Certification.Group_id;
                cer.Hosp_id = request.Certification.Hosp_id;
                cer.User_id = request.Certification.User_id;
                cer.Media_auth = request.Certification.Media_auth;

                MovieRequest insertMovie = new MovieRequest();
                insertMovie.Certification = cer;
                insertMovie.Patient_id = request.Patient_id;
                insertMovie.Video_no = request.Movie_index.ToString();
                insertMovie.Movie_date = DateTime.Now.ToString();
                insertMovie.Remarks = request.Remarks;
                insertMovie.Video_path = file_name.Replace(basePath, "").Replace(@"\", "/").Substring(1);
                insertMovie.Edit_user = request.Certification.User_id;
                insertMovie.Movie_size = request.Movie_size;
                insertMovie.Video_tag = request.Video_tag;
                insertMovie.Title = request.Title;
                //insert
                bool movieRet = Tools.InsertImg(insertMovie);

                //5. 静止画情報をDBに登録処理失敗の場合、動画ファイルを削除
                if (movieRet == false)
                {
                    try
                    {
                        // 動画ファイルを削除
                        File.Delete(file_name);
                    }
                    catch (Exception ) {
                        BizException biz1 = new BizException("ServerError", Constants.MsgDelFile);
                        throw biz1;
                    }

                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedRegister);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedRegister);
                    throw biz;
                }
            }
            catch (BizException bz)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;

            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgInternalServerError;
            }
            movieReponse.Error = error;
            return movieReponse;
        }

        /// <summary>
        /// 動画情報削除
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolRepone MediaDelete(DeleteRequest request)
        {
            BoolRepone boolRepone = new BoolRepone();
            boolRepone.ret = false;
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            bool del = false;
            try
            {
                // ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadMoviFolder"].ToString();
                //0.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgFolderNoExist);
                    throw biz;
                }
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2.動画ファイルをフォルダから削除
                String mibiePath = Tools.GetMoviPath(request);
                if (string.IsNullOrEmpty(mibiePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedGetPath);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedGetPath);
                    throw biz;
                }

                try
                {
                    // ファイル削除
                    File.Delete(basePath + @"\" + mibiePath);
                }
                catch (Exception) {
                    BizException biz = new BizException("ServerError", Constants.MsgDelFile);
                    throw biz;
                }

                //4.動画情報のDB情報を削除
                bool movieRet = Tools.DeleteMovie(request);
                if (movieRet == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedDelete);
                    throw biz;
                }
                boolRepone.ret = del;
            }
            catch (BizException bz)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgFailedDelete;
            }
            boolRepone.Error = error;
            return boolRepone;
        }


        /// <summary>
        /// 静止画情報削除
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebMethod]
        public BoolRepone MediaDeleteImg(DeleteRequest request)
        {
            BoolRepone boolRepone = new BoolRepone();
            boolRepone.ret = false;
            ErrorReponse error = new ErrorReponse();
            error.ErrorCode = Constants.MsgOK;
            bool del = false;
            try
            {
                // ファイル格納フォルダを取得
                String basePath = System.Configuration.ConfigurationManager.AppSettings["UpLoadImgFolder"].ToString();
                //0.ファイル格納フォルダの存在チェック
                if (!Directory.Exists(basePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgFolderNoExist);
                    throw biz;
                }
                //1.tbl_sessionテーブルをgroup_id, hosp_id, user_id, media_auth を基に照合する
                if (Tools.KEY_CHK(request.Certification.Group_id, request.Certification.User_id, request.Certification.Media_auth, request.Certification.Session_flg) == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgUnauthorized);
                    BizException biz = new BizException("Unauthorized", Constants.MsgUnauthorized);
                    throw biz;
                };
                //2.動画ファイルをフォルダから削除
                String mibiePath = Tools.GetImgPath(request);
                if (string.IsNullOrEmpty(mibiePath))
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedGetPath);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedGetPath);
                    throw biz;
                }

                try
                {
                    // ファイル削除
                    File.Delete(basePath + @"\" + mibiePath);
                }
                catch (Exception) { }

                //4.動画情報のDB情報を削除
                bool movieRet = Tools.DeleteImg(request);
                if (movieRet == false)
                {
                    logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + Constants.MsgFailedDelete);
                    BizException biz = new BizException("ServerError", Constants.MsgFailedDelete);
                    throw biz;
                }
                boolRepone.ret = del;
            }
            catch (BizException bz)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + bz);
                BizException biz = new BizException(bz.ErrorCode, bz.Message);
                Tools.WriteLog(bz.ErrorCode, biz, logger);
                error.ErrorCode = bz.ErrorCode;
                error.ErrorMessage = bz.Message;
            }
            catch (Exception e)
            {
                logger.Error(request.Certification.Hosp_id + "-" + request.Certification.User_id + ":" + e);
                BizException biz = new BizException("ServerError", Constants.MsgInternalServerError);
                Tools.WriteLog("ServerError", biz, logger);
                error.ErrorCode = "ServerError";
                error.ErrorMessage = Constants.MsgFailedDelete;
            }
            boolRepone.Error = error;
            return boolRepone;
        }
    }
}
