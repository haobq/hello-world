({
    doInit: function(component, event, helper) {
        var action = component.get("c.getRemoteRecord");
        var parm =location.pathname.split("/")[4];
        action.setParams({
            recordId :location.pathname.split("/")[4]
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var ret = response.getReturnValue();
                var templatecontent = component.find("templatecontent");
                component.set("v.recordId", ret.Id);
                component.set("v.header",ret.Name+'を編集' );
                component.set("v.remoteRecord", ret);
                component.set('v.showModal', true);
                templatecontent.set("v.value",ret.remotehoukokutemplatecontent__c.replace(/<br>/g, "\r\n"));
            } else {
                console.log("Failed with state: " + state);
            }
        });
        $A.enqueueAction(action);
    },
    
    onPicklistChange : function(component, event, helper)
    {
       var val = component.find("InputSelect").get("v.value");
       var templatecontent = component.find("templatecontent");
        if (val=="" || val=="(自由入力)") {
            templatecontent.set("v.value", "");  
        }else if (val=="マスタセンタ・修正用") {
            templatecontent.set("v.value",$A.get("$Label.c.master_modify"));
        }else if (val=="マスタセンタ・DB入手用") {
            templatecontent.set("v.value",$A.get("$Label.c.master_db").replace(/<br>/g, "\r\n"));
        }else if (val=="システムサポート用") {
            templatecontent.set("v.value",$A.get("$Label.c.system_sport").replace(/<br>/g, "\r\n"));
        }else if (val=="システム部・試用") {
            templatecontent.set("v.value",$A.get("$Label.c.system_input").replace(/<br>/g, "\r\n"));
        }
    }, 
    onSaveClicked : function(component, event, helper) {
        var action = component.get("c.updateRemotesagyo");
        var remoteRecord = component.get("v.remoteRecord");
        remoteRecord.bushocode__c = component.find("bushocode").get("v.value");
        remoteRecord.shaincode__c = component.find("shaincode").get("v.value");
        remoteRecord.torihikisakino__c = component.find("torihikisakino").get("v.value");
        remoteRecord.sagyouymd__c = component.find("sagyouymd").get("v.value");
        remoteRecord.sagyoustarthm__c = component.find("sagyoustarthm").get("v.value");
        remoteRecord.sagyouendhm__c = component.find("sagyouendhm").get("v.value");
        remoteRecord.ankennamename__c = component.find("ankennamename").get("v.value")
        remoteRecord.ankenshubetsu__c = component.find("ankenshubetsu").get("v.value");
        remoteRecord.remotehoukokumokuteki__c = component.find("remotehoukokumokuteki").get("v.value");
        remoteRecord.iraishono__c = component.find("iraishono").get("v.value");
        remoteRecord.outputdate__c = component.find("outputdate").get("v.value");
        remoteRecord.InputSelect__c = component.find("InputSelect").get("v.value");
        remoteRecord.remotehoukokutemplatecontent__c = component.find("templatecontent").get("v.value");
        remoteRecord.zyusin__c = component.find("zyusin").get("v.value");
        action.setParams({ remotesagyo : remoteRecord });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
		        $A.get('e.force:refreshView').fire();
                helper.displayToast('success', '保存しました。');
            } else if (state === "ERROR") {
                let errors = response.getError();
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    helper.defaultErrorHandler(errors);
                }
            }
        });
        $A.enqueueAction(action);
        // ポップアップクローズ
        $A.get("e.force:closeQuickAction").fire();
    },
    onCancelClicked : function(component, event, helper) {
        // ポップアップクローズ
        $A.get("e.force:closeQuickAction").fire();
    }
})