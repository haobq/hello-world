({
    defaultErrorHandler : function(errors) {
        let toastParams = {
            title: "error",
            message: "Unknown error",
            type: "error",
            mode: "sticky"
        };

        if (errors && Array.isArray(errors) && errors.length > 0) {
            console.error(JSON.stringify(errors));
            toastParams.message = errors[0].message;
        }

        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },
    displayToast : function(type, message) {
        var toastEvent = $A.get('e.force:showToast');
        toastEvent.setParams({
            type: type,
            message: message
        });
        toastEvent.fire();
    }
})