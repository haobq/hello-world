package jp.co.inc.media.video.utils;

import java.util.Date;

public class User {

	public User() {
		userName = "";
		mediaName= "";
		register= "";
		mediaPath= "";
		regDate= null;
	}
	/**
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName セットする userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return mediaName
	 */
	public String getMediaName() {
		return mediaName;
	}
	/**
	 * @param mediaName セットする mediaName
	 */
	public void setMediaName(String mediaName) {
		this.mediaName = mediaName;
	}
	/**
	 * @return register
	 */
	public String getRegister() {
		return register;
	}
	/**
	 * @param register セットする register
	 */
	public void setRegister(String register) {
		this.register = register;
	}
	/**
	 * @return mediaPath
	 */
	public String getMediaPath() {
		return mediaPath;
	}
	/**
	 * @param mediaPath セットする mediaPath
	 */
	public void setMediaPath(String mediaPath) {
		this.mediaPath = mediaPath;
	}
	/**
	 * @return regDate
	 */
	public Date getRegDate() {
		return regDate;
	}
	/**
	 * @param regDate セットする regDate
	 */
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	String userName;
	String mediaName;
	String register;
	String mediaPath;
	Date   regDate;

}
