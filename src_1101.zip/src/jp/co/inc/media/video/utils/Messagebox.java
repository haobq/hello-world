package jp.co.inc.media.video.utils;

import java.util.Optional;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.MessageConst;

public class Messagebox implements BasConst,MessageConst {

	public static void Error(String errMsg) {
		Alert alrt = new Alert(AlertType.ERROR);
		alrt.setTitle(ERROR_DIALOG_TITLE);
		alrt.setHeaderText(null);
		alrt.setContentText(errMsg);
		Optional<ButtonType> result = alrt.showAndWait();
		if (result.get() == ButtonType.OK) {
		}
	}

	public static void Info(String errMsg) {
		Alert alrt = new Alert(AlertType.INFORMATION);
		alrt.setTitle(ERROR_DIALOG_TITLE);
		alrt.setHeaderText(null);
		alrt.setContentText(errMsg);
		Optional<ButtonType> result = alrt.showAndWait();
		if (result.get() == ButtonType.OK) {
		}
	}

	public static Optional<ButtonType> Confirmation(String errMsg) {
		Alert alrt = new Alert(AlertType.CONFIRMATION);
		alrt.setTitle(CONFIRMATION_DIALOG_TITLE);
		alrt.setHeaderText(null);
		alrt.setContentText(errMsg);
		Optional<ButtonType> result = alrt.showAndWait();
		return result;
	}

}
