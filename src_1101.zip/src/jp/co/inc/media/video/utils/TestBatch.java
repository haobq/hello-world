package jp.co.inc.media.video.utils;

public class TestBatch {
	   public static void main(String[] args) throws Exception {


		 //  ProxyUtil.callGet("https://dev.withyou.media/login");

		   ProxyUtil.callPost("https://dev.withyou.media/login", "application/x-www-form-urlencoded;", "foo=33333&bar=value2");


	    }
}
