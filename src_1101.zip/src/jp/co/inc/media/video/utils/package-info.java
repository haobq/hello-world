/**
 * @author isss_hao
 *
 */
package jp.co.inc.media.video.utils;