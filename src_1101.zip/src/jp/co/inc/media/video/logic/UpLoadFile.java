package jp.co.inc.media.video.logic;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FilenameUtils;

import javafx.concurrent.Task;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasFrame;
import jp.co.inc.media.video.common.MessageConst;
import jp.co.inc.media.video.common.BasConst.Status;
import jp.co.inc.media.video.utils.FileInfoBean;

public class UpLoadFile extends Task<String> implements BasConst, MessageConst {

	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(UpLoadFile.class.getName());

	/**
	 * ファイル削除
	 * @param file ファイル削除
	 * @throws IOException ファイル読み異常
	 */
	public static void delete(File file)
			throws IOException {

		if (file.isDirectory()) {
			//directory is empty, then delete it
			if (file.list().length == 0) {
				file.delete();
			} else {
				//list all the directory contents
				String files[] = file.list();
				for (String temp : files) {
					//construct the file structure
					File fileDelete = new File(file, temp);
					//recursive delete
					delete(fileDelete);
				}
				//check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();
				}
			}
		} else {
			//if file, then delete it
			file.delete();
		}
	}

	/**
	 * フォルダを削除
	 * @param folder フォルダ
	 * @throws IOException  ファイル読み異常
	 */
	public static void deletefolder(String folder)
			throws IOException {
		File directory = new File(folder);
		//make sure directory exists
		if (!directory.exists()) {
		} else {
			try {
				delete(directory);
			} catch (IOException e) {
				e.printStackTrace();
				logger.log(Level.SEVERE, THROW_INFO, e.getMessage());
			}
		}
	}

	/**
	 * 送信処理
	 */
	@Override
	protected String call() throws Exception {

		// フォルダを削除
		deletefolder(mp4Path);

		System.out.println("送信開始時間：" + System.currentTimeMillis());
		double start = System.currentTimeMillis();

		try {

			// 連番
			int renBan = 1;
			File dir;
			for (FileInfoBean file : BasFrame.fileInfolist) {

				// ステータスが完了の場合
				if (file.getStatus().equals(Status.STATUS_COMPLETED)) {
					continue;
				} else {
					// 送信中に更新
					file.setStatus(Status.STATUS_WORKING);
				}

				if (file.fileName.equals(BasFrame.sysInfoBean.getSelectedFileName())) {

					// ファイルコピー
					// 病院ID + _ + 患者ID + _ + カレンダー日付 + _ + 連番
					String strUploadFileName = BasFrame.patientInfo.getHospitalId() + "_"
							+ BasFrame.patientInfo.getPatientId() + "_"
							+ BasFrame.datePicker.getValue().toString().replace("-", "") + "_" + renBan + EXTENTTION;

					// フォルダを作成
					if (!Files.exists(Paths.get(mp4Path))) {
						Files.createDirectory(Paths.get(mp4Path));
					}
					// アップロードファイル
					final Path uploadFilePath = Paths.get(mp4Path + strUploadFileName);
					// 元ファイル
					final Path sourcePath = Paths.get(file.filePath);

					try {
						Files.copy(sourcePath, uploadFilePath);
						System.out.println("コピーが成功しました");
					} catch (IOException e) {
						e.printStackTrace();
						logger.log(Level.SEVERE, THROW_INFO, e.getMessage());
					}

					// ファイル分割
					final FileSplit fileSplit = new FileSplit();
					try {
						fileSplit.split((mp4Path + strUploadFileName), mp4Path, SPLITE_SIZE);
					} catch (Exception e) {
						e.printStackTrace();
						logger.log(Level.SEVERE, THROW_INFO, e.getMessage());
					}

					// 元ファイル削除
					dir = uploadFilePath.toFile();
					dir.delete();

					// 圧縮」、送信、削除　処理開始
					dir = Paths.get(mp4Path).toFile();
					final File files[] = dir.listFiles();
					int fileCount = 0;
					fileCount = files.length;
					// ファイルソード
					java.util.Arrays.sort(files, new java.util.Comparator<File>() {
						public int compare(File file1, File file2) {
							return file1.getName().compareTo(file2.getName());
						}
					});

					// ファイルサイズ
					long fileSize = 0;
					for (File f : files) {

						String zipFilePath = FilenameUtils.removeExtension(f.getPath())
								+ FilenameUtils.getExtension(f.getName());
						String zipFile = zipFilePath + "/" + FilenameUtils.removeExtension(f.getName())
								+ FilenameUtils.getExtension(f.getName()) + ".zip";

						File newfile = new File(zipFilePath);

						// byte定義
						byte[] media;
						if (newfile.mkdir()) {

							// 圧縮 .zip
							fileSplit.archive(f.getPath(), zipFile);

							fileSize = fileSize + f.length();

							// 進捗バーの更新
							updateProgress(fileSize, file.getFileSize());
							// 進捗バー表示
							BasFrame.hBoxPrpgress.setVisible(true);

							// 進捗メッセージの更新
							updateMessage(String.format(" %d/%d", fileSize, file.getFileSize()));
							// 待機
							//TimeUnit.SECONDS.sleep(1);

							// zipファイルをByte[]に変換
							media = ZipCompressUtils.readBytesFromFile(zipFile);

							//						// パラメータ　設定
							//						_mediaUpload_media = media;
							//						_mediaUpload_mediaName =  f.getName();
							//
							//
							//						_mediaUpload_fileCount = fileCount;
							//						_mediaUpload_hospId = "HOSPITAL_ID";
							//						_mediaUpload_patientId = "KANNJYA_ID";

							//						//　サービス呼び出す
							//						String _mediaUpload__return = port.mediaUpload(_mediaUpload_media, _mediaUpload_mediaName, _mediaUpload_fileCount, _mediaUpload_hospId, _mediaUpload_patientId);

							// 結果判定
							//						if (_mediaUpload__return.equals("fileUploadSuccess")) {
							//

							// 完に更新
							file.setStatus(Status.STATUS_COMPLETED);
						}
					}

				}

			}

			// フォルダを削除
			deletefolder(mp4Path);

			// アップロード完了！
			updateMessage(I0004);
			// 待機
			TimeUnit.SECONDS.sleep(1);

			BasFrame.hBoxPrpgress.setVisible(false);

			System.out.println("送信終了時間：" + System.currentTimeMillis());
			double end = System.currentTimeMillis();
			System.out.println("送信時間：" + (end - start)/1000  + "s");


		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e.getMessage());
			return null;
		}

		return "Done";
	}

}
