package jp.co.inc.media.video.components;

import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import jp.co.inc.media.video.common.BasButton;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasDialog;
import jp.co.inc.media.video.common.MessageConst;
import jp.co.inc.media.video.utils.FileInfoBean;
import jp.co.inc.media.video.utils.FolderManager;
import jp.co.inc.media.video.utils.JsonListBean;

/**
 * 送信履歴管理のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class HistoryDialog extends BasDialog implements  BasConst,MessageConst{
	private List<FileInfoBean> fileInfolist;
	private StackPane paneFileDetail = new StackPane();

	/**
	 * 動画管理用JSONファイルリスト
	 *
	 * @param fileListPane 親パネル名
	 * @param jsonfileList JSONファイルリスト
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void setJsonFileList(List<JsonListBean> jsonfileList,Pane fileListPane) {

		fileListPane.getChildren().clear();
		TableView<JsonListBean>  jsonFileTable = new TableView<>();
		ObservableList<JsonListBean> observableList = FXCollections.observableList(jsonfileList);

	    TableColumn<JsonListBean, String> fileStatusColumn = new TableColumn<>(JSON_TITLE_STATAS);
	    fileStatusColumn.setCellValueFactory(new PropertyValueFactory("status"));

	    TableColumn<JsonListBean, String> fileNameColumn = new TableColumn<>(JSON_TITLE_NAME);
	    fileNameColumn.setCellValueFactory(new PropertyValueFactory("fileName"));

		jsonFileTable.getColumns().setAll(fileStatusColumn, fileNameColumn);
		jsonFileTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		jsonFileTable.setItems(observableList);
		jsonFileTable.sort();
		fileListPane.getChildren().add(jsonFileTable);

		//選択状態を検知するバインディングの設定
		jsonFileTable_addListener(jsonFileTable,observableList);
	}

	/**
	 * 動画管理用JSONファイル詳細
	 *
	 * @param jsonfileDetail JSONファイル詳細
	 */
	@SuppressWarnings("unchecked")
	private void setJsonFileDetail(List<FileInfoBean> jsonfileDetail) {

		paneFileDetail.getChildren().clear();
		TableView<FileInfoBean>  jsonDetailTable = new TableView<>();
		ObservableList<FileInfoBean> observableDetail = FXCollections.observableList(jsonfileDetail);

		final TableColumn<FileInfoBean, String> fileStatusColumn = new TableColumn<>(JSON_TITLE_STATAS);
	    fileStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

		final TableColumn<FileInfoBean, String> fileNameColumn = new TableColumn<>(FILE_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory<>("fileName"));

		final TableColumn<FileInfoBean, String> lastedUpdateColumn = new TableColumn<>(FILE_TITLE_LASTED_UPDATE);
		lastedUpdateColumn.setCellValueFactory(new PropertyValueFactory<>("updateDate"));

		final TableColumn<FileInfoBean, String> fileSizeColumn = new TableColumn<>(FILE_TITLE_SIZE);
		fileSizeColumn.setCellValueFactory(new PropertyValueFactory<>("fileSize"));

		final TableColumn<FileInfoBean, String> fileBikouColumn = new TableColumn<>(FILE_TITLE_BIKOU);
		fileBikouColumn.setCellValueFactory(new PropertyValueFactory<>("bikou"));

		final TableColumn<FileInfoBean, String> fileUploadFileNameColumn = new TableColumn<>(FILE_TITLE_UPLOAD_FILE_NAME);
		fileUploadFileNameColumn.setCellValueFactory(new PropertyValueFactory<>("uploadFileName"));

	    jsonDetailTable.getColumns().setAll(fileStatusColumn,fileNameColumn,lastedUpdateColumn,fileSizeColumn,fileBikouColumn,fileUploadFileNameColumn);
	    jsonDetailTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

	    jsonDetailTable.setItems(observableDetail);
	    paneFileDetail.getChildren().add(jsonDetailTable);
	}

	/**
	 * 動画管理用JSONファイルリスト選択時、詳細情報を取得
	 *
	 * @param jsonFileTable 動画管理用JSONファイルリストTABLE
	 * @param fileList 動画管理用JSONファイルリスト
	 */
	private void jsonFileTable_addListener(TableView<JsonListBean>  jsonFileTable, ObservableList<JsonListBean> fileList)  {
		jsonFileTable.getSelectionModel().selectedItemProperty().addListener((ov, old, current) -> {
			String workingDirJson = jsonFolder + current.getFileName();
			try {
				fileInfolist = FolderManager.getJsonInfoBean(workingDirJson);
				setJsonFileDetail(fileInfolist);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}
	/**
	 * 送信履歴管理画面
	 *
	 * @param owner 親パネル名
	 * @param title 画面名
	 * @param width 画面幅
	 * @param height 画面高
	 */
	public HistoryDialog(Stage owner, String title, int width, int height) {
		super(owner, title, width, height);

		BorderPane listPane = new BorderPane();
		BorderPane topPane = new BorderPane();
		topPane.setPrefWidth(790);
		topPane.setPrefHeight(260);

		HBox hvBoxNote = new HBox();
		Label labFileListTitle = new Label("送信ファイルリスト");
		labFileListTitle.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_BOLD);
		labFileListTitle.setAlignment(Pos.BOTTOM_LEFT);
		hvBoxNote.setAlignment(Pos.BASELINE_LEFT);
		hvBoxNote.setSpacing(20);
		hvBoxNote.getChildren().addAll(labFileListTitle);
		topPane.setTop(hvBoxNote);

		StackPane paneFileList = new StackPane();

		//JSONファイル一覧
		List<JsonListBean> fileList = FolderManager.getJsonListBean(jsonFolder);
		setJsonFileList(fileList,paneFileList);
		topPane.setCenter(paneFileList);

		BorderPane bottomPane = new BorderPane();
		HBox detailBoxNote = new HBox();
		Label labFileDetail = new Label("送信ファイル詳細");
		labFileDetail.setStyle("-fx-font-size: " + FONT_NORM_SIZE + "; -fx-font-weight: " + FONT_BOLD);
		labFileDetail.setAlignment(Pos.BOTTOM_LEFT);
		detailBoxNote.setAlignment(Pos.BASELINE_LEFT);
		detailBoxNote.setSpacing(20);
		detailBoxNote.getChildren().addAll(labFileDetail);
		bottomPane.setPrefWidth(790);
		bottomPane.setPrefHeight(280);

		bottomPane.setTop(detailBoxNote);
		bottomPane.setCenter(paneFileDetail);

		SplitPane verticalPane = new SplitPane();
		verticalPane.setOrientation(Orientation.VERTICAL);
		verticalPane.getItems().addAll(topPane, bottomPane);

		//Javafx splitpane 分割 固定
		double posRootLeft[]  = {0.40f, 1.0f };
		verticalPane.setDividerPositions(posRootLeft);
		for (int i = 0; i < verticalPane.getDividers().size(); i++) {
			final int ind = i;
			final SplitPane.Divider divider = verticalPane.getDividers().get(i);
			divider.positionProperty().addListener(new ChangeListener<Number>() {
				@Override
				public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
					divider.setPosition(posRootLeft[ind]);
				}
			});
		}

		Button config =new BasButton("config.png", 16, 16, BUTTON_CONFIG);
		config.setPrefWidth(100);
		config.setStyle(BUTTON_STYLE);
		HBox bottomNode = new HBox(10.0);
		bottomNode.setPadding(new Insets(10, 10, 10, 10));
		bottomNode.setSpacing(40);
		bottomNode.getChildren().addAll(config);
		bottomNode.setAlignment(Pos.CENTER_RIGHT);

		config.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				close();
			}
		});
		listPane.setCenter(verticalPane);
		listPane.setBottom(bottomNode);

		root.getChildren().add(listPane);
	}
}

