/**
 * @author isss_hao
 *
 */
package jp.co.inc.meida.video.utils;