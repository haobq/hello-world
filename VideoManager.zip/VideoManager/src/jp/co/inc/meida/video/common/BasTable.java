package jp.co.inc.meida.video.common;

import java.awt.Dimension;
import java.util.List;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import jp.co.inc.meida.video.utils.FileInfoBean;
import jp.co.inc.meida.video.utils.PatientInfoBean;

public class BasTable extends JPanel implements BasConst {
	private String currentDir = System.getProperty("user.dir").replace("\\", "/");


	public BasTable(List<FileInfoBean> fileInfoBean) {
		Icon completeIcon = new ImageIcon(currentDir +"/img/Complete.png");
		Icon processingIcon = new ImageIcon(currentDir +"/img/processing.png");
		Icon waitingIcon = new ImageIcon(currentDir +"/img/waiting.png");

		DefaultTableModel tableModel= new DefaultTableModel(COLUMN_NAMES, 0) ;
		JTable table = new JTable(tableModel);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

		for(FileInfoBean fileInfo: fileInfoBean) {
			Icon icon = waitingIcon;
			if ("未".equals(fileInfo.getStatus())){
				icon = waitingIcon;
			}else if ("中".equals(fileInfo.getStatus())){
				icon = processingIcon;
			}else if ("完".equals(fileInfo.getStatus())){
				icon = completeIcon;
			}

			tableModel.addRow(new Object[] {icon, fileInfo.getFilename(),fileInfo.getUpdate()});
		}

		table.setRowHeight(30);
		table.setAutoResizeMode(WIDTH);
		table.setAutoCreateRowSorter(true);
		JScrollPane sp = new JScrollPane(table);
        sp.setPreferredSize(new Dimension(330, 280));
		add(sp);
	}



	public BasTable(String flg,List<PatientInfoBean> patientInfoBean) {
		DefaultTableModel tableModel= new DefaultTableModel(COLUMN_PATIENT, patientInfoBean.size()) {
			public Class getColumnClass(int column) {
				return getValueAt(0, column).getClass();
			}
		};
		JTable table = new JTable(tableModel);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

		for(PatientInfoBean patientInfo: patientInfoBean) {
			tableModel.addRow(new Object[] {patientInfo.getPatientId(),patientInfo.getPatientName(),patientInfo.getBirthday(),patientInfo.getPatientSex()});
		}

		table.setRowHeight(30);
		table.setAutoResizeMode(WIDTH);
		table.setAutoCreateRowSorter(true);
		JScrollPane sp = new JScrollPane(table);
        sp.setPreferredSize(new Dimension(330, 300));
		add(sp);
	}
}
