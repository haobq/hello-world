/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.meida.video.common;

import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

public class BasFrame extends JFrame implements BasConst{
	private String currentDir = System.getProperty("user.dir");

    public BasFrame() {
        super();
        try  {
            jbInit();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
    	currentDir.replace("\\", "/");
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(currentDir +"/img/media.jpg"));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JMenuBar menubar = new JMenuBar();
		JMenu menu1 = new JMenu("LOGIN");
		JMenu menu2 = new JMenu("SET");
		JMenu menu3 = new JMenu("HELP");

		menubar.add(menu1);
		menubar.add(menu2);
		menubar.add(menu3);

		this.setJMenuBar(menubar);
		this.setAlwaysOnTop(true);
    }

    public void doInitThread() {

        ThreadCreateMainFrm threadCreateMainFrm = new ThreadCreateMainFrm();

        try {
            threadCreateMainFrm.join();
        } catch (Exception e) {
        }
    }

    class ThreadCreateMainFrm extends Thread {
        public ThreadCreateMainFrm() {
            setPriority(4);
            start();
        }

        public void run() {
            try {
                jbInit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

	public static void main(String[] args) {
		BasFrame frame = new BasFrame();
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.pack();
	    frame.setLocation(100, 100);
	    frame.setVisible(true);

	}

}
