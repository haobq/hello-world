/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.meida.video.common;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.border.Border;

import jp.co.inc.meida.video.utils.FileInfoBean;
import jp.co.inc.meida.video.utils.PatientInfoBean;

public class BasFrame extends JFrame implements BasConst {
	private String currentDir = System.getProperty("user.dir");

	public BasFrame() {
		super();
		try {
			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		currentDir.replace("\\\\", "/");
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(currentDir + "/img/media.jpg"));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JMenuBar menubar = new JMenuBar();
		menubar.setFont(new java.awt.Font("sansserif", 0, 11));
		JMenu menu1 = new JMenu(MENU_SETTING);
		JMenu menu2 = new JMenu(MENU_MANUAL);

		menubar.add(menu1);
		menubar.add(menu2);

		BasPane leftPanel = new BasPane();
		BasPane rightPanel = new BasPane();

	    rightPanel.setBackground(Color.white);
		leftPanel.setPreferredSize(new Dimension(350, 768));

		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.fill = GridBagConstraints.EAST;//【１】縦横にコンポーネットサイズを満たすように配置
		constraints.weightx = 10.0;//【２】余分の水平スペースを分配
		constraints.weighty = 10.0;//【３】余分の垂直スペースを分配
		constraints.insets = new Insets(2, 2, 2, 2);//【４】隙間

		leftPanel.setLayout(layout);
		JButton myButton = new BasButton("フォルダ選択");
		myButton.setFont(new java.awt.Font("monospaced", 0, 14));
		myButton.setForeground(Color.black);
		myButton.setPreferredSize(new Dimension(150, 30));

		List<FileInfoBean> fileList = new ArrayList<FileInfoBean>();
		FileInfoBean fileInfo =new FileInfoBean();
		fileInfo.setStatus("未");
		fileInfo.setFilename("a.mp4");
		fileInfo.setUpdate("220/09/03 11:00:02");
		fileList.add(fileInfo);

		FileInfoBean fileInfo1 =new FileInfoBean();
		fileInfo1.setStatus("未");
		fileInfo1.setFilename("b.mp4");
		fileInfo1.setUpdate("220/09/03 11:00:02");
		fileList.add(fileInfo1);

		BasTable table = new BasTable(fileList);

		JTextField textField01 = new JTextField(25) {
			@Override
			protected void paintComponent(Graphics g) {
				if (!isOpaque()) {
					int w = getWidth() - 1;
					int h = getHeight() - 1;
					Graphics2D g2 = (Graphics2D) g.create();
					g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
					g2.setPaint(UIManager.getColor("TextField.background"));
					g2.fillRoundRect(0, 0, w, h, h, h);
					g2.setPaint(Color.GRAY);
					g2.drawRoundRect(0, 0, w, h, h, h);
					g2.dispose();
				}
				super.paintComponent(g);
			}

			@Override
			public void updateUI() {
				super.updateUI();
				setOpaque(false);
				// setBackground(new Color(0x0, true));
				setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
			}
		};
		textField01.setBackground(Color.white);

		ImageIcon icon = new ImageIcon(new ImageIcon(currentDir + "/img/search.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
		JButton button = new JButton(icon);
		button.setContentAreaFilled(false);
		button.setMargin(new Insets(0, 0, 0, 0));
		button.setBorderPainted(false);

		BasTable basTb = new BasTable("",new ArrayList<PatientInfoBean>());
		constraints.gridx = 0;	//位置x
		constraints.gridy = 0;	//位置y
		constraints.gridwidth = 1;	//コンポーネントの表示領域のセル数 横
		constraints.gridheight = 1;	//コンポーネントの表示領域のセル数 縦
		layout.setConstraints(myButton, constraints);

		constraints.gridx = 0;	//位置x
		constraints.gridy = 2;	//位置y
		constraints.gridwidth = 2;	//コンポーネントの表示領域のセル数 横
		constraints.gridheight = 1;	//コンポーネントの表示領域のセル数 縦
		layout.setConstraints(table, constraints);//現在の制約を使い

		constraints.gridx = 0;	//位置x
		constraints.gridy = 3;	//位置y
		constraints.gridwidth = 1;	//コンポーネントの表示領域のセル数 横
		constraints.gridheight = 1;	//コンポーネントの表示領域のセル数 縦
		layout.setConstraints(textField01, constraints);//現在の制約を使い

		constraints.gridx = 1;	//位置x
		constraints.gridy = 3;	//位置y
		layout.setConstraints(button, constraints);//現在の制約を使い

		constraints.gridx = 0;	//位置x
		constraints.gridy = 4;	//位置y
		constraints.gridwidth = 2;	//コンポーネントの表示領域のセル数 横
		layout.setConstraints(basTb, constraints);//現在の制約を使い

		leftPanel.add(myButton);
		leftPanel.add(table);
		leftPanel.add(textField01);
		leftPanel.add(button);
		leftPanel.add(basTb);

		JTextPane pTextPane = new JTextPane();
		pTextPane.setEditable(false);

		Border blackline = BorderFactory.createLineBorder(Color.DARK_GRAY);
		pTextPane.setBorder(blackline);

		leftPanel.setMinimumSize(new Dimension(100, 0));
		leftPanel.setMaximumSize(new Dimension(400, 0));
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
		splitPane.setDoubleBuffered(true);
		this.setJMenuBar(menubar);
		this.setAlwaysOnTop(true);

		this.getContentPane().add(splitPane, BorderLayout.CENTER);
		this.getContentPane().add(pTextPane, BorderLayout.SOUTH);
	}

	public void doInitThread() {

		ThreadCreateMainFrm threadCreateMainFrm = new ThreadCreateMainFrm();

		try {
			threadCreateMainFrm.join();
		} catch (Exception e) {
		}
	}

	class ThreadCreateMainFrm extends Thread {
		public ThreadCreateMainFrm() {
			setPriority(4);
			start();
		}

		public void run() {
			try {
				jbInit();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		BasFrame frame = new BasFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setLocation(100, 100);
		frame.setVisible(true);

	}

}
