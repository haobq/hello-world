/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */

package jp.co.inc.meida.video.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JWindow;

import jp.co.inc.meida.video.common.BasConst;
import jp.co.inc.meida.video.utils.FileProperty;

public class ESplash extends JWindow implements BasConst{

	private JLabel lblProcess = new JLabel();
	private JLabel lblProcess1 = new JLabel();
	private JLabel lblPrjName = new JLabel();
	private JLabel lblPrjVer = new JLabel();
	private JLabel lblPrjVerDate = new JLabel();
	JButton jButton1 = new JButton();

	public ESplash() {
		try {
            setVerAndDate();
			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		int iScreenX=1024;
		int iScreenY=768;
		int Xpos = (iScreenX - getSize().width) / 2;
		int Ypos = (iScreenY - getSize().height) / 2;
		setBounds(Xpos, Ypos-100, getSize().width, getSize().height);
		setSize(405, 215);
	}

	public JLabel getProcessLbl() {
		return lblProcess;
	}

	public void jbInit() {
		setBackground(Color.white);

		lblProcess.setText("Now Loading");
		lblProcess.setBounds(new Rectangle(15, 180, 100, 17));
		lblProcess.setForeground(Color.BLUE);
		lblProcess.setFont(new Font("ＭＳ Ｐゴシック", 1, 16));
		lblProcess1.setText("．．．");
		lblProcess1.setBounds(new Rectangle(115, 180, 30, 17));
		lblProcess1.setForeground(Color.BLUE);
		lblProcess1.setFont(new Font("DialogInput", 1, 16));

		lblPrjName.setText(SYSTEM_NAME);
		lblPrjName.setBounds(new Rectangle(68, 83, 280, 25));
		lblPrjName.setForeground(new Color(0, 0, 0));
		lblPrjName.setFont(new Font("ＭＳ Ｐゴシック", 1, 25));

		lblPrjVer.setBounds(new Rectangle(87, 123, 150, 25));
		lblPrjVer.setForeground(new Color(0, 0, 0));
		lblPrjVer.setFont(new Font("ＭＳ Ｐゴシック", 1, 20));

		lblPrjVerDate.setBounds(new Rectangle(232, 125, 150, 25));
		lblPrjVerDate.setForeground(Color.GRAY);
		lblPrjVerDate.setFont(new Font("ＭＳ Ｐゴシック", 1, 16));
		ImageIcon ig = new ImageIcon("img/mast1.gif");
		JLabel lblImg = new JLabel(ig);

		lblImg.setOpaque(true);
		lblImg.setBackground(Color.white);
		lblImg.setBounds(new Rectangle(3, 2, 400, 71));

		this.getContentPane().setBackground(Color.white);
		this.getContentPane().setLayout(null);
		this.getContentPane().add(lblImg, null);
		this.getContentPane().add(lblProcess, null);
		this.getContentPane().add(lblProcess1, null);
		this.getContentPane().add(lblPrjName, null);
		this.getContentPane().add(lblPrjVer, null);
		this.getContentPane().add(lblPrjVerDate, null);
	}

	public static void main(String[] args) {
		// スプラッシュ画面起動
		ESplash esplash = new ESplash();
		esplash.setSize(405, 215);
		esplash.setVisible(true);

		//初期化処理
		try {
			Thread.sleep(5000L);
		} catch (InterruptedException ex) {
		}
		// スプラッシュ画面閉じる
		esplash.setVisible(false);
	}

    private void setVerAndDate () {
        String proFilePath = "conf/version.ini";
        FileProperty filePro;
        try {
            filePro = new FileProperty(proFilePath);
            String ver = filePro.getProperty("Ver");
            String date = filePro.getProperty("Date");
            lblPrjVer.setText("Version " + ver);
            lblPrjVerDate.setText(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
