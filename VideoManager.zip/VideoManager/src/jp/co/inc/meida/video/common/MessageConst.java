/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0  2020/09/01
 */

package jp.co.inc.meida.video.common;

/**
 * クラス名：システムメッセージクラス.
 *
 */
public interface MessageConst {
    public final static String V0001 = "動画管理システム   \nﾊﾞｰｼﾞｮﾝ 1.0.0    2020/09/01\nメディア株式会社";
    public final static String E0001 = "システムエラーが発生しました。\nサポートセンターまでご連絡下さい。";
    public final static String E0002 = "";
    public final static String E0003 = "";
}
