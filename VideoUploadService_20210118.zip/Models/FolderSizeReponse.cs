﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class FolderSizeReponse
    {
        public long Contract_size { get; set; }
        public long Used_size { get; set; }
        public long Free_size { get; set; }
        //エラー
        public ErrorReponse Error { get; set; }
    }
}