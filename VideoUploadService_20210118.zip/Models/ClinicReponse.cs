﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class ClinicReponse
    {
        //医院リスト
        public List<Clinic> Clinics  { get; set; }
        //エラー
        public ErrorReponse Error { get; set; }
    }
}