﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    public class FacilityReponse
    {
        //訪問先ID
        public List<Facility> facilities { get; set; }
        //エラー
        public ErrorReponse Error { get; set; }
    }
}