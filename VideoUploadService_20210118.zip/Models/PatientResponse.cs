﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoUploadService.Models
{
    /// <summary>
    /// 患者検索の結果
    /// </summary>
    public class PatientResponse
    {
        // 患者一覧
        public List<Patient> patients { get; set; }
        //エラー
        public ErrorReponse Error { get; set; }

    }
}