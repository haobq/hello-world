﻿using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VideoUploadService.Models.Common
{
    public class SqlHelper
    {
        private static readonly string connstr = ConfigurationManager.ConnectionStrings["DB_CONNECTION"].ConnectionString;
        private static readonly log4net.ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static bool result = false;
        //動画ファイル登録					
        internal static bool InsertMovie(MovieRequest movie)
        {
            string sql = "INSERT INTO tbl_patient_movie" +
                     "(" +
                     "hosp_id," +
                     "patient_id," +
                     "video_no," +
                     "video_kbn," +
                     "mask," +
                     "photo_date," +
                     "remarks," +
                     "video_path," +
                     "edit_date," +
                     "edit_user," +
                     "video_tag," +
                     "title," +
                     "regist_date," +
                     "video_size" +
                     ") " +
                "VALUES" +
                    "(" +
                    "@hosp_id," +
                    "@patient_id," +
                    "@video_no," +
                    "'1'," +
                    "'0'," +
                    "@photo_date," +
                    "@remarks," +
                    "@video_path," +
                    "getdate()," +
                    "@edit_user," +
                    "@video_tag," +
                    "@title," +
                    "getdate()," +
                    "@video_size" +
                    ")";
            try
            {
                //hosp_id
                SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = movie.Certification.Hosp_id
                };
                //patient_id
                SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = movie.Patient_id
                };

                //video_no
                SqlParameter paramVideo_no = new SqlParameter("@video_no", SqlDbType.NVarChar)
                {
                    Value = movie.Video_no
                };

                //photo_date
                SqlParameter paramPhoto_date = new SqlParameter("@photo_date", SqlDbType.DateTime)
                {
                    Value = movie.Movie_date
                };
                //remarks
                SqlParameter paramRemarks = new SqlParameter("@remarks", SqlDbType.NVarChar)
                {
                    Value = movie.Remarks
                };
                //video_path
                SqlParameter paramVideo_path = new SqlParameter("@video_path", SqlDbType.NVarChar)
                {
                    Value = movie.Video_path
                };
                //edit_user
                SqlParameter paramEdit_user = new SqlParameter("@edit_user", SqlDbType.NVarChar)
                {
                    Value = movie.Edit_user
                };
                //edit_user
                SqlParameter paramVideo_tag = new SqlParameter("@video_tag", SqlDbType.NVarChar)
                {
                    Value = movie.Video_tag
                };
                //edit_user
                SqlParameter paramTitle = new SqlParameter("@title", SqlDbType.NVarChar)
                {
                    Value = movie.Title
                };
                //video_size
                SqlParameter paramVideo_size = new SqlParameter("@video_size", SqlDbType.BigInt)
                {
                    Value = movie.Movie_size
                };
                SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramVideo_no,
                    paramPhoto_date,
                    paramRemarks,
                    paramVideo_path,
                    paramEdit_user,
                    paramVideo_tag,
                    paramTitle,
                    paramVideo_size
                };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddRange(parameters);
                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                result = true;
                            }
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception e)
            {
                string ec = e.Message.ToString();
                logger.Error(movie.Certification.Group_id + "-" + movie.Certification.User_id + ":" + e);
                result = false;
            }

            return result;
        }

        //静止画ファイル登録					
        internal static bool InsertImg(MovieRequest movie)
        {

            string sql = "INSERT INTO tbl_patient_image" +
                     "(" +
                     "hosp_id," +
                     "patient_id," +
                     "image_no," +
                     "image_kbn," +
                     "mask," +
                     "photo_date," +
                     "remarks," +
                     "title," +
                     "image_path," +
                     "edit_date," +
                     "edit_user," +
                     "regist_date," +
                     "image_tag" +
                      ") " +
                "VALUES" +
                    "(" +
                    "@hosp_id," +
                    "@patient_id," +
                    "@image_no," +
                    "'1'," +
                    "'0'," +
                    "@photo_date," +
                    "@remarks," +
                    "@title," +
                    "@video_path," +
                    "getdate()," +
                    "@edit_user," +
                    "getdate()," +
                    "@video_tag" +
                  ")";
            try
            {
                //hosp_id
                SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = movie.Certification.Hosp_id
                };
                //patient_id
                SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = movie.Patient_id
                };

                //image_no
                SqlParameter paramImage_no = new SqlParameter("@image_no", SqlDbType.NVarChar)
                {
                    Value = movie.Image_no
                };

                //photo_date
                SqlParameter paramPhoto_date = new SqlParameter("@photo_date", SqlDbType.DateTime)
                {
                    Value = movie.Movie_date
                };
                //remarks
                SqlParameter paramRemarks = new SqlParameter("@remarks", SqlDbType.NVarChar)
                {
                    Value = movie.Remarks
                };
                //video_path
                SqlParameter paramVideo_path = new SqlParameter("@video_path", SqlDbType.NVarChar)
                {
                    Value = movie.Video_path
                };
                //edit_user
                SqlParameter paramEdit_user = new SqlParameter("@edit_user", SqlDbType.NVarChar)
                {
                    Value = movie.Edit_user
                };
                //edit_user
                SqlParameter paramVideo_tag = new SqlParameter("@video_tag", SqlDbType.NVarChar)
                {
                    Value = movie.Video_tag
                };
                //edit_user
                SqlParameter paramTitle = new SqlParameter("@title", SqlDbType.NVarChar)
                {
                    Value = movie.Title
                };
                //video_size
                SqlParameter paramVideo_size = new SqlParameter("@video_size", SqlDbType.BigInt)
                {
                    Value = movie.Movie_size
                };

                SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramImage_no,
                    paramPhoto_date,
                    paramRemarks,
                    paramVideo_path,
                    paramEdit_user,
                    paramVideo_tag,
                    paramTitle,
                    paramVideo_size
               };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddRange(parameters);
                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                result = true;
                            }
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception e)
            {
                string ec = e.Message.ToString();
                logger.Error(movie.Certification.Group_id + "-" + movie.Certification.User_id + ":" + e);
                result = false;
            }

            return result;
        }
        //動画DB情報更新
        internal static bool VideoUpdate(Certification cert, string patient_id, int video_no, string title, string video_tag, string remarks, string video_Kbn, string mask)
        {
            string sql;
            sql = "update tbl_patient_movie";
            sql += " set ";
            sql += " edit_user = @edit_user,";
            if (title != null && title.ToLower() != "null")
            {
                sql += " title = '" + title + "',";
            }
            if (video_tag != null && video_tag.ToLower() != "null")
            {
                sql += " video_tag = '" + video_tag + "',";
            }
            if (remarks != null && remarks.ToLower() != "null")
            {
                sql += " remarks = '" + remarks + "',";
            }
            if (video_Kbn != null && video_Kbn.ToLower() != "null")
            {
                sql += " video_Kbn = '" + video_Kbn + "',";
            }
            if (mask != null && mask.ToLower() != "null")
            {
                sql += " mask = '" + mask + "',";
            }
            sql += " edit_date = getdate()";
            sql += " where hosp_id = @hosp_id and patient_id = @patient_id and video_no = @video_no";

            try
            {
                //User_id
                SqlParameter paramEdit_user = new SqlParameter("@edit_user", SqlDbType.NVarChar)
                {
                    Value = cert.User_id
                };
                //hosp_id
                SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = cert.Hosp_id
                };
                //patient_id
                SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = patient_id
                };
                result = false;
                //image_no
                SqlParameter paramVideo_no = new SqlParameter("@video_no", SqlDbType.Int)
                {
                    Value = video_no
                };
                SqlParameter[] parameters = new SqlParameter[]{
                    paramEdit_user,
                    paramHosp_id,
                    paramPatient_id,
                    paramVideo_no
                };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlTransaction transaction = conn.BeginTransaction())
                        {
                            try
                            {
                                using (SqlCommand cmd = new SqlCommand(sql, conn, transaction))
                                {
                                    cmd.Parameters.AddRange(parameters);
                                    cmd.ExecuteNonQuery();
                                    transaction.Commit();
                                    result = true;
                                }
                            }
                            catch (Exception e)
                            {
                                transaction.Rollback();
                                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                                BizException biz = new BizException("SQLError", Constants.MsgFailedUpdate);
                                throw biz;
                            }
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                BizException biz = new BizException("SQLError", Constants.MsgFailedUpdate);
                throw biz;
            }

            return result;
        }
        //静止画DB情報更新
        internal static bool ImageUpdate(Certification cert, string patient_id, int image_no, string title, string image_tag, string remarks, string image_Kbn, string mask)
        {
            string sql;
            sql  = "update tbl_patient_image";
            sql += " set ";
            sql += " edit_user = @edit_user,";
            if (title != null && title.ToLower() != "null")
            {
                sql += " title = '"+ title+ "',";
            }
            if (image_tag != null && image_tag.ToLower() != "null")
            {
                sql += " image_tag = '" + image_tag + "',";
            }
            if (remarks != null && remarks.ToLower() != "null")
            {
                sql += " remarks = '" + remarks + "',";
            }
            if (image_Kbn != null && image_Kbn.ToLower() != "null")
            {
                sql += " image_Kbn = '" + image_Kbn + "',";
            }
            if (mask != null && mask.ToLower() != "null")
            {
                sql += " mask = '" + mask + "',";
            }
            sql += " edit_date = getdate()";
            sql += " where hosp_id = @hosp_id and patient_id = @patient_id and image_no = @image_no";

            try
            {
                //User_id
                SqlParameter paramEdit_user = new SqlParameter("@edit_user", SqlDbType.NVarChar)
                {
                    Value = cert.User_id
                };
                //hosp_id
                SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = cert.Hosp_id
                };
                //patient_id
                SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = patient_id
                };
                result = false;
                //image_no
                SqlParameter paramImage_no = new SqlParameter("@image_no", SqlDbType.Int)
                {
                    Value = image_no
                };
                SqlParameter[] parameters = new SqlParameter[]{
                    paramEdit_user,
                    paramHosp_id,
                    paramPatient_id,
                    paramImage_no
                };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlTransaction transaction = conn.BeginTransaction())
                        {
                            try
                            {
                                using (SqlCommand cmd = new SqlCommand(sql, conn, transaction))
                                {
                                    cmd.Parameters.AddRange(parameters);
                                    cmd.ExecuteNonQuery();
                                    transaction.Commit();
                                    result = true;
                                }
                            }
                            catch (Exception e)
                            {
                                transaction.Rollback();
                                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                                BizException biz = new BizException("SQLError", Constants.MsgFailedUpdate);
                                throw biz;
                            }
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                BizException biz = new BizException("SQLError", Constants.MsgFailedUpdate);
                throw biz;
            }

            return result;
        }

        //最大ImgeNo取得					
        internal static int GetImageNo(MovieRequest movie)
        {

            //クエリのSQL文を定義する
            //グループ番号の取得
            string sql;
            sql = "select isnull(max(image_no), 0)  + 1   as image_no from tbl_patient_image ";
            sql += "where hosp_id = @hosp_id ";
            sql += "  and patient_id = @patient_id ";
            sql += "  and image_kbn = '1' ";

            //SQLインジェクションを防止する
            //hosp_id
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = movie.Certification.Hosp_id
            };
            //patient_id
            SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
            {
                Value = movie.Patient_id
            };

            SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id
                };

            int seqNo = 1;

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    seqNo = (int)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    string ec = e.Message.ToString();
                    logger.Error(movie.Certification.Hosp_id + "-" + movie.Certification.User_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return seqNo;

        }

        internal static List<Movies> GetVideoList(string hosp_id,string patient_id, string movie_no)
        {
            List<Movies> movies = new List<Movies>();
            //クエリのSQL文を定義する
            string sql = "select patient_id, ";
            sql += "video_no as movie_no,";
            sql += "CONVERT(VARCHAR, photo_date, 111) as photo_date,";
            sql += "title,";
            sql += "video_path as movie_path ,";
            sql += "video_tag as movie_tag,";
            sql += "remarks,";
            sql += "regist_date,";
            sql += "'1' as kbn, ";
            sql += "mask ";
            sql += "from tbl_patient_movie";
            sql += " where hosp_id = @hosp_id and patient_id = @patient_id ";
            if (!string.IsNullOrEmpty(movie_no))
            {
                sql += " and video_no= " + movie_no;
            }
            sql += " order by photo_date desc, regist_date desc ";

            //SQLインジェクションを防止する
            //hosp_id
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            //patient_id
            SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
            {
                Value = patient_id
            };
            SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id
                };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    Movies movie = new Movies();
                                    movie.Patient_id = (reader.IsDBNull(0) ? "" : reader.GetString(0));
                                    movie.Movie_no = (reader.GetInt32(1));
                                    movie.Photo_date = (reader.IsDBNull(2) ? "" : reader.GetString(2));
                                    movie.Title = (reader.IsDBNull(3) ? "" : reader.GetString(3));
                                    movie.Movie_path = (reader.IsDBNull(4) ? "" : reader.GetString(4));
                                    movie.Movie_tag = (reader.IsDBNull(5) ? "" : reader.GetString(5));
                                    movie.Remarks = (reader.IsDBNull(6) ? "" : reader.GetString(6));
                                    movie.Regist_date = (reader.IsDBNull(7) ? "" : reader.GetDateTime(7).ToString());
                                    movie.Kbn = (reader.IsDBNull(8) ? "" : reader.GetString(8));
                                    movie.Mask = (reader.IsDBNull(9) ? "" : reader.GetString(9));
                                    movies.Add(movie);
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    string ec = e.Message.ToString();
                    logger.Error(hosp_id + "-" + patient_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return movies;
        }

        internal static Img GetImage(Certification cert, string patient_id, int image_no)
        {
            Img image = new Img();
            //クエリのSQL文を定義する
            string sql = "select patient_id, ";
            sql += "image_no as image_no,";
            sql += "CONVERT(VARCHAR, photo_date, 111) as photo_date,";
            sql += "title,";
            sql += "image_path as movie_path ,";
            sql += "image_tag as movie_tag,";
            sql += "remarks,";
            sql += "regist_date,";
            sql += "mask ";
            sql += "from tbl_patient_image";
            sql += " where hosp_id = @hosp_id and patient_id = @patient_id ";
            sql += " and image_no= " + @image_no;
            sql += " order by photo_date desc, regist_date desc ";

            //SQLインジェクションを防止する
            //hosp_id
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = cert.Hosp_id
            };
            //patient_id
            SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
            {
                Value = patient_id
            };
            //image_no
            SqlParameter paramImage_no = new SqlParameter("@image_no", SqlDbType.Int)
            {
                Value = image_no
            };
            SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramImage_no
            };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    image = new Img();
                                    image.Patient_id = (reader.IsDBNull(0) ? "" : reader.GetString(0));
                                    image.Image_no = (reader.GetInt32(1));
                                    image.Photo_date = (reader.IsDBNull(2) ? "" : reader.GetString(2));
                                    image.Title = (reader.IsDBNull(3) ? "" : reader.GetString(3));
                                    image.Image_path = (reader.IsDBNull(4) ? "" : reader.GetString(4));
                                    image.Image_tag = (reader.IsDBNull(5) ? "" : reader.GetString(5));
                                    image.Remarks = (reader.IsDBNull(6) ? "" : reader.GetString(6));
                                    image.Regist_date = (reader.IsDBNull(7) ? "" : reader.GetDateTime(7).ToString());
                                    image.Mask = (reader.IsDBNull(8) ? "" : reader.GetString(8));
                                    image.Image_Kbn = "2";
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    string ec = e.Message.ToString();
                    logger.Error(cert.Hosp_id + "-" + patient_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return image;
        }

        internal static List<Movies> GetImageList(string hosp_id, string patient_id, string movie_no)
        {
            List<Movies> movies = new List<Movies>();
            //クエリのSQL文を定義する
            string sql = "select patient_id, ";
            sql += "image_no as movie_no,";
            sql += "CONVERT(VARCHAR, photo_date, 111) as photo_date,";
            sql += "title,";
            sql += "image_path as movie_path ,";
            sql += "image_tag as movie_tag,";
            sql += "remarks,";
            sql += "regist_date,";
            sql += "'2' as kbn, ";
            sql += "mask ";
            sql += "from tbl_patient_image";
            sql += " where hosp_id = @hosp_id and patient_id = @patient_id ";
            if (!string.IsNullOrEmpty(movie_no))
            {
                sql += " and video_no= " + movie_no;
            }
            sql += " order by photo_date desc, regist_date desc ";

            //SQLインジェクションを防止する
            //hosp_id
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            //patient_id
            SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
            {
                Value = patient_id
            };
            SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id
                };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    Movies movie = new Movies();
                                    movie.Patient_id = (reader.IsDBNull(0) ? "" : reader.GetString(0));
                                    movie.Movie_no = (reader.GetInt32(1));
                                    movie.Photo_date = (reader.IsDBNull(2) ? "" : reader.GetString(2));
                                    movie.Title = (reader.IsDBNull(3) ? "" : reader.GetString(3));
                                    movie.Movie_path = (reader.IsDBNull(4) ? "" : reader.GetString(4));
                                    movie.Movie_tag = (reader.IsDBNull(5) ? "" : reader.GetString(5));
                                    movie.Remarks = (reader.IsDBNull(6) ? "" : reader.GetString(6));
                                    movie.Regist_date = (reader.IsDBNull(7) ? "" : reader.GetDateTime(7).ToString());
                                    movie.Kbn = (reader.IsDBNull(8) ? "" : reader.GetString(8));
                                    movie.Mask = (reader.IsDBNull(9) ? "" : reader.GetString(9));
                                    movies.Add(movie);
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    string ec = e.Message.ToString();
                    logger.Error(hosp_id + "-" + patient_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return movies;
        }

        //動画ファイル格納場所					
        internal static String GetMoviPath(DeleteRequest movie)
        {
            //クエリのSQL文を定義する
            string sql = "select video_path FROM tbl_patient_movie where hosp_id = @hosp_id and patient_id = @patient_id and video_no = @video_no";

            //SQLインジェクションを防止する
            //hosp_id
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = movie.Certification.Hosp_id
            };
            //patient_id
            SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
            {
                Value = movie.Patient_id
            };

            //video_no
            SqlParameter paramVideo_no = new SqlParameter("@video_no", SqlDbType.NVarChar)
            {
                Value = movie.Movie_index
            };

            SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramVideo_no
                };

            string path = "";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    path = (string)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    string ec = e.Message.ToString();
                    logger.Error(movie.Certification.Hosp_id + "-" + movie.Certification.User_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return path;
        }


        //静止画ファイル格納場所					
        internal static String GetImgPath(Img image)
        {
            //クエリのSQL文を定義する
            string sql = "select image_path FROM tbl_patient_image where hosp_id = @hosp_id and patient_id = @patient_id and  image_no = @image_no ";

            //SQLインジェクションを防止する
            //hosp_id
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = image.Certification.Hosp_id
            };
            //patient_id
            SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
            {
                Value = image.Patient_id
            };

            //image_no
            SqlParameter paramImage_no = new SqlParameter("@image_no", SqlDbType.Int)
            {
                Value = image.Image_no
            };

            SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramImage_no
               };

            string path = "";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    path = (string)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    string ec = e.Message.ToString();
                    logger.Error(image.Certification.Hosp_id + "-" + image.Certification.User_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return path;
        }

        //動画ファイル削除					
        internal static bool DeleteMovie(DeleteRequest movie)
        {
            string sql = "DELETE FROM tbl_patient_movie where hosp_id = @hosp_id and patient_id = @patient_id and video_no = @video_no ";
            try
            {
                //hosp_id
                SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = movie.Certification.Hosp_id
                };
                //patient_id
                SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = movie.Patient_id
                };

                //video_no
                SqlParameter paramVideo_no = new SqlParameter("@video_no", SqlDbType.NVarChar)
                {
                    Value = movie.Movie_index
                };

                SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramVideo_no
                };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddRange(parameters);
                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                result = true;
                            }
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(movie.Certification.Hosp_id + "-" + movie.Certification.User_id + ":" + e);
                BizException biz = new BizException("SQLError", Constants.MsgFailedDelete);
                throw biz;
            }

            return result;
        }
        //静止画ファイル削除					
        internal static bool DeleteImg(Img image)
        {
            string sql = "DELETE FROM tbl_patient_image where hosp_id = @hosp_id and patient_id = @patient_id and image_no = @image_no ";
            try
            {
                //hosp_id
                SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = image.Certification.Hosp_id
                };
                //patient_id
                SqlParameter paramPatient_id = new SqlParameter("@patient_id", SqlDbType.NVarChar)
                {
                    Value = image.Patient_id
                };

                //image_no
                SqlParameter paramImage_no = new SqlParameter("@image_no", SqlDbType.Int)
                {
                    Value = image.Image_no
                };

                SqlParameter[] parameters = new SqlParameter[]{
                    paramHosp_id,
                    paramPatient_id,
                    paramImage_no
               };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddRange(parameters);
                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                result = true;
                            }
                        }
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(image.Certification.Hosp_id + "-" + image.Certification.User_id + ":" + e);
                BizException biz = new BizException("SQLError", Constants.MsgFailedDelete);
                throw biz;
            }

            return result;
        }

        internal static string GetMedia_auth(string user_id, string hosp_id, string group_id, string session_flg)
        {
            SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "select media_auth from tbl_session where session_flg = '" + session_flg + "' and group_id = @group_id and hosp_id = @hosp_id and user_id = @user_id ";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            SqlParameter parameter2 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            SqlParameter parameter3 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };
            parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };
            string media_auth = "";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    media_auth = (string)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(hosp_id + "-" + user_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return media_auth;

        }

        internal static string GetTerminalId(string group_id, string user_id)
        {
            SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "select terminal_id from mst_terminal where mask = '0' and group_id = @group_id and user_id = @user_id";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };
            parameters = new SqlParameter[] { parameter1, parameter2 };
            string terminal_id = "";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    terminal_id = (string)reader[0];
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(group_id + "-" + user_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return terminal_id;
        }

        internal static int IsOverCapacity(string group_id)
        {
            int rtn = 2;
            SqlParameter[] parameters;
            //クエリのSQL文を定義する
            string sql = "SELECT grp.group_id, ";
            sql = sql + "  case when (isnull(count(img.image_no), 0) *  CONVERT(numeric,1024*1024 )  + isnull(sum(mvi.video_size),0)) > isnull(sum(fs.capacity),0)  then 1 ";
            sql = sql + "       when isnull(sum(fs.capacity),0) = 0  then 2 ";
            sql = sql + "  else 0 ";
            sql = sql + "  end as overCapacity ";
            sql = sql + " FROM ";
            sql = sql + "  dbo.mst_group_hosp  grp ";
            sql = sql + "   left join dbo.tbl_patient_image img ";
            sql = sql + "     on grp.hosp_id = img.hosp_id ";
            sql = sql + "   left join dbo.tbl_patient_movie mvi ";
            sql = sql + "     on grp.hosp_id = mvi.hosp_id ";
            sql = sql + "   left join dbo.tbl_folder_size fs ";
            sql = sql + "     on grp.group_id = fs.group_id ";
            sql = sql + " WHERE grp.group_id = @group_id";
            sql = sql + " GROUP BY grp.group_id ";
            //SQLインジェクションを防止する
            SqlParameter parameter = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = group_id
            };
            parameters = new SqlParameter[] { parameter };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    rtn = (int)reader[1];
                                }
                            }
                            catch (Exception e)
                            {
                                conn.Close();
                                logger.Error(group_id + ":" + e);
                                BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                                throw biz;
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(group_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return rtn;
        }


        //ユーザID、パスワード、グループIDが正しいかをチェックする。
        internal static bool IsCorrect(string groupId, string userId, string pswd)
        {
            bool ret = false;
            string sql;
            SqlParameter[] parameters;
            if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(pswd))
            {
                //クエリのSQL文を定義する
                sql = "select index_no from mst_user where group_id = @groupId and user_id = @userId and user_pw = @pswd and mask= 0";

                //SQLインジェクションを防止する
                SqlParameter parameter1 = new SqlParameter("@groupId", SqlDbType.NVarChar)
                {
                    Value = groupId ?? ""
                };

                SqlParameter parameter2 = new SqlParameter("@userId", SqlDbType.NVarChar)
                {
                    Value = userId ?? ""
                };

                SqlParameter parameter3 = new SqlParameter("@pswd", SqlDbType.NVarChar)
                {
                    Value = pswd ?? ""
                };

                parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };
            }
            else
            {
                //クエリのSQL文を定義する
                sql = "select index_no from mst_group where group_id = @groupId and mask= 0";

                //SQLインジェクションを防止する
                SqlParameter parameter = new SqlParameter("@groupId", SqlDbType.NVarChar)
                {
                    Value = groupId ?? ""
                };

                parameters = new SqlParameter[] { parameter };
            }
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    try
                    {
                        cmd.Parameters.AddRange(parameters);
                        if (cmd.ExecuteScalar() != null)
                        {
                            ret = true;

                        }
                        else
                        {
                            ret = false;
                        }
                    }
                    catch (Exception e)
                    {
                        logger.Error(groupId + "-" + userId + ":" + e);
                        BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                        throw biz;
                    }
                    finally
                    {
                        conn.Close();

                    }
                }
            }
            return ret;

        }

        internal static bool IsCorrect(string groupId)
        {
            bool flag = IsCorrect(groupId, null, null);

            return flag;
        }

        /// <summary>
        /// 患者リストを取得
        /// </summary>
        /// <param name="patientRequest"></param>
        /// <returns></returns>
        internal static List<Patient> GetPatient_data(PatientRequest patientRequest)
        {
            string group_id = patientRequest.Certification.Group_id;
            string hosp_id = patientRequest.Certification.Hosp_id;
            string patient_name = patientRequest.Patient_name;
            string visit_id = patientRequest.Visit_id;
            string visitDate = patientRequest.Visit_Date;
            string kbn = patientRequest.Kbn;

            string sql = " select p.patient_id as patient_id,";
            sql += "   IsNull(p.patient_name, '') as patient_name,";
            sql += "   IsNull(p.patient_kana, '') as patient_kana,";
            sql += "   case when p.patient_sex = 'M' then '男'";
            sql += "   when p.patient_sex = 'F' then '女'";
            sql += "   when p.patient_sex IS NULL then ''";
            sql += "    end as patient_sex,";
            sql += "   case when p.patient_birthday IS NULL then ''";
            sql += "   else CONVERT(VARCHAR(10), p.patient_birthday, 120)";
            sql += "   end as patient_birthday,";
            sql += "   m.visit_abbreviation";
            sql += " from tbl_patient p";
            sql += "   join tbl_patient_visit t ON(p.hosp_id = t.hosp_id and p.patient_id = t.patient_id)";
            sql += "   join mst_visit m On (m.hosp_id = t.hosp_id and m.visit_id = t.visit_id and m.visit_kbn = t.visit_kbn)";
            sql += "   left outer join tbl_visit_schedule f On(p.hosp_id = f.hosp_id and p.patient_id= f.patient_id  and m.visit_id = f.visit_id and m.visit_kbn = f.visit_kbn)";
            sql += " where m.mask = '0' and p.hosp_id = @hosp_id";

            if (Tools.IsCheckParm(kbn) == true)
            {
                if (kbn.Equals("0"))
                {
                    // 全部訪問先
                }
                else if (kbn.Equals("1"))
                {
                    // ご自宅(居宅)のみ
                    sql += " and m.visit_kbn = '1' ";

                }
                else
                {
                    // ご自宅(居宅)以外
                    sql += " and m.visit_kbn <> '1' ";

                }
            }

            if (Tools.IsCheckParm(visit_id) == true)
            {
                sql += " and t.visit_id =  @visit_id";
            }

            if (Tools.IsCheckParm(patient_name) == true)
            {
                sql += " and(p.patient_name like '%@patient_name%' or  p.patient_kana like '%@patient_name%')";
            }

            if (Tools.IsCheckParm(visitDate) == true)
            {
                sql += " and f.visit_date = @visitDate";
            }

            sql += "  Union ";
            sql += " select p.patient_id as patient_id,";
            sql += "   IsNull(p.patient_name, '') as patient_name,";
            sql += "   IsNull(p.patient_kana, '') as patient_kana,";
            sql += "   case when p.patient_sex = 'M' then '男'";
            sql += "   when p.patient_sex = 'F' then '女'";
            sql += "   when p.patient_sex IS NULL then ''";
            sql += "    end as patient_sex,";
            sql += "   case when p.patient_birthday IS NULL then ''";
            sql += "   else CONVERT(VARCHAR(10), p.patient_birthday, 120)";
            sql += "   end as patient_birthday,";
            sql += "   m.visit_abbreviation";
            sql += " from tbl_patient p";
            sql += "   join tbl_patient_visit t ON(p.hosp_id = t.hosp_id and p.patient_id = t.patient_id)";
            sql += "   join mst_visit m On (m.hosp_id = t.hosp_id and m.visit_id = t.visit_id and m.visit_kbn = t.visit_kbn)";
            sql += "   left outer join tbl_platform f On(p.hosp_id = f.hosp_id and p.patient_id= f.patient_id)";
            sql += " where m.mask = '0' and f.mask = '0' and p.hosp_id = @hosp_id";

            if (Tools.IsCheckParm(kbn) == true)
            {
                if (kbn.Equals("0"))
                {
                    // 全部訪問先
                }
                else if (kbn.Equals("1"))
                {
                    // ご自宅(居宅)のみ
                    sql += " and m.visit_kbn = '1' ";

                }
                else
                {
                    // ご自宅(居宅)以外
                    sql += " and m.visit_kbn <> '1' ";

                }
            }

            if (Tools.IsCheckParm(visit_id) == true)
            {
                sql += " and t.visit_id =  @visit_id";
            }

            if (Tools.IsCheckParm(patient_name) == true)
            {
                sql += " and(p.patient_name like '%@patient_name%' or  p.patient_kana like '%@patient_name%')";
            }

            if (Tools.IsCheckParm(visitDate) == true)
            {
                sql += " and f.visit_date = @visitDate";
            }

            sql += " group by p.patient_id, IsNull(p.patient_name, ''), IsNull(p.patient_kana, ''), patient_sex, patient_birthday,m.visit_abbreviation ";

            sql += " order by patient_kana asc ";

            //SQLインジェクションを防止する
            SqlParameter paramHosp_id = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            SqlParameter paramePatient_name = new SqlParameter("@patient_name", SqlDbType.NVarChar)
            {
                Value = patient_name
            };
            SqlParameter paramVisit_id = new SqlParameter("@visit_id", SqlDbType.NVarChar)
            {
                Value = visit_id
            };
            SqlParameter parameVisit_Date = new SqlParameter("@visitDate", SqlDbType.NVarChar)
            {
                Value = visitDate
            };

            SqlParameter[] parameters = new SqlParameter[] { };
            if (Tools.IsCheckParm(patient_name) == true
                && Tools.IsCheckParm(visit_id) == true
                && Tools.IsCheckParm(visitDate) == true)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramePatient_name, paramVisit_id, parameVisit_Date };
            }
            else if (Tools.IsCheckParm(patient_name) == false
               && Tools.IsCheckParm(visit_id) == false
               && Tools.IsCheckParm(visitDate) == false)
            {
                parameters = new SqlParameter[] { paramHosp_id };
            }
            else if (Tools.IsCheckParm(patient_name) == true
                && Tools.IsCheckParm(visit_id) == false
                && Tools.IsCheckParm(visitDate) == false)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramePatient_name };
            }
            else if (Tools.IsCheckParm(patient_name) == true
                && Tools.IsCheckParm(visit_id) == true
                && Tools.IsCheckParm(visitDate) == false)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramePatient_name, paramVisit_id };
            }
            else if (Tools.IsCheckParm(patient_name) == true
                && Tools.IsCheckParm(visit_id) == false
                && Tools.IsCheckParm(visitDate) == true)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramePatient_name, parameVisit_Date };
            }
            else if (Tools.IsCheckParm(patient_name) == false
                && Tools.IsCheckParm(visit_id) == true
                && Tools.IsCheckParm(visitDate) == true)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramVisit_id, parameVisit_Date };
            }
            else if (Tools.IsCheckParm(patient_name) == false
                && Tools.IsCheckParm(visit_id) == false
                && Tools.IsCheckParm(visitDate) == true)
            {
                parameters = new SqlParameter[] { paramHosp_id, parameVisit_Date };
            }
            else if (Tools.IsCheckParm(patient_name) == false
                && Tools.IsCheckParm(visit_id) == true
                && Tools.IsCheckParm(visitDate) == false)
            {
                parameters = new SqlParameter[] { paramHosp_id, paramVisit_id };
            }


            List<Patient> terminals = new List<Patient>();


            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    sql = sql.Replace("@patient_name", patient_name);
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    Patient patient = new Patient
                                    {
                                        Group_id = group_id,
                                        Hosp_id = hosp_id,
                                        Patient_id = (reader.IsDBNull(0) ? "" : reader.GetString(0)),
                                        Patient_name = (reader.IsDBNull(1) ? "" : reader.GetString(1)),
                                        Patient_kana = (reader.IsDBNull(2) ? "" : reader.GetString(2)),
                                        Patient_sex = (reader.IsDBNull(3) ? "" : reader.GetString(3)),
                                        Patient_birthday = (reader.IsDBNull(4) ? "" : reader.GetString(4)),
                                        Visit_name = (reader.IsDBNull(5) ? "" : reader.GetString(5)),
                                    };
                                    terminals.Add(patient);
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    conn.Close();
                    logger.Error(patientRequest.Certification.Hosp_id + "-" + patientRequest.Certification.User_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return terminals;
        }
        /// <summary>
        /// 訪問先リスト取得する
        /// </summary>
        /// <param name="hosp_id"></param>
        /// <param name="visitDate"></param>
        /// <param name="kbn"></param>
        /// <returns></returns>
        internal static List<Facility> GetFacility_data(string hosp_id, string visitDate, string kbn)
        {
            List<Facility> terminals = new List<Facility>();

            string sql = "select visit_id, visit_abbreviation, visit_kbn from  ";
            sql += "(";
            sql += "select m.visit_id as visit_id, m.visit_abbreviation as visit_abbreviation, m.visit_kbn as visit_kbn ";
            sql += " from mst_visit m";
            sql += " left outer join tbl_visit_schedule t On(m.hosp_id = t.hosp_id and m.visit_id = t.visit_id and m.visit_kbn = t.visit_kbn)";
            sql += " where m.mask = '0'";
            sql += " and m.hosp_id = @hosp_id";
            if (!string.IsNullOrEmpty(visitDate))
            {
                sql += " and t.visit_date =  @vd";
            }
            sql += "  Union ";
            sql += "  select m.visit_id as visit_id, m.visit_abbreviation as visit_abbreviation, m.visit_kbn as visit_kbn ";
            sql += "   from mst_visit m";
            sql += "   left outer join tbl_patient_visit p On(m.hosp_id = p.hosp_id and m.visit_id = p.visit_id and m.visit_kbn = p.visit_kbn)";
            sql += "   left outer join tbl_platform t On(p.hosp_id = t.hosp_id and p.patient_id = t.patient_id)";
            sql += "  where m.mask = '0' and t.mask = '0'";
            sql += "   and m.hosp_id =  @hosp_id";
            if (!string.IsNullOrEmpty(visitDate))
            {
                sql += " and t.visit_date =  @vd";
            }

            sql += " ) a";
            if (Tools.IsCheckParm(kbn) == true)
            {
                if (kbn.Equals("0"))
                {
                    // 全部訪問先
                }
                else if (kbn.Equals("1"))
                {
                    // ご自宅(居宅)のみ
                    sql += " where visit_kbn = '1' ";

                }
                else
                {
                    // ご自宅(居宅)以外
                    sql += " where visit_kbn <> '1' ";

                }
            }
            sql += " group by visit_id, visit_abbreviation, visit_kbn ";


            SqlParameter parameter1 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };
            SqlParameter parameter2 = new SqlParameter("@vd", SqlDbType.NVarChar)
            {
                Value = visitDate
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 };
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    Facility facility = new Facility();
                                    facility.Visit_id = (string)reader[0];
                                    facility.Visit_name = (string)reader[1];
                                    facility.visit_kbn = (string)reader[2];
                                    terminals.Add(facility);
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    conn.Close();
                    logger.Error(hosp_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }

            return terminals;

        }
        /// <summary>
        /// 訪問先リスト取得する
        /// </summary>
        /// <param name="hosp_id"></param>
        /// <returns></returns>
        internal static List<Facility> GetFacility_data(string hosp_id)
        {
            string sql = "select visit_id, visit_abbreviation,visit_kbn";
            sql += " from mst_visit";
            sql += " where mask ='0'";
            sql += " and hosp_id = @hosp_id";

            //SQLインジェクションを防止する
            SqlParameter parameter = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
            {
                Value = hosp_id
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter };
            List<Facility> terminals = new List<Facility>();
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            try
                            {
                                while (reader.Read())
                                {
                                    Facility facility = new Facility();
                                    facility.Visit_id = (string)reader[0];
                                    facility.Visit_name = (string)reader[1];
                                    facility.visit_kbn = (string)reader[2];
                                    terminals.Add(facility);
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    conn.Close();
                    logger.Error(hosp_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }
            }
            return terminals;
        }

        /// <summary>
        /// 認証キーをチェックする
        /// </summary>
        /// <param name="groupID"></param>
        /// <param name="user_id"></param>
        /// <param name="mediaAuth"></param>
        /// <returns></returns>
        internal static bool KEY_CHK(string groupID, string user_id, string mediaAuth, string session_flg)
        {
            //クエリのSQL文を定義する
            string sql = "select media_auth from tbl_session ";
            sql += " WHERE regist_datetime <= getdate()";
            sql += " and regist_datetime >= dateadd(day, -1, getdate())";
            sql += " and session_flg = '" + session_flg + "'";
            sql += " and group_id = @group_id";
            sql += " and user_id = @user_id";
            sql += " and media_auth = @media_auth";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = groupID ?? ""
            };

            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id ?? ""
            };

            SqlParameter parameter3 = new SqlParameter("@media_auth", SqlDbType.NVarChar)
            {
                Value = mediaAuth ?? ""
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3 };

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        try
                        {
                            if (cmd.ExecuteScalar() != null)
                            {
                                return true;
                            }
                        }
                        catch (Exception ex)
                        {
                            conn.Close();
                            ex.Message.ToString();
                            BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                            throw biz;
                        }
                        return false;
                    }
                }
                catch (Exception e)
                {
                    conn.Close();
                    logger.Error(groupID + "-" + user_id + ":" + e);
                }
                finally
                {
                    conn.Close();
                }
                return false;

            }
        }

        //tbl_session登録
        internal static bool InsertTblSession(string user_id, string hosp_id, string group_id, string terminal_id, string session_flg)
        {
            bool sqlrtn = false;
            try
            {
                string sqlString = "";
                sqlString = "insert into tbl_session( ";
                sqlString += "user_id, ";
                sqlString += "group_id, ";
                sqlString += "hosp_id, ";
                sqlString += "terminal_id, ";
                sqlString += "session_flg, ";
                sqlString += "media_auth, ";
                sqlString += "regist_datetime) ";
                sqlString += "values( ";
                sqlString += "@user_id, ";
                sqlString += "@group_id, ";
                sqlString += "@hosp_id, ";
                sqlString += "@terminal_id, ";
                sqlString += "'" + session_flg + "', ";
                sqlString += "'" + Tools.GenerateAuthKey(20) + "', ";
                sqlString += "getdate()) ";

                SqlParameter parameter1 = new SqlParameter("@user_id", SqlDbType.NVarChar)
                {
                    Value = user_id
                };
                SqlParameter parameter2 = new SqlParameter("@hosp_id", SqlDbType.NVarChar)
                {
                    Value = hosp_id
                };
                SqlParameter parameter3 = new SqlParameter("@group_id", SqlDbType.NVarChar)
                {
                    Value = group_id
                };
                SqlParameter parameter4 = new SqlParameter("@terminal_id", SqlDbType.NVarChar)
                {
                    Value = terminal_id
                };
                SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2, parameter3, parameter4 };
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    try
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(sqlString, conn))
                        {
                            cmd.Parameters.AddRange(parameters);

                            int num = cmd.ExecuteNonQuery();

                            if (num > 0)
                            {
                                sqlrtn = true;
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        logger.Error(hosp_id + "-" + user_id + ":" + e);
                        BizException biz = new BizException("MsgExistedAuthentication", Constants.MsgExistedAuthentication);
                        throw biz;
                    }
                    finally
                    {
                        conn.Close();
                    }

                }
            }
            catch (Exception e)
            {
                logger.Error(hosp_id + "-" + user_id + ":" + e);
                BizException biz = new BizException("SQLError", Constants.MsgExistedAuthentication);
                throw biz;
            }
            return sqlrtn;
        }

        //TBL_SESSION削除
        internal static bool DelTblSession(Certification cert,bool blogin)
        {
            bool sqlrtn = false;
            string sql = "";

            //ログアウト時
            sql = "delete from tbl_session ";
            sql += "where ";
            sql += " user_id = @user_id ";
            sql += " and group_id = @group_id ";
            sql += " and session_flg = '" + cert.Session_flg + "'";
            if (blogin == true)
            {
                sql += " and regist_datetime <= (SELECT DATEADD(MINUTE, -30, GETDATE()))";
            }
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = cert.Group_id
            };

            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = cert.User_id
            };
            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 };
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);

                        int num = cmd.ExecuteNonQuery();

                        if (num > 0)
                        {
                            sqlrtn = true;
                        }
                    }
                }
                catch (Exception e)
                {
                    logger.Error(cert.Hosp_id + "-" + cert.User_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgFailedDelete);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }

            }
            return sqlrtn;
        }


        /// <summary>
        /// 医院リスト取得する
        /// </summary>
        /// <param name="groupID"></param>
        /// <returns></returns>
        internal static List<Clinic> GetClinic_data(string groupID, string user_id)
        {
            string sql = "select distinct mst_user_hosp.hosp_id,mst_hosp.hosp_name";
            sql += " from mst_user_hosp";
            sql += " INNER join mst_hosp";
            sql += " ON mst_user_hosp.hosp_id = mst_hosp.hosp_id";
            sql += " where mst_user_hosp.group_id = @group_id";
            sql += " and mst_user_hosp.user_id = @user_id";
            sql += " and mst_hosp.mask = '0'";
            sql += " and mst_user_hosp.effect_date_from <= GETDATE()";
            sql += " and mst_user_hosp.effect_date_to >= GETDATE()";

            //SQLインジェクションを防止する
            SqlParameter parameter1 = new SqlParameter("@group_id", SqlDbType.NVarChar)
            {
                Value = groupID
            };
            SqlParameter parameter2 = new SqlParameter("@user_id", SqlDbType.NVarChar)
            {
                Value = user_id
            };

            SqlParameter[] parameters = new SqlParameter[] { parameter1, parameter2 };
            List<Clinic> terminals = new List<Clinic>();
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddRange(parameters);
                        SqlDataReader reader = cmd.ExecuteReader();
                        try
                        {
                            while (reader.Read())
                            {
                                Clinic clinicReponse = new Clinic();
                                Clinic hosp = clinicReponse;
                                hosp.Hosp_id = (string)reader[0];
                                hosp.Hosp_name = (string)reader[1];
                                terminals.Add(hosp);
                            }
                        }
                        finally
                        {
                            reader.Close();
                        }

                    }
                }
                catch (Exception e)
                {
                    logger.Error(groupID + "-" + user_id + ":" + e);
                    BizException biz = new BizException("SQLError", Constants.MsgSqlError);
                    throw biz;
                }
                finally
                {
                    conn.Close();
                }

            }

            return terminals;
        }
    }
}