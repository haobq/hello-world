package jp.co.inc.media.vedio.utils;

public final class PatientInfo {

	/**
	 * 病院ID
	 */
	private String hospitalId;
	/**
	 * 患者ID
	 */
	private String patientId;
	/**
	 * 患者名
	 */
	private String patientName;
	/**
	 * 患者生年月日
	 */
	private String birthday;
	/**
	 * 患者性別
	 */
	private String sex;
	/**
	 * @return sex
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex セットする sex
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return hospitalId
	 */
	public String getHospitalId() {
		return hospitalId;
	}
	/**
	 * @param hospitalId セットする hospitalId
	 */
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	/**
	 * @return patientId
	 */
	public String getPatientId() {
		return patientId;
	}
	/**
	 * @param patientId セットする patientId
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	/**
	 * @return patientName
	 */
	public String getPatientName() {
		return patientName;
	}
	/**
	 * @param patientName セットする patientName
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	/**
	 * @return birthday
	 */
	public String getBirthday() {
		return birthday;
	}
	/**
	 * @param birthday セットする birthday
	 */
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}


}
