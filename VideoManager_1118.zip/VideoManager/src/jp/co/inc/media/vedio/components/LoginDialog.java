package jp.co.inc.media.vedio.components;

import java.util.logging.Level;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jp.co.inc.media.vedio.common.BasButton;
import jp.co.inc.media.vedio.common.BasDialog;
import jp.co.inc.media.vedio.common.BasFrame;
import jp.co.inc.media.vedio.frame.CallMainFrame;
import jp.co.inc.media.vedio.logic.VedioUploadServiceLogic;
import jp.co.inc.media.vedio.service.LoginRespone;
import jp.co.inc.media.vedio.utils.FileProperty;
import jp.co.inc.media.vedio.utils.Messagebox;
import jp.co.inc.media.vedio.utils.PasswordUtil;
import jp.co.inc.media.vedio.utils.SysInfoBean;

public class LoginDialog extends BasDialog {

	public LoginDialog(BasFrame callBaseFrm, Stage owner, String title, int width, int height) throws Exception {
		super(owner, title, width, height);
		initStyle(StageStyle.UTILITY);
		FileProperty filePro = new FileProperty(proFilePath);
		BorderPane loginPane = new BorderPane();
		loginPane.setPrefWidth(width);
		loginPane.setPrefHeight(height);
		GridPane gridpane = new GridPane();
		gridpane.setPadding(new Insets(15));
		gridpane.setHgap(5);
		gridpane.setVgap(5);
		String owned = filePro.getProperty("owned");

		Label userNameLbl = new Label("ユーザーID: ");
		gridpane.add(userNameLbl, 0, 1);

		Label passwordLbl = new Label("パスワード: ");
		gridpane.add(passwordLbl, 0, 2);

		final TextField userNameFld = new TextField();
		if ("true".equals(owned)) {
			userNameFld.setText(filePro.getProperty("userid"));

		}
		gridpane.add(userNameFld, 1, 1);

		final PasswordField passwordFld = new PasswordField();
		if ("true".equals(owned)) {
			passwordFld.setText(PasswordUtil.decrypt(filePro.getProperty("passwd")));
		}

		gridpane.add(passwordFld, 1, 2);
		final CheckBox checkFld = new CheckBox();
		checkFld.setPrefWidth(50);

		if ("true".equals(owned)) {
			checkFld.setSelected(true);
		}

		HBox hBox = new HBox();
		Label ownedLbl = new Label("ログイン情報を保存する");
		hBox.getChildren().addAll(checkFld, ownedLbl);
		gridpane.add(hBox, 1, 3);

		HBox hBoxSpace = new HBox();
		Label spacedLbl = new Label("");
		hBoxSpace.getChildren().addAll(spacedLbl);
		gridpane.add(hBoxSpace, 1, 4);

		Button login =new BasButton("config.png", 16, 16, "ログイン");
		login.setPrefWidth(100);
		login.setStyle(BUTTON_STYLE);
		login.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				try {
					FileProperty filePro = new FileProperty(proFilePath);

					//ログインサービスを呼び出す
					VedioUploadServiceLogic serviceLogic = new VedioUploadServiceLogic();

					LoginRespone loginInfo = serviceLogic.LoginManager(filePro.getProperty("groupid"), userNameFld.getText(), passwordFld.getText());

					if (loginInfo == null) {
						return;
					}

					// ログイン情報を保存
					SysInfoBean.setLoginInfo(loginInfo);

					// ログイン画面非表示
					CallMainFrame.loginDialog.hide();
					// メイン画面呼び出す
					callBaseFrm.start(owner);
					callBaseFrm.show(owner, true);

					System.out.println("callBaseFrm.show");

					if (checkFld.isSelected()) {
						filePro.setProperty("owned", "true");
						filePro.setProperty("userid", userNameFld.getText());
						filePro.setProperty("passwd", PasswordUtil.encrypt(passwordFld.getText()));
					} else {
						filePro.setProperty("owned", "false");
						filePro.setProperty("userid", "");
						filePro.setProperty("passwd", "");
					}
					filePro.storeProperty();
				} catch (Exception e) {

					e.getStackTrace();
					String repl ="VedioUploadService.BizException:";
					if (e.getMessage().indexOf(repl)>0) {
						int beginIndex = e.getMessage().indexOf(repl);
						String errMsg = e.getMessage().substring(beginIndex);
						int endIndex = errMsg.indexOf("。");
						errMsg = errMsg.substring(0,endIndex).replaceAll(repl, "");
						Messagebox.Error(errMsg);
					}else {

						Messagebox.Error(e.getMessage());
					}

					logger.log(Level.SEVERE, "例外のスローを捕捉", e);
				}
			}
		});
		gridpane.add(login, 1, 5);
		GridPane.setHalignment(login, HPos.RIGHT);
		loginPane.setCenter(gridpane);
		BorderPane.setAlignment(gridpane, Pos.CENTER);
		root.getChildren().add(loginPane);
	}
}
