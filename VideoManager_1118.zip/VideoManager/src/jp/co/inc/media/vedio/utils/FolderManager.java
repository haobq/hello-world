package jp.co.inc.media.vedio.utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.inc.media.vedio.common.BasConst;
import jp.co.inc.media.vedio.common.MessageConst;

/**
 * 格納フォルダから動画ファイルリスト取得のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class FolderManager implements BasConst{

	// 動画ファイルの拡張子
	private static String extension = EXTENSION;
	// 動画フォルダの管理用JSON
	private static String managerJson = MANAGER_JSON;
	// 検索開始したいフォルダのPath
	private static String workingDir = "";
	// 作業用のJSONファイル名
	private static String workingDirJson ="";

	private static ObjectMapper mapper = new ObjectMapper();

	// テスト用
	public static void main(String[] args) {
		List<JsonListBean> fileInfolist;
		try {
			getWorkingDir();
			fileInfolist = getJsonListBean(jsonFolder);
			for (JsonListBean todo : fileInfolist) {
				List<FileInfoBean> aaa =getJsonInfoBean(jsonFolder+""+todo.fileName);
				System.out.println("result: " + todo.fileName + ", " + todo.status );
				System.out.println("result: " + aaa.toString() );
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * JSONファイル名と格納パスを取得する
	 */
	public static void getWorkingDir() {
        FileProperty filePro;
        try {
            filePro = new FileProperty(proFilePath);
            workingDirJson = filePro.getProperty("WorkingDirJson");
            workingDir = filePro.getProperty("WorkingDir");

    		File fldJson = new File(folderJson);
    		HashMap<String, String> jsonFolderMap = new HashMap<String, String>();
    		List<FolderListBean> folderInfolist = new ArrayList<FolderListBean>();
    		if (!fldJson.exists()) {
    			mapper.writeValue(fldJson, folderInfolist);
    		}else {
    			folderInfolist = Arrays.asList(mapper.readValue(fldJson, FolderListBean[].class));
    			for(FolderListBean folderbean:folderInfolist) {
    				jsonFolderMap.put(folderbean.getFolderPath(), folderbean.getJsonfilePath());
    			}
    		}

    		if (jsonFolderMap.containsKey(workingDir)) {
    			workingDirJson = jsonFolderMap.get(workingDir);
    		}
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	/**
	 * JSONファイルの格納フォルダに保存されたJSONファイルを取得する
	 * @param path JSONファイルの格納フォルダ
	 * @return List JSONファイルリスト
	 */
	public static List<JsonListBean> getJsonListBean(String path) {
		List<JsonListBean> fileList = new ArrayList<JsonListBean>();
		// 格納フォルダ
		File dir = new File(path);
		File files[] = dir.listFiles();

        FileProperty filePro;
        String workingJson ="";
        try {
            filePro = new FileProperty(proFilePath);
            workingJson = filePro.getProperty("WorkingDirJson");
        } catch (Exception e) {
            e.printStackTrace();
        }
		// 動画ファイル情報をBEANリストに格納する
		if (files!= null) {
			for (int i = 0; i < files.length; i++) {
				if (files[i].isFile()) {
					if (files[i].getName().endsWith(".json")) {
						JsonListBean jsonFileBean = new JsonListBean();
						// JSONファイル名
						jsonFileBean.fileName = files[i].getName();

						if (jsonFileBean.fileName.equals(new File(workingJson).getName())) {
							jsonFileBean.setStatus("現在作業用");
						}else {
							jsonFileBean.setStatus("過去履歴");
						}
						fileList.add(jsonFileBean);
					}
				}
			}
		}

		// 動画ファイルリストを返す
		return fileList;
	}

	/**
	 * SYSTEM.INIにJSONファイル名とJSONファイルの格納フォルダを保存する
	 * @param jsonFolderMap
	 * @param path格納フォルダ
	 */
    private static void SaveWorkingDir(HashMap<String, String> jsonFolderMap, String jsonFile,String workingDir) {
        try {
    		FileProperty filePro = new FileProperty(proFilePath);
            filePro.setProperty("WorkingDirJson",jsonFile.replace("\\", ""));
            filePro.setProperty("WorkingDir", workingDir.replace("\\", ""));
    		filePro.storeProperty();

    		List<FolderListBean> folderInfolist = new ArrayList<FolderListBean>();
    		for (String key : jsonFolderMap.keySet()) {
    			if (!"".equals(key)) {
        			FolderListBean folderBean = new FolderListBean();
        			folderBean.setFolderPath(key);
        			folderBean.setJsonfilePath(jsonFolderMap.get(key));
        			folderInfolist.add(folderBean);
    			}
    		}
    		mapper.writeValue(new File(folderJson), folderInfolist);
        } catch (Exception e) {
			e.printStackTrace();
		}
    }

	/**
	 * 指定JSONファイルの情報を取得する。
	 *
	 * @param jsonfilepath JSON格納フォルダ
	 * @return List 動画ファイルリスト
	 * @throws Exception 動画ファイルリスト取得処理異常
	 */
	public static List<FileInfoBean> getJsonInfoBean(String jsonfilepath) throws Exception {
		File jsonfile = new File(jsonfilepath);
		List<FileInfoBean> managerlist = Arrays.asList(mapper.readValue(jsonfile, FileInfoBean[].class));
		return managerlist;

	}

	/**
	 * 指定JSONファイル	に変更する
	 *
	 * @param jsonfilepath　指定JSONファイル
	 * @param fileinfoBean 指定JSONファイル
	 * @throws Exception 動画ファイルリスト取得処理異常
	 */

	public static void saveFileintoBeanToJson(String jsonfilepath,List<FileInfoBean> fileinfoBean) throws Exception {
		FileProperty filePro = new FileProperty(proFilePath);
		workingDirJson =filePro.getProperty("WorkingDirJson");
		File jsonfile = new File(workingDirJson);
		// 保存する。
		try {
			mapper.writeValue(jsonfile, fileinfoBean);
		} catch (IOException e) {
			throw new Exception(MessageConst.E0003);
		}
	}

	/**
	 * 格納フォルダの動画ファイルリストを取得する。
	 *
	 * @param path 格納フォルダ
	 * @return List 動画ファイルリスト
	 * @throws Exception 動画ファイルリスト取得処理異常
	 */
	public static List<FileInfoBean> getFileInfoList(String path) throws Exception {

		// ｆolder.json存在していない場合、作成する
		File fldJson = new File(folderJson);
		HashMap<String, String> jsonFolderMap = new HashMap<String, String>();
		List<FolderListBean> folderInfolist = new ArrayList<FolderListBean>();
		if (!fldJson.exists()) {
			mapper.writeValue(fldJson, folderInfolist);
		}else {
			folderInfolist = Arrays.asList(mapper.readValue(fldJson, FolderListBean[].class));
			for(FolderListBean folderbean:folderInfolist) {
				jsonFolderMap.put(folderbean.getFolderPath(), folderbean.getJsonfilePath());
			}
		}

		List<FileInfoBean> fileInfolist = searchFile(path);
		// 格納フォルダの管理JSONファイル
		LocalDateTime today = LocalDateTime.now();
		DateTimeFormatter dtformat = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		String managerFile = jsonFolder  + dtformat.format(today)+ managerJson;

		if (fileInfolist.size() == 0) {
			if (jsonFolderMap.containsKey(path)) {
				workingDirJson = jsonFolderMap.get(path);

				// 管理JSONファイルを削除する
				File jsonfile = new File(workingDirJson);
				if (jsonfile.exists()) {
					jsonfile.delete();
					jsonFolderMap.remove(path);
					SaveWorkingDir(jsonFolderMap,"","");
				}
			}
			// 動画ファイルが存在していない場合、処理中止させる。
			throw new Exception(MessageConst.E0002);
		}

		if (!jsonFolderMap.containsKey(path)) {
			workingDirJson = managerFile;
		}else {
			workingDirJson = jsonFolderMap.get(path);
		}
		// 格納フォルダの管理JSONチェック
		File jsonfile = new File(workingDirJson);
		if (!jsonfile.exists()) {
			try {
				// 管理JSONファイルが存在していない時、作成する
				jsonfile = new File(workingDirJson);
				mapper.writeValue(jsonfile, fileInfolist);

				jsonFolderMap.put(path,workingDirJson);
				SaveWorkingDir(jsonFolderMap,workingDirJson,path);
			} catch (IOException e) {
				throw new Exception(MessageConst.E0003);
			}
		}

		// 管理JSONファイルの情報を取得する
		List<FileInfoBean> managerlist = Arrays.asList(mapper.readValue(jsonfile, FileInfoBean[].class));
		List<FileInfoBean> filelist = new ArrayList<FileInfoBean>();

		// 管理JSONファイルのリストに実物動画ファイルない時、管理JSONファイルのリストをフィルタする
		for (FileInfoBean managerInfo : managerlist) {
			for (FileInfoBean fileInfo : fileInfolist) {
				if (managerInfo.getFileName().equals(fileInfo.getFileName())) {
					//同じ動画ファイル名のファイル更新時、ステータスを「未」設定する
					if (managerInfo.getFileSize() != fileInfo.getFileSize() || !managerInfo.getUpdateDate().equals(fileInfo.getUpdateDate())) {
						managerInfo.setFileSize(fileInfo.getFileSize());
						managerInfo.setUpdateDate(fileInfo.getUpdateDate());
						managerInfo.setMovie_date(fileInfo.getMovie_date());
						managerInfo.setHosp_id(fileInfo.getHosp_id());
						managerInfo.setPatient_id(fileInfo.getPatient_id());
						managerInfo.setMovie_index(fileInfo.getMovie_index());
						managerInfo.setMovie_send_time(fileInfo.getMovie_send_time());
						managerInfo.setStatus(Status.STATUS_NEW);
					}
					filelist.add(managerInfo);
				}
			}
		}

		// 格納フォルダの管理JSONファイルに動画ファイル情報を更新する
		for (FileInfoBean fileInfo : fileInfolist) {
			boolean bExists = false;
			for (FileInfoBean managerInfo : managerlist) {
				if (managerInfo.getFileName().equals(fileInfo.getFileName())) {
					bExists = true;
					break;
				}
			}
			// 動画ファイルの追加。
			if (bExists == false) {
				filelist.add(fileInfo);
			}
		}

		// 保存する。
		try {
			mapper.writeValue(jsonfile, filelist);
		} catch (IOException e) {
			throw new Exception(MessageConst.E0003);
		}
		return filelist;
	}

	/**
	 * 格納フォルダの動画ファイルリストを取得する。
	 *
	 * @param path格納フォルダ
	 * @return List<FileInfoBean> 動画ファイルリスト
	 */
	private static List<FileInfoBean> searchFile(String path) {
		// 動画ファイルリスト
		List<FileInfoBean> fileList = new ArrayList<FileInfoBean>();
		// 格納フォルダ
		File dir = new File(path);
		File files[] = dir.listFiles();

		// 動画ファイル情報をBEANリストに格納する
		if (files!= null) {
			for (int i = 0; i < files.length; i++) {
				if (files[i].isFile()) {
					if (files[i].getName().endsWith(extension)) {
						FileInfoBean mp4FileBean = new FileInfoBean();
						// 動画ファイル名
						mp4FileBean.setFileName(files[i].getName());
						// 動画ファイルサーズ
						mp4FileBean.setFileSize(files[i].length());
						// 動画ファイル最新更新日時
						SimpleDateFormat sdf = new SimpleDateFormat(DATE_TYPE_YYYY_MM_DD_HH_MM);
						Long lastModified = files[i].lastModified();
						mp4FileBean.setUpdateDate(sdf.format(lastModified));
						// 動画ファイルのローカルパス
						mp4FileBean.setFilePath(files[i].getAbsolutePath());
						fileList.add(mp4FileBean);
					}
				}
			}
		}

		// 動画ファイルリストを返す
		return fileList;
	}


}
