package jp.co.inc.media.vedio.logic;

import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.namespace.QName;

import javafx.scene.control.ChoiceDialog;
import jp.co.inc.media.vedio.common.BasConst;
import jp.co.inc.media.vedio.common.MessageConst;
import jp.co.inc.media.vedio.frame.CallMainFrame;
import jp.co.inc.media.vedio.service.ArrayOfClinicReponse;
import jp.co.inc.media.vedio.service.ArrayOfFacilityReponse;
import jp.co.inc.media.vedio.service.ClinicReponse;
import jp.co.inc.media.vedio.service.FacilityReponse;
import jp.co.inc.media.vedio.service.LoginRespone;
import jp.co.inc.media.vedio.service.VedioUploadService;
import jp.co.inc.media.vedio.service.VedioUploadServiceSoap;
import jp.co.inc.media.vedio.utils.Messagebox;

public class VedioUploadServiceLogic extends VedioUploadService implements BasConst, MessageConst {
	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(VedioUploadServiceLogic.class.getName());
	private static LoginRespone loginReponse = null;

	private static String hosp_id = null;


	/**
	 * @return hosp_id
	 */
	public static String getHosp_id() {
		return hosp_id;
	}

	/**
	 * @param hosp_id セットする hosp_id
	 */
	public static void setHosp_id(String hosp_id) {
		VedioUploadServiceLogic.hosp_id = hosp_id;
	}

	/**
	 * @return loginReponse
	 */
	public static LoginRespone getLoginReponse() {
		return loginReponse;
	}

	/**
	 * @param loginReponse セットする loginReponse
	 */
	public void setLoginReponse(LoginRespone loginReponse) {
		VedioUploadServiceLogic.loginReponse = loginReponse;
	}

	private static final QName SERVICE_NAME = new QName("http://vedio.media.inc.co.jp/service", "VedioUploadService");
	private static VedioUploadServiceSoap port;

	public VedioUploadServiceLogic() {
		URL wsdlURL = VedioUploadService.WSDL_LOCATION;
		VedioUploadService ss = new VedioUploadService(wsdlURL, SERVICE_NAME);
		port = ss.getVedioUploadServiceSoap12();
	}

	public LoginRespone LoginManager(String groupId, String userId, String paasword) {


		try {

			setLoginReponse(port.login(groupId, userId, paasword, ""));

			String hosp_id = loginReponse.getCert().getHospId();
			ArrayOfClinicReponse clinicReponse = loginReponse.getClinicList();

			if ("".equals(hosp_id) && !clinicReponse.getClinicReponse().isEmpty()) {

				// ログイン画面非表示
				CallMainFrame.loginDialog.hide();

				//医院を選択
				ArrayList<String> list = new ArrayList<String>();
				for (ClinicReponse clinic : clinicReponse.getClinicReponse()) {
					list.add(clinic.getHospName());
				}
				ChoiceDialog<String> choice = new ChoiceDialog<String>(list.get(0), list);
				choice.setTitle("医院選択");
				choice.setHeaderText("下記の医院を選択してください。");
				choice.setContentText("医院名");

				String hosp_name = choice.showAndWait().orElse("");
				if (!"".equals(hosp_name)) {
					for (ClinicReponse clinic : clinicReponse.getClinicReponse()) {
						if (hosp_name.equals(clinic.getHospName())) {
							hosp_id = clinic.getHospId();
							break;
						}
					}

				} else {
					// ログイン画面表示
					CallMainFrame.loginDialog.show();
					return  null;
				}

			}
			loginReponse = port.login(groupId, userId, paasword, hosp_id);
			System.out.println("==============認証情報==========");
			System.out.println("GroupId:" + loginReponse.getCert().getGroupId());
			System.out.println("HospId:" + loginReponse.getCert().getHospId());
			System.out.println("UserId:" + loginReponse.getCert().getUserId());
			System.out.println("MediaAuth:" + loginReponse.getCert().getMediaAuth());
			ArrayOfClinicReponse clinic = loginReponse.getClinicList();
			System.out.println("==============医院情報==========");
			for (ClinicReponse tmp : clinic.getClinicReponse()) {
				System.out.println("HospId:" + tmp.getHospId());
				System.out.println("HospName:" + tmp.getHospName());
			}
			ArrayOfFacilityReponse faci = loginReponse.getFacilityList();
			System.out.println("==============施設情報==========");
			for (FacilityReponse tmp : faci.getFacilityReponse()) {
				System.out.println("VisitId:" + tmp.getVisitId());
				System.out.println("VisitName：" + tmp.getVisitName());
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			String repl ="VedioUploadService.BizException:";
			if (e.getMessage().indexOf(repl)>0) {
				int beginIndex = e.getMessage().indexOf(repl);
				String errMsg = e.getMessage().substring(beginIndex);
				int endIndex = errMsg.indexOf("。");
				errMsg = errMsg.substring(0,endIndex).replaceAll(repl, "");
				System.out.println("errMsg:"+errMsg);

				// 文字置き換え
				if(e.toString().indexOf(FAILED_TO_CREATE_SERVICE)> 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE)> 0
						) {
					Messagebox.Error(ServiceConstructionException);

				} else {

					Messagebox.Error(errMsg);
				}
				// ログイン画面表示
				CallMainFrame.loginDialog.show();
				return  null;
			}else {
				System.out.println("異常:" + e.getMessage());

				// 文字置き換え
				if(e.toString().indexOf(FAILED_TO_CREATE_SERVICE)> 0
						|| e.toString().indexOf(COULD_NOT_SEND_MESSAGE)> 0
						) {
					Messagebox.Error(ServiceConstructionException);

				} else {

					Messagebox.Error(e.getMessage());
				}

				// ログイン画面表示
				CallMainFrame.loginDialog.show();

				return  null;
			}
		}
		return loginReponse;
	}
}
