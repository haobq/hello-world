/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0  2020/09/01
 */

package jp.co.inc.media.vedio.common;

/**
 * クラス名：システムメッセージクラス.
 *
 */
public interface MessageConst {
    public final static String V0001 = "動画管理システム   \nﾊﾞｰｼﾞｮﾝ 1.0.0    2020/09/01\nメディア株式会社";
    public final static String E0000 = "システムは二重起動できない。";
    public final static String E0001 = "システムエラーが発生しました。\nサポートセンターまでご連絡下さい。";
    public final static String E0002 = "動画格納していない,別のフォルダを選択してください。";
    public final static String E0003 = "動画ファイル格納フォルダの管理JSON作成できません。";
    public final static String E0004 = "動画ファイル格納フォルダを選択してください。";
    public final static String E0005 = "患者を選択してください。";
    public final static String E0006 = "訪問日日付が正しくありません。";
    public final static String E0007 = "動画ファイル格納フォルダを選択してください。";
    public final static String E0008 = "正しいプロキシURLを入力してください。";
    public final static String E0009 = "正しいログインURLを入力してください。";
    public final static String E0010 = "ポートは数字を入力してください。";
    public final static String E0011 = "プロキシURLを入力してください。";
    public final static String E0012 = "プロキシポートを入力してください。";
    public final static String E0013 = "ユーザー名を入力してください。";
    public final static String E0014 = "パスワードを入力してください。";
    public final static String E0015 = "作業フォルダ名を入力してください。";
    public final static String E0016 = "正しいログファイル名を入力してください。";
    public final static String E0017 = "二重起動エラー。";
    public final static String E0018 = "動画アップロード失敗。";
    public final static String UserIdOrPassword = "ユーザID／パスワードが不正です。";
    public final static String HospError = "医院データが取得できません。";
    public final static String FacilityError = "施設データが取得できません。";
    public final static String Authentication = "有効な認証データが既にあります。";
    public final static String ServerError = "サーバ側で何らかのエラーが発生した。";
    public final static String GroudIdError = "グループIDが不正です。";
    public final static String Unauthorized = "認証キーが不正";
    public final static String ServiceConstructionException = "サーバに接続できません。";

    public final static String I0001 = "動画ファイルをアップロードします。よろしいですか。";
    public final static String I0002 = "アップロードされた動画ファイルを削除します。よろしいですか。";
    public final static String I0003 = "動画ファイルを選択してください。";
    public final static String I0004 = "完了";
    public final static String I0005 = "備考欄の入力文字が最大制限(200)を超えています。";
    public final static String I0006 = "既に送信済みです。";

}
