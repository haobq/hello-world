﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// メモ: [リファクター] メニューの [名前の変更] コマンドを使用すると、コード、svc、および config ファイルで同時にクラス名 "Service" を変更できます。
public class Service : IService
{
	/// <summary>
	/// 　mp4アップロード処理
	/// </summary>
	/// <param name="media"></param>
	/// <param name="mediaName"></param>
	/// <param name="fileCount"></param>
	/// <param name="hospId"></param>
	/// <param name="patientId"></param>
	/// <returns></returns>
	public string MediaUpload(byte[] media, string mediaName, int fileCount, string hospId, string patientId)
	{
		// クライアントへ返却文字
		// 同じファイルを二回アップロードした場合
		const  String  fileExist = "fileAlreadyExist";
		// ファイルアップロード成功の場合
		const String fileUploadSuccess = "fileUploadSuccess";

		// TODO サーバのmp4ファイル格納フォルダ
		const String basePath = @"C:\inetpub\mp4up";
		// TODO 拡張子　　.png ⇒ .mp4
		const String mp4 = ".mp4";

        //const string sql_template = "select * from tbl_data_set_flg where msg_uid='{0}'";

        try
        {
			//if (!CheckUser(hospId, ipAddress)) return false;        // 認証確認

			//string sql = string.Format(sql_template, msgUid);
			//App_Function fnc = new App_Function();
			//string path = fnc.sqlSelect(sql, "file_path");


			// 病院ID　＋　患者ID
			String kannjyaIdDrect = basePath + @"\" + hospId + @"\" + patientId;
			//　ディレクトリ作成
			if (!Directory.Exists(kannjyaIdDrect))
			{
				Directory.CreateDirectory(kannjyaIdDrect);
			}

			// 患者ID　＋　メディア名称
			String mediaPath = kannjyaIdDrect + @"\" + Path.GetFileNameWithoutExtension(mediaName);

			// zip動画をローカルに保存
			String mediaParhZip = mediaPath + ".zip";


			// 解凍したファイルフォルダ
			String unZipFileFold = kannjyaIdDrect + @"\" + Path.GetFileNameWithoutExtension(mediaName);

			// 移動先解凍したファイル
			String moveUnZipFile = kannjyaIdDrect + @"\" + mediaName;

			// 結合したmp4ファイル
			string file_name = mediaPath + mp4;

			//既にmp4ファイルアップされた場合エラーを返却
			if (File.Exists(moveUnZipFile) || File.Exists(file_name))
			{
				return fileExist;
			}
			else
			{
				util.ByteArrayToFile(media, mediaParhZip);
				//ファイル解凍
				System.IO.Compression.ZipFile.ExtractToDirectory(mediaParhZip, mediaPath);

			}

			// DirectoryInfoのインスタンスを生成する
			DirectoryInfo d = new DirectoryInfo(unZipFileFold);

			// ディレクトリ直下のすべてのファイル一覧を取得する
			FileInfo[] fiAlls = d.GetFiles();

            int uploadFilesCount = fiAlls.Length;


            // -------------結合処理
			// 分割したファイルの総合＝＝クライアントで送信したファイル総数
            if (fileCount == uploadFilesCount)
            {
				// 分割サイズ
				//private const int DIV_BYTE = 1024 * 1024 * 1024;
				const int DIV_BYTE = 1024 * 3;
				// 読込バッファサイズ
				const int READ_BYTE = DIV_BYTE / 10;

				// 分割ファイルをリストアップ
				List<string> divFiles = new List<string>();

				// ディレクトリ直下のすべてのファイル一覧を取得する
				foreach (FileInfo f in fiAlls)
				{
					divFiles.Add(f.FullName);
				}

				// 結合先ファイルを開く
				using (FileStream wf = new FileStream(file_name, FileMode.Create, FileAccess.Write))
				{
					int readByte = 0;
					long leftByte = 0;
					byte[] readBuf = new byte[READ_BYTE];
					foreach (string divFile in divFiles)
					{
						// 分割ファイルを開く
						using (FileStream rf = new FileStream(divFile, FileMode.Open, FileAccess.Read))
						{
							leftByte = rf.Length;
							while (leftByte > 0)
							{
								// 分割ファイルから読み込む
								readByte = rf.Read(readBuf, 0, (int)Math.Min(READ_BYTE, leftByte));
								// 結合先ファイルに書きこむ
								wf.Write(readBuf, 0, readByte);
								// 読込情報の設定
								leftByte -= readByte;
							}
						}
					}
				}

				// ディレクトリ直下のすべてのファイルを削除
				foreach (FileInfo f in fiAlls)
				{
					f.Delete();
				}

				// フォルダを削除
				Directory.Delete(unZipFileFold);
			}
		}
		catch (Exception ex)
        {
			//LogGW(hospId, err, "例外発生：GetFile() {0}", ex.ToString());
			return ex.ToString();
		}

		return fileUploadSuccess;
	}

	public string GetData(int value)
	{
		return string.Format("You entered: {0}", value);
	}

	public CompositeType GetDataUsingDataContract(CompositeType composite)
	{
		if (composite == null)
		{
			throw new ArgumentNullException("composite");
		}
		if (composite.BoolValue)
		{
			composite.StringValue += "Suffix";
		}
		return composite;
	}




}
