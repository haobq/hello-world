package jp.co.inc.media.video.components;

import java.awt.Robot;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import javax.xml.ws.WebServiceException;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Callback;
import jp.co.inc.media.video.common.BasButton;
import jp.co.inc.media.video.common.BasDialog;
import jp.co.inc.media.video.common.BasFrame;
import jp.co.inc.media.video.frame.CallMainFrame;
import jp.co.inc.media.video.logic.VideoUploadServiceLogic;
import jp.co.inc.media.video.service.ArrayOfClinic;
import jp.co.inc.media.video.service.Clinic;
import jp.co.inc.media.video.service.ErrorResponse;
import jp.co.inc.media.video.service.Facility;
import jp.co.inc.media.video.service.LoginRespone;
import jp.co.inc.media.video.utils.Messagebox;

/**
 * 概要：医院センタ画面のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class HospitalSelect extends BasDialog {

	// 医院リスト
	private ComboBox<String> combo;
	// OK ボタン
	private static BasButton btnOK;

	/**
	 * 医院選択
	 * @param callBaseFrm BasFrame
	 * @param owner Stage
	 * @param title Title
	 * @param clinicReponse ArrayOfClinic
	 * @param groupId グループID
	 * @param userId ユーザID
	 * @param paasword パスワード
	 * @param width 幅
	 * @param height 高
	 */
	public HospitalSelect(BasFrame callBaseFrm, Stage owner, String title, ArrayOfClinic clinicReponse,
			String groupId, String userId, String paasword, int width, int height) {
		super(owner, title, width, height);

		initStyle(StageStyle.UTILITY);

		BorderPane hospitalPane = new BorderPane();
		hospitalPane.setPrefWidth(width);
		hospitalPane.setPrefHeight(height);
		GridPane gridpane = new GridPane();
		gridpane.setPadding(new Insets(15));
		gridpane.setHgap(5);
		gridpane.setVgap(5);

		// 医院
		final Label labelHospital = new Label();
		labelHospital.setText(LABVEL_HOSPITAL);
		//labelHospital.setStyle(LBL_STYLE);
		labelHospital.setAlignment(Pos.CENTER_LEFT);
		labelHospital.setMinWidth(60);
		labelHospital.setMaxWidth(60);

		// 医院リスト
		combo = new ComboBox<>();
		//	combo.setStyle(COMBOLIST_STYLE);
		combo.setPromptText(I0009);


		//医院を選択
		ArrayList<String> list = new ArrayList<String>();
		for (Clinic clinic : clinicReponse.getClinic()) {
			list.add(clinic.getHospName());
		}

		for (String hospital : list) {
			System.out.println("hospital:" + hospital);
			combo.getItems().add(hospital);
		}

		combo.setCellFactory(new Callback<ListView<String>, ListCell<String>>() {
			@Override
			public ListCell<String> call(final ListView<String> list) {
				return new ListCell<String>() {

					@Override
					protected void updateItem(String item, boolean empty) {
						super.updateItem(item, empty);

						try {
							if (empty || item == null) {
								setText(null);
							} else {
								setText(item.toUpperCase());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}


					}

					{
						Text text = new Text();
						setGraphic(text);
					}
				};
			}
		});
		combo.getStyleClass().add("textfield");

		HBox hList = new HBox();
		hList.getChildren().addAll(labelHospital, combo);

		btnOK = new BasButton("config.png", ICON_SIZE, ICON_SIZE, "確認");
		btnOK.setStyle(BUTTON_STYLE);
		btnOK.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				conform(callBaseFrm, owner, combo, clinicReponse, groupId, userId, paasword);
			}
		});

		combo.setOnKeyPressed((event) -> {
			try {
				Robot eventRobot = new Robot();
				if (event.getCode().getName() == "Enter") {
					//エンター押下時
					eventRobot.keyPress(java.awt.event.KeyEvent.VK_TAB);
					eventRobot.keyRelease(java.awt.event.KeyEvent.VK_TAB);
					event.consume();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		btnOK.setOnKeyPressed((event) -> {
			try {
				if (event.getCode().getName() == "Enter") {
					conform(callBaseFrm, owner, combo, clinicReponse, groupId, userId, paasword);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		});

		HBox hButton = new HBox();
		hButton.getChildren().add(btnOK);
		hButton.setAlignment(Pos.BASELINE_RIGHT);

		gridpane.add(hList, 0, 1);
		gridpane.add(new Label(), 0, 2);
		gridpane.add(new Label(), 0, 3);
		gridpane.add(hButton, 0, 4);

		hospitalPane.setCenter(gridpane);
		BorderPane.setAlignment(hospitalPane, Pos.CENTER);
		root.getChildren().add(hospitalPane);

	}

	/**
	 * 確認
	 * @param callBaseFrm BasFrame
	 * @param owner Stage
	 * @param combo ComboBox
	 * @param clinicReponse ArrayOfClinic
	 * @param groupId グループID
	 * @param userId ユーザID
	 * @param paasword パスワード
	 */
	public static void conform(BasFrame callBaseFrm, Stage owner, ComboBox<String> combo, ArrayOfClinic clinicReponse,
			String groupId, String userId, String paasword) {
		logger.log(Level.INFO, "START -conform");
		// 必須チェック
		if (combo.getValue() == null) {
			Messagebox.Error(owner, E0011);
			return;
		}

		try {
			if (!"".equals(combo.getValue()) && combo.getValue() != null) {
				for (Clinic clinic : clinicReponse.getClinic()) {
					if (combo.getValue().equals(clinic.getHospName())) {

						VideoUploadServiceLogic.setHosp_id(clinic.getHospId());
						// ログレスポンス設定

						System.out.println("Invoking login...");
						LoginRespone login = VideoUploadServiceLogic.getPort().login(groupId,
								userId, paasword, VideoUploadServiceLogic.getHosp_id(), SESSION_FLG);
						if (!SUCCESS.equals(login.getError().getErrorCode())) {
							ErrorResponse err =  login.getError();
							logger.log(Level.SEVERE, err.getErrorMessage(), err.getErrorDetail());
							Messagebox.Error(BasFrame.mainStage, err.getErrorCode(),err.getErrorMessage());
							return;
						}

						VideoUploadServiceLogic.setLoginReponse(login);

						List<Facility> faci = VideoUploadServiceLogic.getLoginReponse().getFacilityList()
								.getFacility();

						if (faci.size() == 0) {
							Messagebox.Error(owner, "E0016",E0016);
							return;
						}

						// 画面非表示
						VideoUploadServiceLogic.hospitalSelect.hide();

						// ログイン画面非表示
						CallMainFrame.loginDialog.hide();
						// メイン画面呼び出す
						callBaseFrm.start(owner);
						System.out.println("callBaseFrm.show");
					}
				}
			}

		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021",E0021);
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021",E0021);
		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0021",E0021);
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Messagebox.Error(owner, "E0025",E0025);
		}

		logger.log(Level.INFO, "END -conform");
	}

}
