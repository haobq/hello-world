package jp.co.inc.media.video.logic;

import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.ws.WebServiceException;

import org.apache.commons.io.FilenameUtils;

import javafx.application.Platform;
import javafx.concurrent.Task;
import jp.co.inc.media.video.common.BasConst;
import jp.co.inc.media.video.common.BasFrame;
import jp.co.inc.media.video.common.MessageConst;
import jp.co.inc.media.video.service.ErrorResponse;
import jp.co.inc.media.video.service.LoginRespone;
import jp.co.inc.media.video.service.MovieRequest;
import jp.co.inc.media.video.service.VideoUploadService;
import jp.co.inc.media.video.utils.FileInfoBean;
import jp.co.inc.media.video.utils.Messagebox;
import jp.co.inc.media.video.utils.Surveillance;
import jp.co.inc.media.video.utils.ToolsUtils;

/**
 * 概要：ファイルアップロード処理のクラスです。
 *
 * @version 1.0.0
 * @author HaoBuqian
 */
public class UpLoadFile extends Task<String> implements BasConst, MessageConst {

	// Loggerクラスのインスタンスを生成
	static Logger logger = Logger.getLogger(UpLoadFile.class.getName());

	// 最大番号
	static int MaxVideo_no = 0;

	public static Surveillance surveillance= new Surveillance(BasFrame.mainStage);
	/**
	 * ファイル削除
	 * @param file ファイル削除
	 * @throws IOException ファイル読み異常
	 */
	public static void delete(File file)
			throws IOException {

		if (file.isDirectory()) {
			//directory is empty, then delete it
			if (file.list().length == 0) {
				file.delete();
			} else {
				//list all the directory contents
				String files[] = file.list();
				for (String temp : files) {
					//construct the file structure
					File fileDelete = new File(file, temp);
					//recursive delete
					delete(fileDelete);
				}
				//check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();
				}
			}
		} else {
			//if file, then delete it
			file.delete();
		}
	}

	/**
	 * フォルダを削除
	 * @param folder フォルダ
	 * @throws IOException  ファイル読み異常
	 */
	public static void deletefolder(String folder)
			throws IOException {
		File directory = new File(folder);
		//make sure directory exists
		if (!directory.exists()) {
		} else {
			try {
				delete(directory);
			} catch (IOException e) {
				e.printStackTrace();
				logger.log(Level.SEVERE, THROW_INFO, e);
				Messagebox.Error(BasFrame.mainStage, "E0001",E0001);
			}
		}
	}

	/**
	 * 送信処理
	 */
	@Override
	protected String call() throws Exception {

		// フォルダを削除
		deletefolder(mp4Path);

		System.out.println("送信開始時間：" + System.currentTimeMillis());
		double start = System.currentTimeMillis();

		try {

			LoginRespone loginReponse = VideoUploadServiceLogic.getLoginReponse();

			boolean result = false;
			for (FileInfoBean file : BasFrame.fileInfolist) {

				if (file.getFileName().equals(BasFrame.sysInfoBean.getSelectedFileName())) {

					if (file.getFileName().toUpperCase().endsWith(EXTENSION_MP4.toUpperCase())
							|| file.getFileName().toUpperCase().endsWith(EXTENSION_MOV.toUpperCase())) {
						// --------------動画--------------

//						if (file.getFileName().toUpperCase().endsWith(EXTENSION_MP4.toUpperCase())){
//							BasFrame.CaptureImage(((MediaView) paneSub1.getChildren().get(0)), file.getFileName());
//						}
//
						result = uploadMovie(loginReponse, file);

						if(result) {
							// --------------静止画------------

							String fileName = FilenameUtils.removeExtension(file.getFileName())+ EXTENSION_PNG;
							String filePath = imgPath + PANE_IMAGE_NAME1;
							result = uploadImage(loginReponse, file, fileName,filePath,  "0");
						}

					} else {
						// --------------静止画------------
						result = uploadImage(loginReponse, file,file.getFileName(), file.getFilePath(), "1");
					}

					if(result) {
						// 現在日時情報で初期化されたインスタンスの生成
						Date dateObj = new Date();
						SimpleDateFormat format = new SimpleDateFormat(DATE_TYPE_YYYY_MM_DD_HH_MM);

						// 送信時間
						file.setMovie_send_time(format.format(dateObj));

						// 完に更新
						file.setStatus(Status.STATUS_COMPLETED);

						BasFrame.labelPetcent.setVisible(false);
						// アップロード完了！
						updateMessage(I0004);
						// 待機
						TimeUnit.SECONDS.sleep(1);

						BasFrame.hBoxPrpgress.setVisible(false);

						System.out.println("送信終了時間：" + System.currentTimeMillis());
						double end = System.currentTimeMillis();
						System.out.println("送信時間：" + ToolsUtils.calculateTime((long)(end - start) / 1000)+ "s");

					}
				}
			}

			// フォルダを削除
			deletefolder(mp4Path);
			deletefolder(imgPath);
			BasFrame.hBoxPrpgress.setVisible(false);

		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);

			e.getStackTrace();
			Messagebox.Error(BasFrame.mainStage, "E0001",E0001);
			return null;
		}
		return "Done";
	}

	/**
	 * 動画送信処理
	 * @param loginReponse LoginRespone
	 * @param file FileInfoBean
	 * @param renBan 連番
	 * @return true:(送信成功),false:(送信失敗)
	 * @throws Exception 例外
	 */
	protected boolean uploadMovie(LoginRespone loginReponse, FileInfoBean file) throws Exception {
		logger.log(Level.INFO, "START -uploadMovie");
		surveillance.CheckCurrTime("START -uploadMovie");

		boolean ret = false;
		File dir;

		// ファイル拡張子取得
		String fileExtension = "." + FilenameUtils.getExtension(file.getFileName());
		// ファイルコピー
		// 病院ID + _ + 患者ID + _ + カレンダー日付 + _ + 連番
		String strUploadFileName = BasFrame.patientInfo.getHospitalId() + "_"
				+ BasFrame.patientInfo.getPatientId() + "_"
				+ file.getLastUpdateDate().replace("/", "").substring(0,8)
				+ fileExtension;

		// フォルダを作成
		if (!Files.exists(Paths.get(tmpPath))) {
			Files.createDirectory(Paths.get(tmpPath));
		}
		if (!Files.exists(Paths.get(mp4Path))) {
			Files.createDirectory(Paths.get(mp4Path));
		}
		// アップロードファイル
		final Path uploadFilePath = Paths.get(mp4Path + strUploadFileName);
		// 元ファイル
		final Path sourcePath = Paths.get(file.getFilePath());

		try {
			Files.copy(sourcePath, uploadFilePath);
			System.out.println("コピーが成功しました");
		} catch (IOException e) {
			e.printStackTrace();
			logger.log(Level.SEVERE, THROW_INFO, e);
			Messagebox.Error(BasFrame.mainStage, "E0026",E0026);
		}

		// ファイル分割
		final FileSplit fileSplit = new FileSplit();
		try {
			fileSplit.split((mp4Path + strUploadFileName), mp4Path, loginReponse.getVideoSplitSize());
		} catch (Exception e) {
			e.printStackTrace();
			logger.log(Level.SEVERE, THROW_INFO, e);
			Messagebox.Error(BasFrame.mainStage, "E0026",E0026);
		}

		// 元ファイル削除
		dir = uploadFilePath.toFile();
		dir.delete();

		// 圧縮」、送信、削除　処理開始
		dir = Paths.get(mp4Path).toFile();
		final File files[] = dir.listFiles();
		int fileCount = 0;
		fileCount = files.length;
		// ファイルソード
		java.util.Arrays.sort(files, new java.util.Comparator<File>() {
			public int compare(File file1, File file2) {
				return file1.getName().compareTo(file2.getName());
			}
		});

		// ファイルサイズ
		long fileSize = 0;
		int intSplitNo = 0;
		String stimestamp = "";
		jp.co.inc.media.video.service.MovieResponse _mediaUpload_result = new jp.co.inc.media.video.service.MovieResponse();
		for (File f : files) {
			intSplitNo++;

			String zipFilePath = FilenameUtils.removeExtension(f.getPath())
					+ FilenameUtils.getExtension(f.getName());
			String zipFile = zipFilePath + "/" + FilenameUtils.removeExtension(f.getName())
			+ FilenameUtils.getExtension(f.getName()) + EXTENSION_ZIP;

			File newfile = new File(zipFilePath);

			if (newfile.mkdir()) {

				// 圧縮 .zip
				fileSplit.archive(f.getPath(), zipFile);

				fileSize = fileSize + f.length();

				// 進捗バーの更新
				updateProgress(intSplitNo * 100 / fileCount, 100);
				// 進捗バー表示
				BasFrame.hBoxPrpgress.setVisible(true);
				BasFrame.labelPetcent.setVisible(true);

				// 進捗メッセージの更新
				updateMessage(String.format("進捗：%d", intSplitNo * 100 / fileCount));
				// 待機
				//TimeUnit.SECONDS.sleep(1);

				URL wsdlURL = VideoUploadService.WSDL_LOCATION;
				System.out.println("URL:" + wsdlURL);

				// zipファイルをByte[]に変換
				byte[] media = ZipCompressUtils.readBytesFromFile(zipFile);

				MovieRequest req = new MovieRequest();
				System.out.println("req:");

				req.setCertification(loginReponse.getCert());
				req.setPatientId(BasFrame.patientInfo.getPatientId());
				req.setMovieName(strUploadFileName);
				req.setMovieSize(file.getFileSize());
				req.setMovieDate(BasFrame.datePicker.getValue().toString());
				req.setSpriteFileNo(intSplitNo);
				req.setRemarks(file.getBikou());
				req.setFileCount(fileCount);
				req.setMovieContext(media);
				if (intSplitNo == 1) {

			        Date date = new Date();
			        SimpleDateFormat sdf = new SimpleDateFormat(DATE_TYPE_YYYY_MM_DD_HH_MM);
			        stimestamp = sdf.format(date);
					System.out.println("timestamp:" + stimestamp);

			        stimestamp = stimestamp.replace("/", "").replace(" ", "").replace(":", "") + date.getTime();
				}
				req.setMillisecond(stimestamp);
				if (file.getBunrui() == null) {
					req.setVideoTag("");
				} else {
					req.setVideoTag(file.getBunrui());
				}

				if (file.getTitle() == null) {
					req.setTitle("");
				} else {
					req.setTitle(file.getTitle());
				}

				try {
					System.out.println("mediaUpload start:");

					jp.co.inc.media.video.service.MovieResponse _mediaUpload__return = VideoUploadServiceLogic.getPort()
							.mediaUploadMovi(req);
					System.out.println("mediaUpload.result=" + _mediaUpload__return.getError().getErrorCode());
					System.out.println("mediaUpload end:");
					ret = true;
					if (!SUCCESS.equals(_mediaUpload__return.getError().getErrorCode())){
						Platform.runLater(
								() -> {
									ErrorResponse err =  _mediaUpload__return.getError();
									logger.log(Level.SEVERE, err.getErrorMessage(), err.getErrorDetail());
									Messagebox.Error(BasFrame.mainStage, err.getErrorCode(),err.getErrorMessage());
								});
						ret = false;
						break;
					}

					_mediaUpload_result = _mediaUpload__return;

				} catch (WebServiceException e) {
					logger.log(Level.SEVERE, THROW_INFO, e);
					e.printStackTrace();
					//Platform.runLater(
					//		() -> {
					//			Messagebox.Error(BasFrame.mainStage, "E0021",E0021, ToolsUtils.toString(e));
					//		});
				} catch (ConnectException e) {
					logger.log(Level.SEVERE, THROW_INFO, e);
					e.printStackTrace();
					Platform.runLater(
							() -> {
								Messagebox.Error(BasFrame.mainStage, "E0021",E0021);
							});

				} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
					logger.log(Level.SEVERE, THROW_INFO, e);
					e.printStackTrace();
					//Platform.runLater(
					//		() -> {
					//			Messagebox.Error(BasFrame.mainStage, "E0021",E0021, ToolsUtils.toString(e));
					//		});
				} catch (Exception e) {
					logger.log(Level.SEVERE, THROW_INFO, e);
					e.printStackTrace();
					Platform.runLater(
							() -> {
								Messagebox.Error(BasFrame.mainStage, "E0026",E0026);
							});
				}
			}
		}

		// 病院ID + _ + 患者ID + _ + カレンダー日付 + _ + 連番
		strUploadFileName = BasFrame.patientInfo.getHospitalId() + "_"
				+ BasFrame.patientInfo.getPatientId() + "_"
				+ file.getLastUpdateDate().replace("/", "").substring(0,8) + "_" + String.format("%4s", String.valueOf(_mediaUpload_result.getVideoNo())).replace(" ", "0")
				+ fileExtension;
		//連番
		file.setMovie_index(_mediaUpload_result.getVideoNo());
		// アップロードファイル名
		file.setUploadFileName(strUploadFileName);
		logger.log(Level.INFO, "END -uploadMovie");
		return ret;
	}

	/**
	 * 静止画送信処理
	 * @param loginReponse loginReponse
	 * @param file 送信画像ファイル
	 * @param fileName 送信画像名称
	 * @param filePath 送信画像ファイルパス
	 * @param movieImage 0:動画ファイル送信の場合、画像も送信処理、1:画像を送信処理
	 * @return true:(送信成功),false:(送信失敗)
	 * @throws Exception 例外
	 */
	protected boolean uploadImage(LoginRespone loginReponse, FileInfoBean file, String fileName, String filePath,
			String movieImage) throws Exception {
		logger.log(Level.INFO, "START -uploadImage");
		surveillance.CheckCurrTime("START -uploadImage");

		boolean ret = false;
		File dir;

		// --------------静止画------------

		// ファイルコピー

		if ("1".equals(movieImage)) {

			// アップロードファイル名
			file.setUploadFileName(file.getFileName());

			// フォルダを作成
			if (!Files.exists(Paths.get(tmpPath))) {
				Files.createDirectory(Paths.get(tmpPath));
			}
			if (!Files.exists(Paths.get(imgPath))) {
				Files.createDirectory(Paths.get(imgPath));
			}
			// アップロードファイル
			final Path uploadFilePath = Paths.get(imgPath + fileName);
			// 元ファイル
			final Path sourcePath = Paths.get(filePath);

			try {
				Files.copy(sourcePath, uploadFilePath);
				System.out.println("コピーが成功しました");
			} catch (IOException e) {
				e.printStackTrace();
				logger.log(Level.SEVERE, THROW_INFO, e);
				Messagebox.Error(BasFrame.mainStage, "E0027",E0027);
			}

			// 元ファイル削除
			dir = uploadFilePath.toFile();
			dir.delete();

		}

		// 送信、削除　処理開始

		// 進捗バー表示
		BasFrame.hBoxPrpgress.setVisible(true);
		BasFrame.labelPetcent.setVisible(true);

		for (int i = 1; i <= 10; i++) {
			updateProgress(i * 100 / 10, 100);
			//TimeUnit.SECONDS.sleep(1);
			updateMessage(String.format("進捗：%d", i * 100 / 10));
		}

		URL wsdlURL = VideoUploadService.WSDL_LOCATION;
		System.out.println("URL:" + wsdlURL);

		byte[] imageByte = ZipCompressUtils.readBytesFromFile(filePath);

		MovieRequest req = new MovieRequest();
		System.out.println("req:");

		req.setCertification(loginReponse.getCert());
		req.setPatientId(BasFrame.patientInfo.getPatientId());
		req.setMovieName(fileName);
		req.setMovieIndex(0);
		req.setMovieSize(file.getFileSize());
		req.setMovieDate(file.getLastUpdateDate());
		req.setSpriteFileNo(0);
		req.setRemarks(file.getBikou());
		req.setFileCount(1);
		req.setMovieContext(imageByte);
		if (file.getBunrui() == null) {
			req.setVideoTag("");
		} else {
			req.setVideoTag(file.getBunrui());
		}

		if (file.getTitle() == null) {
			req.setTitle("");
		} else {
			req.setTitle(file.getTitle());
		}

		try {
			System.out.println("uploadImage start:");
			jp.co.inc.media.video.service.MovieResponse  _mediaUpload__return = VideoUploadServiceLogic
					.getPort().mediaUploadImg(req);

			System.out.println("mediaUpload.result=" + _mediaUpload__return.getError().getErrorCode());

			System.out.println("uploadImage end:");

			ret = true;
			if (!SUCCESS.equals(_mediaUpload__return.getError().getErrorCode())){
				Platform.runLater(
						() -> {
							ErrorResponse err =  _mediaUpload__return.getError();
							logger.log(Level.SEVERE, err.getErrorMessage(), err.getErrorDetail());
							Messagebox.Error(BasFrame.mainStage, err.getErrorCode(),err.getErrorMessage());
						});
				ret = false;
			}

			// イメージNoを設定
			file.setImage_no(_mediaUpload__return.getImageNo());



		} catch (WebServiceException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Platform.runLater(
					() -> {
						Messagebox.Error(BasFrame.mainStage, "E0021",E0021);
					});
		} catch (ConnectException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Platform.runLater(
					() -> {
						Messagebox.Error(BasFrame.mainStage, "E0021",E0021);
					});

		} catch (org.apache.cxf.service.factory.ServiceConstructionException e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Platform.runLater(
					() -> {
						Messagebox.Error(BasFrame.mainStage, "E0021",E0021);
					});
		} catch (Exception e) {
			logger.log(Level.SEVERE, THROW_INFO, e);
			e.printStackTrace();
			Platform.runLater(
					() -> {
						Messagebox.Error(BasFrame.mainStage, "E0001",E0001);
					});
		}

		logger.log(Level.INFO, "END -uploadImage");
		return ret;

	}

}
