/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.meida.video.common;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Callback;
import jp.co.inc.meida.video.utils.FileInfoBean;

public class BasFrame extends Application implements MediaPlay, BasConst {

	private static final Window mStage = null;

	
	// 左フレーム
	VBox leftFrame;
	
	// フォルダ選択ボタン
	@FXML
	private Button BtnSelectFold;
	// 動画リスト
	
	@FXML
	private Pane paneFileList;

	// テクストボックス　検索
	private TextField txtFind;
	// 検索ボタン
	private Button btnSearch;

	// 患者リスト
	private Pane vbPatientList;
	
	
	private TableView<FileInfoBean> table;
	
	// サブぺネル
	private BorderPane bp1 = new BorderPane();
	private BorderPane bp2 = new BorderPane();
	private BorderPane bp3 = new BorderPane();
	private BorderPane bp4 = new BorderPane();
	private BorderPane bp5 = new BorderPane();

	// メインぺネル
	private BorderPane bp = new BorderPane();
	private HBox hvBoxMainPane;

	// カレンダー
	private DatePicker checkInDatePicker;
	private final String pattern = "yyyy/MM/dd";

	// 動画送信 ボタン
	private Button btnSend;

	// キャンセル ボタン
	private Button btnCancel;

	// 削除 ボタン
	private Button btnDelete;

	// 状況
	private Label lblStats;

	// プログレスバー
	private ProgressBar progressBar;

	// 備考
	TextField txtABikou;

	private String currentDir = System.getProperty("user.dir");

	private VBox vboxfileList;

	// 動画ファイルリスト
	ObservableList<FileInfoBean> fileInfolist = FXCollections.observableArrayList();

	ListView<String> pics_list_view = new ListView<String>();
	ObservableList<String> pics_name_list = FXCollections.observableArrayList();

	ObservableMap<String, String> mediaMap = FXCollections.observableHashMap();


	/**
	 * 画面スタート
	 * @param primaryStage
	 */		@Override
	public void start(Stage primaryStage) {
		// 初期化
		initUI(primaryStage);
	}

	/**
	 * メイン
	 * @param args
	 */		
	 public static void main(String[] args) {
		launch(args);

	}

	/**
	 * Appends text to the end of the specified TextArea without moving the scrollbar.
	 * @param ta TextArea to be used for operation.
	 * @param text Text to append.
	 */
	public static void appendTextToTextArea(TextArea ta, String text) {
		double scrollTop = ta.getScrollTop();
		ta.setText(ta.getText() + text);
		ta.setScrollTop(scrollTop);
	}
	
	/**
	 * 画面コントロール設定
	 * @param primaryStage
	 */	
	public void initUI(Stage primaryStage) {
		try {

			// ベース
			final BorderPane root = new BorderPane();
			root.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");
			
			// メニュー作成
			MenuBarFx menuBar = new MenuBarFx(this);
			// Top追加
			root.setTop(menuBar);

			// bottom HBox
			final HBox hvMediaBottom1 = new HBox();

			// 状況
			lblStats = new Label(STATUSBAR_TITLE_STATAS);
			lblStats.setPrefWidth(700);
			hvMediaBottom1.getChildren().add(lblStats);

			// プログレスバー
			progressBar = new ProgressBar();
			progressBar.setPrefHeight(25);
			hvMediaBottom1.getChildren().add(progressBar);

			// Bottom追加
			root.setBottom(hvMediaBottom1);

			final Label lbLeft = new Label();
			lbLeft.setPrefWidth(5);
			// Left追加
			root.setLeft(lbLeft);

			final Label lbRight = new Label();
			lbRight.setPrefWidth(5);
			// Right追加
			root.setRight(lbRight);

			// フォームSplitPane
			SplitPane splitPane = new SplitPane();

			// Center追加
			root.setCenter(splitPane);

			// 左フレーム
			leftFrame = new VBox();
			leftFrame.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			
			// フォルダ選択
			final HBox btnFoldSelect = new HBox();
			BtnSelectFold = new Button(BUTTON_FOLD_SELECT);
			BtnSelectFold.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			BtnSelectFold.setAlignment(Pos.TOP_LEFT);
			btnFoldSelect.getChildren().add(BtnSelectFold);
			btnFoldSelect.setAlignment(Pos.TOP_LEFT);
		
			// ファイル一覧
			paneFileList = new Pane();
			paneFileList.setMaxHeight(FILE_LIST_HEIGHT);
			paneFileList.setMinHeight(FILE_LIST_HEIGHT);
			paneFileList.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");
			
			// 検索
			final HBox hvBoxSearch = new HBox();
			// 検索テクストボックス
			txtFind = new TextField();
			txtFind.setPromptText("患者検索");
			txtFind.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			txtFind.prefWidthProperty().bind(hvBoxSearch.widthProperty());
			// 検索ボタン
			btnSearch = new Button("検索");
			btnSearch.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			hvBoxSearch.getChildren().addAll(txtFind, btnSearch);

			// 患者一覧
			vbPatientList = new Pane();
//			vbPatientList.setMinHeight(FILE_LIST_HEIGHT);
//			vbPatientList.setMaxHeight(FILE_LIST_HEIGHT);
			
			vbPatientList.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");

			leftFrame.prefHeightProperty().bind(vbPatientList.heightProperty());
			


			// 左垂直SplitPane
			final SplitPane splitLeft = new SplitPane();
			splitLeft.setOrientation(Orientation.VERTICAL);
			splitLeft.getItems().addAll(btnFoldSelect, paneFileList,hvBoxSearch, vbPatientList);
			splitLeft.setDividerPositions( 0.2f, 0.4f);
			
			leftFrame.getChildren().add(splitLeft);

			bp1 = new BorderPane();
			bp2 = new BorderPane();
			bp3 = new BorderPane();
			bp4 = new BorderPane();
			bp5 = new BorderPane();
			
			// MediaSub垂直SplitPane
			final SplitPane splitMediaSub = new SplitPane();
			splitMediaSub.setOrientation(Orientation.HORIZONTAL);
			splitMediaSub.getItems().addAll(bp1, bp2, bp3, bp4, bp5);
			
		    final double pos[] =
		        {
		        		0.2f, 0.4f, 0.6f, 0.8f
		        };

		    splitMediaSub.setDividerPositions( 0.2f, 0.4f, 0.6f, 0.8f);
		    
		    for ( int i = 0; i < splitMediaSub.getDividers().size(); i++ )
		    {
		        final int ind = i;
		        SplitPane.Divider divider = splitMediaSub.getDividers().get( i );
		        divider.positionProperty().addListener(new ChangeListener<Number>()
		        {
		            @Override
		            public void changed( ObservableValue<? extends Number> observable, Number oldValue, Number newValue )
		            {
		                divider.setPosition( pos[ind] );
		            }
		        });
		    }

		    // メインぺネル
			hvBoxMainPane = new HBox();

			bp.setPrefSize(500, 300);
			bp.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");
			hvBoxMainPane.getChildren().add(bp);

			hvBoxMainPane.setAlignment(Pos.CENTER);

			final HBox hvMediaBottom = new HBox();
			final VBox vblank1 = new VBox();
			vblank1.setPrefWidth(20);
			final VBox vblank2 = new VBox();
			vblank2.setPrefWidth(20);
			final VBox vblank3 = new VBox();
			vblank3.setPrefWidth(20);
			final VBox vblank4 = new VBox();
			vblank4.setPrefWidth(20);
			final VBox v1 = new VBox();
			final VBox v2 = new VBox();
			final VBox v3 = new VBox();
			final VBox v4 = new VBox();

			final Label labBikou = new Label("備考：");
			labBikou.setAlignment(Pos.BOTTOM_LEFT);
			labBikou.setStyle("-fx-border-style: solid; -fx-border-width: 1 1 1 1;");

			labBikou.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			txtABikou = new TextField("");
			txtABikou.setStyle("-fx-font-size: 15; -fx-font-weight: bold");

			final TextArea textArea = new TextArea();
			textArea.setPrefWidth(300);

			textArea.setMaxHeight(30);
			textArea.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			textArea.setWrapText(true);
			textArea.setMinHeight(40);

			// カレンダーコントロール
			checkInDatePicker = new DatePicker();
			checkInDatePicker.setMinWidth(30);
			checkInDatePicker.setMaxWidth(140);
			checkInDatePicker.setStyle("-fx-font-size: 15; -fx-font-weight: bold");

			checkInDatePicker.setPromptText(pattern.toLowerCase());

			checkInDatePicker.setValue(LocalDate.now());

			final GridPane gridPane = new GridPane();
			gridPane.setHgap(10);
			gridPane.setVgap(10);
			gridPane.add(checkInDatePicker, 0, 0);

			v1.getChildren().add(gridPane);

			hvMediaBottom.getChildren().add(v1);
			hvMediaBottom.getChildren().add(vblank1);
			hvMediaBottom.getChildren().add(labBikou);
			hvMediaBottom.getChildren().add(textArea);
			hvMediaBottom.getChildren().add(vblank4);
			hvMediaBottom.getChildren().add(v2);
			hvMediaBottom.getChildren().add(vblank2);
			hvMediaBottom.getChildren().add(v3);
			hvMediaBottom.getChildren().add(vblank3);
			hvMediaBottom.getChildren().add(v4);

			/*// 送信、キャンセル、削除ボタン
			 */
			// 動画送信 ボタン
			btnSend = new Button("送    信");
			btnSend.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			v2.getChildren().add(btnSend);

			// キャンセル ボタン
			btnCancel = new Button("キャンセル");
			btnCancel.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			v3.getChildren().add(btnCancel);

			// 削除 ボタン
			btnDelete = new Button("削    除");
			btnDelete.setStyle("-fx-font-size: 15; -fx-font-weight: bold");
			v4.getChildren().add(btnDelete);

//			rightFrame.prefWidthProperty().bind(hvMediaBottom.widthProperty());
//			rightFrame.getChildren().add(hvMediaBottom);

			// 配置⇒中央設定
			hvMediaBottom.setAlignment(Pos.CENTER);

			
			// 左垂直SplitPane
			final SplitPane splitRight = new SplitPane();
			splitRight.setOrientation(Orientation.VERTICAL);
			splitRight.getItems().addAll(splitMediaSub, bp);

		    final double posH[] =
		        {
		            0.2f
		        };

		    splitRight.setDividerPositions( posH );
			
		    
		    
		    
		    for ( int i = 0; i < splitRight.getDividers().size(); i++ )
		    {
		        final int ind = i;
		        SplitPane.Divider divider = splitRight.getDividers().get( i );
		        divider.positionProperty().addListener(new ChangeListener<Number>()
		        {
		            @Override
		            public void changed( ObservableValue<? extends Number> observable, Number oldValue, Number newValue )
		            {
		                divider.setPosition( posH[ind] );
		            }
		        });
		    }
		    
		    
			// ベース
		    final BorderPane rootRight = new BorderPane();
			rootRight.setStyle("-fx-border-style: solid; -fx-border-width: 0 0 0 0;");
		    
			// Bottom追加
			rootRight.setBottom(hvMediaBottom);
		    
			// Center追加
			rootRight.setCenter(splitRight);
			
//			rightFrame.getChildren().add(splitRight);

			// 左、右フレームを親子フレームに追加
			splitPane.getItems().addAll(leftFrame, rootRight);

			// 左、右フレーム分割
			splitPane.setDividerPositions(0.2f, 0.8f);

			//シーンをセット(ウィンドウサイズに影響を与えます)
			Scene scene = new Scene(root, 1000, 500);
			splitPane.prefWidthProperty().bind(scene.widthProperty());
			splitPane.prefHeightProperty().bind(scene.heightProperty());

			//ウィンドウタイトル
			primaryStage.setTitle(SYSTEM_NAME);

			//ウィンドウサイズ変更の無効化
			primaryStage.setResizable(true);

			//アイコンの設定
			Image img = new Image(getClass().getResourceAsStream("../img/media.jpg"));
			primaryStage.getIcons().add(img);

			//フルスクリーンモードのオン、オフ
			//フルスクリーンオンの時はescキーで解除できます
			primaryStage.setFullScreen(false);

			primaryStage.setScene(scene);
			primaryStage.show();

			
//			/**
//			  フレームサイズ変更の場合、発生するイベント処理
//			**/
//			
//			// 右フレーム幅サイズ変更時のイベント
//			primaryStage.widthProperty().addListener((observable, oldValue, newValue) -> {
//				lblStats.setPrefWidth(((Double) newValue * 2 / 3));
//
//			});
//
//			rightFrame.widthProperty().addListener((observable, oldValue, newValue) -> {
//				bp.setPrefWidth(((Double) newValue * 3 / 5));
//				bp1.setPrefWidth(((Double) newValue * 1 / 5));
//				bp2.setPrefWidth(((Double) newValue * 1 / 5));
//				bp3.setPrefWidth(((Double) newValue * 1 / 5));
//				bp4.setPrefWidth(((Double) newValue * 1 / 5));
//				bp5.setPrefWidth(((Double) newValue * 1 / 5));
//
//			});
//
//			// 右フレーム高さサイズ変更時のイベント
//			rightFrame.heightProperty().addListener((observable, oldValue, newValue) -> {
//				bp.setPrefHeight(((Double) newValue * 4 / 7));
//				bp1.setPrefHeight(((Double) newValue * 2 / 7));
////				hvMediaBottom.setPrefHeight(((Double) newValue * 1 / 7));
//			});
//
//			// 左フレーム高さサイズ変更時のイベント
//			leftFrame.heightProperty().addListener((observable, oldValue, newValue) -> {
//
////				vboxfileList.setMaxHeight(((Double) newValue * 1 / 2));
//
//			});
			
			//フォルダ選択ボタンイベント処理
			BtnSelectFold.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					try {
						onClickBtnSelectFold(e);
					} catch (IOException e1) {
						// TODO 自動生成された catch ブロック
						e1.printStackTrace();
					}

				}
			});
			
			
			// ファイルリスト初期化
			initScreen(fileInfolist);
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * フォルダ選択処理
	 * @param event
	 * @throws IOException
	 */	
	@FXML
	void onClickBtnSelectFold(ActionEvent event) throws IOException {

		try {

			FileChooser fileChooser = new FileChooser();

			fileChooser.setTitle("ファイル選択");
			// 拡張子フィルタを設定
			fileChooser.getExtensionFilters().add(
					new FileChooser.ExtensionFilter("イメージファイル", "*.mp4"));
			fileChooser.getExtensionFilters().add(
					new FileChooser.ExtensionFilter("すべてのファイル", "*.mp4"));
			// 初期ディレクトリをホームにする。
			fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));

			// ファイル選択
			List<File> list = fileChooser.showOpenMultipleDialog(mStage);

			boolean isExist = true;
			ObservableMap<String, String> mediatmpMap = FXCollections.observableHashMap();

			
	        //最終更新日時表示書式
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			
			int ifile = 0;
			if (list != null) {

				for (FileInfoBean fb : fileInfolist) {

					mediatmpMap.putIfAbsent(fb.fileName, "");
				}

				for (File file : list) {
					// openFile(file);

					// 事前チェック
					if (!mediatmpMap.containsKey(file.getName())) {
						mediatmpMap.putIfAbsent(file.getName(), "");
					} else {
						infoMessageBox("[" + file.getName() + "]" + "は重複です。", "エラー", "メセージ");
						isExist = false;
						mediatmpMap = null;
						break;
					}

					ifile++;

				}

				if (isExist) {

					ifile = 0;
					for (File file : list) {

						mediaMap.putIfAbsent(file.getName(), "");

						FileInfoBean f = new FileInfoBean();
						f.setFileName(file.getName());
						f.setFilePath(file.getPath());
						
				        //対象ファイルの最終更新日時取得（1970年1月1日からの経過時間）
				        Long lastModified = file.lastModified();
						// 最終更新日時書式整形
						f.setUpdateDate(sdf.format(lastModified));

						// 動画ファイルサイズ(byte)
						f.setFileSize(file.length());

						
						fileInfolist.add(f);

						if (ifile == 0) {
							f.setStatus(STATUS_NEW);

						} else if (ifile == 1) {
							f.setStatus(STATUS_WORKING);

						} else if (ifile == 2) {
							f.setStatus(sSTATUS_COMPLETED);
						} else if (ifile == 3) {
							f.setStatus("2");

						} else if (ifile == 4) {
							f.setStatus(STATUS_NEW);

						} else if (ifile == 5) {
							f.setStatus(STATUS_WORKING);

						} else if (ifile == 6) {
							f.setStatus(sSTATUS_COMPLETED);

						} else if (ifile == 7) {
							f.setStatus(STATUS_NEW);

						}

						ifile++;

					}

					// ファイルリスト初期化
					initScreen(fileInfolist);
					
					// ファイル一覧拙宅
					table.requestFocus();
					table.getSelectionModel().selectFirst();
					table.getFocusModel().focus(0);
				}

			}

		} catch (IllegalArgumentException e) {
			//			logger.log(Level.INFO, "例外のスローを捕捉", e);
		} catch (SecurityException e) {
			e.printStackTrace();
		}

	}

	/**
	 * メッセージボックス
	 * @param infoMessage
	 * @param headerText
	 * @param title
	 * @return
	 */	
	public static boolean infoMessageBox(String infoMessage, String headerText, String title) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setContentText(infoMessage);
		alert.setTitle(title);
		alert.setHeaderText(headerText);
		alert.getButtonTypes();

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK) {
			// ... user chose OK button
			return true;
		} else {
			// ... user chose CANCEL or closed the dialog
			return false;
		}

	}
	
	/**
	 * 画面レイアウト初期化
	 * @param fileList
	 */	
	private void initScreen(ObservableList<FileInfoBean> fileList) {

		//初期化
		vboxfileList = new VBox();

		vboxfileList.setMinWidth(600);
		vboxfileList.setMaxWidth(600);
		vboxfileList.setMinHeight(FILE_LIST_HEIGHT);
		vboxfileList.setMaxHeight(FILE_LIST_HEIGHT);
//		vboxfileList.setFillWidth(true);


		// 初期化
		vboxfileList.getChildren().clear();
		paneFileList.getChildren().clear();

		
		table = new TableView<>();
		final ObservableList<TableColumn<FileInfoBean, ?>> columns = table.getColumns();

		final TableColumn<FileInfoBean, Label> fileStatusColumn = new TableColumn<FileInfoBean, Label>(FILE_TITLE_STATAS);

		final TableColumn<FileInfoBean, String> fileNameColumn = new TableColumn<>(FILE_TITLE_NAME);
		fileNameColumn.setCellValueFactory(new PropertyValueFactory<>("fileName"));

		final TableColumn<FileInfoBean, String> lastedUpdateColumn = new TableColumn<>(FILE_TITLE_LASTED_UPDATE);
		lastedUpdateColumn.setCellValueFactory(new PropertyValueFactory<>("updateDate"));

		final TableColumn<FileInfoBean, String> fileSizeColumn = new TableColumn<>(FILE_TITLE_SIZE);
		fileSizeColumn.setCellValueFactory(new PropertyValueFactory<>("fileSize"));

		
//		fileStatusColumn.setMaxWidth(30);

//		// カラム幅設定
//		fileNameColumn.setMinWidth(176);
//		// カラム幅設定
//		lastedUpdateColumn.setMinWidth(176);
//		// カラム幅設定
//		fileSizeColumn.setMinWidth(176);
////		// カラム幅設定
//		fileNameColumn.setMinWidth(176);


		/**
		  ファイルリストクリックイベント処理
		**/
		setCellValueFactory(fileStatusColumn);

		// カラム追加
		columns.add(fileStatusColumn);
		columns.add(fileNameColumn);
		columns.add(lastedUpdateColumn);
		columns.add(fileSizeColumn);
		table.setItems(fileList);
		// sort
		table.sort();

		vboxfileList.getChildren().clear();

		HBox hbox = new HBox();
//		vboxfileList.getChildren().add(hbox);
		vboxfileList.getChildren().add(table);

//		HBox hbox1 = new HBox();
//		vboxfileList.getChildren().add(hbox);
		
		
//		vboxfileList.setMaxHeight(((Double) leftFrame.maxHeightProperty().getValue() * 1 / 2));
//		
//		paneFileList.prefHeightProperty().bind(vboxfileList.heightProperty());
		
		paneFileList.getChildren().add(vboxfileList);
		paneFileList.prefHeightProperty().bind(table.heightProperty());
//		paneFileList.prefWidthProperty().bind(vboxfileList.widthProperty());

		if (fileList.size() > 0) {
			//選択状態を検知するバインディングの設定
			table_addListener(fileList);
			
		}

	}


	/**
	 * テーブルリスナー
	 * @param fileList
	 */
	void table_addListener(ObservableList<FileInfoBean> fileList ){
		table.getSelectionModel().selectedItemProperty().addListener((ov, old, current) -> {
			//どこが選択されてるか確認用出力
			System.out.println("選択セル（TableView）");

			System.out.println(current.filePath);

			bp.getChildren().clear();
			bp1.getChildren().clear();
			bp2.getChildren().clear();
			bp3.getChildren().clear();

			// シーングラフを作成
			BorderPane pa = bp;
			// 動画ファイルのパスを取得
			File file = new File(current.filePath);
			mediaSet(pa, file, 1);

			if (fileList != null) {

				for (int count = 0; count <= fileList.size() - 1; count++) {
					FileInfoBean user = new FileInfoBean();
					user = fileList.get(count);

					if (user.fileName.equals(current.fileName)) {

						if (count >= 0 && count < fileList.size() - 2) {

							// シーングラフを作成
							pa = bp1;

							// 動画ファイルのパスを取得
							file = new File(user.filePath);
							mediaSet(pa, file, 0);

							// シーングラフを作成
							pa = bp2;
							// 動画ファイルのパスを取得
							file = new File(fileList.get(count + 1).filePath);
							mediaSet(pa, file, 0);

							// シーングラフを作成
							pa = bp3;
							// 動画ファイルのパスを取得
							file = new File(fileList.get(count + 2).filePath);
							mediaSet(pa, file, 0);

						} else if (count == fileList.size() - 2) {

							// シーングラフを作成
							pa = bp1;
							// 動画ファイルのパスを取得
							file = new File(user.filePath);
							mediaSet(pa, file, 0);

							// シーングラフを作成
							pa = bp2;
							// 動画ファイルのパスを取得
							file = new File(fileList.get(count + 1).filePath);
							mediaSet(pa, file, 0);

						} else if (count == fileList.size() - 1) {

							// シーングラフを作成
							pa = bp1;
							// 動画ファイルのパスを取得
							file = new File(user.filePath);
							mediaSet(pa, file, 0);

						}

					}

				}

			}
		});

	}


	/**
	 * キー解放イベント
	 */
	void setOnKeyReleased(){
		table.setOnKeyReleased((KeyEvent t) -> {
	        switch (t.getCode()) {
	            //other code cut out here
	            case Z:
	                if (t.isControlDown()) {

	                    break; //don't break for regular Z
	                }
	            default: 
	                if (t.getCode().isLetterKey() || t.getCode().isDigitKey()) {

	                }
	        }
	    });
	}
	
	/**
	 * セールファクトリー
	 * @param fileStatusColumn
	 */
	void setCellValueFactory(TableColumn<FileInfoBean, Label> fileStatusColumn ){
		fileStatusColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<FileInfoBean, Label>, ObservableValue<Label>>() {

					@Override
					public ObservableValue<Label> call(TableColumn.CellDataFeatures<FileInfoBean, Label> arg0) {
						FileInfoBean data = arg0.getValue();
						Label label = new Label();
						label.setTextFill(Color.RED);

						label.setBackground(new Background(
								new BackgroundFill(Color.BLUEVIOLET, new CornerRadii(10), new Insets(5))));

						label.setPrefSize(10, 10);

						if (data.getStatus().equals(STATUS_NEW)) {

							Image imageDecline = new Image(getClass().getResourceAsStream("../img/unreg.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(STATUS_WORKING)) {

							Image imageDecline = new Image(getClass().getResourceAsStream("../img/loading.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);

						} else if (data.getStatus().equals(sSTATUS_COMPLETED)) {

							Image imageDecline = new Image(getClass().getResourceAsStream("../img/finish.png"));
							ImageView img = new ImageView(imageDecline);
							img.setFitWidth(30);
							img.setFitHeight(30);
							label.setGraphic(img);
						}

						return new SimpleObjectProperty<Label>(label);
					}

				});
	}
	
	/**
	 * コントロールを画面に設定
	 * @param pa
	 * @param f
	 * @param showPlay
	 */
	 void mediaSet(BorderPane pa, File f, int showPlay) {
		// 動画再生クラスをインスタンス化
		Media Video = new Media(f.toURI().toString());
		MediaPlayer Play = new MediaPlayer(Video);
		MediaView mediaView = new MediaView(Play);
		mediaView.setFitWidth(pa.getWidth());
		mediaView.setFitHeight(pa.getHeight());
		
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		
		pa.setCenter(mediaView);
		if (showPlay == 1) {
			// 画面下に表示する情報バーを作成
			HBox bottomNode = new HBox(10.0);
			bottomNode.getChildren().add(MediaPlay.createButton(Play)); // 再生・停止・繰り返しボタン作成
			bottomNode.getChildren().add(MediaPlay.createTimeSlider(Play)); // 時間表示スライダ作成
			bottomNode.getChildren().add(MediaPlay.createVolumeSlider(Play)); // ボリューム表示スライダ作成
			pa.setBottom(bottomNode);

		}
	}

}
