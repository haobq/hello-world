package helloservice.clientcert.endpoint;

public class Hello {

	public String sayHello(String name) {
		// TODO 自動生成されたメソッド・スタブ
		return "hello hao";
	}

}
