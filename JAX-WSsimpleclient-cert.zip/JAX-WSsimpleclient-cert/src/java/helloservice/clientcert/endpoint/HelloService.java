package helloservice.clientcert.endpoint;

public class HelloService {

	public Hello getHelloPort() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
