/**
 * 2020 MEDIA CO.,LTD. All Rights Reserved.
 *
 * @author isss_hao
 * @version 1.0 2020/09/01
 */
package jp.co.inc.meida.video.common;


public class BootBean implements MessageConst {

    /**
     * システム情報を取得するメソッド。
     */
    public void readSystemInfo() {
    }
}
