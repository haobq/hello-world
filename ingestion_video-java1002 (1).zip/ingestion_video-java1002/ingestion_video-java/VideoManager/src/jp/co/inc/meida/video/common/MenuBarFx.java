package jp.co.inc.meida.video.common;

import javafx.event.ActionEvent;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;

public class MenuBarFx  extends MenuBar{

	//メニューバーに付けるメニュー
	Menu menu1 = null; 
	Menu menu2 = null;
	Menu menu3 = null;
	Menu menu4 = null;

	//メニューバーにつけるメニューアイテム
	public MenuItem menuitem11 = null;
	public MenuItem menuitem12 = null;
	public MenuItem menuitem21 = null;
	public MenuItem menuitem22 = null;
	public MenuItem menuitem31 = null;
	public MenuItem menuitem41 = null;
	private BasFrame basFrame;

	public MenuBarFx( BasFrame  basFrame ){
		this.basFrame = basFrame;
		this.setMenuBar();
	}


	/**
	 * メニューバーにメニューを設置する
	 */
	public void setMenuBar(){

		//menu1にメニューアイテムを登録する
		menu1 = new Menu("設定");
		menuitem11 = new MenuItem("設定1");
		menuitem11.addEventHandler( ActionEvent.ACTION , e -> this.event( menuitem11.getText() ) );
		menu1.getItems().add(menuitem11);
		menu1.getItems().add( new SeparatorMenuItem() );
		menuitem12 = new MenuItem("設定2");
		menuitem12.addEventHandler( ActionEvent.ACTION , e -> this.event( menuitem12.getText() ) );
		menu1.getItems().add(menuitem12);

		//menu2にメニューアイテムを登録する
		menu2 = new Menu("マニュアル");
		menuitem21 = new MenuItem("マニュアル1");
		menuitem21.addEventHandler( ActionEvent.ACTION , e -> this.event( menuitem21.getText() ) );
		menu2.getItems().add(menuitem21);

		//menu3にメニューアイテムを登録する
		menu3 = new Menu("送信履歴");
		menuitem31 = new MenuItem("送信履歴");
		menuitem31.addEventHandler( ActionEvent.ACTION , e -> this.event( menuitem31.getText() ) );
		menu3.getItems().add(menuitem31);		

		//menu4にメニューアイテムを登録する
		menu4 = new Menu("ログイン");
		menuitem41 = new MenuItem("ログイン");
		menuitem41.addEventHandler( ActionEvent.ACTION , e -> this.event( menuitem41.getText() ) );
		menu4.getItems().add(menuitem41);		


		//メニューバーにメニューを登録
		this.getMenus().add( menu1 );
		this.getMenus().add( menu2 );
		this.getMenus().add( menu3 );
		this.getMenus().add( menu4 );
	}

	//イベントの受付
	private void event(String s){
		if ( s.equals( "新規作成" )) {
			//				ap.l.setText( "新規作成" );
		}else if ( s.equals( "開く" )) {
			//				ap.l.setText( "開く" );
		}else if ( s.equals( "設定1" )) {
			//				ap.l.setText( "設定1" );
		}else if ( s.equals( "設定2" )) {
			//				ap.l.setText( "設定2" );
		}
	}

}
