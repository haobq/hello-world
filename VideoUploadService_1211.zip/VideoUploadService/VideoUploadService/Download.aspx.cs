using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VideoUploadService
{
    public partial class Download : System.Web.UI.Page
    {
        readonly String basePath = System.Configuration.ConfigurationManager.AppSettings["DownloadFolder"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void Mac64_download_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"vediomanager_win32_setup.msi\"");
            Response.WriteFile(basePath+"1.0.0/vediomanager_win32_setup.msi");
            Response.End();
        }
        public void Win64_download_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"vediomanager_win64_setup.msi\"");
            Response.WriteFile(basePath + @"1.0.0/vediomanager_win64_setup.msi");
            Response.End();
        }
        public void Win32_download_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"vediomanager_win32_setup.msi\"");
            Response.WriteFile(basePath + @"1.0.0/vediomanager_win32_setup.msi");
            Response.End();
        }

        public void Mac64_install_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"install_mac64.pdf\"");
            Response.WriteFile(basePath+ @"1.0.0/install_mac64.pdf");
            Response.End();
        }
        public void Win64_install_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"install_win64.pdf\"");
            Response.WriteFile(basePath+ @"1.0.0/install_win64.pdf");
            Response.End();
        }
        public void Win32_install_Click(Object sender, EventArgs e)
        {
            Response.AddHeader("Content-Type", "application/octet-stream");
            Response.AddHeader("Content-Transfer-Encoding", "Binary");
            Response.AddHeader("Content-disposition", "attachment; filename=\"install_win32.pdf\"");
            Response.WriteFile(basePath+ @"1.0.0/install_win32.pdf");
            Response.End();
        }
    }
}