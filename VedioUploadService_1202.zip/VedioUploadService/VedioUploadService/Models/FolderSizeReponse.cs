﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class FolderSizeReponse
    {
        public long Contract_size { get; set; }
        public long Used_size { get; set; }
        public long Free_size { get; set; }
    }
}