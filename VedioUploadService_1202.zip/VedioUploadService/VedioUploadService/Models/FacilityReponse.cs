﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VedioUploadService.Models
{
    public class FacilityReponse
    {
        //訪問先ID
        public string Visit_id { get; set; }
        //訪問先名
        public string Visit_name { get; set; }
        //訪問先区分
        public string visit_kbn { get; set; }
    }
}